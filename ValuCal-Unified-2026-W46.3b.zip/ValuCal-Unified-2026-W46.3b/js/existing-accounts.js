/* \u2500\u2500 Existing Accounts mode for the unified file (2026-10-09) \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
   Migration step 1 (homologation-map.md): everything Existing Accounts has, in the single file.
   \u2022 Existing-only state and functions (transaction forms, Renewal / Rewrap, Cancel MC, non-renewal,
     account price list\u2026) \u2014 moved verbatim from ExistingAccounts/index.html; no name clashes.
   \u2022 EXISTING_ACCOUNTS_OVERRIDES \u2014 the Existing version of each step that differs from Initial Sales.
     setExistingAccountsMode(true) swaps them in for a customer scenario and restores the Initial Sales
     ones otherwise. Each entry is a convergence TODO: once merged into one shared function with account
     variables (homologation-map.md \u00a72\u2013\u00a74), it is deleted from this list.
   Loaded by ValuCal-MSA/index.html after the shared modules (needs vc-existing-accounts.js). */

// \u2500\u2500 Existing-only state \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
let selectedSubIds = new Set();
let txPreselectedSubIds = [];
let vzUpsellPreSelected = [];
let vzUpsellPreSelectedFeatures = [];
let vzReactivationPreSelected = [];
// 2026-10-15 (per Catalina): Feature Upsell starts By vehicle by default (first option of the switch).
let upsellMode = 'vehicles';
let vzSubFilter = { products: [], statuses: [] };
let selectedTxTypeVZ = null;
let vzUpsellDiscountPct = 0;
let accountPriceListGroupBy = 'subscription';
let accountPriceListModalOptId = null;
const ELIGIBLE_SUBSCRIPTION_ROW_NAMES = new Set(['Vehicle Tracking', 'Forward Facing Camera Subscription', 'Dual Camera Subscription']);
const DEMO_PREVIOUSLY_DEACTIVATED_UNITS = [
  { id: 'deact-1', coreKey: 'vtu-ffc', coreName: 'VTU + FFC', qty: 3, deactivatedDate: '2026-08-01', reason: 'downgrade' },
  { id: 'deact-2', coreKey: 'asset-powered', coreName: 'Powered Asset Tracking Subscription', qty: 2, deactivatedDate: '2026-07-15', reason: 'cancellation' },
];
const HARDWARE_VALUES = {
  'vtu': 150.00,
  'vtu-ffc': 220.00,
  'vtu-dual': 280.00,
  'asset-powered': 120.00,
  'asset-nonpowered': 90.00,
};
const HARDWARE_RETURN_WINDOW_DAYS = 30;
const CANCEL_PENALTY_WAVES = [
  { id: 'loyalty', name: 'Loyalty Wave \u2014 25% off', pct: 25 },
  { id: 'retention', name: 'Retention Wave \u2014 50% off', pct: 50 },
  { id: 'hardship', name: 'Hardship Wave \u2014 100% waived', pct: 100 },
];
const VZ_UPSELL_FEATURES = [
  // Video Features
  { key: 'ffc',      label: 'Forward Facing Camera',      price: 30.00, category: 'video' },
  // 2026-10-21 (Leo): FFC and Dual are the same camera — Dual adds a small driver facing camera to the FFC. So in an
  // upsell the feature is "Driver Facing Camera" (needs the FFC: on the vehicle or added with it). Key stays 'dual'
  // (the vehicle ends on VTU + Dual Camera). Price = Dual − FFC (placeholder).
  { key: 'dual',     label: 'Driver Facing Camera',       price: 10.00, category: 'video' },
  { key: 'evc',      label: 'Extended View Cameras',      price: 15.00, category: 'video' },
  { key: 'monitor',  label: 'In-Cab Monitor',             price: 12.00, category: 'video' },
  { key: 'adas',     label: 'ADAS',                       price:  5.00, category: 'video' },
  { key: 'sd',       label: '256 GB SD Card',             price:  5.00, category: 'video' },
  // Vehicle Features
  { key: 'eld',      label: 'Electronic Logging (ELD)',   price: 15.00, category: 'vehicle' },
  { key: 'driverid', label: 'Driver ID',                  price:  2.00, category: 'vehicle' },
  { key: 'logbook',  label: 'Logbook',                    price:  3.00, category: 'vehicle' },
  { key: 'privacy',  label: 'Privacy Button',             price:  1.00, category: 'vehicle' },
  // Software Features (2026-11-10, per Catalina — from development's build)
  { key: 'navigation', label: 'Reveal Navigation',                  price: 7.00, category: 'software' },
  { key: 'rsa',        label: 'Roadside Assistance Subscription',   price: 0.00, category: 'software' },
  { key: 'dvir',       label: 'DVIR Vehicle Walkaround Inspection', price: 5.00, category: 'software' },
];
const vzProductLabels = {
  'vts':   'Vehicle Tracking (VTS)',
  'pat':   'Powered Asset (PAT)',
  'npat':  'Non-Powered Asset (NPAT)',
  'ffc':   'Forward Facing Camera',
  'dual':  'Driver Facing Camera (Dual)',
  'adas':  'ADAS Camera',
  'sd':    'SD Card Upgrade',
  'driverid': 'Driver ID',
  'eld':   'Electronic Logging (ELD)',
  'rsa':   'Roadside Assistance Subscription',
  'navigation': 'Reveal Navigation',
  'dvir':  'DVIR Vehicle Walkaround Inspection',
  'monitor': 'In-Cab Monitor',
  'evc':   'Extended View Cameras',
  'privacy': 'Privacy Button',
  'logbook': 'Logbook',
};
const VZ_UPSELL_FEATURE_TO_CATALOG_KEY = { driverid: 'driver-id' };
const VZ_UPSELL_CORE_ALIAS = { ffc: 'vtu-ffc', dual: 'vtu-dual' };
const VZ_UPSELL_CORE_RANK = { vtu: 0, 'vtu-ffc': 1, 'vtu-dual': 2 };

// \u2500\u2500 Existing-only functions \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
function getTierEligibilityQty(totalUnits) {
  const qty = Number(totalUnits || 0);
  const minimumCommitment = Number(DEMO_MSA.minQuantityCommitment || 0);
  if (minimumCommitment > 0) {
    return Math.max(qty, minimumCommitment);
  }
  return qty;
}

function getApplicableTierIndex(totalUnits) {
  return getNaturalTierIndex(getTierEligibilityQty(totalUnits));
}

function matchPrebuiltTierForCombo(coreKey, featureKeys) {
  const sorted = [...featureKeys].sort();
  for (const bundleKey of Object.keys(PREBUILT_BUNDLES)) {
    const bundle = PREBUILT_BUNDLES[bundleKey];
    for (const tier of bundle.tiers) {
      if (tier.coreKey !== coreKey) continue;
      const tierSorted = [...(tier.includedFeatures || [])].sort();
      if (tierSorted.length === sorted.length && tierSorted.every((f, i) => f === sorted[i])) {
        return { bundleKey, bundle, tier };
      }
    }
  }
  return null;
}

function findClosestPrebuiltTier(coreKey, featureKeys) {
  const exact = matchPrebuiltTierForCombo(coreKey, featureKeys);
  if (exact) return exact;
  const targetSet = new Set(featureKeys);
  let best = null;
  let bestScore = -Infinity;
  Object.keys(PREBUILT_BUNDLES).forEach((bundleKey) => {
    const bundle = PREBUILT_BUNDLES[bundleKey];
    bundle.tiers.forEach((tier) => {
      const tierSet = new Set(tier.includedFeatures || []);
      const shared = [...tierSet].filter((f) => targetSet.has(f)).length;
      const differing = [...tierSet].filter((f) => !targetSet.has(f)).length
        + [...targetSet].filter((f) => !tierSet.has(f)).length;
      const coreMatchScore = tier.coreKey === coreKey ? 100 : 0;
      const score = coreMatchScore + shared * 2 - differing;
      if (score > bestScore) {
        bestScore = score;
        best = { bundleKey, bundle, tier };
      }
    });
  });
  return best;
}

function isOptionTierLocked(opt) {
  return !!opt && opt.transactionMode !== 'Rewrap' && opt.transactionMode !== 'Reactivation';
}

function getAccountMsaTierUnits() {
  return sumMsaTierQty((Array.isArray(existingOrders) ? existingOrders : []).flatMap(order => order.bundles || []));
}

function getActiveCustomPromotionsForPricing(opt, level) {
  if (!opt) return [];
  const isNewProposalChange = opt.transactionMode === 'Change' && proposalData.entryPoint === 'newProposal';
  const isRenewalRewrap = isSpecialOptionMode(opt);
  if (!isNewProposalChange && !isRenewalRewrap) return [];
  return getCustomPromotions(opt).filter(promotion => {
    if (!customPromoHasAnyValue(promotion)) return false;
    if (isNewProposalChange && promotion.level !== 'order') return false;
    return !level || promotion.level === level;
  });
}

function isSpecialOptionMode(opt) {
  return opt?.transactionMode === 'Renewal' || opt?.transactionMode === 'Rewrap';
}

function getDefaultEffectiveDate(mode) {
  if (mode === 'Renewal') {
    const endDate = parseProposalDate(DEMO_MSA.endDate);
    return endDate ? toIsoDate(addCalendarDays(endDate, 1)) : toIsoDate(new Date());
  }
  const today = new Date();
  return toIsoDate(new Date(today.getFullYear(), today.getMonth() + 1, 1));
}

function setOptionTransactionMode(id, mode) {
  const opt = options.find(o => o.id === id);
  if (!opt) return;
  opt.transactionMode = mode;
  // 2026-09-18 (R21.3, per Catalina): only Rewrap carries an effective date \u2014
  // Renewal (like Change) doesn't use one at all.
  if (mode === 'Change' || mode === 'Renewal') {
    opt.effectiveDate = '';
    opt.reason = '';
  } else if (!opt.effectiveDate || opt.effectiveDate < getDefaultEffectiveDate(mode)) {
    opt.effectiveDate = getDefaultEffectiveDate(mode);
  }
  renderOptions();
}

function renderOptionHeaderControls(opt) {
  // 2026-09-18 (R21.2, per Catalina): the Transaction control only exists
  // inside the Renewal/Rewrap flow, with exactly two choices (Renewal /
  // Rewrap) \u2014 "Create new proposal" cards never show this control at all,
  // because they only ever represent a single punctual change, not a choice
  // between renewing or rewrapping the whole contract.
  if (proposalData.entryPoint !== 'renewalRewrap' || opt.transactionMode === 'Reactivation') return '';
  // 2026-11-04 (per Catalina): a migration is neither a renewal nor a rewrap — no Rewrap / Renewal control.
  if (typeof migrationModeOn !== 'undefined' && migrationModeOn) return '';
  const mode = (opt.transactionMode === 'Rewrap') ? 'Rewrap' : 'Renewal';
  // 2026-09-18 (per Catalina, replacing a toggle-switch attempt from earlier
  // this session): a segmented control keeps both option names visible at
  // all times, so there's no ambiguity about which mode "off" represents \u2014
  // see CSS comment above .segmented-pill's former local rules for the accepted tradeoff if a
  // third transaction type is added later.
  return `<div class="option-header-controls">
    <div class="segmented-pill segmented-pill--on-dark" role="group" aria-label="Transaction type">
      <button type="button" class="segmented-pill__btn ${mode ==='Rewrap' ? 'is-active' : ''}" aria-pressed="${mode === 'Rewrap'}" onclick="setOptionTransactionMode(${opt.id}, 'Rewrap')">Rewrap</button>
      <button type="button" class="segmented-pill__btn ${mode ==='Renewal' ? 'is-active' : ''}" aria-pressed="${mode === 'Renewal'}" onclick="setOptionTransactionMode(${opt.id}, 'Renewal')">Renewal</button>
    </div>
  </div>`;
}

function openOptionListPriceFromCard(optId) {
  const opt = options.find(option => option.id === optId);
  if (!opt || !opt.bundles.length) return;
  const optionIndex = options.findIndex(option => option.id === optId);
  const bodyEl = document.getElementById('sub-price-list-modal-body');
  setPriceListModalTitle(opt, `Option ${Math.max(1, optionIndex + 1)}`);
  if (bodyEl) bodyEl.innerHTML = buildAccountPriceListHtml(opt, 'modal');
  document.getElementById('sub-price-list-modal-overlay')?.classList.add('is-open');
}

function renderOptionMotionControls(opt, termFieldHtml) {
  const mode = opt.transactionMode || 'Change';
  const defaultDate = getDefaultEffectiveDate(mode);
  const discount = getOptionDiscountPct(opt, opt.bundles[0]);
  const editable = isSpecialOptionMode(opt);
  if (!editable || mode === 'Reactivation') return '';
  if (mode === 'Rewrap') opt.effectiveDate = defaultDate;
  const termCellHtml = termFieldHtml || '<div></div>';
  // 2026-10-02 (per Catalina \u2014 Renewal / Rewrap use exactly the same model as
  // Initial Sales): the inline Discretionary Discount bar is replaced by the
  // single "Discounts & Promotions" button, which opens the shared drawer
  // with its MSA Discount (Discretionary) and Order Discount (Promotions)
  const discountBodyHtml = `<button type="button" class="btn btn--secondary btn--large btn-discounts-promotions" onclick="toggleOptPromoPanel(${opt.id})"><span class="material-symbols-outlined">sell</span> Discounts &amp; Promotions</button>`;
  // 2026-10-13 (per Catalina): same shared row as Initial Sales, so Contract term and the button sit side by side.
  return VC.optionTermDiscountRow({
    termHtml: termCellHtml,
    discountHtml: discountBodyHtml,
    showDiscount: true,
    unified: typeof discretionaryDiscountMode === 'undefined' || discretionaryDiscountMode === 'unified',
  });
}

function buildAccountSetupPricingPayload() {
  const mapLineItem = (b, opt, status) => {
    const promoType = b.promoType || getOptionPromotion(opt);
    let netPrice = null;
    try {
      netPrice = calcBundle(b, opt.term, promoType).unitPrice;
    } catch (_) { /* leave null if a bundle is mid-configuration and missing fields */ }
    return {
      product: b.coreName,
      discretionaryDiscountPct: (typeof b.msaDiscountPct === 'number') ? b.msaDiscountPct : null,
      term: parseInt(opt.term) || null,
      qty: b.qty,
      listPrice: getStandardUnitPrice(b),
      netPrice,
      optionName: opt.name,
      optionId: opt.id,
      status, // 'Existing' (already under contract) or 'New' (being drafted in this session)
    };
  };

  // Account level = everything already contracted (existingOrders, seeded
  // above) PLUS whatever new order(s) are being drafted right now (options).
  const existingLineItems = existingOrders.flatMap(opt => (opt.bundles || []).map(b => mapLineItem(b, opt, 'Existing')));
  const draftLineItems = options.flatMap(opt => (opt.bundles || []).map(b => mapLineItem(b, opt, 'New')));
  const accountLineItems = [...existingLineItems, ...draftLineItems];

  // Order level: if the rep is actively drafting a new order in this session
  // (bld.selectedOptionId set), show that. Otherwise, per Catalina (2026-09-16):
  // don't model a second, empty "order" as if it already existed \u2014 an order
  // isn't really created until the contract process finishes, so there's
  // nothing real to show for it yet. Default to the one order that DOES
  // already exist (existingOrders[0]) instead of an empty state, so the demo
  // always shows something real rather than "(no order selected)".
  const draftOpt = options.find(o => o.id === bld.selectedOptionId) || null;
  const currentOpt = draftOpt || existingOrders[0] || null;
  const currentOptStatus = draftOpt ? 'New' : 'Existing';
  const orderLineItems = currentOpt ? (currentOpt.bundles || []).map(b => mapLineItem(b, currentOpt, currentOptStatus)) : [];

  return {
    account: { lineItems: accountLineItems },
    order: {
      id: currentOpt ? currentOpt.id : null,
      name: currentOpt ? currentOpt.name : null,
      lineItems: orderLineItems,
    },
  };
}

function sendAccountSetupPricingData(frame) {
  if (!frame) return;
  const send = () => {
    try {
      // 2026-09-21 (per Catalina): also push the current auto-renewal state
      // so Account Setup reflects it on open \u2014 e.g. after "Disable
      // auto-renewal" is used from the MSA kebab, Account Setup should show
      // "No" (with reason/file) instead of defaulting back to "Yes".
      frame.contentWindow.postMessage({
        type: 'account-setup-pricing-data',
        ...buildAccountSetupPricingPayload(),
        msaAutoRenewal: DEMO_MSA.autoRenewalEnabled === false ? 'no' : 'yes',
        msaAutoRenewalReason: DEMO_MSA.autoRenewalCancellation?.reason || '',
        msaAutoRenewalFileName: DEMO_MSA.autoRenewalCancellation?.fileName || '',
        msaEndDate: DEMO_MSA.endDate,
      }, '*');
    } catch (_) { /* cross-origin under file:// \u2014 same known limitation as the close handshake */ }
  };
  // The iframe may already be loaded (re-opening the overlay) or still loading
  // (first open) \u2014 cover both rather than guessing which applies.
  send();
  frame.addEventListener('load', send, { once: true });
}

function openAccountSetupEntry() {
  const overlay = document.getElementById('account-setup-embed-overlay');
  const frame = document.getElementById('account-setup-embed-frame');
  if (!overlay || !frame) return;

  const params = new URLSearchParams({
    section: 'msa',
    msaSubscription: proposalData.msaSubscription,
    msaMinimumSpendCommitment: proposalData.msaMinimumSpendCommitment,
    msaTermStart: proposalData.msaTermStart,
    msaContractTerm: proposalData.msaContractTerm,
    msaServiceOrderTerm: proposalData.msaServiceOrderTerm,
    msaRampUpPeriod: proposalData.msaRampUpPeriod,
    msaDiscretionaryDiscountPct: proposalData.msaDiscretionaryDiscountPct,
  });
  frame.setAttribute('src', `app/demos/account-setup.html?${params.toString()}`);
  sendAccountSetupPricingData(frame);
  overlay.classList.add('is-open');
  document.body.style.overflow = 'hidden';
}

function _resetBundleTxTypeStep() {
  ['same-as-current','upsell','add','cancel','reactivate'].forEach(t => {
    const card = document.getElementById('tx-card-' + t);
    if (card) card.classList.remove('selected');
  });
  const btn = document.getElementById('btn-tx-type-continue');
  if (btn) { btn.disabled = true; btn.style.opacity = '0.4'; btn.style.cursor = 'not-allowed'; }
  bld.txType = null;
  // 2026-09-18 (R21.2, per Catalina): "Same as Current" only makes sense when
  // creating a brand-new option ("+ Add option", bld.targetOptId is null)
  // while inside the Renewal/Rewrap flow \u2014 that's the only place a whole
  // extra full-mirror-of-Current option is meaningful.
  // 2026-09-18 (correction, per Catalina \u2014 live-testing review): the original
  // condition only checked entryPoint, so it still showed "Same as Current"
  // from "+ Add modification" WITHIN an already-existing Renewal/Rewrap
  // option \u2014 but that option already IS the full mirror of Current, and
  // selecting "Same as Current" there doesn't add anything to it; it silently
  // spawns a whole separate new option instead, which is confusing. Now also
  // gated on bld.targetOptId being null (a brand-new option), not just on
  // entryPoint \u2014 so it's hidden for every "+ Add modification" call
  // regardless of entry point, and only ever shown from "+ Add option".
  const sameAsCurrentCard = document.getElementById('tx-card-same-as-current');
  if (sameAsCurrentCard) {
    const isNewOption = bld.targetOptId === null || bld.targetOptId === undefined;
    sameAsCurrentCard.classList.toggle('hidden', !isNewOption || proposalData.entryPoint !== 'renewalRewrap');
  }
  const cancelCardLabel = document.querySelector('#tx-card-cancel .tx-type-card-name');
  const targetOption = bld.targetOptId ? options.find(option => option.id === bld.targetOptId) : null;
  if (cancelCardLabel) cancelCardLabel.textContent = targetOption?.transactionMode === 'Reactivation' ? 'Reduce scope' : 'Cancel / Downgrade';
  // Per Leo (MSA Process Workshop, 2026-09-21): "if they have never
  // cancelled anything then they don't have anything to reactivate. So we
  // will not list it here" \u2014 the card only ever appears when the mock has
  // at least one previously deactivated unit for this account.
  const reactivateCard = document.getElementById('tx-card-reactivate');
  if (reactivateCard) {
    reactivateCard.classList.toggle('hidden', !(DEMO_PREVIOUSLY_DEACTIVATED_UNITS.length > 0));
  }
}

function selectBundleTxType(type) {
  ['same-as-current','upsell','add','cancel','reactivate'].forEach(t => {
    const card = document.getElementById('tx-card-' + t);
    if (card) card.classList.toggle('selected', t === type);
  });
  bld.txType = type;
  const btn = document.getElementById('btn-tx-type-continue');
  if (btn) { btn.disabled = false; btn.style.opacity = '1'; btn.style.cursor = 'pointer'; }
}

function eaNormalizeExpansionBundle(bundle) {
  if (!bundle) return bundle;
  const isPrebuilt = bundle.isPrebuilt ?? !!bundle.prebuiltBundleKey;
  return { ...bundle, isPrebuilt, bundleKey: bundle.bundleKey || bundle.prebuiltBundleKey || null, tierKey: bundle.tierKey || bundle.prebuiltTierKey || null };
}

function eaExpansionDiscountPct(optId) {
  const opt = optId ? options.find(o => o.id === optId) : null;
  if (opt && opt.discretionaryDiscountPct != null) return Number(opt.discretionaryDiscountPct) || 0;
  return Number(proposalData.msaDiscretionaryDiscountPct) || 0;
}

function eaOpenExpansionForm(optId, bundle) {
  if (bundle) csLoadBundle(optId, eaNormalizeExpansionBundle(bundle));
  else csResetForm(optId);
  bld.msaDiscountPct = eaExpansionDiscountPct(optId);
  bld._msaDiscountInitialized = true;
  const btnCreate = document.getElementById('btn-create');
  if (btnCreate) btnCreate.innerText = bundle ? 'Update Expansion' : 'Add Expansion';
  const term = optId ? (options.find(o => o.id === optId)?.term || 36) : 36;
  const termBadge = document.getElementById('preview-term-badge');
  if (termBadge) termBadge.innerText = `${term} month term contract`;
  // 2026-10-14 (per Catalina): contract modifications don't show the term in the modal (Expansion, Feature Upsell,
  // Partial Cancellation, Reactivation summaries); the badge comes back for Renewal / Rewrap.
  if (termBadge) termBadge.classList.toggle('hidden', proposalData.entryPoint === 'newProposal');
  renderPlanModeUI(term);
  syncBundleModeToggle(term);
  updateBundlePreview();
}

function confirmBundleTxType() {
  if (!bld.txType) return;
  if (bld.txType === 'same-as-current') {
    window.duplicateCurrentAsOption();
    closeBundleModal();
    return;
  }
  // Renewal/Rewrap operates on a full mirror of Current so R22 can match and
  // move real units. Create New Proposal keeps an isolated card instead: the
  // picker still reads the real contract, but only the transaction line is
  // placed in the visible option (R21.9).
  if (proposalData.entryPoint !== 'renewalRewrap' && !bld.targetOptId && (bld.txType === 'upsell' || bld.txType === 'cancel' || bld.txType === 'reactivate')) {
    const isolated = window.createEmptyTransactionOption(bld.txType);
    if (isolated) bld.targetOptId = isolated.id;
  }
  if (proposalData.entryPoint === 'renewalRewrap' && bld.txType === 'cancel' && !bld.targetOptId) {
    const seeded = window.createOptionFromCurrent();
    if (seeded) bld.targetOptId = seeded.id;
  }
  if (proposalData.entryPoint === 'renewalRewrap' && !bld.targetOptId && (bld.txType === 'upsell' || bld.txType === 'reactivate')) {
    const seeded = window.createOptionFromCurrent();
    if (seeded) bld.targetOptId = seeded.id;
  }
  const labels = { upsell: 'Feature Upsell', add: 'Expansion', cancel: 'Cancel / Downgrade', reactivate: 'Reactivate' };
  document.getElementById('bundle-modal-title').innerText = labels[bld.txType] || 'Configure Solution';
  document.getElementById('bundle-step-tx-type').style.display = 'none';
  document.getElementById('bundle-step-configure').style.display = 'flex';
  document.querySelector('.bundle-mode-toggle')?.classList.toggle('hidden', bld.txType !== 'add');
  if (bld.txType !== 'upsell') document.querySelector('.upsell-mode-toggle')?.classList.add('hidden');

  const modal = document.querySelector('#bundle-overlay .bundle-modal');
  if (modal) {
    modal.classList.remove('modal--md', 'bundle-modal--compact');
    modal.classList.add('modal--lg');
    modal.classList.toggle('bundle-modal--configure-solution', bld.txType === 'add');
    modal.classList.toggle('bundle-modal--transaction', bld.txType !== 'add');
    modal.classList.add('bundle-modal--summary-shell');
  }
  const panelTx  = document.getElementById('bundle-panel-tx');
  const panelAdd = document.getElementById('bundle-panel-add');

  if (bld.txType === 'add') {
    // Show original Configure Bundle form
    if (modal) modal.classList.remove('bundle-modal--wide');
    panelTx.style.display  = 'none';
    panelAdd.style.display = 'flex';
    const existingExpansion = bld.targetOptId && bld.targetBundleId
      ? options.find(option => option.id === bld.targetOptId)?.bundles.find(bundle => bundle.id === bld.targetBundleId)
      : null;
    eaOpenExpansionForm(bld.targetOptId, existingExpansion?.isolatedTransactionType === 'add' ? existingExpansion : null);
  } else {
    // Show dynamic TX form (upsell / cancel)
    if (modal) modal.classList.toggle('bundle-modal--wide', true);
    panelAdd.style.display = 'none';
    panelTx.style.display  = 'flex';
    selectedTxTypeVZ = bld.txType;
    // Always reset the footer's left action to Cancel when (re)opening this
    // panel fresh \u2014 Upsell's step 2 swaps it to Back, which must not leak
    // into a new Cancel/Reactivate form or a fresh Upsell session.
    const cancelBackBtnReset = document.getElementById('gc-tx-cancel-back-btn');
    if (cancelBackBtnReset) { cancelBackBtnReset.textContent = 'Cancel'; cancelBackBtnReset.onclick = closeBundleModal; }
    if (bld.txType === 'upsell') {
      renderVZUpsellForm();
    }
    else if (bld.txType === 'cancel') renderVZCancelForm();
    else if (bld.txType === 'reactivate') renderVZReactivationForm();
  }
}

function escapeHtml(value) {
  return String(value == null ? '' : value).replace(/[&<>"']/g, function (ch) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch];
  });
}

function buildUnifiedOrderPromoDraft(opt) {
  const coreKeys = [...new Set(opt.bundles.map(bundle => bundle.coreKey))];
  const groupsByCore = getGroupsByCore(opt, coreKeys);
  const { tierQty: msaTierUnits } = calcOption(opt, getOptionPromotion(opt));
  const packages = getOptionPromoPackages(opt, coreKeys, groupsByCore, msaTierUnits);
  const currentCombo = {}, currentDealClosers = {};
  coreKeys.forEach(coreKey => {
    const first = groupsByCore[coreKey][0];
    currentCombo[coreKey] = { promoType: (first && first.promoType) || 'Standard', promoName: (first && first.promoName) || '' };
    currentDealClosers[coreKey] = (first && first.dealCloser) || '';
  });
  const { selectedKey, customEntry } = resolveSelectionForCombo(opt, coreKeys, groupsByCore, packages, currentCombo, currentDealClosers, msaTierUnits);
  const custom = {};
  coreKeys.forEach(coreKey => {
    custom[coreKey] = selectedKey === 'custom' && customEntry
      ? { ...customEntry.combo[coreKey], dealCloser: customEntry.dealClosers[coreKey] || '' }
      : packages[selectedKey]
        ? { ...packages[selectedKey].combo[coreKey], dealCloser: '' }
        : { promoType: 'Standard', promoName: '', dealCloser: '' };
  });
  opt.orderPromoMode = 'packages';
  return { mode: 'unified', coreKeys, packages, customEntry, selectedKey, custom };
}

function getOrderPromotionComponents(bundle) {
  const featureKeys = bundle.features || [];
  const featureTotal = featureKeys.reduce((sum, key) => sum + getFeatureUnitPrice(key, bundle.qty || 1), 0);
  const coreInfo = corePricing[bundle.coreKey];
  const videoCoreKey = resolveVideoCoreKey(bundle);
  const corePrice = Number.isFinite(Number(bundle.baseCorePrice))
    ? Number(bundle.baseCorePrice)
    : Math.max(0, (Number(bundle.basePrice) || 0) - featureTotal);
  // 2026-10-02 (per Catalina \u2014 same breakdown as Initial Sales): the VTU core
  // reads as "Vehicle Tracking", and a VTU + FFC / VTU +
  // Dual Camera bundle splits into its two subscriptions (camera priced as the
  // delta over VTU only), exactly like New Accounts' getBundleComponentPrices.
  // Only those two bundles combine two subscriptions; every other core stays
  // one row.
  const vtuBase = corePricing['vtu']?.price || 0;
  const cameraNameByCore = { 'vtu-ffc': 'Forward Facing Camera Subscription', 'vtu-dual': 'Dual Camera Subscription' };
  // core / coreKey: where each component comes from in the catalog (Price List order, sortPriceListRows).
  const components = (cameraNameByCore[videoCoreKey] && vtuBase > 0)
    ? [
        { name: 'Vehicle Tracking', listUnit: vtuBase, core: true, coreKey: 'vtu' },
        { name: cameraNameByCore[videoCoreKey], listUnit: Math.max(0, corePrice - vtuBase), core: true, coreKey: videoCoreKey },
      ]
    : [{
        name: bundle.coreKey === 'vtu' ? 'Vehicle Tracking' : (bundle.coreName || coreInfo?.name || bundle.coreKey),
        listUnit: corePrice,
        core: true,
        coreKey: bundle.coreKey,
      }];
  featureKeys.forEach(key => components.push({
    name: featureLabels[key] || key,
    listUnit: getFeatureUnitPrice(key, bundle.qty || 1),
    core: false,
    coreKey: null,
  }));
  const remainder = (Number(bundle.basePrice) || 0) - components.reduce((sum, item) => sum + item.listUnit, 0);
  if (components.length) components[0].listUnit += remainder;
  return components;
}

function getDrawerSummaryOption(opt) {
  return { ...opt, bundles: opt.bundles.filter(bundle => bundle.isolatedTransactionType !== 'cancel') };
}

function computeAccountPriceList(opt) {
  const rows = [];
  const currentBundles = existingOrders.flatMap(order => order.bundles || []);
  const accountMsaTierUnits = sumMsaTierQty(currentBundles);
  const accountMsaTermMonths = DEMO_MSA?.termMonths || existingOrders[0]?.term || 36;
  const historicalTierTermPct = getTierTermDiscountPct(accountMsaTermMonths, accountMsaTierUnits);
  existingOrders.forEach(order => (order.bundles || []).forEach(bundle => {
    const listUnit = Number(bundle.basePrice) || 0;
    const discretionaryPct = Number(bundle.msaDiscountPct) || 0;
    const priceBreakdown = VC.priceListUnitBreakdown({ listUnit, tierTermPct: historicalTierTermPct, discretionaryPct });
    rows.push({ bundle, name: bundle.coreName || corePricing[bundle.coreKey]?.name || bundle.coreKey, source: 'existing', billingModel: bundle.billingModel === 'capex' ? 'capex' : 'opex', qty: bundle.qty, eligibleQty: eligibleComponentsCountForCore(bundle.coreKey) * bundle.qty, listUnit, tierTermUnit: priceBreakdown.tierTermUnit, tierTermPct: historicalTierTermPct, discretionaryUnit: priceBreakdown.afterTierTermUnit * discretionaryPct / 100, msaUnit: priceBreakdown.msaUnit, oneTimeUnit: bundle.billingModel === 'capex' ? getEstimatedHardwareUnitPrice(bundle) : 0 });
  }));
  const { tierQty, term } = calcOption(opt, getOptionPromotion(opt));
  opt.bundles.forEach(bundle => {
    const discretionaryPct = getOptionDiscountPct(opt, bundle);
    const calc = calcBundle({ ...bundle, msaDiscountPct: discretionaryPct, promoName: '' }, term, 'Standard', tierQty);
    const isIsolatedCancel = vzIsFixedRateTx(bundle);
    const listUnit = Number(bundle.basePrice) || 0;
    // 2026-10-02: contract-level Custom Discount (Renewal / Rewrap) lowers MSA Price.
    const contractCustomUnit = getCustomPromoAmountForBundle(bundle, getActiveCustomPromotionsForPricing(opt, 'contract'), 0, calc.unitPrice);
    const tierTermPct = calc.tierTermPct || 0;
    const priceBreakdown = VC.priceListUnitBreakdown({
      listUnit,
      tierTermPct,
      discretionaryPct,
      msaUnitOverride: isIsolatedCancel ? listUnit : Math.max(0, calc.unitPrice - contractCustomUnit),
    });
    rows.push({ bundle, name: bundle.coreName || corePricing[bundle.coreKey]?.name || bundle.coreKey, source: 'proposal', billingModel: bundle.billingModel === 'capex' ? 'capex' : 'opex', qty: bundle.qty, eligibleQty: eligibleComponentsCountForCore(bundle.coreKey) * bundle.qty, listUnit, tierTermUnit: priceBreakdown.tierTermUnit, tierTermPct, discretionaryUnit: priceBreakdown.afterTierTermUnit * discretionaryPct / 100, msaUnit: priceBreakdown.msaUnit, oneTimeUnit: bundle.billingModel === 'capex' ? getEstimatedHardwareUnitPrice(bundle) : 0 });
  });
  return rows;
}

// 2026-10-15 (per Catalina): Cancellation and Reactivation lines carry the subscriptions' current monthly rate (what
// the customer pays today, or paid before deactivating) — no tier / term or discount applies again. The line shows
// how much the monthly goes down (negative) or up (positive): List Price = Contracted Price/mo = that rate,
// Monthly = rate × QTY, same as the Cancellation / Reactivation Summary.
function vzIsFixedRateTx(bundle) {
  return !!bundle && bundle.isMsaAuxiliary && (bundle.isolatedTransactionType === 'cancel' || bundle.isolatedTransactionType === 'reactivate');
}

function splitPriceListRowBySubscription(row) {
  const components = getOrderPromotionComponents(row.bundle);
  if (components.length === 1) return [{
    ...row,
    name: components[0].name,
    core: components[0].core,
    coreKey: components[0].coreKey,
    eligibleQty: ELIGIBLE_SUBSCRIPTION_ROW_NAMES.has(components[0].name) ? row.qty : 0,
  }];
  if (!components.length) return [{ ...row, core: true, coreKey: row.bundle?.coreKey || null }];

  const totalListCents = Math.round(row.listUnit * 100);
  const totalMsaCents = Math.round(row.msaUnit * 100);
  let allocatedListCents = 0;
  let allocatedMsaCents = 0;
  return components.map((component, index) => {
    const isLast = index === components.length - 1;
    const listCents = isLast ? totalListCents - allocatedListCents : Math.round(component.listUnit * 100);
    const msaCents = isLast ? totalMsaCents - allocatedMsaCents : Math.round(totalMsaCents * listCents / totalListCents);
    allocatedListCents += listCents;
    allocatedMsaCents += msaCents;
    return {
      ...row,
      name: component.name,
      core: component.core,
      coreKey: component.coreKey,
      listUnit: listCents / 100,
      msaUnit: msaCents / 100,
      eligibleQty: ELIGIBLE_SUBSCRIPTION_ROW_NAMES.has(component.name) ? row.qty : 0,
      hardwareName: row.name,
      oneTimeUnit: isLast ? row.oneTimeUnit : 0,
    };
  });
}

function mergeDuplicatePriceListRows(rows) {
  const merged = new Map();
  rows.forEach(row => {
    const oneTimeCents = Math.round((Number(row.oneTimeUnit) || 0) * 100);
    const key = [
      row.source,
      row.name,
      row.billingModel,
      Math.round((Number(row.listUnit) || 0) * 100),
      Math.round((Number(row.msaUnit) || 0) * 100),
      row.eligibleQty === row.qty,
      oneTimeCents,
      oneTimeCents ? row.hardwareName || '' : '',
    ].join('|');
    const existing = merged.get(key);
    if (!existing) {
      merged.set(key, { ...row });
      return;
    }
    existing.qty = (Number(existing.qty) || 0) + (Number(row.qty) || 0);
    existing.eligibleQty = (Number(existing.eligibleQty) || 0) + (Number(row.eligibleQty) || 0);
  });
  return [...merged.values()];
}

function buildAccountPriceListHtml(opt, context = 'modal') {
  // Subscription rows split combined vehicle/camera bundles. Capex hardware
  // remains a single, bundle-level row after its final subscription.
  // 2026-11-10 (per Catalina): the option's modifications all show — expansions, upsells, reactivations and cancellations
  // (negative QTY) — even for subscriptions already on the contract (they were hidden by name). The option's own copy
  // of the current lines (Renewal / Rewrap) isn't repeated.
  const isModification = b => !!b && (b.isMsaAuxiliary || b.originalQty === undefined);
  const signed = row => (row.bundle && row.bundle.isolatedTransactionType === 'cancel') ? { ...row, qty: -Math.abs(row.qty), eligibleQty: -Math.abs(row.eligibleQty) } : row;
  const rows = mergeDuplicatePriceListRows(computeAccountPriceList(opt)
    .filter(row => row.source === 'existing' || isModification(row.bundle))
    .flatMap(splitPriceListRowBySubscription)
    // An upsell only adds features: its vehicle's core line (no price) isn't a new subscription.
    .filter(row => !(row.bundle && row.bundle.isolatedTransactionType === 'upsell' && row.core && (Number(row.listUnit) || 0) < 0.005))
    .map(signed));
  if (!rows.length) return `<p class="text-body-small" style="color:var(--gray-600);">No subscriptions on this MSA yet.</p>`;
  // 2026-10-14 (per Catalina): the Billing model column shows only when the lines mix Opex and Capex.
  const showHardware = accountBillingModel === 'both';
  const showOneTime = showHardware && rows.some(r => r.billingModel === 'capex') && rows.some(r => r.billingModel !== 'capex');
  const colspan = showOneTime ? 6 : 5;
  const renderRow = (row) => {
    const isCapex = row.billingModel === 'capex';
    const mainRow = `<tr class="sub-price-row"><td class="sub-price-cell sub-price-cell--name">${row.name}</td>${showOneTime ? `<td class="sub-price-cell">${isCapex ? 'Capex' : 'Opex'}</td>` : ''}<td class="sub-price-cell sub-price-cell--num">${formatMoney(row.listUnit)}</td><td class="sub-price-cell sub-price-cell--msa">${buildMsaPriceCellHtml(row.msaUnit, false, 0)}</td><td class="sub-price-cell sub-price-cell--num">${row.qty}</td><td class="sub-price-cell sub-price-cell--num">${row.eligibleQty}</td></tr>`;
    const hardwareRow = (showHardware && isCapex && row.oneTimeUnit > 0.005)
      ? `<tr class="sub-price-row sub-price-row--hardware"><td class="sub-price-cell sub-price-cell--name">${row.hardwareName || row.name} Hardware</td>${showOneTime ? '<td class="sub-price-cell">Capex</td>' : ''}<td class="sub-price-cell sub-price-cell--num">${formatMoney(row.oneTimeUnit)}</td><td class="sub-price-cell sub-price-cell--msa">${buildMsaPriceCellHtml(row.oneTimeUnit, false, 0)}</td><td class="sub-price-cell sub-price-cell--num">${row.qty}</td><td class="sub-price-cell sub-price-cell--num">0</td></tr>`
      : '';
    return mainRow + hardwareRow;
  };
  // 2026-10-23 (MSA DTP 2026-10-21, R17): in each group, core subscriptions first in catalog order, then the rest by
  // contracted price per item, highest first — sortPriceListRows (vc-catalog.js).
  const currentRows = sortPriceListRows(rows.filter(row => row.source === 'existing'));
  const newRows = sortPriceListRows(rows.filter(row => row.source === 'proposal'));
  const groups = [{ label: 'Current contract', items: currentRows }, { label: 'Modifications', items: newRows }].filter(group => group.items.length);
  const tableHtml = `<table class="sub-price-table${showOneTime ?' sub-price-table--unified' : ''}"><thead><tr><th class="sub-price-header">Subscription</th>${showOneTime ? '<th class="sub-price-header">Billing model</th>' : ''}<th class="sub-price-header sub-price-header--num">List Price</th><th class="sub-price-header sub-price-header--msa">${buildMsaPriceHeaderLabelHtml()}</th><th class="sub-price-header sub-price-header--num">QTY</th><th class="sub-price-header sub-price-header--num">Eligible Subs</th></tr></thead>${groups.map(group => `<tbody><tr class="price-list-source-row"><td colspan="${colspan}" class="price-list-source-cell">${group.label}</td></tr>${group.items.map(row => renderRow(row)).join('')}</tbody>`).join('')}</table>`;
  return `<div class="subscription-summary-scroll">${tableHtml}</div>`;
}

function openEditProposalModal() {
  // Segment radios
  const seg = proposalData.segment || 'SMB';
  document.querySelectorAll('input[name="edit-segment"]').forEach(r => {
    r.checked = r.value === seg;
  });
  _syncEditSegmentSections(seg);
  // Enterprise
  const poEl = document.getElementById('edit-po-number');
  const ccEl = document.getElementById('edit-cost-center');
  if (poEl) poEl.value = proposalData.poNumber || '';
  if (ccEl) ccEl.value = proposalData.costCenter || '';
  // Government
  const govPoEl = document.getElementById('edit-gov-po');
  const cvEl   = document.getElementById('edit-contract-vehicle');
  const coName = document.getElementById('edit-co-name');
  const coEmail= document.getElementById('edit-co-email');
  const coPhone= document.getElementById('edit-co-phone');
  if (govPoEl) govPoEl.value = proposalData.poNumber || '';
  if (cvEl)    cvEl.value    = proposalData.contractVehicle || '';
  if (coName)  coName.value  = proposalData.contractingOfficerName || '';
  if (coEmail) coEmail.value = proposalData.contractingOfficerEmail || '';
  if (coPhone) coPhone.value = proposalData.contractingOfficerPhone || '';

  document.getElementById('edit-proposal-overlay').classList.add('is-open');
}

function closeEditProposalModal() {
  document.getElementById('edit-proposal-overlay').classList.remove('is-open');
}

function onEditSegmentChange() {
  const sel = document.querySelector('input[name="edit-segment"]:checked');
  if (sel) _syncEditSegmentSections(sel.value);
}

function _syncEditSegmentSections(seg) {
  const entSection = document.getElementById('edit-ent-section');
  const govSection = document.getElementById('edit-gov-section');
  if (entSection) entSection.classList.toggle('hidden', seg !== 'Enterprise');
  if (govSection) govSection.classList.toggle('hidden', seg !== 'Government');
}

function saveProposalInfo() {
  // Segment
  const selSeg = document.querySelector('input[name="edit-segment"]:checked');
  const newSeg = selSeg ? selSeg.value : (proposalData.segment || 'SMB');
  proposalData.segment = newSeg;

  // Segment-specific fields
  if (newSeg === 'Enterprise') {
    proposalData.poNumber   = (document.getElementById('edit-po-number')  || {}).value || '';
    proposalData.costCenter = (document.getElementById('edit-cost-center') || {}).value || '';
    proposalData.contractVehicle = '';
    proposalData.contractingOfficerName = '';
    proposalData.contractingOfficerEmail = '';
    proposalData.contractingOfficerPhone = '';
  } else if (newSeg === 'Government') {
    proposalData.poNumber           = (document.getElementById('edit-gov-po')          || {}).value || '';
    proposalData.contractVehicle    = (document.getElementById('edit-contract-vehicle') || {}).value || '';
    proposalData.contractingOfficerName  = (document.getElementById('edit-co-name')    || {}).value || '';
    proposalData.contractingOfficerEmail = (document.getElementById('edit-co-email')   || {}).value || '';
    proposalData.contractingOfficerPhone = (document.getElementById('edit-co-phone')   || {}).value || '';
    proposalData.costCenter = '';
  } else {
    // SMB \u2014 clear all deal-classification fields
    proposalData.poNumber = '';
    proposalData.costCenter = '';
    proposalData.contractVehicle = '';
    proposalData.contractingOfficerName = '';
    proposalData.contractingOfficerEmail = '';
    proposalData.contractingOfficerPhone = '';
  }

  updateSegmentHeader();
  closeEditProposalModal();
  renderOptions();
  logProposalEvent('Proposal settings updated', `Segment: ${newSeg}.`);
}

function openTierSettingsFromMenu(event) {
  if (event) event.stopPropagation();
  document.getElementById('more-menu-draft')?.classList.add('hidden');
  document.getElementById('draft-more-btn')?.setAttribute('aria-expanded', 'false');
  openEditProposalModal();
  document.getElementById('edit-prop-tier')?.focus();
}

function getContractCreatedBanner() {
  return ['Contract has been created', 'Review the terms and send the contract to the customer.'];
}

function syncNewProposalButton() {
  const host = document.getElementById('quotes-list-page-header-host');
  if (host && !document.getElementById('btn-new-proposal')) {
    host.innerHTML = VC.pageHeader({
      title: 'Proposal Dashboard',
      subtitle: 'View and manage proposals for this account or lead.',
      // 2026-10-15 (per Catalina): Filters icon in the header, before the main action (no extra row above the table).
      secondaryHtml: '<div id="ql-filter-bar" class="ql-filter-bar"></div>',
      action: {
        id: 'btn-new-proposal',
        label: 'Create new proposal',
        onClick: 'options = []; nextOptId = 1; openDraftingRoute()',
      },
    });
  }
  const button = document.getElementById('btn-new-proposal');
  if (!button) return;
  // 2026-11-04 (per Catalina): a legacy account (Migrations) has "Migrate to MSA" as the dashboard's main action.
  if (typeof migrationModeOn !== 'undefined' && migrationModeOn) {
    button.textContent = 'Migrate to MSA';
    button.onclick = () => window.startMigrationProposal();
    return;
  }
  const isInactive = accountStatus === 'inactive';
  button.textContent = isInactive ? 'Reactivate' : 'Create new proposal';
  button.onclick = isInactive
    ? startReactivationProposal
    : () => { options = []; nextOptId = 1; openDraftingRoute(); };
}

function startRenewalRewrapProposal() {
  options = [];
  nextOptId = 1;
  openDraftingRoute(false, false, 'renewalRewrap');
  if (!options.length) {
    const opt = window.createOptionFromCurrent('Option 1');
    if (opt) {
      opt.transactionMode = 'Rewrap';
      opt.discretionaryDiscountPct = 0;
      // 2026-09-18 (R21.3, per transcript \u2014 Catalina/Leo, 2026-09-17 meeting):
      // promotions are order-specific and never carry over to a renewal/rewrap
      // ("in this option they are not promotions because the promotions are
      // different between orders... maybe the price is going to increase") \u2014
      // reset alongside the discount, not just copy Current's old promo as-is.
      opt.bundles.forEach(b => { b.msaDiscountPct = 0; b.promoType = 'Standard'; b.promoName = ''; });
      opt.effectiveDate = '';
      renderOptions();
      document.getElementById('empty-state')?.classList.add('hidden');
      document.getElementById('options-grid')?.classList.remove('hidden');
    }
  }
}

function startReactivationProposal() {
  options = [];
  nextOptId = 1;
  openDraftingRoute(false, false, 'reactivation');
  const opt = window.createOptionFromCurrent('Option 1');
  if (!opt) return;
  opt.transactionMode = 'Reactivation';
  opt.discretionaryDiscountPct = 0;
  opt.bundles.forEach(b => { b.msaDiscountPct = 0; b.promoType = 'Standard'; b.promoName = ''; });
  opt.effectiveDate = '';
  opt.term = 36;
  renderOptions();
  document.getElementById('empty-state')?.classList.add('hidden');
  document.getElementById('options-grid')?.classList.remove('hidden');
}

function getMcCancellationPenalty(opt) {
  const status = getMsaCommitmentStatus();
  const totalMonthly = calcOption(opt, getOptionPromotion(opt)).totalMonthly;
  const endDate = new Date(status.msaEndDate + 'T00:00:00');
  const remainingMonths = Math.max(0, Math.ceil((endDate - new Date()) / (1000 * 60 * 60 * 24 * 30.44)));
  const grossAmount = remainingMonths * totalMonthly;
  const wave = CANCEL_PENALTY_WAVES.find(w => w.id === opt.cancelPenaltyWaveId) || null;
  const waveDiscountPct = wave ? wave.pct : 0;
  const amount = grossAmount * (1 - waveDiscountPct / 100);
  return { amount, grossAmount, remainingMonths, totalMonthly, wave, waveDiscountPct };
}

function getUnreturnedHardwareValue(opt) {
  const bundles = Array.isArray(opt?.bundles) ? opt.bundles : [];
  const breakdown = bundles.map(b => {
    const unitValue = HARDWARE_VALUES[b.coreKey] || 0;
    const qty = Number(b.qty) || 0;
    return { coreKey: b.coreKey, name: b.coreName || corePricing[b.coreKey]?.name || b.coreKey, qty, unitValue, subtotal: unitValue * qty };
  }).filter(row => row.qty > 0);
  const totalValue = breakdown.reduce((sum, row) => sum + row.subtotal, 0);
  const returnByDate = new Date(Date.now() + HARDWARE_RETURN_WINDOW_DAYS * 24 * 60 * 60 * 1000);
  return { breakdown, totalValue, returnByDate };
}

function getHardwareAccordionHtml(opt, uid) {
  // 2026-09-28 (per Catalina/Leo \u2014 point 4 of Capex/Opex support): under a
  // Capex billing model the customer already owns the hardware outright (it
  // was a one-time purchase, not something Verizon is still carrying), so
  // there's no "unreturned hardware" penalty to speak of. Only suppressed for
  // a pure Capex account; kept for Opex and for "Both" (mixed accounts still
  // have Opex-billed units this could apply to, and this prototype doesn't
  // yet track billing model per unit/bundle in Existing Accounts \u2014 see
  // requirements.md Open Questions).
  if (accountBillingModel === 'capex') return '';
  const hw = getUnreturnedHardwareValue(opt);
  if (!hw.breakdown.length) return '';
  const returnByLabel = hw.returnByDate.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
  const rowsHtml = hw.breakdown.map(row => `
    <div style="display:flex;justify-content:space-between;gap:12px;padding:6px 0;font-size:12px;color:var(--gray-700);">
      <span>${row.name} \u00d7 ${row.qty}</span>
      <span>${formatMoney(row.unitValue)}/unit \u2014 <strong style="color:var(--black);">${formatMoney(row.subtotal)}</strong></span>
    </div>`).join('');
  return `
    <div class="cancel-mc-penalty" style="flex-direction:column;align-items:stretch;gap:6px;">
      <div style="display:flex;justify-content:space-between;align-items:center;">
        <span class="cancel-mc-penalty-label">Unreturned hardware value (if not returned by ${returnByLabel})</span>
        <strong class="cancel-mc-card-penalty-value">${formatMoney(hw.totalValue)}</strong>
      </div>
      <div class="vc-accordion" id="hw-acc-${uid}">
        <button type="button" class="vc-accordion__header" aria-expanded="false" onclick="toggleAddonAccordion('hw-acc-${uid}')">
          <span class="vc-accordion__title">See itemized hardware value</span>
          <span class="vc-accordion__right"><span class="material-symbols-outlined vc-accordion__chevron" aria-hidden="true">expand_more</span></span>
        </button>
        <div class="vc-accordion__body">${rowsHtml}</div>
      </div>
    </div>`;
}

function getCancelPenaltyWaveDropdownHtml(opt) {
  const optionsHtml = CANCEL_PENALTY_WAVES.map(w => `<option value="${w.id}" ${opt.cancelPenaltyWaveId === w.id ? 'selected' : ''}>${w.name}</option>`).join('');
  return `
    <div class="approval-field" style="margin-top:8px;">
      <label for="cancel-wave-select-${opt.id}" class="vc-field-label">Cancellation promotion (optional)</label>
      <select id="cancel-wave-select-${opt.id}" class="select" data-vc-dropdown onchange="setCancelPenaltyWave(${opt.id}, this.value)">
        <option value="">None</option>
        ${optionsHtml}
      </select>
    </div>`;
}

function setCancelPenaltyWave(optId, waveId) {
  const opt = options.find(o => o.id === optId);
  if (!opt) return;
  opt.cancelPenaltyWaveId = waveId || null;
  if (document.getElementById('cancel-mc-modal-overlay')?.classList.contains('is-open')) {
    renderCancelMcModalPenalty();
  } else {
    renderOptions();
  }
}

function getCancelMcSummaryHtml() {
  const currentOrders = Array.isArray(existingOrders) ? existingOrders : [];
  const currentBundles = currentOrders.flatMap(order => order.bundles || []);
  const totalUnits = currentBundles.reduce((sum, bundle) => sum + (Number(bundle.qty) || 0), 0);
  const totalMonthly = currentOrders.reduce((sum, order) => sum + calcOption({ bundles: order.bundles || [], term: order.term || 36 }, 'Standard').totalMonthly, 0);
  const subs = currentBundles.reduce((sum, bundle) => sum + getMsaTierQty(bundle.qty, bundle.coreKey), 0);
  const tier = getMsaDiscountTier(subs);
  const tierRange = tier.max >= 9999 ? `${tier.min}+` : `${tier.min}–${tier.max}`;
  const bundlesHtml = currentBundles.map(bundle => {
    const order = currentOrders.find(candidate => (candidate.bundles || []).includes(bundle));
    const pricing = calcBundle(bundle, order?.term || 36, bundle.promoType || 'Standard', totalUnits);
    return `<div style="padding:10px 0;border-top:1px solid var(--gray-200);">
      <div style="font-size:13px;font-weight:700;color:var(--black);">${bundle.coreName}</div>
      <div style="display:flex;justify-content:space-between;gap:12px;margin-top:4px;font-size:11px;color:var(--gray-600);">
        <span>QTY: ${bundle.qty}</span><span>${formatMoney(pricing.unitPrice)}/unit</span><strong style="color:var(--black);">${formatMoney(pricing.monthly)}/month</strong>
      </div>
    </div>`;
  }).join('');
  return `<div style="font-size:11px;font-weight:700;color:var(--gray-500);text-transform:uppercase;letter-spacing:.05em;margin-bottom:8px;">Current solutions</div>
    ${bundlesHtml}
    <div style="display:flex;justify-content:space-between;gap:16px;border-top:1px solid var(--gray-300);margin-top:4px;padding-top:10px;"><span>Monthly total</span><strong>${formatMoney(totalMonthly)}/month</strong></div>
    <div style="margin-top:8px;color:var(--gray-600);font-size:12px;">${totalUnits} units \u00b7 ${subs} subs \u00b7 Tier/Term ${tierRange}</div>`;
}

function renderCancelMcModalPenalty() {
  const opt = options.find(o => o.id === bld.selectedOptionId);
  if (!opt) return;
  const penalty = getMcCancellationPenalty(opt);
  const monthsLabel = `${penalty.remainingMonths} month${penalty.remainingMonths === 1 ? '' : 's'} remaining`;
  document.getElementById('cancel-mc-modal-penalty-label').textContent = `Early termination fee (${monthsLabel})`;
  document.getElementById('cancel-mc-modal-penalty').textContent = formatMoney(penalty.amount);
  document.getElementById('cancel-mc-modal-wave-line').textContent = penalty.wave ? `${penalty.wave.name} applied \u2014 was ${formatMoney(penalty.grossAmount)}` : '';
  document.getElementById('cancel-mc-modal-wave-dropdown').innerHTML = getCancelPenaltyWaveDropdownHtml(opt);
}

function closeCancelMcModal() {
  document.getElementById('cancel-mc-modal-overlay')?.classList.remove('is-open');
}

function acceptCancelMc() {
  closeCancelMcModal();
  navigateToContractReviewFromSelection();
}

function closeCancelAutoRenewalModal() {
  document.getElementById('cancel-auto-renewal-modal-overlay')?.classList.remove('is-open');
}

function updateCancelAutoRenewalSubmitState() {
  const reason = document.getElementById('car-reason')?.value.trim() || '';
  const reasonError = document.getElementById('car-reason-error');
  if (reasonError && reason) reasonError.classList.add('hidden');
  if (reason) document.getElementById('car-reason')?.classList.remove('input--error');
}

function triggerCancelAutoRenewalUpload() {
  document.getElementById('car-upload-input')?.click();
}

function handleCancelAutoRenewalUploadChange(input) {
  const fileNameEl = document.getElementById('car-upload-filename');
  const uploadError = document.getElementById('car-upload-error');
  const fileName = input?.files?.[0]?.name || '';
  if (!fileNameEl) return;
  if (!fileName) {
    fileNameEl.classList.add('hidden');
    fileNameEl.textContent = '';
    return;
  }
  fileNameEl.textContent = `Attached: ${fileName}`;
  fileNameEl.classList.remove('hidden');
  if (uploadError) uploadError.classList.add('hidden');
}

function confirmCancelAutoRenewal() {
  const reason = document.getElementById('car-reason')?.value.trim() || '';
  const fileName = document.getElementById('car-upload-input')?.files?.[0]?.name || '';
  let hasError = false;
  if (!reason) {
    document.getElementById('car-reason-error')?.classList.remove('hidden');
    document.getElementById('car-reason')?.classList.add('input--error');
    hasError = true;
  }
  if (!fileName) {
    document.getElementById('car-upload-error')?.classList.remove('hidden');
    hasError = true;
  }
  if (hasError) {
    if (!reason) document.getElementById('car-reason')?.focus();
    return;
  }
  DEMO_MSA.autoRenewalEnabled = false;
  DEMO_MSA.autoRenewalCancellation = { reason, fileName, date: new Date().toISOString().slice(0, 10) };
  closeCancelAutoRenewalModal();
  showSuccessBanner('Auto-renewal disabled', 'The auto-renewal has been turned off for this MSA.');
}

function setVZTxFooter(html) {
  const el = document.getElementById('gc-tx-footer-actions');
  if (!el) return;

  el.innerHTML = html;

  const upsellNextBtn = el.querySelector('#gc-upsell-next-btn');
  if (upsellNextBtn) {
    upsellNextBtn.type = 'button';
    upsellNextBtn.disabled = false;
    upsellNextBtn.onclick = function (event) {
      event.preventDefault();
      vzGoUpsellStep2();
    };
  }

  const upsellAddBtn = el.querySelector('#gc-upsell-add-btn');
  if (upsellAddBtn) {
    upsellAddBtn.type = 'button';
    upsellAddBtn.onclick = function (event) {
      event.preventDefault();
      vzAddUpsellToOrder();
    };
  }

  const cancelNextBtn = el.querySelector('#gc-cancel-next-btn');
  if (cancelNextBtn) {
    cancelNextBtn.type = 'button';
    cancelNextBtn.onclick = function (event) {
      event.preventDefault();
      vzGoCancelStep2();
    };
  }
}

function vzMonthsUntil(dateStr) {
  const d = new Date(dateStr);
  const now = new Date();
  return Math.max(0, Math.round((d - now) / (30.44 * 24 * 60 * 60 * 1000)));
}

function vzFmtDate(d) {
  if (!d) return '--';
  const dt = new Date(d + 'T00:00:00');
  return dt.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

function vzSubStartFromEnd(subEnd, termMonthsFallback = 24) {
  if (!subEnd) return '';
  const dt = new Date(subEnd + 'T00:00:00');
  if (Number.isNaN(dt.getTime())) return '';
  const monthsToSubtract = Math.max(1, Number(termMonthsFallback) || 24);
  dt.setMonth(dt.getMonth() - monthsToSubtract);
  return dt.toISOString().slice(0, 10);
}

function vzMockVehicleDetails(serial) {
  let h = 0;
  for (let i = 0; i < serial.length; i++) h = Math.imul(h * 31 + serial.charCodeAt(i), 1) | 0;
  h = Math.abs(h);
  const makes = [
    { make: 'Ford',       models: ['F-150', 'Transit', 'E-350', 'F-250'] },
    { make: 'Toyota',     models: ['Camry', 'Tacoma', 'Sienna', 'Tundra'] },
    { make: 'Chevrolet',  models: ['Silverado 3500HD Crew Cab', 'Express', 'Colorado'] },
    { make: 'Ram',        models: ['1500', 'ProMaster', '2500'] },
    { make: 'GMC',        models: ['Sierra', 'Savana', 'Canyon'] },
  ];
  const { make, models } = makes[h % makes.length];
  const model = models[(h >> 4) % models.length];
  const year  = 2018 + ((h >> 8) % 7);
  const L = 'ABCDEFGHJKLMNPRSTUVWXYZ';
  const plate = L[(h >> 12) % L.length] + L[(h >> 16) % L.length] + L[(h >> 20) % L.length]
              + String(1000 + (h >> 4) % 8999); // C360 format: ABC1234 (2026-10-14, per Catalina)
  return { year, make, model, plate };
}

// Deterministic permutation 1..total (step coprime with total) so consecutive unit numbers jump between bundles.
function vzMixedUnitNumber(n, total) {
  if (!total || total < 2) return n;
  const gcd = (a, b) => (b ? gcd(b, a % b) : a);
  const step = [7, 5, 11, 13, 3].find(k => k < total && gcd(k, total) === 1) || 1;
  return ((n - 1) * step) % total + 1;
}

function vzGenerateSubscriptions() {
  const subs = [];
  let subId = 1;
  const opt = bld.targetOptId ? options.find(o => o.id === bld.targetOptId) : null;
  const sourceBundles = proposalData.entryPoint === 'renewalRewrap'
    ? (opt ? (opt.bundles || []).filter(bundle => bundle.originalQty !== undefined) : [])
    : (Array.isArray(existingOrders) ? existingOrders : []).flatMap(order => order.bundles || []);
  const bundles = sourceBundles;
  const excludedCancelIds = new Set((opt?.bundles || [])
    .filter(bundle => bundle.isolatedTransactionType === 'cancel' && bundle.id !== bld.targetBundleId)
    .flatMap(bundle => Array.isArray(bundle.selectedSubIds) ? bundle.selectedSubIds : []));
  const totalUnits = bundles.reduce((sum, b) => sum + (Number(b.qty) || 0), 0);
  const msaEndDate = (proposalData && proposalData.msaEndDate) || '2028-01-01';
  const contractType = (proposalData && proposalData.contractType) || 'Flex';
  const remain = vzMonthsUntil(msaEndDate);
  const term = (opt && opt.term) || 36;

  bundles.forEach((bundle, bundleIndex) => {
    const qty = Math.max(0, Math.floor(Number(bundle.qty) || 0));
    if (!qty) return;
    let unitPrice = bundle.basePrice || 0;
    try {
      unitPrice = calcBundle(bundle, term, bundle.promoType || 'Standard', totalUnits).unitPrice;
    } catch (_) {}

    for (let i = 0; i < qty; i++) {
      const stableSubId = window.getVZBundleSubscriptionId(bundle, i);
      if (excludedCancelIds.has(stableSubId)) continue;
      const serial = `VZC-${String(subId).padStart(6, '0')}`;
      // 2026-11-05 (Mayank): stable per vehicle (was random, so Edit showed another VIN each time).
      const vin = `1VZC${String(subId).padStart(5,'0')}VX${String(vzHash(serial + ':vin') % 90 + 10)}`;
      subs.push({
        id: stableSubId,
        erp: `ERP-${vzHash(serial + ':erp') % 90000 + 10000}`,
        techRef: `${String(vzHash(serial + ':t1') % 900000000 + 1000000000)}-${String(vzHash(serial + ':t2') % 900000000 + 1000000000)}`,
        product: bundle.coreName,
        productKey: bundle.coreKey,
        features: Array.isArray(bundle.features) ? bundle.features : [],
        bundleId: bundle.id,
        subStatus: 'Active',
        renewalType: contractType,
        subEnd: msaEndDate,
        deviceStatus: 'Active',
        rate: unitPrice,
        serial: serial,
        vin: vin,
        ecfEnd: msaEndDate,
        minCommit: term,
        remainMonths: remain,
        esn: serial,
        // 2026-10-14 (per Catalina): 10-digit order number, no prefix (e.g. 5003808673); a few vehicles share an order.
        orderNumber: String(5003808673 + bundleIndex * 1371 + Math.floor(i / 5) * 17),
        subStart: vzSubStartFromEnd(msaEndDate, term) || vzSubStartFromEnd(msaEndDate, 24),
        // 2026-10-14 (per Catalina): unit numbers interleave the cores so the list reads as a mixed fleet.
        // One long name on purpose, to show the "…" truncation in the vehicle table (2026-10-14, per Catalina).
        vehicleName: vzMixedUnitNumber(subId, totalUnits) === 2 ? 'Northside Refrigerated Delivery Truck 02' : `Unit-${String(vzMixedUnitNumber(subId, totalUnits)).padStart(3,'0')}`,
        parentEsn: '--',
        isCore: true,
        linkedCoreSerial: null,
      });
      subId++;
    }
  });

  return subs;
}

function vzGetAlreadyUpsoldSubIds() {
  const opt = bld.targetOptId ? options.find(o => o.id === bld.targetOptId) : null;
  return new Set((opt?.bundles || [])
    .filter(bundle => bundle.isolatedTransactionType === 'upsell' && bundle.id !== bld.targetBundleId)
    .flatMap(bundle => Array.isArray(bundle.selectedSubIds) ? bundle.selectedSubIds : []));
}

function vzApplySubFilter(subs) {
  return subs.filter(s => {
    const productOk = vzSubFilter.products.length === 0 || vzSubFilter.products.includes(s.productKey);
    const statusOk  = vzSubFilter.statuses.length === 0 || vzSubFilter.statuses.includes(s.deviceStatus);
    return productOk && statusOk;
  });
}

function renderVZUpsellForm() {
  vzTxBillingModel = 'opex';
  vzUpsellPreSelected = txPreselectedSubIds.length > 0 ? [...txPreselectedSubIds] : [];
  vzUpsellFeatureFilterKeys = [];
  txPreselectedSubIds = [];
  vzUpsellDiscountPct = Number(proposalData.msaDiscretionaryDiscountPct) || 0;

  const allSubs = vzGenerateSubscriptions();
  const subs = allSubs.filter(s => s.isCore);

  const area = document.getElementById('gc-tx-form-area');
  // 2026-10-15 (per Catalina): "Start with" dropdown replaced by the By feature | By vehicle switch in the modal header.
  area.innerHTML = `
    <div class="gc-tx-step active" id="gc-tx-upsell-step1">
      ${upsellMode === 'vehicles' ? `
      <!-- VEHICLES MODE: vehicle table (sections per core subscription, sortable headers) -->
      ${vzVehicleTableShellHtml('upsell')}
      ` : `
      <!-- FEATURES MODE: categorized feature grid -->
      ${vzUpsellFeaturesHtml(new Set(), 0)}
      `}
    </div>

    <div class="gc-tx-step" id="gc-tx-upsell-step2">
      ${upsellMode === 'features' ? '' : `<div class="gc-tx-step-header">
        <div class="gc-tx-step-title">Choose Features to Add</div>
      </div>`}
      <div id="gc-upsell-step2-body"></div>
    </div>`;
  vzSyncUpsellModeToggle();

  // Initialize right-side preview pane
  vzUpdateUpsellPreview();


  // Footer: back button + Add Upsell (disabled until step 2 complete)
  if (upsellMode === 'vehicles') {
    setVZTxFooter(`
      <button class="btn btn--primary btn--large" id="gc-upsell-next-btn" onclick="vzGoUpsellStep2()" style="flex:none; padding:10px 24px; font-size:14px; gap:8px;">Choose features</button>
    `);
    vzRenderUpsellTable();
  } else {
    setVZTxFooter(`<button class="btn btn--primary btn--large" onclick="vzGoUpsellStep2()" style="flex:none; padding:10px 24px; font-size:14px; gap:8px;">Select vehicles</button>`);
  }
}

// 2026-10-15 (per Catalina): the switch lives in the modal header, step 1 only. Changing it starts over; if something
// is already selected, a small confirmation first ("Your selection will be cleared").
let vzPendingUpsellMode = null;
function vzSyncUpsellModeToggle() {
  const toggle = document.querySelector('.upsell-mode-toggle');
  if (!toggle) return;
  const step2 = document.getElementById('gc-tx-upsell-step2');
  const onStep1 = !step2 || !step2.classList.contains('active');
  toggle.classList.toggle('hidden', bld.txType !== 'upsell' || !onStep1 || !document.getElementById('gc-tx-upsell-step1'));
  ['features', 'vehicles'].forEach(mode => {
    const btn = document.getElementById(`upsell-mode-${mode}`);
    if (!btn) return;
    btn.classList.toggle('segmented-control__option--active', upsellMode === mode);
    btn.setAttribute('aria-pressed', String(upsellMode === mode));
  });
}
function vzUpsellHasSelection() {
  return document.querySelectorAll('#gc-tx-upsell-step1 .gc-upsell-feature-cb:checked, #gc-tx-upsell-step1 .gc-upsell-vehicle-cb:checked').length > 0;
}
function vzSetUpsellMode(mode) {
  if (mode === upsellMode) return;
  // 2026-10-21 (per Catalina): no "Change how you start?" confirmation — switching starts over right away.
  upsellMode = mode;
  renderVZUpsellForm();
}
function closeUpsellModeConfirm() {
  vzPendingUpsellMode = null;
  document.getElementById('upsell-mode-overlay')?.classList.remove('is-open');
}
function confirmUpsellModeChange() {
  const mode = vzPendingUpsellMode;
  closeUpsellModeConfirm();
  if (!mode) return;
  upsellMode = mode;
  renderVZUpsellForm();
}

function vzToggleUpsellAll(el) {
  document.querySelectorAll('.gc-upsell-vehicle-cb').forEach(cb => { if (!cb.closest('tr')?.classList.contains('vz-search-hidden')) cb.checked = el.checked; });
  vzUpdateUpsellCount();
}

function vzUpdateUpsellCount() {
  if (typeof vzSyncSelectedCount === 'function') vzSyncSelectedCount('upsell');
  const count = document.querySelectorAll('.gc-upsell-vehicle-cb:checked').length;
  const btn = document.getElementById('gc-upsell-next-btn');
  if (btn) {
    btn.disabled = count === 0;
    btn.style.opacity = count === 0 ? '0.45' : '1';
    btn.style.cursor = count === 0 ? 'not-allowed' : 'pointer';
  }
  vzUpdateUpsellPreview();
  vzRefreshMsaCommitmentPanel();
}

function vzSyncSelectWidth(sel) {
  // 2026-10-07: these selects are VDS Select S now (width follows the content) \u2014 nothing to measure.
  if (sel) sel.style.width = '';
}

/* ── Vehicle table — Feature Upsell + Partial Cancellation (2026-10-14, per Weekly 2026-10-13 / Catalina) ──
   One table for both transactions:
   - "Sort by": Vehicle (C360-style blocks) or Core subscription (sections per core, features listed per vehicle).
   - Vehicle row: Vehicle (name + VIN), Make, Model, License Plate, Order, Status (one status per vehicle:
     Installed, Scheduled, Shipped, In fulfillment, Ordered). No Start / End Date.
   - Sub-row: the subscription + its hardware with serials (Cancel adds Tech Ref ID, Rate / mo, Remain).
   - Subscriptions not yet assigned to a vehicle (Ordered, In fulfillment) show "--" in the vehicle columns.
   - Feature Upsell lists vehicles only (assets can't take features); Partial Cancellation lists vehicles and assets.
   - Feature-first Upsell: step 2 lists only vehicles that don't have the chosen features yet. */
const VZ_VEHICLE_STATUSES = ['Installed', 'Scheduled', 'Shipped', 'In fulfillment', 'Ordered'];
const VZ_VEHICLE_STATUS_BADGE = { Installed: 'badge--green', Scheduled: 'badge--blue', Shipped: 'badge--blue', 'In fulfillment': 'badge--yellow', Ordered: 'badge--gray', Deactivated: 'badge--gray' };
let vzUpsellFeatureFilterKeys = []; // feature-first Upsell: features chosen in step 1

function vzIsAssetCore(coreKey) { return String(coreKey || '').startsWith('asset'); }

function vzHash(text) {
  let h = 0;
  for (let i = 0; i < text.length; i++) h = Math.imul(h * 31 + text.charCodeAt(i), 1) | 0;
  return Math.abs(h);
}

function vzVehicleStatus(serial) {
  // 2026-10-16 (per Catalina): a more visible mix for demos — about half Installed, the rest across Scheduled,
  // Shipped, In fulfillment and Ordered (was 70% Installed, so the other statuses were hard to find).
  const n = vzHash(serial + ':st8') % 100;
  if (n < 48) return 'Installed';
  if (n < 62) return 'Scheduled';
  if (n < 74) return 'Shipped';
  if (n < 88) return 'In fulfillment';
  return 'Ordered';
}

// Hardware a subscription carries (serials only once the device has shipped).
function vzSubscriptionHardware(sub, status) {
  const shipped = !['Ordered', 'In fulfillment'].includes(status);
  const serialFor = (prefix) => shipped ? `${prefix}-${String(vzHash(sub.serial + prefix) % 900000 + 100000)}` : '--';
  const core = {
    vtu: [['Vehicle Tracking Unit', 'VZC']],
    'vtu-ffc': [['Vehicle Tracking Unit', 'VZC'], ['AI Dashcam (forward)', 'CAM']],
    'vtu-dual': [['Vehicle Tracking Unit', 'VZC'], ['AI Dashcam (dual)', 'CAM']],
    'asset-powered': [['Powered Asset Tracker', 'AST']],
    'asset-nonpowered': [['Non-Powered Asset Tracker', 'AST']],
  }[sub.productKey] || [['Tracking Unit', 'VZC']];
  const extras = (sub.features || []).filter(k => k === 'evc' || k === 'monitor')
    .map(k => [k === 'evc' ? 'Extended View Camera' : 'In-Cab Monitor', k === 'evc' ? 'EVC' : 'MON']);
  return [...core, ...extras].map(([label, prefix]) => ({ label, serial: prefix === 'VZC' && shipped ? sub.serial : serialFor(prefix) }));
}

function vzVehicleRecord(sub) {
  // Reactivation lists previously deactivated vehicles (status "Deactivated", hardware already installed once).
  const status = sub.deactivatedDate ? 'Deactivated' : vzVehicleStatus(sub.serial);
  const assigned = !['Ordered', 'In fulfillment'].includes(status);
  const isAsset = vzIsAssetCore(sub.productKey);
  let make = '', model = '', plate = '', year = '';
  if (isAsset) {
    const h = vzHash(sub.serial);
    make = ['Great Dane', 'Wabash', 'Utility', 'Caterpillar'][h % 4];
    model = ['Dry Van', 'Reefer', 'Flatbed', 'Generator'][(h >> 3) % 4];
    plate = vzMockVehicleDetails(sub.serial).plate;
  } else {
    const vd = vzMockVehicleDetails(sub.serial);
    make = vd.make; model = vd.model; plate = vd.plate; year = vd.year;
  }
  return {
    sub, status, assigned, isAsset,
    name: assigned ? sub.vehicleName : '',
    vin: assigned && !isAsset ? sub.vin : '',
    make: assigned ? make : '', model: assigned ? model : '', plate: assigned ? plate : '',
    year: assigned ? year : '',
    order: sub.orderNumber || '',
    hardware: vzSubscriptionHardware(sub, status),
  };
}

function vzSubscriptionLabelHtml(sub) {
  if (builderMode === 'plan') {
    const match = findClosestPrebuiltTier(sub.productKey, sub.features || []);
    if (match) {
      const coreLabel = corePricing[sub.productKey]?.name || sub.productKey;
      const featureNames = (sub.features || []).map(k => featureLabels[k] || k).join(', ');
      return `<div class="vz-vtable__strong">${match.bundle.name} — ${match.tier.label}</div><div class="vz-vtable__meta">${coreLabel}${featureNames ? ', ' + featureNames : ''}</div>`;
    }
  }
  return `<div class="vz-vtable__strong">${sub.product}</div>`;
}

// Which upsell features a subscription already has (core rank for cameras, catalog features otherwise).
// 2026-11-05 (Existing Business follow-up, Mayank / Rogelio / Catalina): no duplicates — a feature already added to a
// vehicle in another Feature Upsell of the same option counts as one it has (it isn't offered or charged again).
function vzPendingUpsellKeys(subId) {
  const opt = bld.targetOptId ? options.find(o => o.id === bld.targetOptId) : null;
  const keys = new Set();
  (opt?.bundles || []).forEach(bundle => {
    if (bundle.isolatedTransactionType !== 'upsell' || bundle.id === bld.targetBundleId) return;
    if (!Array.isArray(bundle.selectedSubIds) || !bundle.selectedSubIds.includes(subId)) return;
    (bundle.features || []).forEach(k => keys.add(k));
  });
  if (keys.has('dual')) keys.add('ffc'); // Dual = FFC + driver facing camera
  return keys;
}
function vzSubHasUpsellFeatures(sub, sourceBundles) {
  const sourceBundle = sourceBundles.find(b => b.id === sub.bundleId);
  const currentFeatures = Array.isArray(sourceBundle?.features) ? sourceBundle.features : (sub.features || []);
  const has = new Set();
  VZ_UPSELL_FEATURES.forEach(f => {
    const aliasCore = VZ_UPSELL_CORE_ALIAS[f.key];
    if (aliasCore) {
      if ((VZ_UPSELL_CORE_RANK[sub.productKey] || 0) >= (VZ_UPSELL_CORE_RANK[aliasCore] || 0)) has.add(f.key);
    } else if (currentFeatures.includes(VZ_UPSELL_FEATURE_TO_CATALOG_KEY[f.key] || f.key)) {
      has.add(f.key);
    }
  });
  vzPendingUpsellKeys(sub.id).forEach(k => has.add(k));
  return has;
}

// View switch (2026-10-14, per Catalina — like before the C360-style rework): "Sort by" Vehicle (default) or Core
// subscription. Vehicle = one block per vehicle (C360 style: summary row + its subscriptions, features and hardware);
// Core subscription = sections per core subscription with the vehicles that have it (features listed per vehicle,
// so it's clear the grouping is by core only).
const vzVehicleTableView = { upsell: 'vehicle', cancel: 'vehicle' };

function vzVehicleTableShellHtml(prefix, note) {
  const view = vzVehicleTableView[prefix] || 'vehicle';
  vzVehicleFilters[prefix] = { status: [], product: [] };
  vzShowSelectedOnly[prefix] = false;
  return `${note ? `<p class="vz-vtable-note">${note}</p>` : ''}
    <!-- 2026-10-14 (per Catalina): "Sort by" hidden for now; the table shows the Vehicle view. Remove "hidden" to bring it back. -->
    <div class="vz-vtable-toolbar hidden">
      <div class="vz-vtable-toolbar__sort">
        <label class="sort-by-label" for="gc-${prefix}-view-select">Sort by:</label>
        <select class="select select--small select--borderless" id="gc-${prefix}-view-select" data-vc-dropdown onchange="vzSetVehicleTableView('${prefix}', this.value)">
          <option value="vehicle"${view === 'vehicle' ? ' selected' : ''}>Vehicle</option>
          <option value="core"${view === 'core' ? ' selected' : ''}>Core subscription</option>
        </select>
      </div>
    </div>
    <!-- 2026-10-20 (PM/PO/UX sync + EB workshop, per Catalina): search and filters for large accounts — they hide rows
         (no paging); selections are kept while the search changes. -->
    <div class="vz-search" id="gc-${prefix}-search">
      <div class="vz-search__bar">
        ${VC.searchField({ id: `gc-${prefix}-search-input`, size: 'small', className: 'vz-search__box', placeholder: 'Search by model, license plate, VIN or name', ariaLabel: 'Search vehicles', onInput: `vzApplyVehicleSearch('${prefix}')` })}
        <span class="vz-search__filters" id="gc-${prefix}-filter-bar"></span>
      </div>
    </div>
    <div class="gc-sub-table-wrap vz-vtable-wrap">
      <table class="gc-sub-table vz-vtable vz-vtable--${prefix}" id="gc-${prefix}-table">
        <thead id="gc-${prefix}-thead"></thead>
        <tbody id="gc-${prefix}-tbody"></tbody>
      </table>
    </div>`;
}

// Table header (C360): select-all checkbox + "Vehicle/Asset", bold, black rule under it.
// ── Vehicle search / filters (2026-10-20) ──────────────────────────────────────────────────────────
// Rows are hidden, never re-rendered, so selections stay while the search changes. Matches model (year make model),
// license plate, VIN and vehicle name; Status and Product filters list only the values present in the table.
const vzShowSelectedOnly = {};
const VZ_SEARCH_CHECKBOXES = { upsell: '.gc-upsell-vehicle-cb', cancel: '.gc-cancel-cb', reactivation: '.gc-reactivation-cb' };
// 2026-10-20 (per Catalina): Status and Product live behind a filter icon, in the Dashboard's filter pattern (accordions
// with checkboxes, "Clear all", "Show results (n)"), opened as a panel inside the modal; "Clear filters" next to the icon.
const vzVehicleFilters = {};
const vzVehicleFilterDraft = {};
const vzVehicleFilterOpen = {};
const VZ_FILTER_FIELDS = [
  { key: 'status', title: 'Status' },
  { key: 'product', title: 'Product' },
];
function vzFilterValues(table, key) {
  const tbody = document.getElementById(`gc-${table}-tbody`);
  if (!tbody) return [];
  return [...new Set([...tbody.querySelectorAll('tr.vz-vtable__vehicle')].map(r => r.dataset[key]).filter(Boolean))].sort();
}
function vzActiveFilterCount(table) {
  const f = vzVehicleFilters[table] || {};
  return VZ_FILTER_FIELDS.filter(x => (f[x.key] || []).length).length;
}
function vzRowMatches(table, row, filters, q) {
  return (!q || row.dataset.search.includes(q))
    && (!filters.status.length || filters.status.includes(row.dataset.status))
    && (!filters.product.length || filters.product.includes(row.dataset.product));
}
function vzInitVehicleSearch(table) {
  const f = vzVehicleFilters[table] || (vzVehicleFilters[table] = { status: [], product: [] });
  VZ_FILTER_FIELDS.forEach(x => { const vals = vzFilterValues(table, x.key); f[x.key] = f[x.key].filter(v => vals.includes(v)); });
  vzRenderVehicleFilterBar(table);
  vzApplyVehicleSearch(table);
}
function vzRenderVehicleFilterBar(table) {
  const bar = document.getElementById(`gc-${table}-filter-bar`);
  if (!bar) return;
  const count = vzActiveFilterCount(table);
  bar.innerHTML = `${count ? `<button type="button" class="text-link text-link--small" id="gc-${table}-filter-clear" onclick="vzClearVehicleFilters('${table}')">Clear filters</button>` : ''}<button type="button" class="btn-icon btn-icon--solid btn-icon--small ql-filter-btn vz-search__filter-btn" id="gc-${table}-filter-btn" title="Filters" aria-label="Filters${count ? ` (${count} active)` : ''}" aria-haspopup="dialog" aria-controls="gc-${table}-filter-drawer" onclick="vzOpenVehicleFilters('${table}')">
      <span class="material-symbols-outlined" aria-hidden="true">filter_list</span>${count ? `<span class="badge-indicator badge-indicator--numbered ql-filter-count" aria-hidden="true">${count}</span>` : ''}
    </button>`;
}
function vzEnsureVehicleFilterDrawer(table) {
  const id = `gc-${table}-filter-drawer`;
  if (document.getElementById(id)) return;
  // 2026-11-04 fix: the filters panel opens inside the modal that holds this table (Migrations' vehicles modals),
  // not always inside the Configure Solution modal.
  const host = document.getElementById(`gc-${table}-table`)?.closest('.modal') || document.querySelector('#bundle-overlay .bundle-modal') || document.body;
  host.insertAdjacentHTML('beforeend', VC.drawer({
    id, title: 'Filters', onClose: `vzCloseVehicleFilters('${table}')`,
    actions: [{ label: 'Show results', primary: true, id: `${id}-apply`, onClick: `vzApplyVehicleFilterDraft('${table}')` }],
  }));
  document.getElementById(id).classList.add('vc-drawer--contained');
  document.getElementById(`${id}-backdrop`).classList.add('vc-drawer-backdrop--contained');
  document.getElementById(`${id}-title`).insertAdjacentHTML('afterend',
    `<button type="button" class="text-link text-link--small ql-filter-clear-all" id="${id}-clear" onclick="vzClearVehicleFilterDraft('${table}')">Clear all</button>`);
}
function vzRenderVehicleFilterDrawer(table) {
  const id = `gc-${table}-filter-drawer`;
  const body = document.querySelector(`#${id} .vc-drawer__body`);
  if (!body) return;
  const draft = vzVehicleFilterDraft[table];
  const open = vzVehicleFilterOpen[table] || (vzVehicleFilterOpen[table] = new Set(VZ_FILTER_FIELDS.map(x => x.key)));
  body.innerHTML = VZ_FILTER_FIELDS.map(field => {
    const picked = draft[field.key];
    const isOpen = open.has(field.key);
    const rows = vzFilterValues(table, field.key).map(v => `<label class="vc-check-row"><input type="checkbox" class="checkbox__input" ${picked.includes(v) ? 'checked' : ''} onchange="vzToggleVehicleFilterValue('${table}', '${field.key}', '${String(v).replace(/'/g, "\\'")}', this.checked)"><span class="vc-check-row__text">${v}</span></label>`).join('');
    return `<div class="vc-accordion ql-filter-section${isOpen ? ' is-open' : ''}">
      <button type="button" class="vc-accordion__header" aria-expanded="${isOpen}" onclick="vzToggleVehicleFilterSection('${table}', '${field.key}')">
        <span class="vc-accordion__title">${field.title}</span>
        <span class="vc-accordion__right">${picked.length ? `<span class="badge vc-accordion__count">${picked.length}</span>` : ''}<span class="material-symbols-outlined vc-accordion__chevron" aria-hidden="true">expand_more</span></span>
      </button>
      <div class="vc-accordion__body">${rows}</div>
    </div>`;
  }).join('');
  const clear = document.getElementById(`${id}-clear`);
  if (clear) clear.disabled = !VZ_FILTER_FIELDS.some(x => draft[x.key].length);
  const apply = document.getElementById(`${id}-apply`);
  if (apply) {
    const q = (document.getElementById(`gc-${table}-search-input`)?.value || '').trim().toLowerCase();
    const n = [...document.querySelectorAll(`#gc-${table}-tbody tr.vz-vtable__vehicle`)].filter(r => vzRowMatches(table, r, draft, q)).length;
    apply.textContent = `Show results (${n})`;
  }
}
function vzOpenVehicleFilters(table) {
  const first = !document.getElementById(`gc-${table}-filter-drawer`);
  vzEnsureVehicleFilterDrawer(table);
  const f = vzVehicleFilters[table];
  vzVehicleFilterDraft[table] = { status: [...f.status], product: [...f.product] };
  vzRenderVehicleFilterDrawer(table);
  if (first) document.getElementById(`gc-${table}-filter-drawer`)?.getBoundingClientRect();
  VC.setDrawerOpen(`gc-${table}-filter-drawer`, true);
}
function vzCloseVehicleFilters(table) {
  VC.setDrawerOpen(`gc-${table}-filter-drawer`, false);
}
function vzToggleVehicleFilterSection(table, key) {
  const open = vzVehicleFilterOpen[table];
  if (open.has(key)) open.delete(key); else open.add(key);
  vzRenderVehicleFilterDrawer(table);
}
function vzToggleVehicleFilterValue(table, key, value, checked) {
  const cur = vzVehicleFilterDraft[table][key];
  vzVehicleFilterDraft[table][key] = checked ? [...new Set([...cur, value])] : cur.filter(v => v !== value);
  vzRenderVehicleFilterDrawer(table);
}
function vzClearVehicleFilterDraft(table) {
  vzVehicleFilterDraft[table] = { status: [], product: [] };
  vzRenderVehicleFilterDrawer(table);
}
function vzApplyVehicleFilterDraft(table) {
  const d = vzVehicleFilterDraft[table];
  vzVehicleFilters[table] = { status: [...d.status], product: [...d.product] };
  vzCloseVehicleFilters(table);
  vzRenderVehicleFilterBar(table);
  vzApplyVehicleSearch(table);
}
function vzClearVehicleFilters(table) {
  vzVehicleFilters[table] = { status: [], product: [] };
  vzRenderVehicleFilterBar(table);
  vzApplyVehicleSearch(table);
}
function vzApplyVehicleSearch(table) {
  const tbody = document.getElementById(`gc-${table}-tbody`);
  if (!tbody) return;
  const q = (document.getElementById(`gc-${table}-search-input`)?.value || '').trim().toLowerCase();
  const filters = vzVehicleFilters[table] || { status: [], product: [] };
  const cbSel = VZ_SEARCH_CHECKBOXES[table];
  const rows = [...tbody.querySelectorAll('tr.vz-vtable__vehicle')];
  let shown = 0;
  rows.forEach(row => {
    const block = tbody.querySelectorAll(`tr[data-vkey="${row.dataset.vkey}"]`);
    const selected = [...block].some(tr => [...tr.querySelectorAll(cbSel)].some(cb => cb.checked));
    const match = vzRowMatches(table, row, filters, q) && (!vzShowSelectedOnly[table] || selected);
    block.forEach(tr => tr.classList.toggle('vz-search-hidden', !match));
    if (match) shown += 1;
  });
  let empty = tbody.querySelector('.vz-search-empty');
  if (!shown && rows.length) {
    // Same empty state as the Proposal Dashboard filters: message + "Clear filters" (clears search, filters and Show selected).
    if (!empty) { empty = document.createElement('tr'); empty.className = 'vz-search-empty'; tbody.appendChild(empty); }
    empty.innerHTML = `<td colspan="9" class="table-body-cell ql-filter-empty"><div>${vzActiveFilterCount(table) || vzShowSelectedOnly[table] ? 'No vehicles match these filters.' : 'No vehicles match your search.'}</div><button type="button" class="text-link text-link--small ql-filter-clear-empty" onclick="vzClearVehicleSearch('${table}')">Clear filters</button></td>`;
  } else if (empty) empty.remove();
  // 2026-10-20 (per Catalina): no results count outside the table, as in the Proposal Dashboard.
  vzSyncSelectedCount(table);
}
function vzSyncSelectedCount(table) {
  const tbody = document.getElementById(`gc-${table}-tbody`);
  if (!tbody) return;
  const cbSel = VZ_SEARCH_CHECKBOXES[table];
  const keys = new Set([...tbody.querySelectorAll(`${cbSel}:checked`)].map(cb => cb.closest('tr')?.dataset.vkey).filter(Boolean));
  const el = document.getElementById(`gc-${table}-selected-count`);
  if (el) el.textContent = keys.size ? ` (${keys.size})` : '';
  // 2026-10-21 (per Catalina): the header checkbox is indeterminate when only some of the visible rows are selected.
  const all = document.getElementById(`gc-${table}-select-all`);
  if (all) {
    const boxes = [...tbody.querySelectorAll(cbSel)].filter(cb => !cb.disabled && !cb.closest('tr')?.classList.contains('vz-search-hidden'));
    const on = boxes.filter(cb => cb.checked).length;
    all.checked = boxes.length > 0 && on === boxes.length;
    all.indeterminate = on > 0 && on < boxes.length;
  }
  const btn = document.getElementById(`gc-${table}-show-selected`);
  if (btn) {
    btn.classList.toggle('hidden', !keys.size && !vzShowSelectedOnly[table]);
    btn.textContent = vzShowSelectedOnly[table] ? 'Show all' : 'Show selected';
  }
}
function vzClearVehicleSearch(table) {
  const input = document.getElementById(`gc-${table}-search-input`);
  if (input) { input.value = ''; VC.searchFieldSync(input); }
  vzVehicleFilters[table] = { status: [], product: [] };
  vzShowSelectedOnly[table] = false;
  vzRenderVehicleFilterBar(table);
  vzApplyVehicleSearch(table);
}
function vzToggleShowSelected(table) {
  vzShowSelectedOnly[table] = !vzShowSelectedOnly[table];
  vzApplyVehicleSearch(table);
}

function vzVehicleTableHeadHtml(table, colCount) {
  // Read only: no checkbox column (2026-11-04, per Catalina — it left an empty gap before the vehicle).
  if (table === 'migration') return `<tr class="vz-vtable__head"><th colspan="${colCount}">Vehicle/Asset</th></tr>`;
  if (table === 'migration-select') return `<tr class="vz-vtable__head"><th class="vz-vtable__check"><input type="checkbox" class="checkbox__input" id="gc-migration-select-select-all" checked onchange="migrationSelectAll(this.checked)" aria-label="Select all"></th><th colspan="${colCount - 1}">Vehicle/Asset</th></tr>`;
  const selectAll = table === 'upsell' ? 'vzToggleUpsellAll(this)' : table === 'reactivation' ? 'vzToggleReactivationAll(this)' : 'vzToggleCancelAll(this)';
  return `<tr class="vz-vtable__head"><th class="vz-vtable__check"><input type="checkbox" class="checkbox__input" id="gc-${table}-select-all" onchange="${selectAll}" aria-label="Select all"></th><th colspan="${colCount - 1}">Vehicle/Asset<span class="vz-vtable__head-selected" id="gc-${table}-selected-count"></span><button type="button" class="text-link text-link--small vz-vtable__head-link hidden" id="gc-${table}-show-selected" onclick="vzToggleShowSelected('${table}')">Show selected</button></th></tr>`;
}

function vzSortVehicleRecords(records) {
  // Assigned vehicles by name; unassigned subscriptions ("--") last.
  return [...records].sort((a, b) => {
    if (!a.name !== !b.name) return a.name ? -1 : 1;
    return String(a.name || a.sub.serial).localeCompare(String(b.name || b.sub.serial), 'en', { numeric: true });
  });
}

function vzSetVehicleTableView(table, view) {
  vzVehicleTableView[table] = view === 'core' ? 'core' : 'vehicle';
  if (table === 'upsell') {
    vzUpsellPreSelected = [...document.querySelectorAll('.gc-upsell-vehicle-cb:checked')].map(cb => cb.value);
    vzRenderUpsellTable();
  } else {
    window._vzCancelPreSelected = [...document.querySelectorAll('.gc-cancel-cb:checked')].map(cb => cb.value);
    vzRenderCancelTable();
  }
}

// Vehicle icon in the Vehicle / Asset cell (restored 2026-10-14, per Catalina); assets get a box icon.
const VZ_VEHICLE_ICON_SVG = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="vz-vtable__icon" aria-hidden="true"><path d="M7.55556 11.9999C7.55556 12.2197 7.49039 12.4345 7.3683 12.6172C7.24621 12.7999 7.07268 12.9423 6.86965 13.0264C6.66662 13.1105 6.44321 13.1325 6.22768 13.0897C6.01214 13.0468 5.81416 12.941 5.65877 12.7856C5.50338 12.6302 5.39756 12.4322 5.35468 12.2167C5.31181 12.0011 5.33381 11.7777 5.41791 11.5747C5.50201 11.3717 5.64442 11.1981 5.82714 11.076C6.00987 10.954 6.22469 10.8888 6.44444 10.8888C6.73913 10.8888 7.02174 11.0059 7.23012 11.2142C7.43849 11.4226 7.55556 11.7052 7.55556 11.9999ZM16.4444 11.9999C16.4444 12.2197 16.5096 12.4345 16.6317 12.6172C16.7538 12.7999 16.9273 12.9423 17.1304 13.0264C17.3334 13.1105 17.5568 13.1325 17.7723 13.0897C17.9879 13.0468 18.1858 12.941 18.3412 12.7856C18.4966 12.6302 18.6024 12.4322 18.6453 12.2167C18.6882 12.0011 18.6662 11.7777 18.5821 11.5747C18.498 11.3717 18.3556 11.1981 18.1729 11.076C17.9901 10.954 17.7753 10.8888 17.5556 10.8888C17.2609 10.8888 16.9783 11.0059 16.7699 11.2142C16.5615 11.4226 16.4444 11.7052 16.4444 11.9999ZM22 10.8888C21.9999 11.1834 21.8828 11.466 21.6744 11.6743C21.4661 11.8827 21.1835 11.9998 20.8889 11.9999H20.84L20.8889 12.2166V20.8888H16.4444V18.2866H7.55556V20.8888H3.11111V12.2166L3.16 11.9999H3.11111C2.81643 11.9999 2.53381 11.8828 2.32544 11.6745C2.11706 11.4661 2 11.1835 2 10.8888C2 10.5941 2.11706 10.3115 2.32544 10.1031C2.53381 9.89474 2.81643 9.77768 3.11111 9.77768H3.66111L4.68222 5.24101C4.83477 4.62492 5.19179 4.07879 5.69494 3.69189C6.19808 3.30499 6.81759 3.10021 7.4522 3.11101H16.5478C17.1823 3.10006 17.8017 3.30481 18.3047 3.69175C18.8077 4.07869 19.1645 4.62491 19.3166 5.24101L20.3389 9.77768H20.8889C21.1835 9.77778 21.4661 9.89487 21.6744 10.1032C21.8828 10.3116 21.9999 10.5941 22 10.8888ZM6.30556 18.2843H4.36111V19.6388H6.30556V18.2843ZM19.6389 18.2843H17.6944V19.6388H19.6389V18.2843ZM19.6389 12.3555L18.0978 5.51546C18.0066 5.17691 17.8041 4.8789 17.523 4.66948C17.2418 4.46005 16.8983 4.35139 16.5478 4.36101H7.45222C7.10175 4.35139 6.75824 4.46005 6.47705 4.66948C6.19587 4.87891 5.99338 5.17691 5.90222 5.51546L4.36111 12.3555V17.0343H19.6389V12.3555Z" fill="currentColor"/></svg>';
// 2026-10-15 (per Catalina): assets use the VDS icon "adaptive-speaker" (assets-shared/ds/icons/adaptive-speaker.svg).
const VZ_ASSET_ICON_SVG = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="vz-vtable__icon" aria-hidden="true"> <path d="M19.7778 10.2949H4.22222C3.63285 10.2949 3.06762 10.529 2.65087 10.9458C2.23413 11.3625 2 11.9278 2 12.5171V18.6746C2 19.2639 2.23413 19.8292 2.65087 20.2459C3.06762 20.6627 3.63285 20.8968 4.22222 20.8968H19.7778C20.3671 20.8968 20.9324 20.6627 21.3491 20.2459C21.7659 19.8292 22 19.2639 22 18.6746V12.5171C22 11.9278 21.7659 11.3625 21.3491 10.9458C20.9324 10.529 20.3671 10.2949 19.7778 10.2949ZM20.75 18.6746C20.7497 18.9323 20.6472 19.1795 20.4649 19.3617C20.2827 19.544 20.0355 19.6465 19.7778 19.6468H4.22222C3.96446 19.6465 3.71735 19.544 3.53508 19.3617C3.35282 19.1795 3.25029 18.9323 3.25 18.6746V12.5171C3.25029 12.2594 3.35282 12.0123 3.53508 11.83C3.71735 11.6477 3.96446 11.5452 4.22222 11.5449H19.7778C20.0355 11.5452 20.2827 11.6477 20.4649 11.83C20.6472 12.0123 20.7497 12.2594 20.75 12.5171V18.6746ZM16.6968 12.8215C16.1481 12.8215 15.6116 12.9842 15.1554 13.2891C14.6991 13.5939 14.3435 14.0272 14.1335 14.5342C13.9235 15.0411 13.8685 15.599 13.9756 16.1372C14.0826 16.6754 14.3469 17.1697 14.7349 17.5578C15.1229 17.9458 15.6173 18.21 16.1554 18.3171C16.6936 18.4241 17.2515 18.3692 17.7585 18.1592C18.2654 17.9492 18.6987 17.5936 19.0036 17.1374C19.3085 16.6811 19.4712 16.1447 19.4712 15.596C19.4712 15.2316 19.3994 14.8708 19.26 14.5342C19.1206 14.1976 18.9162 13.8918 18.6586 13.6341C18.401 13.3765 18.0951 13.1721 17.7585 13.0327C17.4219 12.8933 17.0611 12.8215 16.6968 12.8215ZM16.6968 17.1203C16.3953 17.1203 16.1005 17.0309 15.8498 16.8634C15.5991 16.6959 15.4037 16.4578 15.2883 16.1792C15.173 15.9007 15.1428 15.5942 15.2016 15.2984C15.2604 15.0027 15.4056 14.7311 15.6188 14.5179C15.832 14.3047 16.1036 14.1595 16.3993 14.1007C16.6951 14.0419 17.0016 14.0721 17.2801 14.1874C17.5587 14.3028 17.7968 14.4982 17.9643 14.7489C18.1318 14.9996 18.2212 15.2944 18.2212 15.5959C18.2207 16.0001 18.06 16.3875 17.7742 16.6733C17.4884 16.9591 17.1009 17.1198 16.6968 17.1203ZM7.30321 12.8215C6.75447 12.8215 6.21805 12.9842 5.76178 13.289C5.30551 13.5939 4.94988 14.0272 4.73987 14.5341C4.52986 15.0411 4.4749 15.5989 4.58194 16.1371C4.68898 16.6753 4.95321 17.1697 5.34122 17.5577C5.72923 17.9458 6.22358 18.21 6.76178 18.3171C7.29997 18.4241 7.85782 18.3692 8.36479 18.1592C8.87177 17.9492 9.30508 17.5936 9.60995 17.1374C9.91481 16.6811 10.0775 16.1447 10.0775 15.596C10.0775 14.8601 9.78526 14.1545 9.26498 13.6342C8.74469 13.1138 8.03902 12.8215 7.30321 12.8215ZM7.30321 17.1203C7.0017 17.1203 6.70695 17.0309 6.45624 16.8634C6.20552 16.6959 6.01011 16.4578 5.89472 16.1793C5.77932 15.9007 5.74911 15.5942 5.80793 15.2985C5.86674 15.0028 6.01192 14.7311 6.22512 14.5179C6.43832 14.3047 6.70995 14.1595 7.00567 14.1007C7.30139 14.0419 7.60792 14.0721 7.88648 14.1874C8.16504 14.3028 8.40313 14.4982 8.57064 14.7489C8.73814 14.9996 8.82754 15.2944 8.82753 15.5959C8.82708 16 8.66634 16.3875 8.38057 16.6733C8.09481 16.9591 7.70735 17.1198 7.30321 17.1203ZM7.38889 6.25935L6.50563 5.3761C7.96369 3.92061 9.9397 3.10315 11.9999 3.10315C14.0601 3.10315 16.0361 3.92061 17.4941 5.3761L16.6109 6.25935C15.3867 5.03881 13.7286 4.35342 11.9999 4.35342C10.2712 4.35342 8.61306 5.03881 7.38889 6.25935ZM15.9772 7.14476L15.094 8.02801C14.2726 7.20878 13.1599 6.74871 11.9999 6.74871C10.8398 6.74871 9.72714 7.20878 8.90581 8.02801L8.02257 7.14476C9.07816 6.09129 10.5086 5.49964 11.9999 5.49964C13.4912 5.49964 14.9217 6.09129 15.9773 7.14476H15.9772Z" fill="currentColor"/> </svg>';
function vzVehicleIconHtml(r) {
  return r.isAsset ? VZ_ASSET_ICON_SVG : VZ_VEHICLE_ICON_SVG;
}
function vzVehicleTitle(r) {
  // Weekly 2026-10-13: a subscription not assigned to a vehicle yet shows "--" for the vehicle.
  if (!r.assigned) return '--';
  return r.isAsset ? `${r.make} ${r.model}` : `${r.year} ${r.make} ${r.model}`;
}
function vzStatusBadgeHtml(r) {
  return `<span class="badge ${VZ_VEHICLE_STATUS_BADGE[r.status] || 'badge--gray'}">${r.status}</span>`;
}

// C360-style summary row: title + VIN, then label-over-value blocks.
function vzVehicleSummaryHtml(r) {
  const dash = '--';
  return `<div class="vz-vtable__summary${r.billingLabel ? ' vz-vtable__summary--billing' : ''}">
      <div class="vz-vtable__vehicle-cell">${vzVehicleIconHtml(r)}<div><div class="vz-vtable__title" title="${vzVehicleTitle(r)}">${vzVehicleTitle(r)}</div>${r.vin ? `<div class="vz-vtable__vin">${r.vin}</div>` : ''}</div></div>
      <div class="vz-vtable__block"><div title="${r.name || ''}"><span class="vz-vtable__label">Name:</span> ${r.name || dash}</div><div><span class="vz-vtable__label">License plate:</span> ${r.plate || dash}</div></div>
      <div class="vz-vtable__block"><div class="vz-vtable__label">Order</div><div>${r.order || dash}</div></div>
      ${r.billingLabel ? `<div class="vz-vtable__block"><div class="vz-vtable__label">Billing status</div><div${r.billingLabel === 'Not billed' ? ' class="vz-vtable__billing-alert"' : ''}>${r.billingLabel}</div></div>` : ''}
      <div class="vz-vtable__block vz-vtable__block--status"><div class="vz-vtable__label">Status</div><div>${vzStatusBadgeHtml(r)}</div></div>
    </div>`;
}

// Subscription lines under a vehicle: the core subscription (one row per device: Core – Main / Core – Accessory),
// then one row per feature in it (Category "Feature"; hardware only for EVC / In-Cab Monitor).
function vzSubscriptionLines(r) {
  const sub = r.sub;
  const lines = [];
  const featureHw = { evc: 'Extended View Camera', monitor: 'In-Cab Monitor' };
  const coreHw = r.hardware.filter(h => !Object.values(featureHw).includes(h.label));
  coreHw.forEach((h, i) => lines.push({ first: i === 0, isCore: true, name: sub.product, category: i === 0 ? 'Core – Main' : 'Core – Accessory', hardware: h.label, serial: h.serial }));
  (sub.features || []).forEach(k => {
    const hw = featureHw[k] ? r.hardware.find(h => h.label === featureHw[k]) : null;
    lines.push({ first: true, isCore: false, name: featureLabels[k] || k, category: 'Feature', hardware: hw ? hw.label : '--', serial: hw ? hw.serial : '--' });
  });
  return lines;
}

// C360 model (2026-10-14, per Catalina): every subscription on a vehicle is its own entry — the core is split into
// Vehicle Tracking + its camera subscription, and every feature is a subscription too. Each subscription shows its
// ID (gray), Tech-Ref ID and Install Type; each of its hardware items is a row with its Category (Core – Main,
// Core – Accessory, Feature – Accessory) and the device with its serial below. Features without hardware: Feature, --.
// ── Seasonal on the existing account (2026-10-19, per Catalina / Leo) ─────────────────────────────────
// With seasonal billing on the account (Simulation Builder › Account configuration), some sample vehicles already
// have a season: a "Seasonal Fee (9 On / 3 Off)" subscription, shown like a feature on the vehicle. It's billed
// with Vehicle Tracking and can't be cancelled on its own (cancelling Vehicle Tracking cancels it).
const VZ_SEASONAL_SAMPLE = { hold: '9-3', holdStart: 11 }; // hold Dec–Feb → on Mar–Nov
function vzIsSeasonalVehicle(sub) {
  return typeof isSeasonalAvailable === 'function' && isSeasonalAvailable() && !!sub && !vzIsAssetCore(sub.productKey) && vzHash(String(sub.serial) + ':season') % 4 === 0;
}
function vzAccountHasSeasonal() {
  // The sample seasonal vehicles are a share of the account's vehicles, so any vehicle on the account means seasonal.
  return typeof isSeasonalAvailable === 'function' && isSeasonalAvailable() && (Array.isArray(existingOrders) ? existingOrders : [])
    .some(order => (order.bundles || []).some(b => !vzIsAssetCore(b.coreKey)));
}

function vzVehicleSubscriptions(r) {
  const sub = r.sub;
  // Weekly 2026-10-13 (Leo): serial numbers exist only once the hardware is installed; Scheduled, Shipped,
  // In fulfillment and Ordered show the hardware without a serial.
  const shipped = r.status === 'Installed' || r.status === 'Deactivated';
  const n = (salt) => String(1424000000 + vzHash(sub.serial + salt) % 900000);
  const serial = (salt) => shipped ? String(112300000 + vzHash(sub.serial + 'hw' + salt) % 900000) : '--';
  const techRef = (salt) => `${n(salt)}-${String(2324000000 + vzHash(sub.serial + 'tr' + salt) % 900000)}`;
  const installType = vzHash(sub.serial + 'it') % 3 === 0 ? 'CMI' : 'VMI';
  const mk = (name, salt, hardware, comp) => ({ name, key: salt, comp, id: n(salt), techRef: techRef(salt), installType, hardware });
  const list = [];
  if (vzIsAssetCore(sub.productKey)) {
    list.push(mk(`${sub.product} Subscription`, 'core', [{ category: 'Core – Main', label: sub.productKey === 'asset-powered' ? 'Powered Asset Tracker' : 'Non-Powered Asset Tracker', serial: serial('core') }]));
  } else {
    // PM/PO/UX sync 2026-10-14 (Leo): only core devices (VTU, asset trackers) and cameras have a serial number —
    // cables (Y-Cable kit) don't. The camera subscription isn't core: its category is Companion (own serial, works
    // with the VTU).
    list.push(mk('Vehicle Tracking Subscription', 'vt', [
      { category: 'Core – Main', label: 'VTU | Xirgo 6383', serial: serial('vtu') },
      { category: 'Core – Accessory', label: 'Y-Cable Kit | Xirgo 9pin', serial: '' },
    ], 'Vehicle Tracking'));
    if (vzIsSeasonalVehicle(sub)) list.push(Object.assign(mk(`Seasonal Fee (${getSeasonalHoldName({ seasonal: { hold: VZ_SEASONAL_SAMPLE.hold } })})`, 'season', [{ category: 'Feature', label: '--', serial: '' }], 'Seasonal Fee'), { isSeasonalFee: true }));
    if (sub.productKey === 'vtu-ffc') list.push(mk('AI Dashcam Forward Facing Video Subscription', 'ffc', [{ category: 'Companion', label: 'AI Dashcam Road NA 64-3w', serial: serial('cam') }], 'Forward Facing Camera Subscription'));
    if (sub.productKey === 'vtu-dual') list.push(mk('AI Dashcam Dual Facing Video Subscription', 'dual', [{ category: 'Companion', label: 'AI Dashcam Dual NA 64-3w', serial: serial('cam') }], 'Dual Camera Subscription'));
  }
  // LogBook has no hardware and no serial (Leo, 2026-10-14). Extended View Cameras keep their serial (cameras do);
  // the In-Cab Monitor has none.
  const featureHw = { evc: 'Extended View Camera', monitor: 'In-Cab Monitor' };
  (sub.features || []).forEach(k => {
    const label = `${({ logbook: 'LogBook' })[k] || featureLabels[k] || k} Subscription`;
    list.push(mk(label, 'f-' + k, featureHw[k] ? [{ category: 'Feature – Accessory', label: featureHw[k], serial: k === 'evc' ? serial(k) : '' }] : [{ category: 'Feature', label: '--', serial: '' }], featureLabels[k] || k));
  });
  // Monthly price share of each subscription (Partial Cancellation): the vehicle's rate split by list price.
  const sources = vzGetSourceBundlesForPreview() || [];
  const bundle = (sub.bundleId != null && sources.find(b => b.id === sub.bundleId)) || sources.find(b => b.coreKey === sub.productKey);
  const comps = bundle && typeof getOrderPromotionComponents === 'function' ? getOrderPromotionComponents(bundle) : [];
  const totalList = comps.reduce((sum, c) => sum + (Number(c.listUnit) || 0), 0);
  list.forEach((sb, i) => {
    const comp = comps.find(c => c.name === sb.comp);
    sb.rate = totalList > 0 && comp ? sub.rate * (comp.listUnit / totalList) : (i === 0 ? sub.rate : 0);
  });
  const feeLine = list.find(sb => sb.isSeasonalFee);
  if (feeLine) feeLine.rate = list[0].rate * (SEASONAL_PREMIUM_PCT / 100);
  return list;
}

// Per-table behaviour: Upsell selects vehicles; Cancellation and Reactivation (its mirror, 2026-10-14 per Catalina)
// select subscriptions, each with its own rate (negative for Cancellation, positive for Reactivation).
const VZ_PICK_TABLES = {
  cancel: { cb: 'gc-cancel-cb', hdr: 'gc-cancel-vehicle-hdr', toggle: 'vzToggleCancelVehicle', sync: 'vzSyncCancelVehicleHdr', count: 'vzUpdateCancelCount', verb: 'Cancel', sign: '-', rateClass: 'vz-vtable__neg', second: 'Remain' },
  reactivation: { cb: 'gc-reactivation-cb', hdr: 'gc-reactivation-vehicle-hdr', toggle: 'vzToggleReactivationVehicle', sync: 'vzSyncReactivationVehicleHdr', count: 'vzUpdateReactivationCount', verb: 'Reactivate', sign: '+', rateClass: 'vz-vtable__pos', second: 'Deactivated' },
};

function vzVehicleBlocksHtml(records, table, preSelected) {
  const pick = VZ_PICK_TABLES[table] || null;
  const isCancel = !!pick;
  const colCount = isCancel ? 6 : 4;
  const subhead = `<tr class="vz-vtable__subhead"><td colspan="2" class="vz-vtable__sub-first">Subscription</td><td class="vz-vtable__fit">Category</td><td>Hardware</td>${isCancel ? `<td class="vz-vtable__fit">Rate / mo</td><td class="vz-vtable__fit">${pick.second}</td>` : ''}</tr>`;
  return vzSortVehicleRecords(records).map(r => {
    const s = r.sub;
    const checked = preSelected.includes(s.id) ? 'checked' : '';
    const groupKey = s.productKey;
    // 2026-11-04 (Migrations): the 'migration' table is read only — no checkboxes, no row click.
    const readOnly = table === 'migration';
    // 'migration-select': pick vehicles with service to add to a migration option (checked by default).
    const migSelect = table === 'migration-select';
    const summaryCheck = readOnly ? '' : migSelect
      ? `<input type="checkbox" class="gc-migsel-cb checkbox__input" value="${s.id}" checked onchange="migrationSelectChanged()" aria-label="Select ${r.name || s.product}">`
      : isCancel
      ? `<input type="checkbox" class="${pick.hdr} checkbox__input" data-serial="${s.serial}" ${checked} onchange="${pick.toggle}('${s.serial}', this.checked)" aria-label="Select ${r.name || s.product}">`
      : `<input type="checkbox" class="gc-upsell-vehicle-cb checkbox__input" value="${s.id}" data-group="${groupKey}" ${checked} onchange="vzUpdateUpsellCount()" aria-label="Select ${r.name || s.product}">`;
    const rowClick = readOnly ? '' : migSelect ? `var cb=this.querySelector('.gc-migsel-cb'); cb.checked=!cb.checked; migrationSelectChanged();` : isCancel ? `${pick.toggle}('${s.serial}')` : `var cb=this.querySelector('.gc-upsell-vehicle-cb'); cb.checked=!cb.checked; vzUpdateUpsellCount();`;
    const subs = vzVehicleSubscriptions(r);
    const lines = subs.map((sb, si) => {
      const span = sb.hardware.length;
      // 2026-10-14 (Weekly, Leo: "en partial cancellation debes poder cancelar la suscripción"): one checkbox per
      // subscription. Vehicle Tracking keeps the vehicle's id (cancelling it = the vehicle); the others get their own.
      const cbValue = si === 0 ? s.id : `${s.id}::${sb.key}`;
      const cbChecked = preSelected.includes(cbValue) ? 'checked' : '';
      const cancelCheck = isCancel
        ? `<input type="checkbox" class="${pick.cb} checkbox__input" data-serial="${s.serial}" data-group="${groupKey}" data-product="${sb.name}" data-corekey="${s.productKey}" value="${cbValue}" data-rate="${sb.rate.toFixed(4)}" data-remain="${s.remainMonths}" ${cbChecked}${sb.isSeasonalFee ? ' disabled title="Billed with Vehicle Tracking — it can\'t be cancelled on its own"' : ''} onchange="${table === 'reactivation' ? 'vzReactivationCoreRule(this); ' : 'vzCancelCoreRule(this); '}${pick.count}(); ${pick.sync}('${s.serial}')" aria-label="${pick.verb} ${sb.name}">`
        : '';
      const subCell = `<td colspan="2" rowspan="${span}" class="vz-vtable__sub-first"><div class="vz-vtable__sub-name">${cancelCheck}<div>
          <div>${sb.name}</div>
          <div><span class="vz-vtable__label">Tech Ref ID:</span> ${sb.techRef}</div>
        </div></div></td>`;
      const money = isCancel
        ? `<td class="vz-vtable__num ${pick.rateClass}">${pick.sign}${formatMoney(sb.rate)}</td><td class="vz-vtable__num">${table === 'reactivation' ? vzFmtDate(s.deactivatedDate) : `${s.remainMonths} mo`}</td>`
        : '';
      // 2026-10-14 (per Catalina): no rowspan on Rate / Remain — every hardware row has the same cells, so the
      // Hardware column keeps its right border on every row.
      const contMoney = isCancel ? '<td class="vz-vtable__num"></td><td class="vz-vtable__num"></td>' : '';
      return sb.hardware.map((hw, hi) => {
        const hwCell = hw.label === '--' ? '--' : `<div>${hw.label}</div>${hw.serial ? `<div class="vz-vtable__muted">${hw.serial}</div>` : ''}`;
        const cells = `<td class="vz-vtable__fit">${hw.category}</td><td>${hwCell}</td>`;
        return hi === 0
          ? `<tr class="vz-vtable__sub vz-vtable__sub--start">${subCell}${cells}${money}</tr>`
          : `<tr class="vz-vtable__sub vz-vtable__sub--cont">${cells}${contMoney}</tr>`;
      }).join('');
    }).join('');
    const searchText = [vzVehicleTitle(r), r.vin, r.name, r.plate, r.make, r.model].filter(Boolean).join(' ').toLowerCase();
    const vk = `data-vkey="${s.serial}"`;
    return `<tr class="vz-vtable__vehicle" ${vk} data-search="${searchText.replace(/"/g, '&quot;')}" data-status="${r.status}" data-product="${s.product}" onclick="${rowClick}">
        ${readOnly ? '' : `<td class="vz-vtable__check" onclick="event.stopPropagation();">${summaryCheck}</td>`}
        <td colspan="${readOnly ? colCount : colCount - 1}">${vzVehicleSummaryHtml(r)}</td>
      </tr>${subhead.replace('<tr ', `<tr ${vk} `)}${lines.replace(/<tr class="vz-vtable__sub/g, `<tr ${vk} class="vz-vtable__sub`)}`;
  }).join('');
}

function vzCoreSectionsHtml(records, table, preSelected) {
  const isCancel = table === 'cancel';
  const colCount = isCancel ? 9 : 7;
  const dash = '--';
  return vzGroupVehicleRecords(records).map(group => {
    const noun = group.isAsset ? (group.items.length === 1 ? 'asset' : 'assets') : (group.items.length === 1 ? 'vehicle' : 'vehicles');
    const groupToggle = isCancel ? `vzToggleCancelGroup('${group.key}', this.checked)` : `vzToggleUpsellGroup('${group.key}', this.checked)`;
    const header = `<tr class="vz-vtable__group">
      <td class="vz-vtable__check"><input type="checkbox" class="checkbox__input" onchange="${groupToggle}" aria-label="Select all ${group.label}"></td>
      <td colspan="${colCount - 1}"><span class="vz-vtable__strong">${group.label}</span> <span class="badge badge--stone">${group.items.length} ${noun}</span></td>
    </tr>
    <tr class="vz-vtable__subhead"><td class="vz-vtable__check"></td><td>Vehicle / Asset</td><td class="vz-vtable__fit">Name</td><td class="vz-vtable__fit">License plate</td><td class="vz-vtable__fit">Status</td><td class="vz-vtable__fit">Order</td><td>Features</td>${isCancel ? '<td>Rate / mo</td><td>Remain</td>' : ''}</tr>`;
    const rows = vzSortVehicleRecords(group.items).map(r => {
      const s = r.sub;
      const checked = preSelected.includes(s.id) ? 'checked' : '';
      const check = isCancel
        ? `<input type="checkbox" class="gc-cancel-cb checkbox__input" data-serial="${s.serial}" data-group="${group.key}" data-product="${s.product}" data-corekey="${s.productKey}" value="${s.id}" data-rate="${s.rate}" data-remain="${s.remainMonths}" ${checked} onchange="vzUpdateCancelCount()" aria-label="Cancel ${s.product}">`
        : `<input type="checkbox" class="gc-upsell-vehicle-cb checkbox__input" value="${s.id}" data-group="${group.key}" ${checked} onchange="vzUpdateUpsellCount()" aria-label="Select ${r.name || s.product}">`;
      const cbClass = isCancel ? '.gc-cancel-cb' : '.gc-upsell-vehicle-cb';
      const after = isCancel ? 'vzUpdateCancelCount();' : 'vzUpdateUpsellCount();';
      const features = [...(vzIsSeasonalVehicle(s) ? ['Seasonal Fee'] : []), ...(s.features || []).map(k => featureLabels[k] || k)].join(', ');
      return `<tr class="vz-vtable__row" onclick="var cb=this.querySelector('${cbClass}'); cb.checked=!cb.checked; ${after}">
        <td class="vz-vtable__check" onclick="event.stopPropagation();">${check}</td>
        <td><div class="vz-vtable__vehicle-cell">${vzVehicleIconHtml(r)}<div><div class="vz-vtable__strong">${r.assigned ? vzVehicleTitle(r) : dash}</div>${r.vin ? `<div class="vz-vtable__vin">${r.vin}</div>` : ''}</div></div></td>
        <td class="vz-vtable__fit vz-vtable__name-cell" title="${r.name || ''}">${r.name || dash}</td><td class="vz-vtable__fit">${r.plate || dash}</td><td class="vz-vtable__fit">${vzStatusBadgeHtml(r)}</td><td class="vz-vtable__fit">${r.order || dash}</td>
        <td class="vz-vtable__muted">${features || dash}</td>
        ${isCancel ? `<td class="vz-vtable__num vz-vtable__neg">-${formatMoney(s.rate)}</td><td class="vz-vtable__num">${s.remainMonths} mo</td>` : ''}
      </tr>`;
    }).join('');
    return header + rows;
  }).join('');
}

function vzGroupVehicleRecords(records) {
  const groups = [];
  records.forEach(r => {
    let g = groups.find(x => x.key === r.sub.productKey);
    if (!g) { g = { key: r.sub.productKey, label: r.sub.product, isAsset: r.isAsset, items: [] }; groups.push(g); }
    g.items.push(r);
  });
  return groups;
}

function vzRenderUpsellTable() {
  const thead = document.getElementById('gc-upsell-thead');
  const tbody = document.getElementById('gc-upsell-tbody');
  if (!thead || !tbody) return;
  const sourceBundles = vzGetSourceBundlesForPreview();
  let subs = vzApplySubFilter(vzGenerateSubscriptions().filter(s => s.isCore && !vzIsAssetCore(s.productKey)));
  if (upsellMode === 'features' && vzUpsellFeatureFilterKeys.length) {
    const addsCamera = vzUpsellFeatureFilterKeys.includes('ffc');
    const needsCamera = !addsCamera && vzUpsellFeatureFilterKeys.some(k => VZ_UPSELL_CAMERA_EXTRAS.includes(k));
    subs = subs.filter(s => {
      const has = vzSubHasUpsellFeatures(s, sourceBundles);
      if (needsCamera && !has.has('ffc')) return false;
      return vzUpsellFeatureFilterKeys.some(k => !has.has(k));
    });
  }
  const records = subs.map(vzVehicleRecord);
  thead.innerHTML = vzVehicleTableHeadHtml('upsell', vzVehicleTableView.upsell === 'core' ? 7 : 4);
  if (!records.length) {
    tbody.innerHTML = `<tr><td colspan="7" class="vz-vtable__empty">No vehicles without the selected features.</td></tr>`;
    vzUpdateUpsellCount();
    return;
  }
  tbody.innerHTML = vzVehicleTableView.upsell === 'core'
    ? vzCoreSectionsHtml(records, 'upsell', vzUpsellPreSelected)
    : vzVehicleBlocksHtml(records, 'upsell', vzUpsellPreSelected);
  vzUpdateUpsellCount();
  vzInitVehicleSearch('upsell');
}

function vzRenderCancelTable() {
  const thead = document.getElementById('gc-cancel-thead');
  const tbody = document.getElementById('gc-cancel-tbody');
  if (!thead || !tbody) return;
  // A vehicle that already has a pending Upsell in this option can't also be cancelled (per Catalina).
  const alreadyUpsoldIds = vzGetAlreadyUpsoldSubIds();
  const records = vzGenerateSubscriptions().filter(s => s.isCore && !alreadyUpsoldIds.has(s.id)).map(vzVehicleRecord);
  const preSelected = window._vzCancelPreSelected || [];
  thead.innerHTML = vzVehicleTableHeadHtml('cancel', vzVehicleTableView.cancel === 'core' ? 9 : 6);
  tbody.innerHTML = vzVehicleTableView.cancel === 'core'
    ? vzCoreSectionsHtml(records, 'cancel', preSelected)
    : vzVehicleBlocksHtml(records, 'cancel', preSelected);
  document.querySelectorAll('.gc-cancel-vehicle-hdr').forEach(h => vzSyncCancelVehicleHdr(h.dataset.serial));
  vzUpdateCancelCount();
  vzInitVehicleSearch('cancel');
}

function vzToggleUpsellGroup(groupKey, checked) {
  document.querySelectorAll(`.gc-upsell-vehicle-cb[data-group="${groupKey}"]`)
    .forEach(cb => cb.checked = checked);
  vzUpdateUpsellCount();
}

function vzSetUpsellStep(showStep2) {
  const step1 = document.getElementById('gc-tx-upsell-step1');
  const step2 = document.getElementById('gc-tx-upsell-step2');
  if (!step1 || !step2) return;

  step1.classList.toggle('active', !showStep2);
  step2.classList.toggle('active', showStep2);
  step1.style.display = showStep2 ? 'none' : 'block';
  step2.style.display = showStep2 ? 'block' : 'none';
  vzSyncUpsellModeToggle();
}

function vzGoUpsellStep1() {
  vzSetUpsellStep(false);
  // Back to step 1: restore the forward button matching the current mode
  // (Choose features when picking vehicles first, Select vehicles when
  // picking features first) and restore Cancel as the footer's left action.
  if (upsellMode === 'vehicles') {
    setVZTxFooter(`
      <button class="btn btn--primary btn--large" id="gc-upsell-next-btn" onclick="vzGoUpsellStep2()" style="flex:none; padding:10px 24px; font-size:14px; gap:8px;">Choose features</button>
    `);
  } else {
    setVZTxFooter(`
      <button class="btn btn--primary btn--large" onclick="vzGoUpsellStep2()" style="flex:none; padding:10px 24px; font-size:14px; gap:8px;">Select vehicles</button>
    `);
  }
  const cancelBackBtn = document.getElementById('gc-tx-cancel-back-btn');
  if (cancelBackBtn) { cancelBackBtn.textContent = 'Cancel'; cancelBackBtn.onclick = closeBundleModal; }
  // Re-evaluate count in case vehicles are already selected
  vzUpdateUpsellCount();
}

function vzGoUpsellStep2() {
  const body = document.getElementById('gc-upsell-step2-body');
  if (!body) return;

  if (upsellMode === 'vehicles') {
    const selectedSubIds = [...document.querySelectorAll('.gc-upsell-vehicle-cb:checked')].map(cb => cb.value);
    const count = selectedSubIds.length;
    if (!count) {
      showToast('Tip: choose one or more vehicles before adding the upsell.');
      return;
    }
    // 2026-11-11 (per Catalina): only features that NONE of the selected vehicles has (or can't take) are offered.
    const alreadyHasKeys = vzGetUpsellAlreadyHasFeatureKeys(selectedSubIds);
    // 2026-10-20 (per Catalina): no "N vehicles selected" line on the Features step.
    const offered = VZ_UPSELL_FEATURES.some(f => !alreadyHasKeys.has(f.key));
    body.innerHTML = offered ? vzUpsellFeaturesHtml(alreadyHasKeys, count)
      : '<div class="notification notification--info" role="status"><div class="notification__body"><div class="notification__message">The selected vehicles have no features in common to add. Change the selection.</div></div></div>';
    vzSyncUpsellFeatures();
  } else {
    const selFeatures = document.querySelectorAll('.gc-upsell-feature-cb:checked').length;
    if (!selFeatures) { showToast('Select at least one feature'); return; }
    // Feature-first: list only the vehicles that don't have the chosen features yet.
    vzUpsellFeatureFilterKeys = [...document.querySelectorAll('.gc-upsell-feature-cb:checked')].map(cb => cb.value);
    // 2026-10-14 (per Catalina): no "Select Vehicles" title or filter note — the table alone.
    // 2026-10-20 (per Catalina): no "Vehicles without …" line — the table alone.
    body.innerHTML = vzVehicleTableShellHtml('upsell');
    vzRenderUpsellTable();
  }

  vzSetUpsellStep(true);
  vzUpdateUpsellPreview();
  setVZTxFooter(`
    <button class="btn btn--primary btn--large" id="gc-upsell-add-btn" style="flex:none; padding:10px 24px; font-size:14px;">Add Upsell</button>
  `);
  // Step 2 of 2: swap the footer's left action from Cancel to Back so the
  // step-1 selections aren't lost \u2014 the top-right "X" remains the only
  // full-abandon control.
  const cancelBackBtn = document.getElementById('gc-tx-cancel-back-btn');
  if (cancelBackBtn) { cancelBackBtn.textContent = 'Back'; cancelBackBtn.onclick = vzGoUpsellStep1; }
}

// ── Feature Upsell: features view (2026-10-20, per Catalina) ────────────────────────────────────────────
// Standard = the Configure Solution view (accordions, VC.featuresPicker) with its rules: EVC → EVC Layout + In-Cab
// Monitor, SD Card Storage 128 / 256, Driver ID → Keyfobs (3 per vehicle included, extras one-time). Upsell rules:
// Driver Facing Camera, ADAS / EVC / Monitor / SD need the forward camera (the vehicles have it, or FFC is added in
// the same upsell — per Leo, Dual = FFC + driver facing camera); what every selected vehicle already has is hidden.
// In "By feature" the key fobs total follows the vehicles chosen next. The old cards stay as a simulation (Simulation
// Builder › Demo simulations › Feature Upsell view).
var upsellFeaturesViewSim = 'accordion';
// Key fobs: the user's adjustment over the included ones (3 × vehicles), as in Expansion when the quantity changes —
// so in "By feature" the stepper works before the vehicles are chosen and the total follows them.
let vzUpsellKeyfobDelta = 0;
let vzUpsellEvcType = 'sides-rear-cargo';
let vzUpsellVehicleCount = 0;     // vehicles selected before the features step (0 in "By feature")
let vzUpsellCameraOnVehicles = false;
const VZ_EVC_LAYOUTS = [['sides-rear-cargo', 'Sides, Rear & Cargo'], ['sides', 'Sides'], ['sides-rear', 'Sides & Rear'], ['rear-cargo', 'Rear and Cargo']];
const VZ_UPSELL_CAMERA_EXTRAS = ['evc', 'monitor', 'adas', 'sd'];
function vzUpsellFeature(key) { return VZ_UPSELL_FEATURES.find(f => f.key === key); }
function vzUpsellFeaturesHtml(alreadyHas, vehicleCount) {
  vzUpsellVehicleCount = vehicleCount || 0;
  vzUpsellCameraOnVehicles = !vzUpsellVehicleCount || alreadyHas.has('ffc');
  return upsellFeaturesViewSim === 'cards' ? vzUpsellFeatureCardsHtml(alreadyHas) : vzUpsellFeatureAccordionsHtml(alreadyHas);
}
function vzUpsellFeatureCardsHtml(alreadyHas) {
  return ['video', 'vehicle', 'software'].map(cat => {
    const catFeatures = VZ_UPSELL_FEATURES.filter(f => f.category === cat && !alreadyHas.has(f.key));
    if (!catFeatures.length) return '';
    return `<div class="vz-upsell-cat">
      <div class="vz-upsell-cat__label">${cat === 'video' ? 'Video Features' : cat === 'software' ? 'Software Features' : 'Vehicle Features'}</div>
      <div class="vc-select-box-group vc-select-box-group--cols-2">
        ${catFeatures.map(f => VC.selectBox({ type: 'checkbox', name: 'gc-upsell-features', value: f.key, title: f.label, subtitleHtml: `+${formatMoney(f.price)}/unit/mo`, onChange: 'vzUpdateUpsellPreview()', attrs: { class: 'gc-upsell-feature-cb', 'data-price': f.price } })).join('')}
      </div>
    </div>`;
  }).join('');
}
function vzUpsellFeatureAccordionsHtml(alreadyHas) {
  const row = (key, extra = {}) => {
    const f = vzUpsellFeature(key);
    if (!f || alreadyHas.has(key)) return '';
    return VC.featureCheckRow({ id: `gc-upsell-f-${key}`, rowId: `gc-upsell-row-${key}`, value: key, label: `${f.label} (+${formatMoney(f.price)})`,
      className: 'gc-upsell-feature-cb', attrs: { 'data-price': f.price }, onChange: 'vzOnUpsellFeatureChange(this)', ...extra });
  };
  const monitorRow = row('monitor');
  const layout = `<div class="vc-field-label">EVC Layout</div>
    <select class="select" id="gc-upsell-evc-type" data-vc-dropdown onchange="vzUpsellEvcType=this.value; vzUpdateUpsellPreview()">
      ${VZ_EVC_LAYOUTS.map(([v, l]) => `<option value="${v}"${v === vzUpsellEvcType ? ' selected' : ''}>${l}</option>`).join('')}
    </select>`;
  const keyfobs = `<div class="keyfob-section-block">
        <div class="keyfob-label">Keyfobs</div>
        <div class="input-stepper input-stepper--small">
          <button type="button" class="input-stepper__btn" onclick="vzChangeUpsellKeyfobs(-1)" aria-label="Decrease"><span class="material-symbols-outlined">remove</span></button>
          <input class="input-stepper__value" id="gc-upsell-keyfob-qty" type="number" min="0" max="999" step="1" value="${vzReadUpsellKeyfobs()}" oninput="vzSetUpsellKeyfobs(this.value)" aria-label="Keyfobs">
          <button type="button" class="input-stepper__btn" onclick="vzChangeUpsellKeyfobs(1)" aria-label="Increase"><span class="material-symbols-outlined">add</span></button>
        </div>
        <div id="gc-upsell-keyfob-note" class="notification notification--info keyfob-note" role="status"></div>
      </div>`;
  const sd = alreadyHas.has('sd') ? '' : VC.featureRadioRow({ rowId: 'gc-upsell-row-sd', title: 'SD Card Storage', name: 'gc-upsell-sd', onChange: 'vzOnUpsellFeatureChange(this)', options: [
    { id: 'gc-upsell-sd-128', value: '128', label: '128 GB', checked: true },
    { id: 'gc-upsell-f-sd', value: 'sd', label: `256 GB (+${formatMoney(vzUpsellFeature('sd').price)})`, className: 'gc-upsell-feature-cb', counts: true, attrs: { 'data-price': vzUpsellFeature('sd').price } },
  ] });
  const evc = row('evc', { nestedId: 'gc-upsell-evc-options', nestedHtml: layout + monitorRow });
  return VC.featuresPicker({ groups: [
    { id: 'gc-upsell-acc-video', title: 'Video Features', itemsHtml: vzUpsellCameraFieldHtml(alreadyHas) + (evc || monitorRow) + sd + row('adas') },
    { id: 'gc-upsell-acc-vehicle', title: 'Vehicle Features', itemsHtml: row('eld') + row('driverid', { nestedHtml: keyfobs }) + row('privacy') + row('logbook') },
    { id: 'gc-upsell-acc-software', title: 'Software Features', itemsHtml: row('navigation') + row('rsa') + row('dvir') },
  ] });
}
// 2026-10-21 (per Catalina, after Leo: FFC and Dual are the same camera, Dual adds a driver facing camera): one
// "Camera" dropdown picks the camera level the vehicles end on — like the core dropdown in Configure Solution.
// Options depend on what the selected vehicles have: none or a mix → "Select..." / Forward Facing Camera (+$30) /
// Dual Camera (+$40); all with FFC → Forward Facing Camera (current) / Dual Camera (+$10); all with Dual → no field. Behind it, two hidden feature inputs (ffc, dual = driver facing camera) keep the
// pricing / summary / save logic of the other features.
// 2026-11-05 (Existing Business follow-up, Leo via Mayank): a vehicle that already has a camera doesn't get another
// one — no Camera field when every selected vehicle has one (no "current" / Dual upgrade); the EVC stays available.
// With a mix, the camera only goes to the vehicles without one.
function vzUpsellCameraFieldHtml(alreadyHas) {
  if (alreadyHas.has('dual') || alreadyHas.has('ffc')) return '';
  const ffc = vzUpsellFeature('ffc'), dfc = vzUpsellFeature('dual');
  const allFfc = alreadyHas.has('ffc');
  const selectedIds = [...document.querySelectorAll('.gc-upsell-vehicle-cb:checked')].map(cb => cb.value);
  const opts = allFfc
    ? [['', 'Forward Facing Camera (current)'], ['dual', `Dual Camera (+${formatMoney(dfc.price)})`]]
    : [['', 'Select...'], ['ffc', `Forward Facing Camera (+${formatMoney(ffc.price)})`], ['dual', `Dual Camera (+${formatMoney(ffc.price + dfc.price)})`]];
  const hidden = (key, f) => `<input type="checkbox" class="gc-upsell-feature-cb hidden" id="gc-upsell-f-${key}" value="${key}" data-price="${f.price}" tabindex="-1" aria-hidden="true">`;
  return `<div class="vc-feature-row vz-upsell-camera" id="gc-upsell-row-camera">
      <div class="vc-field-label">Camera</div>
      <select class="select" id="gc-upsell-camera" data-vc-dropdown onchange="vzSetUpsellCamera(this.value)">
        ${opts.map(([v, l]) => `<option value="${v}">${l}</option>`).join('')}
      </select>
      ${allFfc ? '' : hidden('ffc', ffc)}${hidden('dual', dfc)}
      <input type="checkbox" class="hidden" id="gc-upsell-camera-count" data-fp-count tabindex="-1" aria-hidden="true">
    </div>`;
}
function vzSetUpsellCamera(value) {
  const ffcBox = document.getElementById('gc-upsell-f-ffc');
  const dfcBox = document.getElementById('gc-upsell-f-dual');
  if (ffcBox) ffcBox.checked = value === 'ffc' || value === 'dual';
  if (dfcBox) dfcBox.checked = value === 'dual';
  vzSyncUpsellFeatures();
}
function vzOnUpsellFeatureChange(input) {
  vzSyncUpsellFeatures();
}
function vzSyncUpsellFeatures() {
  const root = document.querySelector('#gc-tx-form-area .vc-features-picker');
  if (!root) return;
  const checked = key => !!document.getElementById(`gc-upsell-f-${key}`)?.checked;
  // The Camera dropdown mirrors the hidden ffc / dual inputs (also when an upsell is reopened for editing).
  const camSel = document.getElementById('gc-upsell-camera');
  if (camSel) {
    const level = checked('dual') ? 'dual' : checked('ffc') ? 'ffc' : '';
    if (camSel.value !== level) { camSel.value = level; camSel.__vcDropdown?.refresh?.(); }
    const count = document.getElementById('gc-upsell-camera-count');
    if (count) count.checked = !!level;
  }
  // Video extras need a camera: on the vehicles already, or added in this upsell.
  const camera = vzUpsellCameraOnVehicles || checked('ffc');
  VZ_UPSELL_CAMERA_EXTRAS.forEach(key => {
    const rowEl = document.getElementById(`gc-upsell-row-${key}`);
    if (!rowEl) return;
    rowEl.classList.toggle('hidden', !camera);
    if (!camera) {
      rowEl.querySelectorAll('input').forEach(i => { i.checked = i.value === '128'; });
    }
  });
  // In-Cab Monitor lives inside EVC: unchecking EVC unchecks it and resets the layout.
  const evcBox = document.getElementById('gc-upsell-f-evc');
  if (evcBox && !evcBox.checked) {
    const mon = document.querySelector('#gc-upsell-evc-options #gc-upsell-f-monitor');
    if (mon) mon.checked = false;
    vzUpsellEvcType = 'sides-rear-cargo';
    const sel = document.getElementById('gc-upsell-evc-type');
    if (sel) { sel.value = vzUpsellEvcType; sel.__vcDropdown?.refresh?.(); }
  }
  // Keyfobs: order total, 3 per vehicle included, extras one-time. Without vehicles yet ("By feature"), the note says
  // the included ones follow the vehicles.
  const note = document.getElementById('gc-upsell-keyfob-note');
  if (note) {
    const n = vzUpsellKeyfobVehicles();
    const included = KEYFOBS_INCLUDED * n;
    const extra = Math.max(0, vzReadUpsellKeyfobs() - included);
    const head = n ? `First ${included} free (${KEYFOBS_INCLUDED} per vehicle)` : `${KEYFOBS_INCLUDED} free per vehicle`;
    note.innerHTML = `<span class="material-symbols-outlined notification__icon" aria-hidden="true">info</span><div class="notification__body"><div class="notification__message">${head}` +
      (extra ? ` + ${extra} extra = <strong>${formatMoney(extra * KEYFOB_EXTRA_PRICE)} one-time</strong>` : '') + `</div></div>`;
    const input = document.getElementById('gc-upsell-keyfob-qty');
    if (input && document.activeElement !== input) input.value = vzReadUpsellKeyfobs();
  }
  VC.featuresPickerSync(root);
  vzUpdateUpsellPreview();
}
// Vehicles the key fobs are counted on: chosen before the features (By vehicle) or selected so far (By feature).
function vzUpsellKeyfobVehicles() {
  return vzUpsellVehicleCount || document.querySelectorAll('.gc-upsell-vehicle-cb:checked').length;
}
function vzReadUpsellKeyfobs(vehicles = vzUpsellKeyfobVehicles()) {
  return Math.max(0, KEYFOBS_INCLUDED * vehicles + vzUpsellKeyfobDelta);
}
function vzSetUpsellKeyfobs(raw) {
  const n = parseInt(raw, 10);
  if (!Number.isNaN(n)) vzUpsellKeyfobDelta = Math.max(0, n) - KEYFOBS_INCLUDED * vzUpsellKeyfobVehicles();
  vzSyncUpsellFeatures();
}
function vzChangeUpsellKeyfobs(delta) {
  const total = Math.max(0, vzReadUpsellKeyfobs() + delta);
  vzUpsellKeyfobDelta = total - KEYFOBS_INCLUDED * vzUpsellKeyfobVehicles();
  const input = document.getElementById('gc-upsell-keyfob-qty');
  if (input) input.value = total;
  vzSyncUpsellFeatures();
}
// Key fobs saved with the upsell: included for the vehicles + the user's adjustment.
function vzUpsellKeyfobQtyForSave(featureKeys, vehicles) {
  if (!featureKeys.includes('driverid')) return undefined;
  return vzReadUpsellKeyfobs(vehicles);
}

function vzGetUpsellAlreadyHasFeatureKeys(selectedSubIds) {
  if (!selectedSubIds.length) return new Set();
  const allSubs = vzGenerateSubscriptions();
  const sourceBundles = vzGetSourceBundlesForPreview();
  let result = null;
  selectedSubIds.forEach((id) => {
    const sub = allSubs.find((s) => s.id === id);
    if (!sub) return;
    const sourceBundle = sourceBundles.find((b) => b.id === sub.bundleId);
    const currentFeatures = Array.isArray(sourceBundle?.features) ? sourceBundle.features : (Array.isArray(sub.features) ? sub.features : []);
    const has = new Set();
    VZ_UPSELL_FEATURES.forEach((f) => {
      const aliasCore = VZ_UPSELL_CORE_ALIAS[f.key];
      if (aliasCore) {
        if ((VZ_UPSELL_CORE_RANK[sub.productKey] || 0) >= (VZ_UPSELL_CORE_RANK[aliasCore] || 0)) has.add(f.key);
      } else {
        const catalogKey = VZ_UPSELL_FEATURE_TO_CATALOG_KEY[f.key] || f.key;
        if (currentFeatures.includes(catalogKey)) has.add(f.key);
      }
    });
    vzPendingUpsellKeys(id).forEach(k => has.add(k));
    // An asset (powered / non-powered) can't take vehicle or video features — counts as "not available" for the selection.
    if (vzIsAssetCore(sub.productKey)) VZ_UPSELL_FEATURES.forEach(f => { if (f.category !== 'software') has.add(f.key); });
    // 2026-11-11 (per Catalina): a feature is offered only when NONE of the selected vehicles has it (or can't take it),
    // so it applies to every selected vehicle the same way — no mixed selections where it's added to some only
    // (replaces the 10-21 "hidden only when ALL have it" rule; Mayank's Select all scenarios change).
    result = result === null ? has : new Set([...result, ...has]);
  });
  return result || new Set();
}

function vzGetSourceBundlesForPreview() {
  const opt = bld.targetOptId ? options.find(o => o.id === bld.targetOptId) : null;
  return proposalData.entryPoint === 'renewalRewrap'
    ? (opt ? (opt.bundles || []).filter(bundle => bundle.originalQty !== undefined) : [])
    : (Array.isArray(existingOrders) ? existingOrders : []).flatMap(order => order.bundles || []);
}

function vzResolveUpsellTarget(sub, checkedFeatureKeys, sourceBundles) {
  const sourceBundle = sourceBundles.find(b => b.id === sub.bundleId);
  let targetCore = sub.productKey;
  checkedFeatureKeys.forEach((key) => {
    const aliasCore = VZ_UPSELL_CORE_ALIAS[key];
    if (aliasCore && (VZ_UPSELL_CORE_RANK[aliasCore] || 0) > (VZ_UPSELL_CORE_RANK[targetCore] || 0)) {
      targetCore = aliasCore;
    }
  });
  const currentFeatures = Array.isArray(sourceBundle?.features) ? sourceBundle.features : [];
  const addedFeatureKeys = checkedFeatureKeys
    .filter((key) => !VZ_UPSELL_CORE_ALIAS[key])
    .map((key) => VZ_UPSELL_FEATURE_TO_CATALOG_KEY[key] || key);
  const targetFeatures = Array.from(new Set([...currentFeatures, ...addedFeatureKeys]));
  return { targetCore, targetFeatures, addedFeatureKeys };
}

function vzGetUpsellPlanGroups(checkedFeatureKeys, selectedSubIds) {
  if (!checkedFeatureKeys.length || !selectedSubIds.length) return [];
  const allSubs = vzGenerateSubscriptions();
  const sourceBundles = vzGetSourceBundlesForPreview();
  const groups = new Map();
  selectedSubIds.forEach((id) => {
    const sub = allSubs.find((s) => s.id === id);
    if (!sub) return;
    const { targetCore, targetFeatures, addedFeatureKeys } = vzResolveUpsellTarget(sub, checkedFeatureKeys, sourceBundles);
    const match = findClosestPrebuiltTier(targetCore, targetFeatures);
    if (!match) return;
    const groupKey = `${match.bundleKey}::${match.tier.key}`;
    if (!groups.has(groupKey)) {
      groups.set(groupKey, {
        label: `${match.bundle.name} \u2014 ${match.tier.label}`,
        coreLabel: corePricing[targetCore]?.name || targetCore,
        featureKeys: targetFeatures,
        addedFeatureKeys,
        count: 0,
      });
    }
    groups.get(groupKey).count += 1;
  });
  return [...groups.values()].sort((a, b) => b.count - a.count);
}

function vzRenderUpsellPlanGroupsHtml(groups) {
  if (!groups.length) return '';
  const cards = groups.map((g) => {
    const featuresHtml = g.featureKeys.map((k) => {
      const label = featureLabels[k] || k.toUpperCase();
      return g.addedFeatureKeys.includes(k)
        ? `<span class="upsell-plan-added-chip">${label} \u2014 added</span>`
        : label;
    }).join(', ');
    const icon = g.isPlan ? '<span class="material-symbols-outlined" style="font-size:14px;vertical-align:-2px;color:var(--gray-600);">trending_up</span> ' : '';
    return `<div class="upsell-plan-match-card">
      <div class="upsell-plan-match-title">${icon}${g.label} <span class="upsell-plan-match-count">\u00b7 ${g.count} ${g.count === 1 ? 'vehicle' : 'vehicles'}</span></div>
      <div class="upsell-plan-match-detail">${g.coreLabel}${featuresHtml ? ' \u00b7 ' + featuresHtml : ''}</div>
    </div>`;
  }).join('');
  return `<div class="upsell-plan-groups">${cards}</div>`;
}

// 2026-10-21 (per Catalina): each vehicle pays only what it doesn't have yet. With a mixed selection (e.g. Dual Camera
// on vehicles without a camera and on vehicles that already have FFC) the vehicles are grouped by what they add —
// 8 × $40.00 (FFC + driver facing camera) and 4 × $10.00 (driver facing camera only) — in the summary and when saved
// (one modification per group). Vehicles that already have everything chosen aren't charged.
function vzUpsellPriceGroups(features, selectedIds) {
  const keys = features.map(f => f.value);
  const price = k => Number(features.find(f => f.value === k)?.dataset.price || 0);
  const groups = new Map();
  selectedIds.forEach(id => {
    const has = vzGetUpsellAlreadyHasFeatureKeys([id]);
    // 2026-11-05: a vehicle with a camera gets no camera (no Dual upgrade either).
    const hasCamera = has.has('ffc') || has.has('dual');
    const add = keys.filter(k => !has.has(k) && !(hasCamera && (k === 'ffc' || k === 'dual')));
    if (!add.length) return;
    const sig = add.join('+');
    const g = groups.get(sig) || { keys: add, unit: add.reduce((s, k) => s + price(k), 0), ids: [] };
    g.ids.push(id);
    groups.set(sig, g);
  });
  return [...groups.values()];
}
function vzUpsellGroupLabel(keys) {
  if (keys.includes('dual')) return keys.includes('ffc') ? 'Dual Camera' : 'Dual Camera (upgrade from FFC)';
  if (keys.includes('ffc')) return 'Forward Facing Camera';
  return keys.map(k => vzProductLabels[k] || k).join(', ');
}
// 2026-10-21 (per Catalina): the Upsell Summary prices the groups exactly as the option card will once saved — the
// option's tier (frozen to the contract's committed units in "Create new proposal"), its term and its discount — so
// Contracted Price and Monthly match the card.
function vzUpsellCardPricing(groups) {
  const opt = bld.targetOptId ? options.find(o => o.id === bld.targetOptId) : null;
  const tmpBundles = groups.map((g, i) => ({ id: `vz-upsell-preview-${i}`, coreKey: 'transaction-upsell', coreName: '', basePrice: g.unit, baseCorePrice: g.unit, features: g.keys, qty: g.ids.length, isMsaAuxiliary: true, isolatedTransactionType: 'upsell', promoType: 'Standard', promoName: '' }));
  if (!opt) {
    return tmpBundles.map(b => { const p = calcBundle({ ...b, msaDiscountPct: vzUpsellDiscountPct }, 36, 'Standard', b.qty); return { contracted: p.unitPrice, monthly: p.unitPrice * b.qty }; });
  }
  const kept = opt.bundles.filter(b => b.id !== bld.targetBundleId);
  const tmp = { ...opt, bundles: [...kept, ...tmpBundles] };
  const promo = getOptionPromotion(tmp);
  const frozen = proposalData.entryPoint !== 'renewalRewrap';
  const totalUnits = tmp.bundles.reduce((sum, b) => sum + (b.qty || 0), 0);
  const naturalIdx = frozen ? getApplicableTierIndex(getContractCommittedUnits()) : getApplicableTierIndex(totalUnits);
  const forced = frozen ? -1 : (opt.forcedTierIndex !== undefined ? opt.forcedTierIndex : -1);
  const optTier = forced === -1 ? naturalIdx : Math.max(forced, naturalIdx);
  const { tierQty } = calcOption(tmp, promo, optTier);
  const tierTermPct = getTierTermDiscountPct(opt.term, tierQty);
  return tmpBundles.map(b => {
    const discountPct = getOptionDiscountPct(opt, b);
    const contracted = getStandardUnitPrice(b) * (1 - tierTermPct / 100) * (1 - discountPct / 100);
    const unit = calcBundle({ ...b, msaDiscountPct: discountPct }, opt.term, b.promoType || promo, tierQty).unitPrice;
    return { contracted, monthly: unit * b.qty };
  });
}
function vzUpdateUpsellPreview() {
  const pane = document.getElementById('gc-tx-preview-area');
  if (!pane) return;
  // 2026-11-05 (per Catalina): when an upsell is edited, the step on screen may not have the other half (features on
  // the vehicles step, vehicles on the features step) — the summary uses the upsell's saved choice for it.
  let features = [...document.querySelectorAll('.gc-upsell-feature-cb:checked')];
  if (!features.length && bld.targetBundleId && !document.querySelector('.gc-upsell-feature-cb')) {
    features = (vzUpsellPreSelectedFeatures || []).map(k => ({ value: k, dataset: { price: String(vzUpsellFeature(k)?.price || 0) } }));
  }
  let selectedIds = [...document.querySelectorAll('.gc-upsell-vehicle-cb:checked')].map(cb => cb.value);
  if (!selectedIds.length && bld.targetBundleId && !document.querySelector('.gc-upsell-vehicle-cb')) selectedIds = [...(vzUpsellPreSelected || [])];
  const groups = features.length ? vzUpsellPriceGroups(features, selectedIds) : [];
  const cardPrices = vzUpsellCardPricing(groups);
  const priced = groups.map((g, i) => ({ ...g, ...cardPrices[i] }));
  const vehicleCount = groups.length ? priced.reduce((n, g) => n + g.ids.length, 0) : selectedIds.length;
  const totalMRR = priced.reduce((s, g) => s + g.monthly, 0);
  const mixed = priced.length > 1;
  const single = priced.length === 1 ? priced[0] : null;
  // One group (or no vehicles yet): the features it adds, as before.
  const lineKeys = single ? single.keys : features.map(f => f.value);
  const perUnit = single ? single.unit : features.reduce((s, f) => s + parseFloat(f.dataset.price || 0), 0);
  const discountedPerUnit = single ? single.contracted : perUnit;
  const msaPriceLine = single && perUnit - discountedPerUnit > 0.005
    ? `<div class="preview-line" style="border-top:1px solid var(--gray-200);margin-top:4px;padding-top:6px;"><strong>Contracted Price</strong><strong>${formatMoney(discountedPerUnit)}</strong></div>`
    : '';

  // Plan detection (grouping selected vehicles by the True Bundle they'd land
  // on) is a Simulation Builder / Plan-mode concept only — per Catalina, Custom
  // mode never talks about plans, so this stays empty there.
  let planGroupsHtml = '';
  if (builderMode === 'plan') {
    const planGroups = vzGetUpsellPlanGroups(features.map((f) => f.value), selectedIds);
    planGroupsHtml = vzRenderUpsellPlanGroupsHtml(planGroups);
  }

  // 2026-10-14 (per Catalina): same header as the Expansion summary — "Upsell Summary" title, term badge, "$--/month".
  // That's the initial state; from the first selection the lines show, with "--" until they can be calculated.
  // QTY replaces "Vehicles selected".
  const dash = '--';
  const isPriced = vehicleCount > 0 && priced.length > 0;
  const headerHtml = `
    <div class="preview-label-row"><div class="preview-label preview-label--title">Upsell Summary</div>${vzBillingModelSwitchHtml()}</div>
    <div class="preview-price">$<span>${isPriced ? formatMoneyAmount(totalMRR) : dash}</span><span>/month</span></div>`;
  if (!selectedIds.length && !features.length) { pane.innerHTML = headerHtml; return; }
  const evcLabel = k => k === 'evc' && document.getElementById('gc-upsell-evc-type') ? ` (${(VZ_EVC_LAYOUTS.find(l => l[0] === vzUpsellEvcType) || [])[1] || ''})` : '';
  const priceOf = k => parseFloat(features.find(f => f.value === k)?.dataset.price || 0);
  const featureLines = mixed
    ? priced.map(g => `<div class="preview-line"><span>${vzUpsellGroupLabel(g.keys)}${g.keys.filter(k => k !== 'ffc' && k !== 'dual').length && (g.keys.includes('ffc') || g.keys.includes('dual')) ? ' + ' + g.keys.filter(k => k !== 'ffc' && k !== 'dual').map(k => vzProductLabels[k] || k).join(', ') : ''} <span class="vz-preview-note-inline">${g.ids.length} × ${formatMoney(g.unit)}</span></span><span>${formatMoney(g.monthly)}</span></div>`).join('')
    : lineKeys.length
      ? lineKeys.map(k => `<div class="preview-line"><span>${vzProductLabels[k] || k}${evcLabel(k)}</span><span>${formatMoney(priceOf(k))}</span></div>`).join('')
      : `<div class="preview-line"><span>Features</span><span>${dash}</span></div>`;
  // Key fobs with Driver ID (one-time, "--" when there are no extras).
  let keyfobLine = '';
  const fobVehicles = groups.length ? priced.filter(g => g.keys.includes('driverid')).reduce((n, g) => n + g.ids.length, 0) : (features.some(f => f.value === 'driverid') ? vehicleCount : 0);
  if (fobVehicles) {
    const fobs = vzReadUpsellKeyfobs(fobVehicles);
    const included = KEYFOBS_INCLUDED * fobVehicles;
    const extra = Math.max(0, fobs - included);
    keyfobLine = `<div class="preview-line"><span>Key Fobs (${Math.min(fobs, included)} included${extra ? ` + ${extra} extra` : ''})</span><span>${extra ? `${formatMoney(extra * KEYFOB_EXTRA_PRICE)} one-time` : dash}</span></div>`;
  }
  const skipped = selectedIds.length && groups.length ? selectedIds.length - vehicleCount : 0;
  pane.innerHTML = `${headerHtml}
    ${planGroupsHtml ? `<div class="vz-preview-plans">${planGroupsHtml}</div>` : ''}
    <div class="preview-line-items vz-preview-lines">
      ${featureLines}
      ${mixed ? '' : `<div class="preview-line vz-preview-line--rule"><strong>List Price</strong><strong>${lineKeys.length ? formatMoney(perUnit) : dash}</strong></div>`}
      ${isPriced ? msaPriceLine : ''}
      <div class="preview-line${mixed ? ' vz-preview-line--rule' : ''}"><span>QTY</span><span>${vehicleCount || dash}</span></div>
      <div class="preview-line vz-preview-line--total"><strong>Monthly</strong><strong>${isPriced ? formatMoney(totalMRR) : dash}</strong></div>
      ${keyfobLine}
      ${skipped ? `<div class="vz-preview-note">${skipped} selected vehicle${skipped === 1 ? '' : 's'} already ${skipped === 1 ? 'has' : 'have'} everything chosen — not charged.</div>` : ''}
    </div>`;
}

function getUpsellTargetBundleLabel(featureKeys, fallbackLabel) {
  if (featureKeys.includes('dual')) return 'VTU + DC';
  if (featureKeys.includes('ffc')) return 'VTU + FFC';
  return fallbackLabel;
}

function vzAddUpsellToOrder() {
  const features = [...document.querySelectorAll('.gc-upsell-feature-cb:checked')];
  if (!features.length) { showToast('Select at least one feature'); return; }
  const selectedIds = [...document.querySelectorAll('.gc-upsell-vehicle-cb:checked')].map(cb => cb.value);
  if (!selectedIds.length) { showToast('Select at least one vehicle'); return; }

  const opt = options.find(o => o.id === bld.targetOptId);
  if (!opt) { showToast('No option to apply the upsell to'); return; }

  // One modification per price group (vehicles that add the same features) — see vzUpsellPriceGroups.
  const groups = vzUpsellPriceGroups(features, selectedIds);
  if (!groups.length) { showToast('The selected vehicles already have these features'); return; }
  const fobGroups = groups.filter(g => g.keys.includes('driverid'));
  const fobVehicles = fobGroups.reduce((n, g) => n + g.ids.length, 0);
  const fobDelta = fobVehicles ? vzReadUpsellKeyfobs(fobVehicles) - KEYFOBS_INCLUDED * fobVehicles : 0;
  const bundles = groups.map((g, i) => {
    const label = g.keys.map(k => vzProductLabels[k] || k).join(', ');
    return {
      id: i === 0 && bld.targetBundleId ? bld.targetBundleId : Date.now() + i,
      coreKey: 'transaction-upsell',
      coreName: getUpsellTargetBundleLabel(g.keys, label) + (g.keys.includes('dual') && !g.keys.includes('ffc') ? ' (upgrade from FFC)' : ''),
      basePrice: g.unit,
      baseCorePrice: g.unit,
      features: g.keys,
      qty: g.ids.length,
      isMsaAuxiliary: true,
      isolatedTransactionType: 'upsell',
      selectedSubIds: g.ids,
      txLabel: 'Feature Upsell',
      promoType: 'Standard',
      promoName: '',
      keyfobQty: g.keys.includes('driverid') ? Math.max(0, KEYFOBS_INCLUDED * g.ids.length + (g === fobGroups[0] ? fobDelta : 0)) : undefined,
      evcType: g.keys.includes('evc') ? vzUpsellEvcType : undefined
    };
  });
  const existingIndex = bld.targetBundleId ? opt.bundles.findIndex(bundle => bundle.id === bld.targetBundleId) : -1;
  if (existingIndex >= 0) opt.bundles.splice(existingIndex, 1, ...bundles);
  else opt.bundles.push(...bundles);
  closeBundleModal();
  renderOptions();
  document.getElementById('empty-state')?.classList.add('hidden');
  document.getElementById('options-grid')?.classList.remove('hidden');
  const upsellLabel = features.map(f => vzProductLabels[f.value] || f.value).join(', ');
  logProposalEvent('Option edited', `Upsell: ${upsellLabel} on ${groups.reduce((n, g) => n + g.ids.length, 0)} vehicle(s).`);
  return;

  const featureKeys = features.map(f => f.value);
  const featureLabel = features.map(f => vzProductLabels[f.value] || f.value).join(', ');
  const featurePriceMap = {};
  VZ_UPSELL_FEATURES.forEach(f => { featurePriceMap[f.key] = f.price; });

  // Group the selected vehicles by which real bundle they currently belong to
  // (same source of truth the selection table itself was built from).
  const allSubs = vzGenerateSubscriptions();
  const countByBundleId = {};
  allSubs.forEach(s => {
    if (!selectedIds.includes(s.id)) return;
    countByBundleId[s.bundleId] = (countByBundleId[s.bundleId] || 0) + 1;
  });

  // 2026-09-18 (R22 correction, per the 2026-09-17 meeting transcript \u2014 Leo:
  // "in reality that goes with the second bundle"): 'ffc' and 'dual' aren't
  // plain addon features \u2014 they alias a full existing core SKU (vtu-ffc /
  // vtu-dual). Upselling "Forward Facing Camera" onto a vtu-only vehicle must
  // move it into the real vtu-ffc bundle, not create a separate "vtu + ffc
  // feature" line next to it. Resolve by rank so a vehicle never gets
  // downgraded by an unrelated feature pick.
  const CORE_ALIAS_BY_FEATURE = { ffc: 'vtu-ffc', dual: 'vtu-dual' };
  const CORE_RANK = { 'vtu': 0, 'vtu-ffc': 1, 'vtu-dual': 2 };

  let movedTotal = 0;
  Object.keys(countByBundleId).forEach(bundleIdKey => {
    const source = opt.bundles.find(b => String(b.id) === bundleIdKey);
    if (!source) return;
    const moveCount = Math.min(countByBundleId[bundleIdKey], Number(source.qty) || 0);
    if (moveCount <= 0) return;

    const existingFeatures = Array.isArray(source.features) ? source.features : [];
    const combinedKeys = Array.from(new Set([...existingFeatures, ...featureKeys]));

    const sourceRank = CORE_RANK[source.coreKey] ?? 0;
    const impliedRank = combinedKeys.reduce((max, k) => {
      const aliasCore = CORE_ALIAS_BY_FEATURE[k];
      return aliasCore ? Math.max(max, CORE_RANK[aliasCore]) : max;
    }, -1);
    const resultCoreKey = impliedRank > sourceRank
      ? Object.keys(CORE_RANK).find(k => CORE_RANK[k] === impliedRank)
      : source.coreKey;
    // ffc/dual are now represented at the core level (resultCoreKey) \u2014 don't
    // also keep them in the plain features array, or the bundle would double
    // up on the same thing.
    const resultFeatures = combinedKeys.filter(k => !CORE_ALIAS_BY_FEATURE[k]).sort();
    const resultSignature = resultFeatures.join(',');

    let target = opt.bundles.find(b =>
      b !== source &&
      b.coreKey === resultCoreKey &&
      (Array.isArray(b.features) ? [...b.features].sort() : []).join(',') === resultSignature
    );

    if (target) {
      if (target.originalQty === undefined) target.originalQty = target.qty;
      target.qty = (Number(target.qty) || 0) + moveCount;
    } else {
      const addonsPrice = resultFeatures.reduce((sum, k) => sum + (featurePriceMap[k] || 0), 0);
      // If the resulting core is a real, known SKU (vtu/vtu-ffc/vtu-dual),
      // use its real name/base price from corePricing instead of gluing the
      // feature label onto the source's name.
      const resolvedCore = corePricing[resultCoreKey];
      const baseCorePrice = resolvedCore ? resolvedCore.price : (source.baseCorePrice ?? source.basePrice);
      const coreName = resolvedCore ? resolvedCore.name : source.coreName;
      const remainingFeatureLabel = features
        .filter(f => !CORE_ALIAS_BY_FEATURE[f.value])
        .map(f => vzProductLabels[f.value] || f.value)
        .join(', ');
      target = {
        id: Date.now() + Math.floor(Math.random() * 1000),
        coreKey: resultCoreKey,
        coreName: remainingFeatureLabel ? `${coreName} + ${remainingFeatureLabel}` : coreName,
        basePrice: baseCorePrice + addonsPrice,
        baseCorePrice,
        features: resultFeatures,
        evcType: source.evcType || null,
        qty: moveCount,
        msaDiscountPct: (typeof vzUpsellDiscountPct === 'number' ? vzUpsellDiscountPct : source.msaDiscountPct) || 0,
        promoType: source.promoType || 'Standard',
        promoName: source.promoName || '',
        txLabel: 'Feature Upsell',
      };
      opt.bundles.push(target);
    }

    // Preserve the source's baseline before reducing it (same pattern as
    // vzAddCancelToOrder) so its own delta visual (red border, "X of Y
    // units") keeps working correctly too.
    if (source.originalQty === undefined) source.originalQty = source.qty;
    source.qty = Math.max(0, (Number(source.qty) || 0) - moveCount);
    movedTotal += moveCount;
  });

  closeBundleModal();
  renderOptions();
  document.getElementById('empty-state')?.classList.add('hidden');
  document.getElementById('options-grid')?.classList.remove('hidden');
  logProposalEvent('Option edited', `Upsell: ${featureLabel} on ${movedTotal} vehicle(s).`);
}

function renderVZCancelForm() {
  vzTxBillingModel = 'opex';
  const editingCancel = bld.targetBundleId && bld.targetOptId ? options.find(o => o.id === bld.targetOptId)?.bundles.find(b => b.id === bld.targetBundleId) : null;
  vzCancelEffective = editingCancel?.cancellationEffective === 'end' ? 'end' : 'immediate';
  const vzCancelPreSelected = txPreselectedSubIds.length > 0 ? [...txPreselectedSubIds] : [];
  txPreselectedSubIds = [];

  const area = document.getElementById('gc-tx-form-area');
  area.innerHTML = `
    <div class="gc-tx-step active" id="gc-cancel-step1">
      ${vzVehicleTableShellHtml('cancel')}
    </div>
    <div class="gc-tx-step" id="gc-cancel-step2">
      <div class="gc-tx-reason">
        <label class="vc-field-label" for="gc-cancel-reason">Cancellation Reason</label>
        <select class="select" id="gc-cancel-reason" data-vc-dropdown onchange="vzUpdateCancelPreview()">
          <!-- 2026-10-06 (per Catalina): official cancellation reasons list. Grouped by its
               own prefixes (Sale / Relationship / Financial / Installation); the option shows
               the reason without the prefix, the stored label keeps it. -->
          <option value="">Select reason...</option>
          <optgroup label="Sale">
            <option data-label="Sale - Oversold" value="sale-oversold">Oversold</option>
            <option data-label="Sale - Product Fit/Misrepresentation" value="sale-product-fit-misrepresentation">Product Fit/Misrepresentation</option>
            <option data-label="Sale - Buyers Remorse" value="sale-buyers-remorse">Buyers Remorse</option>
            <option data-label="Sale - Deferred to later - Customer not ready" value="sale-deferred-to-later-customer-not-ready">Deferred to later - Customer not ready</option>
          </optgroup>
          <optgroup label="Relationship">
            <option data-label="Relationship - VZC Experience" value="relationship-vzc-experience">VZC Experience</option>
            <option data-label="Relationship - VZC System/Process Issues" value="relationship-vzc-system-process-issues">VZC System/Process Issues</option>
            <option data-label="Relationship - Agent Response Time" value="relationship-agent-response-time">Agent Response Time</option>
            <option data-label="Relationship - Agent Response Quality" value="relationship-agent-response-quality">Agent Response Quality</option>
          </optgroup>
          <optgroup label="Financial">
            <option data-label="Financial - Out of Business" value="financial-out-of-business">Out of Business</option>
            <option data-label="Financial - Sold Company" value="financial-sold-company">Sold Company</option>
          </optgroup>
          <optgroup label="Installation">
            <option data-label="Installation - Installation Appointment" value="installation-installation-appointment">Installation Appointment</option>
            <option data-label="Installation - Onboarding Quality" value="installation-onboarding-quality">Onboarding Quality</option>
            <option data-label="Installation - Shipping Error" value="installation-shipping-error">Shipping Error</option>
          </optgroup>
          <optgroup label="Other reasons">
            <option data-label="Unable to Obtain VINs" value="unable-to-obtain-vins">Unable to Obtain VINs</option>
            <option data-label="Unresponsive Customer" value="unresponsive-customer">Unresponsive Customer</option>
            <option data-label="Inventory Shortages" value="inventory-shortages">Inventory Shortages</option>
          </optgroup>
        </select>
      </div>
      <div class="gc-tx-reason">
        <div class="textarea-field">
          <label class="textarea-field__label" for="gc-cancel-notes">Additional Notes</label>
          <div class="textarea-field__container"><textarea class="textarea-field__input" id="gc-cancel-notes" rows="3" placeholder="Describe the circumstances..."></textarea></div>
        </div>
      </div>
    </div>`;

  window._vzCancelPreSelected = vzCancelPreSelected;
  vzRenderCancelTable();
  vzUpdateCancelPreview();

  setVZTxFooter(`
    <button class="btn btn--primary btn--large" id="gc-cancel-next-btn" onclick="vzGoCancelStep2()" disabled style="flex:none; padding:10px 24px; font-size:14px; opacity:0.4; cursor:not-allowed;">Select reason</button>
  `);
}

function vzGoCancelStep1() {
  document.getElementById('gc-cancel-step1').classList.add('active');
  document.getElementById('gc-cancel-step2').classList.remove('active');
  setVZTxFooter(`
    <button class="btn btn--primary btn--large" id="gc-cancel-next-btn" onclick="vzGoCancelStep2()" disabled style="flex:none; padding:10px 24px; font-size:14px; opacity:0.4; cursor:not-allowed;">Select reason</button>
  `);
  // Back to step 1: restore Cancel as the footer's left action (matches the
  // Upsell flow's pattern \u2014 Back on the left replaces the separate ghost
  // link, so the footer never shows 3 actions at once).
  const cancelBackBtn = document.getElementById('gc-tx-cancel-back-btn');
  if (cancelBackBtn) { cancelBackBtn.textContent = 'Cancel'; cancelBackBtn.onclick = closeBundleModal; }
  vzUpdateCancelCount();
}

function vzGoCancelStep2() {
  const count = document.querySelectorAll('.gc-cancel-cb:checked').length;
  if (!count) { showToast('Select at least one subscription'); return; }
  document.getElementById('gc-cancel-step1').classList.remove('active');
  document.getElementById('gc-cancel-step2').classList.add('active');
  vzUpdateCancelPreview();
  setVZTxFooter(`
    <button class="btn btn--primary btn--large" id="gc-cancel-add-btn" onclick="vzAddCancelToOrder()" style="flex:none; padding:10px 24px; font-size:14px;">Add Cancellation</button>
  `);
  // Step 2 of 2: swap the footer's left action from Cancel to Back, same
  // pattern as Upsell \u2014 no separate ghost Back link, so the footer only
  // ever shows 2 actions.
  const cancelBackBtn = document.getElementById('gc-tx-cancel-back-btn');
  if (cancelBackBtn) { cancelBackBtn.textContent = 'Back'; cancelBackBtn.onclick = vzGoCancelStep1; }
}

function vzUpdateCancelCount() {
  if (typeof vzSyncSelectedCount === 'function') vzSyncSelectedCount('cancel');
  const count = document.querySelectorAll('.gc-cancel-cb:checked').length;
  // Enable/disable the step1 "Select reason" next button
  const nextBtn = document.getElementById('gc-cancel-next-btn');
  if (nextBtn) {
    nextBtn.disabled = count === 0;
    nextBtn.style.opacity = count === 0 ? '0.4' : '1';
    nextBtn.style.cursor = count === 0 ? 'not-allowed' : 'pointer';
  }
  vzUpdateCancelPreview();
}

function vzToggleCancelAll(el) {
  const visible = x => !x.closest('tr')?.classList.contains('vz-search-hidden');
  document.querySelectorAll('.gc-cancel-cb').forEach(cb => { if (visible(cb) && !cb.disabled) cb.checked = el.checked; });
  document.querySelectorAll('.gc-cancel-cb[disabled]').forEach(cb => vzCancelCoreRule(cb));
  document.querySelectorAll('.gc-cancel-vehicle-hdr').forEach(h => { if (visible(h)) { h.checked = el.checked; h.indeterminate = false; } });
  vzUpdateCancelCount();
}

function vzToggleCancelVehicle(serial, checked) {
  const cbs = document.querySelectorAll(`.gc-cancel-cb[data-serial="${serial}"]`);
  const newState = checked !== undefined ? checked : !([...cbs].every(cb => cb.checked));
  cbs.forEach(cb => cb.checked = newState);
  vzSyncCancelVehicleHdr(serial);
  vzUpdateCancelCount();
}

function vzSyncCancelVehicleHdr(serial) {
  const hdr = document.querySelector(`.gc-cancel-vehicle-hdr[data-serial="${serial}"]`);
  if (!hdr) return;
  const cbs = [...document.querySelectorAll(`.gc-cancel-cb[data-serial="${serial}"]`)];
  hdr.checked = cbs.length > 0 && cbs.every(cb => cb.checked);
  hdr.indeterminate = !hdr.checked && cbs.some(cb => cb.checked);
}

function vzToggleCancelGroup(groupKey, checked) {
  document.querySelectorAll(`.gc-cancel-cb[data-group="${groupKey}"]`)
    .forEach(cb => { cb.checked = checked; vzSyncCancelVehicleHdr(cb.dataset.serial); });
  vzUpdateCancelCount();
}

// 2026-10-14 (per Catalina): Opex / Capex switch next to the summary title, like Expansion — shown so the business can
// confirm whether Upsell / Cancellation / Reactivation need it (pending-requirements #41). Display only; no pricing effect.
let vzTxBillingModel = 'opex';
function vzBillingModelSwitchHtml() {
  const btn = (m, label) => `<button type="button" class="segmented-pill__btn${vzTxBillingModel === m ? ' is-active' : ''}" aria-pressed="${vzTxBillingModel === m}" onclick="vzSetTxBillingModel('${m}')">${label}</button>`;
  return `<div class="preview-model-field"><div class="segmented-pill" role="group" aria-label="Billing model">${btn('opex', 'Opex')}${btn('capex', 'Capex')}</div></div>`;
}
function vzSetTxBillingModel(model) {
  vzTxBillingModel = model === 'capex' ? 'capex' : 'opex';
  if (bld.txType === 'upsell') vzUpdateUpsellPreview();
  else if (bld.txType === 'cancel') vzUpdateCancelPreview();
  else if (bld.txType === 'reactivate') vzUpdateReactivationPreview();
}

// PM/PO/UX sync 2026-10-14 (Leo): Partial Cancellation has no Opex / Capex choice (each subscription already is one or
// the other). In its place: when the cancellation takes effect — Immediately (default; ECF applies) or at the End of
// contract (scheduled so those subscriptions don't auto-renew; billed until the term ends, no ECF). Only when the MSA
// auto-renews; otherwise everything ends with the contract anyway.
let vzCancelEffective = 'immediate';
function vzCancelEffectiveAvailable() {
  return typeof DEMO_MSA === 'undefined' || DEMO_MSA.autoRenewalEnabled !== false;
}
function vzCancelEffectiveSwitchHtml() {
  if (!vzCancelEffectiveAvailable()) return '';
  const btn = (v, label) => `<button type="button" class="segmented-pill__btn${vzCancelEffective === v ? ' is-active' : ''}" aria-pressed="${vzCancelEffective === v}" onclick="vzSetCancelEffective('${v}')">${label}</button>`;
  return `<div class="preview-model-field"><div class="segmented-pill" role="group" aria-label="Effective">${btn('immediate', 'Immediate')}${btn('end', 'End of contract')}</div></div>`;
}
function vzSetCancelEffective(value) {
  vzCancelEffective = value === 'end' ? 'end' : 'immediate';
  vzUpdateCancelPreview();
}

function vzUpdateCancelPreview() {
  const pane = document.getElementById('gc-tx-preview-area');
  if (!pane) return;
  // 2026-10-14 (per Catalina): same layout as the Upsell / Expansion summary — "Cancellation Summary" title, term badge,
  // "-$--/month"; the lines are always there with "--" until something is selected. QTY replaces "Selected subscriptions".
  const dash = '--';
  const selected = [...document.querySelectorAll('.gc-cancel-cb:checked')];
  const term = bld.targetOptId ? (options.find(o => o.id === bld.targetOptId)?.term || 36) : 36;
  const mrrLoss = selected.reduce((sum, cb) => sum + parseFloat(cb.dataset.rate || 0), 0);
  const ecf = selected.reduce((sum, cb) => sum + parseFloat(cb.dataset.rate || 0) * Math.max(0, parseInt(cb.dataset.remain) || 0) * 0.5, 0);
  const atEnd = vzCancelEffectiveAvailable() && vzCancelEffective === 'end';
  const has = selected.length > 0;
  const byProduct = new Map();
  selected.forEach(cb => {
    const key = cb.dataset.product || 'Subscription';
    const row = byProduct.get(key) || { qty: 0, amount: 0 };
    row.qty += 1; row.amount += parseFloat(cb.dataset.rate || 0);
    byProduct.set(key, row);
  });
  // 2026-10-15 (per Catalina): one line per subscription with its monthly amount, no "(n)" count — like the Expansion
  // summary; the count is the QTY line below.
  const productLines = has
    ? [...byProduct.entries()].map(([name, row]) => `<div class="preview-line"><span>${name}</span><span class="vz-preview-negative">-${formatMoney(row.amount)}</span></div>`).join('')
    : `<div class="preview-line"><span>Subscriptions</span><span>${dash}</span></div>`;
  const headerHtml = `
    <div class="preview-label-row"><div class="preview-label preview-label--title">Cancellation Summary</div>${vzCancelEffectiveSwitchHtml()}</div>
    <div class="preview-price">${has ? '-' : ''}$<span>${has ? formatMoneyAmount(mrrLoss) : dash}</span><span>/month</span></div>`;
  // Initial state (nothing selected): only the header, like the Upsell Summary.
  if (!has) { pane.innerHTML = headerHtml; return; }
  pane.innerHTML = `${headerHtml}
    <div class="preview-line-items vz-preview-lines">
      ${productLines}
      <div class="preview-line vz-preview-line--rule"><span>QTY</span><span>${has ? selected.length : dash}</span></div>
      <div class="preview-line vz-preview-line--total"><strong>Monthly reduction</strong><strong class="${has ? 'vz-preview-negative' : ''}">${has ? `-${formatMoney(mrrLoss)}` : dash}</strong></div>
      ${atEnd
        ? `<div class="preview-line"><span>Effective</span><span>${vzFmtDate(DEMO_MSA.endDate)}</span></div>
      <div class="vz-preview-note">Billed until the contract ends; these subscriptions won't renew. No ECF.</div>`
        : `<div class="preview-line"><span>Est. ECF</span><span>${has ? formatMoney(ecf) : dash}</span></div>
      <div class="vz-preview-note">ECF at 50% of remaining contract</div>`}
    </div>`;
}

function vzAddCancelToOrder() {
  const reason = document.getElementById('gc-cancel-reason');
  if (reason && !reason.value) { showToast('Select a cancellation reason'); return; }
  const selected = [...document.querySelectorAll('.gc-cancel-cb:checked')];
  if (!selected.length) { showToast('Select at least one subscription'); return; }
  const reasonOpt = reason ? reason.options[reason.selectedIndex] : null;
  const reasonLabel = reasonOpt ? (reasonOpt.dataset.label || reasonOpt.textContent.trim()) : '';
  const count = selected.length;

  const opt = bld.targetOptId ? options.find(o => o.id === bld.targetOptId) : null;
  if (!opt) { showToast('No option to apply the cancellation to'); return; }

  if (proposalData.entryPoint !== 'renewalRewrap') {
    const selectedIds = selected.map(cb => cb.value);
    const selectedCoreKeys = [...new Set(selected.map(cb => cb.dataset.corekey).filter(Boolean))];
    const realBundles = (Array.isArray(existingOrders) ? existingOrders : []).flatMap(order => order.bundles || []);
    const selectedBundles = selectedCoreKeys.map(coreKey => realBundles.find(bundle => bundle.coreKey === coreKey)).filter(Boolean);
    const unitRate = selectedBundles.length
      ? selectedBundles.reduce((sum, bundle) => sum + Number(calcBundle(bundle, 36, bundle.promoType || 'Standard', bundle.qty).unitPrice || 0), 0) / selectedBundles.length
      : 0;
    // 2026-10-14: per-subscription selection — the cancellation amount is the sum of the selected subscriptions' rates.
    const selectedRateTotal = selected.reduce((sum, cb) => sum + (parseFloat(cb.dataset.rate) || 0), 0);
    const productLabel = vzTxSolutionLabel(selected) || selectedBundles.map(bundle => bundle.coreName).join(', ') || 'selected products';
    const isolatedBundle = {
      id: bld.targetBundleId || Date.now(),
      coreKey: 'transaction-cancel',
      coreName: `${productLabel}`,
      basePrice: -(selectedRateTotal / selected.length || unitRate),
      baseCorePrice: -(selectedRateTotal / selected.length || unitRate),
      features: [],
      qty: selected.length,
      isMsaAuxiliary: true,
      isolatedTransactionType: 'cancel',
      selectedSubIds: selectedIds,
      txLabel: vzCancelEffectiveAvailable() && vzCancelEffective === 'end' ? 'Cancellation (end of contract)' : 'Cancellation',
      cancellationEffective: vzCancelEffectiveAvailable() ? vzCancelEffective : 'immediate',
      promoType: 'Standard',
      promoName: '',
      cancellationReason: reasonLabel
    };
    const existingIndex = bld.targetBundleId
      ? opt.bundles.findIndex(bundle => bundle.id === bld.targetBundleId)
      : -1;
    if (existingIndex >= 0) opt.bundles[existingIndex] = isolatedBundle;
    else opt.bundles.push(isolatedBundle);
    closeBundleModal();
    renderOptions();
    document.getElementById('empty-state')?.classList.add('hidden');
    document.getElementById('options-grid')?.classList.remove('hidden');
    logProposalEvent('Option edited', `Cancellation: ${selected.length} subscription${selected.length > 1 ? 's' : ''} reduced. Reason: ${reasonLabel}.`);
    return;
  }

  const currentBundles = opt.bundles.filter(bundle => bundle.originalQty !== undefined);
  const selectedCoreKeys = [...new Set(selected.map(cb => cb.dataset.corekey).filter(Boolean))];
  const selectedBundles = selectedCoreKeys.map(coreKey => currentBundles.find(bundle => bundle.coreKey === coreKey)).filter(Boolean);
  const unitRate = selectedBundles.length
    ? selectedBundles.reduce((sum, bundle) => sum + Number(calcBundle(bundle, opt.term || 36, bundle.promoType || 'Standard', bundle.qty).unitPrice || 0), 0) / selectedBundles.length
    : 0;
  const productLabel = selectedBundles.map(bundle => bundle.coreName).join(', ') || 'selected products';
  opt.bundles.push({
    id: bld.targetBundleId || Date.now(),
    coreKey: 'transaction-cancel',
    coreName: `${productLabel}`,
    basePrice: -unitRate,
    baseCorePrice: -unitRate,
    features: [],
    qty: selected.length,
    isMsaAuxiliary: true,
    isolatedTransactionType: 'cancel',
    selectedSubIds: selected.map(cb => cb.value),
    txLabel: vzCancelEffectiveAvailable() && vzCancelEffective === 'end' ? 'Cancellation (end of contract)' : 'Cancellation',
    cancellationEffective: vzCancelEffectiveAvailable() ? vzCancelEffective : 'immediate',
    promoType: 'Standard',
    promoName: '',
    cancellationReason: reasonLabel
  });
  closeBundleModal();
  renderOptions();
  document.getElementById('empty-state')?.classList.add('hidden');
  document.getElementById('options-grid')?.classList.remove('hidden');
  logProposalEvent('Option edited', `Cancellation: ${selected.length} subscription${selected.length > 1 ? 's' : ''} reduced. Reason: ${reasonLabel}.`);
  return;

  const removeByCore = {};
  selected.forEach(cb => {
    const key = cb.dataset.corekey;
    if (!key) return;
    removeByCore[key] = (removeByCore[key] || 0) + 1;
  });

  Object.entries(removeByCore).forEach(([coreKey, removeCount]) => {
    const bundle = opt.bundles.find(b => b.coreKey === coreKey);
    if (!bundle) return;
    if (bundle.originalQty === undefined) bundle.originalQty = bundle.qty;
    bundle.qty = Math.max(0, (Number(bundle.qty) || 0) - removeCount);
  });

  closeBundleModal();
  renderOptions();
  document.getElementById('empty-state')?.classList.add('hidden');
  document.getElementById('options-grid')?.classList.remove('hidden');
  const optionNumber = Math.max(1, options.findIndex(o => o.id === opt.id) + 1);
  logProposalEvent('Option edited', `${count} subscription${count > 1 ? 's' : ''} reduced on Option ${optionNumber}. Reason: ${reasonLabel}.`);
}

function renderVZReactivationForm() {
  vzTxBillingModel = 'opex';
  vzReactivationPreSelected = txPreselectedSubIds.length > 0 ? [...txPreselectedSubIds] : [];
  txPreselectedSubIds = [];
  // 2026-10-14 (per Catalina): Reactivation mirrors Partial Cancellation — same vehicle table (C360 style) and summary,
  // but it lists previously deactivated vehicles and adds their subscriptions back (+ instead of -).
  const area = document.getElementById('gc-tx-form-area');
  area.innerHTML = `
    <div class="gc-tx-step active" id="gc-reactivation-step1">
      ${vzVehicleTableShellHtml('reactivation')}
    </div>`;
  vzRenderReactivationTable();
  vzUpdateReactivationPreview();
  setVZTxFooter(`
    <button class="btn btn--primary btn--large" id="gc-reactivation-add-btn" onclick="vzAddReactivationToOrder()" disabled style="flex:none; padding:10px 24px; font-size:14px; opacity:0.4; cursor:not-allowed;">Add Reactivation</button>
  `);
}

// Previously deactivated vehicles, one subscription set per unit (from DEMO_PREVIOUSLY_DEACTIVATED_UNITS).
function vzGenerateDeactivatedSubscriptions() {
  const opt = bld.targetOptId ? options.find(o => o.id === bld.targetOptId) : null;
  const term = (opt && opt.term) || 36;
  const subs = [];
  let n = 1;
  DEMO_PREVIOUSLY_DEACTIVATED_UNITS.forEach((unit, unitIndex) => {
    const rate = vzGetReactivationUnitPrice(unit.coreKey, unit.qty, term);
    for (let i = 0; i < unit.qty; i++) {
      const serial = `VZD-${String(n).padStart(6, '0')}`;
      subs.push({
        id: `${unit.id}-${i + 1}`,
        product: unit.coreName,
        productKey: unit.coreKey,
        features: [],
        bundleId: null,
        rate,
        serial,
        vin: `1VZD${String(n).padStart(5, '0')}RX${String(10 + (vzHash(serial) % 89))}`,
        orderNumber: String(5003790140 + unitIndex * 1371),
        vehicleName: `Unit-${String(100 + n).padStart(3, '0')}`,
        techRef: '',
        remainMonths: 0,
        isCore: true,
        deactivatedDate: unit.deactivatedDate,
        reason: unit.reason,
      });
      n++;
    }
  });
  return subs;
}

function vzRenderReactivationTable() {
  const thead = document.getElementById('gc-reactivation-thead');
  const tbody = document.getElementById('gc-reactivation-tbody');
  if (!thead || !tbody) return;
  const preSelected = Array.isArray(vzReactivationPreSelected) ? vzReactivationPreSelected : [];
  const records = vzGenerateDeactivatedSubscriptions().map(vzVehicleRecord);
  thead.innerHTML = vzVehicleTableHeadHtml('reactivation', 6);
  tbody.innerHTML = vzVehicleBlocksHtml(records, 'reactivation', preSelected);
  document.querySelectorAll('.gc-reactivation-vehicle-hdr').forEach(h => vzSyncReactivationVehicleHdr(h.dataset.serial));
  vzUpdateReactivationCount();
  vzInitVehicleSearch('reactivation');
}

function vzToggleReactivationAll(el) {
  const visible = x => !x.closest('tr')?.classList.contains('vz-search-hidden');
  document.querySelectorAll('.gc-reactivation-cb').forEach(cb => { if (visible(cb)) cb.checked = el.checked; });
  document.querySelectorAll('.gc-reactivation-vehicle-hdr').forEach(h => { if (visible(h)) { h.checked = el.checked; h.indeterminate = false; } });
  vzUpdateReactivationCount();
}

function vzToggleReactivationVehicle(serial, checked) {
  const cbs = document.querySelectorAll(`.gc-reactivation-cb[data-serial="${serial}"]`);
  const newState = checked !== undefined ? checked : !([...cbs].every(cb => cb.checked));
  cbs.forEach(cb => cb.checked = newState);
  vzSyncReactivationVehicleHdr(serial);
  vzUpdateReactivationCount();
}

// 2026-10-15 (per Catalina): mirror rule for Partial Cancellation — cancelling the core subscription cancels everything
// on that vehicle (a companion / feature can't stay active without it); unchecking a companion / feature while the
// core is selected unchecks the core too.
function vzCancelCoreRule(cb) {
  const serial = cb.dataset.serial;
  const all = [...document.querySelectorAll(`.gc-cancel-cb[data-serial="${serial}"]`)];
  const core = all.find(x => !String(x.value).includes('::'));
  if (!core) return;
  if (cb === core && cb.checked) all.forEach(x => { x.checked = true; });
  else if (cb !== core && !cb.checked) core.checked = false;
  // 2026-10-19 (per Leo): the Seasonal Fee can't be cancelled on its own — it follows Vehicle Tracking.
  all.filter(x => String(x.value).endsWith('::season')).forEach(x => { x.checked = core.checked; });
}

// PM/PO/UX sync 2026-10-14 (Leo): a companion or feature can't be reactivated without the core subscription (Vehicle
// Tracking / asset tracker) — checking one checks the vehicle's core; unchecking the core unchecks the rest.
function vzReactivationCoreRule(cb) {
  const serial = cb.dataset.serial;
  const all = [...document.querySelectorAll(`.gc-reactivation-cb[data-serial="${serial}"]`)];
  const core = all.find(x => !String(x.value).includes('::'));
  if (!core) return;
  if (cb === core && !cb.checked) all.forEach(x => { x.checked = false; });
  else if (cb !== core && cb.checked) core.checked = true;
  all.filter(x => String(x.value).endsWith('::season')).forEach(x => { x.checked = core.checked; });
}

function vzSyncReactivationVehicleHdr(serial) {
  const hdr = document.querySelector(`.gc-reactivation-vehicle-hdr[data-serial="${serial}"]`);
  if (!hdr) return;
  const cbs = [...document.querySelectorAll(`.gc-reactivation-cb[data-serial="${serial}"]`)];
  hdr.checked = cbs.length > 0 && cbs.every(cb => cb.checked);
  hdr.indeterminate = !hdr.checked && cbs.some(cb => cb.checked);
}

function vzUpdateReactivationCount() {
  if (typeof vzSyncSelectedCount === 'function') vzSyncSelectedCount('reactivation');
  const count = document.querySelectorAll('.gc-reactivation-cb:checked').length;
  const btn = document.getElementById('gc-reactivation-add-btn');
  if (btn) {
    btn.disabled = count === 0;
    btn.style.opacity = count === 0 ? '0.4' : '1';
    btn.style.cursor = count === 0 ? 'not-allowed' : 'pointer';
  }
  vzUpdateReactivationPreview();
}

function vzGetReactivationUnitPrice(coreKey, qty, term) {
  const core = corePricing[coreKey];
  const dummyBundle = { coreKey, basePrice: core?.price || 0, baseCorePrice: core?.price || 0, qty, features: [] };
  try { return calcBundle(dummyBundle, term, 'Standard', qty).unitPrice; } catch (_) { return core?.price || 0; }
}

// Reactivation Summary — mirror of the Cancellation Summary (adds instead of subtracting, no ECF).
function vzUpdateReactivationPreview() {
  const pane = document.getElementById('gc-tx-preview-area');
  if (!pane) return;
  const dash = '--';
  const selected = [...document.querySelectorAll('.gc-reactivation-cb:checked')];
  const term = bld.targetOptId ? (options.find(o => o.id === bld.targetOptId)?.term || 36) : 36;
  const total = selected.reduce((sum, cb) => sum + parseFloat(cb.dataset.rate || 0), 0);
  const has = selected.length > 0;
  const byProduct = new Map();
  selected.forEach(cb => {
    const key = cb.dataset.product || 'Subscription';
    const row = byProduct.get(key) || { qty: 0, amount: 0 };
    row.qty += 1; row.amount += parseFloat(cb.dataset.rate || 0);
    byProduct.set(key, row);
  });
  const productLines = has
    ? [...byProduct.entries()].map(([name, row]) => `<div class="preview-line"><span>${name}</span><span class="vz-preview-positive">+${formatMoney(row.amount)}</span></div>`).join('')
    : `<div class="preview-line"><span>Subscriptions</span><span>${dash}</span></div>`;
  const headerHtml = `
    <div class="preview-label-row"><div class="preview-label preview-label--title">Reactivation Summary</div></div>
    <div class="preview-price">${has ? '+' : ''}$<span>${has ? formatMoneyAmount(total) : dash}</span><span>/month</span></div>`;
  if (!has) { pane.innerHTML = headerHtml; return; }
  pane.innerHTML = `${headerHtml}
    <div class="preview-line-items vz-preview-lines">
      ${productLines}
      <div class="preview-line vz-preview-line--rule"><span>QTY</span><span>${has ? selected.length : dash}</span></div>
      <div class="preview-line vz-preview-line--total"><strong>Monthly increase</strong><strong class="${has ? 'vz-preview-positive' : ''}">${has ? `+${formatMoney(total)}` : dash}</strong></div>
    </div>`;
}

// 2026-11-10 (per Catalina): a Cancellation / Reactivation line reads like the other transactions — the solution name
// (VTU + FFC), not the list of subscriptions. When only some subscriptions of a vehicle are picked (e.g. just the camera),
// they follow the name: "VTU + FFC — AI Dashcam Forward Facing Video Subscription".
function vzTxSolutionLabel(selected) {
  const solutions = [...new Set(selected.map(cb => corePricing[cb.dataset.corekey]?.name || cb.dataset.corekey).filter(Boolean))];
  const bySerial = {};
  selected.forEach(cb => { (bySerial[cb.dataset.serial] = bySerial[cb.dataset.serial] || []).push(cb.value); });
  const partial = Object.values(bySerial).some(ids => !ids.some(id => !String(id).includes('::')));
  if (!partial) return solutions.join(', ');
  const subs = [...new Set(selected.filter(cb => String(cb.value).includes('::')).map(cb => cb.dataset.product).filter(Boolean))];
  return solutions.join(', ') + (subs.length ? ' \u2014 ' + subs.join(', ') : '');
}

function vzAddReactivationToOrder() {
  const selected = [...document.querySelectorAll('.gc-reactivation-cb:checked')];
  if (!selected.length) { showToast('Select at least one unit to reactivate'); return; }

  const opt = bld.targetOptId ? options.find(o => o.id === bld.targetOptId) : null;
  if (!opt) { showToast('No option to apply the reactivation to'); return; }

  // 2026-10-14: per-subscription selection (mirror of Partial Cancellation) — amount = sum of the selected rates.
  const totalQty = selected.length;
  const reactivatedUnitQty = new Set(selected.map(cb => cb.dataset.serial).filter(Boolean)).size;
  const totalMonthly = selected.reduce((sum, cb) => sum + (parseFloat(cb.dataset.rate) || 0), 0);
  const unitRate = totalQty ? totalMonthly / totalQty : 0;
  const productLabel = vzTxSolutionLabel(selected);
  const selectedIds = selected.map(cb => cb.value);

  const isolatedBundle = {
    id: bld.targetBundleId || Date.now(),
    coreKey: 'transaction-reactivation',
    coreName: productLabel,
    basePrice: unitRate,
    baseCorePrice: unitRate,
    features: [],
    qty: totalQty,
    reactivatedUnitQty,
    isMsaAuxiliary: true,
    isolatedTransactionType: 'reactivate',
    selectedSubIds: selectedIds,
    txLabel: 'Reactivation',
    promoType: 'Standard',
    promoName: ''
  };
  const existingIndex = bld.targetBundleId
    ? opt.bundles.findIndex(bundle => bundle.id === bld.targetBundleId)
    : -1;
  if (existingIndex >= 0) opt.bundles[existingIndex] = isolatedBundle;
  else opt.bundles.push(isolatedBundle);

  closeBundleModal();
  renderOptions();
  document.getElementById('empty-state')?.classList.add('hidden');
  document.getElementById('options-grid')?.classList.remove('hidden');
  logProposalEvent('Option edited', `Reactivation: ${totalQty} unit${totalQty === 1 ? '' : 's'} reactivated.`);
}

function vzRestoreUpsellFeatureSelection(container) {
  if (!container) return;
  const selected = new Set(vzUpsellPreSelectedFeatures || []);
  container.querySelectorAll('.gc-upsell-feature-cb').forEach((checkbox) => {
    if (!selected.has(checkbox.value)) return;
    checkbox.checked = true;
  });
  const evcSel = document.getElementById('gc-upsell-evc-type');
  if (evcSel) { evcSel.value = vzUpsellEvcType; evcSel.__vcDropdown?.refresh?.(); }
  vzSyncUpsellFeatures();
}

function vzCaptureUpsellFeatureSelectionFromDom() {
  const featureInputs = [...document.querySelectorAll('.gc-upsell-feature-cb')];
  if (!featureInputs.length) return;
  vzUpsellPreSelectedFeatures = featureInputs
    .filter((checkbox) => checkbox.checked)
    .map((checkbox) => checkbox.value);
}

// \u2500\u2500 Existing-only globals and patches \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
window.startRenewalRewrapProposal = startRenewalRewrapProposal;

window.startReactivationProposal = startReactivationProposal;

window.setCancelPenaltyWave = setCancelPenaltyWave;

window.openCancelMcModal = function openCancelMcModal() {
  options = [];
  nextOptId = 1;
  const opt = window.createOptionFromCurrent('Cancel MC');
  if (!opt) return;
  opt.transactionMode = 'Cancel';
  bld.selectedOptionId = opt.id;
  document.getElementById('cancel-mc-modal-summary').innerHTML = getCancelMcSummaryHtml();
  document.getElementById('cancel-mc-modal-hardware').innerHTML = getHardwareAccordionHtml(opt, 'modal-' + opt.id);
  renderCancelMcModalPenalty();
  document.getElementById('cancel-mc-modal-overlay').classList.add('is-open');
};

window.openCancelAutoRenewalModal = function openCancelAutoRenewalModal() {
  const reasonInput = document.getElementById('car-reason');
  const reasonError = document.getElementById('car-reason-error');
  const uploadInput = document.getElementById('car-upload-input');
  const uploadFilename = document.getElementById('car-upload-filename');
  const uploadError = document.getElementById('car-upload-error');
  if (reasonInput) {
    reasonInput.value = '';
    reasonInput.classList.remove('input--error');
  }
  if (reasonError) reasonError.classList.add('hidden');
  if (uploadInput) uploadInput.value = '';
  if (uploadFilename) { uploadFilename.classList.add('hidden'); uploadFilename.textContent = ''; }
  if (uploadError) uploadError.classList.add('hidden');
  updateCancelAutoRenewalSubmitState();
  const endBlock = document.getElementById('car-contract-end-block');
  const endValueEl = document.getElementById('car-contract-end-value');
  if (endBlock && endValueEl) {
    if (DEMO_MSA.endDate) {
      const endDate = new Date(DEMO_MSA.endDate + 'T00:00:00');
      const now = new Date();
      const monthsLeft = Math.max(0, Math.round((endDate - now) / (1000 * 60 * 60 * 24 * 30.44)));
      const endDateLabel = endDate.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
      endValueEl.textContent = `${endDateLabel} \u2014 ${monthsLeft} month${monthsLeft === 1 ? '' : 's'} remaining`;
      endBlock.classList.remove('hidden');
    } else {
      endBlock.classList.add('hidden');
    }
  }
  document.getElementById('cancel-auto-renewal-modal-overlay')?.classList.add('is-open');
};

document.addEventListener('click', () => {
  document.querySelectorAll('.msa-commitment-menu').forEach(menu => setKebabMenuOpen(menu, false));
});

(function patchUpsellFeatureStatePersistence() {
  if (typeof window.confirmBundleTxType === 'function') {
    const originalConfirmBundleTxType = window.confirmBundleTxType;
    window.confirmBundleTxType = function patchedConfirmBundleTxType(...args) {
      const isUpsell = bld?.txType === 'upsell';
      if (isUpsell) {
        const existingUpsell = bld.targetOptId && bld.targetBundleId
          ? options.find((option) => option.id === bld.targetOptId)?.bundles.find((bundle) => bundle.id === bld.targetBundleId)
          : null;
        vzUpsellPreSelectedFeatures = existingUpsell?.isolatedTransactionType === 'upsell'
          ? [...(existingUpsell.features || [])]
          : [];
        const isEdit = existingUpsell?.isolatedTransactionType === 'upsell';
        vzUpsellKeyfobDelta = isEdit && existingUpsell.keyfobQty != null ? existingUpsell.keyfobQty - KEYFOBS_INCLUDED * (Number(existingUpsell.qty) || 0) : 0;
        vzUpsellEvcType = (isEdit && existingUpsell.evcType) || 'sides-rear-cargo';
      }

      const result = originalConfirmBundleTxType.apply(this, args);

      if (isUpsell && typeof window.renderVZUpsellForm === 'function') {
        const area = document.getElementById('gc-tx-body') || document;
        if (upsellMode === 'features') {
          vzRestoreUpsellFeatureSelection(area);
        }
      }

      return result;
    };
  }

  if (typeof window.renderVZUpsellForm === 'function') {
    const originalRenderVZUpsellForm = window.renderVZUpsellForm;
    window.renderVZUpsellForm = function patchedRenderVZUpsellForm(...args) {
      const result = originalRenderVZUpsellForm.apply(this, args);
      const area = document.getElementById('gc-tx-body') || document;
      if (upsellMode === 'features') {
        vzRestoreUpsellFeatureSelection(area);
      }
      return result;
    };
  }

  if (typeof window.vzGoUpsellStep1 === 'function') {
    const originalVzGoUpsellStep1 = window.vzGoUpsellStep1;
    window.vzGoUpsellStep1 = function patchedVzGoUpsellStep1(...args) {
      vzCaptureUpsellFeatureSelectionFromDom();
      return originalVzGoUpsellStep1.apply(this, args);
    };
  }

  if (typeof window.vzGoUpsellStep2 === 'function') {
    const originalVzGoUpsellStep2 = window.vzGoUpsellStep2;
    window.vzGoUpsellStep2 = function patchedVzGoUpsellStep2(...args) {
      const result = originalVzGoUpsellStep2.apply(this, args);
      const body = document.getElementById('gc-tx-body') || document;
      vzRestoreUpsellFeatureSelection(body);
      if (typeof window.vzUpdateUpsellPreview === 'function') {
        window.vzUpdateUpsellPreview();
      }
      return result;
    };
  }

  if (typeof window.vzSetUpsellMode === 'function') {
    const originalVzSetUpsellMode = window.vzSetUpsellMode;
    window.vzSetUpsellMode = function patchedVzSetUpsellMode(...args) {
      vzCaptureUpsellFeatureSelectionFromDom();
      const result = originalVzSetUpsellMode.apply(this, args);
      const area = document.getElementById('gc-tx-body') || document;
      if (upsellMode === 'features') {
        vzRestoreUpsellFeatureSelection(area);
      }
      return result;
    };
  }
})();

// \u2500\u2500 Existing versions of steps that differ from Initial Sales (swapped in by setExistingAccountsMode) \u2500\u2500
const EXISTING_ACCOUNTS_OVERRIDES = {
  calcOption: function calcOption(opt, promoType = 'Standard', forcedTierIndex = -1) {
  const customPromotions = getActiveCustomPromotionsForPricing(opt);
  return VC.calcOption(opt, promoType, {
    prepareBundle: bundle => ({ ...bundle, msaDiscountPct: getOptionDiscountPct(opt, bundle) }),
    getTerm: option => proposalData.isAddOn && proposalData.segment !== 'Government' && !isSpecialOptionMode(option)
      ? (Number(option.term) || getMsaMonthsRemaining() || 36)
      : option.term,
    // Tier (Catalina, 2026-10-09): the MSA tier is already set, so it only changes with a Rewrap. Rewrap (and
    // Reactivation) count the vehicles contracted after the change \u2014 a partial cancellation lowers the count;
    // Create new proposal and Renewal keep the account's current MSA tier.
    getTierQty: (option, tierBundles, units) => isOptionTierLocked(option) ? getAccountMsaTierUnits() : units,
    getMsaTierUnits: bundle => bundle.isolatedTransactionType === 'cancel'
      ? -(Number(bundle.qty) || 0)
      : getMsaTierQty(bundle.qty, bundle.coreKey),
    getCustomPromotionAmount: (bundle, option, unitPrice) => customPromotions.length
      ? getCustomPromoAmountForBundle(bundle, customPromotions, 0, unitPrice)
      : 0,
    getBundleMonthly: (bundle, option, result, customPromoUnit) => vzIsFixedRateTx(bundle)
      ? (Number(bundle.basePrice) || 0) * (Number(bundle.qty) || 0)
      : Math.max(0, result.monthly - customPromoUnit * bundle.qty),
  });
},

  openConfigureBundle: function openConfigureBundle(optId, bundleId) {
  bld.targetOptId = optId || null;
  bld.targetBundleId = bundleId || null;

  const optionLabelEl = document.getElementById('bundle-option-label');
  if (optionLabelEl) {
    if (optId) {
      const optionIndex = options.findIndex((o) => o.id === optId);
      optionLabelEl.innerText = `Option ${Math.max(1, optionIndex + 1)}`;
    } else {
      optionLabelEl.innerText = `Option ${options.length + 1}`;
    }
  }

  const modal = document.querySelector('#bundle-overlay .bundle-modal');
  modal?.classList.remove('bundle-modal--transaction', 'bundle-modal--summary-shell');
  if (bundleId) {
    // Editing existing bundle \u2014 skip tx type step, go straight to configure
    if (modal) {
      modal.classList.remove('modal--md', 'bundle-modal--compact');
      modal.classList.add('modal--lg', 'bundle-modal--configure-solution', 'bundle-modal--summary-shell');
    }
    document.getElementById('bundle-step-tx-type').style.display = 'none';
    document.getElementById('bundle-step-configure').style.display = 'flex';
    document.querySelector('.bundle-mode-toggle')?.classList.add('hidden');
    document.querySelector('.upsell-mode-toggle')?.classList.add('hidden');
    document.getElementById('bundle-modal-title').innerText = 'Configure Solution';
    const panelTxEdit = document.getElementById('bundle-panel-tx');
    const panelAddEdit = document.getElementById('bundle-panel-add');
    if (panelTxEdit) panelTxEdit.style.display = 'none';
    if (panelAddEdit) panelAddEdit.style.display = 'flex';
    const editBundle = options.find(o => o.id === optId)?.bundles.find(b => b.id === bundleId);
    eaOpenExpansionForm(optId, editBundle);
    document.getElementById('btn-create').innerText = 'Update Solution';
  } else {
    // New bundle \u2014 show tx type selection first (compact)
    if (modal) {
      modal.classList.remove('modal--lg', 'bundle-modal--wide', 'bundle-modal--configure-solution', 'bundle-modal--summary-shell');
      modal.classList.add('modal--md', 'bundle-modal--compact');
    }
    _resetBundleTxTypeStep();
    document.getElementById('bundle-step-tx-type').style.display = 'flex';
    document.getElementById('bundle-step-configure').style.display = 'none';
    document.querySelector('.bundle-mode-toggle')?.classList.add('hidden');
    document.querySelector('.upsell-mode-toggle')?.classList.add('hidden');
    // 2026-09-18 (per Catalina): "New item" undersold what this modal does \u2014
    // it opens straight into a Feature Upsell / Expansion / Cancel-Downgrade
    // choice, none of which is a generic "item". "Modification" reads more
    // accurately in both Renewal/Rewrap and Create New Proposal.
    document.getElementById('bundle-modal-title').innerText = 'New modification';
  }
  document.getElementById('bundle-overlay').classList.add('is-open');
},

  createBundle: function createBundle() {
  const wasEditingExistingBundle = !!bld.targetOptId && !!bld.targetBundleId;
  const wasAddingToExistingOption = !!bld.targetOptId && !bld.targetBundleId;
  const optId = bld.targetOptId || nextOptId++;
  const sharedBundle = csBuildBundleData();
  if (!sharedBundle) return;
  const bundleData = {
    ...sharedBundle,
    msaDiscountPct: bld.msaDiscountPct || 0,
    ...(bld.txType === 'add'
      ? { isolatedTransactionType: 'add', txLabel: 'Expansion' }
      : {}),
    ...(sharedBundle.isPrebuilt
      ? { prebuiltBundleKey: sharedBundle.bundleKey, prebuiltTierKey: sharedBundle.tierKey }
      : {})
  };
  
  if (bld.targetOptId) {
     const opt = options.find(o => o.id === bld.targetOptId);
     if(opt) {
       if (bld.targetBundleId) {
         const idx = opt.bundles.findIndex(b => b.id === bld.targetBundleId);
         // 2026-09-17 (per Catalina): editing an existing bundle (e.g. reducing
         // its qty via the row's "Edit bundle" action) must not wipe out
         // originalQty \u2014 that field is what getBundleDelta() uses to detect
         // and render the reduced/cancelled state. Previously this replaced
         // the whole bundle object, silently losing originalQty and making an
         // intentionally-reduced bundle look like a brand-new "added" one.
         if (idx > -1 && opt.bundles[idx].originalQty !== undefined) {
           bundleData.originalQty = opt.bundles[idx].originalQty;
         }
         opt.bundles[idx] = bundleData;
       } else {
         opt.bundles.push(bundleData);
       }
     }
  } else {
     // F2: co-term for add-on orders (non-Gov); default to MSA remaining months
     const isCoTerm = proposalData.isAddOn && proposalData.segment !== 'Government';
     const accountDefaultTerm = typeof getDefaultContractTerm === 'function' ? getDefaultContractTerm() : 36; // 48 with seasonal (per Leo)
     const initTerm = isCoTerm ? (getMsaMonthsRemaining() ?? accountDefaultTerm) : accountDefaultTerm;
    options.push({ id: optId, name: 'Option ' + (options.length + 1), term: initTerm, bundles: [bundleData], waves: [], forcedTierIndex: -1, transactionMode: 'Change', effectiveDate: '', reason: '', discretionaryDiscountPct: proposalData.msaDiscretionaryDiscountPct || 0 });
  }
  
  closeBundleModal();
  renderOptions();
  document.getElementById('empty-state').classList.add('hidden');
  document.getElementById('options-grid').classList.remove('hidden');
  const optionNumber = options.findIndex((o) => o.id === optId) + 1;
  if (!bld.targetOptId) {
    logProposalEvent('Option created', `Option ${Math.max(1, optionNumber)} was created.`);
  } else if (wasEditingExistingBundle) {
    logProposalEvent('Option edited', `Option ${Math.max(1, optionNumber)} configuration was updated.`);
  } else if (wasAddingToExistingOption) {
    logProposalEvent('Option edited', `A new solution was added to Option ${Math.max(1, optionNumber)}.`);
  }
},

  getSubscriptionRowsForOption: function getSubscriptionRowsForOption(opt) {
  const rows = {};
  opt.bundles
    .filter(bundle => bundle.isolatedTransactionType !== 'cancel')
    .forEach(bundle => {
    getOrderPromotionComponents(bundle).forEach(component => {
      if (!rows[component.name]) rows[component.name] = { name: component.name, qty: 0, targets: [] };
      rows[component.name].qty += bundle.qty;
      if (!rows[component.name].targets.some(target => target.bundleId === bundle.id && target.component === component.name)) {
        rows[component.name].targets.push({ bundleId: bundle.id, component: component.name });
      }
    });
  });
  return Object.values(rows);
},

  getCustomPromoTableRows: function getCustomPromoTableRows(opt) {
  return getSubscriptionRowsForOption(opt);
},

  getCustomPromoCurrentPrice: function getCustomPromoCurrentPrice(opt, row) {
  return getCustomPromoTableRowCurrentPrice(opt, row);
},

  getCustomPromoTableRowCurrentPrice: function getCustomPromoTableRowCurrentPrice(opt, row) {
  const { tierQty } = calcOption(opt, getOptionPromotion(opt));
  return row.targets.reduce((sum, target) => {
    const bundle = opt.bundles.find(item => item.id === target.bundleId);
    if (!bundle) return sum;
    const component = getOrderPromotionComponents(bundle).find(item => item.name === target.component);
    if (!component) return sum;
    const currentUnit = calcBundle({
      ...bundle,
      promoName: '',
      msaDiscountPct: getOptionDiscountPct(opt, bundle),
    }, opt.term, 'Standard', tierQty).unitPrice;
    const basePrice = Number(bundle.basePrice) || 1;
    return sum + currentUnit * (component.listUnit / basePrice);
  }, 0);
},

  getCustomPromoAmountForBundle: function getCustomPromoAmountForBundle(bundle, customPromotions, tierTermPct, rawNetPrice, onlyComponent) {
  const components = getOrderPromotionComponents(bundle);
  const basePrice = Number(bundle.basePrice) || 1;
  return VC.customPromotionAmount({
    bundleId: bundle.id,
    promotions: customPromotions,
    components,
    onlyComponent,
    getAmount: (promotion, target, component) => {
      if (promotion.type === 'tier') return getTierPriceAmount(promotion, target, component, tierTermPct);
      const currentUnit = rawNetPrice * (component.listUnit / basePrice);
      const value = Number(target.value) || 0;
      const amount = promotion.type === 'dollar'
        ? value
        : promotion.type === 'target'
          ? Math.max(0, currentUnit - value)
          : currentUnit * (value / 100);
      return Math.min(currentUnit, amount);
    },
  });
},

  computeCustomPromoTimelineTotals: function computeCustomPromoTimelineTotals(opt, promotion) {
  // 2026-10-05 fix (per Leo, 2026-10-02 call): the legend now uses the same
  // engine as the drawer footer / option card (computeOptionSummaryTotals), so
  // "Promotion" = Monthly Promo Price and "After promo" = that monthly plus
  // this promotion's own $ amount.
  const { promoTotal } = computeOptionSummaryTotals(opt);
  const { tierQty, term } = calcOption(opt, getOptionPromotion(opt));
  const tierTermPct = getTierTermDiscountPct(term, tierQty);
  let promoAmount = 0;
  if (customPromoHasAnyValue(promotion)) {
    opt.bundles.forEach(bundle => {
      const bundlePromo = bundle.promoType || getOptionPromotion(opt);
      const pricedBundle = { ...bundle, msaDiscountPct: getOptionDiscountPct(opt, bundle) };
      const { unitPrice: rawNetPrice } = calcBundle(pricedBundle, term, bundlePromo, tierQty);
      promoAmount += getCustomPromoAmountForBundle(bundle, [promotion], tierTermPct, rawNetPrice) * bundle.qty;
    });
  }
  if (opt.pilot?.pricingMode === 'free') promoAmount = 0;
  return { totalCurrent: promoTotal + promoAmount, totalDuringPromo: promoTotal };
},

  computeBundlePriceList: function computeBundlePriceList(opt) {
  const { tierQty, term } = calcOption(opt, getOptionPromotion(opt));
  const activeCustomPromotions = getActiveCustomPromotionsForPricing(opt);
  return opt.bundles.map(bundle => {
    const promoType = bundle.promoType || getOptionPromotion(opt);
    const priced = { ...bundle, msaDiscountPct: getOptionDiscountPct(opt, bundle) };
    const netUnitBeforeCustom = calcBundle(priced, opt.term, promoType, tierQty).unitPrice;
    const noOrderPromoUnit = calcBundle({ ...priced, promoName: '' }, opt.term, 'Standard', tierQty).unitPrice;
    const customPromoUnit = getCustomPromoAmountForBundle(bundle, activeCustomPromotions, 0, netUnitBeforeCustom);
    const netUnit = Math.max(0, netUnitBeforeCustom - customPromoUnit);
    const orderPromoUnit = Math.max(0, noOrderPromoUnit - netUnitBeforeCustom) + customPromoUnit;
    const listUnit = Number(bundle.basePrice) || 0;
    const tierTermPct = calcBundle({ ...bundle, msaDiscountPct: 0, promoName: '' }, opt.term, 'Standard', tierQty).tierTermPct || 0;
    const afterTierTermUnit = listUnit * (1 - tierTermPct / 100);
    return {
      name: bundle.coreName || corePricing[bundle.coreKey]?.name || bundle.coreKey,
      qty: bundle.qty,
      listUnit,
      tierTermUnit: Math.max(0, listUnit - afterTierTermUnit),
      tierTermPct,
      discretionaryUnit: Math.max(0, afterTierTermUnit - noOrderPromoUnit),
      msaUnit: noOrderPromoUnit,
      orderPromoUnit,
      netUnit,
    };
  });
},

  buildSubscriptionPriceListHtml: function buildSubscriptionPriceListHtml(opt, context = 'drawer', promoDraftByCore = null) {
  // 2026-10-02 (per Catalina): Frequency column only for a mixed account
  // (Billing model = Both) with at least one Capex bundle in this option.
  const showFrequency = accountBillingModel === 'both' && opt.bundles.some(bundle => bundle.billingModel === 'capex');
  if (!opt.bundles.length) return `<p class="text-body-small" style="color:var(--gray-600);">No subscriptions configured yet.</p>`;
  const { tierQty, term } = calcOption(opt, getOptionPromotion(opt));
  const activeCustomPromotions = getActiveCustomPromotionsForPricing(opt);
  let monthlyBeforeChanges = 0;
  let monthlyAfterChanges = 0;
  let monthlyAfterTierTerm = 0;
  let orderPromoTotal = 0;
  const blocks = opt.bundles.map(bundle => {
    const draftPromo = promoDraftByCore ? promoDraftByCore[bundle.coreKey] : null;
    const previewBundle = draftPromo
      ? { ...bundle, promoType: draftPromo.promoType, promoName: draftPromo.promoName, dealCloser: draftPromo.dealCloser }
      : bundle;
    const promoType = draftPromo ? draftPromo.promoType : (bundle.promoType || getOptionPromotion(opt));
    const priced = { ...previewBundle, msaDiscountPct: getOptionDiscountPct(opt, bundle) };
    const netUnitBeforeCustom = calcBundle(priced, term, promoType, tierQty).unitPrice;
    const noOrderPromoUnit = calcBundle({ ...priced, promoName: '' }, term, 'Standard', tierQty).unitPrice;
    const tierTermPct = calcBundle({ ...bundle, msaDiscountPct: 0, promoName: '' }, term, 'Standard', tierQty).tierTermPct || 0;
    const discretionaryPct = getOptionDiscountPct(opt, bundle);
    const components = getOrderPromotionComponents(bundle).map(component => {
      const share = (Number(bundle.basePrice) || 1) > 0 ? component.listUnit / (Number(bundle.basePrice) || 1) : 0;
      const afterTierTerm = VC.priceListUnitBreakdown({ listUnit: component.listUnit, tierTermPct }).afterTierTermUnit;
      // 2026-10-02: a contract-level "Create a Custom Discount" (Renewal /
      // Rewrap MSA Discount tab) lowers the MSA Price itself \u2014 it replaces the
      // discount program \u2014 while order-level custom promotions stay in
      // Promotion / Discount. Same $ basis as the option card totals.
      const contractCustomAmount = getCustomPromoAmountForBundle(bundle, activeCustomPromotions.filter(promotion => promotion.level === 'contract'), tierTermPct, netUnitBeforeCustom, component.name);
      const orderCustomAmount = getCustomPromoAmountForBundle(bundle, activeCustomPromotions.filter(promotion => promotion.level !== 'contract'), tierTermPct, netUnitBeforeCustom, component.name);
      const msaUnit = VC.priceListUnitBreakdown({
        listUnit: component.listUnit,
        tierTermPct,
        discretionaryPct,
        msaUnitOverride: Math.max(0, afterTierTerm * (1 - discretionaryPct / 100) - contractCustomAmount),
      }).msaUnit;
      const afterPromo = Math.max(0, netUnitBeforeCustom * share - contractCustomAmount - orderCustomAmount);
      const orderPromo = Math.max(0, msaUnit - afterPromo);
      return { name: component.name, standardUnit: component.listUnit, discretionaryUnit: Math.max(0, afterTierTerm - msaUnit), msaUnit, orderPromo, afterPromo };
    });
    const monthlyBefore = components.reduce((sum, component) => sum + component.msaUnit, 0) * bundle.qty;
    const monthlyAfter = components.reduce((sum, component) => sum + component.afterPromo, 0) * bundle.qty;
    const bundleOrderPromo = components.reduce((sum, component) => sum + component.orderPromo, 0) * bundle.qty;
    monthlyBeforeChanges += monthlyBefore;
    monthlyAfterTierTerm += components.reduce((sum, component) => sum + component.msaUnit + component.discretionaryUnit, 0) * bundle.qty;
    monthlyAfterChanges += monthlyAfter;
    orderPromoTotal += bundleOrderPromo;
    const headerPrice = monthlyAfter;
    return `<div class="subscription-summary-block" data-bundle-id="${bundle.id}">
      <div class="subscription-summary-head"><span>${bundle.coreName}<span class="subscription-summary-head-sep"></span><span class="subscription-summary-head-qty"><span class="subscription-summary-head-qty-label">QTY</span> <span class="subscription-summary-head-qty-num">${bundle.qty}</span></span></span><span class="subscription-summary-head-price">${formatMoney(headerPrice)}</span></div>
      <table class="bundle-summary-components">
        <thead><tr><th class="bundle-summary-components-header">Subscriptions</th>${showFrequency ? '<th class="bundle-summary-components-header bundle-summary-components-header--freq">Frequency</th>' : ''}<th class="bundle-summary-components-header bundle-summary-components-header--num">List Price</th><th class="bundle-summary-components-header bundle-summary-components-header--num">Contracted Price</th><th class="bundle-summary-components-header bundle-summary-components-header--num">Promotions</th><th class="bundle-summary-components-header bundle-summary-components-header--num">Promo Price</th></tr></thead>
        <tbody>${components.map(component => `<tr><td class="bundle-summary-components-cell bundle-summary-components-cell--name">${component.name}</td>${showFrequency ? '<td class="bundle-summary-components-cell bundle-summary-components-cell--freq">Monthly</td>' : ''}<td class="bundle-summary-components-cell bundle-summary-components-cell--num">${formatMoney(component.standardUnit)}</td><td class="bundle-summary-components-cell bundle-summary-components-cell--num${component.discretionaryUnit > 0.005 ?' price-amount--msa-discount' : ''}">${formatMoney(component.msaUnit)}</td><td class="bundle-summary-components-cell bundle-summary-components-cell--num${component.orderPromo > 0.005 ?' price-amount--order-discount' : ''}">${component.orderPromo > 0.005 ? `-${formatMoney(component.orderPromo)}` : formatMoney(0)}</td><td class="bundle-summary-components-cell bundle-summary-components-cell--num">${formatMoney(component.afterPromo)}</td></tr>`).join('')}${accountBillingModel === 'both' && bundle.billingModel === 'capex' && getEstimatedHardwareUnitPrice(bundle) > 0.005 ? buildDrawerHardwareRowHtml('Hardware', getEstimatedHardwareUnitPrice(bundle)) : ''}</tbody>
      </table>
    </div>`;
  }).join('');
  // 2026-10-02 (per Leo): Order-discount-level amounts read blue.
  // 2026-10-02 (per Catalina): same footer as New Accounts \u2014 Monthly Total (at MSA
  // Price), one blue Promotion / Discount line, then Monthly Promo Price.
  const footerPromoAmount = Math.max(0, monthlyBeforeChanges - monthlyAfterChanges);
  // 2026-10-02 (per Catalina): MSA Discount line (green) \u2014 Monthly Total now starts after Tier/Term, so Monthly Total \u2212 MSA Discount \u2212 Promotion / Discount = Monthly Promo Price.
  const footerMsaDiscountAmount = Math.max(0, monthlyAfterTierTerm - monthlyBeforeChanges);
  const msaDiscountLine = footerMsaDiscountAmount > 0.005 ? `<div class="subscription-summary-line price-amount--msa-discount"><span>Account Discount</span><span>\u2212${formatMoney(footerMsaDiscountAmount)}</span></div>` : '';
  const orderPromoLine = footerPromoAmount > 0.005 ? `<div class="subscription-summary-line price-amount--order-discount"><span>Promotions</span><span>\u2212${formatMoney(footerPromoAmount)}</span></div>` : '';
  const totalsFooter = `<div class="subscription-summary-totals"><div class="subscription-summary-line"><span>Monthly Total</span><span>${formatMoney(monthlyAfterTierTerm)}</span></div>${msaDiscountLine}${orderPromoLine}<div class="subscription-summary-line subscription-summary-line--strong"><span>Monthly Promo Price</span><span>${formatMoney(monthlyAfterChanges)}</span></div></div>`;
  return `<div class="subscription-summary-scroll">${blocks}</div>${totalsFooter}`;
},

  computeOptionSummaryTotals: function computeOptionSummaryTotals(opt) {
  const { tierQty, term } = calcOption(opt, getOptionPromotion(opt));
  const tierTermPct = getTierTermDiscountPct(term, tierQty);
  const customPromotions = getCustomPromotions(opt).filter(promotion => customPromoHasAnyValue(promotion) && Array.isArray(promotion.targets) && promotion.targets.length > 0);
  return VC.aggregateOptionTotals(opt, bundle => {
    const isIsolatedCancel = vzIsFixedRateTx(bundle);
    const listPrice = getStandardUnitPrice(bundle);
    const priceBreakdown = VC.priceListUnitBreakdown({
      listUnit: listPrice,
      tierTermPct: isIsolatedCancel ? 0 : tierTermPct,
      discretionaryPct: getOptionDiscountPct(opt, bundle),
    });
    const afterTierTerm = priceBreakdown.afterTierTermUnit;
    const msaPrice = priceBreakdown.msaUnit;
    const bundlePromo = bundle.promoType || getOptionPromotion(opt);
    const pricedBundle = { ...bundle, msaDiscountPct: getOptionDiscountPct(opt, bundle) };
    const { unitPrice: rawNetPrice, monthly: rawMonthly } = calcBundle(pricedBundle, term, bundlePromo, tierQty);
    const customAmountPerUnit = getCustomPromoAmountForBundle(bundle, customPromotions, tierTermPct, rawNetPrice);
    // 2026-10-02: a contract-level Custom Discount (MSA Discount tab) lowers
    // the card's MSA Price too, not just the promo total.
    const contractCustomPerUnit = getCustomPromoAmountForBundle(bundle, customPromotions.filter(promotion => promotion.level === 'contract'), tierTermPct, rawNetPrice);
    return {
      // 2026-10-15 (per Catalina): the option QTY is the net change in units — cancelled units count negative and a
      // Feature Upsell adds nothing; Reactivation counts each physical unit once even when it restores several subscriptions.
      qty: bundle.isMsaAuxiliary && bundle.isolatedTransactionType === 'cancel' ? -(Number(bundle.qty) || 0)
        : (bundle.isMsaAuxiliary && bundle.isolatedTransactionType === 'upsell' ? 0
          : (bundle.isMsaAuxiliary && bundle.isolatedTransactionType === 'reactivate' ? (Number(bundle.reactivatedUnitQty ?? bundle.qty) || 0) : bundle.qty)),
      listTotal: listPrice * bundle.qty,
      msaTotal: isIsolatedCancel ? (Number(bundle.basePrice) || 0) * bundle.qty : Math.max(0, msaPrice - contractCustomPerUnit) * bundle.qty,
      promoTotal: isIsolatedCancel ? (Number(bundle.basePrice) || 0) * bundle.qty : Math.max(0, rawMonthly - customAmountPerUnit * bundle.qty),
      capexHardwareOneTime: !isIsolatedCancel && bundle.billingModel === 'capex' ? getEstimatedHardwareUnitPrice(bundle) * bundle.qty : 0,
      keyfobOneTime: !isIsolatedCancel && typeof getBundleKeyfobOneTime === 'function' ? getBundleKeyfobOneTime(bundle) : 0,
    };
  }, {
    initialTotals: { qty: 0, listTotal: 0, msaTotal: 0, promoTotal: 0, capexHardwareOneTime: 0, keyfobOneTime: 0 },
    adjustTotals: totals => {
      if (opt.pilot?.pricingMode === 'free') { totals.promoTotal = 0; totals.capexHardwareOneTime = 0; totals.keyfobOneTime = 0; }
      return totals;
    },
  });
},

  buildOptionSummaryStripHtml: function buildOptionSummaryStripHtml(opt) {
  if (!opt.bundles.length) return '';
  // 2026-10-14 (per Catalina): same summary as Initial Sales on every existing-account option; 2026-10-16: one-time
  // charges (Capex hardware + extra keyfobs) follow the Simulation Builder choice (buildOneTimeAwareTotalsRow).
  const { qty, listTotal, msaTotal, promoTotal, capexHardwareOneTime, keyfobOneTime } = computeOptionSummaryTotals(opt);
  return buildOneTimeAwareTotalsRow({
    qty, listTotal, msaTotal, promoTotal,
    oneTime: (capexHardwareOneTime || 0) + (keyfobOneTime || 0),
    qtyCellExtras: { valueClassName: `opt-totals-value--qty${qty < 0 ? ' opt-totals-value--negative' : ''}` },
  });
},

  renderOptions: function renderOptions() {
  setTimeout(() => { if (typeof updateApprovalSnackbar === 'function') { updateApprovalSnackbar(); updateMarkDeadBtn(); renderMsaContextBar(); } }, 0);
  updateDraftingHeaderTitle();
  const grid = document.getElementById('options-grid');
  grid.innerHTML = '';
  const currentPanel = document.getElementById('current-proposal-panel');
  if (currentPanel) {
    const wasCollapsed = currentPanel.classList.contains('is-collapsed');
    currentPanel.innerHTML = renderCurrentProposalCard();
    currentPanel.classList.toggle('is-collapsed', wasCollapsed);
    const toggleIcon = currentPanel.querySelector('[data-current-toggle-icon]');
    const toggleButton = currentPanel.querySelector('.current-proposal-header-actions button:last-child');
    if (toggleIcon) toggleIcon.textContent = wasCollapsed ? 'chevron_right' : 'chevron_left';
    if (toggleButton) {
      toggleButton.setAttribute('aria-label', wasCollapsed ? 'Expand Current' : 'Collapse Current');
      toggleButton.title = wasCollapsed ? 'Expand Current' : 'Collapse Current';
    }
  }

  // Update Header Labels
  const nameEls = document.querySelectorAll('.header-prop-name');
  nameEls.forEach(el => el.innerText = proposalData.name);
  
  const promoEls = document.querySelectorAll('.header-prop-promo');
  promoEls.forEach(el => el.innerText = proposalData.promoType);
  
  // Tier label \u2014 per-option now; show summary in header
  const tierEls = document.querySelectorAll('.header-prop-tier');
  const forcedOpts = options.filter(o => (o.forcedTierIndex !== undefined ? o.forcedTierIndex : -1) !== -1);
  const isApproved = proposalData.approvalStatus === 'Approved';
  const isForced = forcedOpts.length > 0;
  tierEls.forEach(el => {
    if (!isForced) {
      el.innerText = 'Auto';
    } else if (isApproved) {
      el.innerHTML = `Forced <span class="tier-status tier-status-approved">(Approved)</span>`;
    } else {
      el.innerHTML = `Forced <span class="tier-status tier-status-pending">(Approval required)</span>`;
    }
  });


// 2026-11-03 (per Leo via Catalina): the Current setup can be read by solution (default, like the option cards) or by
// subscription (like the Price List).
var currentSetupView = 'solutions'; // var: the panel can render before this line runs
window.setCurrentSetupView = function setCurrentSetupView(view) {
  currentSetupView = view === 'subscriptions' ? 'subscriptions' : 'solutions';
  const panel = document.getElementById('current-proposal-panel');
  if (panel) panel.innerHTML = renderCurrentProposalCard();
};

window.setCurrentSetupContractAccount = function setCurrentSetupContractAccount(contractAccountId) {
  const validIds = new Set(['all', ...DEMO_CONTRACT_ACCOUNTS.map(account => account.id)]);
  if (!validIds.has(contractAccountId)) return;
  unifiedAccount.currentSetupContractAccountId = contractAccountId;
  if (typeof syncUnifiedScenarioUrl === 'function') syncUnifiedScenarioUrl();
  const panel = document.getElementById('current-proposal-panel');
  if (panel) panel.innerHTML = renderCurrentProposalCard();
};

function renderCurrentProposalCard() {
  // 2026-11-04 (Migrations): a legacy account shows its legacy panel instead (js/migration.js).
  if (typeof migrationModeOn !== 'undefined' && migrationModeOn && typeof renderMigrationLegacyPanel === 'function') return renderMigrationLegacyPanel();
  const multipleContractAccounts = unifiedAccount.accountType === 'customer' && unifiedAccount.hasMultipleContractAccounts;
  const allCurrentOrders = multipleContractAccounts ? getContractAccountOrders() : (Array.isArray(existingOrders) ? existingOrders : []);
  const currentSetupContractAccountId = multipleContractAccounts ? (unifiedAccount.currentSetupContractAccountId || 'all') : 'all';
  const currentOrders = currentSetupContractAccountId === 'all'
    ? allCurrentOrders
    : allCurrentOrders.filter(order => order.contractAccountId === currentSetupContractAccountId);
  const isReactivation = options.some(option => option.transactionMode === 'Reactivation');
  const currentSetupTitle = isReactivation ? 'Previous setup' : 'Current setup';
  // 2026-10-14 (per Catalina): no "Read-only reference" caption.
  const currentSetupCaption = '';
  const currentBundles = currentOrders.flatMap((order) => order.bundles || []);
  const totalUnits = currentBundles.reduce((sum, bundle) => sum + (bundle.qty || 0), 0);
  const totalMonthly = multipleContractAccounts
    ? calcOption({ bundles: currentBundles, term: currentOrders[0]?.term || 36 }, 'Standard', -1).totalMonthly
    : currentOrders.reduce((sum, order) => {
        return sum + calcOption({ bundles: order.bundles || [], term: order.term || 36 }, 'Standard', -1).totalMonthly;
      }, 0);
  const avgUnit = totalUnits > 0 ? totalMonthly / totalUnits : 0;
  const orderLabel = currentOrders.length === 1 ? currentOrders[0].name : `${currentOrders.length} active orders`;
  // 2026-09-18 (R21.4 correction, per the 2026-09-17 meeting transcript \u2014 Leo:
  // "we need to add to the left we need to add the band... because we need to
  // say the band needs to say... the 32"): the subscription count (which
  // drives the band/tier, e.g. camera bundles count double) wasn't visible
  // anywhere on the account's real, currently-contracted setup \u2014 only the
  // vehicle count was. This lives on the "Current" panel itself (the one
  // already built in R17.5), not on Account Setup \u2014 that's a separate,
  // still-pending item (R16).
  const accountBundles = (Array.isArray(existingOrders) ? existingOrders : []).flatMap(order => order.bundles || []);
  const currentMsaTierUnits = sumMsaTierQty(accountBundles);
  // 2026-09-18 (per Catalina): show the tier's actual range alongside the
  // discount \u2014 reuses the same MSA_DISCOUNT_TIERS min/max already driving
  // the quantity band.
  const currentBandTier = getMsaDiscountTier(currentMsaTierUnits);
  const currentBandRange = currentBandTier.max >= 9999 ? `${currentBandTier.min}+` : `${currentBandTier.min}–${currentBandTier.max}`;
  // R29 (2026-09-23): the Tier/Term discount needs a term, not just quantity \u2014
  // uses the account's actual current MSA term (all current orders share it).
  const currentTierTermMonths = DEMO_MSA?.termMonths || currentOrders[0]?.term || 36;

  const parentAccountUnits = accountBundles.reduce((sum, bundle) => sum + (Number(bundle.qty) || 0), 0);
  // 2026-11-03 (per Catalina): the Current setup lists SOLUTIONS, like the option cards — each row shows its features
  // (Video / Vehicle features lines, as on the cards) so two rows with the same core aren't read as duplicates, and
  // identical solutions (same core, features and promotion, e.g. from different orders) are merged into one row.
  const solutionKey = (b) => [b.coreKey, (Array.isArray(b.features) ? b.features.slice().sort() : []).join('+'), b.evcType || '', b.promoType || 'Standard', String(b.promoName || '').trim()].join('|');
  const currentFeatureLinesHtml = (b) => {
    const keys = Array.isArray(b.features) ? b.features : [];
    const isVideoCore = b.coreKey === 'vtu-ffc' || b.coreKey === 'vtu-dual';
    let video = keys.filter(k => ['sd-256', 'adas', 'evc', 'monitor'].includes(k)).map(k => featureLabels[k] || k);
    if (isVideoCore && !keys.includes('sd-256')) video = ['128 GB SD Card', ...video];
    const vehicle = keys.filter(k => ['driver-id', 'privacy', 'logbook'].includes(k)).map(k => featureLabels[k] || k);
    return (video.length ? `<div class="bundle-feature-line"><strong>Video:</strong> ${video.join(', ')}</div>` : '') +
      (vehicle.length ? `<div class="bundle-feature-line"><strong>Vehicle features:</strong> ${vehicle.join(', ')}</div>` : '') +
      (keys.some(k => SOFTWARE_FEATURE_KEYS.includes(k)) ? `<div class="bundle-feature-line"><strong>Software features:</strong> ${keys.filter(k => SOFTWARE_FEATURE_KEYS.includes(k)).map(k => featureLabels[k] || k).join(', ')}</div>` : '');
  };
  // 2026-11-03 (per Leo via Catalina): applied promotions (time-bound, e.g. months 1–6) show as one short line on the
  // row that has them; the row's price is what the account pays today.
  const promoMult = (b) => 1 - ((b.currentPromo && Number(b.currentPromo.pct)) || 0) / 100;
  const promoLineHtml = (promo) => promo
    ? `<span class="material-symbols-outlined" aria-hidden="true">sell</span><span>${promo.name} \u2212${promo.pct}% \u00b7 ends ${promo.endsLabel}</span>`
    : '';
  const termOf = (bundle) => (currentOrders.find((candidate) => (candidate.bundles || []).includes(bundle))?.term) || 36;

  // View 1 — Solutions (default): like the option cards.
  const groupedSolutions = [];
  currentBundles.forEach((bundle) => {
    const priced = calcBundle(bundle, termOf(bundle), bundle.promoType || 'Standard', parentAccountUnits);
    // 2026-11-04 (per Leo via Catalina): no promotion per solution — rows show the contract price (identical solutions
    // merge even if one order has a promotion); the promotions only show in the total (Contract MRR, then Promo MRR — same order as the option cards).
    const monthly = priced.monthly;
    const key = solutionKey(bundle);
    const found = groupedSolutions.find(g => g.key === key);
    if (found) { found.qty += bundle.qty || 0; found.monthly += monthly; found.promoMonthly += monthly * promoMult(bundle); }
    else groupedSolutions.push({ key, bundle, qty: bundle.qty || 0, monthly, promoMonthly: monthly * promoMult(bundle) });
  });
  const solutionRows = groupedSolutions.map(({ bundle, qty, monthly }) => {
    const unitPrice = qty > 0 ? monthly / qty : 0;
    const standardUnitPrice = getStandardUnitPrice(bundle);
    const discountPct = standardUnitPrice > 0 ? Math.round((1 - unitPrice / standardUnitPrice) * 100) : 0;
    const isVideo = bundle.coreKey === 'vtu-ffc' || bundle.coreKey === 'vtu-dual';
    const hasNamedPromo = !!String(bundle.promoName || '').trim();
    const hasMediaPromo = bundle.promoType === 'Media' && isVideo;
    return {
      name: bundle.coreName,
      qty,
      featuresHtml: currentFeatureLinesHtml(bundle),
      monthlyHtml: formatMoney(monthly),
      monthly,
      unitHtml: formatMoney(unitPrice),
      listHtml: discountPct > 0 ? formatMoney(standardUnitPrice) : '',
      discountPct: discountPct > 0 ? discountPct : 0,
      promoMonthly: groupedSolutions.find(g => g.bundle === bundle)?.promoMonthly || monthly,
      promoLabel: '',
    };
  });

  // View 2 — Subscriptions: like the Price List (Vehicle Tracking, each camera, features as their own lines).
  // Units with a promotion stay on their own line.
  const subscriptionGroups = [];
  currentBundles.forEach((bundle) => {
    const tierTermPct = getTierTermDiscountPct(termOf(bundle), parentAccountUnits);
    getBundleComponentPrices(bundle, tierTermPct).forEach((component) => {
      const key = component.name + '|' + (bundle.currentPromo ? bundle.currentPromo.name : '');
      const qty = bundle.qty || 0;
      const monthly = component.msaUnit * promoMult(bundle) * qty;
      const found = subscriptionGroups.find(g => g.key === key);
      if (found) { found.qty += qty; found.monthly += monthly; found.listTotal += component.listUnit * qty; }
      else subscriptionGroups.push({ key, name: component.name, core: component.core, promo: bundle.currentPromo || null, qty, monthly, listTotal: component.listUnit * qty });
    });
  });
  // Price List order: core subscriptions first, the same subscription's lines together (without promotion first).
  const firstSeen = new Map();
  subscriptionGroups.forEach((g, i) => { if (!firstSeen.has(g.name)) firstSeen.set(g.name, i); });
  subscriptionGroups.sort((a, b) => ((b.core ? 1 : 0) - (a.core ? 1 : 0)) || (firstSeen.get(a.name) - firstSeen.get(b.name)) || ((a.promo ? 1 : 0) - (b.promo ? 1 : 0)));
  const subscriptionRows = subscriptionGroups.map((g) => {
    const unitPrice = g.qty > 0 ? g.monthly / g.qty : 0;
    const listUnit = g.qty > 0 ? g.listTotal / g.qty : 0;
    return {
      name: g.name,
      qty: g.qty,
      monthlyHtml: formatMoney(g.monthly),
      monthly: g.monthly,
      unitHtml: formatMoney(unitPrice),
      listHtml: listUnit - unitPrice > 0.005 ? formatMoney(listUnit) : '',
      promoHtml: promoLineHtml(g.promo),
    };
  });

  // 2026-11-04 (per Catalina): the Solutions | Subscriptions switch is hidden for now — always Solutions. To bring it
  // back, pass viewToggleHtml again and use currentSetupView here.
  const view = 'solutions';
  const rows = view === 'subscriptions' ? subscriptionRows : solutionRows;
  const contractMrr = solutionRows.reduce((sum, row) => sum + row.monthly, 0);
  const promoMrr = solutionRows.reduce((sum, row) => sum + row.promoMonthly, 0);
  // Like Configure Solution's Capex model (Month 1 / Month 2+): two values side by side when a promotion applies.
  const hasPromos = currentBundles.length && contractMrr - promoMrr > 0.005;
  const totalsHtml = hasPromos ? `<div class="monthly-total">
      <div class="vc-field-label current-proposal-total-label"><span>Monthly total</span><span class="current-proposal-total-qty">QTY ${totalUnits}</span></div>
      <div class="preview-capex-summary current-proposal-mrr">
        <div class="preview-capex-box"><div class="preview-capex-box-title">Contract MRR</div><div class="preview-capex-box-total">${formatMoney(contractMrr)}<small>/mo</small></div></div>
        <div class="preview-capex-box"><div class="preview-capex-box-title">Promo MRR</div><div class="preview-capex-box-total">${formatMoney(promoMrr)}<small>/mo</small></div></div>
      </div>
    </div>` : '';
  const viewToggleHtml = `<div class="segmented-pill" role="group" aria-label="Current setup view">${[['solutions', 'Solutions'], ['subscriptions', 'Subscriptions']].map(([value, label]) =>
    `<button type="button" class="segmented-pill__btn${view === value ? ' is-active' : ''}" aria-pressed="${view === value}" onclick="setCurrentSetupView('${value}')">${label}</button>`).join('')}</div>`;

  return VC.currentSetupPanel({
    title: currentSetupTitle,
    caption: currentSetupCaption,
    totalUnits,
    monthlyHtml: formatMoney(currentBundles.length ? contractMrr : totalMonthly),
    totalsHtml,
    // 2026-10-14 (per Catalina): no avg unit price or tier under the monthly total (the tier is in the MSA panel).
    bundles: rows,
    listTitle: 'Active solutions',
    emptyText: view === 'subscriptions' ? 'No active subscriptions' : 'No active solutions',
    headerFiltersHtml: multipleContractAccounts ? `<label class="vc-current-setup-filter vc-current-setup-filter--inline"><select class="select select--small" data-vc-dropdown aria-label="Filter Current Setup by Contract Account" onchange="setCurrentSetupContractAccount(this.value)"><option value="all"${currentSetupContractAccountId === 'all' ? ' selected' : ''}>All contract accounts</option>${DEMO_CONTRACT_ACCOUNTS.map(account => `<option value="${account.id}"${currentSetupContractAccountId === account.id ? ' selected' : ''}>${account.name}</option>`).join('')}</select></label>` : '',
  });
}


// 2026-09-17 (per Catalina): shared builder so any entry point that should
// "start from Current" (the Same as Current tx-type, and now Upsell/Add when
// creating a brand-new option) uses the exact same seed data \u2014 previously
// only the standalone Duplicate button used this, so Upsell/Add created a
// bare new option unrelated to Current instead of building on top of it.
window.createOptionFromCurrent = function createOptionFromCurrent(name) {
  const currentOrders = Array.isArray(existingOrders) ? existingOrders : [];
  if (!currentOrders.length) return null;
  const opt = {
    id: nextOptId++,
    name: name || ('Option ' + (options.length + 1)),
    term: currentOrders[0].term || 36,
    forcedTierIndex: -1,
    transactionMode: 'Change',
    effectiveDate: '',
    reason: '',
    discretionaryDiscountPct: proposalData.msaDiscretionaryDiscountPct || 0,
    // 2026-09-18 (R22 prep, per Catalina): bundles seeded straight from
    // existingOrders never had an `id` \u2014 harmless while Edit/Delete were the
    // only consumers (R21.5 now hides those buttons for any bundle with
    // originalQty anyway), but vzGenerateSubscriptions()'s bundleId grouping
    // (used by the Upsell matching engine, R22) needs a real, unique id per
    // bundle to tell them apart. Assign one if the source didn't have one.
    bundles: currentOrders.flatMap(order => order.bundles || []).map((bundle, i) => ({
      ...JSON.parse(JSON.stringify(bundle)),
      id: bundle.id ?? (Date.now() + i),
      originalQty: bundle.qty
    })),
    waves: []
  };
  options.push(opt);
  return opt;
}

window.createEmptyTransactionOption = function createEmptyTransactionOption(txType) {
  const currentOrders = Array.isArray(existingOrders) ? existingOrders : [];
  const opt = {
    id: nextOptId++,
    name: 'Option ' + (options.length + 1),
    term: currentOrders[0]?.term || 36,
    forcedTierIndex: -1,
    transactionMode: 'Change',
    effectiveDate: '',
    reason: '',
    discretionaryDiscountPct: proposalData.msaDiscretionaryDiscountPct || 0,
    bundles: [],
    waves: [],
    isolatedTransactionType: txType,
    pendingTransaction: true
  };
  options.push(opt);
  return opt;
}

const closeTransactionBundleModal = window.closeBundleModal;
window.closeBundleModal = function closeBundleModalWithTransactionCleanup() {
  const pendingCount = options.filter(opt => opt.pendingTransaction && !opt.bundles.length).length;
  options = options.filter(opt => !opt.pendingTransaction || opt.bundles.length);
  options.forEach(opt => { if (opt.pendingTransaction) delete opt.pendingTransaction; });
  closeTransactionBundleModal();
  if (pendingCount) {
    renderOptions();
    updateEmptyStateCopy();
    document.getElementById('empty-state')?.classList.toggle('hidden', options.length > 0);
    document.getElementById('options-grid')?.classList.toggle('hidden', !options.length);
  }
};

window.editIsolatedTransaction = function editIsolatedTransaction(optId, bundleId) {
  const opt = options.find(candidate => candidate.id === optId);
  const bundle = opt?.bundles?.find(candidate => candidate.id === bundleId);
  if (!bundle?.isolatedTransactionType) return openConfigureBundle(optId, bundleId);
  txPreselectedSubIds = Array.isArray(bundle.selectedSubIds) ? [...bundle.selectedSubIds] : [];
  openConfigureBundle(optId);
  bld.targetBundleId = bundleId;
  selectBundleTxType(bundle.isolatedTransactionType);
  confirmBundleTxType();
  // 2026-11-05 (per Catalina): editing an upsell opens on the step it started from; the Upsell Summary already shows
  // what was added (see vzUpdateUpsellPreview).
  if (bundle.isolatedTransactionType === 'upsell' && typeof vzUpdateUpsellPreview === 'function') vzUpdateUpsellPreview();
}

window.duplicateCurrentAsOption = function duplicateCurrentAsOption(event) {
  event?.stopPropagation();
  const opt = createOptionFromCurrent();
  if (!opt) return;
  renderOptions();
  document.getElementById('empty-state')?.classList.add('hidden');
  document.getElementById('options-grid')?.classList.remove('hidden');
  logProposalEvent('Option created', `Option ${options.length} was duplicated from Current.`);
}

function getBundleDelta(bundle) {
  if (bundle.originalQty === undefined) return { type: 'added', amount: bundle.qty || 0 };
  const originalQty = Number(bundle.originalQty) || 0;
  const qty = Number(bundle.qty) || 0;
  if (qty === 0 && originalQty > 0) return { type: 'cancelled', amount: originalQty };
  if (qty > 0 && qty < originalQty) return { type: 'reduced', amount: originalQty - qty };
  // 2026-09-18 (R22, per Catalina): a bundle that already existed (has an
  // originalQty) can also GROW \u2014 e.g. an Upsell moving units in from another
  // bundle once their features match this one. Treat that the same as
  // "added" visually (green border + badge), just with the exact count.
  if (qty > originalQty) return { type: 'increased', amount: qty - originalQty };
  return null;
}

window.getVZBundleSubscriptionId = function getVZBundleSubscriptionId(bundle, index) {
  const bundleKey = bundle.id ?? `${bundle.coreKey || 'bundle'}-${bundle.coreName || 'unknown'}`;
  return `SUB-VZ-${String(bundleKey)}-${index}`;
}

function getCurrentLineImpact(opt, currentBundle) {
  const currentIds = new Set(Array.from(
    { length: Math.max(0, Number(currentBundle.originalQty ?? currentBundle.qty) || 0) },
    (_, index) => window.getVZBundleSubscriptionId(currentBundle, index)
  ));
  const currentBundles = (opt.bundles || []).filter(bundle => bundle.originalQty !== undefined);
  return (opt.bundles || []).reduce((impact, bundle) => {
    if (!bundle.isolatedTransactionType || !Array.isArray(bundle.selectedSubIds)) return impact;
    const affected = bundle.selectedSubIds.filter(id => currentIds.has(id)).length;
    if (bundle.isolatedTransactionType === 'upsell') {
      const featureKeys = Array.isArray(bundle.features) ? bundle.features : [];
      const destinationCore = featureKeys.includes('dual')
        ? 'vtu-dual'
        : (featureKeys.includes('ffc') ? 'vtu-ffc' : null);
      if (destinationCore) {
        if (currentBundle.coreKey === destinationCore) {
          const movedFromOtherCore = bundle.selectedSubIds.filter(id => currentBundles.some(source => {
            if (source.coreKey === destinationCore) return false;
            const sourceQty = Number(source.originalQty ?? source.qty) || 0;
            return Array.from({ length: sourceQty }, (_, index) => window.getVZBundleSubscriptionId(source, index)).includes(id);
          })).length;
          impact.addedCount += movedFromOtherCore;
        } else {
          impact.cancelledCount += affected;
        }
      } else {
        impact.addedCount += affected;
      }
    }
    if (bundle.isolatedTransactionType === 'cancel') {
      impact.cancelledCount += affected;
      // 2026-11-10 (per Catalina): cancelling only the camera of a VTU + camera vehicle (not its Vehicle Tracking) turns
      // it into a Vehicle Tracking Subscription — −1 on its camera line, +1 on the Vehicle Tracking line it moves to.
      const cameraOnly = vzCameraOnlyCancelledVehicles(bundle);
      cameraOnly.forEach(vehicleId => {
        const source = currentBundles.find(b => vzBundleVehicleIds(b).includes(vehicleId));
        if (!source) return;
        if (source === currentBundle) impact.cancelledCount += 1;
        else if (vzDowngradeTarget(source, currentBundles) === currentBundle) impact.addedCount += 1;
      });
    }
    return impact;
  }, { addedCount: 0, cancelledCount: 0 });
}

// Vehicle ids of a current line (one per unit), as in the vehicle tables.
function vzBundleVehicleIds(bundle) {
  return Array.from({ length: Math.max(0, Number(bundle.originalQty ?? bundle.qty) || 0) }, (_, index) => window.getVZBundleSubscriptionId(bundle, index));
}
// Vehicles whose camera subscription was cancelled without their Vehicle Tracking (ids "vehicle::ffc" / "vehicle::dual").
function vzCameraOnlyCancelledVehicles(cancelBundle) {
  const ids = Array.isArray(cancelBundle.selectedSubIds) ? cancelBundle.selectedSubIds : [];
  const whole = new Set(ids.filter(id => !String(id).includes('::')));
  return [...new Set(ids.filter(id => /::(ffc|dual)$/.test(String(id))).map(id => String(id).split('::')[0]))].filter(v => !whole.has(v));
}
// The Vehicle Tracking line a camera vehicle lands on when its camera is cancelled: same non-video features.
function vzDowngradeTarget(source, currentBundles) {
  if (source.coreKey !== 'vtu-ffc' && source.coreKey !== 'vtu-dual') return null;
  const videoKeys = ['sd-256', 'adas', 'evc', 'monitor'];
  const keep = (Array.isArray(source.features) ? source.features : []).filter(k => !videoKeys.includes(k)).sort().join('+');
  return currentBundles.find(b => b.coreKey === 'vtu' && (Array.isArray(b.features) ? b.features : []).slice().sort().join('+') === keep) || null;
}

  if (!proposalData.closeDate) {
    proposalData.closeDate = getLastDayOfCurrentMonthIso();
  }
  const closeDateDisplayEl = document.getElementById('header-prop-close-date-display');
  const closeDateInputEl = document.getElementById('header-prop-close-date-input');
  const vcmiModeEl = document.getElementById('header-prop-vcmi-mode');
  const vcmiContextEl = document.getElementById('header-prop-vcmi-context');
  if (closeDateDisplayEl) {
    const parsedClose = parseProposalDate(proposalData.closeDate);
    closeDateDisplayEl.textContent = parsedClose ? formatUsDate(parsedClose) : '--/--/----';
  }
  if (closeDateInputEl) closeDateInputEl.value = proposalData.closeDate;
  if (vcmiModeEl) vcmiModeEl.textContent = proposalData.vcmiMode || 'VMI';
  if (vcmiContextEl) vcmiContextEl.textContent = getVcmiContextLabel();

  updateSeasonalPill();
  updateSegmentHeader();

  // Sync gov-mode card width on options grid
  const _grid = document.getElementById('options-grid');
  if (_grid) {
    _grid.classList.toggle('gov-mode', proposalData.wavesEnabled && proposalData.segment === 'Government');
  }

  // Hide Global Approval Banner as requested (moving to inline indicator)
  const banner = document.getElementById('global-approval-banner');
  if (banner) banner.classList.add('hidden');
  
  // Ensure layout doesn't keep extra padding if no other banners are present
  const warningBanner = document.getElementById('warning-banner');
  if (!warningBanner || warningBanner.classList.contains('hidden')) {
    document.getElementById('vc-body').classList.remove('has-banner');
  }

  // Update button state
  updateSendBtn();

  options.forEach((opt, i) => {
    const msaLockedTerm = Number(DEMO_MSA.termMonths) || 0;
    const shouldLockMsaTerm = msaLockedTerm > 0 && !isSpecialOptionMode(opt);
    if (shouldLockMsaTerm && Number(opt.term) !== msaLockedTerm) {
      opt.term = msaLockedTerm;
    }

    // 2026-09-18 (R21.2, per Catalina): band/tier is frozen for "Create new
    // proposal" options \u2014 it always reflects the contract's real, currently
    // committed unit count (not this isolated card's own small totalUnits),
    // and no manual tier override is allowed. Renewal/Rewrap options keep the
    // existing dynamic behavior (natural tier from the option's own \u2014 full,
    // mirrored \u2014 totalUnits, with the override dropdown still available).
    const isBandFrozen = proposalData.entryPoint !== 'renewalRewrap';
    const currentForcedTier = isBandFrozen ? -1 : ((opt.forcedTierIndex !== undefined) ? opt.forcedTierIndex : -1);
    const optionPromoType = getOptionPromotion(opt);
    const totalUnits = opt.bundles.reduce((sum, bundle) => sum + (bundle.qty || 0), 0);
    const applicableNaturalIdx = isBandFrozen ? getApplicableTierIndex(getContractCommittedUnits()) : getApplicableTierIndex(totalUnits);
    const optTier = currentForcedTier === -1
      ? applicableNaturalIdx
      : Math.max(currentForcedTier, applicableNaturalIdx);
    const { totalMonthly, avgUnit, tierQty: msaTierUnits } = calcOption(opt, optionPromoType, optTier);
    const tierObj = getEffectiveTier(getTierEligibilityQty(totalUnits), optTier);
    const tier = tierObj;
    const skip = tier.index - applicableNaturalIdx;
    // 2026-10-07 (per Catalina): same approval rule as Initial Sales \u2014 placeholder until the real rules:
    // a Custom Discount / Promotion with a value (shared: assets-shared/js/vc-approval.js).
    const requiresApproval = getOptionApprovalInfo(opt, opt).requiresApproval;

    let bundlesHtml = '';
    // 2026-09-21 (per Catalina): in "Create new proposal" (entryPoint ===
    // 'newProposal'), every bundle IS a modification being built from
    // scratch \u2014 there's no separate "current line" to diff against \u2014 so
    // they must all get the hover edit/delete controls, same as
    // Renewal/Rewrap's isolated-transaction bundles. This was silently
    // regressed when modificationBundles was scoped to renewalRewrap only.
    const currentLineBundles = proposalData.entryPoint === 'renewalRewrap'
      ? opt.bundles.filter(bundle => bundle.originalQty !== undefined)
      : (proposalData.entryPoint === 'newProposal' ? [] : opt.bundles);
    const modificationBundles = proposalData.entryPoint === 'renewalRewrap'
      ? opt.bundles.filter(bundle => bundle.isolatedTransactionType)
      : (proposalData.entryPoint === 'newProposal' ? opt.bundles : []);
    [...currentLineBundles, ...modificationBundles].forEach((b, bundleIndex) => {
      const isModification = modificationBundles.includes(b);
      if (isModification && bundleIndex === currentLineBundles.length && proposalData.entryPoint === 'renewalRewrap') {
        // 2026-09-21 (per Catalina): "Configure promotions" moves down into
        // this Contract Modifications sub-header for Renewal/Rewrap, instead
        // of sitting in the top Active Bundles header \u2014 promotions apply to
        // the new modification lines, not the read-only Current lines above.
        // 2026-10-02: "Configure promotions" removed from this sub-header \u2014
        // Renewal / Rewrap now have one entry point, the "Discounts &
        // Promotions" button next to Contract term (same as Initial Sales).
        bundlesHtml += VC.sectionStrip({ title: 'Contract modifications', count: modificationBundles.length, follows: true });
      }
      const bundlePromo = b.promoType || optionPromoType;
      const bundlePricing = calcBundle({ ...b, msaDiscountPct: getOptionDiscountPct(opt, b) }, opt.term, bundlePromo, msaTierUnits);
      const orderCustomPromotions = getActiveCustomPromotionsForPricing(opt);
      const customPromoAmount = orderCustomPromotions.length
        ? getCustomPromoAmountForBundle(b, orderCustomPromotions, 0, bundlePricing.unitPrice)
        : 0;
      const isFixedRateTx = vzIsFixedRateTx(b);
      const unitPrice = isFixedRateTx ? (Number(b.basePrice) || 0) : Math.max(0, bundlePricing.unitPrice - customPromoAmount);
      const monthly = unitPrice * b.qty;
      const bt = bundlePricing.tier;
      const bundleDelta = isModification ? null : getBundleDelta(b);
      const isCancelled = bundleDelta?.type === 'cancelled';
      // 2026-09-18 (R22, per Catalina): 'increased' (a bundle that already
      // existed and grew \u2014 e.g. an Upsell moved units in) gets the same
      // green-border treatment as 'added' (a brand-new bundle), just with a
      // "+N added" count instead of a plain "New" badge.
      const isAdded = proposalData.entryPoint === 'renewalRewrap' && (bundleDelta?.type === 'added' || bundleDelta?.type === 'increased');
      const impact = !isModification && proposalData.entryPoint === 'renewalRewrap'
        ? getCurrentLineImpact(opt, b)
        : { addedCount: 0, cancelledCount: 0 };
      const impactBadges = (impact.addedCount || impact.cancelledCount)
        ? `<span class="bundle-impact-badges">${impact.addedCount ? `<span class="badge badge--green">+${impact.addedCount}</span>` : ''}${impact.cancelledCount ? `<span class="badge badge--red">\u2212${impact.cancelledCount}</span>` : ''}</span>`
        : '';
      const qtyLabel = isModification ? `${b.qty}` : `${b.originalQty ?? b.qty}`;
      const qtyStatus = isModification
        ? ''
        : (bundleDelta?.type === 'reduced'
        ? `<span class="bundle-qty-delta">\u2212${bundleDelta.amount} cancelled</span>`
        : (isCancelled ? '<span class="bundle-cancelled-badge">Cancelled</span>' : (bundleDelta?.type === 'increased' ? `<span class="bundle-added-badge">+${bundleDelta.amount} added</span>` : (isAdded ? '<span class="bundle-added-badge">New</span>' : ''))));
      const standardUnitPrice = getStandardUnitPrice(b);
      const hasBundleDiscount = standardUnitPrice > unitPrice + 0.005;
      const isChangeOption = opt.transactionMode === 'Change';
      const { unitPrice: promoOnlyUnitPrice } = calcBundle({ ...b, msaDiscountPct: 0 }, opt.term, bundlePromo, msaTierUnits);
      const { unitPrice: trueListUnitPrice } = calcBundle({ ...b, msaDiscountPct: 0, dealCloser: '', promoName: '' }, opt.term, 'Standard', msaTierUnits);
      const discretionaryAmount = Math.max(0, promoOnlyUnitPrice - bundlePricing.unitPrice);
      const promoAmount = Math.max(0, trueListUnitPrice - promoOnlyUnitPrice);
      const hasCombinedDiscount = trueListUnitPrice > 0;
      const promoPctForTooltip = hasCombinedDiscount ? Math.round((promoAmount / trueListUnitPrice) * 100) : 0;
      const discretionaryPctForTooltip = hasCombinedDiscount ? Math.round((discretionaryAmount / trueListUnitPrice) * 100) : 0;
      const tierTermPctForBundleRow = getTierTermDiscountPct(opt.term, msaTierUnits);
      const badgeCustomPromos = getCustomPromotions(opt).filter(promotion => customPromoHasAnyValue(promotion) && Array.isArray(promotion.targets) && promotion.targets.some(target => target.bundleId === b.id));
      const customOrderAmountForBadge = getCustomPromoAmountForBundle(b, badgeCustomPromos.filter(promotion => promotion.level !== 'contract'), tierTermPctForBundleRow, bundlePricing.unitPrice);
      const customContractAmountForBadge = getCustomPromoAmountForBundle(b, badgeCustomPromos.filter(promotion => promotion.level === 'contract'), tierTermPctForBundleRow, bundlePricing.unitPrice);
      const customOrderPctForBadge = hasCombinedDiscount ? Math.round((customOrderAmountForBadge / trueListUnitPrice) * 100) : 0;
      const customContractPctForBadge = hasCombinedDiscount ? Math.round((customContractAmountForBadge / trueListUnitPrice) * 100) : 0;
      const totalOrderPctForBadge = promoPctForTooltip + customOrderPctForBadge;
      const totalContractPctForBadge = discretionaryPctForTooltip + customContractPctForBadge;
      const orderCustomFixedDuration = badgeCustomPromos.find(promotion => promotion.level !== 'contract' && promotion.durationMode === 'months' && promotion.durationMonths && promotion.durationMonths !== opt.term);
      const orderPromoDurationDiffersFromTerm = b.promoDurationMonths != null && b.promoDurationMonths > 0 && b.promoDurationMonths !== opt.term;
      const orderDurationMonthsForBadge = orderPromoDurationDiffersFromTerm ? b.promoDurationMonths : (orderCustomFixedDuration ? orderCustomFixedDuration.durationMonths : null);
      const afterTierTermUnit = standardUnitPrice * (1 - tierTermPctForBundleRow / 100);
      const msaPriceUnit = isFixedRateTx ? unitPrice : afterTierTermUnit * (1 - getOptionDiscountPct(opt, b) / 100);
      const isVideo   = b.coreKey === 'vtu-ffc' || b.coreKey === 'vtu-dual';
      const promoApplied = bundlePromo === 'Media' && isVideo;
      const featureKeys = Array.isArray(b.features) ? b.features : [];
      const videoFeatureKeys = ['sd-256', 'adas', 'evc', 'monitor'];
      const vehicleFeatureKeys = ['driver-id', 'privacy', 'logbook'];
      let videoFeatures = featureKeys
        .filter(k => videoFeatureKeys.includes(k))
        .map((k) => {
          if (k === 'evc') return `EVC (${getEvcTypeLabel(b.evcType)})`;
          return featureLabels[k] || k;
        });
      if (isVideo && !featureKeys.includes('sd-256')) {
        videoFeatures = ['128 GB SD Card', ...videoFeatures];
      }
      const vehicleFeatures = featureKeys
        .filter(k => vehicleFeatureKeys.includes(k))
        .map(k => featureLabels[k] || k);
      const featureMeta = `
        ${videoFeatures.length ? `<div class="bundle-feature-line"><strong>Video:</strong> ${videoFeatures.join(', ')}</div>` : ''}
        ${vehicleFeatures.length ? `<div class="bundle-feature-line"><strong>Vehicle features:</strong> ${vehicleFeatures.join(', ')}</div>` : ''}
        ${featureKeys.some(k => SOFTWARE_FEATURE_KEYS.includes(k)) ? `<div class="bundle-feature-line"><strong>Software features:</strong> ${featureKeys.filter(k => SOFTWARE_FEATURE_KEYS.includes(k)).map(k => featureLabels[k] || k).join(', ')}</div>` : ''}
      `;
      let discBadges = '';
      // 2026-10-06 (per Catalina): the old custom "Media Promo \u221220%", "Custom
      // promotion \u2212$X/unit" and "Jump N tier" pills (disc-badge) are no longer
      // shown \u2014 only the VDS badges used by the current design.
      if (isChangeOption && totalOrderPctForBadge > 0) discBadges += `<span class="badge badge--blue">\u2212${totalOrderPctForBadge}%${orderDurationMonthsForBadge ? ` for ${orderDurationMonthsForBadge}mo` : ''}</span> `;

      const bundleStatRowHtml = isChangeOption
        ? VC.statRow({ className: 'bundle-stat-row--4col', cells: [
          { label: 'QTY (units)', valueHtml: `${qtyLabel}${qtyStatus}${isModification ? '' : impactBadges}` },
          { label: 'List Price', value: formatMoney(standardUnitPrice) },
          { label: 'Contracted Price', value: formatMoney(msaPriceUnit) },
          { label: 'Monthly', valueHtml: `${monthly < (msaPriceUnit * b.qty - 0.005) ? `<span class="bundle-stat-value-strike">${formatMoney(msaPriceUnit * b.qty)}</span> ` : ''}${formatMoney(monthly)}` },
        ] })
        : VC.statRow({ cells: [
          { label: 'QTY (units)', valueHtml: `${qtyLabel}${qtyStatus}${isModification ? '' : impactBadges}` },
          { label: 'Monthly unit price', valueHtml: `${hasBundleDiscount ? `<span class="bundle-stat-value-strike">${formatMoney(standardUnitPrice)}</span> ` : ''}${formatMoney(unitPrice)}` },
          { label: 'Monthly', valueHtml: formatMoney(monthly) },
        ] });
      const bundleRowStateClass = isCancelled ? 'bundle-row--cancelled' : (bundleDelta?.type === 'reduced' ? 'bundle-row--reduced' : (isAdded ? 'bundle-row--added' : ''));
      const bundleActionsHtml = isModification ? `<div class="bundle-row-actions">
        <button type="button" class="btn-icon btn-icon--solid btn-icon--vds-small" title="Edit solution" aria-label="Edit solution" onclick="editIsolatedTransaction(${opt.id}, ${b.id})"><span class="material-symbols-outlined" aria-hidden="true">edit</span></button>
        <button type="button" class="btn-icon btn-icon--solid btn-icon--vds-small" title="Delete solution" aria-label="Delete solution" onclick="deleteBundle(${opt.id}, ${b.id})"><span class="material-symbols-outlined" aria-hidden="true">delete</span></button>
      </div>` : '';
      // 2026-10-14 (per Catalina): modification name on top (eyebrow), product below — shared solution-row title.
      const bundleTitleHtml = `<div class="bundle-row-title">${b.txLabel ? `<div class="bundle-row-eyebrow">${b.txLabel}</div>` : ''}<div class="bundle-row-name">${b.coreName}</div>${typeof getSeasonalSubtitleHtml === 'function' ? getSeasonalSubtitleHtml(b) : ''}</div>`;
      const bundleBadgesHtml = discBadges ? `<div style="flex-shrink:0;display:flex;gap:4px;flex-wrap:wrap;justify-content:flex-end;">${discBadges}</div>` : '';

      bundlesHtml += VC.solutionRow({
        actionsMode: 'hover',
        className: bundleRowStateClass,
        actionsHtml: bundleActionsHtml,
        titleHtml: bundleTitleHtml,
        badgesHtml: bundleBadgesHtml,
        metaHtml: featureMeta,
        statRowHtml: bundleStatRowHtml,
      });
    });

    const card = document.createElement('div');
    card.className = 'option-card';
    card.setAttribute('data-option-id', opt.id);

    // Main button: disabled (not hidden) while the option needs approval.
    // 2026-11-04 (Migrations): a migration creates the MSA contract, not an Order Form.
    const primaryAction = { onClick: `selectOption(${opt.id})`, disabled: requiresApproval, ...(isExistingContractProposal() ? { label: 'Select &amp; Create Contract' } : {}) };

    // Pre-compute per-option prices for term and tier dropdowns
    const _termPx = ['12','24','36','48','60'].map(t => {
      if (totalUnits === 0) return '';
      const { totalMonthly: tm } = calcOption({...opt, term: t}, optionPromoType, optTier);
      return ' \u2014 ' + formatMoney(tm) + '/mo';
    });

    // F2: co-term \u2014 lock term display when add-on (non-Gov)
    const isCoTerm = proposalData.isAddOn && proposalData.segment !== 'Government' && !isSpecialOptionMode(opt);
    const _termLabels = ['12 months','24 months','36 months','48 months','60 months'];
    const _termVals   = ['12','24','36','48','60'];
    const termRows = _termVals.map((tv, idx) => {
      const isSel = String(opt.term) === tv;
      const isLockedOut = shouldLockMsaTerm && Number(tv) !== msaLockedTerm;
      const priceStr = _termPx[idx] ? _termPx[idx].replace(' \u2014 ', '') : '';
      return `<div class="dropdown-option opt-term-row ${isSel ?'opt-term-row--selected' : ''} ${isLockedOut ? 'opt-term-row--disabled' : ''}" ${!isLockedOut ? `onclick="selectOptTerm(${opt.id}, '${tv}')"` : ''}>
        <span class="opt-term-row-label">${_termLabels[idx]}</span>
        ${priceStr ? `<span class="opt-term-row-price">${priceStr}</span>` : ''}
      </div>`;
    }).join('');


    // 2026-09-18 (per Catalina): the term's date-range caption needs the
    // right START date to compute correctly. proposalData.msaTermStart is the
    // ORIGINAL MSA's start date \u2014 correct for a Change card (co-term), but
    // wrong for Renewal (which starts the day after the current contract
    // ends) and wrong for Rewrap (which starts on the option's own Effective
    // Date, chosen separately per option, not at the account level).
    const optTermStartDate = opt.transactionMode === 'Rewrap'
      ? (opt.effectiveDate || getDefaultEffectiveDate('Rewrap'))
      : opt.transactionMode === 'Renewal'
        ? getDefaultEffectiveDate('Renewal')
        : proposalData.msaTermStart;
    const optTermRangeLabel = (() => {
      const start = parseProposalDate(optTermStartDate);
      if (!start) return `${opt.term} months`;
      const end = getMsaTermEndDate(optTermStartDate, Number(opt.term));
      if (!end) return `${opt.term} months`;
      const startLabel = opt.transactionMode === 'Rewrap'
        ? `<span style="color:var(--orange);font-weight:700;">${formatUsDate(start)}</span>`
        : formatUsDate(start);
      return `${startLabel} \u2013 ${formatUsDate(end)}`;
    })();

    const termFieldHtml = isCoTerm
      ? `<div>
           <div class="vc-field-label">Contract term</div>
           <div class="coterm-display">
             <strong>${optTermRangeLabel}</strong>&ensp;<span style="font-size:12px;color:var(--gray-600);">Co-term \u00b7 MSA ${proposalData.msaId}</span>
           </div>
         </div>`
      : `<div>
           <div class="vc-field-label">Contract term</div>
           <div class="custom-select-wrap">
             <button class="custom-select-btn selected" onclick="toggleOptTermDropdown(${opt.id}, event)">
               <span>${opt.term} months</span>
               <span class="material-symbols-outlined">expand_more</span>
             </button>
             <div class="custom-dropdown hidden" id="opt-term-dd-${opt.id}">
               ${termRows}
             </div>
           </div>
           ${typeof migrationModeOn !== 'undefined' && migrationModeOn ? '' : `<div style="font-size:11px;color:var(--gray-600);margin-top:4px;">${optTermRangeLabel}</div>`}
         </div>`;
    // 2026-11-04 (per Leo via Catalina): a migration option has no start / end dates under the contract term.


    // 2026-10-07: card structure, header actions and transaction-type differences come from the shared
    // option card (assets-shared/js/vc-option-card.js) \u2014 same template as Initial Sales.
    const optionCardVariant = proposalData.entryPoint === 'newProposal'
      ? 'modification'
      : ({ Reactivation: 'reactivation', Rewrap: 'rewrap', Renewal: 'renewal' }[opt.transactionMode] || 'renewal');
    card.innerHTML = VC.optionCard({
      variant: optionCardVariant,
      optId: opt.id,
      titleHtml: buildOptionTitleHtml(opt, `Option ${i + 1}`),
      headerControlsHtml: renderOptionHeaderControls(opt),
      // 2026-10-22 (per Catalina): Renewal / Rewrap / Reactivation start from what the customer has — the only option
      // can't be deleted (no empty proposal); cloned alternatives can.
      hideDelete: proposalData.entryPoint !== 'newProposal' && options.filter(o => !o.msaPreviewFor).length <= 1,
      headerMetaHtml: typeof buildOptionTierMetaHtml === 'function' ? buildOptionTierMetaHtml(opt) : '',
      menuItems: [
        // Brief 35 (2026-10-22): optional customer-facing label — first item (per Catalina).
        getOptionLabelMenuItem(opt),
        // 2026-11-09 (per Catalina): View Price List in every Existing Business option (was Create new proposal only).
        ...(opt.bundles.length > 0 ? [{ label: 'View Price List', onClick: 'openOptionListPriceFromCard(' + opt.id + ')' }] : []),
        // 2026-10-16 (per Catalina): hidden (not disabled) below the threshold.
        ...(totalUnits >= SCHEDULE_THRESHOLD_QTY ? [{ label: 'Order Schedule', onClick: 'openOptionScheduleFromCard(' + opt.id + ')' }] : []),
      ],
      locked: requiresApproval && proposalData.approvalStatus === 'Pending',
      termRowHtml: renderOptionMotionControls(opt, termFieldHtml),
      // 2026-10-14 (per Catalina): every existing-account option uses the Initial Sales summary (was: QTY, Tier/Term,
      // Avg unit price, Monthly total on Renewal / Rewrap / Reactivation).
      summaryHtml: opt.bundles.length > 0 ? buildOptionSummaryStripHtml(opt) : '',
      notificationHtml: buildApprovalBannerHtml(opt, opt),
      // 2026-11-04 (Migrations): vehicles with service that aren't billed can be added to the option.
      extraHtml: typeof migrationOptionNoticeHtml === 'function' ? migrationOptionNoticeHtml(opt) : '',
      primaryAction,
      sectionRightHtml: opt.bundles.length > 0 && proposalData.entryPoint !== 'renewalRewrap' && opt.transactionMode !== 'Reactivation'
        ? `<span class="bundles-label-divider"></span><button class="btn-opt-promo" onclick="toggleOptPromoPanel(${opt.id})"><span class="material-symbols-outlined">sell</span> Configure promotions</button>`
        : '',
      rowsHtml: bundlesHtml,
      // 2026-11-10 (per Catalina): Renewal / Rewrap count the active solutions, not the modifications added to them.
      rowsCount: proposalData.entryPoint === 'renewalRewrap' ? opt.bundles.filter(b => b.originalQty !== undefined).length : opt.bundles.length,
      footerHtml: proposalData.wavesEnabled ? buildOptWavesHtml(opt, totalUnits) : '',
    });
    grid.appendChild(card);
  });

  const addCard = document.createElement('div');
  addCard.className = 'btn-dashed-add btn-dashed-add--card add-option-card';
  addCard.onclick = () => openConfigureBundle();
  addCard.innerHTML = `+ Add option ${options.length + 1}`;
  if (typeof canAddProposalOption !== 'function' || canAddProposalOption()) grid.appendChild(addCard);
  updateOptionsGridAlignment();
  renderDraftingMsaCommitmentPanel();
},

  renderSelectionOptions: function renderSelectionOptions() {
  const grid = document.getElementById('selection-grid');
  grid.innerHTML = options.map((opt, i) => {
    const optionPromoType = getOptionPromotion(opt);
    const { totalMonthly, totalUnits, avgUnit } = calcOption(opt, optionPromoType, (opt.forcedTierIndex ?? -1));
    const tier = getEffectiveTier(totalUnits, (opt.forcedTierIndex ?? -1));
    const skip = tier.index - tier.naturalIndex;
    const requiresApproval = getOptionApprovalInfo(opt, opt).requiresApproval;

    let tierBadgeHtml = '';
    if (tier && tier.discount > 0) {
      tierBadgeHtml = `<span class="tier-badge">${tier.label}</span>`;
    } else if (totalUnits > 0) {
      tierBadgeHtml = `<span class="tier-badge" style="background:var(--gray-100);color:var(--gray-600);">${tier ? tier.label : '1-9'}</span>`;
    }

    let actionHtml = '';
    if (requiresApproval) {
      const role = getApprovalRole(skip);
      const isPending = proposalData.approvalStatus === 'Pending';
      actionHtml = `
        <!-- 2026-10-06 (per Catalina): old orange "Request approval" button removed. -->
        <button class="btn btn--primary btn--large btn-select-contract" disabled>${getSelectCreateLabel().replace('&', '&amp;')}</button>
      `;
    } else {
      actionHtml = `
        <button class="btn btn--primary btn--large btn-select-contract" onclick="selectOption(${opt.id})">${getSelectCreateLabel().replace('&', '&amp;')}</button>
      `;
    }

    const videoFeatureKeys = ['sd-256', 'adas', 'evc', 'monitor'];
    const vehicleFeatureKeys = ['driver-id', 'privacy', 'logbook'];

    let bundlesHtml = '';
    opt.bundles.forEach(b => {
      const bundlePromo = b.promoType || optionPromoType;
      const { unitPrice, monthly, tier: bt } = calcBundle(b, opt.term, bundlePromo, totalUnits);
      const standardUnitPrice = getStandardUnitPrice(b);
      const hasBundleDiscount = standardUnitPrice > unitPrice + 0.005;
      const isVideo = b.coreKey === 'vtu-ffc' || b.coreKey === 'vtu-dual';
      const promoApplied = bundlePromo === 'Media' && isVideo;
      const featureKeys = Array.isArray(b.features) ? b.features : [];
      let videoFeatures = featureKeys
        .filter(k => videoFeatureKeys.includes(k))
        .map((k) => {
          if (k === 'evc') return `EVC (${getEvcTypeLabel(b.evcType)})`;
          return featureLabels[k] || k;
        });
      if (isVideo && !featureKeys.includes('sd-256')) {
        videoFeatures = ['128 GB SD Card', ...videoFeatures];
      }
      const vehicleFeatures = featureKeys
        .filter(k => vehicleFeatureKeys.includes(k))
        .map(k => featureLabels[k] || k);
      const featureMeta = `
        ${videoFeatures.length ? `<div class="bundle-feature-line"><strong>Video:</strong> ${videoFeatures.join(', ')}</div>` : ''}
        ${vehicleFeatures.length ? `<div class="bundle-feature-line"><strong>Vehicle features:</strong> ${vehicleFeatures.join(', ')}</div>` : ''}
        ${featureKeys.some(k => SOFTWARE_FEATURE_KEYS.includes(k)) ? `<div class="bundle-feature-line"><strong>Software features:</strong> ${featureKeys.filter(k => SOFTWARE_FEATURE_KEYS.includes(k)).map(k => featureLabels[k] || k).join(', ')}</div>` : ''}
      `;
      let discBadges = ''; // old "Media Promo \u221220%" pill removed 2026-10-06 (per Catalina)

      bundlesHtml += `
        <div class="bundle-row">
          <div class="bundle-row-name">${b.coreName} <span style="float:right;font-weight:400;font-size:11px;color:var(--gray-600)">QTY: ${b.qty}</span></div>
          ${typeof getSeasonalSubtitleHtml === 'function' ? getSeasonalSubtitleHtml(b) : ''}
          ${featureMeta}
          <div class="bundle-row-price">${formatMoney(monthly)}<span>/month</span></div>
          <div class="bundle-row-unit">${hasBundleDiscount ? `<span class="bundle-stat-value-strike">${formatMoney(standardUnitPrice)}</span> ` : ''}${formatMoney(unitPrice)}/unit</div>
          <div style="margin-top:6px;">${discBadges}</div>
        </div>`;
    });

    return `
      <div class="option-card option-card--readonly">
        <div class="option-card-header">
          <span>Option ${i+1}</span>
        </div>
        <div class="option-card-body">
          <div class="monthly-total">
            <div class="vc-field-label" style="margin-top:12px;display:flex;align-items:center;justify-content:space-between;">
              <span>Monthly total</span>
              <div style="display:flex; align-items:center; gap:8px;">
                ${tierBadgeHtml}
                <span style="color:var(--gray-600); font-size:11px; font-weight:400;">QTY: ${totalUnits}</span>
              </div>
            </div>
            <div class="monthly-amount">${formatMoney(totalMonthly)}<span>/month</span></div>
            <div class="per-unit">${formatMoney(avgUnit)}/unit (avg)</div>
          </div>
          ${actionHtml}
          <div class="bundles-list">
            ${VC.sectionStrip({ icon: proposalData.entryPoint === 'newProposal' ? 'receipt_long' : 'package_2', title: proposalData.entryPoint === 'newProposal' ? 'Modifications' : 'Active Solutions', count: opt.bundles.length })}
            ${bundlesHtml || '<div style="font-size:11px;color:var(--gray-400);padding:16px;text-align:center;">No transactions yet</div>'}
          </div>
        </div>
      </div>`;
  }).join('');
},

};

// Fields Existing Accounts' proposal / builder state carries on top of Initial Sales'.
const EXISTING_PROPOSAL_DEFAULTS = {
  entryPoint: 'newProposal', forcedTierIndex: -1, approvalStatus: 'None', lockedTerm: null,
  isAddOn: false, msaId: 'MSA-2024-0391', msaSubscription: '34.00', msaMinimumSpendCommitment: 870.00,
  msaTermStart: '2025-01-01', msaContractTerm: 36, msaServiceOrderTerm: '36', serviceOrderStartDate: '',
  serviceOrderEndDate: '', msaRampUpPeriod: 30, msaDiscretionaryDiscountPct: 7, msaEndDate: '', wavesEnabled: false,
  segment: 'SMB', poNumber: '', costCenter: '', contractVehicle: '', contractingOfficerName: '',
  contractingOfficerEmail: '', contractingOfficerPhone: '',
};

let existingAccountsModeOn = false;
const INITIAL_SALES_VERSIONS = {};
const INITIAL_SALES_PROPOSAL_VALUES = {};
function setExistingAccountsMode(on) {
  on = !!on;
  // Scenario profile (assets-shared/js/vc-common.js): the shared functions read the account's rules from it.
  if (window.VC && typeof VC.setScenario === 'function') VC.setScenario(on ? 'existing' : 'new');
  Object.keys(EXISTING_ACCOUNTS_OVERRIDES).forEach(name => {
    if (!(name in INITIAL_SALES_VERSIONS)) INITIAL_SALES_VERSIONS[name] = window[name];
    window[name] = on ? EXISTING_ACCOUNTS_OVERRIDES[name] : INITIAL_SALES_VERSIONS[name];
  });
  // The proposal takes the existing account's MSA facts while in this mode; Initial Sales' values come back after.
  if (on && !existingAccountsModeOn) {
    Object.keys(EXISTING_PROPOSAL_DEFAULTS).forEach(key => {
      INITIAL_SALES_PROPOSAL_VALUES[key] = { had: key in proposalData, value: proposalData[key] };
      proposalData[key] = EXISTING_PROPOSAL_DEFAULTS[key];
    });
    if (!('msaDiscountPct' in bld)) bld.msaDiscountPct = 0;
  } else if (!on && existingAccountsModeOn) {
    Object.keys(INITIAL_SALES_PROPOSAL_VALUES).forEach(key => {
      const saved = INITIAL_SALES_PROPOSAL_VALUES[key];
      if (saved.had) proposalData[key] = saved.value; else delete proposalData[key];
    });
    document.querySelectorAll('#msa-commitment-list-slot, #msa-commitment-drafting-slot, .msa-commitment-step-slot')
      .forEach(slot => { slot.innerHTML = ''; });
  }
  // Existing Accounts starts Configure Solution on \u00c0 la carte; Initial Sales on Bundle (when the account allows both).
  if (typeof getAllowedSolutionTypes === 'function') {
    const allowed = getAllowedSolutionTypes();
    const preferred = on ? 'custom' : 'plan';
    builderMode = allowed.includes(preferred) ? preferred : allowed[0];
  }
  existingAccountsModeOn = on;
  document.body.classList.toggle('vc-existing-mode', on);
  // Configure Solution reads "Expansion Summary" / "Add Expansion" for an existing account.
  if (on && typeof renderProposalMetaMsaSummary === 'function') renderProposalMetaMsaSummary();
  // Confirm selection copy: a new account generates its MSA; an existing account starts a quote on its MSA.
  const confirmSubtext = document.getElementById('csm-option-subtext');
  if (confirmSubtext) confirmSubtext.textContent = on
    ? 'This will lock the drafting session and generate the order.'
    : 'This will lock the drafting session and generate the Master Service Agreement contract.';
  // 2026-11-03 (per Catalina): Existing Business creates an Order Form, not a contract.
  const confirmBtn = document.getElementById('csm-confirm-btn');
  if (confirmBtn) confirmBtn.textContent = on ? 'Confirm & create order' : 'Confirm & create contract';
  const summaryTitle = document.querySelector('#bundle-overlay .preview-label--title');
  if (summaryTitle) summaryTitle.textContent = on ? 'Expansion Summary' : 'Solution Summary';
}
