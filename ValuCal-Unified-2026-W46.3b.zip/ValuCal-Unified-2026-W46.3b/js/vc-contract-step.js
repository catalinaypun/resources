/* Valu Cal — Contract step (shared: create-contract loader + Contract screen), 2026-10-07.
   One implementation for Initial Sales and Existing Accounts (A2 + A3). Source: Initial Sales.
   Markup: VC.contractScreenMarkup(), VC.quoteLoaderMarkup(), VC.promoValidationFailMarkup(),
   VC.contractPreviewMarkup() — each flow drops them into hosts.
   Flow hooks (stay per flow): confirmSelectionAndProceed (what happens before the loader), enterDealResult,
   renderNav, renderOptions / renderSelectionOptions, touchNavDate, showSuccessBanner, updateFulfillmentBtn,
   updateSendBtn, calcOption, logProposalEvent. Optional: getProposalDocMsaSummary() (MSA box in the
   contract), getContractCreatedBanner() → [title, body]. */
window.VC = window.VC || {};
window.VC.contractScreenMarkup = function () { return "<div id=\"screen-contract\" class=\"content-area hidden\" style=\"padding-bottom: 80px;\">\n\n    <!-- \u2500\u2500 PHASE 0: Contract Review gate (live DocuSign preview) \u2500\u2500 -->\n    <div id=\"contract-phase-contractpreview\" class=\"hidden\" style=\"margin-top:0;\">\n      <div class=\"contract-preview-step\">\n        <div class=\"contract-preview-step-head\">\n          <div class=\"contract-preview-step-head-copy\">\n            <h3>Contract Review</h3>\n            <div class=\"contract-preview-step-head-sub\"><span>Review the contract before sending it. It will be sent through the Purchase Portal to <strong id=\"contract-portal-recipient-email\">--</strong>.</span><!-- 2026-11-04 (per Catalina): the validations follow the recipient, after a divider. --><span id=\"contract-validation-host\" class=\"contract-validation-host\"></span></div>\n          </div>\n          <div class=\"contract-preview-step-head-actions\">\n            <div class=\"kebab-menu\">\n            <button class=\"btn-icon btn-icon--tonal btn-icon--vds-small\" type=\"button\" onclick=\"toggleContractPreviewMenu(event)\" aria-label=\"More actions\" aria-haspopup=\"true\" aria-expanded=\"false\">\n              <span class=\"material-symbols-outlined\">more_vert</span>\n            </button>\n            <div id=\"more-menu-contract-preview\" class=\"kebab-menu__panel hidden\" role=\"menu\">\n              <button type=\"button\" class=\"kebab-menu__item contract-schedule-menu-item\" role=\"menuitem\" onclick=\"openContractScheduleModal()\">Edit order schedule</button>\n              <button type=\"button\" class=\"kebab-menu__item\" role=\"menuitem\" onclick=\"openContractModifyConfirmModal()\">Modify proposal</button>\n              <div id=\"sim-title-contract-preview\" class=\"kebab-menu__label simulation-title\">\n                Simulation\n              </div>\n              <button id=\"sim-contract-signed-contract-preview\" type=\"button\" class=\"kebab-menu__item simulation-action\" role=\"menuitem\" onclick=\"simulateContractSigned()\">Contract signed</button>\n              <button id=\"sim-payment-setup-contract-preview\" type=\"button\" class=\"kebab-menu__item simulation-action\" role=\"menuitem\" onclick=\"simulatePaymentSetup()\">Payment setup configured</button>\n              <div class=\"kebab-menu__divider\" role=\"separator\"></div>\n              <button type=\"button\" class=\"kebab-menu__item kebab-menu__item--danger\" role=\"menuitem\" onclick=\"openMarkDeadModal()\">Mark dead deal</button>\n            </div>\n            </div>\n            <!-- 2026-10-05 (per Leo / Catalina \u2014 Topic 5 of the 2026-10-01 call):\n                 the editable-email step is gone. The contract goes to the\n                 Customer Portal, which notifies the customer itself; no\n                 confirmation modal (per Leo) \u2014 the recipient is stated in the\n                 Contract Review subtitle (moved there from under the button,\n                 per Catalina, 2026-10-05: it read as cluttered). -->\n            <button type=\"button\" id=\"contract-send-portal-btn\" class=\"btn btn--primary btn--large\" onclick=\"sendContractToCustomerPortal()\">Send Purchase Portal Link</button>\n          </div>\n        </div>\n        <div class=\"contract-preview-live-note notification notification--info\" role=\"status\" aria-live=\"polite\">\n          <span class=\"notification__icon\" aria-hidden=\"true\"><span class=\"material-symbols-outlined\">info</span></span>\n          <div class=\"notification__body\">\n            <p class=\"notification__title\">This is a live preview from DocuSign.</p>\n            <p class=\"notification__message\">Nothing here is editable in ValuCal. To make changes, edit the contract directly in DocuSign. Updates will appear here automatically.</p>\n          </div>\n        </div>\n        <div class=\"contract-preview-doc-shell\">\n          <div class=\"contract-preview-viewer-toolbar\">\n            <button type=\"button\" class=\"btn-icon btn-icon--solid btn-icon--vds-small\" onclick=\"refreshContractPreview(this)\" aria-label=\"Refresh contract preview\" title=\"Refresh contract preview\"><span class=\"material-symbols-outlined\" aria-hidden=\"true\">refresh</span></button>\n          </div>\n          <div class=\"doc-viewer\" id=\"contract-doc-viewer\"></div>\n        </div>\n      </div>\n    </div>\n\n    <!-- \u2500\u2500 PHASE 2: Sign & Payment (action bar + preview only) \u2500\u2500 -->\n    <div id=\"contract-phase-signpay\" class=\"hidden\" style=\"background:white; border:1px solid var(--gray-200); border-radius:8px; overflow:hidden;\">\n      <div class=\"review-header-bar\">\n        <h2 class=\"ql-page-title\" style=\"flex:1; min-width:0; padding-right:12px; margin:0; font-family:var(--font-family-etext, 'VerizonNHGDS', sans-serif);\">\n          Signature & Payment Tracking\n        </h2>\n        <div style=\"display:flex; gap:8px; align-items:center; position:relative;\">\n          <div class=\"kebab-menu\">\n          <button type=\"button\" class=\"btn-icon btn-icon--tonal btn-icon--vds-small\" onclick=\"toggleContractMenu2(event)\" aria-label=\"More actions\" aria-haspopup=\"true\" aria-expanded=\"false\">\n            <span class=\"material-symbols-outlined\">more_vert</span>\n          </button>\n          <div id=\"more-menu-contract2\" class=\"kebab-menu__panel hidden\" role=\"menu\">\n            <button type=\"button\" class=\"kebab-menu__item contract-schedule-menu-item\" role=\"menuitem\" onclick=\"openContractScheduleModal()\">Edit order schedule</button>\n            <button type=\"button\" class=\"kebab-menu__item\" role=\"menuitem\" onclick=\"resendContractLink()\">Resend Purchase Portal Link</button>\n            <button type=\"button\" class=\"kebab-menu__item\" role=\"menuitem\" onclick=\"openContractModifyConfirmModal()\">Modify proposal</button>\n            <div id=\"sim-title-contract2\" class=\"kebab-menu__label simulation-title\">\n              Simulation\n            </div>\n            <button id=\"sim-contract-signed-contract2\" type=\"button\" class=\"kebab-menu__item simulation-action\" role=\"menuitem\" onclick=\"simulateContractSigned()\">Contract signed</button>\n            <button id=\"sim-payment-setup-contract2\" type=\"button\" class=\"kebab-menu__item simulation-action\" role=\"menuitem\" onclick=\"simulatePaymentSetup()\">Payment setup configured</button>\n            <div class=\"kebab-menu__divider\" role=\"separator\"></div>\n            <button type=\"button\" class=\"kebab-menu__item kebab-menu__item--danger\" role=\"menuitem\" onclick=\"openMarkDeadModal()\">Mark dead deal</button>\n          </div>\n          </div>\n        </div>\n      </div>\n      <div id=\"contract-send-loader\" class=\"contract-send-loader hidden\" role=\"status\" aria-live=\"polite\">\n        <div class=\"contract-send-loader__inner\">\n          <div class=\"loader loader--small\" aria-hidden=\"true\"><svg class=\"loader__spinner\" viewBox=\"0 0 64 64\" fill=\"none\"><circle class=\"loader__track\" cx=\"32\" cy=\"32\" r=\"28\" stroke-width=\"6\" stroke-linecap=\"round\"/><path class=\"loader__arc\" d=\"M32 4 A28 28 0 0 1 60 32\" stroke-width=\"6\" stroke-linecap=\"round\" fill=\"none\"/></svg></div>\n          <div class=\"contract-send-loader__text\">Sending contract to customer...</div>\n        </div>\n      </div>\n      <div id=\"sp-waiting-message\" class=\"sp-waiting-message hidden is-waiting\" role=\"status\" aria-live=\"polite\">\n        <span id=\"sp-waiting-message-icon\" class=\"material-symbols-outlined\" aria-hidden=\"true\">mark_email_read</span>\n        <div>\n          <div id=\"sp-waiting-message-title\" class=\"sp-waiting-title\">Contract sent successfully</div>\n          <div id=\"sp-waiting-message-copy\" class=\"sp-waiting-copy\">The contract is now with the customer. We are waiting for signature and payment setup to complete before moving to Deal Result.</div>\n          <div class=\"sp-waiting-actions\">\n            <button type=\"button\" class=\"btn btn--secondary btn--large\" onclick=\"openContractInDocuSign()\">View Contract</button>\n          </div>\n        </div>\n      </div>\n      <div class=\"vc-checklist-wrap\" id=\"sp-checklist-wrap\">\n        <div class=\"vc-checklist\">\n          <div class=\"vc-checklist__title\">Contract progress</div>\n          <!-- 2026-10-05 (per Catalina): first, already-checked step stating\n               where the contract was sent. -->\n          <div class=\"vc-checklist__row hidden\" id=\"sp-row-portal\">\n            <span class=\"vc-checklist__state vc-checklist__state--done\" aria-hidden=\"true\"><span class=\"material-symbols-outlined\">check</span></span>\n            <div>\n              <div class=\"vc-checklist__label\">Sent to Purchase Portal</div>\n              <div class=\"vc-checklist__sub\" id=\"sp-portal-sub\">Contract sent to --</div>\n              <div class=\"vc-checklist__meta\" id=\"sp-portal-date\">--</div>\n            </div>\n          </div>\n          <div class=\"vc-checklist__row\" id=\"sp-row-signature\">\n            <span class=\"vc-checklist__state vc-checklist__state--progress\" id=\"sp-signature-state-icon\" aria-hidden=\"true\"><div class=\"loader\"><svg class=\"loader__spinner\" viewBox=\"0 0 64 64\" fill=\"none\" aria-hidden=\"true\"><circle class=\"loader__track\" cx=\"32\" cy=\"32\" r=\"28\" stroke-width=\"6\" stroke-linecap=\"round\"/><path class=\"loader__arc\" d=\"M32 4 A28 28 0 0 1 60 32\" stroke-width=\"6\" stroke-linecap=\"round\" fill=\"none\"/></svg></div></span>\n            <div>\n              <div class=\"vc-checklist__label\">Client Signature</div>\n              <div class=\"vc-checklist__sub\" id=\"sp-signature-sub\">Waiting for customer signature in DocuSign.</div>\n              <div class=\"vc-checklist__meta\" id=\"sp-signature-date\"></div>\n            </div>\n          </div>\n          <div class=\"vc-checklist__row\" id=\"sp-row-payment\">\n            <span class=\"vc-checklist__state vc-checklist__state--pending\" id=\"sp-payment-state-icon\" aria-hidden=\"true\"></span>\n            <div>\n              <div class=\"vc-checklist__label\">Payment Setup</div>\n              <div class=\"vc-checklist__sub\" id=\"sp-payment-sub\">Starts after contract signature is completed.</div>\n              <div class=\"vc-checklist__meta\" id=\"sp-payment-date\">Pending</div>\n            </div>\n          </div>\n          <!-- 2026-10-29 (MSA sync 10-28, per Leo): automatic final validation after payment — promotions and account data. -->\n          <div class=\"vc-checklist__row\" id=\"sp-row-validation\">\n            <span class=\"vc-checklist__state vc-checklist__state--pending\" id=\"sp-validation-state-icon\" aria-hidden=\"true\"></span>\n            <div>\n              <div class=\"vc-checklist__label\">Final validation</div>\n              <div class=\"vc-checklist__sub\" id=\"sp-validation-sub\">Runs automatically after payment setup.</div>\n              <ul class=\"vc-checklist__issues hidden\" id=\"sp-validation-issues\"></ul>\n              <div class=\"vc-checklist__meta\" id=\"sp-validation-date\">Pending</div>\n            </div>\n          </div>\n        </div>\n      </div>\n    </div>\n\n  </div>"; };
window.VC.quoteLoaderMarkup = function () { return "<div class=\"vc-stage-loader-overlay\" id=\"quote-loader-overlay\" aria-live=\"polite\" aria-busy=\"true\">\n  <div class=\"vc-stage-loader\">\n    <div class=\"vc-stage-loader__progress\">\n      <div class=\"vc-stage-loader__track\">\n        <div class=\"vc-stage-loader__fill\" id=\"ql-fill\"></div>\n      </div>\n      <div class=\"vc-stage-loader__labels\">\n        <span class=\"vc-stage-loader__label is-active\" id=\"ql-label-0\">Validation</span>\n        <span class=\"vc-stage-loader__label\" id=\"ql-label-1\">Opportunity</span>\n        <span class=\"vc-stage-loader__label\" id=\"ql-label-2\">Quote</span>\n        <span class=\"vc-stage-loader__label\" id=\"ql-label-3\">Contract</span>\n      </div>\n    </div>\n\n    <div class=\"vc-stage-loader__headline\" id=\"ql-headline\">Validating promotions &amp; programs</div>\n    <div class=\"vc-stage-loader__body\" id=\"ql-body\">\n      Checking that the selected promotions and discount<br>programs are still valid for this proposal.\n    </div>\n\n    <div class=\"vc-stage-loader__warning\">Don't close or refresh this window</div>\n  </div>\n</div>"; };
window.VC.promoValidationFailMarkup = function () { return "<div class=\"modal-overlay\" id=\"promo-validation-fail-overlay\">\n  <div class=\"modal\" role=\"alertdialog\" aria-modal=\"true\" aria-labelledby=\"promo-validation-fail-title\" onclick=\"event.stopPropagation()\">\n    <button type=\"button\" class=\"modal__close btn-icon btn-icon--ghost-vds btn-icon--vds-large\" onclick=\"backToOptionsFromPromoValidation()\" aria-label=\"Close promotion validation message\"><span class=\"material-symbols-outlined\" aria-hidden=\"true\">close</span></button>\n    <div class=\"modal__content\">\n      <h2 class=\"modal__title\" id=\"promo-validation-fail-title\">A promotion no longer applies</h2>\n      <div class=\"modal__body\" id=\"promo-validation-fail-body\"></div>\n    </div>\n    <div class=\"modal__actions modal__actions--fill-container\">\n      <button class=\"btn btn--secondary btn--large\" onclick=\"backToOptionsFromPromoValidation()\">Back to options</button>\n      <button class=\"btn btn--primary btn--large\" onclick=\"removePromoAndContinue()\">Continue</button>\n    </div>\n  </div>\n</div>"; };
window.VC.contractPreviewMarkup = function () {
  return `<div id="contract-preview-overlay" class="modal-overlay" onclick="handleContractPreviewOverlayClick(event)">
    <div class="modal modal--full contract-preview-modal" role="dialog" aria-modal="true" aria-labelledby="contract-preview-modal-title" onclick="event.stopPropagation()">
      <div class="contract-preview-modal-head modal__sticky-header">
        <div class="contract-preview-modal-head-copy">
          <h2 id="contract-preview-modal-title" class="modal__title contract-preview-modal-title">Contract preview</h2>
        </div>
        <button type="button" class="modal__close btn-icon btn-icon--ghost-vds btn-icon--vds-large" onclick="closeContractPreviewModal()" aria-label="Close contract preview">
          <span class="material-symbols-outlined" aria-hidden="true">close</span>
        </button>
      </div>
      <div class="contract-preview-modal-body modal__scroll-area">
        <!-- 2026-10-20 (per Catalina): same blue notification as the Contract step, not a plain subtitle. -->
        <div class="notification notification--info contract-preview-modal-notice" role="status" aria-live="polite">
          <span class="notification__icon" aria-hidden="true"><span class="material-symbols-outlined">info</span></span>
          <div class="notification__body">
            <p class="notification__title">This is a live preview from DocuSign.</p>
            <p class="notification__message">Nothing here is editable in ValuCal. To make changes, edit the contract directly in DocuSign. Updates will appear here automatically.</p>
          </div>
        </div>
        <div class="contract-preview-viewer-toolbar">
          <button type="button" class="btn-icon btn-icon--solid btn-icon--vds-small" onclick="refreshContractPreview(this)" aria-label="Refresh contract preview" title="Refresh contract preview"><span class="material-symbols-outlined" aria-hidden="true">refresh</span></button>
        </div>
        <div class="doc-viewer" id="contract-doc-viewer-modal"></div>
      </div>
    </div>
  </div>`;
};

// MSA box in the contract document (Existing: same facts as the MSA panel; Initial Sales: none).
function buildContractMsaBoxHtml(contractId) {
  if (typeof getProposalDocMsaSummary !== 'function') return '';
  const summary = getProposalDocMsaSummary();
  if (!summary || !summary.fields || !summary.fields.length) return '';
  const title = escapeContractDocHtml(contractId || summary.title || '');
  const cell = (label, value) => `<div><div style="font-size:10px;font-weight:700;margin-bottom:3px;white-space:nowrap;">${label}</div><div style="font-size:11px;color:#222;white-space:nowrap;">${value}</div></div>`;
  return `<div style="background:#fff;border:1px solid #000;border-radius:4px;padding:10px 16px 12px;margin:0 0 18px;">
      <div style="background:#000;color:#fff;font-size:10px;font-weight:700;padding:8px 16px;margin:-10px -16px 10px;border-radius:3px 3px 0 0;">Master Service Agreement${title ? ` · ${title}` : ''}</div>
      <div style="display:grid;grid-template-columns:repeat(${summary.fields.length}, auto);justify-content:space-between;gap:12px;">${summary.fields.map(f => cell(f.label, f.value)).join('')}</div>
    </div>`;
}

const CONTRACT_SEND_LOADER_DELAY_MS = 1100;
let contractConfirmProceedAction = null;
let contractResendMode = false;
let contractResendReturnState = 'waiting';
let contractSendLoaderTimer = null;
let contractSubState = 'waiting';
let hasSeenContractPreviewGate = false;
let pendingFailingPromotion = null;
let promoValidationSim = 'pass';
// 2026-10-29 (MSA sync 10-28): final validation after payment — 'pass' confirms the sale, 'fail' stops it with the issues.
let finalValidationSim = 'pass';
// 2026-11-04 (user story "Opportunity moving from presenting to negotiating", per Catalina): validations that run when
// the contract is created, before the Purchase Portal link can be sent. See startContractValidations.
// 'pass' | 'ecs-fail' | 'running' (the ECS check never finishes, to show the wait).
let contractValidationSim = 'pass';
let contractValidation = null;
let selectedOpt = null;
let signatureModalCountdownTimer = null;
let signatureModalDelayTimer = null;
let svtPendingTransitionTimer = null;

function isDirectBillAccount() {
  return typeof unifiedAccount !== 'undefined' && unifiedAccount.paymentMethod === 'direct-bill';
}

function clearSignatureCompletionSimulation() {
  if (signatureModalDelayTimer) {
    clearTimeout(signatureModalDelayTimer);
    signatureModalDelayTimer = null;
  }
  if (signatureModalCountdownTimer) {
    clearInterval(signatureModalCountdownTimer);
    signatureModalCountdownTimer = null;
  }
}

function continueFromSignatureCompleted() {
  if (contractSubState !== 'waiting') {
    clearSignatureCompletionSimulation();
    return;
  }
  clearSignatureCompletionSimulation();
  contractSubState = 'signed';
  // Brief 34 v2: the signed contract (snapshot) — "View contract" on Contract signed.
  logProposalEvent('Contract signed', 'Customer signature was completed.', { docHtml: document.getElementById('contract-doc-viewer')?.innerHTML || '' });
  touchNavDate('contract', true);
  touchNavDate('contract_sign_pay', true);
  updateContractSubState();
  renderNav();
}

function optionHasPromotionsOrDiscounts(opt) {
  if (!opt) return false;
  const check = o => !!o && (
    (Number(o.msaDiscountPct) || 0) > 0 ||
    !!o.discountProgramKey ||
    (Array.isArray(o.customPromotions) && o.customPromotions.some(p => customPromoHasAnyValue(p))) ||
    (o.bundles || []).some(b => (Number(b.msaDiscountPct) || 0) > 0 || !!b.promoName || !!b.dealCloser || (b.promoType && b.promoType !== 'Standard'))
  );
  const companion = options.find(o => o.msaPreviewFor === opt.id);
  return check(opt) || check(companion);
}

function customPromoHasAnyValue(p) {
  if ((p.value || 0) > 0) return true;
  return (p.targets || []).some(t => (t.value || 0) > 0);
}

function isContractSignedOrBeyond() {
  return ['signed', 'payment'].includes(contractSubState);
}

function openMarkDeadModal() {
  if (isContractSignedOrBeyond()) return;
  _qlClosePendingRow = null; // opened from within drafting/selection
  document.getElementById('mark-dead-overlay').classList.add('is-open');
  if (typeof setMarkDeadReasonError === 'function') setMarkDeadReasonError(false);
  updateMarkDeadConfirmBtn();
}

function updateMarkDeadConfirmBtn() {
  const select = document.getElementById('dead-reason-select');
  const btn = document.getElementById('btn-confirm-rejection');
  if (!select || !btn) return;
  btn.disabled = !select.value;
  if (select.value) setMarkDeadReasonError(false);
}

// Inline validation on the Reason field (VDS error state) instead of a browser alert (2026-10-13).
function setMarkDeadReasonError(show) {
  document.getElementById('dead-reason-select')?.classList.toggle('select--error', show);
  document.getElementById('dead-reason-error')?.classList.toggle('hidden', !show);
}

function setKebabMenuOpen(menu, open) {
  if (!menu) return;
  menu.classList.toggle('hidden', !open);
  menu.closest('.kebab-menu')?.querySelector('.btn-icon')?.setAttribute('aria-expanded', String(open));
}

function createContract(optId) {
  const opt = options.find((o) => o.id === optId);
  if (!opt) return;
  // 2026-10-15: creating the contract saves the proposal (it gets its ID in the breadcrumb).
  if (typeof proposalIsSaved !== 'undefined' && !proposalIsSaved) { proposalIsSaved = true; if (typeof updateDraftingHeaderTitle === 'function') updateDraftingHeaderTitle(); }
  const optionNumber = options.findIndex((o) => o.id === optId) + 1;
  proposalData.lockedTerm = opt.term; // F1: freeze term at selection
  const result = calcOption(opt, getOptionPromotion(opt));
  proposalData.msaMinimumSpendCommitment = result.totalMonthly;
  logProposalEvent('Contract created', `Created from ${getOptionDisplayLabel(Math.max(1, optionNumber), true)} — ${opt.term}-month term locked.`, { optionNumber: Math.max(1, optionNumber), term: opt.term });

  screen = 'contract-review';

  hideProposalReviewModal();
  document.getElementById('screen-proposal-selection')?.classList.add('hidden');
  document.getElementById('screen-drafting')?.classList.add('hidden');
  document.getElementById('options-grid')?.classList.add('hidden');

  document.getElementById('screen-contract')?.classList.remove('hidden');

  document.querySelector('.vc-main-stepper')?.classList.remove('hidden');
  if (document.getElementById('step-dot-1')) {
    document.getElementById('step-dot-1').className = 'vc-step-dot done';
    document.getElementById('step-dot-1').innerHTML = '<span class="material-symbols-outlined" style="font-size:14px;">check</span>';
  }
  document.getElementById('step-label-1')?.classList.remove('muted');
  if (document.getElementById('step-dot-2')) document.getElementById('step-dot-2').className = 'vc-step-dot active';
  document.getElementById('step-label-2')?.classList.remove('muted');

  const l3 = document.getElementById('substep-label-3');
  if (l3) {
    l3.textContent = 'Create Contract';
    l3.classList.remove('muted');
  }

  document.getElementById('vc-body').style.paddingTop = '159px';

  document.getElementById('footer-send').innerText = 'Send E-Sign Link';
  document.getElementById('footer-send').disabled = false;

  const banner = document.getElementById('success-banner');
  if (banner) {
    banner.style.top = '159px';
    const createdBanner = typeof getContractCreatedBanner === 'function'
      ? getContractCreatedBanner()
      : ['Contract has been created', 'Your Master Service Agreement was successfully generated. Review the terms and send the e-sign link.'];
    showSuccessBanner(createdBanner[0], createdBanner[1]);
  }

  touchNavDate('proposal');
  touchNavDate('proposal_selection');
  enterContractScreen(opt);
  renderNav();
}

function showQuoteCreationLoader(validationAlreadyPassed = false) {
  const overlay = document.getElementById('quote-loader-overlay');
  if (!overlay) {
    createContract(bld.selectedOptionId);
    return;
  }

  function getLoaderLabelBaseText(labelEl) {
    if (!labelEl) return '';
    if (!labelEl.dataset.baseLabel) {
      labelEl.dataset.baseLabel = (labelEl.textContent || '').trim();
    }
    return labelEl.dataset.baseLabel;
  }

  function setLoaderProgressLabelState(labelEl, state) {
    if (!labelEl) return;
    const baseText = getLoaderLabelBaseText(labelEl);
    labelEl.className = `vc-stage-loader__label${state ? ` is-${state}` : ''}`;

    if (state === 'done') {
      labelEl.innerHTML = `<span class="material-symbols-outlined" aria-hidden="true">check</span> ${baseText}`;
      return;
    }

    labelEl.textContent = baseText;
  }

  // 2026-10-05 (per Leo, 2026-10-02 call): a "Validation" step runs first —
  // "Validating promotions & programs" — before Opportunity / Quote / Contract.
  // Follow-up (per Catalina): only when the selected option actually has a
  // promotion or discount applied; otherwise the loader keeps its original 3
  // steps. Each step takes ~2.5 s.
  const fill = document.getElementById('ql-fill');
  const lbl0 = document.getElementById('ql-label-0');
  const lbl1 = document.getElementById('ql-label-1');
  const lbl2 = document.getElementById('ql-label-2');
  const lbl3 = document.getElementById('ql-label-3');
  const allLoaderSteps = [
    { label: lbl0, validation: true, headline: 'Validating promotions & programs', body: 'Checking that the selected promotions and discount<br>programs are still valid for this proposal.' },
    { label: lbl1, headline: 'Creating Opportunity', body: 'Setting up the opportunity record in Salesforce.<br>This may take a moment.' },
    { label: lbl2, headline: 'Creating Quote', body: 'Generating your configured quote and<br>linking it to the opportunity record.' },
    { label: lbl3, headline: 'Creating Contract', body: 'Preparing the contract package and<br>routing it to the contract workspace.' },
  ];
  const needsValidation = validationAlreadyPassed || optionHasPromotionsOrDiscounts(options.find(o => o.id === bld.selectedOptionId));
  const loaderSteps = allLoaderSteps.filter(step => needsValidation || !step.validation);
  const stepCount = loaderSteps.length;
  const stepPct = 100 / stepCount;
  const stepMs = 2500;
  // 2026-10-05 (per Catalina): after "Remove and continue", the loader comes
  // back with Validation already checked and resumes at Opportunity.
  const firstIndex = validationAlreadyPassed ? 1 : 0;
  if (fill) { fill.style.transition = 'none'; fill.style.width = `${firstIndex * stepPct}%`; }
  loaderSteps.forEach((step, index) => setLoaderProgressLabelState(step.label, index < firstIndex ? 'done' : (index === firstIndex ? 'active' : '')));
  if (lbl0) lbl0.classList.toggle('hidden', !needsValidation);
  document.getElementById('ql-headline').textContent = loaderSteps[firstIndex].headline;
  document.getElementById('ql-body').innerHTML = loaderSteps[firstIndex].body;

  overlay.classList.add('is-open');

  const runStep = (index) => {
    const step = loaderSteps[index];
    setLoaderProgressLabelState(step.label, 'active');
    if (step.validation && lbl0) lbl0.classList.remove('hidden');
    document.getElementById('ql-headline').textContent = step.headline;
    document.getElementById('ql-body').innerHTML = step.body;
    requestAnimationFrame(() => requestAnimationFrame(() => {
      if (fill) { fill.style.transition = `width ${stepMs / 1000}s ease`; fill.style.width = `${(index + 1) * stepPct}%`; }
    }));
    setTimeout(() => {
      if (step.validation) {
        const failing = promoValidationSim === 'fail' ? findFailingPromotion(options.find(o => o.id === bld.selectedOptionId)) : null;
        if (failing) {
          overlay.classList.remove('open', 'is-open');
          openPromoValidationFailModal(failing);
          return;
        }
      }
      setLoaderProgressLabelState(step.label, 'done');
      if (index + 1 < loaderSteps.length) { runStep(index + 1); return; }
      setTimeout(() => {
        overlay.classList.remove('open', 'is-open');
        createContract(bld.selectedOptionId);
      }, 500);
    }, stepMs);
  };
  runStep(firstIndex);
}

  function getLoaderLabelBaseText(labelEl) {
    if (!labelEl) return '';
    if (!labelEl.dataset.baseLabel) {
      labelEl.dataset.baseLabel = (labelEl.textContent || '').trim();
    }
    return labelEl.dataset.baseLabel;
  }

  function setLoaderProgressLabelState(labelEl, state) {
    if (!labelEl) return;
    const baseText = getLoaderLabelBaseText(labelEl);
    labelEl.className = `vc-stage-loader__label${state ? ` is-${state}` : ''}`;

    if (state === 'done') {
      labelEl.innerHTML = `<span class="material-symbols-outlined" aria-hidden="true">check</span> ${baseText}`;
      return;
    }

    labelEl.textContent = baseText;
  }

function findFailingPromotion(opt) {
  if (!opt) return null;
  const companion = options.find(o => o.msaPreviewFor === opt.id);
  const holders = [opt, companion].filter(Boolean);
  for (const holder of holders) {
    const program = DISCOUNT_PROGRAMS.find(p => p.key === holder.discountProgramKey);
    if (program) return { kind: 'program', holderId: holder.id, key: program.key, label: `${program.name} (${program.pct}%)`, type: 'Account Discount program' };
  }
  for (const holder of holders) {
    const bundle = (holder.bundles || []).find(b => b.promoName);
    if (bundle) return { kind: 'promo', holderId: holder.id, key: bundle.promoName, label: bundle.promoName, type: 'Order promotion' };
  }
  for (const holder of holders) {
    const bundle = (holder.bundles || []).find(b => b.dealCloser);
    if (bundle) return { kind: 'deal-closer', holderId: holder.id, key: bundle.dealCloser, label: bundle.dealCloser, type: 'Deal closer' };
  }
  return null;
}

function openPromoValidationFailModal(failing) {
  pendingFailingPromotion = failing;
  const opt = options.find(o => o.id === bld.selectedOptionId);
  const optionNumber = Math.max(1, options.findIndex(o => o.id === (opt && opt.id)) + 1);
  const body = document.getElementById('promo-validation-fail-body');
  if (body) {
    // 2026-10-14 (per Catalina): one generic sentence — no type, no reason, no next-step text (the buttons say it).
    body.innerHTML = `<strong>${failing.label}</strong> no longer applies to ${getOptionDisplayLabel(optionNumber, true)}, so we removed it and updated the price.`;
  }
  // Follow-up (per Catalina): removal isn't the rep's choice — it happens as
  // soon as the failure is found; the dialog only informs. Both buttons just
  // decide where to go next.
  removeFailingPromotion(false);
  document.getElementById('promo-validation-fail-overlay')?.classList.add('is-open');
}

function closePromoValidationFailModal() {
  document.getElementById('promo-validation-fail-overlay')?.classList.remove('is-open');
}

function removeFailingPromotion() {
  const failing = pendingFailingPromotion;
  pendingFailingPromotion = null;
  const holder = failing ? options.find(o => o.id === failing.holderId) : null;
  if (holder) {
    if (failing.kind === 'program') {
      holder.discountProgramKey = null;
      holder.msaDiscountPct = 0;
      holder.bundles.forEach(b => { b.msaDiscountPct = 0; });
    } else if (failing.kind === 'promo') {
      holder.bundles.forEach(b => { if (b.promoName === failing.key) { b.promoName = ''; b.promoType = 'Standard'; } });
    } else if (failing.kind === 'deal-closer') {
      holder.bundles.forEach(b => { if (b.dealCloser === failing.key) b.dealCloser = ''; });
    }
    if (typeof logProposalEvent === 'function') logProposalEvent('Promotion removed', `${failing.label} no longer applied and was removed at contract creation.`);
    renderOptions();
    if (screen === 'selection' && typeof renderSelectionOptions === 'function') renderSelectionOptions();
  }
}

function removePromoAndContinue() {
  closePromoValidationFailModal();
  setTimeout(() => showQuoteCreationLoader(true), 160);
}

function showToast(msg) { if (typeof showSuccessBanner === 'function') showSuccessBanner(msg, ''); }

function clearSvtPendingTransition() {
  if (svtPendingTransitionTimer) {
    clearTimeout(svtPendingTransitionTimer);
    svtPendingTransitionTimer = null;
  }
}

function scheduleSaleConfirmation(expectedState, eventMessage) {
  clearSvtPendingTransition();
  svtPendingTransitionTimer = setTimeout(() => {
    svtPendingTransitionTimer = null;
    if (contractSubState !== expectedState) return;
    logProposalEvent('Sale confirmed', eventMessage);
    enterDealResult('won');
  }, 2200);
}

// ── Final validation after payment (2026-10-29, MSA sync 10-28, per Leo / Rogelio) ──
// Re-checks promotions and account data once the contract is signed and paid (e.g. the lead source changed after the
// contract was created). Pass → Sale Confirmed. Fail → the flow stops and the step lists the issues; what happens
// next (void + new contract, clone the proposal, tell the rep) is still open (tracker O-F3).
function resetFinalValidationRow() {
  const sub = document.getElementById('sp-validation-sub');
  const issues = document.getElementById('sp-validation-issues');
  const date = document.getElementById('sp-validation-date');
  if (sub) sub.textContent = isDirectBillAccount() ? 'Runs automatically after the signature.' : 'Runs automatically after payment setup.';
  if (issues) { issues.replaceChildren(); issues.classList.add('hidden'); }
  if (date) date.textContent = 'Pending';
}
function getFinalValidationIssues() {
  if (finalValidationSim !== 'fail') return [];
  const opt = options.find(o => o.id === bld.selectedOptionId);
  const failing = findFailingPromotion(opt);
  return failing
    ? [`${failing.label} (${failing.type}) no longer applies: the account's lead source changed after the contract was created.`]
    : ["The account's lead source changed after the contract was created."];
}
function runFinalValidation(expectedState, eventMessage) {
  clearSvtPendingTransition();
  const icon = document.getElementById('sp-validation-state-icon');
  const sub = document.getElementById('sp-validation-sub');
  const issuesEl = document.getElementById('sp-validation-issues');
  const date = document.getElementById('sp-validation-date');
  if (sub) sub.textContent = 'Checking that promotions and account data still apply.';
  if (date) date.textContent = 'In progress';
  svtPendingTransitionTimer = setTimeout(() => {
    svtPendingTransitionTimer = null;
    if (contractSubState !== expectedState) return;
    const issues = getFinalValidationIssues();
    const when = new Date().toLocaleDateString();
    if (issues.length) {
      if (icon) {
        icon.className = 'vc-checklist__state vc-checklist__state--error';
        icon.innerHTML = '<span class="material-symbols-outlined" aria-hidden="true">close</span>';
      }
      if (sub) sub.textContent = "The sale can't be confirmed. Issues found:";
      if (issuesEl) {
        issuesEl.replaceChildren(...issues.map(text => { const li = document.createElement('li'); li.textContent = text; return li; }));
        issuesEl.classList.remove('hidden');
      }
      if (date) date.textContent = `Failed ${when}`;
      setSignPayStatusMessage('validation-failed');
      logProposalEvent('Final validation failed', issues.join(' '));
      return;
    }
    if (icon) {
      icon.className = 'vc-checklist__state vc-checklist__state--done';
      icon.innerHTML = '<span class="material-symbols-outlined" aria-hidden="true">check</span>';
    }
    if (sub) sub.textContent = 'Promotions and account data still apply.';
    if (date) date.textContent = `Passed ${when}`;
    logProposalEvent('Final validation passed', 'Promotions and account data still apply.');
    svtPendingTransitionTimer = setTimeout(() => {
      svtPendingTransitionTimer = null;
      if (contractSubState !== expectedState) return;
      logProposalEvent('Sale confirmed', eventMessage);
      enterDealResult('won');
    }, 1200);
  }, 2200);
}

function addProposalNotification(notif) {
  // Graceful stub for notification system
}

function getCurrentProposalIdForNotifications() {
  return (proposalData && proposalData.proposalId) ? String(proposalData.proposalId).trim() : '0524';
}

function clearContractSendLoaderTimer() {
  if (!contractSendLoaderTimer) return;
  clearTimeout(contractSendLoaderTimer);
  contractSendLoaderTimer = null;
}

function setContractSendLoaderVisible(isVisible) {
  const loader = document.getElementById('contract-send-loader');
  const waitingMessage = document.getElementById('sp-waiting-message');
  const checklistWrap = document.getElementById('sp-checklist-wrap');
  if (loader) loader.classList.toggle('hidden', !isVisible);
  if (waitingMessage) waitingMessage.classList.toggle('hidden', isVisible);
  if (checklistWrap) checklistWrap.classList.toggle('hidden', isVisible);
}

function finalizeContractSendTransition(isResend, returnState) {
  contractSubState = isResend ? returnState : 'waiting';
  logProposalEvent(isResend ? 'Contract re-sent' : 'Contract sent', isResend
    ? `The Purchase Portal link was re-sent to ${getContractPortalRecipientEmail()}.`
    : `Contract was sent to the Purchase Portal (${getContractPortalRecipientEmail()}) for signature and payment setup.`,
    // Brief 34: the contract as it was sent (snapshot) — the history previews that version.
    { docHtml: document.getElementById('contract-doc-viewer')?.innerHTML || '' });
  touchNavDate('contract_review_send', true);
  updateContractSubState();
  renderContractPortalSentRow(true);
  // 2026-10-05 (per Catalina): green success toast (same auto-dismissing
  // pattern used elsewhere) confirming the send and its recipient.
  showSuccessBanner(isResend ? 'Purchase Portal link re-sent' : 'Contract sent', `The contract was sent through the Purchase Portal to ${getContractPortalRecipientEmail()}.`);
  document.getElementById('footer-back')?.classList.remove('hidden');
  document.getElementById('footer-back')?.classList.add('visible');
  contractResendMode = false;
  contractResendReturnState = 'waiting';
  renderNav();
}

function enterContractScreen(opt) {
  clearContractSendLoaderTimer();
  setContractSendLoaderVisible(false);
  clearSignatureCompletionSimulation();
  selectedOpt = opt;
  hasSeenContractPreviewGate = false;
  contractResendMode = false;
  contractResendReturnState = 'waiting';
  syncExpirationInputs(getSelectedExpirationDate());
  contractSubState = 'pre-send'; // before sending e-sign
  touchNavDate('contract_created');
  syncContractPortalRecipient();
  renderContractPortalSentRow(false);
  // Show phase 0 (Contract Review, DocuSign preview), hide the signature & payment tracking
  document.getElementById('contract-phase-contractpreview').classList.remove('hidden');
  document.getElementById('contract-phase-signpay').classList.add('hidden');
  // Stepper: step 1 active
  const d1 = document.getElementById('c-dot-1');
  const d2 = document.getElementById('c-dot-2');
  const l1 = document.getElementById('c-line-1');
  if (d1) d1.className = 'c-step-dot active';
  if (document.getElementById('c-dot-label-2')) document.getElementById('c-dot-label-2').className = 'c-step-label muted';
  if (d2) d2.className = 'c-step-dot pending';
  if (l1) l1.className = 'c-line';
  // Footer
  document.getElementById('footer-back').classList.remove('visible');
  document.getElementById('footer-back').classList.add('hidden');
  renderContractDoc(opt);
  startContractValidations();
}

function getContractPortalRecipientEmail() {
  const to = (document.getElementById('prop-msg-to')?.value || '').trim();
  return to || 'acme.logistics@acmecorp.com';
}

function syncContractPortalRecipient() {
  const email = getContractPortalRecipientEmail();
  const el = document.getElementById('contract-portal-recipient-email');
  if (el) { el.textContent = email; el.title = email; }
}

function renderContractPortalSentRow(isSent) {
  const row = document.getElementById('sp-row-portal');
  if (!row) return;
  row.classList.toggle('hidden', !isSent);
  if (!isSent) return;
  const sub = document.getElementById('sp-portal-sub');
  const date = document.getElementById('sp-portal-date');
  if (sub) sub.textContent = `Contract sent to ${getContractPortalRecipientEmail()}`;
  if (date) date.textContent = (window._navDates && window._navDates.contract_review_send) || new Date().toLocaleDateString();
}

function sendContractToCustomerPortal() {
  if (!selectedOpt) return;
  if (contractValidation && contractValidation.state !== 'passed') return; // validations still running or failed
  hasSeenContractPreviewGate = true;
  document.getElementById('contract-phase-contractpreview')?.classList.add('hidden');
  sendContractNow();
}

function setSignPayStatusMessage(state) {
  const wrap = document.getElementById('sp-waiting-message');
  const icon = document.getElementById('sp-waiting-message-icon');
  const title = document.getElementById('sp-waiting-message-title');
  const copy = document.getElementById('sp-waiting-message-copy');
  if (!wrap || !icon || !title || !copy) return;

  const map = {
    waiting: {
      icon: 'mark_email_read',
      title: 'Contract sent successfully',
      copy: isDirectBillAccount()
        ? 'The contract is now with the customer. We are waiting for the signature before moving to Deal Result.'
        : 'The contract is now with the customer. We are waiting for signature and payment setup to complete before moving to Deal Result.',
    },
    signed: {
      icon: 'how_to_reg',
      title: 'Contract signed',
      copy: isDirectBillAccount()
        ? 'The customer signed. The sale is being confirmed.'
        : 'The customer signed. We are waiting for the customer to set up payment.',
    },
    payment: {
      icon: 'task_alt',
      title: 'Payment completed',
      copy: 'Signature and payment setup are complete. The sale is being confirmed.',
    },
    'validation-failed': {
      icon: 'error',
      title: 'Final validation found issues',
      copy: "The sale can't be confirmed yet. Review the issues in Final validation below.",
    },
  };

  const cfg = map[state] || map.waiting;
  wrap.classList.remove('hidden', 'is-waiting', 'is-signed', 'is-payment', 'is-validation-failed');
  wrap.classList.add(`is-${state in map ? state : 'waiting'}`);
  icon.textContent = cfg.icon;
  title.textContent = cfg.title;
  copy.textContent = cfg.copy;
}

function updateContractSubState() {
  updateContractSimulationMenuVisibility();
  const hideMarkDead = isContractSignedOrBeyond();
  ['more-menu-contract-preview', 'more-menu-contract2'].forEach(menuId => {
    const item = document.getElementById(menuId)?.querySelector('.kebab-menu__item--danger[onclick="openMarkDeadModal()"]');
    if (!item) return;
    item.classList.toggle('hidden', hideMarkDead);
    item.previousElementSibling?.classList.toggle('hidden', hideMarkDead);
  });
  document.getElementById('sp-row-payment')?.classList.toggle('hidden', isDirectBillAccount());
  const waitingMessage = document.getElementById('sp-waiting-message');
  const checklistWrap = document.getElementById('sp-checklist-wrap');
  const dot2 = document.getElementById('c-dot-2');
  const line2 = document.getElementById('c-line-2');
  const dot3 = document.getElementById('c-dot-3');
  const date2 = document.getElementById('contract-date-2');
  const signatureIcon = document.getElementById('sp-signature-state-icon');
  const paymentIcon = document.getElementById('sp-payment-state-icon');
  const signatureSub = document.getElementById('sp-signature-sub');
  const paymentSub = document.getElementById('sp-payment-sub');
  const signatureDate = document.getElementById('sp-signature-date');
  const paymentDate = document.getElementById('sp-payment-date');
  const dates = window._navDates || {};

  // 2026-10-14 (per Leo): Contract Signed (customer signed, payment setup pending) → Pay Completed (payment set up,
  // a few seconds) → Sale Confirmed. Direct bill: the signature confirms the sale (no Payment Setup row).
  function setChecklistState(signatureState, paymentState, validationState = 'pending') {
    const setState = (icon, state) => {
      if (!icon) return;
      icon.className = `vc-checklist__state vc-checklist__state--${state}`;
      icon.innerHTML = state === 'done'
        ? '<span class="material-symbols-outlined" aria-hidden="true">check</span>'
        : state === 'progress'
          ? '<div class="loader"><svg class="loader__spinner" viewBox="0 0 64 64" fill="none" aria-hidden="true"><circle class="loader__track" cx="32" cy="32" r="28" stroke-width="6" stroke-linecap="round"/><path class="loader__arc" d="M32 4 A28 28 0 0 1 60 32" stroke-width="6" stroke-linecap="round" fill="none"/></svg></div>'
          : '';
    };
    setState(signatureIcon, signatureState);
    setState(paymentIcon, paymentState);
    setState(document.getElementById('sp-validation-state-icon'), validationState);
    if (validationState === 'pending') resetFinalValidationRow();
  }

  if (contractSubState === 'waiting') {
    clearSvtPendingTransition();
    setSignPayStatusMessage('waiting');
    if (checklistWrap) checklistWrap.classList.remove('hidden');
    if (signatureSub) signatureSub.textContent = 'Waiting for customer signature in DocuSign. Contact the customer to confirm receipt and assist with the digital signature.';
    if (paymentSub) paymentSub.textContent = 'Starts after the customer signs.';
    if (signatureDate) signatureDate.textContent = ''; // sent date now lives in the "Sent to Customer Portal" row
    if (paymentDate) paymentDate.textContent = 'Pending';
    setChecklistState('progress', 'pending');

  } else if (contractSubState === 'signed') {
    clearSvtPendingTransition();
    clearSignatureCompletionSimulation();
    setSignPayStatusMessage('signed');
    if (checklistWrap) checklistWrap.classList.remove('hidden');
    showSuccessBanner('Contract signed', isDirectBillAccount()
      ? 'The customer signed. The sale is being confirmed.'
      : 'The customer signed. They are redirected to the payment setup portal.');
    if (date2) date2.textContent = new Date().toLocaleDateString();
    if (signatureSub) signatureSub.textContent = 'Signature completed.';
    if (paymentSub) paymentSub.textContent = 'Waiting for payment setup confirmation.';
    if (signatureDate) signatureDate.textContent = `Signed ${dates.contract_sign_pay || '--'}`;
    if (paymentDate) paymentDate.textContent = 'In progress';
    setChecklistState('done', 'progress');
    if (isDirectBillAccount()) {
      setChecklistState('done', 'progress', 'progress');
      runFinalValidation('signed', 'The sale was confirmed automatically after contract signature and final validation.');
    }

  } else if (contractSubState === 'payment') {
    clearSignatureCompletionSimulation();
    clearSvtPendingTransition();
    setSignPayStatusMessage('payment');
    if (checklistWrap) checklistWrap.classList.remove('hidden');
    touchNavDate('contract');
    touchNavDate('contract_sign_pay');
    touchNavDate('contract_payment_setup', true);
    touchNavDate('payment');
    showSuccessBanner('Payment method configured.', '');
    logProposalEvent('Payment setup configured', 'Payment setup was completed.');
    addProposalNotification({
      title: 'Payment setup configured',
      message: 'Customer payment setup has been completed.',
      target: 'deal-result-won',
      dedupeKey: `payment-setup-${getCurrentProposalIdForNotifications()}`
    });
    if (dot2) dot2.className = 'c-step-dot done';
    if (line2) line2.className = 'c-line done';
    if (dot3) dot3.className = 'c-step-dot active';
    if (date2) date2.textContent = new Date().toLocaleDateString();
    if (signatureSub) signatureSub.textContent = 'Signature completed.';
    if (paymentSub) paymentSub.textContent = 'Payment setup completed.';
    if (signatureDate) signatureDate.textContent = `Signed ${dates.contract_sign_pay || '--'}`;
    if (paymentDate) paymentDate.textContent = `Configured ${dates.contract_payment_setup || '--'}`;
    setChecklistState('done', 'done', 'progress');

    // 2026-10-14 (per Leo): no SVT validation step. 2026-10-29 (MSA sync 10-28, per Leo): an automatic final
    // validation (promotions + account data) runs after payment; it confirms the sale or lists what's wrong.
    runFinalValidation('payment', 'The sale was confirmed automatically after signature, payment setup and final validation.');
  }

  updateFulfillmentBtn();
}

function formatContractDocMoney(value) {
  const num = Number(value);
  return Number.isFinite(num) ? formatMoney(num) : '--';
}

function generateContractEnvelopeId(seed) {
  const input = String(seed || 'VC-CONTRACT-DEMO');
  let state = 2166136261;
  for (let i = 0; i < input.length; i += 1) {
    state ^= input.charCodeAt(i);
    state = Math.imul(state, 16777619) >>> 0;
  }
  const hex = [];
  for (let i = 0; i < 32; i += 1) {
    state = (Math.imul(state, 1664525) + 1013904223) >>> 0;
    hex.push((state >>> 28).toString(16).toUpperCase());
  }
  const raw = hex.join('');
  return `${raw.slice(0, 8)}-${raw.slice(8, 12)}-${raw.slice(12, 16)}-${raw.slice(16, 20)}-${raw.slice(20, 32)}`;
}

function buildContractAdditionalTermsHtml() {
  const segment = proposalData.segment || 'SMB';
  if (segment === 'SMB') return '';

  const rows = [];
  if (proposalData.poNumber) rows.push(['Purchase Order #', proposalData.poNumber]);
  if (segment === 'Enterprise' && proposalData.costCenter) rows.push(['Cost center / GL', proposalData.costCenter]);
  if (segment === 'Government') {
    if (proposalData.contractVehicle) rows.push(['Contract vehicle', proposalData.contractVehicle]);
    if (proposalData.contractingOfficerName) rows.push(['Contracting Officer', proposalData.contractingOfficerName]);
    if (proposalData.contractingOfficerEmail) rows.push(['CO email', proposalData.contractingOfficerEmail]);
    if (proposalData.contractingOfficerPhone) rows.push(['CO phone', proposalData.contractingOfficerPhone]);
  }
  if (!rows.length) return '';

  const rowsHtml = rows.map(([key, value]) => `
    <tr>
      <td style="padding:8px 10px; border:1px solid #D1D5DB; width:38%; font-size:12px; font-weight:700; color:#111827;">${escapeContractDocHtml(key)}</td>
      <td style="padding:8px 10px; border:1px solid #D1D5DB; font-size:12px; color:#111827;">${escapeContractDocHtml(value)}</td>
    </tr>
  `).join('');

  return `
    <div style="margin-top:18px;">
      <div style="font-size:14px; font-weight:700; margin-bottom:8px; color:#111827;">4. Additional Terms</div>
      <table style="width:100%; border-collapse:collapse;">
        <tbody>${rowsHtml}</tbody>
      </table>
    </div>
  `;
}

function buildContractDocumentHtml(opt, context) {
  const customerName = escapeContractDocHtml(
    proposalData.accountName || proposalData.customerName || proposalData.account || 'Apex Construction LLC'
  );
  const customerAddress = escapeContractDocHtml(
    proposalData.accountAddress || proposalData.billingAddress || '123 Industrial Pkwy, Tampa FL 33602'
  );
  const envelopeId = generateContractEnvelopeId(opt?.id || `${customerName}-${context.dateStr}`);
  const agreementTitle = proposalData.isAddOn ? 'Service Order' : 'Purchase Agreement';
  const promoLine = context.optionPromoType && context.optionPromoType !== 'None'
    ? `<p style="margin:8px 0 0; font-size:12px; color:#111827;">A ${escapeContractDocHtml(context.optionPromoType)} promotion has been applied to this Agreement.</p>`
    : '';
  const totalMonthlyText = formatContractDocMoney(context.totalMonthly);
  const exhibitHtml = buildWaveInstallScheduleHtml(opt)
    ? `
      <div style="margin-top:24px; border-top:1px solid #D1D5DB; padding-top:14px;">
        <div style="font-size:14px; font-weight:700; margin-bottom:8px; color:#111827;">Exhibit A - Installation Schedule</div>
        ${buildWaveInstallScheduleHtml(opt)}
      </div>
    `
    : '';
  const shouldRenderSignedContract =
    screen === 'deal-result' ||
    contractSubState === 'signed' ||
    contractSubState === 'payment';
  const signedDate = context.dateStr;
  const customerSignerName = escapeContractDocHtml(
    proposalData.contactName || proposalData.customerContactName || 'Laura Mendez'
  );
  const verizonSignerName = escapeContractDocHtml(proposalData.repName || 'Jordan Rivera');

  const customerSignatureFieldHtml = shouldRenderSignedContract
    ? `<div style="display:inline-flex; align-items:center; gap:6px; padding:4px 8px; border:1px solid #0E9F6E; background:#ECFDF3; font-size:11px; font-weight:700; border-radius:3px; margin-right:6px; color:#065F46;"><span class="material-symbols-outlined" style="font-size:13px;">check_circle</span>Signed · ${customerSignerName}</div>
       <div style="display:inline-flex; align-items:center; padding:4px 8px; border:1px solid #0E9F6E; background:#ECFDF3; font-size:10px; font-weight:700; border-radius:3px; color:#065F46;">${signedDate}</div>`
    : `<span style="font-size:11px; color:#9CA3AF;">Awaiting signature</span>`;

  const verizonSignatureFieldHtml = shouldRenderSignedContract
    ? `<div style="display:inline-flex; align-items:center; gap:6px; padding:4px 8px; border:1px solid #0E9F6E; background:#ECFDF3; font-size:11px; font-weight:700; border-radius:3px; margin-right:6px; color:#065F46;"><span class="material-symbols-outlined" style="font-size:13px;">check_circle</span>Signed · ${verizonSignerName}</div>
       <div style="display:inline-flex; align-items:center; padding:4px 8px; border:1px solid #0E9F6E; background:#ECFDF3; font-size:10px; font-weight:700; border-radius:3px; color:#065F46;">${signedDate}</div>`
    : `<span style="font-size:11px; color:#9CA3AF;">Awaiting signature</span>`;

  return `
    <div class="doc-page-outer">
      <div class="vc-doc-shell">
        <div class="vc-doc-brand-line"></div>
        <div class="vc-doc-inner" style="background:#fff; color:#111827; font-family:'VerizonNHGDS',sans-serif;">
          <div style="font-family:monospace; font-size:10px; color:#6B7280; margin-bottom:16px;">Envelope ID: ${envelopeId}</div>

          <div style="text-align:center; margin-bottom:18px;">
            <div style="font-size:22px; letter-spacing:0.08em; font-weight:700;">${agreementTitle}</div>
          </div>

          <div style="display:grid; grid-template-columns:1fr 1fr; gap:18px; margin-bottom:18px;">
            <div>
              <div style="font-size:11px; font-weight:700; color:#4B5563; margin-bottom:4px;">Between:</div>
              <div style="font-size:13px; font-weight:700;">Verizon Connect</div>
              <div style="font-size:12px; color:#374151; line-height:1.45;">7701 Forsyth Blvd<br>St. Louis, MO 63105</div>
            </div>
            <div>
              <div style="font-size:11px; font-weight:700; color:#4B5563; margin-bottom:4px;">And:</div>
              <div style="font-size:13px; font-weight:700;">${customerName}</div>
              <div style="font-size:12px; color:#374151; line-height:1.45;">${customerAddress}</div>
              <div style="margin-top:8px; font-size:12px; color:#374151;"><strong>Effective Date:</strong> ${context.dateStr}</div>
            </div>
          </div>

          ${buildContractMsaBoxHtml(context.contractId)}
          <div style="margin-bottom:14px;">
            <div style="font-size:14px; font-weight:700; margin-bottom:8px; color:#111827;">1. Term</div>
            <p style="margin:0; font-size:12px; line-height:1.6; color:#111827;">This Agreement shall commence on the Effective Date and continue for a period of ${Number(opt?.term) || 36} months, unless terminated earlier in accordance with these terms.</p>
          </div>

          <div style="margin-bottom:14px;">
            <div style="font-size:14px; font-weight:700; margin-bottom:8px; color:#111827;">2. Equipment and Services</div>
            <table style="width:100%; border-collapse:collapse; font-size:12px;">
              <thead>
                <tr>
                  <th style="text-align:left; padding:8px 10px; border:1px solid #D1D5DB; font-weight:700;">Description</th>
                  <th style="text-align:left; padding:8px 10px; border:1px solid #D1D5DB; font-weight:700;">QTY</th>
                  <th style="text-align:left; padding:8px 10px; border:1px solid #D1D5DB; font-weight:700;">Unit / mo</th>
                  <th style="text-align:left; padding:8px 10px; border:1px solid #D1D5DB; font-weight:700;">Total / mo</th>
                </tr>
              </thead>
              <tbody>${context.rowsHtml}</tbody>
            </table>
          </div>

          <div style="margin-bottom:14px;">
            <div style="font-size:14px; font-weight:700; margin-bottom:8px; color:#111827;">3. Pricing and Payment</div>
            <p style="margin:0; font-size:12px; line-height:1.6; color:#111827;">Customer agrees to pay a recurring monthly amount of ${totalMonthlyText}. Billing cycle is monthly and subject to applicable taxes and fees.</p>
            ${promoLine}
          </div>

          ${buildContractAdditionalTermsHtml()}

          <div style="margin-top:18px;">
            <div style="font-size:14px; font-weight:700; margin-bottom:8px; color:#111827;">5. General Terms</div>
            <p style="margin:0; font-size:12px; line-height:1.6; color:#111827;">This agreement is subject to Verizon Connect Terms of Service. Pricing is valid until ${context.expirationStr}. Any changes to scope or pricing must be documented in writing by both parties.</p>
          </div>

          <div style="margin-top:26px; border-top:1px solid #D1D5DB; padding-top:16px;">
            <div style="font-size:14px; font-weight:700; margin-bottom:10px; color:#111827;">Signatures</div>
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:24px;">
              <div>
                <div style="height:1px; background:#111827; margin-bottom:8px;"></div>
                <div style="font-size:11px; color:#4B5563; margin-bottom:8px;">Customer signature &amp; date</div>
                ${customerSignatureFieldHtml}
              </div>
              <div>
                <div style="height:1px; background:#111827; margin-bottom:8px;"></div>
                <div style="font-size:11px; color:#4B5563; margin-bottom:8px;">Verizon Connect representative &amp; date</div>
                ${verizonSignatureFieldHtml}
              </div>
            </div>
          </div>

          ${exhibitHtml}
        </div>
      </div>
    </div>
  `;
}

function refreshContractPreview(triggerBtn) {
  const buttons = Array.from(document.querySelectorAll('[onclick="refreshContractPreview(this)"]'));
  buttons.forEach((btn) => btn.classList.add('is-spinning'));

  const activeOpt = window.selectedOpt || (Array.isArray(window.options) && window.options.length ? window.options[0] : null);
  if (activeOpt && typeof renderContractDoc === 'function') {
    window.selectedOpt = activeOpt;
    renderContractDoc(activeOpt);
  }

  window.setTimeout(() => {
    buttons.forEach((btn) => btn.classList.remove('is-spinning'));
  }, 680);

  if (typeof showToast === 'function') showToast('Contract synced from DocuSign');
}

// Data for VC.serviceOrderDoc from the selected option (brief 36). Prices come from the same pricing as the option
// card (calcBundle): list = standard unit price, MSA discount = the tier / term discount, promo = the option's promotion.
function buildServiceOrderDocData(opt, ctx) {
  const bundles = Array.isArray(opt.bundles) ? opt.bundles : [];
  // Same tier basis as the option card's total (calcOption → calcBundle with the option's tier quantity).
  const tierQty = (calcOption(opt, ctx.optionPromoType) || {}).tierQty;
  // 2026-11-10 (per Catalina): the Order lists SUBSCRIPTIONS, like the Price List — each solution splits into its
  // subscriptions (Vehicle Tracking, the camera subscription, each feature) and equal subscriptions add up into one
  // line (same price, discount and promotion). Transactions without a catalog split (cancellations, reactivations) keep
  // their own line.
  const merged = new Map();
  bundles.forEach(bundle => {
    const pricing = calcBundle(bundle, opt.term, bundle.promoType || ctx.optionPromoType, tierQty);
    const discountPct = pricing.tierTermPct || 0;
    const promoMult = (pricing.promoMult || 1) * (pricing.promoNameMult || 1);
    const promoPct = promoMult < 1 ? Math.round((1 - promoMult) * 10000) / 100 : 0;
    // The promotion's name (Promotions table and promo language — 2026-11-10).
    const promoName = promoPct ? (bundle.promoName || (bundle.promoType && bundle.promoType !== 'Standard' ? bundle.promoType : '') || ctx.optionPromoType || '') : '';
    const qty = Number(bundle.qty) || 0;
    const isTx = String(bundle.coreKey || '').startsWith('transaction-') && bundle.isolatedTransactionType !== 'upsell';
    const comps = !isTx && typeof getOrderPromotionComponents === 'function' ? getOrderPromotionComponents(bundle) : [];
    const parts = comps.length
      ? comps.map(c => ({ name: c.name, price: Number(c.listUnit) || 0, core: !!c.core, coreKey: c.coreKey }))
      : [{ name: bundle.name || bundle.coreName || '--', price: typeof getStandardUnitPrice === 'function' ? getStandardUnitPrice(bundle) : (bundle.basePrice || 0), core: true, coreKey: bundle.coreKey }];
    parts.forEach(part => {
      if (Math.abs(part.price) < 0.005 && part.core && bundle.isolatedTransactionType === 'upsell') return; // upsell: features only
      const key = [part.name, Math.round(part.price * 100), discountPct, promoPct, promoName].join('|');
      const line = merged.get(key) || { kind: 'subscription', name: part.name, qty: 0, price: part.price, discountPct, promoPct, promoName: promoName === 'Standard' ? '' : promoName, subs: [],
        core: part.core, coreKey: part.coreKey, msaUnit: part.price * (1 - discountPct / 100) };
      line.qty += qty;
      merged.set(key, line);
    });
  });
  const lines = typeof sortPriceListRows === 'function' ? sortPriceListRows([...merged.values()]) : [...merged.values()];
  // One-time Fees (2026-11-10, ACT-554 sync): key fobs — 3 per vehicle included with Driver ID, the extra ones charged.
  const oneTime = [];
  if (typeof KEYFOBS_INCLUDED !== 'undefined') {
    let fobs = 0, included = 0;
    bundles.forEach(b => {
      if (!(b.features || []).includes('driver-id') || b.isolatedTransactionType === 'cancel') return;
      const inc = KEYFOBS_INCLUDED * (Number(b.qty) || 0);
      const total = Number.isFinite(Number(b.keyfobQty)) && b.keyfobQty !== null && b.keyfobQty !== '' ? Number(b.keyfobQty) : inc;
      fobs += total;
      included += Math.min(total, inc);
    });
    if (fobs) oneTime.push({ name: 'Key fobs', type: 'One-time', qty: fobs, price: typeof KEYFOB_EXTRA_PRICE !== 'undefined' ? KEYFOB_EXTRA_PRICE : 5,
      included, includedLabel: 'Included with Driver ID (' + KEYFOBS_INCLUDED + ' per vehicle)' });
  }
  const termMonths = Number(opt.term) || 36;
  const start = proposalData.msaTermStart ? parseProposalDate(proposalData.msaTermStart) : new Date();
  const end = proposalData.msaEndDate ? parseProposalDate(proposalData.msaEndDate)
    : (start ? new Date(start.getFullYear(), start.getMonth() + termMonths, start.getDate() - 1) : null);
  const signedState = screen === 'deal-result' || contractSubState === 'signed' || contractSubState === 'payment';
  const customerName = proposalData.accountName || proposalData.customerName || proposalData.account || 'Apex Construction LLC';
  const contact = proposalData.contactName || proposalData.customerContactName || 'Laura Mendez';
  const rep = proposalData.repName || 'Sarah Patel';
  return {
    orderNumber: opt.orderNumber || '5003808673',
    orderDate: ctx.dateStr,
    rep,
    envelopeId: typeof generateContractEnvelopeId === 'function' ? generateContractEnvelopeId(opt.id || customerName) : '',
    customer: { name: customerName, account: proposalData.accountNumber || '1000212803', address: proposalData.accountAddress || proposalData.billingAddress || '123 Industrial Pkwy, Tampa FL 33602', contact },
    agreement: { number: proposalData.msaId || 'MSA-0004127', term: termMonths + ' months', start: start ? formatUsDate(start) : '--', end: end ? formatUsDate(end) : '--', rampUp: Number(proposalData.msaRampUpPeriod) || 30,
      // 2026-11-05: an existing account's Order co-terms with its MSA (dates known); a new MSA (Initial Sales, Migration)
      // shows no start date — the Contract Effective Date is set at Sales Confirmed.
      coTerm: !!(window.VC && VC.scenario && VC.scenario.existing) && !(typeof migrationModeOn !== 'undefined' && migrationModeOn) },
    discountPct: 0,
    promo: null,
    lines,
    oneTime,
    schedule: null,
    signed: signedState ? {
      customer: { name: contact, title: 'Operations Manager', date: ctx.dateStr, po: '' },
      verizon: { name: rep, title: 'Account Executive', date: ctx.dateStr }
    } : null
  };
}

function renderContractDocCore(opt) {
  if (!opt) return;

  const optTierDoc = (opt.forcedTierIndex !== undefined) ? opt.forcedTierIndex : -1;
  const optionPromoType = getOptionPromotion(opt);
  const { totalMonthly, totalUnits } = calcOption(opt, optionPromoType, optTierDoc);
  const dateStr = formatUsDate(new Date());
  const expirationDate = getSelectedExpirationDate();
  const expirationStr = formatExpirationDisplayDate(expirationDate);

  const bundles = Array.isArray(opt.bundles) ? opt.bundles : [];
  const rowsHtml = bundles.map((bundle) => {
    const bundlePromo = bundle.promoType || optionPromoType;
    const pricing = calcBundle(bundle, opt.term, bundlePromo, optTierDoc, totalUnits);
    const unitPrice = formatContractDocMoney(pricing.unitPrice);
    const monthly = formatContractDocMoney(pricing.monthly);
    return `
      <tr>
        <td style="padding:8px 10px; border:1px solid #D1D5DB;">${escapeContractDocHtml(bundle.coreName || '--')}</td>
        <td style="padding:8px 10px; border:1px solid #D1D5DB;">${escapeContractDocHtml(bundle.qty ?? '--')}</td>
        <td style="padding:8px 10px; border:1px solid #D1D5DB;">${unitPrice}</td>
        <td style="padding:8px 10px; border:1px solid #D1D5DB; font-weight:700;">${monthly}</td>
      </tr>
    `;
  }).join('');

  // 2026-10-27 (per Catalina, brief 36): the contract preview shows the new Service Order document (same as the
  // design page componentization/service-order-doc.html), built from the selected option.
  if (window.VC && typeof VC.serviceOrderDoc === 'function') {
    const soHtml = VC.serviceOrderDoc(buildServiceOrderDocData(opt, { optTierDoc, optionPromoType, totalUnits, dateStr }));
    ['contract-doc-viewer', 'contract-doc-viewer-modal'].forEach(id => { const el = document.getElementById(id); if (el) el.innerHTML = soHtml; });
    requestAnimationFrame(scaleDocPages);
    return;
  }

  const docHtml = buildContractDocumentHtml(opt, {
    optionPromoType,
    totalMonthly,
    totalUnits,
    dateStr,
    expirationStr,
    rowsHtml,
    contractId: opt.previewContractId || '',
  });

  const viewer = document.getElementById('contract-doc-viewer');
  if (viewer) viewer.innerHTML = docHtml;
  const modalViewer = document.getElementById('contract-doc-viewer-modal');
  if (modalViewer) modalViewer.innerHTML = docHtml;

  requestAnimationFrame(scaleDocPages);
}

// 2026-10-13 (per Catalina): the contract goes through the Purchase Portal — "Resend Purchase Portal Link"
// re-sends it directly (same send path, keeps the signature / payment progress); no message editor.
function resendContractLink() {
  if (screen !== 'contract-review') return;
  document.getElementById('more-menu-contract')?.classList.add('hidden');
  document.getElementById('more-menu-contract2')?.classList.add('hidden');
  document.getElementById('more-menu-contract-preview')?.classList.add('hidden');
  contractResendReturnState = ['signed', 'payment'].includes(contractSubState) ? contractSubState : 'waiting';
  contractResendMode = true;
  sendContractNow();
}

function simulateContractSigned() {
  if (contractSubState !== 'waiting') return;
  clearSignatureCompletionSimulation();
  document.getElementById('more-menu-contract')?.classList.add('hidden');
  document.getElementById('more-menu-contract2')?.classList.add('hidden');
  document.getElementById('more-menu-contract-preview')?.classList.add('hidden');
  continueFromSignatureCompleted();
}

function simulatePaymentSetup() {
  if (contractSubState !== 'signed' || isDirectBillAccount()) return;
  clearSignatureCompletionSimulation();
  clearSvtPendingTransition();
  contractSubState = 'payment';
  document.getElementById('more-menu-contract')?.classList.add('hidden');
  document.getElementById('more-menu-contract2')?.classList.add('hidden');
  document.getElementById('more-menu-contract-preview')?.classList.add('hidden');
  updateContractSubState();
  renderNav();
}

function openContractModifyConfirmModal() {
  document.getElementById('more-menu-contract')?.classList.add('hidden');
  document.getElementById('more-menu-contract2')?.classList.add('hidden');
  document.getElementById('more-menu-contract-preview')?.classList.add('hidden');
  const t = document.getElementById('contract-modify-title');
  const b = document.getElementById('contract-modify-body');
  const p = document.getElementById('contract-modify-proceed-btn');
  if (t) t.textContent = 'Modify proposal?';
  if (b) b.textContent = 'If you modify the proposal, you will return to the Proposal section and the current contract progress will be discarded. Are you sure you want to proceed?';
  if (p) p.textContent = 'Proceed';
  contractConfirmProceedAction = 'modify-proposal';
  document.getElementById('contract-modify-overlay')?.classList.add('is-open');
}

function updateContractSimulationMenuVisibility() {
  // 2026-10-13 (per Catalina): "Edit order schedule" only for orders above the flow's threshold.
  if (typeof SCHEDULE_THRESHOLD_QTY !== 'undefined') {
    const opt = (typeof selectedOpt !== 'undefined' && selectedOpt) || null;
    const units = opt && Array.isArray(opt.bundles) ? opt.bundles.reduce((sum, b) => sum + (Number(b.qty) || 0), 0) : 0;
    document.querySelectorAll('.contract-schedule-menu-item').forEach(el => el.classList.toggle('hidden', units < SCHEDULE_THRESHOLD_QTY));
  }
  const showMarkSigned = contractSubState === 'waiting';
  const showContractSigned = contractSubState === 'waiting';
  const showPaymentSetup = contractSubState === 'signed' && !isDirectBillAccount();
  const hasAnyAction = showMarkSigned || showContractSigned || showPaymentSetup;

  ['contract', 'contract2', 'contract-preview'].forEach((suffix) => {
    document.getElementById(`sim-title-${suffix}`)?.classList.toggle('hidden', !hasAnyAction);
    document.getElementById(`sim-mark-signed-${suffix}`)?.classList.toggle('hidden', !showMarkSigned);
    document.getElementById(`sim-contract-signed-${suffix}`)?.classList.toggle('hidden', !showContractSigned);
    document.getElementById(`sim-payment-setup-${suffix}`)?.classList.toggle('hidden', !showPaymentSetup);
  });
}

function toggleContractPreviewMenu(event) {
  if (event) {
    event.preventDefault();
    event.stopPropagation();
  }
  updateContractSimulationMenuVisibility();
  const m1 = document.getElementById('more-menu-contract');
  const m2 = document.getElementById('more-menu-contract2');
  const m3 = document.getElementById('more-menu-contract-preview');
  if (!m3) return;
  setKebabMenuOpen(m1, false);
  setKebabMenuOpen(m2, false);
  const shouldOpen = m3.classList.contains('hidden');
  setKebabMenuOpen(m3, shouldOpen);
}

function toggleContractMenu2(event) {
  if (event) {
    event.preventDefault();
    event.stopPropagation();
  }
  updateContractSimulationMenuVisibility();
  const m1 = document.getElementById('more-menu-contract');
  const m2 = document.getElementById('more-menu-contract2');
  const m3 = document.getElementById('more-menu-contract-preview');
  if (!m2) return;
  setKebabMenuOpen(m1, false);
  setKebabMenuOpen(m3, false);
  const shouldOpen = m2.classList.contains('hidden');
  setKebabMenuOpen(m2, shouldOpen);
}

function toggleContractMenu(event) {
  if (event) {
    event.preventDefault();
    event.stopPropagation();
  }
  updateContractSimulationMenuVisibility();
  const m1 = document.getElementById('more-menu-contract');
  const m2 = document.getElementById('more-menu-contract2');
  const m3 = document.getElementById('more-menu-contract-preview');
  if (!m1) return;
  setKebabMenuOpen(m2, false);
  setKebabMenuOpen(m3, false);
  const shouldOpen = m1.classList.contains('hidden');
  setKebabMenuOpen(m1, shouldOpen);
}

function renderContractDoc(opt) {
  renderContractDocCore(opt);
}

function totalUnitsForOption(opt) {
  if (!opt || !Array.isArray(opt.bundles)) return 0;
  return opt.bundles.reduce((sum, b) => sum + (Number(b.qty) || 0), 0);
}

function openContractInDocuSign() {
  const overlay = document.getElementById('contract-preview-overlay');
  const source = document.getElementById('contract-doc-viewer');
  const target = document.getElementById('contract-doc-viewer-modal');
  if (!overlay || !source || !target) return;
  const activeOpt = selectedOpt || (Array.isArray(options) && options.length ? options[0] : null);
  if (activeOpt && typeof renderContractDocCore === 'function') {
    renderContractDocCore(activeOpt);
  }
  target.innerHTML = source.innerHTML;
  overlay.classList.add('is-open');
  document.body.style.overflow = 'hidden';
  requestAnimationFrame(scaleDocPages);
}

function closeContractPreviewModal() {
  const overlay = document.getElementById('contract-preview-overlay');
  if (!overlay) return;
  overlay.classList.remove('open', 'is-open');
  document.body.style.overflow = '';
}

function handleContractPreviewOverlayClick(event) {
  if (event?.target?.id === 'contract-preview-overlay') {
    closeContractPreviewModal();
  }
}

function buildWaveInstallScheduleHtml(opt) {
  const waves = Array.isArray(opt && opt.waves) ? opt.waves : [];
  if (!waves.length) return '';
  const isGov = proposalData.segment === 'Government';
  const govTh = isGov
    ? `<th style="text-align:left; padding:10px 16px; font-size:10px; font-weight:700; letter-spacing:0.02em; color:#7a7a7a; border-bottom:1px solid #efefef;">Approp. ref / expiry</th>`
    : '';
  const rows = waves.map(w => {
    const dateStr = w.targetDate
      ? new Date(w.targetDate + 'T00:00:00').toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
      : 'TBD';
    const qty = Number(w.qty) || 0;
    let govTd = '';
    if (isGov) {
      const ref = (w.appropsRef || '').replace(/</g, '&lt;') || '&mdash;';
      const expStr = w.appropsExpiry
        ? new Date(w.appropsExpiry + 'T00:00:00').toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
        : 'N/A';
      const warn = w.appropsExpiry && w.targetDate && w.targetDate > w.appropsExpiry
        ? ` <span style="color:#92400E;font-weight:700;font-size:10px;">\u26a0 Expiry before wave date</span>`
        : '';
      govTd = `<td style="padding:12px 16px; border-bottom:1px solid #f0f0f0; font-size:12px; color:#1a1a1a;">${ref}<br><span style="color:#6B7280;font-size:11px;">${expStr}</span>${warn}</td>`;
    }
    return `<tr>
        <td style="padding:12px 16px; border-bottom:1px solid #f0f0f0; font-size:13px; color:#1a1a1a; font-weight:600;">${(w.name || 'Wave').replace(/</g,'&lt;')}</td>
        <td style="padding:12px 16px; border-bottom:1px solid #f0f0f0; font-size:13px; color:#1a1a1a;">${dateStr}</td>
        <td style="padding:12px 16px; border-bottom:1px solid #f0f0f0; font-size:13px; color:#1a1a1a;">${qty}</td>
        <td style="padding:12px 16px; border-bottom:1px solid #f0f0f0; font-size:11px; font-weight:700; color:#1D4ED8;">Contracted \u2014 Not Billing</td>
        ${govTd}
      </tr>`;
  }).join('');
  const govFootnote = isGov
    ? ` Government slots may enter <strong>Lapsed</strong> if appropriation expires before dispatch (no ECF, inventory released). `
    : '';
  return `
    <div style="height:1px; background:#efefef; margin:28px 0;"></div>
    <div style="font-size:12px; font-weight:800; letter-spacing:0.02em; color:#1a1a1a; margin-bottom:14px;">Installation schedule</div>
    <table style="width:100%; border-collapse:collapse; border:1px solid #efefef; border-radius:8px; overflow:hidden; font-family:inherit;">
      <thead>
        <tr style="background:#fafafa;">
          <th style="text-align:left; padding:10px 16px; font-size:10px; font-weight:700; letter-spacing:0.02em; color:#7a7a7a; border-bottom:1px solid #efefef;">Wave</th>
          <th style="text-align:left; padding:10px 16px; font-size:10px; font-weight:700; letter-spacing:0.02em; color:#7a7a7a; border-bottom:1px solid #efefef;">Target date</th>
          <th style="text-align:left; padding:10px 16px; font-size:10px; font-weight:700; letter-spacing:0.02em; color:#7a7a7a; border-bottom:1px solid #efefef;">Units</th>
          <th style="text-align:left; padding:10px 16px; font-size:10px; font-weight:700; letter-spacing:0.02em; color:#7a7a7a; border-bottom:1px solid #efefef;">Initial slot status</th>
          ${govTh}
        </tr>
      </thead>
      <tbody>${rows}</tbody>
    </table>
    <div style="margin-top:10px; font-size:11px; color:#7a7a7a; line-height:1.6;">
      Units enter <strong>Active-Billing</strong> upon device activation. <strong>Pending Bind</strong> slots (on-site, not yet activated) do not count toward the billing floor.
      Contracted units undispatched 30\u00a0days past target date activate the pool floor per MSA \u00a74.2 (BR-44/45).${govFootnote}
    </div>`;
}

function sendContractNow() {
  {
    const isResend = contractResendMode;
    const returnState = ['signed', 'payment'].includes(contractResendReturnState)
      ? contractResendReturnState
      : 'waiting';

    // Switch to the signature & payment tracking
    document.getElementById('contract-phase-signpay').classList.remove('hidden');
    // Sync doc viewer 2
    const v1 = document.getElementById('contract-doc-viewer');
    const v2 = document.getElementById('contract-doc-viewer2');
    if (v1 && v2) {
      v2.innerHTML = v1.innerHTML;
      // Recompute scale using the new container width in Signature phase.
      requestAnimationFrame(scaleDocPages);
    }
    // Stepper: step 1 done → step 2 active
    const d1 = document.getElementById('c-dot-1');
    const d2 = document.getElementById('c-dot-2');
    const l1 = document.getElementById('c-line-1');
    if (d1) { d1.className = 'c-step-dot done'; }
    if (l1) l1.className = 'c-line done';
    if (d2) d2.className = 'c-step-dot active';
    if (document.getElementById('c-dot-label-2')) document.getElementById('c-dot-label-2').className = 'c-step-label';
    const date1 = document.getElementById('contract-date-1');
    if (date1) date1.textContent = new Date().toLocaleDateString();

    // Show a basic loader before entering waiting/signature tracking state.
    setContractSendLoaderVisible(true);
    clearContractSendLoaderTimer();
    contractSendLoaderTimer = window.setTimeout(() => {
      contractSendLoaderTimer = null;
      setContractSendLoaderVisible(false);
      finalizeContractSendTransition(isResend, returnState);
    }, CONTRACT_SEND_LOADER_DELAY_MS);
  }
}


/* ── Deal Result (shared, 2026-10-08 — per Catalina: Contract and Deal Result are the same steps in both flows).
   Initial Sales version: won (Sale confirmed — Back to Proposal Dashboard + View Contract), closed-lost. Fulfillment is on hold, so
   there is no fulfillment CTA here. Optional flow hook: captureCompletedPilotAccount() (Initial Sales pilots). */
let lastDealResultMode = null;
// 2026-10-14 (per Catalina): the Deal Result button says where it goes.
const DEAL_RESULT_BACK_LABEL = 'Back to Proposal Dashboard';
window.VC = window.VC || {};
window.VC.dealResultMarkup = function () { return "\u003cdiv id=\"screen-deal-result\" class=\"content-area hidden deal-result-screen\">\n    \u003cdiv id=\"deal-result-main-content\" class=\"deal-result-main\">\n      \u003cdiv id=\"deal-result-icon\" class=\"deal-result-icon\">\u003c/div>\n      \u003ch2 id=\"deal-result-title\" class=\"deal-result-title\">\u003c/h2>\n      \u003cp id=\"deal-result-subtitle\" class=\"deal-result-subtitle\">\u003c/p>\n      \u003cdiv class=\"deal-result-ctas\">\n        \u003cbutton type=\"button\" id=\"deal-result-secondary-btn\" class=\"btn btn--primary btn--large btn-block hidden\" onclick=\"openDealResultViewContractConfirmModal()\">View Contract\u003c/button>\n        \u003cbutton type=\"button\" id=\"deal-result-primary-btn\" class=\"btn btn--secondary btn--large btn-block\" onclick=\"closeDealResult()\">Back to Proposal Dashboard\u003c/button>\n      \u003c/div>\n    \u003c/div>\n  \u003c/div>"; };

function enterDealResult(mode = 'won') {
  clearSignatureCompletionSimulation();
  clearSvtPendingTransition();
  lastDealResultMode = mode;
  contractResendMode = false;
  contractResendReturnState = 'waiting';
  // Hide all main screens, show deal result
  document.getElementById('screen-drafting').classList.add('hidden');
  hideProposalReviewModal();
  document.getElementById('screen-proposal-selection').classList.add('hidden');
  document.getElementById('screen-contract').classList.add('hidden');
  document.getElementById('screen-deal-result').classList.remove('hidden');
  dismissSuccessBanner();

  // Update main stepper — both steps done
  const dot1 = document.getElementById('step-dot-1');
  const dot2m = document.getElementById('step-dot-2');
  if (dot1) { dot1.className = 'vc-step-dot done'; dot1.innerHTML = '<span class="material-symbols-outlined" style="font-size:14px;">check</span>'; }
  if (dot2m) { dot2m.className = 'vc-step-dot done'; dot2m.innerHTML = '<span class="material-symbols-outlined" style="font-size:14px;">check</span>'; }

  // Set deal result dates
  const today = new Date().toLocaleDateString();
  const d1 = document.getElementById('deal-date-1');
  const d2 = document.getElementById('deal-date-2');
  const d3 = document.getElementById('deal-date-3');
  if (d1) d1.textContent = today;
  if (d2) d2.textContent = today;
  if (d3) d3.textContent = today;

  // Footer — hide send, hide back
  document.getElementById('footer-send').classList.add('hidden');
  document.getElementById('footer-back').classList.remove('visible');
  document.getElementById('footer-back').style.display = 'none';

  touchNavDate('result', true);
  const iconWrap = document.getElementById('deal-result-icon');
  const title = document.getElementById('deal-result-title');
  const subtitle = document.getElementById('deal-result-subtitle');
  const primaryBtn = document.getElementById('deal-result-primary-btn');
  const closeRow = document.getElementById('deal-result-close-row');
  const mainContent = document.getElementById('deal-result-main-content');
  if (mainContent) mainContent.classList.remove('hidden');

  if (iconWrap && title && subtitle && primaryBtn) {
    if (mode === 'rejected') {
      if (closeRow) closeRow.style.display = 'none';
      iconWrap.innerHTML = `<svg width="52" height="56" viewBox="0 0 52 56" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="4" y="2" width="36" height="46" rx="3" stroke="#000" stroke-width="2"/>
        <line x1="12" y1="16" x2="32" y2="16" stroke="#000" stroke-width="2" stroke-linecap="round"/>
        <line x1="12" y1="24" x2="32" y2="24" stroke="#000" stroke-width="2" stroke-linecap="round"/>
        <line x1="12" y1="32" x2="22" y2="32" stroke="#000" stroke-width="2" stroke-linecap="round"/>
        <circle cx="38" cy="44" r="11" fill="#000"/>
        <path d="M33.5 39.5L42.5 48.5M42.5 39.5L33.5 48.5" stroke="white" stroke-width="2" stroke-linecap="round"/>
      </svg>`;
      title.innerHTML = 'Deal marked as closed-lost';
      subtitle.innerHTML = 'The quoting session has been closed based on the selected rejection reason.';
      primaryBtn.textContent = DEAL_RESULT_BACK_LABEL;
      primaryBtn.disabled = false;
      primaryBtn.onclick = () => closeDealResult();
    } else {
      if (closeRow) closeRow.style.display = 'flex';
      iconWrap.innerHTML = `<svg width="52" height="56" viewBox="0 0 52 56" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="4" y="2" width="36" height="46" rx="3" stroke="#000" stroke-width="2"/>
        <line x1="12" y1="16" x2="32" y2="16" stroke="#000" stroke-width="2" stroke-linecap="round"/>
        <line x1="12" y1="24" x2="32" y2="24" stroke="#000" stroke-width="2" stroke-linecap="round"/>
        <line x1="12" y1="32" x2="22" y2="32" stroke="#000" stroke-width="2" stroke-linecap="round"/>
        <circle cx="38" cy="44" r="11" fill="#000"/>
        <path d="M33 44l3.5 3.5L43 40.5" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>`;
      // 2026-10-14 (per Catalina): no SVT step — the won state is the confirmed sale.
      title.innerHTML = 'Sale confirmed';
      subtitle.innerHTML = isDirectBillAccount()
        ? 'The contract is signed. The sale has been confirmed.'
        : 'The contract is signed and the payment method is set up. The sale has been confirmed.';
      primaryBtn.textContent = DEAL_RESULT_BACK_LABEL;
      primaryBtn.disabled = false;
      primaryBtn.onclick = () => closeDealResult();
    }
  }
  updateDealResultFulfillmentCta();
  screen = 'deal-result';
  renderNav();
}

function closeDealResult() {
  document.getElementById('more-menu-deal-result')?.classList.add('hidden');
  if (lastDealResultMode !== 'rejected' && typeof captureCompletedPilotAccount === 'function') captureCompletedPilotAccount(); // Initial Sales pilots
  clearSvtPendingTransition();
  openQuotesList();
}

function openDealResultViewContractConfirmModal() {
  document.getElementById('more-menu-deal-result')?.classList.add('hidden');
  closeContractModifyConfirmModal();
  openContractInDocuSign();
}

function updateDealResultFulfillmentCta() {
  const primaryBtn = document.getElementById('deal-result-primary-btn');
  const secondaryBtn = document.getElementById('deal-result-secondary-btn');
  const badge = document.getElementById('deal-result-status-badge');
  if (!primaryBtn) return;


  if (badge) {
    badge.textContent = 'Deal validated';
    badge.style.background = '#dcfce7';
    badge.style.color = 'var(--green)';
    badge.style.borderColor = '#86efac';
  }
  primaryBtn.textContent = DEAL_RESULT_BACK_LABEL;
  primaryBtn.disabled = false;
  primaryBtn.onclick = () => closeDealResult();
  // Sale confirmed (2026-10-14, per Catalina): View Contract first, primary; Back to Proposal Dashboard secondary.
  // Closed-lost has no contract: Back to Proposal Dashboard alone, primary.
  const showView = lastDealResultMode !== 'rejected';
  if (secondaryBtn) {
    secondaryBtn.classList.toggle('hidden', !showView);
    secondaryBtn.disabled = false;
    if (showView) secondaryBtn.onclick = () => openDealResultViewContractConfirmModal();
  }
  primaryBtn.classList.toggle('btn--secondary', showView);
  primaryBtn.classList.toggle('btn--primary', !showView);
}


/* Mark as dead — confirm (shared, 2026-10-09; Existing used to say "Closed", now "Dead" in both flows per Catalina).
   From a Proposal Dashboard row: Dead badge with the closure reason; from drafting/selection: Deal Result. */
function confirmMarkDead() {
  const reason = document.getElementById('dead-reason-select')?.value;
  if (!reason) {
    setMarkDeadReasonError(true);
    return;
  }
  closeMarkDeadModal();

  if (_qlClosePendingRow) {
    // Coming from quotes list — update badge and move row to bottom
    const row = _qlClosePendingRow;
    _qlClosePendingRow = null;
    const quoteName = row.querySelector('a.record-link')?.textContent?.trim() || 'Quote';
    const reasonEl  = document.getElementById('dead-reason-select');
    const reasonText = reasonEl?.options[reasonEl.selectedIndex]?.text || reason;
    const badgeCell = row.querySelector('.badge')?.closest('td');
    if (badgeCell) {
      const today = new Date();
      const closedDate = today.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
      badgeCell.innerHTML = `
        <span class="badge badge--black badge__tooltip-wrap">
          Dead
          <span class="badge__tooltip-icon material-symbols-outlined" style="font-size:16px;width:16px;height:16px;font-variation-settings:'FILL' 0,'wght' 300;">info</span>
          <div class="badge__tooltip-popup">
            <strong style="font-size:12px; font-weight:700; color:#000; line-height:16px; display:block; margin-bottom:2px;">Closure reason</strong>
            <div style="font-size:12px; font-weight:400; color:#000; line-height:16px;">${reasonText}</div>
          </div>
        </span>`;
      // 2026-10-05 (per Catalina): no date under the Dead badge — the
      // Created / Modified column already carries it, so Modified updates.
      const modifiedNote = row.querySelector('td:nth-child(4) .ql-cell-ref');
      if (modifiedNote) modifiedNote.textContent = `Modified ${closedDate}`;
    }
    const tbody = row.closest('tbody');
    if (tbody) tbody.appendChild(row);
    const newBtn = document.getElementById('btn-new-proposal');
    if (newBtn) { newBtn.disabled = false; newBtn.title = ''; }
    // Show success notification
    showSuccessBanner('Proposal marked as dead', `"${quoteName}" was marked as Dead.`);
  } else {
    // Coming from within drafting/selection — navigate to deal result
    const reasonEl = document.getElementById('dead-reason-select');
    logProposalEvent('Marked as dead', 'The proposal was marked as dead.', { reason: reasonEl?.options[reasonEl.selectedIndex]?.text || reason });
    enterDealResult('rejected');
  }
}

// ── Contract validations before sending (2026-11-04, user story "Opportunity moving from presenting to negotiating") ──
// Creating the contract moves the opportunity from Presenting to Negotiating and runs the validations one after the
// other: GCH and CLE ID (already checked when the opportunity was created), the ECS check (can take up to 10 minutes)
// (account configuration removed 2026-11-04, per Catalina: an earlier validation already covers it, with the
// promotions). Send Purchase Portal Link stays
// disabled until every validation passes. The rep can leave the page: the proposal shows Pending Validation on the
// dashboard, then Contract Created (validated) or Validation Failed. Per Catalina: one compact bar showing only the
// validation running now (the list can grow), with View details for the whole list. No actions on a failure yet.
// 2026-11-05 (ACT-554 sync, Rogelio / Anil): GCH and CLE ID are one item, already passed (checked at Select & Create
// Contract — the CLE ID modal stops the rep before); then BP creation (M1), MSA creation and the ECS check, which block
// sending (the contract document is still generated). If M1 fails (billing address and / or opportunity values),
// each failure is a pending action on the account badge; fixing both in Account setup passes M1 and the rest go on.
// Demo timing: M1 and MSA creation 3 s each, ECS check 30 s, the longest (instead of up to 10 minutes).
const CONTRACT_VALIDATIONS = [
  { key: 'gchcleid', label: 'GCH and CLE ID', sub: 'Checked at Select & Create Contract', demoMs: 0, preChecked: true },
  { key: 'm1', label: 'BP creation (M1)', sub: 'Business Partner creation milestone', demoMs: 3000 },
  { key: 'msa', label: 'MSA creation', sub: 'Creates the MSA', demoMs: 3000 },
  { key: 'ecs', label: 'ECS check', sub: 'Usually takes up to 10 minutes', demoMs: 30000 },
];
// The short reason under a failed validation in View details.
const CONTRACT_VALIDATION_ROW_REASONS = {
  m1: 'Missing information in the billing address and the opportunity.',
  ecs: "The account didn't pass the ECS check.",
};
const CONTRACT_VALIDATION_ERRORS = {
  m1: 'Missing information in the billing address and the opportunity. Fix it in Account setup (pending actions under the account name).',
  ecs: "The account didn't pass the ECS check.",
};
// M1 failure → pending actions on the account (Account setup): { address, opportunity }.
let m1PendingFixes = { address: false, opportunity: false };
let m1FixedForDemo = false; // once fixed, M1 passes when it runs again
function getM1PendingCount() {
  return (m1PendingFixes.address ? 1 : 0) + (m1PendingFixes.opportunity ? 1 : 0);
}
function syncM1PendingActions() {
  if (typeof updateAccountBadgeFromValidation === 'function') updateAccountBadgeFromValidation();
  if (typeof syncAccountSetupContractAccountContext === 'function') syncAccountSetupContractAccountContext();
}
// Account setup saved a fix ('address' | 'opportunity'); with nothing left, M1 runs again and the validations go on.
function contractValidationM1Fixed(part) {
  if (!m1PendingFixes[part]) return;
  m1PendingFixes[part] = false;
  syncM1PendingActions();
  const cv = contractValidation;
  if (getM1PendingCount() || !cv || cv.state !== 'failed' || cv.failedKey !== 'm1') return;
  // 2026-11-05 (per Catalina): once both are saved, BP creation (M1) turns green and the rest go on.
  m1FixedForDemo = true;
  cv.state = 'running';
  cv.failedKey = null;
  cv.results.m1 = 'passed';
  cv.index = CONTRACT_VALIDATIONS.findIndex(v => v.key === 'm1') + 1;
  if (typeof logProposalEvent === 'function') logProposalEvent('Contract validation started', 'Account setup fixed; BP creation (M1) passed, the other validations go on.');
  contractValidationStatusChanged();
  runNextContractValidation();
}
// The state a dashboard row opens with (set before createContract): 'passed' | 'pending' | 'failed' | null (run).
let contractValidationPreset = null;

function cancelContractValidations() {
  if (contractValidation) { clearTimeout(contractValidation.timer); clearInterval(contractValidation.tick); }
  contractValidation = null;
  if (getM1PendingCount()) { m1PendingFixes = { address: false, opportunity: false }; syncM1PendingActions(); }
  m1FixedForDemo = false;
}

function startContractValidations() {
  cancelContractValidations();
  const preset = contractValidationPreset;
  contractValidationPreset = null;
  const cv = { results: {}, index: 0, state: 'running', open: false, timer: null, tick: null, stepStartedAt: Date.now() };
  CONTRACT_VALIDATIONS.forEach(v => { cv.results[v.key] = 'waiting'; });
  contractValidation = cv;
  const ecsIndex = CONTRACT_VALIDATIONS.findIndex(v => v.key === 'ecs');
  if (preset === 'passed') {
    CONTRACT_VALIDATIONS.forEach(v => { cv.results[v.key] = 'passed'; });
    cv.state = 'passed';
    renderContractValidation();
    return;
  }
  if (preset === 'failed') {
    CONTRACT_VALIDATIONS.slice(0, ecsIndex).forEach(v => { cv.results[v.key] = 'passed'; });
    cv.results.ecs = 'failed';
    cv.state = 'failed';
    cv.failedKey = 'ecs';
    renderContractValidation();
    return;
  }
  if (preset === 'pending') {
    // A sample proposal left validating: the ECS check started a few minutes ago and goes on from there.
    CONTRACT_VALIDATIONS.slice(0, ecsIndex).forEach(v => { cv.results[v.key] = 'passed'; });
    cv.index = ecsIndex;
    runNextContractValidation(Date.now() - 8 * 60000);
    return;
  }
  if (typeof logProposalEvent === 'function') logProposalEvent('Contract validation started', 'GCH and CLE ID, BP creation (M1), MSA creation and ECS check.');
  CONTRACT_VALIDATIONS.forEach((v, i) => { if (v.preChecked) { cv.results[v.key] = 'passed'; cv.index = i + 1; } });
  runNextContractValidation();
}

function contractValidationStatusChanged() {
  renderContractValidation();
  if (typeof renderNav === 'function') renderNav();
}

function runNextContractValidation(startedAt) {
  const cv = contractValidation;
  if (!cv) return;
  const v = CONTRACT_VALIDATIONS[cv.index];
  if (!v) {
    cv.state = 'passed';
    clearInterval(cv.tick);
    if (typeof logProposalEvent === 'function') logProposalEvent('Contract validation passed', 'Every validation passed. The Purchase Portal link can be sent.');
    contractValidationStatusChanged();
    return;
  }
  cv.results[v.key] = 'running';
  cv.stepStartedAt = startedAt || Date.now();
  clearInterval(cv.tick);
  if (v.key === 'ecs') cv.tick = setInterval(renderContractValidation, 30000); // keeps "Started N min ago" current
  renderContractValidation();
  if (v.key === 'ecs' && contractValidationSim === 'running') return; // the wait itself is the demo
  cv.timer = setTimeout(() => {
    if (contractValidation !== cv) return;
    const fails = (contractValidationSim === 'ecs-fail' && v.key === 'ecs') || (contractValidationSim === 'm1-fail' && v.key === 'm1' && !m1FixedForDemo);
    if (fails) {
      cv.results[v.key] = 'failed';
      cv.state = 'failed';
      cv.failedKey = v.key;
      clearInterval(cv.tick);
      if (v.key === 'm1') { m1PendingFixes = { address: true, opportunity: true }; syncM1PendingActions(); }
      if (typeof logProposalEvent === 'function') logProposalEvent('Contract validation failed', `${v.label}: ${CONTRACT_VALIDATION_ERRORS[v.key]}`);
      contractValidationStatusChanged();
      return;
    }
    cv.results[v.key] = 'passed';
    cv.index += 1;
    runNextContractValidation();
  }, v.demoMs);
}

function toggleContractValidationDetails(event) {
  if (event) event.stopPropagation();
  if (!contractValidation) return;
  contractValidation.open = !contractValidation.open;
  renderContractValidation();
}

function contractValidationAgo(at) {
  const minutes = Math.floor((Date.now() - at) / 60000);
  if (minutes < 1) return 'less than a minute ago';
  return `${minutes} min ago`;
}

function renderContractValidation() {
  const cv = contractValidation;
  const sendBtn = document.getElementById('contract-send-portal-btn');
  if (sendBtn) {
    const ready = !cv || cv.state === 'passed';
    sendBtn.disabled = !ready;
    if (ready) sendBtn.removeAttribute('title');
    else sendBtn.title = 'Available when the contract is validated';
  }
  const host = document.getElementById('contract-validation-host');
  if (!host) return;
  if (!cv) { host.innerHTML = ''; return; }
  // 2026-11-04 (per Catalina): "Validations:" on the Contract Review subtitle, after the recipient and a divider — not
  // between the instruction and the DocuSign preview, and the kebab stays next to the button. View details opens the
  // whole list in a popover.
  const total = CONTRACT_VALIDATIONS.length;
  const done = CONTRACT_VALIDATIONS.filter(v => cv.results[v.key] === 'passed').length;
  const current = CONTRACT_VALIDATIONS.find(v => cv.results[v.key] === 'running' || cv.results[v.key] === 'failed');
  // 2026-11-04 (per Catalina): the same state circles as the Contract progress checklist (vc-checklist__state):
  // done = green check, in progress = loader, failed = red ×, waiting = empty circle.
  const loaderSvg = '<div class="loader" aria-hidden="true"><svg class="loader__spinner" viewBox="0 0 64 64" fill="none"><circle class="loader__track" cx="32" cy="32" r="28" stroke-width="6" stroke-linecap="round"/><path class="loader__arc" d="M32 4 A28 28 0 0 1 60 32" stroke-width="6" stroke-linecap="round" fill="none"/></svg></div>';
  const stateIcon = (state, small) => {
    const cls = { passed: 'done', running: 'progress', failed: 'error', waiting: 'pending' }[state];
    const inner = state === 'passed' ? '<span class="material-symbols-outlined">check</span>'
      : state === 'failed' ? '<span class="material-symbols-outlined">close</span>'
      : state === 'running' ? loaderSvg : '';
    return `<span class="vc-checklist__state vc-checklist__state--${cls}${small ? ' vc-checklist__state--small' : ''}" aria-hidden="true">${inner}</span>`;
  };
  let iconHtml, status, meta, message;
  if (cv.state === 'passed') {
    iconHtml = stateIcon('passed', true);
    status = 'All passed';
    meta = '';
    message = 'Every validation passed. You can send the Purchase Portal link.';
  } else if (cv.state === 'failed') {
    iconHtml = stateIcon('failed', true);
    status = `${current ? current.label : 'Validation'} failed`;
    meta = '';
    message = `${CONTRACT_VALIDATION_ERRORS[cv.failedKey] || ''} The contract can't be sent until it's resolved.`;
  } else {
    iconHtml = stateIcon('running', true);
    status = current ? current.label : '';
    const isEcs = current && current.key === 'ecs';
    meta = `(${done + 1} of ${total})${isEcs ? ' · Up to 10 min' : ''}`;
    message = isEcs
      ? `The ECS check usually takes up to 10 minutes (started ${contractValidationAgo(cv.stepStartedAt)}). You can leave this page; the status shows on the dashboard.`
      : `Validations run one after the other (started ${contractValidationAgo(cv.stepStartedAt)}).`;
  }
  const progress = cv.state === 'passed' ? 100 : Math.round(((done + (cv.state === 'failed' ? 1 : 0)) / total) * 100);
  const rowStatus = { passed: 'Passed', running: 'In progress', failed: 'Failed', waiting: 'Waiting' };
  const rows = CONTRACT_VALIDATIONS.map(v => {
    const r = cv.results[v.key];
    // 2026-11-05 (per Catalina): no descriptor under each validation; only a failed one says why.
    // 2026-11-05 (per Catalina): each item carries its own context — a failed one its reason and fix, the running
    // ECS check its time.
    const fix = r === 'failed' && v.key === 'm1' ? '<button type="button" class="text-link text-link--small contract-validation__fix" onclick="openAccountSetupEmbed()">Fix in Account setup</button>' : '';
    const reason = r === 'failed' ? `<span class="contract-validation__row-sub contract-validation__row-sub--error">${CONTRACT_VALIDATION_ROW_REASONS[v.key] || ''}</span>${fix}`
      : r === 'running' && v.key === 'ecs' ? `<span class="contract-validation__row-sub">Up to 10 min · started ${contractValidationAgo(cv.stepStartedAt)}</span>` : '';
    return `<li class="contract-validation__row contract-validation__row--${r}">${stateIcon(r)}<span class="contract-validation__row-label">${v.label}${reason}</span><span class="contract-validation__row-status">${rowStatus[r]}</span></li>`;
  }).join('');
  host.innerHTML = `<span class="contract-validation contract-validation--${cv.state}" role="status" aria-live="polite">
    <span class="contract-validation__label">Validations:</span>
    <span class="contract-validation__icon">${iconHtml}</span>
    <span class="contract-validation__status">${status}</span>
    ${meta ? `<span class="contract-validation__meta">${meta}</span>` : ''}
    <button type="button" class="text-link text-link--small contract-validation__details" aria-expanded="${cv.open}" aria-controls="contract-validation-popover" onclick="toggleContractValidationDetails(event)">View details</button>
  </span>
  <div id="contract-validation-popover" class="contract-validation__popover${cv.open ? '' : ' hidden'}" role="dialog" aria-label="Validations" onclick="event.stopPropagation()">
    <div class="contract-validation__popover-head">
      <span class="contract-validation__count">${done} of ${total} complete</span>
      <span class="contract-validation__bar" aria-hidden="true"><span class="contract-validation__fill" style="--cv-progress:${progress}%"></span></span>
    </div>
    <ul class="contract-validation__list">${rows}</ul>
  </div>`;
  syncContractValidationWrap();
}

// When the subtitle is too long and the validations drop to the next line, the divider goes away.
function syncContractValidationWrap() {
  const host = document.getElementById('contract-validation-host');
  const lead = host && host.previousElementSibling;
  if (!host || !lead) return;
  host.classList.remove('contract-validation-host--wrapped');
  host.classList.toggle('contract-validation-host--wrapped', host.offsetTop > lead.offsetTop + 4);
}
window.addEventListener('resize', syncContractValidationWrap);

// The details popover closes on any click outside it.
document.addEventListener('click', () => {
  if (contractValidation && contractValidation.open) { contractValidation.open = false; renderContractValidation(); }
});

