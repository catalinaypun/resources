/* ── Valu Cal icons (2026-10-21, per Catalina) ─────────────────────────────────────────────────────
   Rule: icons come from the VDS library (assets-shared/ds/icons, 685 SVG). Only when VDS has nothing similar AND the
   icon is needed, a Material Symbols icon is used — kept as a Valu Cal LOCAL icon (like local components).

   VC.ICON_MAP: Material name used in the prototype → { vds: VDS file name (no .svg) or null, uses, where, note }.
   Status: vds set = VDS; vds null = local (Material fallback). Validated with Catalina 2026-10-21 (component library ›
   Foundations › Icon library). Existing markup is mapped at runtime (applyIcons below); new code uses VC.icon(name).
   An icon name that isn't in the map stays Material and is listed in VC.unmappedIcons — add it here.
   usage (checked 2026-10-21 by walking the screens): 'visible' (on screen in the main flows), 'conditional' (only in
   some states / scenarios), 'not-used' (paused Fulfillment, removed features, or Proposal PDF content — not app UI). */
(function () {
  window.VC = window.VC || {};
  window.VC.ICON_MAP = {
    close:                  { usage: 'visible', vds: 'close',                          uses: 33, where: 'Modal / drawer / chip close' },
    check_circle:           { usage: 'visible', vds: 'checkmark-alternate',            uses: 27, where: 'Success notifications, done states' },
    expand_more:            { usage: 'visible', vds: 'down-caret',                     uses: 22, where: 'Accordion chevrons, dropdowns' },
    check:                  { usage: 'visible', vds: 'checkmark',                      uses: 13, where: 'Checks in lists and steps' },
    edit:                   { usage: 'visible', vds: 'edit',                           uses: 12, where: 'Edit actions' },
    info:                   { usage: 'visible', vds: 'info',                           uses: 11, where: 'Info notifications, tooltips' },
    delete:                 { usage: 'visible', vds: 'trash',                          uses: 11, where: 'Delete option / solution' },
    warning:                { usage: 'visible', vds: 'warning',                        uses: 6,  where: 'Warning notifications' },
    drag_indicator:         { usage: 'conditional', usageNote: 'Reordering', vds: null, uses: 6,  where: 'Drag handles', note: 'Material kept (Catalina, 2026-10-21)', alt: ['drag-handler'] },
    calendar_month:         { usage: 'visible', vds: null, uses: 5,  where: 'Date fields', note: 'Material kept — VDS calendars show a "31" or a clock (Catalina, 2026-10-21)', alt: ['service-end-date', 'calendar'] },
    arrow_back:             { usage: 'conditional', usageNote: 'Back links (plan finder, selection)', vds: 'left-arrow',                     uses: 5,  where: 'Back links' },
    sync:                   { usage: 'visible', vds: 'sync',                           uses: 4,  where: 'Sync / refresh states' },
    sell:                   { usage: 'visible', vds: 'tag',                            uses: 4,  where: 'Discounts & Promotions button', alt: ['promo-badge'] },
    search:                 { usage: 'visible', vds: 'search',                         uses: 4,  where: 'Search fields' },
    arrow_forward:          { usage: 'visible', vds: 'right-arrow',                    uses: 4,  where: 'Forward links' },
    add:                    { usage: 'visible', vds: 'plus',                           uses: 4,  where: 'Add actions' },
    remove:                 { usage: 'visible', vds: 'minus',                          uses: 3,  where: 'Steppers (minus)' },
    more_vert:              { usage: 'visible', vds: 'more-vertical',                  uses: 3,  where: 'Kebab menus' },
    draw:                   { usage: 'visible', vds: 'email-signature',                uses: 3,  where: 'Signature fields (contract)', alt: ['compose'] },
    refresh:                { usage: 'visible', vds: 'sync',                           uses: 2,  where: 'Refresh contract preview' },
    lock:                   { usage: 'not-used', usageNote: 'Fulfillment (paused)', vds: 'lock-closed',                    uses: 2,  where: 'Locked options' },
    // 2026-11-06 (icon pack for the devs): icons added after 10-21 that were still Material — mapped to VDS.
    chevron_right:          { usage: 'visible', vds: 'right-caret', uses: 2, where: 'Current setup panel: expand (collapsed)' },
    receipt_long:           { usage: 'visible', vds: 'orders', uses: 2, where: 'Existing Business option: Modifications section' },
    schedule:               { usage: 'conditional', usageNote: 'Migrations', vds: 'clock', uses: 1, where: 'Migrations: To start billing section' },
    business:               { usage: 'conditional', usageNote: 'Account setup', vds: 'enterprise', uses: 2, where: 'Account setup navigation' },
    manage_accounts:        { usage: 'conditional', usageNote: 'Account setup', vds: 'user-settings', uses: 2, where: 'Account setup navigation: Owner' },
    payments:               { usage: 'conditional', usageNote: 'Account setup', vds: 'payment-received', uses: 2, where: 'Account setup navigation: Billing' },
    filter_list:            { usage: 'visible', vds: null, uses: 2,  where: 'Filter buttons', note: 'Material kept (Catalina, 2026-10-21)', alt: ['filter'] },
    download:               { usage: 'visible', vds: 'download',                       uses: 2,  where: 'Downloads' },
    content_copy:           { usage: 'visible', vds: 'duplicate',                      uses: 2,  where: 'Clone option' },
    bookmark:               { usage: 'not-used', usageNote: 'Fulfillment (paused)', vds: 'bookmark',                       uses: 2,  where: 'Recommended / saved' },
    videocam:               { usage: 'conditional', usageNote: 'Send Proposal video toggle', vds: 'video',                          uses: 1,  where: 'Video features' },
    videocam_off:           { usage: 'conditional', usageNote: 'Send Proposal video toggle', vds: 'no-video',                       uses: 1,  where: 'No video' },
    verified_user:          { usage: 'not-used', usageNote: 'Proposal PDF content', vds: 'security-check',                 uses: 1,  where: 'Verification note' },
    upload:                 { usage: 'conditional', usageNote: 'File upload (approval, cancellations)', vds: 'upload',                         uses: 1,  where: 'File upload' },
    trending_up:            { usage: 'conditional', usageNote: 'Upsell plan groups (Bundle mode)', vds: 'growth',                         uses: 1,  where: 'Plan groups (upsell summary)', alt: ['increase'] },
    send:                   { usage: 'visible', vds: 'send-message',                   uses: 1,  where: 'Send Proposal button' },
    science:                { usage: 'not-used', usageNote: 'Removed (Simulate Invoice)', vds: 'energy-science',                 uses: 1,  where: 'Simulation / demo tools', alt: ['research'] },
    restart_alt:            { usage: 'conditional', usageNote: 'Existing Business transaction card', vds: 'history',                        uses: 1,  where: 'Transaction type card (Renewal)', alt: ['sync'] },
    power_off:              { usage: 'not-used', usageNote: 'Fulfillment (paused)', vds: 'turnon-off',                     uses: 1,  where: 'Vehicle attribute: master switch off' },
    notifications:          { usage: 'visible', vds: 'notification',                   uses: 1,  where: 'Notifications' },
    menu:                   { usage: 'visible', vds: 'menu',                           uses: 1,  where: 'App menu' },
    mark_email_read:        { usage: 'visible', vds: 'invitation-accepted',            uses: 1,  where: 'Contract sent, waiting for signature', alt: ['email'] },
    link:                   { usage: 'conditional', usageNote: 'Send Proposal additional links', vds: 'link',                           uses: 1,  where: 'Links' },
    keyboard_arrow_down:    { usage: 'conditional', usageNote: 'Some dropdowns', vds: 'down-caret',                     uses: 1,  where: 'Dropdown chevron' },
    handshake:              { usage: 'conditional', usageNote: 'MSA context bar (pilot)', vds: 'handshake',                      uses: 1,  where: 'Deal result' },
    expand_less:            { usage: 'conditional', usageNote: 'Open accordions', vds: 'up-caret',                       uses: 1,  where: 'Collapse' },
    error:                  { usage: 'visible', vds: 'error',                          uses: 1,  where: 'Error notifications' },
    emergency:              { usage: 'not-used', usageNote: 'Fulfillment (paused)', vds: 'ambulance',                      uses: 1,  where: 'Vehicle attribute: emergency vehicle' },
    domain:                 { usage: 'visible', vds: 'enterprise',                     uses: 1,  where: 'Account context (header)', alt: ['government'] },
    description:            { usage: 'conditional', usageNote: 'Documents', vds: 'single-document',                uses: 1,  where: 'Documents' },
    chevron_left:           { usage: 'visible', vds: 'left-caret',                     uses: 1,  where: 'Back chevron' },
    build:                  { usage: 'not-used', usageNote: 'Fulfillment (paused)', vds: 'tools',                          uses: 1,  where: 'Vehicle attribute: competitor device removal' },
    autorenew:              { usage: 'conditional', usageNote: 'MSA context bar (auto-extend)', vds: 'sync',                           uses: 1,  where: 'Auto-extend chip' },
    apps:                   { usage: 'visible', vds: 'grid-view',                      uses: 1,  where: 'Salesforce app launcher (mock chrome)' },
    account_balance:        { usage: 'conditional', usageNote: 'MSA context bar (Government)', vds: 'government',                     uses: 1,  where: 'Government segment chip' },
    accessible:             { usage: 'not-used', usageNote: 'Fulfillment (paused)', vds: 'international-symbol-of-access', uses: 1,  where: 'Vehicle attribute: wheelchair lift' },
    person:                 { usage: 'visible', usageNote: 'Pricing Desk', vds: 'user',                           uses: 1,  where: 'Pricing Desk user block (header avatar)' },
    // Set from data (icon names in JS objects) — counted at runtime.
    task_alt:               { usage: 'visible', vds: 'checkmark-alternate',            uses: 1,  where: 'Status icons (data)' },
    shield:                 { usage: 'not-used', usageNote: 'Proposal PDF content', vds: 'security-check',                 uses: 1,  where: 'Status icons (data)' },
    pause_circle:           { usage: 'not-used', usageNote: 'Fulfillment (paused)', vds: 'pause',                          uses: 1,  where: 'Status icons (data)' },
    local_shipping:         { usage: 'not-used', usageNote: 'Fulfillment (paused)', vds: 'shipping',                       uses: 1,  where: 'Shipping status (data)' },
    local_gas_station:      { usage: 'not-used', usageNote: 'Proposal PDF content', vds: 'gas',                            uses: 1,  where: 'Vehicle attribute (data)' },
    how_to_reg:             { usage: 'visible', vds: 'user-registration',              uses: 1,  where: 'Status icons (data)' },
    contract:               { usage: 'conditional', usageNote: 'Discounts drawer (contract discount)', vds: 'compliance-document',            uses: 1,  where: 'Contract status (data)' },
    cancel:                 { usage: 'conditional', usageNote: 'Existing Business transactions', vds: 'close-alt',                      uses: 1,  where: 'Cancelled status (data)' },
    block:                  { usage: 'conditional', usageNote: 'Feature Upsell step', vds: 'no',                             uses: 1,  where: 'Blocked status (data)' },
    attach_money:           { usage: 'not-used', usageNote: 'Proposal PDF content', vds: 'coin',                           uses: 1,  where: 'Pricing (data)' },
    arrow_downward:         { usage: 'visible', vds: 'down-arrow',                     uses: 1,  where: 'Dashboard column sort (data)' },
    arrow_upward:           { usage: 'conditional', usageNote: 'Dashboard sort ascending', vds: 'up-arrow',                       uses: 1,  where: 'Dashboard column sort (data)' },
    unfold_more:            { usage: 'visible', vds: 'sort',                           uses: 1,  where: 'Dashboard column sort (data)' },
    package_2:              { usage: 'visible', vds: 'parcel',                         uses: 4,  where: 'Current setup: Active solutions (data)' },
    // No similar VDS icon — kept as Valu Cal local icons (Material).
    radio_button_unchecked: { usage: 'not-used', usageNote: 'Fulfillment (paused)', vds: null, uses: 1, where: 'Fulfillment: "Empty" status (paused flow)', note: 'No empty-circle icon in VDS' },
    pending:                { usage: 'not-used', usageNote: 'Fulfillment (paused)', vds: null, uses: 1, where: 'Fulfillment: "Partial" status (paused flow)', note: 'No partial / pending icon in VDS', alt: ['clock'] },
    waves:                  { usage: 'not-used', usageNote: 'Removed (deployment waves)', vds: null, uses: 1, where: 'Option deployment waves strip', note: 'No waves icon in VDS' },
  };
  // VC.icon(name, { className, label }) — the icon markup for new code. `name` is the Material name used across the
  // prototype; it renders the VDS icon from the map (or stays Material when it's a local icon).
  window.VC.icon = function (name, p) {
    p = p || {};
    var v = window.VC.ICON_MAP[name];
    var cls = 'material-symbols-outlined' + (v && v.vds ? ' vc-icon vc-icon--' + v.vds : '') + (p.className ? ' ' + p.className : '');
    return '<span class="' + cls + '"' + (p.label ? ' role="img" aria-label="' + p.label + '"' : ' aria-hidden="true"') + '>' + name + '</span>';
  };
  // Existing markup (<span class="material-symbols-outlined">edit</span>, also icons set from data or toggled later):
  // each icon whose name maps to VDS gets the VDS SVG (vc-icons.css — CSS mask, follows the text color and size).
  window.VC.unmappedIcons = new Set();
  function applyIcon(el) {
    if (el.hasAttribute('data-material')) return; // shown as Material on purpose (e.g. the mapping table)
    var name = (el.textContent || '').trim();
    var v = window.VC.ICON_MAP[name];
    var cur = el.getAttribute('data-vc-icon');
    if (cur && cur !== (v && v.vds)) { el.classList.remove('vc-icon', 'vc-icon--' + cur); el.removeAttribute('data-vc-icon'); }
    if (v && v.vds) { el.classList.add('vc-icon', 'vc-icon--' + v.vds); el.setAttribute('data-vc-icon', v.vds); }
    else if (name && !v) window.VC.unmappedIcons.add(name);
  }
  window.VC.applyIcons = function (root) {
    root = root || document;
    if (root.nodeType === 1 && root.classList.contains('material-symbols-outlined')) applyIcon(root);
    if (root.querySelectorAll) Array.prototype.forEach.call(root.querySelectorAll('.material-symbols-outlined'), applyIcon);
  };
  function start() {
    window.VC.applyIcons(document);
    if (!window.MutationObserver) return;
    new MutationObserver(function (records) {
      records.forEach(function (r) {
        if (r.type === 'characterData') { var p = r.target.parentElement; if (p && p.classList.contains('material-symbols-outlined')) applyIcon(p); return; }
        if (r.target.nodeType === 1 && r.target.classList.contains('material-symbols-outlined')) applyIcon(r.target);
        Array.prototype.forEach.call(r.addedNodes, function (n) { if (n.nodeType === 1) window.VC.applyIcons(n); });
      });
    }).observe(document.documentElement, { childList: true, subtree: true, characterData: true });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();

  // Every icon in the vendored VDS library (assets-shared/ds/icons) — for the Icons page of the component library.
  window.VC.VDS_ICONS = ["3d-ad", "4k", "accessibility", "accessories", "ad-tech-stack", "adaptive-speaker", "add-folder", "add-to-favorite", "add-user", "added-to-favorite", "advanced-settings", "agent", "agent-chat", "agriculture-leaves", "agriculture-tractor", "agriculture-vineyard", "ai-dashcam", "air-conditioner", "airport", "alarm", "alert-notification", "allow-block-list", "ambulance", "american-sign-language", "analytics", "anchor", "announcement", "app-dialer", "app-level-protection", "ar", "ar-lens", "archive", "artboard", "asset-tracking", "assistive-listening-systems", "at", "attach", "audience-targeted-search", "audio-description", "available-lines", "award", "awareness", "baby-monitor", "badminton", "barcode", "baseball", "basketball", "battery", "battery-charging", "battery-level-full", "battery-level-low", "battery-level-medium", "battery-level-outline", "battery-power-saving", "best-practices", "bid", "bill-down", "bill-up", "billards", "blind", "bluetooth", "bonus-data", "bookmark", "bookmark-filled", "bot", "bowling", "box-open", "boxing", "braille", "brightness", "bring-your-own-device", "bucket-truck", "bucket-truck-boom", "bug", "business-continuity", "business-internet", "buy-plans", "calendar", "calibrate", "call-disconnected", "caller-id", "camera", "camera-effects", "camera-modes", "car-battery", "cards-on-reserve", "carryover-data", "cell-phone", "cell-signal", "cell-signal-alt", "cell-tower", "certificate", "chat", "chat-disabled", "check-in", "checkmark", "checkmark-alt-bold", "checkmark-alternate", "checkmark-bold", "clean-surface", "clock", "close", "close-alt", "close-bold Large", "close-bold Medium", "close-bold Small", "closed-captioning", "closed-captioning-filled", "cloud", "cloud-alternative", "cloud-document", "coax", "coffee", "cognitive-disability", "coin", "comparison", "compass", "compliance-document", "compose", "condition-based-maintenance", "condition-based-wrench", "connect", "connect-parts", "construction-hammer", "construction-truck", "consultative-transfer", "convergence", "conversion", "count-down", "crash", "credit-card", "crop", "cross-device", "cross-device-targeting", "cta", "ctr", "custom-audience", "customer-identifier-biz", "customer-identifier-bottom", "customer-identifier-glasses", "customer-identifier-hat", "customer-identifier-shirt", "customer-identifier-shoe", "customer-sentiment-negative", "customer-sentiment-neutral", "customer-sentiment-positive", "customize", "data", "data-boost", "data-unlimited", "data-unlimited-premium", "deaf", "decrease", "device-activity", "device-protection", "devices-and-add-ons", "dfc-video-side-by-side", "diagnostic", "digital-content", "digital-signage", "digital-signage-car", "dining", "direct-carrier-billing", "directory", "discus", "display", "display-utilities", "distribution", "domain-targeting", "doorbell", "down-arrow", "down-caret", "download", "drag-and-drop", "drag-handler", "driver", "drivers-license", "drone-camera", "drop-shipment", "duplicate", "earbud", "edit", "education", "education-curriculum", "electric-car", "electric-power", "electric-utility", "electric-van", "email", "email-signature", "embedded-sound", "emergency-contact", "emoji", "employee-termination", "energy-science", "energy-utilities", "enterprise", "error", "error-bold", "ethernet", "euro", "expense", "external-link", "face-covering", "facebook", "facial-recognition-id", "fall-detected", "fast", "favorite", "fax", "federal-defense", "feedback", "feedback-filled", "filter", "filter-off", "financial", "find-my-remote", "fine-art", "fingerprint-sensor", "fire", "fit-to-zone", "flag", "fleet", "fleet-tracking", "flexibility", "flexibility-rectangles", "flexible-four-arrows", "flexible-three-arrows", "flip-camera", "flurry", "folder", "folder-locked", "football", "forwarded-call", "fridge", "fullscreen", "fullscreen-minimize", "gaming", "gas", "gateway", "generative-ai", "generative-ai-filled", "geofence", "get-help", "gift", "gifted-data", "golf", "government", "grid-view", "group-family", "growth", "growth-opportunities", "hackers", "handshake", "hard-brake", "hd", "headphones", "healthcare-corporate", "healthcare-general", "help-me-decide", "history", "home", "home-internet", "home-security", "hot-warning", "humidity", "ideas-or-solutions", "identity-graph", "identity-restoration", "impression-video", "in-store-pickup", "inclusivity", "incoming-call", "increase", "industry", "inferred-identity", "info", "info-bold", "instagram", "insurance", "intelligent-tracking", "international", "international-long-distance", "international-symbol-of-access", "internet-devices", "internet-of-things", "inventory", "invitation-accepted", "invitation-expired", "invitation-rejected", "irobot", "ironing-board", "join-call", "k12-education", "kids-stroller", "landscape", "laptop-antivirus", "laptop-controls", "laptop-gps-tracking", "laptop-settings", "laptop-trends", "laptop-wireless", "large-plan", "latch-release", "law", "left-arrow", "left-caret", "left-caret-bold", "levers", "light", "lighthouse", "link", "list", "live-caption", "lmr", "loaner-equipment", "location", "location-alt", "location-only-device", "location-pin", "location-tracking", "lock-closed", "lock-open", "locker", "logout", "loyalty-retention", "manufacturing", "map-view", "masonry-view", "maximize", "medal", "media-entertainment", "medium-business", "medium-plan", "menu", "merge-calls", "microphone", "microphone-alternate", "minus", "missed-call", "mobile-and-home", "mobile-apps", "mobile-command-center", "mobile-hotspot", "mobile-kiosk-info", "mobile-kiosk-wireless", "mobile-plus-tv", "mobile-retail", "mobile-retargeting", "mobile-search", "mobile-workforce-management", "more-horizontal", "more-vertical", "motion-detector", "move-to", "multicast", "multiple-device-protection", "multiple-devices", "multiple-documents", "music", "mute", "my-account", "my-plan-2-to-3-lines", "my-plan-4-plus-lines", "my-plans", "my-plans-details", "nationwide", "native", "native-video", "network", "network-attached-storage", "network-connection", "new", "news", "next", "nfc-tag", "night", "no", "no-backup", "no-fee", "no-location", "no-off", "no-smoking", "no-video", "notification", "notifications-off", "notify-me", "notify-someone", "office-phone-system", "oil-industry", "on-demand", "on-go-car", "on-screen-text", "one-year", "open-captioning", "operational-transformation", "orders", "out-of-stock", "outgoing-call", "pack-backpack", "pack-luggage", "pack-purse", "pagination-left-arrow", "pagination-left-caret", "pagination-right-arrow", "pagination-right-caret", "paper-free-billing", "parcel", "passenger", "passkey", "pattern", "pause", "pause-alt", "pause-alt-filled", "pause-internet", "paused", "payment-installments", "payment-received", "peel-sticker", "person-biking", "person-walking", "pets-collar", "pharmaceutical", "phone", "phone-all-good", "phone-data", "phone-favorite", "phone-medical", "phone-number", "phone-public-safety", "phone-volume", "photo", "pin", "pizza", "place-address", "plan-perks", "plan-speed-home", "plan-speed-plus", "plan-speed-ultimate", "platform", "play", "play-alt-filled", "play-alternate", "play-with", "playlist", "plus", "plus-tier-plan", "police-fleet", "portrait", "pressure", "previous", "print", "pro-on-the-go", "professional-services-case", "professional-services-chart", "promo-badge", "protection-score", "public-safety", "public-transportation", "purchase-data", "push-notification", "push-to-talk", "pushpin", "pushpin-selected", "puzzle", "question", "real-time", "real-time-tracking", "recycle", "remind-me", "reminder", "remove-item", "remove-user", "reoccuring-payment", "replace-a-photo", "reply", "reports-and-alerts", "research", "resend-email", "reservations", "responsible-business", "retail-store", "retail-store-alt", "retargeting", "returns", "rewards", "rewind-and-fast-forward", "right-arrow", "right-arrow-diagonal-bold", "right-caret", "right-caret-bold", "ring", "ringing", "ringtone", "risk-monitor", "risky-connection", "router", "rss", "running", "safe-browsing", "satellite", "satellite-off", "save", "scale", "scale-alt", "schedules", "school-notebook", "screen-orientation-locked", "screen-orientation-unlocked", "screen-share", "search", "second-home", "security-alert", "security-check", "security-keyhole", "security-wireless", "send-message", "server-clock", "server-search", "server-stack", "service-end-date", "services", "set-fallback-image", "set-gallery-image", "settings", "share", "shipping", "shock", "shopping", "shopping-bag", "signal-broadcast", "sim-card", "single-document", "skateboard", "skip-back", "skip-forward", "small-business", "small-plan", "smart-assistant", "smart-boiler", "smart-communities", "smart-family-child-address-book", "smart-lighting", "smart-meter", "smart-scooter", "smart-socket", "smart-switch", "smoke-detector", "snooze", "snowboard", "social-distancing", "social-security", "solar-panel", "sort", "sos", "sound", "speaker-mute", "speaker-phone", "speed", "speed-monitoring", "sports-bike", "sports-skis", "sports-soccer", "sports-tennis", "stadium", "stadium-flag", "stakeholder", "star", "start-trip", "steps", "stethoscope", "stocktogether", "stop", "stop-alt", "support", "support-drawer", "surfboard", "survey", "swipe", "swipe-left", "swipe-right", "switch", "sync", "table-tennis", "tablet", "tablet-data", "tablet-wireless", "tag", "talking", "target-goal", "taxes", "team-leader", "tech-laptop", "technology", "telematics-car", "teletype", "temperature", "template", "text-message", "text-to-speech", "theme", "thermostat-tech", "thumbs-down", "thumbs-down-filled", "thumbs-up", "thumbs-up-filled", "ticket", "tiles", "tilt", "timer", "tire-blowout", "tools", "top-box", "total-mobile-protection", "tow-truck", "trade-in", "trading-deck", "traffic-light", "trailers", "training", "translate", "transportation", "trash", "travel-keys", "travel-pass", "trip-planner", "trumpet", "trusted-browser", "turnon-off", "tv", "tv-content", "ultimate-plan", "umbrella", "undo", "unification", "unified-comms", "unlimited-plan", "unmanaged-devices", "up-arrow", "up-caret", "uplink", "upload", "url-transparency", "user", "user-guides-1", "user-guides-2", "user-registration", "user-settings", "utility-grid-management", "vibration", "video", "video-clips", "video-on-tablet", "video-settings", "virtual-reality", "visibility", "visibility-off", "voice-hd", "voice-mail", "volleyball", "volume", "volunteer", "vpn", "wallet", "warning", "warning-bold", "water-resistant", "water-utility", "wearable", "weather", "webinar", "weights", "whiteboard", "wifi-backup", "wifi-scan", "wifi-wireless", "winch-service", "wireless-vending", "wireless-video-surveillance", "xcorp", "year", "yield", "youtube", "zoom-in", "zoom-out"];
})();
