/* Pricing Desk — Create a promotion (brief 03, MVP). Opens from "Create new" on Promotions & Discounts
   (?page=promotions&view=create) as a full page: breadcrumb, title, one card per section, sticky footer
   (Cancel · Save as draft · Submit for approval). One form for both types: the type selector switches the sections.
   Sections (requirements by section › Section 2 › "Creating a promotion"):
   Order Discount — 1. Basics, 2. Applies to, 3. Dates, 4. Who sees it, 5. Exclusions, 6. Limits,
   7. Can be combined with, 8. What happens to it later (read-only).
   Account Discount — 1. Basics, 2. Discount, 3. Dates, 4. Who sees it, 5. Approval limits, 6. Fixed rules (read-only).
   Who sees it / Exclusions / deal conditions use one condition builder: "+ Add condition" → a field (grouped Account,
   Deal / order, User; config/catalog.config.js › conditionGroups) and one or more values. Values inside a condition:
   any of them; conditions: all of them (AND). PENDING (business): AND / OR between conditions.
   Validation on Save / Submit (first prototype pattern): buttons always enabled; on click the missing fields get an
   inline error and a summary banner lists them; errors clear as the fields are fixed. Save as draft needs Type, Name
   and a unique Code; Submit needs every required field. New promotions are kept for the session
   (PD.addSessionPromotion, js/pd-promotions.js). Sample products and list prices: config/catalog.config.js. */
(function (global) {
  var PD = global.PD = global.PD || {};
  var TYPES = [['order', 'Order Discount'], ['account', 'Account Discount']];
  var ACCOUNT_NOTE = 'Applies to every item\'s subscription charge, at Initial Sale, Renewal, Rewrap and Reactivation.';
  var FIELD_LABELS = {
    name: 'Name', code: 'Code', percent: 'Discount', start: 'Offer start', end: 'Offer end', rows: 'Applies to',
    conditions: 'Who sees it', cond: 'Who sees it', excl: 'Exclusions', limit: 'Limits', maxApproval: 'Maximum without approval',
    priority: 'Priority', deal: 'Deal conditions',
  };
  var LISTS = { cond: 'conditions', excl: 'exclusions', deal: 'dealConds' };
  var LIMITS = [['perOrder', 'Units per order'], ['perAccount', 'Units per account'], ['total', 'Units in total'], ['budget', 'Budget']];
  var FIXED_EXCLUSIONS = 'Public schedules and seasonal lines are always excluded.';

  // Ranges set by Pricing & Finance (config/guardrails.config.js): shown next to the fields, enforced on save.
  function guard() { return PD.GUARDRAILS || { setBy: 'Pricing & Finance', order: {}, account: {} }; }
  function pctText(n) { return String(n) + '%'; }
  function amtText(n) { return '$' + Number(n).toFixed(2); }
  function rangeText(r, f) { return r ? f(r.min) + '–' + f(r.max) : ''; }
  function outOf(v, r) { return r && (v < r.min || v > r.max); }
  PD.guardrailNote = function (kind) {
    var g = guard();
    if (kind === 'order') return g.setBy + ' allows ' + rangeText(g.order.percent, pctText) + ' or ' + rangeText(g.order.amount, amtText) + ' per unit / month.';
    if (kind === 'account') return g.setBy + ' allows ' + rangeText(g.account.percent, pctText) + '.';
    if (kind === 'maxApproval') return g.setBy + ' allows ' + rangeText(g.account.maxWithoutApproval, pctText) + '.';
    if (kind === 'months') return 'Durations allowed by ' + g.setBy + '. From the order date; never past the MSA term end.';
    return '';
  };

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function el(id) { return document.getElementById(id); }
  function money(n) { return n == null || isNaN(n) ? '--' : '$' + Number(n).toFixed(2); }
  function catalogItem(id) { return ((PD.CATALOG && PD.CATALOG.items) || []).filter(function (i) { return i.id === id; })[0] || null; }

  function emptyRow() { return { target: '', saleMode: 'OPEX', installMethod: 'Any', type: 'percentage', value: '' }; }
  function newForm() {
    return {
      type: 'order', name: '', code: '', codeEdited: false, description: '',
      rows: [emptyRow()], percent: '', start: '', end: '', months: '12',
      audience: 'all', conditions: [], exclusions: [], combinable: [],
      limits: { perOrder: { min: '', max: '' }, perAccount: { min: '', max: '' }, total: { min: '', max: '' }, budget: { min: '', max: '' } },
      maxApproval: '', priority: '', dealConds: [],
      attempted: null, // 'draft' | 'submit' once a save was tried: errors then update as fields change
    };
  }
  PD.createForm = PD.createForm || newForm();

  // Code suggested from the name until it's edited: upper case, words joined by "-", at most 20 characters.
  PD.suggestPromotionCode = function (name) {
    return String(name || '').toUpperCase().replace(/[^A-Z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 20).replace(/-+$/, '');
  };

  // Monthly benefit per unit of a form row: % of the item's sample list price for the row's sale mode, or the amount.
  PD.rowBenefit = function (row) {
    var v = parseFloat(row.value);
    if (isNaN(v)) return null;
    if (row.type === 'amount') return v;
    var item = catalogItem(row.target);
    var price = item && item.listPrice ? item.listPrice[row.saleMode] : null;
    return price == null ? null : Math.round(price * v) / 100;
  };

  // ── Validation. Returns { <field key>: message }; row fields are "row-<i>-target" / "row-<i>-value".
  PD.validatePromotionForm = function (f, mode) {
    // mode 'live' (nothing saved yet): only format errors; 'draft': + Name and Code; 'submit': + every required field.
    var e = {};
    var required = mode === 'draft' || mode === 'submit';
    if (required && !f.name.trim()) e.name = 'Enter a name.';
    var code = f.code.trim().toUpperCase();
    if (!code) { if (required) e.code = 'Enter a code.'; }
    else if (PD.promotions().some(function (p) { return String(p.code).toUpperCase() === code; })) e.code = 'This code is already used by another promotion.';
    if (f.type === 'order') {
      f.rows.forEach(function (r, i) {
        var v = parseFloat(r.value);
        if (r.value !== '' && (isNaN(v) || v <= 0 || (r.type === 'percentage' && v > 100))) {
          e['row-' + i + '-value'] = r.type === 'percentage' ? 'Enter a % between 0 and 100.' : 'Enter an amount above 0.';
        } else if (r.value !== '') {
          var gr = r.type === 'percentage' ? guard().order.percent : guard().order.amount;
          if (outOf(v, gr)) e['row-' + i + '-value'] = guard().setBy + ' allows ' + rangeText(gr, r.type === 'percentage' ? pctText : amtText) + '.';
        }
        if (mode !== 'submit') return;
        if (!r.target) e['row-' + i + '-target'] = 'Pick a product or category.';
        if (r.value === '') e['row-' + i + '-value'] = 'Enter a value.';
      });
    } else {
      var pct = parseFloat(f.percent);
      if (f.percent !== '' && (isNaN(pct) || pct <= 0 || pct > 100)) e.percent = 'Enter a % between 0 and 100.';
      else if (f.percent !== '' && outOf(pct, guard().account.percent)) e.percent = PD.guardrailNote('account');
      else if (mode === 'submit' && f.percent === '') e.percent = 'Enter the discount.';
    }
    if (mode === 'submit' && !f.start) e.start = 'Pick the offer start.';
    if (f.start && f.end && f.end < f.start) e.end = 'The offer end can\'t be before the start.';
    // 4. Who sees it, 5. Exclusions, deal conditions: on Submit each condition needs a field and a value.
    if (mode === 'submit' && f.audience === 'match' && !f.conditions.length) e.conditions = 'Add at least one condition, or pick "All accounts".';
    var kinds = ['cond'].concat(f.type === 'order' ? ['excl'] : ['deal']);
    kinds.forEach(function (kind) {
      if (kind === 'cond' && f.audience !== 'match') return;
      f[LISTS[kind]].forEach(function (c, i) {
        if (kind === 'deal' && c.change !== '') {
          var ch = parseFloat(c.change);
          if (isNaN(ch) || ch === 0 || ch < -100 || ch > 100) e['deal-' + i + '-change'] = 'Enter a change between -100 and 100, not 0.';
        }
        if (mode !== 'submit') return;
        if (!c.field) e[kind + '-' + i + '-field'] = 'Pick a field.';
        if (!c.values.length) e[kind + '-' + i + '-values'] = 'Pick at least one value.';
        if (kind === 'deal' && c.change === '') e['deal-' + i + '-change'] = 'Enter the change.';
      });
    });
    if (f.type === 'order') {
      // 6. Limits (optional): 0 or more; the minimum not above the maximum.
      LIMITS.forEach(function (l) {
        var lim = f.limits[l[0]];
        var min = parseFloat(lim.min), max = parseFloat(lim.max);
        if (lim.min !== '' && (isNaN(min) || min < 0)) e['limit-' + l[0] + '-min'] = 'Enter 0 or more.';
        if (lim.max !== '' && (isNaN(max) || max < 0)) e['limit-' + l[0] + '-max'] = 'Enter 0 or more.';
        if (!e['limit-' + l[0] + '-min'] && !e['limit-' + l[0] + '-max'] && lim.min !== '' && lim.max !== '' && min > max) {
          e['limit-' + l[0] + '-min'] = 'The minimum can\'t be above the maximum.';
        }
      });
    } else {
      // 5. Approval limits: maximum without approval 0–100 (optional); a unique priority (1 or more) on Submit.
      var mx = parseFloat(f.maxApproval);
      if (f.maxApproval !== '' && (isNaN(mx) || mx < 0 || mx > 100)) e.maxApproval = 'Enter a % between 0 and 100.';
      else if (f.maxApproval !== '' && outOf(mx, guard().account.maxWithoutApproval)) e.maxApproval = PD.guardrailNote('maxApproval');
      var pr = Number(f.priority);
      if (f.priority !== '') {
        if (!(pr >= 1) || Math.floor(pr) !== pr) e.priority = 'Enter a whole number, 1 or more.';
        else if (PD.promotions().some(function (p) { return p.level === 'account' && ['expired', 'retired'].indexOf(p.status) === -1 && p.approval && p.approval.priority === pr; })) {
          e.priority = 'Another program already has priority ' + pr + '.';
        }
      } else if (mode === 'submit') e.priority = 'Enter the priority.';
    }
    return e;
  };

  function summaryLabels(errors) {
    var labels = [];
    Object.keys(errors).forEach(function (k) {
      var label = /^row-/.test(k) ? FIELD_LABELS.rows : (FIELD_LABELS[k] || FIELD_LABELS[k.split('-')[0]] || k);
      if (labels.indexOf(label) === -1) labels.push(label);
    });
    return labels;
  }

  // Updates every error slot and the summary banner in place (no re-render: the focus stays where it is).
  function applyErrors(errors) {
    Array.prototype.forEach.call(document.querySelectorAll('#pd-create [data-error-for]'), function (slot) {
      var key = slot.getAttribute('data-error-for');
      var msg = errors[key];
      slot.textContent = msg || '';
      slot.classList.toggle('hidden', !msg);
      var field = el('pd-create-' + key);
      if (field) {
        field.classList.toggle(field.tagName === 'SELECT' ? 'select--error' : 'input--error', !!msg);
        if (msg) field.setAttribute('aria-invalid', 'true'); else field.removeAttribute('aria-invalid');
        if (field.__vcDropdown && field.__vcDropdown.refresh) field.__vcDropdown.refresh(); // the shared dropdown copies the classes
      }
    });
    var summary = el('pd-create-summary');
    if (!summary) return;
    // The summary shows only once a save was tried; before that, only format errors show inline as you type.
    var labels = PD.createForm.attempted ? summaryLabels(errors) : [];
    summary.classList.toggle('hidden', !labels.length);
    var text = el('pd-create-summary-text');
    if (text) text.textContent = labels.join(', ');
  }

  function revalidate() {
    var f = PD.createForm;
    applyErrors(PD.validatePromotionForm(f, f.attempted || 'live'));
  }

  // ── Markup helpers (shared VDS pieces: input, select, textarea-field, input-affix, segmented control, card).
  function label(forId, text, optional) {
    return '<label class="vc-field-label" for="' + forId + '">' + esc(text) + (optional ? ' (optional)' : '') + '</label>';
  }
  function errorSlot(key) {
    return '<div class="input__error-text hidden" id="pd-create-' + key + '-error" data-error-for="' + key + '"></div>';
  }
  function field(key, labelText, controlHtml, opts) {
    opts = opts || {};
    return '<div class="vds-field vc-form-page__field' + (opts.full ? ' vc-form-page__field--full' : '') + '">' +
      label('pd-create-' + key, labelText, opts.optional) + controlHtml + (opts.note ? '<p class="vc-form-page__note text-body-small">' + esc(opts.note) + '</p>' : '') + errorSlot(key) +
    '</div>';
  }
  function textInput(key, value, attrs) {
    return '<input type="text" class="input" id="pd-create-' + key + '" value="' + esc(value) + '" aria-describedby="pd-create-' + key + '-error"' + (attrs || '') + '>';
  }
  function options(list, current) {
    return list.map(function (o) {
      var v = Array.isArray(o) ? o[0] : o;
      var t = Array.isArray(o) ? o[1] : o;
      return '<option value="' + esc(v) + '"' + (String(v) === String(current) ? ' selected' : '') + '>' + esc(t) + '</option>';
    }).join('');
  }
  function dateInput(key, value) {
    return '<span class="vc-date-field"><input type="date" class="input" id="pd-create-' + key + '" value="' + esc(value) + '"' +
      ' onchange="PD.setCreateField(\'' + key + '\', this.value)" oninput="PD.setCreateField(\'' + key + '\', this.value)"' +
      ' aria-describedby="pd-create-' + key + '-error">' +
      '<span class="material-symbols-outlined vc-date-field__icon" aria-hidden="true">calendar_month</span></span>';
  }
  function card(id, title, bodyHtml) {
    return '<section class="card card--outlined vc-form-page__card" id="pd-create-section-' + id + '" aria-labelledby="pd-create-section-' + id + '-title">' +
      '<h2 class="vc-form-page__card-title text-body-large-bold" id="pd-create-section-' + id + '-title">' + esc(title) + '</h2>' + bodyHtml +
    '</section>';
  }

  function basicsCard(f) {
    var persona = PD.currentPersona ? PD.currentPersona() : null;
    var typeControl = '<div class="segmented-control" role="radiogroup" aria-label="Type" id="pd-create-type">' + TYPES.map(function (t) {
      var on = f.type === t[0];
      return '<button type="button" role="radio" aria-checked="' + on + '" class="segmented-control__option' + (on ? ' segmented-control__option--active' : '') + '"' +
        ' id="pd-create-type-' + t[0] + '" onclick="PD.setCreateType(\'' + t[0] + '\')">' + esc(t[1]) + '</button>';
    }).join('') + '</div>';
    return card('basics', '1. Basics', '<div class="vc-form-page__fields">' +
      '<div class="vds-field vc-form-page__field vc-form-page__field--full"><span class="vc-field-label" id="pd-create-type-label">Type</span>' + typeControl + '</div>' +
      field('name', 'Name', textInput('name', f.name, ' maxlength="60" oninput="PD.setCreateName(this.value)"')) +
      field('code', 'Code', textInput('code', f.code, ' maxlength="20" oninput="PD.setCreateCode(this.value)"'), { note: 'Suggested from the name; unique.' }) +
      '<div class="vds-field vc-form-page__field vc-form-page__field--full"><div class="textarea-field textarea-field--2x">' +
        '<label class="textarea-field__label" for="pd-create-description">Description (optional)</label>' +
        '<div class="textarea-field__container"><textarea class="textarea-field__input" id="pd-create-description" rows="2" maxlength="300"' +
          ' oninput="PD.setCreateField(\'description\', this.value)">' + esc(f.description) + '</textarea></div>' +
      '</div></div>' +
    '</div>');
  }

  // Products and categories in two titled groups (Catalina, 2026-10-26); each option shows only the name, and so does
  // the closed dropdown (the group says what it is; the detail shows the kind in its own column).
  var TARGET_GROUPS = [['Product category', 'Product categories'], ['Product', 'Products']];
  function targetGroups(items, current) {
    return TARGET_GROUPS.map(function (g) {
      var inGroup = items.filter(function (it) { return it.kind === g[0]; });
      return inGroup.length ? '<optgroup label="' + esc(g[1]) + '">' + options(inGroup.map(function (it) { return [it.id, it.name]; }), current) + '</optgroup>' : '';
    }).join('');
  }

  function rowHtml(r, i, count) {
    var items = (PD.CATALOG && PD.CATALOG.items) || [];
    var cat = PD.CATALOG || {};
    var pre = 'pd-create-row-' + i + '-';
    var on = function (k) { return ' onchange="PD.setCreateRow(' + i + ', \'' + k + '\', this.value)"'; };
    var target = '<select class="select select--small" id="' + pre + 'target" aria-label="Product or category, row ' + (i + 1) + '"' + on('target') + ' aria-describedby="' + pre + 'target-error">' +
      '<option value="">Select…</option>' + targetGroups(items, r.target) + '</select>' +
      errorSlot('row-' + i + '-target');
    var sale = '<select class="select select--small" id="' + pre + 'sale" aria-label="Sale mode, row ' + (i + 1) + '"' + on('saleMode') + '>' + options(cat.saleModes || [], r.saleMode) + '</select>';
    var install = '<select class="select select--small" id="' + pre + 'install" aria-label="Installation method, row ' + (i + 1) + '"' + on('installMethod') + '>' + options(cat.installMethods || [], r.installMethod) + '</select>';
    var type = '<select class="select select--small" id="' + pre + 'type" aria-label="Type, row ' + (i + 1) + '"' + on('type') + '>' + options([['percentage', '%'], ['amount', '$']], r.type) + '</select>';
    var value = '<span class="input-affix input-affix--compact' + (r.type === 'amount' ? '' : ' input-affix--suffix') + '">' +
      (r.type === 'amount' ? '<span class="input-affix__text" aria-hidden="true">$</span>' : '') +
      '<input type="number" class="input input--small input-affix__field" id="' + pre + 'value" min="0" step="0.01" value="' + esc(r.value) + '" placeholder="0"' +
        ' aria-label="Value, row ' + (i + 1) + '" aria-describedby="' + pre + 'value-error" oninput="PD.setCreateRow(' + i + ', \'value\', this.value)">' +
      (r.type === 'amount' ? '' : '<span class="input-affix__text" aria-hidden="true">%</span>') +
    '</span>' + errorSlot('row-' + i + '-value');
    var remove = count > 1
      ? '<button type="button" class="btn-icon btn-icon--ghost-vds btn-icon--vds-small" id="' + pre + 'remove" aria-label="Remove row ' + (i + 1) + '" title="Remove row" onclick="PD.removeCreateRow(' + i + ')"><span class="material-symbols-outlined" aria-hidden="true">delete</span></button>'
      : '';
    return '<tr>' + [target, sale, install, type, value].map(function (c) { return '<td class="table-body-cell">' + c + '</td>'; }).join('') +
      '<td class="table-body-cell vc-master-detail__num" id="' + pre + 'benefit">' + money(PD.rowBenefit(r)) + '</td>' +
      '<td class="table-body-cell">' + remove + '</td></tr>';
  }

  function appliesToCard(f) {
    var table = VC.dataTable({
      className: 'vc-master-detail__table vc-form-page__table', ariaLabel: 'Applies to', id: 'pd-create-rows',
      rowsHtml: f.rows.map(function (r, i) { return rowHtml(r, i, f.rows.length); }),
      columns: [{ label: 'Product or category' }, { label: 'Sale mode' }, { label: 'Installation' }, { label: 'Type' }, { label: 'Value' },
        { label: 'Monthly benefit per unit', className: 'vc-master-detail__num' }, { label: '' }],
    });
    return card('applies', '2. Applies to',
      '<p class="vc-form-page__note text-body-small">One row per product or product category. The monthly benefit per unit uses the sample list price.</p>' +
      '<p class="vc-form-page__note text-body-small" id="pd-create-guard-order">' + esc(PD.guardrailNote('order')) + '</p>' +
      '<div class="vc-master-detail__table-wrap">' + table + '</div>' +
      // Add buttons: Valu Cal's dashed pill ("+ Add Solution", shared .btn-dashed-add--pill; Catalina, 2026-10-26).
      '<button type="button" class="btn-dashed-add btn-dashed-add--pill" id="pd-create-add-row" onclick="PD.addCreateRow()">+ Add row</button>');
  }

  function discountCard(f) {
    var control = '<span class="input-affix input-affix--compact input-affix--suffix">' +
      '<input type="number" class="input input--small input-affix__field" id="pd-create-percent" min="0" max="100" step="0.1" value="' + esc(f.percent) + '" placeholder="0"' +
        ' aria-describedby="pd-create-percent-error" oninput="PD.setCreateField(\'percent\', this.value)">' +
      '<span class="input-affix__text" aria-hidden="true">%</span></span>';
    return card('discount', '2. Discount', '<div class="vc-form-page__fields">' +
      field('percent', 'Discount on the MSA term', control, { note: ACCOUNT_NOTE + ' ' + PD.guardrailNote('account') }) + '</div>');
  }

  function datesCard(f) {
    var months = f.type === 'order'
      ? field('months', 'Benefit duration', '<select class="select" id="pd-create-months" onchange="PD.setCreateField(\'months\', this.value)">' +
          options((guard().order.benefitMonths || (PD.CATALOG && PD.CATALOG.benefitMonths) || []).map(function (m) { return [String(m), m + ' months']; }), f.months) + '</select>',
          { note: PD.guardrailNote('months') })
      : '';
    return card('dates', '3. Dates', '<div class="vc-form-page__fields">' +
      field('start', 'Offer start', dateInput('start', f.start)) +
      field('end', 'Offer end', dateInput('end', f.end), { optional: true, note: 'Empty = No end date.' }) +
      months + '</div>');
  }

  // ── Condition builder (who sees it, exclusions, deal conditions).
  function conditionGroups() { return (PD.CATALOG && PD.CATALOG.conditionGroups) || []; }
  function findConditionField(id) {
    var found = null;
    conditionGroups().forEach(function (g) { g.fields.forEach(function (fd) { if (fd.id === id) found = { field: fd, group: g }; }); });
    return found;
  }
  function fieldOptions(current, onlyDealAdjust) {
    return conditionGroups().map(function (g) {
      var fields = g.fields.filter(function (fd) { return !onlyDealAdjust || fd.dealAdjust; });
      return fields.length ? '<optgroup label="' + esc(g.label) + '">' + options(fields.map(function (fd) { return [fd.id, fd.label]; }), current) + '</optgroup>' : '';
    }).join('');
  }
  function conditionRow(kind, c, i) {
    var pre = 'pd-create-' + kind + '-' + i + '-';
    var found = findConditionField(c.field);
    var values = found ? found.field.values : [];
    var nth = ', condition ' + (i + 1);
    var fieldSel = '<select class="select" id="' + pre + 'field" aria-label="Field' + nth + '" aria-describedby="' + pre + 'field-error"' +
      ' onchange="PD.setCreateCondition(\'' + kind + '\', ' + i + ', \'field\', this.value)">' +
      '<option value="">Select a field…</option>' + fieldOptions(c.field, kind === 'deal') + '</select>' + errorSlot(kind + '-' + i + '-field');
    var valuesSel = '<select class="select" multiple data-placeholder="' + (found ? 'Select values…' : 'Pick a field first') + '" id="' + pre + 'values" aria-label="Values' + nth + '" aria-describedby="' + pre + 'values-error"' +
      (found ? '' : ' disabled') + ' onchange="PD.setCreateCondition(\'' + kind + '\', ' + i + ', \'values\', Array.prototype.map.call(this.selectedOptions, function (o) { return o.value; }))">' +
      values.map(function (v) { return '<option value="' + esc(v) + '"' + (c.values.indexOf(v) !== -1 ? ' selected' : '') + '>' + esc(v) + '</option>'; }).join('') +
      '</select>' + errorSlot(kind + '-' + i + '-values');
    var change = kind === 'deal'
      ? '<div><span class="input-affix input-affix--suffix"><input type="number" class="input input--small input-affix__field" id="' + pre + 'change" step="0.5" min="-100" max="100" placeholder="+/-0"' +
          ' value="' + esc(c.change) + '" aria-label="Change to the maximum' + nth + '" aria-describedby="' + pre + 'change-error"' +
          ' oninput="PD.setCreateCondition(\'deal\', ' + i + ', \'change\', this.value)"><span class="input-affix__text" aria-hidden="true">%</span></span>' + errorSlot('deal-' + i + '-change') + '</div>'
      : '';
    return '<div class="vc-form-page__condition' + (kind === 'deal' ? ' vc-form-page__condition--deal' : '') + '" id="' + pre + 'row">' +
      '<span class="vc-form-page__condition-join text-body-small">' + (i ? 'and' : (kind === 'deal' ? 'When' : 'Where')) + '</span>' +
      '<div>' + fieldSel + '</div><div>' + valuesSel + '</div>' + change +
      '<button type="button" class="btn-icon btn-icon--ghost-vds btn-icon--vds-small" id="' + pre + 'remove" aria-label="Remove condition ' + (i + 1) + '" title="Remove"' +
        ' onclick="PD.removeCreateCondition(\'' + kind + '\', ' + i + ')"><span class="material-symbols-outlined" aria-hidden="true">delete</span></button>' +
    '</div>';
  }
  function conditionList(kind, list, addLabel) {
    return '<div class="vc-form-page__conditions" id="pd-create-' + kind + '-list">' + list.map(function (c, i) { return conditionRow(kind, c, i); }).join('') + '</div>' +
      '<button type="button" class="btn-dashed-add btn-dashed-add--pill" id="pd-create-' + kind + '-add" onclick="PD.addCreateCondition(\'' + kind + '\')">' + esc(addLabel) + '</button>';
  }

  function whoCard(f) {
    var radio = function (v, text) {
      return '<label class="vc-check-row"><input type="radio" class="radio__input" name="pd-create-audience" id="pd-create-audience-' + v + '" value="' + v + '"' +
        (f.audience === v ? ' checked' : '') + ' onchange="PD.setCreateAudience(\'' + v + '\')"><span class="vc-check-row__text">' + esc(text) + '</span></label>';
    };
    return card('who', '4. Who sees it',
      '<div class="vc-form-page__radios" role="radiogroup" aria-label="Who sees it">' + radio('all', 'All accounts') + radio('match', 'Only accounts that match these conditions') + '</div>' +
      (f.audience === 'match'
        ? '<p class="vc-form-page__note text-body-small">A condition matches any of its values; all the conditions must match.</p>' + conditionList('cond', f.conditions, '+ Add condition')
        : '') + errorSlot('conditions'));
  }

  function exclusionsCard(f) {
    return card('exclusions', '5. Exclusions',
      '<p class="vc-form-page__locked text-body-medium" id="pd-create-fixed-exclusions"><span class="material-symbols-outlined" aria-hidden="true">lock</span>' + esc(FIXED_EXCLUSIONS) + '</p>' +
      '<p class="vc-form-page__note text-body-small">Optional: exclude more with conditions on the account, the deal or the user.</p>' +
      conditionList('excl', f.exclusions, '+ Add exclusion'));
  }

  function limitInput(key, bound, value) {
    var id = 'pd-create-limit-' + key + '-' + bound;
    var input = '<input type="number" class="input input--small' + (key === 'budget' ? ' input-affix__field' : '') + '" id="' + id + '" min="0" step="1" value="' + esc(value) + '" placeholder="--"' +
      ' aria-label="' + (bound === 'min' ? 'Minimum' : 'Maximum') + ', ' + esc((LIMITS.filter(function (l) { return l[0] === key; })[0] || [])[1]) + '" aria-describedby="' + id + '-error"' +
      ' oninput="PD.setCreateLimit(\'' + key + '\', \'' + bound + '\', this.value)">';
    return (key === 'budget' ? '<span class="input-affix"><span class="input-affix__text" aria-hidden="true">$</span>' + input + '</span>' : input) + errorSlot('limit-' + key + '-' + bound);
  }
  function limitsCard(f) {
    var table = VC.dataTable({
      className: 'vc-master-detail__table vc-form-page__table vc-form-page__table--limits', ariaLabel: 'Limits', id: 'pd-create-limits',
      columns: [{ label: 'Limit' }, { label: 'Minimum' }, { label: 'Maximum' }],
      rowsHtml: LIMITS.map(function (l) {
        return '<tr><td class="table-body-cell">' + esc(l[1]) + '</td><td class="table-body-cell">' + limitInput(l[0], 'min', f.limits[l[0]].min) + '</td>' +
          '<td class="table-body-cell">' + limitInput(l[0], 'max', f.limits[l[0]].max) + '</td></tr>';
      }),
    });
    return card('limits', '6. Limits', '<p class="vc-form-page__note text-body-small">Optional. When a limit is reached the promotion is no longer offered.</p>' +
      '<div class="vc-master-detail__table-wrap">' + table + '</div>');
  }

  function combinedCard(f) {
    var others = PD.promotions().filter(function (p) { return p.level === 'order' && ['expired', 'retired'].indexOf(p.status) === -1; });
    var sel = '<select class="select" multiple data-placeholder="Select promotions…" id="pd-create-combinable" aria-label="Can be combined with"' +
      ' onchange="PD.setCreateCombinable(Array.prototype.map.call(this.selectedOptions, function (o) { return o.value; }))">' +
      others.map(function (p) { return '<option value="' + esc(p.id) + '"' + (f.combinable.indexOf(p.id) !== -1 ? ' selected' : '') + '>' + esc(p.name) + '</option>'; }).join('') + '</select>';
    return card('combined', '7. Can be combined with', '<div class="vc-form-page__fields">' +
      field('combinable', 'Promotions it can go together with in the same order', sel, { optional: true }) + '</div>');
  }

  function bandsLine() {
    return (PD.STANDARD_BANDS || []).map(function (b) { return (b.upTo == null ? 'Above' : 'Up to ' + b.upTo + '%') + ': ' + b.role; }).join(' · ');
  }
  function approvalCard(f) {
    var maxCtl = '<span class="input-affix input-affix--compact input-affix--suffix">' +
      '<input type="number" class="input input--small input-affix__field" id="pd-create-maxApproval" min="0" max="100" step="0.1" value="' + esc(f.maxApproval) + '" placeholder="0"' +
        ' aria-describedby="pd-create-maxApproval-error" oninput="PD.setCreateField(\'maxApproval\', this.value)">' +
      '<span class="input-affix__text" aria-hidden="true">%</span></span>';
    var prCtl = '<input type="number" class="input input--small vc-form-page__input--narrow" id="pd-create-priority" min="1" step="1" value="' + esc(f.priority) + '"' +
      ' aria-describedby="pd-create-priority-error" oninput="PD.setCreateField(\'priority\', this.value)">';
    return card('approval', '5. Approval limits', '<div class="vc-form-page__fields">' +
      field('maxApproval', 'Maximum a rep can give without approval', maxCtl, { optional: true, note: PD.guardrailNote('maxApproval') }) +
      field('priority', 'Priority', prCtl, { note: 'Unique. Orders the rep\'s list when several programs apply; the first one is preselected.' }) +
      '<div class="vds-field vc-form-page__field vc-form-page__field--full"><span class="vc-field-label">Approval bands</span>' +
        '<p class="vc-form-page__value text-body-medium" id="pd-create-bands">' + esc(bandsLine() || '--') + '</p>' +
        '<p class="vc-form-page__note text-body-small">Set by Pricing &amp; Finance.</p></div>' +
      '</div>' +
      '<div class="vds-field"><span class="vc-field-label">Deal conditions (optional)</span>' +
        '<p class="vc-form-page__note text-body-small">Raise or lower the maximum for some deals, e.g. a 60-month term: +1%.</p></div>' +
      conditionList('deal', f.dealConds, '+ Add deal condition'));
  }

  function laterCard(f) {
    var rules = PD.PROMOTION_RULES || { orderLater: [], accountFixed: [] };
    var order = f.type === 'order';
    return card('later', order ? '8. What happens to it later' : '6. Fixed rules',
      '<p class="vc-form-page__note text-body-small">' + (order ? 'Always true for an Order Discount promotion.' : 'Always true for an Account Discount program.') + '</p>' +
      '<ul class="vc-master-detail__bullets text-body-medium" id="pd-create-later">' + (order ? rules.orderLater : rules.accountFixed).map(function (t) { return '<li>' + esc(t) + '</li>'; }).join('') + '</ul>');
  }

  // Leaving with something typed asks in a VDS modal (2026-10-26, Catalina: the question in the footer went unnoticed
  // when leaving from the breadcrumb at the top).
  function discardModalHtml() {
    return '<div class="modal-overlay is-open" id="pd-create-discard-overlay" onclick="PD.keepEditingPromotion()">' +
      '<div class="modal modal--sm" role="alertdialog" aria-modal="true" aria-labelledby="pd-create-discard-title" aria-describedby="pd-create-discard-message" onclick="event.stopPropagation()">' +
        '<div class="modal__content">' +
          '<h2 class="modal__title" id="pd-create-discard-title">Discard this promotion?</h2>' +
          '<p class="modal__body" id="pd-create-discard-message">What you typed will be lost.</p>' +
        '</div>' +
        '<div class="modal__actions">' +
          '<button type="button" class="btn btn--secondary btn--large" id="pd-create-keep" onclick="PD.keepEditingPromotion()">Keep editing</button>' +
          '<button type="button" class="btn btn--primary btn--large" id="pd-create-discard" onclick="PD.closeCreatePromotion(true)">Discard</button>' +
        '</div>' +
      '</div>' +
    '</div>';
  }

  function footerHtml(f) {
    return '<div class="vc-form-page__footer" id="pd-create-footer">' +
      '<button type="button" class="text-link vc-form-page__footer-cancel" id="pd-create-cancel" onclick="PD.cancelCreatePromotion()">Cancel</button>' +
      '<button type="button" class="btn btn--secondary btn--small" id="pd-create-save" onclick="PD.saveNewPromotion(\'draft\')">Save as draft</button>' +
      '<button type="button" class="btn btn--primary btn--small" id="pd-create-submit" onclick="PD.saveNewPromotion(\'submit\')">Submit for approval</button>' +
    '</div>';
  }

  function sectionsHtml(f) {
    if (f.type === 'account' && f.priority === '') f.priority = String(suggestedPriority());
    return basicsCard(f) + (f.type === 'order' ? appliesToCard(f) : discountCard(f)) + datesCard(f) + whoCard(f) +
      (f.type === 'order' ? exclusionsCard(f) + limitsCard(f) + combinedCard(f) : approvalCard(f)) + laterCard(f);
  }

  PD.renderCreatePromotion = function (host) {
    var f = PD.createForm;
    var owner = PD.currentPersona ? PD.currentPersona() : null;
    host.innerHTML = '<div class="vc-form-page" id="pd-create">' +
      '<div class="vc-form-page__header">' +
        // Breadcrumb like Valu Cal's "Proposals / Create new" (VDS breadcrumb-nav; Catalina, 2026-10-26).
        '<nav aria-label="Breadcrumb"><ol class="breadcrumb-nav">' +
          '<li class="breadcrumb-nav__item"><a class="breadcrumb-nav__link" href="?persona=' + esc(PD.state.personaId) + '&amp;page=promotions" id="pd-create-back"' +
            ' onclick="event.preventDefault(); PD.cancelCreatePromotion()">Promotions &amp; Discounts</a><span class="breadcrumb-nav__sep" aria-hidden="true">/</span></li>' +
          '<li class="breadcrumb-nav__item breadcrumb-nav__item--current" aria-current="page">Create new</li>' +
        '</ol></nav>' +
        '<h1 class="vc-page-header__title" id="pd-page-title">Create promotion</h1>' +
        // Owner under the title, full name (Catalina, 2026-10-26: not a field in Basics).
        '<p class="vc-form-page__meta text-body-medium" id="pd-create-owner">Owner: ' + esc(owner ? owner.name : '--') + '</p>' +
      '</div>' +
      '<div class="notification notification--error hidden" role="alert" id="pd-create-summary" tabindex="-1">' +
        '<span class="material-symbols-outlined notification__icon" aria-hidden="true">error</span>' +
        '<div class="notification__body"><div class="notification__title">Complete the required fields</div>' +
        '<div class="notification__message" id="pd-create-summary-text"></div></div>' +
      '</div>' +
      '<div class="vc-form-page__sections" id="pd-create-sections">' + sectionsHtml(f) + '</div>' +
      footerHtml(f) +
    '</div>';
    document.title = 'Create promotion — Pricing Desk';
    if (VC.enhanceDropdowns) VC.enhanceDropdowns(host, 'select.select');
    if (VC.initDatePickers) VC.initDatePickers(host);
    revalidate();
  };

  function rerenderSections() {
    var sections = el('pd-create-sections');
    if (!sections) return;
    sections.innerHTML = sectionsHtml(PD.createForm);
    if (VC.enhanceDropdowns) VC.enhanceDropdowns(sections, 'select.select');
    if (VC.initDatePickers) VC.initDatePickers(sections);
    revalidate();
  }

  // ── Field updates (the form object is the source; the DOM is only re-rendered when the structure changes).
  PD.setCreateType = function (type) {
    var f = PD.createForm;
    if (f.type === type) return;
    f.type = type;
    rerenderSections();
    var btn = el('pd-create-type-' + type);
    if (btn) btn.focus();
  };
  PD.setCreateField = function (key, value) {
    PD.createForm[key] = value == null ? '' : String(value);
    revalidate();
  };
  PD.setCreateName = function (value) {
    var f = PD.createForm;
    f.name = value || '';
    if (!f.codeEdited) {
      f.code = PD.suggestPromotionCode(f.name);
      var code = el('pd-create-code');
      if (code) code.value = f.code;
    }
    revalidate();
  };
  PD.setCreateCode = function (value) {
    var f = PD.createForm;
    f.code = String(value || '').toUpperCase();
    f.codeEdited = f.code !== '';
    var code = el('pd-create-code');
    if (code && code.value !== f.code) code.value = f.code;
    revalidate();
  };
  PD.setCreateRow = function (i, key, value) {
    var r = PD.createForm.rows[i];
    if (!r) return;
    r[key] = value == null ? '' : String(value);
    if (key === 'type') { rerenderSections(); var t = el('pd-create-row-' + i + '-type'); if (t) t.focus(); return; }
    var cell = el('pd-create-row-' + i + '-benefit');
    if (cell) cell.textContent = money(PD.rowBenefit(r));
    revalidate();
  };
  PD.addCreateRow = function () {
    var f = PD.createForm;
    f.rows.push(emptyRow());
    rerenderSections();
    var t = el('pd-create-row-' + (f.rows.length - 1) + '-target');
    if (t) t.focus();
  };
  PD.removeCreateRow = function (i) {
    var f = PD.createForm;
    if (f.rows.length < 2) return;
    f.rows.splice(i, 1);
    rerenderSections();
    var add = el('pd-create-add-row');
    if (add) add.focus();
  };

  // The next free priority among Account Discount programs.
  function suggestedPriority() {
    var used = PD.promotions().filter(function (p) { return p.level === 'account' && p.approval && p.approval.priority != null; })
      .map(function (p) { return p.approval.priority; });
    return used.length ? Math.max.apply(null, used) + 1 : 1;
  }

  function focusControl(id) {
    var c = el(id);
    if (!c) return;
    if (c.__vcDropdown && c.__vcDropdown.trigger) c.__vcDropdown.trigger.focus(); else c.focus();
  }

  PD.setCreateAudience = function (value) {
    var f = PD.createForm;
    f.audience = value === 'match' ? 'match' : 'all';
    if (f.audience === 'match' && !f.conditions.length) f.conditions.push({ field: '', values: [], change: '' });
    rerenderSections();
    focusControl('pd-create-audience-' + f.audience);
  };
  PD.addCreateCondition = function (kind) {
    var list = PD.createForm[LISTS[kind]];
    list.push({ field: '', values: [], change: '' });
    rerenderSections();
    focusControl('pd-create-' + kind + '-' + (list.length - 1) + '-field');
  };
  PD.removeCreateCondition = function (kind, i) {
    PD.createForm[LISTS[kind]].splice(i, 1);
    rerenderSections();
    focusControl('pd-create-' + kind + '-add');
  };
  PD.setCreateCondition = function (kind, i, key, value) {
    var c = PD.createForm[LISTS[kind]][i];
    if (!c) return;
    if (key === 'field') {
      c.field = value || '';
      c.values = [];
      rerenderSections(); // the values change with the field
      focusControl('pd-create-' + kind + '-' + i + '-values');
      return;
    }
    c[key] = key === 'values' ? (value || []).slice() : (value == null ? '' : String(value));
    revalidate();
  };
  PD.setCreateLimit = function (key, bound, value) {
    PD.createForm.limits[key][bound] = value == null ? '' : String(value);
    revalidate();
  };
  PD.setCreateCombinable = function (ids) {
    PD.createForm.combinable = (ids || []).slice();
  };

  function isDirty(f) {
    return !!(f.name || f.code || f.description || f.percent || f.start || f.end || f.maxApproval ||
      f.audience === 'match' || f.exclusions.length || f.dealConds.length || f.combinable.length ||
      LIMITS.some(function (l) { return f.limits[l[0]].min !== '' || f.limits[l[0]].max !== ''; }) ||
      f.rows.some(function (r) { return r.target || r.value !== ''; }));
  }

  // ── Leaving the form.
  var discardReturnFocus = null;
  PD.cancelCreatePromotion = function () {
    var f = PD.createForm;
    if (!isDirty(f)) { PD.closeCreatePromotion(true); return; }
    discardReturnFocus = document.activeElement;
    var old = el('pd-create-discard-overlay');
    if (old) old.remove();
    document.body.insertAdjacentHTML('beforeend', discardModalHtml());
    var keep = el('pd-create-keep');
    if (keep) keep.focus();
  };
  PD.keepEditingPromotion = function () {
    var overlay = el('pd-create-discard-overlay');
    if (overlay) overlay.remove();
    if (discardReturnFocus && discardReturnFocus.focus && document.contains(discardReturnFocus)) discardReturnFocus.focus();
    discardReturnFocus = null;
  };
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && el('pd-create-discard-overlay')) PD.keepEditingPromotion();
  });
  PD.closeCreatePromotion = function (discard) {
    var overlay = el('pd-create-discard-overlay');
    if (overlay) overlay.remove();
    if (discard) PD.createForm = newForm();
    PD.navigate({ page: 'promotions' });
    var create = el('pd-promo-create');
    if (create) create.focus();
  };

  function newId(code) {
    var base = 'new-' + code.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    var id = base;
    var n = 2;
    while (PD.findPromotion(id)) id = base + '-' + n++;
    return id;
  }

  function todayIso() {
    var d = new Date();
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  }

  // "Segment: SMB, Mid-Market" — the same text as the sample data; incomplete conditions are left out (drafts).
  function conditionText(c) {
    var found = findConditionField(c.field);
    return found && c.values.length ? found.field.label + ': ' + c.values.join(', ') : null;
  }
  function conditionsByGroup(list) {
    var out = { account: [], deal: [], user: [] };
    list.forEach(function (c) {
      var found = findConditionField(c.field);
      var text = conditionText(c);
      if (found && text) out[found.group.id].push(text);
    });
    return out;
  }
  function num(v) { return v === '' || v == null || isNaN(parseFloat(v)) ? null : parseFloat(v); }

  // The form as a promotion with the same shape as the sample data (config/promotions.config.js), so the detail
  // renders it like any other. Empty optional values show "--" in the detail.
  PD.promotionFromForm = function (f, status) {
    var persona = PD.currentPersona ? PD.currentPersona() : null;
    var code = f.code.trim().toUpperCase();
    var p = {
      id: newId(code), level: f.type, name: f.name.trim(), code: code, status: status, version: 1,
      owner: persona ? persona.name : '', offerStart: f.start || '', offerEnd: f.end || null, createdInSession: true,
      conditions: f.audience === 'match' ? conditionsByGroup(f.conditions) : { account: [], deal: [], user: [] },
    };
    if (f.type === 'order') {
      p.definition = {
        description: f.description.trim(),
        appliesTo: f.rows.filter(function (r) { return r.target || r.value !== ''; }).map(function (r) {
          var item = catalogItem(r.target);
          return {
            target: item ? item.name : '', kind: item ? item.kind : '', saleMode: r.saleMode, installMethod: r.installMethod,
            type: r.type, value: r.value === '' ? null : parseFloat(r.value), listPrice: item && item.listPrice ? item.listPrice[r.saleMode] : null,
          };
        }),
      };
      p.benefitMonths = Number(f.months) || null;
      p.exclusions = f.exclusions.map(conditionText).filter(Boolean);
      p.limits = { min: {}, max: {} };
      LIMITS.forEach(function (l) { p.limits.min[l[0]] = num(f.limits[l[0]].min); p.limits.max[l[0]] = num(f.limits[l[0]].max); });
      p.combinableWith = f.combinable.slice();
    } else {
      p.definition = { percent: f.percent === '' ? null : parseFloat(f.percent), transactions: ['Initial Sale', 'Renewal', 'Rewrap', 'Reactivation'], description: f.description.trim() };
      p.approval = {
        maxWithoutApproval: num(f.maxApproval), bands: (PD.STANDARD_BANDS || []).slice(), priority: f.priority === '' ? null : Number(f.priority),
        // "Term 60 months: maximum +1%"
        dealConditions: f.dealConds.map(function (c) {
          var found = findConditionField(c.field);
          var ch = num(c.change);
          return found && c.values.length && ch ? found.field.label + ' ' + c.values.join(' or ') + ': maximum ' + (ch > 0 ? '+' : '') + ch + '%' : null;
        }).filter(Boolean),
      };
    }
    if (status === 'pending') { p.submittedOn = todayIso(); p.waitingFor = 'Pricing & Finance'; }
    return p;
  };

  // mode 'draft' (Type, Name, unique Code) or 'submit' (every required field). Errors → inline + summary, focus on
  // the summary. Saved → back to the list with the new promotion selected and a toast.
  PD.saveNewPromotion = function (mode) {
    var f = PD.createForm;
    f.attempted = mode;
    var errors = PD.validatePromotionForm(f, mode);
    applyErrors(errors);
    if (Object.keys(errors).length) {
      var summary = el('pd-create-summary');
      if (summary) summary.focus();
      return null;
    }
    var p = PD.promotionFromForm(f, mode === 'submit' ? 'pending' : 'draft');
    PD.addSessionPromotion(p);
    PD.createForm = newForm();
    PD.promoState.search = '';
    PD.promoState.filters = { types: [], statuses: [] };
    PD.promoState.selectedId = p.id;
    PD.navigate({ page: 'promotions' });
    var item = el('pd-promo-item-' + p.id);
    if (item) { item.focus(); if (item.scrollIntoView) item.scrollIntoView({ block: 'nearest' }); }
    PD.showToast(mode === 'submit' ? p.name + ' submitted for approval' : p.name + ' saved as draft');
    return p;
  };

  // ── Toast (VDS notification, success, floating): one at a time, closes after 4.5 s or with ×.
  var toastTimer = null;
  PD.showToast = function (title) {
    var host = el('pd-toast');
    if (!host) {
      host = document.createElement('div');
      host.id = 'pd-toast';
      host.className = 'vc-toast-host';
      document.body.appendChild(host);
    }
    host.innerHTML = '<div class="notification notification--success notification--toast" role="status">' +
      '<span class="material-symbols-outlined notification__icon" aria-hidden="true">check_circle</span>' +
      '<div class="notification__body"><div class="notification__title" id="pd-toast-title">' + esc(title) + '</div></div>' +
      '<button type="button" class="notification__dismiss" aria-label="Close" onclick="PD.hideToast()"><span class="material-symbols-outlined" aria-hidden="true">close</span></button>' +
    '</div>';
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(PD.hideToast, 4500);
  };
  PD.hideToast = function () {
    var host = el('pd-toast');
    if (host) host.innerHTML = '';
  };
})(window);
