/* Pricing Desk — Approvals (brief 04): the approver's queue as a table and each request on its own page.
   For the approver personas (personas.config.js › approvalLevel: 1 Associate Director, 2 Director, 3 Pricing &
   Finance). 2026-10-26 (Catalina): a table, not the promotions split view — approvers compare requests (amount, level,
   time waiting) before picking one; the first Pricing Desk prototype did the same.
   Queue (?page=approvals): page title, tabs "Assigned to me" (pending requests waiting at the persona's level) and
   "Completed by me" (approved at their level or decided by them), search by record or submitter, and a table in
   the look of Valu Cal's Proposal Dashboard (the request name is the link that opens it; rows are not clickable).
   Request page (?page=approvals&view=request&item=<id>): breadcrumb "Approvals / <record>", title, status, meta and
   read-only sections — 1. Why it needs approval, 2. What is requested, 3. From the requester, 4. Approval path,
   5. Activity.
   Requests: config/approvals.config.js (Valu Cal) + one per promotion in Pending approval (Pricing Desk; every new
   promotion goes to Pricing & Finance, Level 3 — requirements by section › Section 3 › Notes).
   PENDING (brief 04, batch 2): Approve / Reject (comment required), outcomes, notifications. */
(function (global) {
  var PD = global.PD = global.PD || {};
  var TABS = [['assigned', 'Assigned to me'], ['completed', 'Completed by me']];
  var TYPES = { promotion: 'New promotion', pricing: 'Pricing' };
  var REQUESTER_ROLE = { promotion: 'Promotion manager', pricing: 'Sales rep' };
  var STATUS = {
    pending: { label: 'Pending approval', badge: 'badge--yellow' },
    approved: { label: 'Approved', badge: 'badge--green' },
    rejected: { label: 'Rejected', badge: 'badge--red' },
  };

  PD.approvalState = PD.approvalState || { tab: 'assigned', search: '' };

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function el(id) { return document.getElementById(id); }
  function orDash(v) { return v == null || v === '' ? '--' : v; }
  function fmt(iso) { return PD.formatDate ? PD.formatDate(iso) : iso; }
  function levelInfo(n) { return (PD.APPROVAL_LEVELS || []).filter(function (l) { return l.level === n; })[0] || null; }
  function todayIso() {
    var d = new Date();
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  }
  function daysBetween(a, b) {
    var pa = Date.parse(a + 'T00:00:00'), pb = Date.parse(b + 'T00:00:00');
    return isNaN(pa) || isNaN(pb) ? null : Math.round((pb - pa) / 86400000);
  }

  // A new promotion waiting for approval, as a request (Pricing Desk → Pricing & Finance).
  function promotionRequest(p) {
    return {
      id: 'promo-' + p.id, source: 'Pricing Desk', type: 'promotion', record: p.name, promotionId: p.id,
      submitter: p.owner, submittedOn: p.submittedOn || '', startLevel: 3, neededLevel: 3, approvals: [], status: 'pending',
      triggers: ['Every new promotion needs approval by Pricing & Finance.'],
      reason: '', justification: '', attachment: '',
    };
  }

  PD.approvalRequests = function () {
    var promos = (PD.promotions ? PD.promotions() : []).filter(function (p) { return p.status === 'pending'; }).map(promotionRequest);
    return (PD.APPROVAL_REQUESTS || []).concat(promos);
  };
  PD.findApprovalRequest = function (id) { return PD.approvalRequests().filter(function (r) { return r.id === id; })[0] || null; };

  // The level a pending request is waiting at: the one after the last approved, from its first level.
  PD.requestCurrentLevel = function (r) {
    if (r.status !== 'pending') return null;
    var last = (r.approvals || []).reduce(function (m, a) { return Math.max(m, a.level); }, 0);
    return Math.max(r.startLevel || 1, last + 1);
  };
  function waitingSince(r) {
    var dates = (r.approvals || []).map(function (a) { return a.on; }).concat([r.submittedOn]).filter(Boolean).sort();
    return dates[dates.length - 1] || '';
  }
  PD.waitingLabel = function (r) {
    var d = daysBetween(waitingSince(r), todayIso());
    if (d == null) return '';
    return d <= 0 ? 'waiting since today' : 'waiting ' + d + (d === 1 ? ' day' : ' days');
  };
  // What this persona did on the request (for Completed by me): their approval or their final decision.
  function myAction(r, persona) {
    if (r.decidedBy === persona.name) return { status: r.status, on: r.decidedOn };
    var a = (r.approvals || []).filter(function (x) { return x.by === persona.name; })[0];
    return a ? { status: 'approved', on: a.on } : null;
  }

  PD.approvalQueue = function (tab) {
    var persona = PD.currentPersona();
    var level = persona && persona.approvalLevel;
    if (!level) return [];
    var q = (PD.approvalState.search || '').trim().toLowerCase();
    var list = PD.approvalRequests().filter(function (r) {
      if (q && (r.record + ' ' + r.submitter).toLowerCase().indexOf(q) === -1) return false;
      return tab === 'completed' ? !!myAction(r, persona) : PD.requestCurrentLevel(r) === level;
    });
    return list.sort(function (a, b) {
      if (tab === 'completed') { var x = myAction(a, persona).on, y = myAction(b, persona).on; return x < y ? 1 : x > y ? -1 : 0; }
      var wa = waitingSince(a), wb = waitingSince(b);
      return wa < wb ? -1 : wa > wb ? 1 : 0;
    });
  };

  function statusBadge(status) {
    var s = STATUS[status];
    return s ? '<span class="badge ' + s.badge + '">' + esc(s.label) + '</span>' : '';
  }

  // The amount shown in the queue: the proposal's MRR after discounts (Valu Cal requests); "--" for a promotion.
  function amountOf(r) {
    var row = (r.snapshot || []).filter(function (x) { return x[0] === 'MRR after discounts'; })[0];
    return row ? row[1] : '--';
  }

  function rowHtml(r, tab, persona) {
    var link = '<a href="?persona=' + esc(PD.state.personaId) + '&amp;page=approvals&amp;view=request&amp;item=' + esc(r.id) + '" class="record-link" id="pd-req-link-' + esc(r.id) + '"' +
      ' onclick="event.preventDefault(); PD.openApprovalRequest(\'' + esc(r.id) + '\')">' + esc(r.record) + '</a>';
    var cells = [
      link + '<div class="text-body-small ql-cell-ref">' + esc(TYPES[r.type] + ' · ' + r.source) + '</div>',
      '<span class="vc-cell-clamp">' + esc(r.triggers[0]) + '</span>',
      esc(r.submitter) + '<div class="text-body-small ql-cell-ref">' + esc(fmt(r.submittedOn)) + '</div>',
    ];
    var num = '<td class="table-body-cell ql-col-num">' + esc(amountOf(r)) + '</td>';
    var tail = tab === 'completed'
      ? '<td class="table-body-cell">' + statusBadge(myAction(r, persona).status) + '</td><td class="table-body-cell">' + esc(fmt(myAction(r, persona).on)) + '</td>'
      : '<td class="table-body-cell"><span class="badge badge--gray-low">Level ' + PD.requestCurrentLevel(r) + '</span></td><td class="table-body-cell">' + esc(PD.waitingLabel(r).replace(/^waiting /, '')) + '</td>';
    return '<tr class="ql-table-row" id="pd-req-row-' + esc(r.id) + '">' + cells.map(function (c) { return '<td class="table-body-cell">' + c + '</td>'; }).join('') + num + tail + '</tr>';
  }

  function tableHtml(list, tab, persona) {
    return '<div class="ql-table-wrap">' + VC.dataTable({
      className: 'ql-table pd-req-table', id: 'pd-req-tbody', ariaLabel: tab === 'completed' ? 'Requests completed by me' : 'Requests assigned to me',
      columns: [{ label: 'Request' }, { label: 'Why it needs approval' }, { label: 'Submitted by' }, { label: 'MRR', className: 'ql-col-num' }]
        .concat(tab === 'completed' ? [{ label: 'Decision' }, { label: 'Decided on' }] : [{ label: 'Level' }, { label: 'Waiting' }]),
      rowsHtml: list.map(function (r) { return rowHtml(r, tab, persona); }),
    }) + '</div>';
  }

  // ── Detail.
  function section(id, title, bodyHtml) {
    return '<section class="vc-master-detail__section" id="pd-req-section-' + id + '" aria-labelledby="pd-req-section-' + id + '-title">' +
      '<h3 class="vc-master-detail__section-title text-body-large-bold" id="pd-req-section-' + id + '-title">' + esc(title) + '</h3>' + bodyHtml +
    '</section>';
  }
  function fields(pairs) {
    return '<dl class="vc-master-detail__fields">' + pairs.map(function (f) {
      return '<dt class="text-body-small-bold">' + esc(f[0]) + '</dt><dd class="text-body-medium">' + esc(orDash(f[1])) + '</dd>';
    }).join('') + '</dl>';
  }

  function requestedHtml(r) {
    if (r.type === 'promotion') {
      var p = PD.findPromotion ? PD.findPromotion(r.promotionId) : null;
      if (!p) return '<p class="text-body-medium">--</p>';
      var level = p.level === 'account' ? 'Account Discount' : 'Order Discount';
      return fields([['Promotion', p.name], ['Type', level], ['Code', p.code], ['Owner', p.owner]]) +
        '<div class="vc-master-detail__subsections" id="pd-req-promotion">' + PD.promotionSectionsHtml(p, { nested: true }) + '</div>';
    }
    return fields(r.snapshot || []);
  }

  // The chain from the requester to the highest level needed: approved, rejected, waiting (current), next, not needed.
  function pathHtml(r) {
    var current = PD.requestCurrentLevel(r);
    var steps = ['<li class="vc-master-detail__step is-done"><span class="material-symbols-outlined" aria-hidden="true">check_circle</span>' +
      '<span><span class="text-body-medium-bold">' + esc(REQUESTER_ROLE[r.type]) + '</span><span class="text-body-small vc-master-detail__step-note">Submitted by ' + esc(r.submitter) + ' on ' + esc(fmt(r.submittedOn)) + '</span></span></li>'];
    (PD.APPROVAL_LEVELS || []).forEach(function (l) {
      if (l.level < (r.startLevel || 1)) return;
      var a = (r.approvals || []).filter(function (x) { return x.level === l.level; })[0];
      var state, icon, note;
      if (a) { state = 'is-done'; icon = 'check_circle'; note = 'Approved by ' + a.by + ' on ' + fmt(a.on); }
      else if (r.status === 'rejected' && l.level === Math.max.apply(null, (r.approvals || []).map(function (x) { return x.level; }).concat([(r.startLevel || 1) - 1])) + 1) {
        state = 'is-rejected'; icon = 'cancel'; note = 'Rejected by ' + r.decidedBy + ' on ' + fmt(r.decidedOn);
      } else if (l.level === current) { state = 'is-current'; icon = 'schedule'; note = 'Waiting for ' + l.name; }
      else if (l.level > r.neededLevel || r.status !== 'pending') { state = 'is-skipped'; icon = 'remove'; note = 'Not needed'; }
      else { state = 'is-next'; icon = 'radio_button_unchecked'; note = 'Next: ' + l.name; }
      steps.push('<li class="vc-master-detail__step ' + state + '" id="pd-req-step-' + l.level + '"><span class="material-symbols-outlined" aria-hidden="true">' + icon + '</span>' +
        '<span><span class="text-body-medium-bold">Level ' + l.level + ' · ' + esc(l.role) + '</span><span class="text-body-small vc-master-detail__step-note">' + esc(note) + '</span></span></li>');
    });
    return '<ol class="vc-master-detail__path" id="pd-req-path">' + steps.join('') + '</ol>';
  }

  function activityHtml(r) {
    var rows = [[r.submittedOn, 'Submitted by ' + r.submitter + ' (' + REQUESTER_ROLE[r.type] + ')']];
    (r.approvals || []).forEach(function (a) { var l = levelInfo(a.level); rows.push([a.on, 'Approved at Level ' + a.level + (l ? ' (' + l.role + ')' : '') + ' by ' + a.by]); });
    if (r.status === 'approved') rows.push([r.decidedOn, 'Approved — final decision by ' + r.decidedBy]);
    if (r.status === 'rejected') rows.push([r.decidedOn, 'Rejected by ' + r.decidedBy + (r.comment ? ': ' + r.comment : '')]);
    return '<ul class="vc-master-detail__activity text-body-medium" id="pd-req-activity">' + rows.map(function (x) {
      return '<li><span class="text-body-small vc-master-detail__step-note">' + esc(fmt(x[0])) + '</span><span>' + esc(x[1]) + '</span></li>';
    }).join('') + '</ul>';
  }

  function sectionsHtml(r) {
    return '<div class="vc-master-detail__sections" id="pd-req-sections">' +
        section('why', '1. Why it needs approval', '<ul class="vc-master-detail__bullets text-body-medium">' + r.triggers.map(function (t) { return '<li>' + esc(t) + '</li>'; }).join('') + '</ul>') +
        section('requested', '2. What is requested', requestedHtml(r)) +
        section('requester', '3. From the requester', fields([['Reason', r.reason], ['Justification', r.justification], ['Attachment', r.attachment]])) +
        section('path', '4. Approval path', pathHtml(r)) +
        section('activity', '5. Activity', activityHtml(r)) +
      '</div>';
  }

  // ── Page.
  function tabLabel(t) { return t[1] + ' (' + PD.approvalQueue(t[0]).length + ')'; }
  function tabsHtml(state) {
    return '<div class="segmented-control vc-master-detail__tabs" role="tablist" aria-label="Queue" id="pd-req-tabs">' + TABS.map(function (t) {
      var on = state.tab === t[0];
      return '<button type="button" role="tab" aria-selected="' + on + '" class="segmented-control__option' + (on ? ' segmented-control__option--active' : '') + '"' +
        ' id="pd-req-tab-' + t[0] + '" onclick="PD.setApprovalTab(\'' + t[0] + '\')">' + esc(tabLabel(t)) + '</button>';
    }).join('') + '</div>';
  }

  PD.updateApprovals = function () {
    var state = PD.approvalState;
    var persona = PD.currentPersona();
    var list = PD.approvalQueue(state.tab);
    TABS.forEach(function (t) { var b = el('pd-req-tab-' + t[0]); if (b) b.textContent = tabLabel(t); });
    var host = el('pd-req-items');
    if (!host) return;
    host.innerHTML = list.length
      ? tableHtml(list, state.tab, persona)
      : '<div class="vc-master-detail__empty text-body-medium" id="pd-req-empty">' +
          (state.search ? 'No requests match your search' : state.tab === 'completed' ? 'You haven\'t decided any request yet' : 'Nothing waiting for you') + '</div>';
  };

  PD.setApprovalTab = function (tab) {
    var state = PD.approvalState;
    if (state.tab === tab) return;
    state.tab = tab;
    TABS.forEach(function (t) {
      var b = el('pd-req-tab-' + t[0]);
      if (!b) return;
      var on = t[0] === tab;
      b.classList.toggle('segmented-control__option--active', on);
      b.setAttribute('aria-selected', String(on));
    });
    PD.updateApprovals();
  };

  PD.setApprovalSearch = function (value) { PD.approvalState.search = value || ''; PD.updateApprovals(); };

  PD.openApprovalRequest = function (id) {
    PD.navigate({ page: 'approvals', view: 'request', item: id });
    var title = el('pd-req-title');
    if (title) { title.setAttribute('tabindex', '-1'); title.focus(); }
  };
  PD.closeApprovalRequest = function () {
    var id = PD.state.item;
    PD.navigate({ page: 'approvals' });
    var link = el('pd-req-link-' + id);
    if (link) link.focus();
  };

  // The queue: page title, tabs + search, table.
  function queuePageHtml(page, state) {
    return '<div class="pd-approvals" id="pd-approvals">' +
      '<div class="vc-page-header"><div class="vc-page-header__main">' +
        '<h1 class="vc-page-header__title" id="pd-page-title">' + esc(page.title) + '</h1>' +
      '</div></div>' +
      '<div class="vc-queue-toolbar">' + tabsHtml(state) +
        VC.searchField({ id: 'pd-req-search', placeholder: 'Search by record or submitter', value: state.search, onInput: 'PD.setApprovalSearch(this.value)' }) +
      '</div>' +
      '<div id="pd-req-items"></div>' +
    '</div>';
  }

  // A request's page: breadcrumb, title + status, meta, the sections in one card.
  function requestPageHtml(r) {
    if (!r) {
      return '<div class="vc-form-page" id="pd-req-page"><div class="vc-form-page__header">' + crumb('Request not found') +
        '<h1 class="vc-page-header__title" id="pd-page-title">Request not found</h1></div></div>';
    }
    return '<div class="vc-form-page" id="pd-req-page">' +
      '<div class="vc-form-page__header">' + crumb(r.record) +
        '<div class="vc-form-page__title-row">' +
          '<h1 class="vc-page-header__title" id="pd-req-title">' + esc(r.record) + '</h1>' + statusBadge(r.status) +
        '</div>' +
        '<p class="vc-form-page__meta text-body-medium" id="pd-req-meta">' + esc(TYPES[r.type] + ' · from ' + r.source + ' · submitted by ' + r.submitter + ' on ' + fmt(r.submittedOn)) + '</p>' +
      '</div>' +
      '<section class="card card--outlined vc-form-page__card" id="pd-req-detail" aria-labelledby="pd-req-title">' + sectionsHtml(r) + '</section>' +
    '</div>';
  }
  function crumb(current) {
    return '<nav aria-label="Breadcrumb"><ol class="breadcrumb-nav">' +
      '<li class="breadcrumb-nav__item"><a class="breadcrumb-nav__link" href="?persona=' + esc(PD.state.personaId) + '&amp;page=approvals" id="pd-req-back"' +
        ' onclick="event.preventDefault(); PD.closeApprovalRequest()">Approvals</a><span class="breadcrumb-nav__sep" aria-hidden="true">/</span></li>' +
      '<li class="breadcrumb-nav__item breadcrumb-nav__item--current" aria-current="page">' + esc(current) + '</li>' +
    '</ol></nav>';
  }

  PD.renderApprovalsPage = function (host, page) {
    page = page || { title: 'Approvals' };
    if (PD.state.view === 'request') {
      var r = PD.findApprovalRequest(PD.state.item);
      host.innerHTML = requestPageHtml(r);
      document.title = (r ? r.record : 'Request') + ' — Pricing Desk';
      return;
    }
    host.innerHTML = queuePageHtml(page, PD.approvalState);
    PD.updateApprovals();
  };

  PD.PAGE_RENDERERS = PD.PAGE_RENDERERS || {};
  PD.PAGE_RENDERERS.approvals = PD.renderApprovalsPage;
})(window);
