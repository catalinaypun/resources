/* Pricing Desk — app state, menu per role and pages (brief 01, batch 2).
   State = current persona + current page, both in the URL (?persona=<id>&page=<page id>). A page the persona can't
   see (not in its menu) falls back to the persona's home. The hamburger opens the shared VC.navigationDrawer with only
   the current persona's pages (config/personas.config.js › menu), the page on screen marked active; picking one opens
   it and closes the menu. Each page is only its shared page header for now (config/pages.config.js). */
(function (global) {
  var PD = global.PD = global.PD || {};
  var MENU_HOST_ID = 'pd-menu-host';
  var PAGE_HOST_ID = 'pd-page-host';
  var DRAWER_IDS = { drawerId: 'pd-menu', overlayId: 'pd-menu-overlay' };

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  PD.findPage = function (id) {
    return (PD.PAGES || []).filter(function (p) { return p.id === id; })[0] || null;
  };

  PD.pagesFor = function (persona) {
    return (persona ? persona.menu : []).map(PD.findPage).filter(Boolean);
  };

  // The page if the persona can see it, otherwise the persona's home.
  PD.resolvePageId = function (persona, pageId) {
    return persona && persona.menu.indexOf(pageId) !== -1 && PD.findPage(pageId) ? pageId : persona && persona.home;
  };

  PD.state.pageId = PD.resolvePageId(PD.currentPersona(), new URLSearchParams(global.location ? global.location.search : '').get('page'));

  // A view inside a page (brief 03: view=create on Promotions & Discounts opens the create form). Only known views
  // of the page on screen are kept; switching page or persona drops it.
  // view=request&item=<id> on Approvals opens a request's detail page (brief 04).
  var VIEWS = { promotions: ['create'], approvals: ['request'] };
  function resolveView(pageId, view) { return view && (VIEWS[pageId] || []).indexOf(view) !== -1 ? view : null; }
  var startParams = new URLSearchParams(global.location ? global.location.search : '');
  PD.state.view = resolveView(PD.state.pageId, startParams.get('view'));
  PD.state.item = PD.state.view ? startParams.get('item') : null;

  PD.currentPage = function () { return PD.findPage(PD.state.pageId); };

  function pageHref(personaId, pageId) {
    return '?persona=' + encodeURIComponent(personaId) + '&page=' + encodeURIComponent(pageId);
  }

  function writeUrl() {
    try {
      var url = new URL(global.location.href);
      url.searchParams.set('persona', PD.state.personaId);
      url.searchParams.set('page', PD.state.pageId);
      if (PD.state.view) url.searchParams.set('view', PD.state.view); else url.searchParams.delete('view');
      if (PD.state.item) url.searchParams.set('item', PD.state.item); else url.searchParams.delete('item');
      global.history.replaceState(null, '', url.toString());
    } catch (e) { /* some file:// contexts refuse URL changes — the app still switches */ }
  }

  // PD.navigate({ persona, page, view }): switch persona and / or page (with the fallback to home) and the view inside
  // the page (none unless given), update the URL, render.
  PD.navigate = function (to) {
    to = to || {};
    if (to.persona && PD.findPersona(to.persona)) PD.state.personaId = to.persona;
    PD.state.pageId = PD.resolvePageId(PD.currentPersona(), to.page || PD.state.pageId);
    PD.state.view = resolveView(PD.state.pageId, to.view);
    PD.state.item = PD.state.view && to.item ? String(to.item) : null;
    writeUrl();
    PD.render();
  };

  // B-F2: a link whose persona / page falls back (unknown persona, a page the persona can't see) shows what's on
  // screen in the URL from the start. A URL without persona and page stays as it is.
  PD.normalizeUrl = function () {
    var params = new URLSearchParams(global.location ? global.location.search : '');
    if (!params.has('persona') && !params.has('page')) return;
    if (params.get('persona') !== PD.state.personaId || params.get('page') !== PD.state.pageId || (params.get('view') || null) !== PD.state.view || (params.get('item') || null) !== PD.state.item) writeUrl();
  };
  PD.normalizeUrl();

  PD.menuItems = function () {
    var persona = PD.currentPersona();
    return PD.pagesFor(persona).map(function (p) {
      return {
        label: p.title,
        href: pageHref(persona.id, p.id),
        active: p.id === PD.state.pageId,
        onClick: "PD.openPage('" + p.id + "', event)",
      };
    });
  };

  PD.renderMenu = function () {
    var host = document.getElementById(MENU_HOST_ID);
    if (!host) return;
    host.innerHTML = VC.navigationDrawer({
      items: PD.menuItems(),
      onClose: 'PD.setMenuOpen(false)',
      overlayId: DRAWER_IDS.overlayId,
      drawerId: DRAWER_IDS.drawerId,
      logoName: 'pricing', logoEm: 'Desk', logoSub: 'Pricing & Approvals', // descriptor, like Valu Cal's "Pricing Engine" (2026-10-26)
    });
  };

  PD.setMenuOpen = function (open) {
    VC.setNavigationDrawerOpen(open, DRAWER_IDS);
    if (open) {
      var active = document.querySelector('#' + DRAWER_IDS.drawerId + ' .sidebar-item.active');
      if (active) active.focus();
    }
  };

  PD.isMenuOpen = function () {
    var drawer = document.getElementById(DRAWER_IDS.drawerId);
    return !!drawer && drawer.classList.contains('active');
  };

  PD.openPage = function (pageId, event) {
    if (event) event.preventDefault();
    PD.setMenuOpen(false);
    PD.navigate({ page: pageId });
    // The header is re-rendered: give the focus back to the new ☰ button (B-F1).
    var menuButton = document.querySelector('.vc-header button[aria-label="Open main menu"]');
    if (menuButton) menuButton.focus();
  };

  PD.renderPage = function () {
    var host = document.getElementById(PAGE_HOST_ID);
    var page = PD.currentPage();
    if (!host || !page) return;
    var render = (PD.PAGE_RENDERERS || {})[page.id];
    var header = render && page.headerInBody ? '' :
      '<div class="vc-page-header"><div class="vc-page-header__main">' +
        '<h1 class="vc-page-header__title" id="pd-page-title">' + esc(page.title) + '</h1>' +
        '<p class="vc-page-header__subtitle">' + esc(page.subtitle) + '</p>' +
      '</div></div>';
    host.innerHTML = '<section id="pd-page-' + esc(page.id) + '" aria-labelledby="pd-page-title">' + header +
      '<div id="pd-page-body"></div>' +
    '</section>';
    document.title = page.title + ' — Pricing Desk';
    // Pages with content register a renderer (e.g. js/pd-promotions.js); the others stay empty for now. With
    // headerInBody the renderer shows the page title (h1#pd-page-title) and subtitle itself.
    if (render) render(document.getElementById('pd-page-body'), page);
  };

  PD.render = function () {
    PD.renderHeader();
    PD.renderMenu();
    PD.renderPage();
  };

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && PD.isMenuOpen()) PD.setMenuOpen(false);
  });
})(window);
