/* Pricing Desk — Promotions page (brief 02, batch 1): list + detail in the shared split view (vc-master-detail,
   candidate Core layout). Read-only. The list: header + count badge, search (name or code), the Filters button that
   opens the filter drawer (Type, Status — same pattern as Valu Cal's Proposal Dashboard; no status checked = Draft,
   Pending approval and Active, so Expired and Retired show only when checked), items ordered Pending approval,
   Draft, Active, Expired, Retired and newest offer start first inside each; the first item is selected.
   The detail (batch 2): the common header (name, status, meta line, pending-approval notice; "Submit for approval"
   on a Draft) and read-only sections per level — Order Discount 1–7, Account Discount program 1–5 (brief 02 › Spec).
   Data: config/promotions.config.js; what changes in the session (a Draft submitted for approval; new promotions
   from the create form, brief 03) is kept in sessionStorage so the approver queue (brief 04) can read it. */
(function (global) {
  var PD = global.PD = global.PD || {};

  // Pricing Desk's own status colors (brief 02): Valu Cal's proposal colors don't apply here.
  var STATUS = {
    pending: { label: 'Pending approval', badge: 'badge--yellow', rank: 0 },
    draft: { label: 'Draft', badge: 'badge--gray', rank: 1 },
    active: { label: 'Active', badge: 'badge--green', rank: 2 },
    expired: { label: 'Expired', badge: 'badge--white', rank: 3 },
    retired: { label: 'Retired', badge: 'badge--white', rank: 4 },
  };
  var STATUS_ORDER = ['pending', 'draft', 'active', 'expired', 'retired'];
  var ACTIVE_STATUSES = ['pending', 'draft', 'active'];
  var LEVELS = { account: 'Account Discount', order: 'Order Discount' };
  // Filter drawer fields (2026-10-23, per Catalina: "un feature de filtro como el que tenemos en Valu Cal").
  var FILTER_FIELDS = [
    { key: 'types', title: 'Type', values: ['account', 'order'], label: function (v) { return LEVELS[v]; } },
    { key: 'statuses', title: 'Status', values: STATUS_ORDER, label: function (v) { return STATUS[v].label; },
      note: 'With none checked: Draft, Pending approval and Active.' },
  ];
  var FILTER_DRAWER_ID = 'pd-promo-filter-drawer';
  var MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function orDash(v) { return v == null || v === '' ? '--' : v; }

  PD.formatDate = function (iso) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso || '');
    return m ? MONTHS[Number(m[2]) - 1] + ' ' + Number(m[3]) + ', ' + m[1] : '--';
  };

  PD.offerWindow = function (p) {
    return PD.formatDate(p.offerStart) + ' – ' + (p.offerEnd ? PD.formatDate(p.offerEnd) : 'No end date');
  };

  // filters: nothing checked in a field = no filter on it, except Status (none checked = Draft, Pending approval, Active).
  PD.promoState = PD.promoState || { search: '', filters: { types: [], statuses: [] }, selectedId: null };
  var filterDraft = { types: [], statuses: [] };
  var openFilterSections = { types: true, statuses: true };

  // ── Session store (sessionStorage): what the demo changes — { changes: { <id>: { status, submittedOn, ... } },
  // created: [<promotion>, ...] } (created = new promotions from the create form, brief 03).
  // A copy in memory backs it up: where storage is missing or blocked (private windows, some file:// contexts, jsdom)
  // the change lasts until the page reloads.
  var STORE_KEY = 'pd.promotions.session.v1';
  var memorySession = { changes: {}, created: [] };
  function storage() {
    try { return global.sessionStorage || null; } catch (e) { return null; }
  }
  PD.readPromotionSession = function () {
    var s = storage();
    if (!s) return memorySession;
    try {
      var raw = s.getItem(STORE_KEY);
      var data = raw ? JSON.parse(raw) : null;
      return data && typeof data === 'object' ? { changes: data.changes || {}, created: data.created || [] } : memorySession;
    } catch (e) { return memorySession; }
  };
  function writePromotionSession(data) {
    memorySession = { changes: data.changes || {}, created: data.created || [] };
    var s = storage();
    try { if (s) s.setItem(STORE_KEY, JSON.stringify(memorySession)); } catch (e) { /* storage blocked: memory only */ }
  }
  PD.resetPromotionSession = function () {
    memorySession = { changes: {}, created: [] };
    var s = storage();
    try { if (s) s.removeItem(STORE_KEY); } catch (e) { /* storage blocked */ }
  };

  // A new promotion from the create form (brief 03), kept for the session next to the sample data.
  PD.addSessionPromotion = function (promotion) {
    var data = PD.readPromotionSession();
    data.created = data.created.filter(function (p) { return p.id !== promotion.id; }).concat([promotion]);
    writePromotionSession(data);
  };

  // Sample data plus the promotions created in the session, with the session's changes applied on top.
  PD.promotions = function () {
    var session = PD.readPromotionSession();
    var changes = session.changes;
    return (PD.PROMOTIONS || []).concat(session.created).map(function (p) {
      var c = changes[p.id];
      if (!c) return p;
      var merged = {};
      Object.keys(p).forEach(function (k) { merged[k] = p[k]; });
      Object.keys(c).forEach(function (k) { merged[k] = c[k]; });
      return merged;
    });
  };

  function todayIso() {
    var d = new Date();
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  }

  // "Submit for approval" on a Draft: Pending approval, submitted today, waiting for Pricing & Finance.
  // PENDING (business): who approves a new promotion — Pricing & Finance for now (requirements by section › Section 3).
  PD.submitPromotion = function (id) {
    var p = PD.findPromotion(id);
    if (!p || p.status !== 'draft') return;
    var data = PD.readPromotionSession();
    var c = data.changes[id] || {};
    c.status = 'pending';
    c.submittedOn = todayIso();
    c.waitingFor = 'Pricing & Finance';
    data.changes[id] = c;
    writePromotionSession(data);
    PD.promoState.selectedId = id;
    PD.updatePromotions();
    var title = el('pd-promo-title');
    if (title) { title.setAttribute('tabindex', '-1'); title.focus(); }
  };

  // Pending approval first (someone must act), then Draft, Active, Expired, Retired; newest offer start first inside.
  PD.sortPromotions = function (list) {
    return list.slice().sort(function (a, b) {
      return (STATUS[a.status].rank - STATUS[b.status].rank) || (a.offerStart < b.offerStart ? 1 : a.offerStart > b.offerStart ? -1 : 0);
    });
  };

  PD.filterPromotions = function (list, state, filters) {
    var q = (state.search || '').trim().toLowerCase();
    filters = filters || state.filters;
    var statuses = filters.statuses.length ? filters.statuses : ACTIVE_STATUSES;
    return list.filter(function (p) {
      if (filters.types.length && filters.types.indexOf(p.level) === -1) return false;
      if (statuses.indexOf(p.status) === -1) return false;
      if (q && (p.name + ' ' + p.code).toLowerCase().indexOf(q) === -1) return false;
      return true;
    });
  };

  PD.visiblePromotions = function () {
    return PD.sortPromotions(PD.filterPromotions(PD.promotions(), PD.promoState));
  };

  PD.findPromotion = function (id) {
    return PD.promotions().filter(function (p) { return p.id === id; })[0] || null;
  };

  function badge(status) {
    var s = STATUS[status];
    return '<span class="badge ' + s.badge + '">' + esc(s.label) + '</span>';
  }

  function itemHtml(p, selected) {
    return '<li><button type="button" class="vc-master-detail__item' + (selected ? ' is-selected' : '') + '" id="pd-promo-item-' + esc(p.id) + '"' +
      (selected ? ' aria-current="true"' : '') + ' onclick="PD.selectPromotion(\'' + esc(p.id) + '\')">' +
      '<span class="vc-master-detail__item-main">' +
        '<span class="text-body-medium-bold">' + esc(p.name) + '</span>' +
        '<span class="vc-master-detail__item-sub text-body-small">' + esc(LEVELS[p.level] + ', ' + p.code) + '</span>' +
        '<span class="vc-master-detail__item-sub text-body-small">' + esc(PD.offerWindow(p)) + '</span>' +
      '</span>' + badge(p.status) +
    '</button></li>';
  }

  // ── Detail sections (batch 2). Values are text; lists are comma-separated; empty / not applicable = "--".
  var SALE_MODES = { OPEX: 'OPEX', CAPEX: 'CAPEX', Any: 'Any' };
  var FIXED_EXCLUSIONS = 'Public schedules and seasonal lines (always excluded)';
  var ORDER_LATER = [
    'Lasts at most as long as the order and the MSA term.',
    'Dropped at renewal, rewrap and reactivation.',
    'Promoted units never exceed subscribed units.',
    'On cancellation, units without a promotion go first.',
    'The early-cancellation fee uses the full contracted price.',
  ];
  var ACCOUNT_FIXED_RULES = [
    'Applies to every item\'s subscription charge, not to hardware or installation, for the whole MSA term.',
    'Never on auto-renewal and never per order line.',
    'Not carried over to the next term.',
    'Never for public schedules.',
    'Can\'t be combined with a Custom Discount on the same MSA.',
    'Shown to the rep only when its rules apply; if several programs apply, the rep picks one.',
  ];

  // Shared with the create form (js/pd-promotion-create.js), which shows them read-only at the end.
  PD.PROMOTION_RULES = { orderLater: ORDER_LATER, accountFixed: ACCOUNT_FIXED_RULES };

  function list(values) { return values && values.length ? values.join(', ') : '--'; }
  function money(n) {
    if (n == null || isNaN(n)) return '--';
    var fixed = Math.abs(n).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    return (n < 0 ? '-$' : '$') + fixed;
  }
  function count(n) { return n == null ? '--' : String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ','); }

  // Monthly benefit per unit: a percentage of the row's sample list price, or the amount itself.
  PD.monthlyBenefit = function (row) {
    if (!row || row.value == null) return null;
    if (row.type === 'amount') return Number(row.value);
    return row.listPrice == null ? null : Math.round(row.listPrice * row.value) / 100;
  };
  PD.discountLabel = function (row) {
    if (!row || row.value == null) return '--';
    return row.type === 'amount' ? money(row.value) + ' per unit / month' : row.value + '%';
  };

  // nested (brief 04): the sections shown inside another detail (an approval request) — no number, smaller title.
  var nestedSections = false;
  function section(id, title, bodyHtml) {
    var t = nestedSections ? title.replace(/^\d+\.\s*/, '') : title;
    return '<section class="vc-master-detail__section" id="pd-promo-section-' + id + '" aria-labelledby="pd-promo-section-' + id + '-title">' +
      '<h3 class="vc-master-detail__section-title ' + (nestedSections ? 'text-body-medium-bold' : 'text-body-large-bold') + '" id="pd-promo-section-' + id + '-title">' + esc(t) + '</h3>' + bodyHtml +
    '</section>';
  }
  function fields(pairs) {
    return '<dl class="vc-master-detail__fields">' + pairs.map(function (f) {
      return '<dt class="text-body-small-bold">' + esc(f[0]) + '</dt><dd class="text-body-medium">' + esc(f[1]) + '</dd>';
    }).join('') + '</dl>';
  }
  function bullets(items) {
    return '<ul class="vc-master-detail__bullets text-body-medium">' + items.map(function (t) { return '<li>' + esc(t) + '</li>'; }).join('') + '</ul>';
  }

  function whoSeesIt(p) {
    var c = p.conditions || {};
    var has = ['account', 'deal', 'user'].some(function (k) { return c[k] && c[k].length; });
    if (!has) return '<p class="text-body-medium" id="pd-promo-all-accounts">All accounts, all reps</p>';
    return fields([['Account', list(c.account)], ['Deal / order', list(c.deal)], ['User', list(c.user)]]);
  }

  function appliesToTable(rows) {
    if (!rows || !rows.length) return '<p class="text-body-medium">--</p>';
    var body = rows.map(function (r) {
      return '<tr>' + [
        r.target, r.kind, SALE_MODES[r.saleMode] || r.saleMode, r.installMethod, r.type === 'amount' ? 'Amount' : 'Percentage',
        PD.discountLabel(r), money(PD.monthlyBenefit(r)),
      ].map(function (v, i) {
        return '<td class="table-body-cell' + (i >= 5 ? ' vc-master-detail__num' : '') + '">' + esc(orDash(v)) + '</td>';
      }).join('') + '</tr>';
    });
    return '<div class="vc-master-detail__table-wrap">' + VC.dataTable({
      className: 'vc-master-detail__table', ariaLabel: 'Applies to', rowsHtml: body,
      columns: [
        { label: 'Applies to' }, { label: 'Kind' }, { label: 'Sale mode' }, { label: 'Installation' }, { label: 'Type' },
        { label: 'Value', className: 'vc-master-detail__num' }, { label: 'Monthly benefit per unit', className: 'vc-master-detail__num' },
      ],
    }) + '</div>';
  }

  function limitsFields(limits) {
    var min = (limits && limits.min) || {};
    var max = (limits && limits.max) || {};
    // "Min 10", "Max 100", "10 – 50" or "--".
    function range(a, b, fmt) {
      if (a == null && b == null) return '--';
      if (a == null) return 'Max ' + fmt(b);
      if (b == null) return 'Min ' + fmt(a);
      return fmt(a) + ' – ' + fmt(b);
    }
    return fields([
      ['Units per order', range(min.perOrder, max.perOrder, count)],
      ['Units per account', range(min.perAccount, max.perAccount, count)],
      ['Units in total', range(min.total, max.total, count)],
      ['Budget', range(min.budget, max.budget, money)],
    ]);
  }

  function combinedWith(p) {
    var names = (p.combinableWith || []).map(function (id) { var o = PD.findPromotion(id); return o ? o.name : null; }).filter(Boolean);
    return '<p class="text-body-medium" id="pd-promo-combined">' + esc(list(names)) + '</p>';
  }

  function orderSections(p) {
    var d = p.definition || {};
    return section('definition', '1. Definition', (d.description ? '<p class="text-body-medium">' + esc(d.description) + '</p>' : '') + appliesToTable(d.appliesTo)) +
      section('dates', '2. Dates', fields([
        ['Offer window', PD.offerWindow(p) + ' (when it can be picked in Valu Cal)'],
        ['Benefit duration', p.benefitMonths ? p.benefitMonths + ' months from the order date, never past the MSA term end' : '--'],
      ])) +
      section('who', '3. Who sees it', whoSeesIt(p)) +
      section('exclusions', '4. Exclusions', fields([['Always', FIXED_EXCLUSIONS], ['By condition', list(p.exclusions)]])) +
      section('limits', '5. Limits', limitsFields(p.limits)) +
      section('combined', '6. Can be combined with', combinedWith(p)) +
      section('later', '7. What happens to it later', bullets(ORDER_LATER));
  }

  function bandsText(bands) {
    if (!bands || !bands.length) return '--';
    return bands.map(function (b) { return (b.upTo == null ? 'Above' : 'Up to ' + b.upTo + '%') + ': ' + b.role; }).join(', ');
  }

  function accountSections(p) {
    var d = p.definition || {};
    var a = p.approval || {};
    return section('definition', '1. Definition', (d.description ? '<p class="text-body-medium">' + esc(d.description) + '</p>' : '') + fields([
        ['Discount', d.percent == null ? '--' : d.percent + '% on the MSA term'],
        ['Applies to', 'Every item\'s subscription charge (not hardware or installation)'],
        ['Offered at', list(d.transactions)],
      ])) +
      section('dates', '2. Dates', fields([['Offer window', PD.offerWindow(p) + ' (when it can be picked in Valu Cal)']])) +
      section('who', '3. Who sees it', whoSeesIt(p)) +
      section('approval', '4. Approval limits', fields([
        ['Maximum without approval', a.maxWithoutApproval == null ? '--' : a.maxWithoutApproval + '%'],
        ['Approval bands', bandsText(a.bands)],
        ['Deal conditions', list(a.dealConditions)],
        ['Priority', a.priority == null ? '--' : a.priority + ' — order in the rep\'s list when several programs apply; the first one is preselected'],
      ])) +
      section('rules', '5. Fixed rules', bullets(ACCOUNT_FIXED_RULES));
  }

  // ── Promotion actions (kebab next to Submit; 2026-10-26, Catalina: shown now, they do nothing yet).
  // Items follow the lifecycle in the requirements (Section 2 › Lifecycle; recall: Approval Engine SB-07).
  // PENDING (brief 03+): edit, duplicate, bring the offer end forward, retire, delete, withdraw.
  var PROMO_MENU_ID = 'pd-promo-actions';
  var PROMO_ACTIONS = {
    draft: [['edit', 'Edit'], ['duplicate', 'Duplicate'], 'divider', ['delete', 'Delete draft', true]],
    pending: [['withdraw', 'Withdraw approval request'], ['duplicate', 'Duplicate']],
    active: [['edit', 'Edit (new version)'], ['end-early', 'Bring the offer end forward'], ['duplicate', 'Duplicate'], 'divider', ['retire', 'Retire', true]],
    expired: [['duplicate', 'Duplicate']],
    retired: [['duplicate', 'Duplicate']],
  };
  function promoActionsMenu(p) {
    var items = (PROMO_ACTIONS[p.status] || []).map(function (a) {
      if (a === 'divider') return { type: 'divider' };
      return { label: a[1], danger: !!a[2], id: 'pd-promo-action-' + a[0], onClick: "PD.promotionAction('" + a[0] + "')" };
    });
    return VC.kebabMenu({ id: PROMO_MENU_ID, label: 'Promotion actions', triggerTitle: 'More actions', onToggle: 'PD.togglePromotionMenu(event)', items: items });
  }
  PD.setPromotionMenuOpen = function (open) {
    var panel = document.querySelector('#' + PROMO_MENU_ID + ' .kebab-menu__panel');
    var trigger = document.querySelector('#' + PROMO_MENU_ID + ' > button');
    if (!panel || !trigger) return;
    panel.classList.toggle('hidden', !open);
    trigger.setAttribute('aria-expanded', String(!!open));
  };
  PD.togglePromotionMenu = function (event) {
    if (event) event.stopPropagation();
    var panel = document.querySelector('#' + PROMO_MENU_ID + ' .kebab-menu__panel');
    PD.setPromotionMenuOpen(!!panel && panel.classList.contains('hidden'));
  };
  // Not built yet: the menu just closes and the focus goes back to its button.
  PD.promotionAction = function () {
    PD.setPromotionMenuOpen(false);
    var trigger = document.querySelector('#' + PROMO_MENU_ID + ' > button');
    if (trigger) trigger.focus();
  };
  document.addEventListener('click', function (e) {
    var menu = document.getElementById(PROMO_MENU_ID);
    if (menu && !menu.contains(e.target)) PD.setPromotionMenuOpen(false);
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') PD.setPromotionMenuOpen(false);
  });

  // A promotion's read-only sections, for other pages (brief 04: what an approval request asks for).
  PD.promotionSectionsHtml = function (p, opts) {
    nestedSections = !!(opts && opts.nested);
    try { return p.level === 'account' ? accountSections(p) : orderSections(p); } finally { nestedSections = false; }
  };
  PD.promotionStatusBadge = function (status) { return STATUS[status] ? badge(status) : ''; };

  function detailHtml(p) {
    if (!p) return '<div class="vc-master-detail__empty text-body-medium">Select a promotion</div>';
    var meta = [LEVELS[p.level], p.code, p.version ? 'v' + p.version : '', p.owner].map(orDash).join(', ');
    var pending = p.status === 'pending'
      ? VC.approvalNotification({ title: esc('Submitted for approval on ' + PD.formatDate(p.submittedOn) + ', waiting for ' + orDash(p.waitingFor)) })
      : '';
    var submit = p.status === 'draft'
      ? '<button type="button" class="btn btn--primary btn--small" id="pd-promo-submit" onclick="PD.submitPromotion(\'' + esc(p.id) + '\')">Submit for approval</button>'
      : '';
    var actions = '<div class="vc-master-detail__detail-actions">' + submit + promoActionsMenu(p) + '</div>';
    return '<div class="vc-master-detail__detail-header">' +
        '<h2 class="vc-master-detail__detail-title text-title-xsmall-bold" id="pd-promo-title">' + esc(p.name) + '</h2>' + badge(p.status) + actions +
      '</div>' +
      '<p class="vc-master-detail__detail-meta text-body-medium" id="pd-promo-meta">' + esc(meta) + '</p>' + pending +
      '<div class="vc-master-detail__sections" id="pd-promo-sections">' + (p.level === 'account' ? accountSections(p) : orderSections(p)) + '</div>';
  }

  function el(id) { return document.getElementById(id); }

  // Re-renders the count, the items and the detail (not the toolbar, so the search field keeps its focus).
  PD.updatePromotions = function () {
    var visible = PD.visiblePromotions();
    var state = PD.promoState;
    if (!visible.some(function (p) { return p.id === state.selectedId; })) state.selectedId = visible.length ? visible[0].id : null;
    var count = el('pd-promo-count');
    if (count) {
      count.textContent = '(' + visible.length + ')';
      count.setAttribute('aria-label', visible.length + (visible.length === 1 ? ' promotion' : ' promotions') + ' shown');
    }
    var items = el('pd-promo-items');
    if (items) {
      if (!PD.promotions().length) {
        items.innerHTML = '<div class="vc-master-detail__empty text-body-medium" id="pd-promo-empty">No promotions yet</div>';
      } else if (!visible.length) {
        items.innerHTML = '<div class="vc-master-detail__empty text-body-medium" id="pd-promo-empty">No promotions match your search or filters' +
          '<button type="button" class="text-link" onclick="PD.clearPromotionFilters()">Clear filters</button></div>';
      } else {
        items.innerHTML = '<ul class="vc-master-detail__items" aria-label="Promotions">' +
          visible.map(function (p) { return itemHtml(p, p.id === state.selectedId); }).join('') + '</ul>';
      }
    }
    var detail = el('pd-promo-detail');
    if (detail) detail.innerHTML = detailHtml(PD.findPromotion(state.selectedId));
  };

  // Selecting only moves the highlight and redraws the detail, so the focus stays on the item.
  PD.selectPromotion = function (id) {
    if (!PD.findPromotion(id)) return;
    PD.promoState.selectedId = id;
    Array.prototype.forEach.call(document.querySelectorAll('#pd-promo-items .vc-master-detail__item'), function (b) {
      var on = b.id === 'pd-promo-item-' + id;
      b.classList.toggle('is-selected', on);
      if (on) b.setAttribute('aria-current', 'true'); else b.removeAttribute('aria-current');
    });
    var detail = el('pd-promo-detail');
    if (detail) detail.innerHTML = detailHtml(PD.findPromotion(id));
  };

  PD.setPromotionSearch = function (value) { PD.promoState.search = value || ''; PD.updatePromotions(); };

  // ── Filters: button + drawer (same pattern and shared pieces as Valu Cal's Proposal Dashboard filters:
  // btn-icon + badge-indicator count, VC.drawer, vc-accordion with vc-check-row, "Clear all", "Show results (N)").
  // The drawer edits a draft; "Show results" applies it, closing without applying discards it.
  PD.activePromotionFilterCount = function () {
    return FILTER_FIELDS.filter(function (f) { return PD.promoState.filters[f.key].length > 0; }).length;
  };

  PD.renderPromotionFilterBar = function () {
    var bar = el('pd-promo-filter-bar');
    if (!bar) return;
    var count = PD.activePromotionFilterCount();
    bar.innerHTML = '<button type="button" class="btn-icon btn-icon--solid btn-icon--medium ql-filter-btn" id="pd-promo-filter-btn" title="Filters"' +
        ' aria-label="Filters' + (count ? ' (' + count + ' active)' : '') + '" aria-haspopup="dialog" aria-controls="' + FILTER_DRAWER_ID + '" onclick="PD.openPromotionFilters()">' +
        '<span class="material-symbols-outlined" aria-hidden="true">filter_list</span>' +
        (count ? '<span class="badge-indicator badge-indicator--numbered ql-filter-count" aria-hidden="true">' + count + '</span>' : '') +
      '</button>' +
      (count ? '<button type="button" class="text-link text-link--small" id="pd-promo-filter-clear" onclick="PD.clearPromotionFilters()">Clear filters</button>' : '');
  };

  function ensureFilterDrawer() {
    if (el(FILTER_DRAWER_ID)) return;
    document.body.insertAdjacentHTML('beforeend', VC.drawer({
      id: FILTER_DRAWER_ID, title: 'Filters', onClose: 'PD.closePromotionFilters()',
      actions: [{ label: 'Show results', primary: true, id: 'pd-promo-filter-apply', onClick: 'PD.applyPromotionFilters()' }],
    }));
    var title = el(FILTER_DRAWER_ID + '-title');
    if (title) title.insertAdjacentHTML('afterend', '<button type="button" class="text-link text-link--small ql-filter-clear-all" id="pd-promo-filter-clear-all" onclick="PD.clearPromotionFilterDraft()">Clear all</button>');
  }

  PD.renderPromotionFilterDrawer = function () {
    var body = document.querySelector('#' + FILTER_DRAWER_ID + ' .vc-drawer__body');
    if (!body) return;
    body.innerHTML = FILTER_FIELDS.map(function (f) {
      var picked = filterDraft[f.key];
      var open = openFilterSections[f.key];
      var rows = f.values.map(function (v) {
        return '<label class="vc-check-row"><input type="checkbox" class="checkbox__input" data-field="' + f.key + '" value="' + v + '"' + (picked.indexOf(v) !== -1 ? ' checked' : '') +
          ' onchange="PD.togglePromotionFilterValue(\'' + f.key + '\', \'' + v + '\', this.checked)"><span class="vc-check-row__text">' + esc(f.label(v)) + '</span></label>';
      }).join('');
      return '<div class="vc-accordion ql-filter-section' + (open ? ' is-open' : '') + '" id="pd-promo-filter-' + f.key + '">' +
        '<button type="button" class="vc-accordion__header" aria-expanded="' + open + '" onclick="PD.togglePromotionFilterSection(\'' + f.key + '\')">' +
          '<span class="vc-accordion__title">' + esc(f.title) + '</span>' +
          '<span class="vc-accordion__right">' + (picked.length ? '<span class="badge vc-accordion__count">' + picked.length + '</span>' : '') +
            '<span class="material-symbols-outlined vc-accordion__chevron" aria-hidden="true">expand_more</span></span>' +
        '</button>' +
        '<div class="vc-accordion__body">' + (f.note ? '<p class="text-body-small">' + esc(f.note) + '</p>' : '') + rows + '</div>' +
      '</div>';
    }).join('');
    var clearAll = el('pd-promo-filter-clear-all');
    if (clearAll) clearAll.disabled = !FILTER_FIELDS.some(function (f) { return filterDraft[f.key].length; });
    var apply = el('pd-promo-filter-apply');
    if (apply) apply.textContent = 'Show results (' + PD.filterPromotions(PD.promotions(), PD.promoState, filterDraft).length + ')';
  };

  PD.openPromotionFilters = function () {
    var first = !el(FILTER_DRAWER_ID);
    ensureFilterDrawer();
    filterDraft = { types: PD.promoState.filters.types.slice(), statuses: PD.promoState.filters.statuses.slice() };
    PD.renderPromotionFilterDrawer();
    if (first) el(FILTER_DRAWER_ID).getBoundingClientRect(); // commit the closed position so the first slide-in animates
    VC.setDrawerOpen(FILTER_DRAWER_ID, true);
  };

  PD.isPromotionFiltersOpen = function () {
    var d = el(FILTER_DRAWER_ID);
    return !!d && d.classList.contains('is-open');
  };

  PD.closePromotionFilters = function () {
    VC.setDrawerOpen(FILTER_DRAWER_ID, false);
    var btn = el('pd-promo-filter-btn');
    if (btn) btn.focus();
  };

  PD.togglePromotionFilterSection = function (key) {
    openFilterSections[key] = !openFilterSections[key];
    PD.renderPromotionFilterDrawer();
  };

  PD.togglePromotionFilterValue = function (key, value, checked) {
    var cur = filterDraft[key].filter(function (v) { return v !== value; });
    if (checked) cur.push(value);
    filterDraft[key] = cur;
    PD.renderPromotionFilterDrawer();
  };

  PD.clearPromotionFilterDraft = function () {
    filterDraft = { types: [], statuses: [] };
    PD.renderPromotionFilterDrawer();
  };

  PD.applyPromotionFilters = function () {
    PD.promoState.filters = { types: filterDraft.types.slice(), statuses: filterDraft.statuses.slice() };
    PD.renderPromotionFilterBar();
    PD.updatePromotions();
    PD.closePromotionFilters();
  };

  // "Clear filters" (next to the Filters button and in the empty state): search and filters back to the default.
  PD.clearPromotionFilters = function () {
    PD.promoState.search = '';
    PD.promoState.filters = { types: [], statuses: [] };
    var body = el('pd-promotions');
    if (body) PD.renderPromotionsPage(body.parentElement);
    var search = el('pd-promo-search');
    if (search) search.focus();
  };

  function toolbarHtml(state) {
    return '<div class="vc-master-detail__toolbar">' +
      VC.searchField({ id: 'pd-promo-search', placeholder: 'Search by name or code', value: state.search, onInput: 'PD.setPromotionSearch(this.value)' }) +
      '<div class="ql-filter-bar" id="pd-promo-filter-bar"></div>' +
    '</div>';
  }

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && PD.isPromotionFiltersOpen()) PD.closePromotionFilters();
  });

  // 2026-10-23 (Catalina): the list takes the full height of the window and carries the page title and subtitle.
  // 2026-10-26 (Catalina): edge to edge (--bleed), as in the first Pricing Desk prototype.
  // (the page has no separate header: config/pages.config.js headerInBody).
  PD.renderPromotionsPage = function (host, page) {
    if (PD.state.view === 'create' && PD.renderCreatePromotion) { PD.renderCreatePromotion(host); return; }
    page = page || (PD.findPage && PD.findPage('promotions')) || { title: 'Promotions & Discounts', subtitle: '' };
    host.innerHTML = '<div class="vc-master-detail vc-master-detail--fill vc-master-detail--bleed" id="pd-promotions">' +
      '<section class="vc-master-detail__list" aria-labelledby="pd-page-title">' +
        '<div class="vc-master-detail__list-header">' +
          '<div class="vc-master-detail__list-title-row">' +
            '<h1 class="vc-master-detail__list-title vc-page-header__title" id="pd-page-title">' + esc(page.title) + '</h1>' +
            '<span class="vc-master-detail__list-title vc-page-header__title" id="pd-promo-count"></span>' +
            '<div class="vc-master-detail__list-actions">' +
              '<button type="button" class="btn btn--primary btn--small" id="pd-promo-create" onclick="PD.createPromotion()">Create new</button>' +
            '</div>' +
          '</div>' +
          (page.subtitle ? '<p class="vc-page-header__subtitle">' + esc(page.subtitle) + '</p>' : '') +
        '</div>' + toolbarHtml(PD.promoState) +
        '<div class="vc-master-detail__scroll" id="pd-promo-items"></div>' +
      '</section>' +
      '<section class="vc-master-detail__detail" id="pd-promo-detail" aria-live="polite"></section>' +
    '</div>';
    PD.renderPromotionFilterBar();
    PD.updatePromotions();
  };

  // "Create new" opens the create form (brief 03, js/pd-promotion-create.js) in this page: ?page=promotions&view=create.
  PD.createPromotion = function () { PD.navigate({ page: 'promotions', view: 'create' }); };

  PD.PAGE_RENDERERS = PD.PAGE_RENDERERS || {};
  PD.PAGE_RENDERERS.promotions = PD.renderPromotionsPage;
})(window);
