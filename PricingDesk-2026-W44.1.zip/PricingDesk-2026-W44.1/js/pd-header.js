/* Pricing Desk — app header and Simulation Builder (brief 01; 2026-10-26).
   The header is the shared VC.appHeader (logo "pricing" / "Desk", no subtitle) with, on the right, the notifications
   bell (js/pd-notifications.js) and the user block: person icon, name and role of the current persona — no menu.
   2026-10-26 (Catalina): the persona switcher left the app header; picking who you are is a demo control, so it lives
   in a "Simulation Builder" link in the (mock) Salesforce bar that opens a drawer, as in Valu Cal. Applying a persona
   goes to that persona's home (js/pd-app.js keeps the state and the URL: ?persona=<id>&page=<id>). */
(function (global) {
  var PD = global.PD = global.PD || {};
  var HOST_ID = 'pd-header-host';

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function config() { return PD.PERSONAS_CONFIG || { defaultId: '', personas: [] }; }

  PD.personas = function () { return config().personas; };

  PD.findPersona = function (id) {
    return PD.personas().filter(function (p) { return p.id === id; })[0] || null;
  };

  // ?persona=<id> from a query string; unknown or missing → the default persona (Alicia).
  PD.personaIdFromSearch = function (search) {
    var id = new URLSearchParams(search || '').get('persona');
    return PD.findPersona(id) ? id : config().defaultId;
  };

  PD.state = PD.state || { personaId: PD.personaIdFromSearch(global.location ? global.location.search : '') };

  PD.currentPersona = function () {
    return PD.findPersona(PD.state.personaId) || PD.findPersona(config().defaultId);
  };

  PD.userBlock = function (persona) {
    return '<div class="vc-header-right" id="pd-user">' +
      '<div class="vc-account-heading-row">' +
        '<div class="vc-account-icon">' + VC.icon('person') + '</div>' + // as in Valu Cal, no background (Catalina, 2026-10-26)
        '<div class="vc-account-heading">' +
          '<div class="vc-account-name" id="pd-user-name">' + esc(persona.name) + '</div>' +
          '<div class="vc-account-subtitle" id="pd-user-role">' + esc(persona.role) + '</div>' +
        '</div>' +
      '</div>' +
    '</div>';
  };

  PD.renderHeader = function () {
    var host = document.getElementById(HOST_ID);
    if (!host) return;
    host.innerHTML = VC.appHeader({
      logoName: 'pricing', logoEm: 'Desk', logoSub: 'Pricing & Approvals', // descriptor, like Valu Cal's "Pricing Engine" (2026-10-26)
      onMenuClick: 'PD.setMenuOpen(true)',
      // 2026-10-26: the notifications bell next to the user block (js/pd-notifications.js).
      rightHtml: '<div class="vc-header-end">' + (PD.notificationsBell ? PD.notificationsBell() : '') + PD.userBlock(PD.currentPersona()) + '</div>',
    });
  };

  // Picking a persona switches the whole app to it: header, menu and its home page.
  PD.switchPersona = function (id) {
    var persona = PD.findPersona(id);
    if (!persona) return;
    PD.navigate({ persona: id, page: persona.home });
  };

  // ── Simulation Builder (demo controls): a drawer from the Salesforce bar, as in Valu Cal. For now: the role.
  var SIM_ID = 'pd-sim-builder';
  var simDraft = null;
  function simBodyHtml() {
    return '<div class="vc-sim-builder">' +
      '<h3 class="vc-sim-builder__title text-body-large-bold">Role</h3>' +
      '<p class="text-body-small vc-sim-builder__note">Who is using Pricing Desk. Each role sees its own pages.</p>' +
      '<div class="vc-sim-builder__options" role="radiogroup" aria-label="Role">' +
        PD.personas().map(function (p) {
          return VC.selectableOptionRow({ name: 'pd-sim-persona', value: p.id, title: p.name, meta: [esc(p.role)],
            checked: p.id === simDraft, onChange: "PD.setSimulationPersona('" + p.id + "')" });
        }).join('') +
      '</div>' +
    '</div>';
  }
  function ensureSimDrawer() {
    if (document.getElementById(SIM_ID)) return;
    document.body.insertAdjacentHTML('beforeend', VC.drawer({
      id: SIM_ID, title: 'Simulation Builder', onClose: 'PD.closeSimulationBuilder()',
      actions: [
        { label: 'Cancel', id: SIM_ID + '-cancel', onClick: 'PD.closeSimulationBuilder()' },
        { label: 'Apply', primary: true, id: SIM_ID + '-apply', onClick: 'PD.applySimulationBuilder()' },
      ],
    }));
  }
  PD.openSimulationBuilder = function () {
    var first = !document.getElementById(SIM_ID);
    ensureSimDrawer();
    simDraft = PD.state.personaId;
    var body = document.querySelector('#' + SIM_ID + ' .vc-drawer__body');
    if (body) body.innerHTML = simBodyHtml();
    if (first) document.getElementById(SIM_ID).getBoundingClientRect(); // so the first slide-in animates
    VC.setDrawerOpen(SIM_ID, true);
    var checked = document.querySelector('#' + SIM_ID + ' input[name="pd-sim-persona"]:checked');
    if (checked) checked.focus();
  };
  PD.setSimulationPersona = function (id) { simDraft = id; };
  PD.isSimulationBuilderOpen = function () { var d = document.getElementById(SIM_ID); return !!d && d.classList.contains('is-open'); };
  PD.closeSimulationBuilder = function () {
    VC.setDrawerOpen(SIM_ID, false);
    var link = document.getElementById('pd-sim-builder-link');
    if (link) link.focus();
  };
  PD.applySimulationBuilder = function () {
    var id = simDraft;
    PD.closeSimulationBuilder();
    if (id && id !== PD.state.personaId) PD.switchPersona(id);
  };
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && PD.isSimulationBuilderOpen()) PD.closeSimulationBuilder();
  });
})(window);
