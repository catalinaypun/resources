/* Pricing Desk — prototype version in the Salesforce bar (2026-10-26, same as Valu Cal). The working copy shows the
   build it's heading to: ISO week + day of the week (Monday .1 … Friday .5), e.g. "Version 2026-W44.1". The source
   keeps "dev" as the marker that PricingDesk/componentization/tools/build-standalone.py replaces with the delivered
   version, so this only runs while the text is still "dev". The link opens the release notes. */
(function () {
  var el = document.getElementById('proto-version');
  if (!el || el.textContent.trim() !== 'dev') return;
  var now = new Date();
  var d = new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate()));
  var day = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - day);
  var year = d.getUTCFullYear();
  var week = Math.ceil(((d - Date.UTC(year, 0, 1)) / 86400000 + 1) / 7);
  var label = year + '-W' + String(week).padStart(2, '0') + '.' + day;
  el.textContent = 'Version ' + label;
  el.title = 'Version ' + label + ' · ' + now.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) + ' (working copy). Release notes';
})();
