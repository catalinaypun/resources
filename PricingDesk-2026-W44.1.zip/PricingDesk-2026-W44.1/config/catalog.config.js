/* Pricing Desk sample catalog (brief 03) — sample data only, for the create-promotion form. Products stay in Salesforce;
   Pricing Desk only picks them to give them a price (requirements by section › Section 1).
   Names follow Valu Cal's sample data so the two prototypes tell the same story; there is no connection between them.
   listPrice = sample monthly list price per unit, by sale mode — used to show the monthly benefit per unit of a %.
   conditionGroups = the fields and sample values for "Who sees it", "Exclusions" and deal conditions (brief 03, batch 2). */
(function (global) {
  global.PD = global.PD || {};
  global.PD.CATALOG = {
    items: [
      { id: 'vehicle-tracking', name: 'Vehicle tracking', kind: 'Product category', listPrice: { OPEX: 25, CAPEX: 15 } },
      { id: 'vt-gps', name: 'Vehicle tracking: GPS tracker', kind: 'Product', listPrice: { OPEX: 22, CAPEX: 14 } },
      { id: 'video', name: 'Video', kind: 'Product category', listPrice: { OPEX: 38, CAPEX: 24 } },
      { id: 'video-road', name: 'Video: road-facing camera', kind: 'Product', listPrice: { OPEX: 32, CAPEX: 20 } },
      { id: 'video-dual', name: 'Video: dual camera', kind: 'Product', listPrice: { OPEX: 45, CAPEX: 28 } },
      { id: 'asset-trackers', name: 'Asset trackers', kind: 'Product category', listPrice: { OPEX: 18, CAPEX: 12 } },
      { id: 'at-powered', name: 'Asset tracker: powered', kind: 'Product', listPrice: { OPEX: 16, CAPEX: 10 } },
      { id: 'at-non-powered', name: 'Asset tracker: non-powered', kind: 'Product', listPrice: { OPEX: 12, CAPEX: 8 } },
    ],
    saleModes: ['OPEX', 'CAPEX'],
    installMethods: ['Any', 'VMI', 'CMI'],
    benefitMonths: [6, 12, 24, 36],
    // "Who sees it" / "Exclusions" fields (requirements by section › Section 2 › "Who sees it: conditions"), by what
    // they are about. Sample values; numbers are shown as ranges for the demo. dealAdjust = can raise or lower an
    // Account Discount program's maximum (Section 2 › Account Discount programs).
    conditionGroups: [
      { id: 'account', label: 'Account', fields: [
        { id: 'accounts-include', label: 'Specific accounts', values: ['Acme Logistics', 'Northwind Fleet', 'Contoso Transport', 'Fabrikam Freight', 'Globex Delivery'] },
        { id: 'accounts-exclude', label: 'Accounts to exclude', values: ['Acme Logistics', 'Northwind Fleet', 'Contoso Transport', 'Fabrikam Freight', 'Globex Delivery'] },
        { id: 'vtz-segment', label: 'VTZ Segment', values: ['VTZ SMB', 'VTZ Mid-Market', 'VTZ Enterprise'] },
        { id: 'segment', label: 'Segment', values: ['SMB', 'Mid-Market', 'Enterprise'] },
        { id: 'platform', label: 'Platform', values: ['Reveal', 'Fleetmatics', 'Networkfleet'] },
        { id: 'brand', label: 'Brands', values: ['Verizon Connect', 'Fleetmatics', 'Telogis'] },
        { id: 'family', label: 'Family', values: ['Fleet', 'Field service', 'Asset tracking'] },
        { id: 'account-type', label: 'Account Type', values: ['Customer', 'Partner', 'Reseller'] },
        { id: 'industry', label: 'Industry', values: ['Construction', 'Landscaping', 'Transportation', 'Utilities', 'Field services'] },
        { id: 'lead-source', label: 'Lead Source', values: ['VCW', 'Website', 'Partner referral', 'Event'] },
        { id: 'region', label: 'Region', values: ['North', 'South', 'East', 'West'] },
        { id: 'customer-group', label: 'Customer group', values: ['Strategic', 'Key accounts', 'Standard'] },
        { id: 'sales-team', label: 'Owning sales team', values: ['SMB inside sales', 'Mid-Market field', 'Enterprise direct', 'Channel partners'] },
        { id: 'account-sale-type', label: 'Account sale type', values: ['OPEX', 'CAPEX', 'MIXED'] },
        { id: 'product-type', label: 'Product type', values: ['Bundle', 'À la carte', 'Mixed'] },
        { id: 'agreement-type', label: 'Agreement type', values: ['Standard MSA', 'Custom MSA'] },
        { id: 'legacy-origin', label: 'Legacy origin', values: ['Fixed', 'Flex'] },
        { id: 'customer-status', label: 'New or existing customer', values: ['New', 'Existing'] },
      ] },
      { id: 'deal', label: 'Deal / order', fields: [
        { id: 'transaction', label: 'Transaction type', dealAdjust: true, values: ['Initial Sale', 'Expansion', 'Feature Upsell', 'Downgrade', 'Swap', 'Renewal', 'Rewrap', 'Reactivation'] },
        { id: 'term', label: 'Term', dealAdjust: true, values: ['12 months', '24 months', '36 months', '48 months', '60 months'] },
        { id: 'tier', label: 'Tier', dealAdjust: true, values: ['1–9', '10–19', '20–49', '50–99', '100+'] },
        { id: 'weighted-qty', label: 'Weighted quantity', dealAdjust: true, values: ['Under 250', '250–999', '1,000 or more'] },
        { id: 'product', label: 'Product', values: ['Vehicle tracking: GPS tracker', 'Video: road-facing camera', 'Video: dual camera', 'Asset tracker: powered', 'Asset tracker: non-powered'] },
        { id: 'schedule-group', label: 'Schedule group', values: ['Vehicle tracking', 'Video', 'Asset tracking'] },
        { id: 'product-qty', label: 'Product quantity', values: ['1–9', '10–49', '50 or more'] },
        { id: 'product-mix', label: 'Product mix', dealAdjust: true, values: ['Vehicle tracking only', 'Video included', 'Asset tracking included'] },
        { id: 'sale-mode', label: 'Sale mode', values: ['OPEX', 'CAPEX'] },
        { id: 'install-method', label: 'Installation method', values: ['VMI', 'CMI'] },
        { id: 'seasonal', label: 'Seasonal or not', values: ['Seasonal', 'Not seasonal'] },
        { id: 'order-total', label: 'Order total at list price', values: ['Under $10,000', '$10,000–$50,000', 'Over $50,000'] },
      ] },
      { id: 'user', label: 'User', fields: [
        { id: 'team', label: 'Team', values: ['SMB inside sales', 'Mid-Market field', 'Enterprise direct', 'Channel partners'] },
        { id: 'role', label: 'Role', values: ['Sales rep', 'Senior sales rep', 'Sales manager'] },
        { id: 'users-grant', label: 'Specific users (grant)', values: ['Jordan Kim', 'Riley Park', 'Casey Nguyen', 'Drew Patel'] },
        { id: 'users-deny', label: 'Specific users (deny)', values: ['Jordan Kim', 'Riley Park', 'Casey Nguyen', 'Drew Patel'] },
      ] },
    ],
  };
})(window);
