/* Pricing Desk approvals (brief 04) — sample data only. Levels of the generic approval chain (requirements by section ›
   Section 3) and approval requests sent from Valu Cal (pricing on a proposal). Names follow Valu Cal's sample data;
   there is no connection between the prototypes. New-promotion requests are not here: they are built from the
   promotions in Pending approval (js/pd-approvals.js).
   A request: source, type, record, submitter, submittedOn, triggers (plain words: value and limit — TR-08), neededLevel
   (the highest level its triggers need), startLevel (first level asked; the chain asks every level up to the needed
   one, in order — RT-03), approvals (levels already approved), status pending | approved | rejected, snapshot
   (label / value pairs of the proposal at submission), reason, justification, attachment, decidedBy / decidedOn /
   comment once decided. PENDING (business): limits and level values are examples. */
(function (global) {
  global.PD = global.PD || {};
  global.PD.APPROVAL_LEVELS = [
    { level: 1, role: 'Associate Director', name: 'Alex Torres' },
    { level: 2, role: 'Director', name: 'Morgan Chen' },
    { level: 3, role: 'Pricing & Finance', name: 'Taylor Wright' },
  ];
  global.PD.APPROVAL_REQUESTS = [
    {
      id: 'vc-q1057', source: 'Valu Cal', type: 'pricing', record: 'Northwind Fleet — Proposal Q-1057',
      submitter: 'Riley Park', submittedOn: '2026-10-25', startLevel: 1, neededLevel: 1, approvals: [], status: 'pending',
      triggers: ['Custom Promotion with a value: $4.00 off per unit / month for 12 months on Video: dual camera (every custom promotion with a value needs approval).'],
      snapshot: [['Account', 'Northwind Fleet'], ['Proposal', 'Q-1057, Option 2'], ['Transaction', 'Initial Sale'], ['Term', '36 months'],
        ['Units', '40 (tier 20–49)'], ['MRR at list', '$1,800.00'], ['Requested', 'Custom Promotion: $4.00 off per unit / month, 12 months'], ['MRR after discounts', '$1,640.00']],
      reason: 'Competitive pressure', justification: 'Competitor offered a lower video price; this matches it for the first year.', attachment: 'competitor-quote.pdf',
    },
    {
      id: 'vc-q1042', source: 'Valu Cal', type: 'pricing', record: 'Acme Logistics — Proposal Q-1042',
      submitter: 'Jordan Kim', submittedOn: '2026-10-22', startLevel: 1, neededLevel: 2, status: 'pending',
      approvals: [{ level: 1, by: 'Alex Torres', on: '2026-10-23' }],
      triggers: ['Discretionary discount 8% is above the 6% the Associate Director can approve (36 months, tier 50–99).'],
      snapshot: [['Account', 'Acme Logistics'], ['Proposal', 'Q-1042, Option 1'], ['Transaction', 'Renewal'], ['Term', '36 months'],
        ['Units', '85 (tier 50–99)'], ['MRR at list', '$3,825.00'], ['Requested', 'Discretionary discount 8%'], ['MRR after discounts', '$3,377.48']],
      reason: 'Renewal at risk', justification: 'Customer is evaluating two vendors; 8% keeps them on the platform for another term.', attachment: 'renewal-notes.pdf',
    },
    {
      id: 'vc-q1063', source: 'Valu Cal', type: 'pricing', record: 'Contoso Transport — Proposal Q-1063',
      submitter: 'Jordan Kim', submittedOn: '2026-10-20', startLevel: 1, neededLevel: 3, status: 'pending',
      approvals: [{ level: 1, by: 'Alex Torres', on: '2026-10-21' }, { level: 2, by: 'Morgan Chen', on: '2026-10-23' }],
      triggers: ['Discretionary discount 12% is above the 10% the Director can approve (60 months, tier 100+).'],
      snapshot: [['Account', 'Contoso Transport'], ['Proposal', 'Q-1063, Option 1'], ['Transaction', 'Initial Sale'], ['Term', '60 months'],
        ['Units', '240 (tier 100+)'], ['MRR at list', '$9,600.00'], ['Requested', 'Discretionary discount 12%'], ['MRR after discounts', '$7,603.20']],
      reason: 'Strategic account', justification: 'Largest fleet in the region this quarter; the 60-month term protects the margin.', attachment: '',
    },
    {
      id: 'vc-q0998', source: 'Valu Cal', type: 'pricing', record: 'Fabrikam Freight — Proposal Q-0998',
      submitter: 'Casey Nguyen', submittedOn: '2026-10-16', startLevel: 1, neededLevel: 3, status: 'approved',
      approvals: [{ level: 1, by: 'Alex Torres', on: '2026-10-16' }, { level: 2, by: 'Morgan Chen', on: '2026-10-17' }, { level: 3, by: 'Taylor Wright', on: '2026-10-19' }],
      decidedBy: 'Taylor Wright', decidedOn: '2026-10-19',
      triggers: ['Discretionary discount 11% is above the 10% the Director can approve (48 months, tier 100+).'],
      snapshot: [['Account', 'Fabrikam Freight'], ['Proposal', 'Q-0998, Option 1'], ['Transaction', 'Rewrap'], ['Term', '48 months'],
        ['Units', '130 (tier 100+)'], ['MRR at list', '$5,200.00'], ['Requested', 'Discretionary discount 11%'], ['MRR after discounts', '$4,166.24']],
      reason: 'Volume', justification: 'Adds 60 units in the rewrap.', attachment: '',
    },
    {
      id: 'vc-q1011', source: 'Valu Cal', type: 'pricing', record: 'Globex Delivery — Proposal Q-1011',
      submitter: 'Drew Patel', submittedOn: '2026-10-14', startLevel: 1, neededLevel: 3, status: 'rejected',
      approvals: [{ level: 1, by: 'Alex Torres', on: '2026-10-14' }, { level: 2, by: 'Morgan Chen', on: '2026-10-15' }],
      decidedBy: 'Taylor Wright', decidedOn: '2026-10-16', comment: 'Below the margin goal for SMB; resubmit at 10% or with a longer term.',
      triggers: ['Discretionary discount 14% is above the 10% the Director can approve (24 months, tier 10–19).'],
      snapshot: [['Account', 'Globex Delivery'], ['Proposal', 'Q-1011, Option 1'], ['Transaction', 'Initial Sale'], ['Term', '24 months'],
        ['Units', '15 (tier 10–19)'], ['MRR at list', '$600.00'], ['Requested', 'Discretionary discount 14%'], ['MRR after discounts', '$464.40']],
      reason: 'Competitive pressure', justification: 'Customer asked for a price match.', attachment: 'price-match.pdf',
    },
  ];
})(window);
