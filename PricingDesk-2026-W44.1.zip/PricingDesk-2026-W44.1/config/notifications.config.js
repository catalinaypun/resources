/* Pricing Desk notifications (header bell) — sample data only, per persona.
   Alicia (Promotion Manager) hears when her promotions are approved (Catalina, 2026-10-26).
   kind: approved | rejected; promotionId opens that promotion in Promotions & Discounts; date ISO; unread at start.
   PENDING (brief 04): approving / rejecting a request in the approver queue adds a notification for its owner;
   approvers get "New approval request" notifications. Other personas have none yet. */
(function (global) {
  global.PD = global.PD || {};
  global.PD.NOTIFICATIONS = {
    alicia: [
      { id: 'n-media-20-v2', kind: 'approved', promotionId: 'media-20', title: 'Media Promo was approved',
        message: 'Taylor Wright (Pricing & Finance) approved version 2.', date: '2026-10-24', unread: true },
      { id: 'n-adp-ent-v2', kind: 'approved', promotionId: 'adp-ent', title: 'Enterprise was approved',
        message: 'Taylor Wright (Pricing & Finance) approved version 2.', date: '2026-10-19', unread: true },
      { id: 'n-adp-web-v2', kind: 'approved', promotionId: 'adp-web', title: 'Website Lead Source was approved',
        message: 'Taylor Wright (Pricing & Finance) approved version 2.', date: '2026-10-02', unread: false },
    ],
  };
})(window);
