/* Pricing Desk promotions (brief 02) — sample data only. Names and percentages follow Valu Cal's sample data so the two
   prototypes tell the same story in a demo; there is no connection between the products.
   Dates are ISO (YYYY-MM-DD); offerEnd null = no end date. Today in the demo: Oct 2026.
   level 'account' = Account Discount (Discretionary) program; level 'order' = Order Discount promotion.
   status: draft | pending | active | expired | retired. Every promotion has at least one condition except Media Promo
   (the "All accounts, all reps" example).
   Order Discount (batch 2, Leo's review 2026-10-23): definition.appliesTo = one row per product category, product or
   schedule group, each with its own sale mode, installation method, type and value; listPrice is the sample monthly
   list price used to compute the monthly benefit per unit of a percentage. limits.min / limits.max; combinableWith =
   promotion ids; exclusions = the ones set by condition (public schedules and seasonal lines are always excluded).
   Account Discount program: definition.percent, definition.transactions (when it's offered), approval (max % without
   approval, bands by role, deal conditions, priority = order in the rep's list when several apply). */
(function (global) {
  global.PD = global.PD || {};
  var MSA_TRANSACTIONS = ['Initial Sale', 'Renewal', 'Rewrap', 'Reactivation'];
  // PENDING (business): band values are examples; Pricing & Finance sets them.
  var STANDARD_BANDS = [
    { upTo: 6, role: 'Associate Director' },
    { upTo: 10, role: 'Director' },
    { upTo: null, role: 'Pricing & Finance' },
  ];
  global.PD.STANDARD_BANDS = STANDARD_BANDS; // shown read-only in the create form (brief 03)
  global.PD.PROMOTIONS = [
    {
      id: 'adp-vcw', level: 'account', name: 'VCW Lead Source', code: 'ADP-VCW', status: 'active', version: 3, owner: 'Alicia Milton',
      offerStart: '2026-01-01', offerEnd: null,
      definition: { percent: 1, transactions: MSA_TRANSACTIONS, description: 'For accounts that came through the VCW lead source.' },
      conditions: { account: ['Lead source: VCW'], deal: [], user: [] },
      approval: { maxWithoutApproval: 1, bands: STANDARD_BANDS, dealConditions: [], priority: 4 },
    },
    {
      id: 'adp-web', level: 'account', name: 'Website Lead Source', code: 'ADP-WEB', status: 'active', version: 2, owner: 'Alicia Milton',
      offerStart: '2026-03-01', offerEnd: null,
      definition: { percent: 2, transactions: MSA_TRANSACTIONS, description: 'For accounts that came through the website.' },
      conditions: { account: ['Lead source: Website'], deal: [], user: [] },
      approval: { maxWithoutApproval: 2, bands: STANDARD_BANDS, dealConditions: [], priority: 3 },
    },
    {
      id: 'adp-dec', level: 'account', name: 'December Special', code: 'ADP-DEC', status: 'pending', version: 1, owner: 'Alicia Milton',
      offerStart: '2026-12-01', offerEnd: '2026-12-31', submittedOn: '2026-10-21', waitingFor: 'Pricing & Finance',
      definition: { percent: 3, transactions: ['Initial Sale', 'Renewal'], description: 'Year-end push for small and mid-size fleets.' },
      conditions: { account: ['Segment: SMB, Mid-Market'], deal: ['Term: 36 months or more'], user: [] },
      approval: { maxWithoutApproval: 3, bands: STANDARD_BANDS, dealConditions: ['Term of 60 months: maximum +1%'], priority: 1 },
    },
    {
      id: 'adp-ent', level: 'account', name: 'Enterprise', code: 'ADP-ENT', status: 'active', version: 2, owner: 'Alicia Milton',
      offerStart: '2026-07-01', offerEnd: '2027-06-30',
      definition: { percent: 4, transactions: MSA_TRANSACTIONS, description: 'Standard program for large fleets.' },
      conditions: { account: ['Segment: Enterprise'], deal: ['Units: 250 or more'], user: ['Team: Enterprise direct'] },
      approval: { maxWithoutApproval: 4, bands: STANDARD_BANDS, dealConditions: ['Units over 1,000: maximum +2%', 'Pilot accounts: maximum -1%'], priority: 2 },
    },
    {
      id: 'adp-q1r', level: 'account', name: 'Q1 Retention', code: 'ADP-Q1R', status: 'draft', version: 1, owner: 'Alicia Milton',
      offerStart: '2027-01-01', offerEnd: '2027-03-31',
      definition: { percent: 2, transactions: ['Renewal', 'Rewrap'], description: 'Keeps accounts whose MSA term is about to end.' },
      conditions: { account: ['MSA term ends within 6 months'], deal: [], user: [] },
      approval: { maxWithoutApproval: 2, bands: STANDARD_BANDS, dealConditions: [], priority: 5 },
    },
    {
      id: 'media-20', level: 'order', name: 'Media Promo', code: 'MEDIA-20', status: 'active', version: 2, owner: 'Alicia Milton',
      offerStart: '2026-09-01', offerEnd: '2026-12-31',
      definition: {
        description: '20% off camera-core solutions.',
        appliesTo: [
          { target: 'Video: road-facing camera', kind: 'Product', saleMode: 'OPEX', installMethod: 'Any', type: 'percentage', value: 20, listPrice: 32 },
          { target: 'Video: dual camera', kind: 'Product', saleMode: 'OPEX', installMethod: 'Any', type: 'percentage', value: 20, listPrice: 45 },
        ],
      },
      benefitMonths: 12,
      conditions: { account: [], deal: [], user: [] },
      exclusions: [],
      limits: { min: { perOrder: null, perAccount: null, total: null, budget: null }, max: { perOrder: 100, perAccount: 250, total: null, budget: 50000 } },
      combinableWith: ['at-launch'],
    },
    {
      id: 'at-launch', level: 'order', name: 'Asset Tracker Launch', code: 'AT-LAUNCH', status: 'draft', version: 1, owner: 'Alicia Milton',
      offerStart: '2027-01-15', offerEnd: '2027-04-30',
      definition: {
        description: 'Launch offer for the asset tracker family.',
        appliesTo: [
          { target: 'Asset trackers', kind: 'Product category', saleMode: 'OPEX', installMethod: 'CMI', type: 'amount', value: 5, listPrice: 18 },
          { target: 'Asset trackers', kind: 'Product category', saleMode: 'CAPEX', installMethod: 'CMI', type: 'amount', value: 3, listPrice: 12 },
        ],
      },
      benefitMonths: 6,
      conditions: { account: ['Segment: SMB'], deal: ['Asset trackers: 10 or more'], user: [] },
      exclusions: ['Accounts on a pilot'],
      limits: { min: { perOrder: 10, perAccount: null, total: null, budget: null }, max: { perOrder: 50, perAccount: null, total: 2000, budget: null } },
      combinableWith: ['media-20'],
    },
    {
      id: 'summer-10', level: 'order', name: 'Summer Fleet', code: 'SUMMER-10', status: 'expired', version: 1, owner: 'Alicia Milton',
      offerStart: '2026-06-01', offerEnd: '2026-08-31',
      definition: {
        description: 'Summer offer on vehicle tracking.',
        appliesTo: [
          { target: 'Vehicle tracking', kind: 'Schedule group', saleMode: 'OPEX', installMethod: 'VMI', type: 'percentage', value: 10, listPrice: 25 },
        ],
      },
      benefitMonths: 12,
      conditions: { account: ['Industry: Construction, Landscaping'], deal: [], user: ['Region: South, West'] },
      exclusions: [],
      limits: { min: { perOrder: null, perAccount: null, total: null, budget: null }, max: { perOrder: null, perAccount: 150, total: null, budget: 20000 } },
      combinableWith: [],
    },
    {
      id: 'holiday-15', level: 'order', name: 'Holiday Video', code: 'HOLIDAY-15', status: 'retired', version: 2, owner: 'Alicia Milton',
      offerStart: '2025-11-15', offerEnd: '2026-01-15', retiredOn: '2025-12-20',
      definition: {
        description: 'Holiday offer on video solutions.',
        appliesTo: [
          { target: 'Video', kind: 'Product category', saleMode: 'OPEX', installMethod: 'Any', type: 'percentage', value: 15, listPrice: 38 },
        ],
      },
      benefitMonths: 12,
      conditions: { account: ['Segment: SMB, Mid-Market'], deal: [], user: [] },
      exclusions: [],
      limits: { min: { perOrder: null, perAccount: null, total: null, budget: null }, max: { perOrder: 40, perAccount: 120, total: 1500, budget: null } },
      combinableWith: [],
    },
  ];
})(window);
