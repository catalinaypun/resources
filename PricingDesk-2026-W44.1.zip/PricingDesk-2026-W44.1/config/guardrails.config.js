/* Pricing Desk — ranges set by Pricing & Finance (sample data). The promotion manager creates promotions and discounts
   within them (requirements by section › Section 3 › Configuration › "Ranges for promotions and discounts"; Leo,
   MSA Alignment 2026-10-23: "the promo manager can create whatever promos within the ranges that the pricing team
   set … you can never go more than 50% discount"). The create form shows them next to each field and won't save a
   value outside them. PENDING (brief): the Pricing & Finance screen to edit them; the values are examples. */
(function (global) {
  global.PD = global.PD || {};
  global.PD.GUARDRAILS = {
    setBy: 'Pricing & Finance',
    order: {
      percent: { min: 1, max: 50 },          // % off per unit / month
      amount: { min: 0.5, max: 20 },         // $ off per unit / month
      benefitMonths: [6, 12, 24],            // durations that can be offered
    },
    account: {
      percent: { min: 0.5, max: 15 },        // % on the MSA term
      maxWithoutApproval: { min: 0, max: 5 },
    },
  };
})(window);
