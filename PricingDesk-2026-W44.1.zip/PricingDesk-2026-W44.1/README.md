# Pricing Desk - prototype 2026-W44.1 (standalone, built Oct 26, 2026)

Open `index.html` in a browser (an internet connection loads the icon font and the date picker).

| Folder | What it is |
|---|---|
| `design-system/pricing-desk-design-system.css` | The whole design system in one stylesheet: tokens, typography, base components and the components shared with Valu Cal. `fonts/` and `icons/` hold only what it uses. |
| `js/` | Shared components (`vc-*.js`) and Pricing Desk logic (`pd-*.js`). |
| `config/` | Sample data: roles, pages, catalog, promotions, approval requests, Pricing & Finance ranges, notifications. |
| `img/` | Shared images. |

**Simulation Builder** (top right, Salesforce bar) switches the role: Promotion Manager (Alicia Milton) works in
Promotions & Discounts; the approvers (Alex Torres, Morgan Chen, Taylor Wright) in Approvals. Changes made in the demo
(new promotions, submissions) are kept while the browser tab is open.
