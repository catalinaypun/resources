# Valu Cal - unified prototype (standalone, 2026-10-15)

Open `index.html` in a browser. The app, styles, JavaScript, configuration and local images are bundled in this folder. An internet connection loads the Material Symbols icon font and date picker.

| Folder | What it is |
|---|---|
| `design-system/valucal-design-system.css` | The whole design system in one stylesheet: tokens, typography, base components and every Valu Cal component. `fonts/` and `icons/` hold only what it uses. |
| `js/` | Components (`vc-*.js`) and flow logic (`existing-accounts.js`, `flow-composer.js`, `unified-bootstrap.js`, `pilot-dashboard.js`). |
| `config/` | `transactions.config.js` - steps, modules and variables of every transaction (what the Transaction composer shows); scenario resolution. |
| `img/`, `app/` | Email / PDF images, logo, sample quote PDF, account-setup demos. |

Simulation Builder (top right) - **Scenario** tab: account and entry point; **Composer** tab: steps and modules per
transaction, live on the screen.
