# Pricing Desk — Requirements

> **Purpose:** Define the complete Promotions Management flow in Pricing Desk: summary management, promotion create/edit, child promotion pricing setup, and prototype-level validations/feedback.

---

## Context

- **Tool area:** Pricing Manager
- **Target user role:** Promotion Manager
- **Entry point:** Salesforce-embedded Pricing Desk module
- **Primary surfaces:**
	- Summary workspace (`index.html`)
	- Promotion form workspace (`create-new.html`) used for both Create and Edit

---

## User Stories

| ID | As a… | I want to… | So that… |
|---|---|---|---|
| US-01 | Promotion Manager | see a searchable and filterable promotions list | I can find promotions quickly without leaving the workspace |
| US-02 | Promotion Manager | review selected promotion details, eligibility and child pricing | I can validate structure and pricing before changing anything |
| US-03 | Promotion Manager | create a promotion from scratch or prefill from an existing promotion | I can accelerate authoring while keeping consistency |
| US-04 | Promotion Manager | edit an existing promotion using the same form as create | I can work in one consistent interaction model |
| US-05 | Promotion Manager | clone and delete promotions from the summary view | I can manage lifecycle operations from the same screen |
| US-06 | Promotion Manager | configure child promotions with products, tiers, and time-based discounts | I can model bundled commercial scenarios end-to-end |
| US-07 | Promotion Manager | get real-time validation and clear disable/enable behavior on dependent fields | I can avoid invalid configurations before save |
| US-08 | Promotion Manager | receive clear success feedback after create/update/delete | I can confirm what operation completed |

---

## Acceptance Criteria

### US-01 — Summary workspace (search/filter/list)
- **Given** I open Pricing Desk
- **When** data is available
- **Then** I see a left promotions list with name, date range and status badge, and a right detail area for the selected promotion.
- **And** the first visible promotion is selected by default.
- **And** I can search by promotion name.
- **And** search suggestions appear from 3+ typed characters and selecting a suggestion moves focus to that promotion.
- **And** status filters are available (`all`, `New`, `Developing`, `Submitted`, `Active`, `Expired`).
- **And** when status is `all`, expired promotions are hidden by default until user explicitly includes them.

### US-02 — Promotion detail and child pricing review
- **Given** a promotion is selected
- **When** I inspect the detail panel
- **Then** I see promotion header info (name, date range, status), eligibility strip values (country, platform, segment, cost center, lead source, MRR, tenure), and child promotion cards.
- **And** each child card shows child metadata (terms, free months, lock price, discount type, install) and product tier tables (`Qty`, `Price`).

### US-03 — Create promotion flow
- **Given** I start from Add Promotion
- **When** the create form opens
- **Then** I see a full-page form with tabs for `Promotion details` and `Child promotions & pricing`.
- **And** the required promotion fields (name, type, country, start date, end date) gate the primary action enablement.
- **And** I can prefill from an existing promotion using the `Prefill from existing…` control.
- **And** prefill asks confirmation when replacing touched user input.
- **And** prefill loads parent and child data (including child products/pricing structures).

### US-04 — Edit promotion flow (same form as create)
- **Given** I choose Edit from summary detail actions
- **When** edit opens
- **Then** the app opens the same `create-new.html` form in edit mode with all promotion data pre-populated.
- **And** page header context identifies the promotion being edited.
- **And** primary action label is `Save`.
- **And** save writes back to the same promotion id (update behavior, not create-new-id behavior).

### US-05 — Summary actions (clone/delete)
- **Given** a promotion is selected
- **When** I open actions menu
- **Then** I can trigger:
	- `Edit` (open form in edit mode)
	- `Clone` (open create form prefilled from selected promotion)
	- `Delete` (confirmation modal; removes promotion from session list)
- **And** successful operations show a toast message (`created`, `updated`, `deleted`).

### US-06 — Parent form field behavior and dependencies
- **Given** I interact with parent fields
- **Then** these behaviors apply:
	- `Record Type` is read-only and derived from `Promotion Type` (`Bundle` → `Bundle Offer`, `Standalone` → `Standalone Offer`, empty type → empty record type).
	- `ValueCal Promo Type` is disabled until `ValueCal Active` is checked.
	- Unchecking `ValueCal Active` resets `ValueCal Promo Type` to `--None--`.
	- `Owner` and `Currency` render as read-only fields.

### US-07 — MRR and tenure cross-field validation
- **Given** I fill range pairs (`Minimum MRR`/`Maximum MRR`, `Min Customer Tenure`/`Max Customer Tenure`)
- **When** both values of a pair exist and min is greater than max
- **Then** only the `min` field is marked with error style and helper text `Min must be <= max`.
- **And** if a pair becomes valid, or one side is emptied, error styling and helper text clear immediately.
- **And** while any pair is invalid, primary action is disabled and hint includes `valid MRR/Tenure ranges`.

### US-08 — Child promotions and pricing configuration
- **Given** I am in `Child promotions & pricing`
- **Then** I can add, duplicate, remove, collapse/expand, and rename child promotions.
- **And** each child supports:
	- Terms, install type, discount type, free months, lock price.
	- Applies-to filters (transaction type, subtype, industry).
	- Contract flexibility fields.
	- Product picker with compatibility constraints between core and feature products.
	- Tiered pricing input with computed `Final promo` value based on discount mode.
	- Warning/error affordances for below-floor or invalid pricing outcomes.
	- Optional time-based discount rules by product and month ranges.

### US-09 — Session persistence scope (prototype)
- **Given** I create or update a promotion
- **When** I return to summary during the same browser session
- **Then** the promotion appears via session-backed additions/upserts.
- **And** save operations pass through `PROMO_JUST_CREATED` payload handoff.

---

## States & Edge Cases

| State | Trigger | Expected UI behavior |
|---|---|---|
| default | Page opens with valid data | Two-panel summary layout is visible, one promotion is selected, and detail content is rendered |
| loading | Promotion data retrieval in progress | Loading treatment is visible and summary/detail workspace is hidden |
| validation-error | User attempts to save invalid required/range fields | Validation helper/error styles are shown and primary action stays disabled |
| system-error | Promotions retrieval fails | System error treatment is shown and main workspace is hidden |

---

## Open Questions

- [ ] Should `Delete` remain prototype-session only or be defined as persisted backend behavior?
- [ ] Which additional parent or child fields are required for `Save draft` versus `Submit`?
- [ ] Should list sorting (by status/date/name) be added beyond search and status filter?
