(function () {
  var PLATFORM_OPTIONS = ["Reveal", "Fleet", "Reveal Starter", "Reveal+", "Reveal Pro", "Reveal Now"];
  var SEGMENT_OPTIONS = [
    "Micro", "SMB", "Government", "Enterprise", "Strategic", "Intl MICRO", "Intl SMB", "Intl MAJORS",
    "Intl Enterprise", "Intl Strategic", "Intl Government", "Reveal in Stores", "Mid Market"
  ];
  var COST_CENTER_OPTIONS = ["VZT TG ENT", "VZT TG F", "VZT TG SMB", "West", "WORKAUS1", "WORKIRL1", "WORKUK1"];
  var LEAD_SOURCE_OPTIONS = ["Marketing Inbound", "Partner Referral", "Outbound Cold"];
  var TRANSACTION_OPTIONS = ["Existing Business", "Re-Sign Business", "Existing Business - Blended", "New Business"];
  var INDUSTRY_OPTIONS = [
    "Transportation", "Construction", "Utilities", "Oil & Gas", "Healthcare", "Public Sector", "Retail", "Telecom"
  ];
  // TODO(pricing): confirm the source of standard quantity bands and edit permissions
  // (pricing sheet-level? per product?) before wiring server-backed enforcement.
  var PRODUCT_CATALOG = {
    "VTU Only": { code: "P-10119", listPrice: 35.0, refFloor: 25.0 },
    "VTU + Forward Facing Camera": { code: "P-10120", listPrice: 65.0, refFloor: 45.0 },
    "VTU + Dual Camera": { code: "P-10121", listPrice: 75.0, refFloor: 55.0 },
    "Powered Asset": { code: "P-10122", listPrice: 39.0, refFloor: 30.0 },
    "Non-Powered Asset": { code: "P-10123", listPrice: 19.0, refFloor: 15.0 },
    "Vehicle Tracking Sub": { code: "P-10119", listPrice: 35.0, refFloor: 25.0 },
    "Asset Tracking": { code: "P-10124", listPrice: 39.0, refFloor: 30.0 },
    "Road Facing AI Dashcam": { code: "P-10125", listPrice: 28.0, refFloor: 22.0 },
    "Dual Channel AI Dashcam": { code: "P-10126", listPrice: 42.0, refFloor: 32.0 },
    "EVC Base": { code: "P-10127", listPrice: 24.0, refFloor: 18.0 },
    "EVC Premium": { code: "P-10128", listPrice: 34.0, refFloor: 26.0 },
    "Pro Installation": { code: "P-10129", listPrice: 16.0, refFloor: 12.0 },
    "Driver ID Keyfob": { code: "P-10130", listPrice: 10.0, refFloor: 7.0 },
    "NPAT": { code: "P-10131", listPrice: 31.0, refFloor: 25.0 },
    "VTU": { code: "P-10132", listPrice: 35.0, refFloor: 24.0 }
  };

  function tiers(basePrice) {
    return [
      { minQty: 1, maxQty: 5, price: basePrice },
      { minQty: 6, maxQty: 19, price: +(basePrice - 2).toFixed(2) },
      { minQty: 20, maxQty: 49, price: +(basePrice - 3.5).toFixed(2) }
    ];
  }

  function child(id, name, terms, installType, deactivated, priceA, priceB) {
    return {
      id: id,
      name: name,
      terms: terms,
      freeMonthsRange: "1-5",
      lockPrice: true,
      discountType: "Percentage",
      installType: installType,
      transactionType: ["Existing Business", "New Business"],
      industry: ["Transportation", "Construction"],
      subType: "Expansion",
      deactivated: deactivated,
      products: [
        { productName: "NPAT", refFloor: priceA + 4, tiers: tiers(priceA) },
        { productName: "VTU", refFloor: priceB + 4, tiers: tiers(priceB) }
      ],
      pricingMatrix: []
    };
  }

  var PROMOTIONS = [
    {
      id: "PROMO-1001",
      name: "Flex Asset Promo - NEW: $50 BIC 100-199 UNITS",
      status: "Active",
      deactivated: false,
      startDate: "2025-12-01",
      endDate: "2026-06-30",
      extensionDate: "2026-07-31",
      submissionDate: "2025-11-15",
      owner: "Current User",
      manager: "Alicia Stone",
      description: "Q4 launch promo for mixed asset bundles and retention-ready discounts.",
      highlight: "$50 BIC for high-volume fleet installs",
      type: "Bundle",
      recordType: "Bundle Offer",
      country: "USA",
      platform: ["Fleet", "Reveal+"],
      customerSegment: ["SMB", "Enterprise", "Mid Market"],
      costCenter: ["VZT TG ENT", "West"],
      leadSource: ["Marketing Inbound"],
      pricebook: "North America Commercial Pricebook",
      currency: "USD",
      promotionLanguage: "English",
      vbgVzwLead: true,
      adApprovalRequired: false,
      minMRR: 250,
      maxMRR: 12000,
      minTenure: 0,
      maxTenure: 60,
      contractFlexibility: true,
      purchaseType: "All-In Subscription Plan",
      pricingSheet: "FS-Q4-Enterprise-Primary",
      levelUpPricing: true,
      valueCalActive: true,
      valueCalPromoType: "Retention Bundle",
      children: [
        child("VZBUND12234", "FREE 36 MONTHS", 36, "CMI", false, 23, 22.5),
        child("VZBUND12235", "FREE 48 MONTHS", 48, "VCMI", false, 24, 23)
      ]
    },
    {
      id: "PROMO-1002",
      name: "Reveal Starter Expansion Campaign - Government Lite 2026",
      status: "Developing",
      deactivated: false,
      startDate: "2026-01-10",
      endDate: "2026-09-30",
      extensionDate: "",
      submissionDate: "",
      owner: "Current User",
      manager: "Alicia Stone",
      description: "Pipeline campaign for government and public sector starter offers.",
      highlight: "Seasonal discount for public fleets",
      type: "Standalone",
      recordType: "Targeted Offer",
      country: "CAN",
      platform: ["Reveal Starter", "Reveal"],
      customerSegment: ["Government", "Intl Government"],
      costCenter: [],
      leadSource: ["Partner Referral"],
      pricebook: "Canada Public Sector Pricebook",
      currency: "USD",
      promotionLanguage: "English/French",
      vbgVzwLead: false,
      adApprovalRequired: true,
      minMRR: 100,
      maxMRR: 8000,
      minTenure: 0,
      maxTenure: 36,
      contractFlexibility: false,
      purchaseType: "Equip Purchase w/no Commit",
      pricingSheet: "RS-GOV-2026",
      levelUpPricing: false,
      valueCalActive: false,
      valueCalPromoType: "",
      children: [
        child("VZBUND22010", "GOV 24M", 24, "CMI", false, 21.5, 21)
      ]
    },
    {
      id: "PROMO-1003",
      name: "Fleet Growth Bundle — Enterprise Strategic International",
      status: "Submitted",
      deactivated: false,
      startDate: "2026-02-01",
      endDate: "2026-12-31",
      extensionDate: "",
      submissionDate: "2026-01-15",
      owner: "Current User",
      manager: "Daniel Reeve",
      description: "Cross-market enterprise growth offer submitted for legal and finance review.",
      highlight: "Strategic accounts acceleration",
      type: "Bundle",
      recordType: "Growth Offer",
      country: "MEX",
      platform: ["Fleet", "Reveal Pro"],
      customerSegment: ["Strategic", "Intl Strategic", "Intl Enterprise"],
      costCenter: ["WORKUK1", "WORKIRL1"],
      leadSource: [],
      pricebook: "LATAM Enterprise Pricebook",
      currency: "USD",
      promotionLanguage: "Spanish",
      vbgVzwLead: true,
      adApprovalRequired: true,
      minMRR: 500,
      maxMRR: 20000,
      minTenure: 6,
      maxTenure: 72,
      contractFlexibility: true,
      purchaseType: "All-In Subscription Plan",
      pricingSheet: "FG-INTL-STRAT-2026",
      levelUpPricing: true,
      valueCalActive: true,
      valueCalPromoType: "Expansion",
      children: [
        child("VZBUND33001", "STRAT 36M", 36, "VCMI", false, 27, 26.5),
        child("VZBUND33002", "STRAT 48M", 48, "CMI", true, 26.5, 26),
        child("VZBUND33003", "STRAT 24M", 24, "CMI", false, 28, 27)
      ]
    },
    {
      id: "PROMO-1004",
      name: "Asset Tracking Re-Engagement Bundle — Mid Market Q3",
      status: "Active",
      deactivated: false,
      startDate: "2025-09-01",
      endDate: "2026-03-31",
      extensionDate: "2026-05-31",
      submissionDate: "2025-08-11",
      owner: "Current User",
      manager: "Maya Brooks",
      description: "Re-engagement offer for dormant mid market accounts with blended transactions.",
      highlight: "Win-back discount with lock price",
      type: "Bundle",
      recordType: "Reactivation Offer",
      country: "USA",
      platform: ["Reveal", "Reveal+", "Reveal Pro"],
      customerSegment: ["Mid Market", "SMB"],
      costCenter: ["VZT TG SMB"],
      leadSource: ["Outbound Cold"],
      pricebook: "US Mid Market Pricebook",
      currency: "USD",
      promotionLanguage: "English",
      vbgVzwLead: false,
      adApprovalRequired: false,
      minMRR: 150,
      maxMRR: 9000,
      minTenure: 3,
      maxTenure: 48,
      contractFlexibility: true,
      purchaseType: "Equip Purchase w/no Commit",
      pricingSheet: "AT-MM-WINBACK",
      levelUpPricing: true,
      valueCalActive: false,
      valueCalPromoType: "",
      children: [
        child("VZBUND44001", "WINBACK 36M", 36, "CMI", false, 22, 21.5),
        child("VZBUND44002", "WINBACK 24M", 24, "VCMI", false, 23, 22)
      ]
    },
    {
      id: "PROMO-1005",
      name: "Legacy Fleet Compliance Offer — Sunset",
      status: "Expired",
      deactivated: true,
      startDate: "2024-01-01",
      endDate: "2024-12-31",
      extensionDate: "",
      submissionDate: "2023-12-15",
      owner: "Current User",
      manager: "Maya Brooks",
      description: "Legacy compliance promotion retained only for audit reference.",
      highlight: "Historical promotion",
      type: "Standalone",
      recordType: "Legacy",
      country: "USA",
      platform: ["Fleet"],
      customerSegment: ["Enterprise"],
      costCenter: ["VZT TG F"],
      leadSource: ["Marketing Inbound"],
      pricebook: "US Legacy Pricebook",
      currency: "USD",
      promotionLanguage: "English",
      vbgVzwLead: false,
      adApprovalRequired: false,
      minMRR: 0,
      maxMRR: 0,
      minTenure: 0,
      maxTenure: 0,
      contractFlexibility: false,
      purchaseType: "Equip Purchase w/no Commit",
      pricingSheet: "LEGACY-COMP",
      levelUpPricing: false,
      valueCalActive: false,
      valueCalPromoType: "",
      children: [
        child("VZBUND55001", "LEGACY 12M", 12, "CMI", true, 20, 19.5)
      ]
    },
    {
      id: "PROMO-1006",
      name: "New Business Reveal Now Offer — SMB Rapid Launch",
      status: "New",
      deactivated: false,
      startDate: "2026-04-15",
      endDate: "2026-11-30",
      extensionDate: "",
      submissionDate: "",
      owner: "Current User",
      manager: "Daniel Reeve",
      description: "Early-stage promo draft for Reveal Now accelerated onboarding.",
      highlight: "Fast start package",
      type: "Standalone",
      recordType: "Launch Offer",
      country: "CAN",
      platform: ["Reveal Now"],
      customerSegment: ["Micro", "SMB", "Intl SMB"],
      costCenter: [],
      leadSource: [],
      pricebook: "CAN SMB Launch Pricebook",
      currency: "USD",
      promotionLanguage: "English",
      vbgVzwLead: true,
      adApprovalRequired: false,
      minMRR: 75,
      maxMRR: 6000,
      minTenure: 0,
      maxTenure: 24,
      contractFlexibility: false,
      purchaseType: "All-In Subscription Plan",
      pricingSheet: "RN-SMB-LAUNCH",
      levelUpPricing: false,
      valueCalActive: true,
      valueCalPromoType: "Starter",
      children: [
        child("VZBUND66001", "SMB 24M", 24, "CMI", false, 24.5, 24)
      ]
    }
  ];

  function promo(id, name, status, startDate, endDate, country, platforms, segments, minMRR, maxMRR, childrenList) {
    return {
      id: id,
      name: name,
      status: status,
      deactivated: false,
      startDate: startDate,
      endDate: endDate,
      extensionDate: "",
      submissionDate: "",
      owner: "Current User",
      manager: "Alicia Stone",
      description: "Generated promotion for prototype list coverage.",
      highlight: "Prototype seeded data",
      type: "Bundle",
      recordType: "Growth Offer",
      country: country,
      platform: platforms,
      customerSegment: segments,
      costCenter: ["VZT TG ENT"],
      leadSource: ["Marketing Inbound"],
      pricebook: "Prototype Pricebook",
      currency: "USD",
      promotionLanguage: "English",
      vbgVzwLead: true,
      adApprovalRequired: false,
      minMRR: minMRR,
      maxMRR: maxMRR,
      minTenure: 0,
      maxTenure: 60,
      contractFlexibility: true,
      purchaseType: "All-In Subscription Plan",
      pricingSheet: "AUTO-SEED",
      levelUpPricing: true,
      valueCalActive: true,
      valueCalPromoType: "Expansion",
      children: childrenList
    };
  }

  PROMOTIONS = PROMOTIONS.concat([
    promo("PROMO-1007", "Q2 Expansion Sprint — Fleet + Reveal Pro", "Developing", "2026-05-01", "2026-12-15", "USA", ["Fleet", "Reveal Pro"], ["SMB", "Mid Market"], 200, 9500, [
      child("VZBUND77001", "EXP 24M", 24, "CMI", false, 23.5, 23),
      child("VZBUND77002", "EXP 36M", 36, "VCMI", false, 22.5, 22)
    ]),
    promo("PROMO-1008", "Public Sector Summer Push — Reveal Starter", "Submitted", "2026-06-01", "2026-10-31", "USA", ["Reveal Starter"], ["Government"], 100, 7000, [
      child("VZBUND88001", "GOV 18M", 18, "CMI", false, 21.5, 21)
    ]),
    promo("PROMO-1009", "Strategic Winback Initiative — International", "Active", "2026-03-01", "2026-12-31", "MEX", ["Fleet", "Reveal+"], ["Strategic", "Intl Strategic"], 600, 25000, [
      child("VZBUND99001", "STRAT 36M", 36, "VCMI", false, 28, 27.5),
      child("VZBUND99002", "STRAT 48M", 48, "VCMI", false, 27, 26.5)
    ]),
    promo("PROMO-1010", "SMB Jumpstart Bundle — Reveal + Fleet", "New", "2026-07-01", "2026-12-20", "CAN", ["Reveal", "Fleet"], ["Micro", "SMB"], 75, 5500, [
      child("VZBUND10101", "SMB 12M", 12, "CMI", false, 23, 22.5)
    ]),
    promo("PROMO-1011", "Enterprise Contract Booster — Reveal Pro", "Developing", "2026-08-01", "2027-01-31", "USA", ["Reveal Pro"], ["Enterprise", "Strategic"], 800, 30000, [
      child("VZBUND11101", "ENT 36M", 36, "VCMI", false, 29, 28.5)
    ]),
    promo("PROMO-1012", "Cross-Sell Momentum Offer — Reveal Now", "Submitted", "2026-05-15", "2026-11-15", "USA", ["Reveal Now", "Reveal+"], ["SMB", "Mid Market"], 180, 10000, [
      child("VZBUND12101", "MOMENTUM 24M", 24, "CMI", false, 24, 23.5),
      child("VZBUND12102", "MOMENTUM 36M", 36, "CMI", false, 23, 22.5)
    ]),
    promo("PROMO-1013", "Reveal+ Retention Accelerator — Mid Market", "Active", "2026-01-20", "2026-10-20", "USA", ["Reveal+"], ["Mid Market", "SMB"], 150, 11000, [
      child("VZBUND13101", "RET 24M", 24, "VCMI", false, 22.5, 22)
    ]),
    promo("PROMO-1014", "International Starter Drive — Fleet Essentials", "Developing", "2026-09-01", "2027-03-31", "MEX", ["Fleet"], ["Intl SMB", "Intl MICRO"], 60, 4500, [
      child("VZBUND14101", "INTL 18M", 18, "CMI", false, 21, 20.5)
    ]),
    promo("PROMO-1015", "Year-End Volume Builder — Enterprise Fleet", "Submitted", "2026-10-01", "2026-12-31", "USA", ["Fleet", "Reveal Pro"], ["Enterprise", "Strategic"], 900, 32000, [
      child("VZBUND15101", "VOL 36M", 36, "VCMI", false, 30, 29.5),
      child("VZBUND15102", "VOL 48M", 48, "VCMI", false, 29, 28.5)
    ]),
    promo("PROMO-1016", "Renewal Priority Track — Reveal Pro +", "Active", "2026-02-15", "2026-12-15", "CAN", ["Reveal Pro", "Reveal+"], ["Enterprise", "Mid Market"], 300, 14000, [
      child("VZBUND16101", "RENEW 24M", 24, "CMI", false, 25, 24.5)
    ])
  ]);

  var PRICING_TEMPLATES = [
    {
      id: "TPL-100",
      name: "Standard SMB Base Template",
      discountType: "Override Price",
      tiers: [
        { minQty: 1, maxQty: 5, value: 22.5 },
        { minQty: 6, maxQty: 19, value: 20.5 },
        { minQty: 20, maxQty: 49, value: 19.5 }
      ]
    },
    {
      id: "TPL-101",
      name: "Enterprise Volume Template",
      discountType: "% Off",
      tiers: [
        { minQty: 1, maxQty: 25, value: 8 },
        { minQty: 26, maxQty: 100, value: 12 }
      ]
    }
  ];

  window.APP_OPTIONS = {
    platform: PLATFORM_OPTIONS,
    customerSegment: SEGMENT_OPTIONS,
    costCenter: COST_CENTER_OPTIONS,
    leadSource: LEAD_SOURCE_OPTIONS,
    transactionType: TRANSACTION_OPTIONS,
    industry: INDUSTRY_OPTIONS,
    countries: ["USA", "CAN", "MEX"],
    types: ["Bundle", "Standalone"],
    purchaseType: ["--None--", "Equip Purchase w/no Commit", "All-In Subscription Plan"],
    valueCalPromoType: ["--None--", "Retention Bundle", "Expansion", "Starter", "Seasonal"]
  };
  window.PROMOTIONS = JSON.parse(JSON.stringify(PROMOTIONS));
  window.PRICING_TEMPLATES = JSON.parse(JSON.stringify(PRICING_TEMPLATES));
  window.PRODUCT_CATALOG = JSON.parse(JSON.stringify(PRODUCT_CATALOG));
  window.PROMOTIONS_SEED = window.PROMOTIONS;
  window.PRICING_TEMPLATES_SEED = window.PRICING_TEMPLATES;
}());
