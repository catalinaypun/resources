# Changelog - Valu Cal MVP

All notable design changes to this flow are documented here.

---

## [2026-07-03]

### Added
- Initial ecosystem flow for Valu Cal MVP linking to the imported valucal_mvp.html screen.
