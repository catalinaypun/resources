# MSA en la versión de producción (v1) — Acciones pendientes

**Archivos que toca este documento:** `app/demos/valucal_mvp_production.html` (punto 1) y `app/demos/account-setup.html` (puntos 2 y 3).

Este documento se limpió el 2026-08-31: se verificó línea por línea contra el código real cuáles puntos del plan original ya estaban implementados (la mayoría) y solo quedan los que de verdad faltan.

---

## 1. 🔴 Completar el port del modal "MSA Setup" a producción (crítico — hay un bug en vivo)

**Contexto:** casi todo el trabajo de MSA en `valucal_mvp_production.html` ya está hecho — el bug de sintaxis del comentario, los campos nuevos en `proposalData`, el header de "Term start date" en Drafting, el gating y reset de opciones (parte no-MSA), el contador "Total qty vs. minimum" en las cards, la sincronización del modal de Send Proposal, el modal embebido de Account Setup, y la confirmación de MSA en la pantalla de Salesforce (`salesforce-quote.html`) — todo verificado presente en el código.

**Lo que falta — y explica por qué nada de MSA se activa nunca en producción:** el modal real de "MSA Setup" (donde el rep captura minimum quantity commitment / minimum service term / ramp-up period antes de entrar a Drafting) **nunca se terminó de portar**. Verificado en el código:

- `proposalData.msaId` nunca se asigna en ningún lado del archivo — se queda vacío para siempre. Esto significa que la barra de contexto de MSA, el indicador de mínimo en las cards, y los datos que se pasan al modal de confirmación en `salesforce-quote.html` nunca se activan en la práctica, aunque el código que los muestra sí esté listo.
- `openDraftingRoute()` llama a `closeMsaSetupModal()` en dos lugares (dentro de la función y en `openDraftingQuoteFromList()`), pero **esa función no existe en el archivo** — es un `ReferenceError` en vivo cada vez que se navega a Drafting.
- No existe el gating (`if (!skipMsaSetup && isMsaSetupRequired())`) que debería abrir el modal antes de entrar a Drafting cuando la cuenta no tiene MSA.
- No existe el HTML del modal (`#msa-setup-overlay` / `.msa-setup-modal`) ni las funciones `isMsaSetupRequired()`, `getMsaSetupMissingFields()`, `updateMsaSetupCtaState()`, `handleMsaSetupInput()`, `toggleMsaMinServiceTermDropdown()`, `selectMsaMinServiceTerm()`, `closeMsaSetupModal()`, `openMsaSetupRoute()`, `createMsaAgreement()`.

**La buena noticia: esto ya está construido, probado y funcionando en la versión futura (`index.html`, antes `app/demos/valucal_mvp.html`)** — es exactamente el mismo modal, ya con todas las correcciones de diseño aplicadas (3 campos sin Term start date, dropdown de meses para minimum service term, botón "Confirm", sin dividers, asterisco rojo en los campos obligatorios, etc.). No hay que diseñar nada nuevo — es copiar ese código ya probado:

1. Copiar de `index.html` las funciones `isMsaSetupRequired()`, `getMsaSetupMissingFields()`, `updateMsaSetupCtaState()`, `handleMsaSetupInput()`, `toggleMsaMinServiceTermDropdown()`, `selectMsaMinServiceTerm()`, `closeMsaSetupModal()`, `openMsaSetupRoute()`, `createMsaAgreement()` (buscar por esos nombres en `index.html`) y pegarlas en `valucal_mvp_production.html`, junto a `renderMsaHeaderTermStart()`/`updateMsaHeaderTermStart()` (que sí existen ahí).
2. Copiar el HTML del modal `#msa-setup-overlay` desde `index.html` (buscar ese id) a `valucal_mvp_production.html`, insertándolo antes de `<div id="screen-drafting" class="content-area">`.
3. Copiar el CSS del modal (`.msa-setup-modal`, `.msa-setup-number-input`, `.msa-setup-min-service-wrap`, `.textarea-field__label--required`, etc.) desde `index.html`.
4. En `openDraftingRoute()`, agregar el gating que falta al inicio de la función: `if (!skipMsaSetup && isMsaSetupRequired()) { openMsaSetupRoute(); return; }` — mismo patrón ya presente en `index.html`.
5. Verificar que `createMsaAgreement()` deje `proposalData.msaId` con un valor real al confirmar — de eso depende que se activen el indicador de mínimo en las cards, la barra de contexto, y los datos que recibe el modal de confirmación en `salesforce-quote.html` (que ya está listo del otro lado, solo espera que `proposalData.msaId` exista).

---

## 2. Account Setup — corregir los `field-hint` de la tarjeta "Master Service Agreement"

En `account-setup.html`, la tarjeta "Master Service Agreement" (7 campos) ya existe con la estructura correcta, pero el texto de ayuda (`field-hint`) está mal en 2 campos y falta en otros 5. Aplicar en ambos estados de cada campo (fila de solo lectura y fila de edición):

| Campo | `field-hint` actual | `field-hint` correcto |
|---|---|---|
| Vehicle Tracking | "per unit per month" | "Fixed at signature. There is no re-quoting downstream." |
| Powered Asset Tracking | "per unit per month" | "Optional. Leave empty if the customer takes no asset trackers." |
| Minimum quantity commitment | (ninguno) | "A total across all SKUs, not a figure per SKU." |
| Term start date | (ninguno) | Sin cambio — ya usa un input con máscara MM/DD/YYYY y date picker, no necesita el hint de formato del prototipo original. |
| Contract term, months | (ninguno) | "The agreement envelope." |
| Minimum service term, months | (ninguno) | "Applies per service order, from that order's billing start." |
| Ramp-up period, months | (ninguno) | "Optional. Commitment suspended and billing follows installation." |

La clase CSS `.field-hint` ya existe en el archivo, no hay que crearla. Seguir el mismo patrón ya usado en Vehicle Tracking/Powered Asset Tracking: `<div class="field-hint">texto</div>` dentro de `.field-lbl`.

---

## 3. Account Setup — nuevo campo "Minimum spend commitment"

Agregar un campo nuevo a la tarjeta "Master Service Agreement", dentro del grupo "Negotiated price and commitment", justo después de "Minimum quantity commitment". Es un piso de **gasto mensual en dólares**, distinto del "Minimum quantity commitment" (que es un piso de cantidad de unidades).

- **Llave interna:** `msaMinimumSpendCommitment` (mantiene el prefijo `msa` de los otros 7 campos).
- **Label:** "Minimum spend commitment"
- **Hint:** "The dollar floor billed monthly, regardless of the actual mix of products."
- **Input:** numérico, `step="50"`, placeholder `"e.g. 1950.00"`.
- **Formato de lectura:** `$X,XXX.XX/mo` — ej. `$1,950.00/mo`. **Ojo:** no usar el mismo formateador de `msaVehicleTrackingPrice` (`toFixed`, sin separador de miles) — para que un valor como 1950 se vea `$1,950.00/mo` y no `$1950.00/mo`, usar `toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})`.

**Las 5 piezas a tocar, mismo patrón que "Minimum quantity commitment":**
1. HTML — replicar el bloque `row-msaMinimumQuantityCommitment` / `edit-msaMinimumQuantityCommitment`, con los nuevos ids `row-msaMinimumSpendCommitment` / `edit-msaMinimumSpendCommitment`. El `style="border-bottom:none;"` que hoy tiene "Minimum quantity commitment" (por ser el último campo del grupo) pasa a este campo nuevo, ya que él queda de último.
2. `state.accountInfo` — agregar `msaMinimumSpendCommitment: ''`.
3. `fieldLabels` — agregar `msaMinimumSpendCommitment: 'Minimum spend commitment'`.
4. `displayValues` — agregar el formateador con `toLocaleString` descrito arriba.
5. No hace falta tocar ningún array/lista de badge o pre-poblado — el badge de la tarjeta es texto fijo ("7 items pending", no calculado), y `saveEdit()` ya es genérico (lee `input-<field>`, guarda en `state.accountInfo[field]`, pinta `val-<field>` con `displayValues[field](val)`) — con las 4 piezas de arriba alcanza para que Save/Cancel funcionen igual que en los campos vecinos.
