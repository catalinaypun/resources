# ValuCal — Acciones pendientes (general)

Documento de trabajo para `app/demos/valucal_mvp.html` (ahora `index.html`) — la versión **futura** de ValuCal (con Proposal, Contract, Deal Result). Este documento se limpió el 2026-08-31: todo lo que ya estaba construido, verificado por QA o resuelto se retiró. Solo quedan las acciones genuinamente pendientes.

**Convención de escritura:** no usar MAYÚSCULAS SOSTENIDAS (ni en copy propuesto, ni en nombres de cláusulas/secciones de ejemplo, ni en énfasis) salvo que Catalina lo pida explícitamente para ese caso puntual.

**Nota para quien ejecute:** antes de tocar cualquier función de la zona de contrato/proposal, revisar si está duplicada en el archivo — cuando una función se declara dos veces en JavaScript, la **segunda definición (más abajo en el archivo)** es la que realmente corre.

---

## 1. Fase 3 — Módulos de personalización propios para el contrato

**Bloqueado**, depende de que Catalina comparta el draft de una iteración anterior de la propuesta que puede servir de base. No bloquea nada más — mientras tanto se puede seguir usando un set de módulos genérico.

Con lo ya confirmado en la Fase 2 (editor de mensaje del contrato, ya construida), esta fase tiene dos partes pendientes:
- **Qué módulos van en el checklist** de "Message content" para contrato (equivalente a Intro/Pricing Summary/Expiration Date/What's Included/Key Differentiators de la propuesta, pero pensado para "aquí está tu contrato, fírmalo antes de X" en vez de vender la propuesta).
- **El copy y la imagen del hero** de la versión "Visual email" del correo de contrato (equivalente al "Your Custom Fleet Quote." + imagen de la propuesta, vía `buildContractVisualMessageHtmlFromBlocks`) — se puede usar un placeholder genérico mientras tanto (ej. "Your Contract is Ready.") y ajustar después.

---

## 2. Proposal — Editor de email (Finalize Your Proposal Package): requerimientos ACT 563

**⏸️ En pausa desde 2026-08-25** (se priorizó MSA). Ninguno de estos puntos se ha empezado a ejecutar en código todavía. Vienen de la llamada de revisión de producto "ACT 563 - Generation of email proposal generation" (2026-08-24), con Nicholas Carrington, Liam Wahlstrom, William Gabriel, Luis Vargas (usuarios diarios), Valon Sadiku, Rogelio Fuentes (PO), Shawnette Sapp, Catalina y Cheniece Persico. Referencia en código: `#proposal-review-edit-message`, `renderProposalMsgContentChecklist()`, `MESSAGE_BLOCK_IDS`, `buildProposalVisualMessageHtmlFromBlocks()`.

**Confirmados, listos para especificar/ejecutar:**

1. **Selección de opción específica para incluir en el email.** Hoy solo se puede mostrar/ocultar la sección completa de pricing (`MESSAGE_BLOCK_IDS.OPTION_INFORMATION`) — no elegir cuál opción específica incluir cuando hay varias (36 meses vs. 60 meses, por ejemplo). Agregar checkboxes para seleccionar qué opción(es) de precio se incluyen en el email.

   **1.1 — Dónde vive hoy el problema (verificado en código):** el email arma la sección de precios recorriendo **todas** las opciones sin filtro — `const optionBlocksHtml = options.map(function (opt, optIdx) {...})` (dentro de la función que construye el mensaje al abrir el editor; el archivo tiene esta misma línea duplicada, una copia ~14338 y la que realmente corre ~16446 — tocar solo la de ~16446, siguiendo la regla de "gana la segunda definición"). Cada opción se renderiza como una `.vez-email__option-card` con nombre ("Option N"), término, líneas de bundle y total.

   **1.2 — Guardar qué opciones van incluidas.** El modelo de bloques (`getProposalMessageBlocksModel()`, bloque `MESSAGE_BLOCK_IDS.OPTION_INFORMATION`) hoy es solo `{ visible: true }`. Agregar un campo nuevo `selectedOptionIds` (array de `opt.id` — no de índice, para que no se desalinee si se agrega/quita una opción) — por defecto, al abrir el editor, incluir todas las opciones existentes (mismo comportamiento de hoy si el rep no toca nada).

   **1.3 — UI: checkboxes por opción dentro del checklist.** En `renderProposalMsgContentChecklist()` (línea ~10165), la fila de "Pricing Summary" (`MESSAGE_BLOCK_IDS.OPTION_INFORMATION`) hoy no tiene editor inline propio (no está en `HAS_LEVEL`/`HAS_TEXT`/`HAS_LIST`). Agregar un caso nuevo en `renderInlineEditor(blockId, block)`: cuando `blockId === MESSAGE_BLOCK_IDS.OPTION_INFORMATION` y `options.length > 1`, renderizar una lista de checkboxes, uno por `opt` en `options` (label: `"Option " + (idx+1) + " — " + opt.term + " Month"`, `checked` si `opt.id` está en `block.selectedOptionIds`), cada uno con `onchange="onProposalOptionInclusionToggle('${opt.id}', this.checked)"`. Si solo hay 1 opción, no mostrar la lista (no tiene sentido elegir entre una sola).

   **1.4 — Función nueva `onProposalOptionInclusionToggle(optId, checked)`:** agrega o quita `optId` de `block.selectedOptionIds` (mismo patrón que ya usan `onProposalMessageBlockListItemInput`/`removeProposalMessageBlockListItem` para mutar el modelo y re-renderizar), y vuelve a llamar a la función que reconstruye el preview del email (la misma que ya se dispara con los demás toggles del checklist) para que el cambio se refleje de inmediato.

   **1.5 — Filtrar en el armado del email:** en la función que construye `optionBlocksHtml` (~16446), cambiar `options.map(...)` por `options.filter(function(opt){ return (model.blocks[MESSAGE_BLOCK_IDS.OPTION_INFORMATION].selectedOptionIds || []).includes(opt.id); }).map(...)` — el resto de la lógica de cada card no cambia.

   **1.6 — 🔴 Bug encontrado (2026-08-31, corregido 2026-09-01): el fix del punto 1.5 se aplicó a una copia muerta de la función, el preview no se actualiza.** Verificado en código: `fillProposalMessageDefaults(forceRebuild)` está **duplicada** — línea ~14376 y línea ~16503. Por la regla de "la segunda definición gana", la que realmente corre es la de la línea ~16503 — así que `onProposalOptionInclusionToggle()` sí actualiza `block.selectedOptionIds` y sí llama a `fillProposalMessageDefaults(true)`, pero esa llamada cae en la copia que ignora la selección, y el preview de la derecha nunca refleja el checkbox.
      - **Corrección (2026-09-01) a la nota anterior de este documento — las dos copias NO son intercambiables, revisadas línea por línea:**
        - La copia de la línea ~14376 (donde se había metido el filtro por error) es la **vieja/obsoleta**: arma el cuerpo del correo a mano con `createMessageChip(...)` y termina en `bodyEl.innerHTML = optionalBlocks ? (coreBlock + '<br><br>' + optionalBlocks) : coreBlock;` — no pasa por el sistema de formato de mensaje (`buildProposalMessageHtmlBySelectedFormat`, el que decide Visual vs. Plain text).
        - La copia de la línea ~16503 (la que realmente corre) es la **vigente**: arma `coreBlock` con `proposalEscapeHtml(...)`, y llama a `buildProposalMessageHtmlBySelectedFormat({...})` para el HTML final — es de la que depende el punto 6 (plain text) de este mismo documento.
        - Conclusión: **hay que aplicar el filtro a la copia vigente (~16503), no a la vieja.** Borrar la copia vieja (~14376–14497) en vez de la vigente — al revés de lo que decía la versión anterior de esta nota.
      - **Fix — instrucción lista para ejecutar (VS):**
        1. En la copia vigente (línea ~16503), reemplazar:
           ```js
           const optionBlocksHtml = options.map(function (opt, optIdx) {
           ```
           por:
           ```js
           const optionModel = getProposalMessageBlocksModel().blocks[MESSAGE_BLOCK_IDS.OPTION_INFORMATION] || {};
           const allOptionIds = Array.isArray(options)
             ? options.map(function (opt) { return String(opt && opt.id != null ? opt.id : ''); }).filter(Boolean)
             : [];
           let selectedOptionIds = Array.isArray(optionModel.selectedOptionIds)
             ? optionModel.selectedOptionIds.map(String)
             : [];
           if (!selectedOptionIds.length && allOptionIds.length) {
             selectedOptionIds = allOptionIds.slice();
             optionModel.selectedOptionIds = selectedOptionIds.slice();
             optionModel._selectionInitialized = true;
           }
           const includedOptionIds = new Set(selectedOptionIds.filter(function (id) { return allOptionIds.indexOf(id) !== -1; }));
           if (!includedOptionIds.size && allOptionIds.length) {
             allOptionIds.forEach(function (id) { includedOptionIds.add(id); });
           }
           const filteredOptions = Array.isArray(options)
             ? options.filter(function (opt) { return includedOptionIds.has(String(opt && opt.id != null ? opt.id : '')); })
             : [];
           const optionBlocksHtml = filteredOptions.map(function (opt, optIdx) {
           ```
           (el resto del `.map` que sigue después de esa línea no cambia.)
        2. Borrar por completo la función vieja: desde `function fillProposalMessageDefaults(forceRebuild) {` en la línea ~14376 hasta su `}` de cierre en la línea ~14497 (justo antes de `function handleRequestApproval()`).
        3. Probar: abrir el editor de "Finalize Your Proposal Package" con 2+ opciones, desmarcar una en el checklist, y confirmar que el preview de la derecha deja de mostrarla de inmediato.
1.7 — **Decisión (2026-09-01): simplificar el label de cada opción en el checklist de Pricing.** Hoy dice "Option 1 — 36 Month" (línea ~10280 de `index.html`, dentro de `renderInlineEditor()` para `MESSAGE_BLOCK_IDS.OPTION_INFORMATION`, usado tanto en las filas de checkbox del punto 1.3 como en las de "Recommended" del punto 2). Catalina prefiere quitar el término/mes y dejar solo "Option 1", "Option 2", etc. **Fix:** cambiar `const label = 'Option ' + (idx + 1) + ' — ' + String(opt && opt.term != null ? opt.term : '') + ' Month';` por `const label = 'Option ' + (idx + 1);`. No afecta el email en sí (ahí "Option N" ya se muestra solo, sin el mes, y el término va aparte en `.vez-email__option-term`) — es solo el label dentro del checklist del editor.

2. **Label "Recommended" en una opción.** Cuando se incluyen varias opciones, poder marcar una como recomendada — el rep elige cuál. Solo aplica si hay 2+ opciones (mismo criterio que el checklist de inclusión del punto 1).

   **Decisiones confirmadas (2026-09-01):**
   - Texto del badge: **"Recommended"** (no "Best choice").
   - Si el rep desmarca del checklist de inclusión (punto 1) la opción que estaba marcada como recomendada, la recomendación **se limpia automáticamente** — no puede quedar una opción "recomendada" que no se envía en el email.

   **Las piezas a tocar (mismo patrón que `selectedOptionIds` del punto 1):**
   1. **Modelo de datos** — en el bloque por defecto `MESSAGE_BLOCK_IDS.OPTION_INFORMATION` (línea ~9641, junto a `selectedOptionIds`), agregar `recommendedOptionId: null` (un solo id, no array).
   2. **UI — radio por opción.** En `renderInlineEditor()` (línea ~10251, mismo `if (blockId === MESSAGE_BLOCK_IDS.OPTION_INFORMATION && options.length > 1)` donde ya viven los checkboxes de inclusión), agregar un radio button junto a cada checkbox: `<input type="radio" name="proposal-option-recommended" ' + (isRecommended ? 'checked' : '') + ' onchange="onProposalOptionRecommendedToggle('${optId}')">` con un label pequeño ("Recommended") al lado. Deshabilitar el radio (`disabled`) si esa opción no está marcada como incluida (checkbox desmarcado) — no tiene sentido recomendar algo que no se va a mandar.
   3. **Función nueva `onProposalOptionRecommendedToggle(optId)`:** setea `block.recommendedOptionId = optId` (comportamiento de radio, reemplaza cualquier selección anterior), persiste el modelo (mismo patrón de `onProposalOptionInclusionToggle`), re-renderiza el checklist y llama a `fillProposalMessageDefaults(true)` para refrescar el preview.
   4. **Limpieza automática en `onProposalOptionInclusionToggle(optId, checked)`** (línea ~10221): si `checked === false` y `block.recommendedOptionId === optId`, agregar `block.recommendedOptionId = null` antes de persistir el modelo.
   5. **Badge en el email — usar el badge del Design System, no un estilo suelto.** ✅ Ya implementado por VS (2026-09-01), pero con una clase ad-hoc (`.vez-email__option-badge`, línea ~3438, colores hardcodeados `#eaf8ef`/`#166534`) en vez del componente del DS. **Corrección pedida por Catalina (2026-09-01): usar el badge real del Design System.**
      - El archivo ya carga `app/assets/ds/design-system.css`, que define `.badge` (línea 606) + modificadores de color (línea 620 en adelante) — el mismo patrón que ya se usa en otras partes del archivo para status (`badge badge--blue`, `badge badge--green`, `badge badge--gray-low`, etc., ej. línea 7512 "Closed Won").
      - **Fix:** en el HTML del badge (línea ~16498, `recommendedBadgeHtml`), reemplazar `<span class="vez-email__option-badge">Recommended</span>` por `<span class="badge badge--green">Recommended</span>` (verde = mismo significado positivo que ya usa "Closed Won" en el resto del producto).
      - Borrar la regla CSS suelta `.vez-email__option-badge { ... }` (línea ~3438) — ya no se necesita, el estilo lo da `.badge`/`.badge--green` del DS.
4. **"Free on-site installation" — mover al primer bullet.** **Corrección de referencia (2026-09-01):** no vive en `MESSAGE_BLOCK_IDS.PRO_INSTALLATION` (ese es un bloque distinto, "Professional installation." con su propio texto libre) — vive dentro de `MESSAGE_BLOCK_IDS.PACKAGE_INCLUDES` ("What's included at no extra cost"), como el ítem "On-site professional installation" dentro del array `items` (hoy es el 4to de 5). No se duplica en otro lado con propósito editable (ya se descartó duplicarlo en "Key Differentiators"; sí aparece también, hardcodeado y no editable, en el bloque separado `YOUR_PACKAGE` — no forma parte de este pedido).

   **Fix:** en `createDefaultProposalMessageBlocksModel()` (línea ~9649 de `index.html`), reordenar el array `items` de `MESSAGE_BLOCK_IDS.PACKAGE_INCLUDES` para que "On-site professional installation" quede primero:
   ```js
   [MESSAGE_BLOCK_IDS.PACKAGE_INCLUDES]: { visible: true, items: [
     'On-site professional installation',
     'Complete price lock guarantee on services',
     'Waived activation fees',
     'Waived equipment cost ($399–$699 value)',
     '45-day rollout period'
   ]},
   ```
   Como el renderer de esa sección (línea ~15478 y ~15645, "What's included at no extra cost") pinta `block.items` en el orden del array, no hace falta tocar nada más — el orden nuevo aplica tanto al email como al checklist editable del punto de la izquierda.
5. **"Removal of existing equipment" — checkbox condicional.** Checkbox opcional (default **desmarcado**) que, al marcarse, agrega **un bullet nuevo y separado** ("Removal/de-install of old hardware") a la lista — **decisión final (2026-09-01): no se liga/modifica el texto del bullet de instalación existente, queda como ítem aparte.** (Nota: esto reemplaza la redacción original de la llamada ACT 563, que decía lo contrario — "no es un bullet nuevo, es una adición condicional al texto ya existente" — Catalina lo cambió explícitamente a "debe quedar como un item aparte".)

   **Corrección de diseño (2026-09-01):** el spec original de este punto apuntaba a `MESSAGE_BLOCK_IDS.PRO_INSTALLATION` — verificado en código que **ese bloque nunca se renderiza en el checklist** (no está en `MANDATORY`, `OPTIONAL`, `FOLLOW_UP` ni `linkedItems` dentro de `renderProposalMsgContentChecklist()`) — es un bloque huérfano, el rep nunca lo ve ni lo puede activar hoy. La única sección de instalación que el rep sí ve y edita es el bullet "On-site professional installation" dentro de **"What's Included"** (`MESSAGE_BLOCK_IDS.PACKAGE_INCLUDES`, el mismo que en el punto 4 se movió al primer lugar). **Decisión: el checkbox va ahí, en "What's Included", modificando ese bullet — no en "Pro Installation".** Catalina también pidió que el checkbox aparezca **antes** de la lista de bullets editable, no después.

   **Verificado en código — los dos renderers reales a tocar (Visual y Plain text; ojo que `buildProposalMessageHtmlFromBlocks` está duplicada — línea ~9756 es la copia muerta, línea ~15608 es la que corre, por la regla de "la segunda definición gana"):**
   - `buildProposalVisualSectionFromBlock` (línea ~15475, caso `PACKAGE_INCLUDES`).
   - `buildProposalMessageHtmlFromBlocks`, copia viva (línea ~15645, caso `PACKAGE_INCLUDES`) — **no tocar la copia muerta de la línea ~9775**.

   **Las piezas a tocar:**
   1. **Modelo** — en el bloque por defecto de `PACKAGE_INCLUDES` (línea ~9649), agregar `removalIncluded: false` (junto a `items: [...]`).
   2. **Helper compartido (para no repetir la lógica en los 2 renderers, como pasó con el bug de la 1.6).** Agrega el bullet nuevo justo después del de instalación si lo encuentra (por contenido, no por posición, para que funcione aunque el rep reordene los bullets); si no lo encuentra, lo agrega al final:
      ```js
      function getPackageIncludesRenderItems(block) {
        const items = normalizeProposalKeyPoints(block && block.items || []).slice();
        if (block && block.removalIncluded) {
          const removalItem = 'Removal/de-install of old hardware';
          const idx = items.findIndex(function (item) { return /on-site professional installation/i.test(item); });
          if (idx !== -1) {
            items.splice(idx + 1, 0, removalItem);
          } else {
            items.push(removalItem);
          }
        }
        return items;
      }
      ```
   3. **Usar el helper en los 2 renderers**, reemplazando `const items = normalizeProposalKeyPoints(block.items || []);` por `const items = getPackageIncludesRenderItems(block);`:
      - Línea ~15476 (Visual, dentro de `buildProposalVisualSectionFromBlock`).
      - Línea ~15646 (Plain text, dentro de la copia viva de `buildProposalMessageHtmlFromBlocks`, la de línea ~15608 en adelante).
   4. **UI — checkbox antes de la lista.** En `renderInlineEditor()`, dentro del branch `if (HAS_LIST.has(blockId))` (línea ~10312), agregar el checkbox solo para `PACKAGE_INCLUDES`, antes del `<div class="msg-inline-list">`:
      ```js
      if (HAS_LIST.has(blockId)) {
        const items = block.items || [];
        const rowsHtml = items.map(function(item, idx) { /* ...markup existente, sin cambios... */ }).join('');
        const removalCheckboxHtml = blockId === MESSAGE_BLOCK_IDS.PACKAGE_INCLUDES
          ? '<label style="display:flex;align-items:center;gap:8px;padding-bottom:10px;margin-bottom:10px;border-bottom:1px solid var(--gray-200);font-size:12px;color:var(--black);">' +
              '<input type="checkbox" class="vds-checkbox-ff" ' + (block.removalIncluded ? 'checked' : '') + ' onchange="onPackageIncludesRemovalToggle(this.checked)">' +
              '<span>Include removal of existing equipment</span>' +
            '</label>'
          : '';
        return '<div class="msg-content-item-editor">' + removalCheckboxHtml + '<div class="msg-inline-list">' + rowsHtml + '</div><button type="button" class="msg-inline-add-btn" onclick="addProposalMessageBlockListItem(\'' + blockId + '\')">+ Add item</button></div>';
      }
      ```
      (Solo se agrega `removalCheckboxHtml` al `return` final — el resto del branch, incluyendo `rowsHtml`, no cambia.)
   5. **Función nueva `onPackageIncludesRemovalToggle(checked)`:**
      ```js
      function onPackageIncludesRemovalToggle(checked) {
        const model = getProposalMessageBlocksModel();
        const block = model.blocks[MESSAGE_BLOCK_IDS.PACKAGE_INCLUDES];
        if (!block) return;
        block.removalIncluded = !!checked;
        proposalData.messageBlocksModel = JSON.parse(JSON.stringify(model));
        fillProposalMessageDefaults(true);
        renderCustomizationSummary();
      }
      ```
7. **Múltiples destinatarios — sin integración a Salesforce.** Entrada manual de texto (escribir/pegar direcciones adicionales) — el "To" principal se sigue autocompletando como hoy desde el contacto de la cuenta. No construir un selector/buscador contra Salesforce.

   **Decisión (2026-09-01): por ahora NO se construye un campo "Cc" separado — no está claro todavía si en la llamada original pidieron un Cc de verdad o simplemente poder escribir varios correos dentro del mismo "To".** Mientras no se confirme, se deja en el "To".

   **Verificado en código:** el campo "To" (`#prop-msg-to`, línea ~7850) es un `<input type="text">` sin ninguna validación de formato de email (revisé `getProposalReviewValidationState()`/`renderProposalReviewInlineValidation()`, línea ~21709 — solo validan close date, expiration date y el email del rep; el "To" del cliente no se valida). Es decir, **el rep ya puede escribir o pegar varios correos separados por coma en el "To" hoy mismo, sin ningún cambio de código** — la única razón por la que no es obvio es que el placeholder dice "Enter email..." (singular).

   **Único cambio para este punto, por ahora:** actualizar el placeholder para comunicar que acepta varios, en las 2 vistas (v1 y v2, mismo patrón de UIs paralelas que el resto del editor):
   - Línea ~7850 (`#prop-msg-to`): `placeholder="Enter email..."` → `placeholder="Enter email(s), separated by commas"`.
   - Línea ~8150 (`#prop-msg-to-v2`): no tiene placeholder hoy — agregar `placeholder="Enter email(s), separated by commas"`.

   **Pendiente de confirmar con el equipo:** si la intención real de la llamada era un "Cc" propiamente dicho (distinto del "To" que autocompleta desde el contacto de la cuenta), construir ese campo aparte más adelante — ya quedó investigado cómo hacerlo (dos inputs sincronizados en las vistas v1/v2, sin modelo de datos, dos previews) si se retoma.
8. **Materiales adicionales — set curado de defaults (marcados por defecto).** Default de 5-6 items vía Highspot, todos marcados:
   - Live map + route replay + geofences (un solo video que cubre los 3)
   - Reports (video 3-en-1)
   - Integrated dash cam video (cubre todas las cámaras, incluye EVC de forma general)
   - Fleet maintenance
   - EVC — video promo de 1 minuto, standalone, separado del integrated video
   - ELD compliance video
   - Excluido explícitamente: el video "Reveal Overview" (muy general, duplica contenido)
   - **Resuelto (2026-09-02): Catalina ya consiguió los 6 links reales de Highspot.** De 7 URLs que le compartieron, una (con título "Reveal Overview") era justo el video que se había excluido explícitamente en la llamada original — quedaron los 6 correctos, confirmados 1 a 1 contra la lista curada.

   **Verificado en código:** hoy el bloque `ADDITIONAL_LINKS` (línea ~9643) tiene 4 links placeholder distintos a estos ("Reveal Demo — Fleet Maintenance", "Reveal Demo — Reports", "Reveal Demo — Geofences", "Reveal Reports") — hay que **reemplazar el array completo**, no agregar a lo que hay.

   **Fix — reemplazar el array `links` del bloque `ADDITIONAL_LINKS`** (línea ~9643 de `index.html`, dentro de `createDefaultProposalMessageBlocksModel()`) por:
   ```js
   [MESSAGE_BLOCK_IDS.ADDITIONAL_LINKS]: { visible: true, links: [
     { id: 'live-maps-geofences',   label: 'Live MapsGeofences Route Replay', url: 'https://view.highspot.com/viewer/7f31eef12fd27b7fb791097b4182a18f?iid=68dbfaf9abadeee363f01dbc', enabled: true },
     { id: 'alert-dashboards',      label: 'Alert Dashboards Reports',        url: 'https://view.highspot.com/viewer/f437b6bf2006484721db9e4b70bd8cc3?iid=68dc251779b2173e9ccd5df0', enabled: true },
     { id: 'vehicle-health',        label: 'Vehicle health and maintenance',  url: 'https://view.highspot.com/viewer/3f61183a86db9327644c0e2fce47b920?iid=691b5326a47ab9eee7b0eb1e', enabled: true },
     { id: 'integrated-video',      label: 'Integrated Video',                url: 'https://view.highspot.com/viewer/9b1e7cb1f60fcf96591df9bd3da50901', enabled: true },
     { id: 'reveal-compliance',     label: 'Reveal Compliance',               url: 'https://view.highspot.com/viewer/9dd1cd931b71680cd35247ec88446884?iid=6707ffc884dd6c80ba31f3f4', enabled: true },
     { id: 'extended-view-cameras', label: 'Extended View Cameras',           url: 'https://view.highspot.com/viewer/7ce46b990e4c8609cb2b2f7e5ccc59d2?iid=67475146726b4c6d47be36b1', enabled: true }
   ]},
   ```
   Los `label` quedan exactamente como aparecen en las portadas de los videos en Highspot (sin limpiar formato) — decisión explícita de Catalina.

   **Bug encontrado al integrar (2026-09-02): el límite de "máximo 5" materiales sigue hardcodeado en 6 lugares distintos** — con 6 links por defecto ya se dispara el bloqueo y el buscador de materiales adicionales desaparece (se reemplaza por el texto "Maximum 5 items"). Hay que subir el límite a 6 en los 6 lugares:
   1. Línea ~9879 (`onAdditionalLinkToggle`): `if (enabledCount >= 5) { renderProposalMsgContentChecklist(); return; } // enforce max 5` → cambiar `5` por `6` (y el comentario).
   2. Línea ~9902 (`addAdditionalLink`): `if (enabledCount >= 5) return;` → `if (enabledCount >= 6) return;`.
   3. Línea ~9974 (`selectAddLinkSuggestion`): `if (block.links.length >= 5) return;` → `if (block.links.length >= 6) return;`.
   4. Línea ~10371 (`renderAdditionalMaterialsSection`): `const atMax = links.length >= 5;` → `const atMax = links.length >= 6;`.
   5. Línea ~10392: `'/5</span>'` (el contador "N/5") → `'/6</span>'`.
   6. **Cambio de UX (2026-09-02):** en vez de esconder el buscador por completo cuando se llega al máximo (como hace hoy, reemplazándolo por el texto centrado "Maximum 5 items"), dejar el buscador **siempre visible**, pero deshabilitado al llegar al tope — así el rep siempre ve que existe la función de buscar, aunque no pueda agregar más en ese momento. En `renderAdditionalMaterialsSection()` (línea ~10396), cambiar:
      ```js
      (!atMax ? '<div class="addlinks-search-wrap" style="margin-top:8px;">' +
        '<span class="material-symbols-outlined addlinks-search-icon">search</span>' +
        '<input type="text" class="addlinks-search-input" id="addlinks-search-input" placeholder="Search materials..." autocomplete="off"' +
        ' onfocus="showAddLinksSuggestions()" oninput="filterAddLinksSuggestions(this.value)" onblur="hideAddLinksSuggestionsDelayed()">' +
        '<div class="addlinks-suggestions hidden" id="addlinks-suggestions"></div>' +
      '</div>' : '<div style="font-size:11px;color:var(--gray-400);text-align:center;margin-top:8px;padding:6px 0;">Maximum 5 items</div>')
      ```
      por:
      ```js
      '<div class="addlinks-search-wrap" style="margin-top:8px;">' +
        '<span class="material-symbols-outlined addlinks-search-icon">search</span>' +
        '<input type="text" class="addlinks-search-input" id="addlinks-search-input" placeholder="' + (atMax ? 'Maximum 6 items reached' : 'Search materials...') + '" autocomplete="off"' +
        (atMax ? ' disabled' : ' onfocus="showAddLinksSuggestions()" oninput="filterAddLinksSuggestions(this.value)" onblur="hideAddLinksSuggestionsDelayed()"') + '>' +
        (!atMax ? '<div class="addlinks-suggestions hidden" id="addlinks-suggestions"></div>' : '') +
      '</div>'
      ```

   **Nota aparte, no urgente:** el catálogo de búsqueda `ADDITIONAL_LINKS_CATALOG` (línea ~9910, usado por el buscador para sugerir materiales para agregar más allá de los 6 default) todavía tiene los links viejos de placeholder (Reveal Demo — Fleet Maintenance, etc.) — quedaron obsoletos ahora que los 6 default son los reales. Si el buscador es solo para casos raros de agregar un 7mo/8vo material custom, no es urgente tocarlo; si se quiere que el buscador sugiera contenido real de Highspot, hay que actualizarlo aparte (pendiente de definir qué otros materiales deberían estar ahí).
9. **"Impact mode" (trackers no motorizados / NPAT) — decisión tomada (2026-08-31, simplificada 2026-09-01): dinámico, auto-detectado, no manual, 2 escenarios (no 3).** Se descarta el toggle manual — el sistema debe **detectar automáticamente**, a partir de los datos de la orden (`opt.bundles`/`corePricing`), si hay algún core NPAT (non-powered asset tracker) entre las opciones incluidas en el email, y ajustar el bullet de instalación dentro de "What's Included" (`MESSAGE_BLOCK_IDS.PACKAGE_INCLUDES`, mismo bloque de los puntos 4 y 5).

   **Verificación resuelta (2026-09-01):** sí hay suficiente dato para distinguir un core NPAT — en `corePricing` (línea ~10519) hay exactamente 5 `coreKey`: `vtu`, `vtu-ffc`, `vtu-dual` (vehículo), `asset-powered` (asset con instalación) y `asset-nonpowered` (el NPAT). Un `bundle.coreKey === 'asset-nonpowered'` identifica el NPAT sin ambigüedad, mismo patrón que ya usan `isVehicleCore()`/`isVideoCore()` (línea ~12071).

   **Decisión final (2026-09-01) — 2 escenarios, evaluados sobre las opciones incluidas en el email (mismo filtro `selectedOptionIds` del punto 1):**
   - **Sin NPAT, o mixto (NPAT + equipo normal):** se deja el bullet "On-site professional installation" tal cual. Si es específicamente **mixto**, además se le agrega un asterisco al bullet y aparece automáticamente un disclaimer debajo de la lista de "What's Included": **"*Wireless asset trackers do not require installation."**
   - **100% NPAT** (todas las opciones incluidas en el email son NPAT): **se quita el bullet de instalación por completo** — no se reemplaza por otro texto, simplemente no aparece.

   **Las piezas a tocar:**
   1. **Helper — opciones incluidas en el email** (mismo cálculo que ya existe para filtrar `optionBlocksHtml` en el punto 1.6, pero expuesto como función reutilizable porque ahora se necesita en un lugar distinto del código):
      ```js
      function getEmailIncludedOptions() {
        const optionModel = getProposalMessageBlocksModel().blocks[MESSAGE_BLOCK_IDS.OPTION_INFORMATION] || {};
        const allOptionIds = Array.isArray(options) ? options.map(function (opt) { return String(opt && opt.id != null ? opt.id : ''); }).filter(Boolean) : [];
        let selectedOptionIds = Array.isArray(optionModel.selectedOptionIds) ? optionModel.selectedOptionIds.map(String) : [];
        if (!selectedOptionIds.length && allOptionIds.length) selectedOptionIds = allOptionIds.slice();
        const includedIds = new Set(selectedOptionIds.filter(function (id) { return allOptionIds.indexOf(id) !== -1; }));
        if (!includedIds.size && allOptionIds.length) allOptionIds.forEach(function (id) { includedIds.add(id); });
        return Array.isArray(options) ? options.filter(function (opt) { return includedIds.has(String(opt && opt.id != null ? opt.id : '')); }) : [];
      }
      ```
   2. **Helper — estado NPAT del email (`'none' | 'mixed' | 'all'`):**
      ```js
      function getEmailNpatStatus() {
        const includedOptions = getEmailIncludedOptions();
        let hasNpat = false;
        let hasNonNpat = false;
        includedOptions.forEach(function (opt) {
          (opt.bundles || []).forEach(function (bundle) {
            if (bundle.coreKey === 'asset-nonpowered') hasNpat = true; else hasNonNpat = true;
          });
        });
        if (!hasNpat) return 'none';
        if (hasNpat && hasNonNpat) return 'mixed';
        return 'all';
      }
      ```
   3. **Extender `getPackageIncludesRenderItems(block)` (el mismo helper del punto 5)** para aplicar el ajuste de NPAT sobre el bullet de instalación, después de la lógica de "removal" ya existente:
      ```js
      function getPackageIncludesRenderItems(block) {
        const items = normalizeProposalKeyPoints(block && block.items || []).slice();
        const installIdx = items.findIndex(function (item) { return /on-site professional installation/i.test(item); });
        if (block && block.removalIncluded) {
          const removalItem = 'Removal/de-install of old hardware';
          if (installIdx !== -1) { items.splice(installIdx + 1, 0, removalItem); } else { items.push(removalItem); }
        }
        if (installIdx !== -1) {
          const npatStatus = getEmailNpatStatus();
          if (npatStatus === 'all') {
            items.splice(installIdx, 1);
          } else if (npatStatus === 'mixed') {
            items[installIdx] = items[installIdx].replace(/\*$/, '') + '*';
          }
        }
        return items;
      }
      ```
   4. **Helper — HTML del disclaimer** (solo aparece si es mixto):
      ```js
      function getPackageIncludesFootnoteHtml() {
        return getEmailNpatStatus() === 'mixed'
          ? '<p style="font-size:11px;color:#666;margin-top:8px;">*Wireless asset trackers do not require installation.</p>'
          : '';
      }
      ```
   5. **Usar el disclaimer en los 2 renderers, justo después de cerrar la lista de "What's Included":**
      - Visual (`buildProposalVisualSectionFromBlock`, línea ~15481): cambiar `return '<div class="vez-email__block"><h3 class="vez-email__block-label">What’s included at no extra cost.</h3><div class="vez-email__check-list">' + rows + '</div></div>';` por lo mismo agregando `+ getPackageIncludesFootnoteHtml()` antes del `</div>` final.
      - Plain text (copia viva de `buildProposalMessageHtmlFromBlocks`, línea ~15645): cambiar `return '<b>What\'s Included at No Extra Cost:</b><ul style="margin:6px 0 0;padding-left:22px;">' + items.map(...).join('') + '</ul>';` para agregar `+ getPackageIncludesFootnoteHtml()` después de `</ul>`.
   6. **Bug encontrado por Catalina (2026-09-02) — falta aplicar lo mismo en el panel de edición.** El fix de arriba solo cambia el **email real**; el panel donde el rep edita los bullets de "What's Included" (`renderInlineEditor()`, branch `HAS_LIST`, línea ~10328) sigue leyendo `block.items` crudo — sigue mostrando "On-site professional installation" aunque el email (caso 100% NPAT) ya no lo incluya. **Decisión: debe desaparecer también del panel de edición**, no solo mostrarse atenuado o con una nota.

      **Ojo con la integridad de los datos:** los botones de editar/borrar/arrastrar cada bullet (`onProposalMessageBlockListItemInput`, `removeProposalMessageBlockListItem`, los handlers de drag) funcionan por **índice dentro de `block.items`** — si se filtra la lista antes de mapearla, los índices se corren y editar/borrar el bullet equivocado. Hay que ocultar el ítem de la vista **sin perder su índice real**, calculando `idx` sobre el array original antes de filtrar. En `renderInlineEditor()`, branch `HAS_LIST.has(blockId)` (línea ~10328), cambiar:
      ```js
      if (HAS_LIST.has(blockId)) {
        const items = block.items || [];
        const rowsHtml = items.map(function(item, idx) { return '<div class="msg-inline-list-row" ...>...</div>'; }).join('');
        ...
      }
      ```
      por:
      ```js
      if (HAS_LIST.has(blockId)) {
        let entries = (block.items || []).map(function(item, idx) { return { item: item, idx: idx }; });
        if (blockId === MESSAGE_BLOCK_IDS.PACKAGE_INCLUDES && getEmailNpatStatus() === 'all') {
          entries = entries.filter(function(e) { return !/on-site professional installation/i.test(e.item); });
        }
        const rowsHtml = entries.map(function(entry) {
          const item = entry.item, idx = entry.idx;
          return '<div class="msg-inline-list-row" ondragover="onProposalMessageBlockItemDragOver(event,\'' + blockId + '\',' + idx + ')" ondragleave="event.currentTarget.classList.remove(\'is-drag-over\')" ondrop="onProposalMessageBlockItemDrop(event,\'' + blockId + '\',' + idx + ')"><span class="material-symbols-outlined msg-inline-drag-handle" draggable="true" ondragstart="onProposalMessageBlockItemDragStart(event,\'' + blockId + '\',' + idx + ')" ondragend="onProposalMessageBlockItemDragEnd(event)">drag_indicator</span><input type="text" class="msg-inline-item-input vds-input" value="' + proposalEscapeHtml(item) + '" oninput="onProposalMessageBlockListItemInput(\'' + blockId + '\',' + idx + ',this.value)"><button type="button" class="msg-inline-item-delete" onclick="removeProposalMessageBlockListItem(\'' + blockId + '\',' + idx + ')"><span class="material-symbols-outlined" style="font-size:16px;">delete</span></button></div>';
        }).join('');
        ...
      }
      ```
      (Todo lo demás del branch — el checkbox de "Include removal of existing equipment" y el botón "+ Add item" — no cambia.) Nota: esto solo afecta qué se **muestra**; el ítem sigue existiendo en `block.items` sin tocarse, así que si el email deja de ser 100% NPAT (el rep cambia la selección de opciones), el bullet vuelve a aparecer solo, sin que nadie lo haya borrado.

11. **Intro — mencionar explícitamente que el PDF va adjunto, con "attached" en negrita.** Decisión (2026-09-02): el texto de hoy no dice "PDF" explícitamente. Nuevo texto default: *"Thank you for your time today. Please find attached the PDF with your customized fleet proposal and discounted pricing."* — con la palabra **"attached" en negrita**.

    **Verificado en código:** el texto del bloque `INTRO` pasa por `renderMessageBlockTemplate()` (línea ~10525), que hace `proposalEscapeHtml()` primero — es decir, si se escribiera `<strong>` directamente dentro del texto default, se vería como texto literal en el email, no como negrita (por eso el saludo con el nombre del contacto NO mete el `<strong>` dentro de `block.text`, lo agrega aparte en el código: `'Hi <strong>' + tokenMap.contactName + '</strong>,<br>'`, línea ~15511/15702). Mismo patrón hay que usar para "attached": no meterlo crudo en el texto default, sino que el renderer le agregue negrita a la palabra después de escapar.

    **Las piezas a tocar:**
    1. **Texto default** (línea ~9638): cambiar el `text` del bloque `INTRO` a `'Thank you for your time today. Please find attached the PDF with your customized fleet proposal and discounted pricing.'`.
    2. **Renderer Visual** (`buildProposalVisualSectionFromBlock`, línea ~15512): cambiar `const intro = renderMessageBlockTemplate(block.text, tokenMap);` por `const intro = renderMessageBlockTemplate(block.text, tokenMap).replace(/\battached\b/i, '<strong>$&</strong>');`.
    3. **Renderer Plain text** (copia viva de `buildProposalMessageHtmlFromBlocks`, línea ~15703): mismo cambio — `const intro = renderMessageBlockTemplate(block.text, tokenMap).replace(/\battached\b/i, '<strong>$&</strong>');`.

    Con el `.replace()` en el renderer (no en el texto guardado), si el rep edita el texto y sigue usando la palabra "attached", se sigue poniendo en negrita automáticamente — y si la borra, simplemente no hay negrita, sin romper nada.

**Abiertos, necesitan más definición antes de construir:**

6. **Plain text.** Se mantiene por ahora, condicionado a confirmar mobile-friendliness. Verificar que el email visual (`buildProposalVisualMessageHtmlFromBlocks`) sea responsive/mobile-friendly (~70% abre primero desde el celular) antes de reconsiderar quitar plain text.

**Pendiente de aprobación externa — no construir como definitivo todavía:**

10. **Lenguaje legal/promocional en el email.** Criterio ya definido: incluir el mismo disclaimer legal que ya aparece en el PDF, por defecto y sin opción de quitarlo (no es checkbox), ubicado abajo del todo, justo arriba de "All rights reserved". **Falta aprobación** de Alicia Milton (lenguaje de promos) y del equipo de marketing (Bri, equipo de Josh Arona) — Rogelio quedó en coordinar esa revisión. Además, todo el look and feel del email (lo ve el cliente final) necesita el visto bueno de marketing antes de darlo por definitivo.

**Nota — corregida (2026-09-02), el punto 3 de la llamada original NO aplica hoy:** se verificó en código que `MESSAGE_BLOCK_IDS.CASE_STUDY` no es funcionalidad activa — no está en `LINKED` (vacío, `[]`) por lo que nunca aparece como fila en el checklist del editor, y tampoco está en `getDefaultProposalMessageBlockOrder()` por lo que nunca se renderiza en el email real, sin importar su `level`. Además, el texto que sí tiene programado (visible solo si algún día se reconecta) está hardcodeado a un cliente fijo ("B.A.M Trucking"), sin usar `getSelectedCaseStudyData()` — sería un bug adicional a corregir si se reactiva. **Confirmado con Catalina (2026-09-02): no es prioridad ahora, queda fuera de los pendientes activos.** Si más adelante se quiere que el email mencione el case study real seleccionado en el PDF, hay que: (1) agregarlo a `LINKED` y al `order` por defecto para que aparezca en el checklist y en el email, y (2) reemplazar el texto hardcodeado por datos de `getSelectedCaseStudyData()`.

---

## 3. MSA — preguntas de negocio sin resolver (no bloquean la UI ya construida, pero siguen abiertas)

El MSA (fields, modal de setup, gating, indicador de mínimo, etc.) ya está construido y funcionando en `index.html`. Quedan sin resolver, del lado de negocio, estas preguntas — no requieren cambios de código todavía, pero conviene tenerlas presentes porque van a implicar cambios de lógica más adelante:

- **Billing durante ramp-up:** si el cliente solo usa la cantidad real durante el ramp-up (ej. 10 de 30 comprometidos), ¿se factura por 10 o por 30? Hubo respuestas contradictorias en la llamada del 2026-08-25 (Shawnette dijo "por los 30", el ejemplo de Madhuri mostró facturación por los 10 reales). Sin resolver.
- **Fin del ramp-up sin llegar al mínimo:** confirmado — se factura igual al mínimo comprometido, sin penalización adicional.
- **Múltiples service orders a mitad de término:** ¿todos terminan en la misma fecha que el MSA original, o cada uno corre su propio término? Anil propuso alinear todos a la misma fecha; Shawnette coincidió pero falta validar con negocio.
- **Renovación con compromiso excedido:** si el cliente terminó el término con más unidades que el compromiso original (ej. empezó en 30, terminó en 80), ¿el MSA renovado parte de 80? Sin resolver, pendiente de stakeholders de negocio (Vidya, Shri, legal).
- **Firma única a nivel de MSA:** la intención del equipo es que la firma se capture una sola vez, a nivel de MSA (no en cada service order) — pendiente de validación de Legal, no decidido. Si se confirma, el flujo de "Send for signature"/DocuSign eventualmente podría dejar de aplicar a cada service order individual.
- **MSA en el Proposal (email/PDF pre-firma):** es poco probable que estos datos deban mostrarse ahí, pero falta que Shawnette lo valide con negocio, no está descartado del todo. Lo que sí es claro: toda la información de MSA (term start date, contract term, ramp-up, minimum commitment) debe fluir hacia el documento de contrato/firma que se genera desde Salesforce — tenerlo en cuenta para no romper esa cadena si se toca algo de los campos.
