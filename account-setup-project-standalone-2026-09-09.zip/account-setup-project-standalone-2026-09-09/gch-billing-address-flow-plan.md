# GCH Duplicate Check — Plan de migración (ACT562-450 / PRG0961)

Migración del flujo de Salesforce "GCH Customer name Update Phase II" a la herramienta
custom, disparado desde la edición de Account name en Account Setup. Fuente:
[Figma — PRG0961](https://www.figma.com/design/Xi3Aozb5Qo6MHaTxEvLjEE/PRG0961---GCH-Customer-name-Update-Phase-II).

Este documento es un plan vivo: se va llenando a medida que revisamos cada pantalla
del flujo actual en Salesforce. Cada prompt tiene un estado:

- ✅ **Listo** — tenemos suficiente detalle de Figma/negocio para ejecutarlo tal cual.
- ⏳ **Pendiente** — sabemos qué hace el paso pero falta el detalle visual/copy exacto de Figma.
- ❓ **Necesita definición** — hay una decisión de producto o de mock/prototipo que solo tú puedes resolver.

**Reglas obligatorias para TODOS los prompts de este documento** (no son
opcionales, aplican a cada uno de los prompts de abajo sin excepción):

1. **Usar los componentes del design system existentes.** Nada de markup o
   estilos ad-hoc cuando ya existe un equivalente en `assets/ds/design-system.css`
   (`.modal`, `.loader`, `.notification`, `.btn`, `.badge`, `.table-header-cell` /
   `.table-body-cell`, `.card`, `.accordion-toggle`, etc.). Si un prompt necesita
   algo que no existe en el DS, se debe decir explícitamente "no existe, se
   construye nuevo" en vez de asumirlo en silencio.
2. **No usar mayúsculas sostenidas en textos**, salvo que sea una sigla real
   (ej. CLE ID, DUNS, CID, CLEID, GCH). Botones, títulos y labels van en
   sentence case ("Update account", no "UPDATE ACCOUNT"). Esto aplica al
   contenido de texto real — el `text-transform: uppercase` por CSS que ya usa
   el DS en labels tipo `.hdr-card-label` o `.card-title` está bien porque el
   texto fuente sigue en sentence case, solo se transforma visualmente.

---

## 1. Resumen del flujo

Disparador: el usuario edita **Account name** desde el modal que ya existe en
`index.html (raíz del proyecto)` (`openAccountNameModal()` / `#account-name-modal`),
que ya exige subir un documento PDF antes de poder guardar — esto coincide
exactamente con el primer nodo del diagrama original ("Enters new name and
uploads document and it is saved in SFDC"). **No es Billing address** — esa fue
la hipótesis inicial por el nombre del ticket, corregida al encontrar el stub ya
construido en el código (ver detalle en Prompt 1).

```
Edita account name + sube documento PDF, da "Save account name"
        │
        ▼
  Loader "Reviewing existing contracts" (un solo modal, ver Prompt 1)
        │
        ├── Encuentra contratos → el mismo modal se transforma en
        │   "Void Associated Contracts" (lista oportunidades afectadas)
        │       Cancel → descarta el cambio de account name, cierra
        │       Continue → vuelve al loader, ahora "Starting GCH review"
        │
        └── No encuentra contratos → el loader cambia su texto a
            "No existing contracts found" (~800ms) y sigue solo a
            "Starting GCH review" sin cerrarse
                │
                ▼
          GCH check corre dentro del mismo loader
                │
                ▼
          GCH Result?
                ├── Duplicate         → Banner + Case creado para DataOps (ver Prompt 2)
                ├── High Confidence   → Banner + Account Update
                ├── Multiple Match    → Modal ancho GCH Search se abre directo (sin banner) → usuario selecciona registro → Update
                └── No Match          → Se crea Case → DataOps revisa y actualiza → Banner + Account Update
```

Nota: el "pop-up in progress" del GCH y el chequeo previo de contratos se fusionaron
en un solo componente (ver Prompt 1) — nunca son dos ventanas separadas, es una sola
superficie que va cambiando de mensaje.

## 2. Qué ya existe en el código y es reutilizable

`index.html (raíz del proyecto)`, sección Compliance (accordion `#gch-card`), ya
implementa un patrón muy cercano a **Multiple Match**:

- `#gch-status-section` — fila de estado con badge "Pending" y botón "Select or request →" (`openGchSubview()`).
- `#gch-subview` — subvista inline con 2 opciones de compañía (`gch-opt-1`, `gch-opt-2`), radio buttons, y botones Cancel / "Confirm selection" (`confirmGchSelection()`).
- `gchRequestNew()` — flujo de "no encontré la correcta, pedir revisión".

Esto cubre visualmente el caso de **Multiple Match**, pero hoy se dispara manualmente
desde Compliance, no desde guardar un Account name nuevo. No existen todavía:
High Confidence (auto-aprobado), No Match (creación de Case), el pop-up "in progress",
ni el modal de Void Contract.

## 3. Preguntas abiertas antes de poder escribir todos los prompts

Ya no quedan preguntas bloqueantes — las 3 que había acá (qué pasa en
Duplicate, cómo mockear "¿hay contratos?", y el copy de los banners de High
Confidence/No Match) se resolvieron con las capturas de Figma de Salesforce
(ver §3.2) y con el Scenario builder del Prompt 4. Queda solo 1 detalle
menor anotado en §3.1 (radios DUNS) pendiente de confirmar con Stephanie,
sin bloquear la construcción — el tema de Cancel ya quedó resuelto (ver
§3.1). Ver §4 para el estado real de implementación (qué de todo esto ya
está en el código y qué falta).

## 3.1 Contexto de negocio — reunión con Stephanie Lopez (11 ago 2026)

Stephanie dio un walkthrough en vivo de la pantalla real de GCH Search en Salesforce.
Puntos clave (min 17:53–40:33 de la grabación):

- **Factibilidad confirmada por el equipo técnico** (Biswa - arquitecto, Naga - dev):
  no hay restricción técnica para que GCH Search, sus resultados y los banners vivan
  dentro de Account Setup. Lo único que están esperando de nuestro lado es una
  **propuesta de diseño** (no necesita estar conectada a datos reales) para poder
  estimar complejidad y timeline. Ese es el entregable inmediato de este plan.
- **Roles con visibilidad distinta** sobre los resultados del GCH Search:
  - *Sales rep* (usuario normal de Account Setup): selecciona un registro → puede
    **Update Account** o **Request Case** (crear un caso para Data Ops). No ve la
    opción de crear CID directamente.
  - *Data Ops*: ve **Create CID** en vez de Request Case.
  - Ambos roles ven **Cancel** (vuelve a la cuenta).
- **Estado bloqueado**: si la cuenta ya tiene un "VIP name" asociado (ya resuelto
  antes), las acciones quedan deshabilitadas — no hay nada que hacer.
- **Panel de búsqueda** (a la izquierda de la tabla): precarga account name y
  billing address cuando se entra desde una cuenta; sirve para que el rep busque
  otro nombre/dirección si no hay match (ej. la empresa cambió de razón social).
  Solo un radio de "search criteria" sigue vigente: **Base Customer Info**.
  Nota de precedencia: en el sandbox (screenshot del 19 ago) aparecen 3 radios
  (Sites DUNS, Global DUNS, Customer Info) en vez de los 2 que describió
  Stephanie — el conteo no cuadra 1:1. Lo que dice Stephanie tiene prioridad
  sobre lo que se ve en sandbox (puede estar desactualizado o no reflejar aún
  los cambios), así que por ahora asumimos que solo **Customer Info** se queda
  y tanto Sites DUNS como Global DUNS se quitan — **pendiente de confirmar con
  Stephanie** si en realidad alguno de los dos DUNS sí debe quedarse.
- **Tabla de resultados** — columnas confirmadas por sandbox + Stephanie: duns,
  cleID, cleName, confidence score, Street, City, State, Postal Code, Country,
  name. `name` y `cleName` son redundantes (visualmente idénticos en el
  sandbox, confirmado también por Stephanie) — se fusionan en nuestra versión;
  falta decidir qué label usar. `duns` y `cleID` **no** son redundantes entre
  sí (valores distintos en sandbox) — ambos se quedan como columnas separadas.
  Tiene barra de búsqueda propia (filtra la tabla), sorting por columna, y
  wrap/clip text por celda.
- **Botones de acción** — Stephanie los nombró "Request Case" (sales-rep) /
  "Create CID" (Data Ops); el sandbox muestra un botón "Request CLE ID" (CLE ID
  = CID, mismo concepto) junto con "Update Account", sin Cancel visible en el
  encuadre capturado. **Resuelto (19 ago):** Cancel sí debe existir — tanto en
  la pantalla de GCH Search como en general a lo largo de toda la actualización
  de Account name (no solo al final). Para la construcción se usan los nombres
  que dio Stephanie como oficiales: Update Account / Request Case (sales-rep) /
  Create CID (Data Ops) / Cancel (ambos roles, siempre visible).
- **Fuera de alcance del sprint actual (Fase 3, documentado para no perderlo)**:
  Data Ops también entraría a Account Setup para resolver Cases — vería una lista
  de casos pendientes de esa cuenta y editaría por los mismos 4 íconos
  (Account / Shipping address / Billing address / CID). Detalle agregado en la
  llamada del 25 ago: cuando Data Ops resuelve el caso, edita el account name
  directo (le da Edit) SIN necesidad de adjuntar el PDF firmado — ese
  requisito es solo para el flujo normal del sales rep, porque para Data Ops
  el caso ya creado hace las veces de esa validación. Stephanie aclaró que
  meterse con la lógica de Cases es ambicioso para este sprint y que primero
  necesita la aprobación de negocio de esta primera fase (lo que ya existe en
  el prototipo) antes de levantar los requerimientos de Data Ops — no
  construir nada de esto todavía.

## 3.1b Contexto de negocio — reunión con Stephanie Lopez (25 ago 2026)

Segunda revisión en vivo del prototipo. Puntos clave:

- **Confidence score — formato real confirmado**: Stephanie entró al sandbox
  en vivo y confirmó que la columna **solo muestra el número** (ej. "10875"),
  nunca el texto del tier ("High"/"Medium"/"Low"). Esto corrige lo asumido en
  el Prompt 3d (formato "Low=7") — la tabla mock sí tenía el tier + número
  porque el screenshot previo generó esa duda, pero Stephanie lo revisó en
  vivo esta vez y es solo el número. Su sugerencia (con la que Catalina
  coincide): no mostrar el texto del tier tampoco en nuestra versión — que el
  color de la celda (ya construido en el Prompt 3k) sea lo único que comunique
  High/Medium/Low, y el número se quede solo, sin prefijo. Ver Prompt 3s.
- **Botón "Request Case" (sales-rep) se renombra a "Request CLEID"** — mismo
  nombre que ya usa el botón de Data Ops en el sandbox real ("Request CLE
  ID"), para que ambos roles usen el mismo término. Create CID (Data Ops) no
  cambia, ya estaba correcto.
- **Habilitación de "Request CLEID" corregida**: hoy en el código requiere
  tener una fila seleccionada en la tabla para habilitarse, igual que Update
  Account. Stephanie aclaró que la lógica de negocio es la opuesta: se pide
  Request CLEID justamente cuando **ninguna** de las filas de la tabla es el
  match correcto — por lo tanto debe estar habilitado siempre (sin depender
  de selección), mientras que Update Account sí sigue exigiendo una fila
  seleccionada. Create CID no se tocó en esta conversación — se deja como
  está (si depende de selección, se mantiene así) porque Stephanie no lo
  mencionó explícitamente para ese botón. Ver Prompt 3t.
- **Campo "Account already has VIP name" del Scenario builder se elimina**:
  Stephanie confirmó que "VIP name" no es un concepto real que ellos usen —
  fue una interpretación errónea generada durante una transcripción de
  llamada anterior. Catalina confirmó en vivo que se quita. Esto incluye
  quitar también toda la lógica de bloqueo de botones y el aviso "This
  account already has a VIP name associated" que dependían de ese campo. Ver
  Prompt 3u.
- **Verificado en código (sin cambios necesarios)**: Stephanie preguntó si al
  editar el account name una segunda vez el nombre nuevo queda reflejado
  correctamente. Se revisó el código y sí — `openAccountNameModal()` siempre
  precarga el input con el nombre ya guardado, exige subir un PDF nuevo en
  cada edición (`clearAccountNameDocumentSelection()`), y
  `applyPendingAccountNameUpdate()` sobrescribe el nombre y actualiza el
  header en cada corrida por el mismo camino de código. El modal de GCH
  Search también resetea su selección/filtro cada vez que se abre. No se
  necesita ningún prompt para esto.
- **Pendiente de validar con negocio, NO implementar todavía**: si debería
  existir un botón/entrada independiente para abrir GCH Search en cualquier
  momento desde Account Setup, sin pasar por el flujo de editar el account
  name (hoy GCH Search solo se dispara automáticamente en el escenario de
  Multiple Match). Stephanie va a preguntar esto en la reunión de negocio del
  26 ago — no se escribe prompt para esto hasta tener respuesta.

**Resuelto (última revisión):** regla general de superficie — si el resultado
es solo informativo (el sistema ya resolvió, o delegó a otro equipo), va como
**notificación/banner en la parte superior de la página**, no modal. Si
requiere que el usuario tome una decisión activa, va como **modal**. Con eso:
- High Confidence → banner (informativo).
- No Match → banner (informativo, ya se creó el Case y DataOps lo toma).
- Duplicate → banner (informativo, mismo patrón que No Match: se crea un Case
  para Data Ops — ver §3.2 y Prompt 2).
- Multiple Match → **modal**, directo, sin banner intermedio (ver Prompt 2 y
  Prompt 3). Es el único de los 4 resultados que exige una decisión activa
  del usuario (elegir el registro correcto). El `.modal` estándar del DS
  tiene max-width fijo de 592px, insuficiente para panel de búsqueda + tabla
  de 10 columnas — se resuelve con `.modal--wide` (variante nueva agregada
  al design system solo para este caso, mismo overlay/backdrop que el resto
  de modales, más max-width). Al cerrarse el modal-loader del Prompt 1, se
  transiciona directo a este modal ancho — una sola transición, no modal
  apilado sobre modal. El botón persistente `#gch-action-btn`
  ("GCH search →") se queda como entrada manual para reabrir la misma
  búsqueda después (ej. con otro nombre), reusando el mismo `.modal--wide`.

---

## Prompt 1 — Convertir el loader de Account name en la secuencia unificada ✅ Listo

```
En index.html (raíz del proyecto) YA EXISTE el punto de entrada de este flujo —
no crear uno nuevo, reescribir el que hay:

- #account-name-modal: modal de edición de Account name, ya exige subir un PDF
  antes de habilitar "Save account name" (botón #account-name-save-btn, ver
  setAddressModalButtonState('accountName')).
- saveAccountNameFromModal(): hoy valida, guarda state.accountInfo.
  accountNamePendingUpdate, cierra #account-name-modal, abre
  #account-name-loading-modal (openAccountNameLoaderModal()), espera 1400ms
  con un solo mensaje fijo, aplica el cambio (applyPendingAccountNameUpdate())
  y redirige con goToExistingAccountExamplePage() a
  app/demos/account-existing-view.html.
- #account-name-loading-modal: YA usa .modal / .modal-overlay / .loader
  loader--large del design system (título "Updating account", body "Uploading
  documents and validating impacted opportunities..."). Es la base correcta,
  solo hay que hacerla evolucionar por estados en vez de un mensaje fijo de
  1400ms.

Cambios:

1. Eliminar el setTimeout plano de 1400ms y el redirect final
   (goToExistingAccountExamplePage()) — el flujo se queda en la misma página,
   no navega a account-existing-view.html (esa página no se toca ni se borra,
   solo deja de usarse en este flujo específico).

2. Dentro de #account-name-loading-modal, agregar dos bloques de contenido que
   se muestran/ocultan alternadamente sin cerrar el modal-overlay: el bloque
   .loader existente (para los estados de carga) y un bloque nuevo para el
   contenido de "Void Associated Contracts" (título + texto + lista + botones).
   Agregar también un .modal__close (X) — visible en TODOS los estados de
   este modal, no solo en void-contracts (ver punto 3b) — y un .modal__actions
   que solo se muestra en el estado void-contracts (con sus propios botones
   Cancel/Continue, distintos del X).

3. ESTADO "checking-contracts" (arranca al llamar saveAccountNameFromModal, en
   vez de abrir el modal fijo de hoy):
   - .loader__label / modal__body: "Reviewing existing contracts".
   - .modal__actions oculto (no aplica en este estado), pero .modal__close (X)
     visible — ver 3b, cancelación disponible en todo el flujo.

3b. Cancelación general del flujo (aplica a los estados checking-contracts,
   no-contracts-found y starting-gch — es decir, a cualquier momento del
   loader que NO sea el bloque void-contracts, que ya tiene su propio Cancel
   en modal__actions): clic en .modal__close (X) interrumpe cualquier
   setTimeout pendiente, descarta state.accountInfo.accountNamePendingUpdate
   sin aplicarlo, cierra #account-name-loading-modal y vuelve a
   #account-name-modal tal cual estaba antes de dar Save (mismo criterio que
   closeAccountNameModal() hoy). Esto cubre el pedido de que "toda la
   actualización de account name" sea cancelable, no solo el paso de void
   contracts.

4. Rama hasExistingContracts() — lee state.mockHasContracts (seteado por el
   Scenario builder del Prompt 4, default false si no se ha tocado):

   4a. SI true → sin cerrar el overlay, ocultar el bloque .loader y mostrar el
       bloque void-contracts (.modal__close ya está visible desde 3b, sigue
       igual):
       - Título: "Void Associated Contracts"
       - Cuerpo: "This account update will automatically void the contracts of
         these opportunities:" + lista con bullets de Text Links mock:
         "Pine Island Ambulance - 3 VTU, 3 Dual Cams (Pro-Install)" y
         "Dual Cams (Pro-Install)", + línea final "Do you want to continue
         with the update?"
       - modal__actions: botón secundario "Cancel" y botón primario "Continue".
       - Cancel → NO aplicar accountNamePendingUpdate (descartarlo), cerrar el
         modal-overlay, volver a #account-name-modal tal cual estaba (mismo
         criterio que closeAccountNameModal() hoy pero sin perder el intento).
       - Continue → ocultar bloque void-contracts, mostrar bloque .loader de
         nuevo con label "Starting GCH review" (pasar a 5).

   4b. SI false → seguir en el bloque .loader, sin ocultar el overlay:
       - Cambiar el label a "No existing contracts found" y reemplazar el
         spinner por el ícono assets/ds/icons/checkmark.svg (mismo patrón
         `<img>` que ya usa showToast() en este archivo).
       - Después de ~800ms, volver al spinner y cambiar el label a
         "Starting GCH review" (pasar a 5).

5. ESTADO "starting-gch": bloque .loader con label "Starting GCH review",
   .modal__close (X) sigue visible (ver 3b) — cancelable hasta el último
   instante antes de que resuelva runGchCheck().
   - Punto de enganche con runGchCheck() (Prompt 2): al resolver, cerrar
     #account-name-loading-modal, llamar applyPendingAccountNameUpdate() (ya
     existe, sin cambios) y mostrar el banner correspondiente en vez de
     redirigir a account-existing-view.html.

6. Tiempos de transición vía setTimeout (checking-contracts ~1200ms,
   no-contracts-found ~800ms, starting-gch ~1000ms) — son de prototipo, no
   hace falta que sean exactos.
```

---

## Prompt 1b — Corrección visual del modal de Void Associated Contracts (QA) ✅ Listo

Bugs encontrados al probar la implementación real (`#account-name-loading-modal`,
`index.html (raíz del proyecto)` ~línea 1571-1609):

1. **Dos títulos a la vez**: el `<h2 class="modal__title" id="account-name-loading-title">Updating account</h2>`
   está fuera de los bloques que se ocultan/muestran (`#account-name-loading-loader-block`
   y `#account-name-void-contracts-block`), así que queda visible siempre. Cuando
   se muestra el estado void-contracts, aparece ese h2 fijo Y el
   `<h3 class="modal__title">Void Associated Contracts</h3>` interno — dos
   títulos apilados.
2. **Poco espacio entre la lista de oportunidades y el texto**: todo el bloque
   void-contracts (título, párrafo, lista, párrafo final) está anidado dentro
   de un solo `<div>` con márgenes manuales (`var(--space-3x)`, `var(--space-2x)`),
   en vez de dejar que cada elemento sea hijo directo de `.modal__content` —
   que ya trae `gap: var(--space-8x)` (32px) automático entre sus hijos
   directos en el design system. Al anidar todo en un div, ese gap del DS no
   aplica y solo queda el margen manual, más apretado. Además el margen
   izquierdo de la lista usa `var(--space-5x)`, que **no existe** como token
   (los espaciados van de `--space-4x` a `--space-6x`, sin `5x`) — la variable
   inválida cae en `initial`, así que ese indent tampoco se está aplicando.
3. **Color de los links raro**: los `<a class="text-link">` de la lista de
   oportunidades usan una clase `.text-link` que **no está definida en
   ningún lado** de `assets/ds/design-system.css` ni en el archivo — por eso
   el navegador renderiza el azul/subrayado por defecto en vez de un estilo
   del DS.

```
En index.html (raíz del proyecto), dentro de #account-name-loading-modal:

1. Título único por estado: eliminar el <h3 class="modal__title">Void
   Associated Contracts</h3> del bloque void-contracts. En su lugar, cuando
   se entra al estado void-contracts, cambiar el textContent del h2 existente
   (#account-name-loading-title, el único modal__title del modal) a "Void
   Associated Contracts". Al volver a los estados de loader
   (checking-contracts / no-contracts-found / starting-gch), restaurar el
   texto del mismo h2 a "Updating account". Esto sigue el mismo criterio ya
   descrito en el plan de "un solo modal que va cambiando de mensaje", ahora
   aplicado también al título, no solo al cuerpo.

2. Espaciado del bloque void-contracts: quitar los márgenes manuales
   (var(--space-3x), var(--space-2x), var(--space-5x) inválido) y dejar que
   cada elemento (párrafo intro, lista, párrafo de confirmación) sea hijo
   directo de .modal__content en vez de estar envuelto en
   #account-name-void-contracts-block con estilos propios — así hereda el
   gap: var(--space-8x) que el design system ya define para espaciar el
   contenido del modal, sin necesidad de márgenes manuales. Si por estructura
   del código es más simple mantener el wrapper div, como mínimo corregir el
   token inválido (var(--space-5x) → var(--space-4x) o var(--space-6x), la
   que se vea más cercana al indent real del DS) y subir los márgenes
   verticales a var(--space-4x) o var(--space-6x) en vez de var(--space-3x)
   para acercarse al ritmo de 32px que usa el resto del modal.

3. Definir .text-link en assets/ds/design-system.css (no existe, hay que
   crearla — hoy el navegador la renderiza con su azul/subrayado por
   defecto porque la clase no tiene ninguna regla). Color: var(--color-blue-800)
   (#006fc0, token real del DS — no un azul inventado), text-decoration:
   underline. En :hover, oscurecer a var(--color-blue-900) o var(--color-blue-1000)
   manteniendo el underline, para dar feedback de interactivo.
```

## Prompt 1c — Centrar el loader; título centrado en estados de loader, a la izquierda en void-contracts ✅ Listo

Causa raíz confirmada en `index.html (raíz del proyecto)`:
- `.modal-loader-wrap` (en el `<style>` del archivo, hoy ~línea 822) no debe
  centrar todo el contenido del modal de forma fija, porque eso arrastra
  también el `<h2 class="modal__title" id="account-name-loading-title">` en
  el único estado donde NO debería estar centrado (void-contracts, que es
  texto de lectura: párrafo, lista, pregunta — todo left-aligned).
- El centrado visual del spinner/check/label debe vivir solo en el bloque del
  loader `#account-name-loading-loader-block` (hoy ~línea 829).
- El título SÍ debe quedar centrado en los 3 estados de loader
  (checking-contracts, no-contracts-found, starting-gch — pedido explícito:
  "en los modales donde hay loader me gustaría que el título estuviera
  centrado"), y alineado a la izquierda solo en el estado void-contracts.

```
En index.html (raíz del proyecto):

1. En `.modal-loader-wrap`, NO usar `align-items: center`; mantener solo:
  `display: flex; flex-direction: column; gap: var(--space-4x);
  min-height: 180px;`. Esto deja el título sin centrado fijo por defecto.

2. Agregar el centrado SOLO en `#account-name-loading-loader-block`:
  `display: flex; flex-direction: column; align-items: center;
  gap: var(--space-3x); text-align: center;`.
  Resultado esperado: spinner/check + label quedan centrados como grupo, aun
  cuando el label haga wrap.

3. Alineación del título según el estado — verificado en el código real
  (~línea 3192) que hoy setAccountNameVoidContractsVisible(visible) SOLO
  cambia title.textContent, nunca su alineación, por eso el título queda
  fijo a la izquierda en todos los estados. Agregar el toggle de
  text-align junto al de texto que ya existe ahí:

  if (title) {
    title.textContent = visible ? 'Void Associated Contracts' : 'Updating account';
    title.style.textAlign = visible ? 'left' : 'center';
  }

  Resultado: "Updating account" (y el resto de labels de loader que
  reusan este mismo h2: checking-contracts, no-contracts-found,
  starting-gch) queda centrado; "Void Associated Contracts" queda a la
  izquierda.

4. Verificar que `#account-name-void-contracts-block` y
  `#account-name-loading-actions` sigan estirando a ancho completo (ambos
  ya usan `width:100%` inline), sin regresiones visuales en ningún estado.
```

---

## 3.2 Banners reales de GCH Result (screenshots Figma, 19 ago 2026)

Los 4 casos confirmados con copy exacto de Salesforce. High Confidence,
Duplicate y No Match van como notificación/banner de página; Multiple Match
va directo como modal (`.modal--wide`, ver Prompt 2 y Prompt 3). Los 4 van
acompañados de un cambio de estado en el indicador "CLE ID" (equivalente a
nuestro badge `acc-badge-gch` en el accordion de Compliance):

| Resultado | Superficie | Color/Estado | Copy exacto | Estado CLE ID |
|---|---|---|---|---|
| High Confidence | Banner | Verde (éxito) | "CLE ID appended to account. The account name and billing address has been updated for compliance." | ✅ check verde |
| Duplicate | Banner | Naranja (warning) | "Duplicate CLE ID record found. Case <#> has been created to Data Ops for review." | ❌ X roja |
| Multiple Match | **Modal directo** (`.modal--wide`, sin banner) | — | El modal GCH Search se abre solo; su propio título/contenido explica que hay múltiples coincidencias, no hace falta copy de banner. | ❌ X roja |
| No Match | Banner | Rojo (error/bloqueante) | "A request to create a new CLE ID is under review by Data Ops team. Case [case number] has been created." | ❌ X roja |

Detalle que corrige tanto el diagrama original como una versión anterior de
este plan: **Multiple Match sí abre directo** el modal de GCH Search apenas
resuelve el GCH check (no hay banner ni paso manual para el primer intento).
El botón persistente `#gch-action-btn` ("GCH search →") se queda como
entrada para reabrir esa misma búsqueda después, no como el único
disparador.

---

## Prompt 2 — Banners de resultado GCH (3 banners + 1 modal directo) ✅ Listo

```
En index.html (raíz del proyecto), dentro de applyGchOutcome(outcome) (llamada
al resolver el estado "starting-gch" del Prompt 1), cerrar
#account-name-loading-modal y mostrar un banner de página en 3 de los 4
resultados de GCH (informativo/no bloqueante) — multiple-match NO lleva
banner, ver punto 4 — usando la misma superficie visual `.notification`.

1. Crear/ajustar una función mostrarGchResultBanner(resultado) donde
  resultado es 'high-confidence' | 'duplicate' | 'no-match' (multiple-match
  NO pasa por esta función, ver punto 4), con este mapeo exacto (copy
  textual, no parafrasear). Usar como base la estructura de `.notification`
  ya presente en el archivo (ver `.notification--warning` /
  `.approval-note`), agregando las variantes de color que falten
  (success/verde, warning/naranja, error/rojo):

   - high-confidence → notification success (verde): "CLE ID appended to
     account. The account name and billing address has been updated for
     compliance."
   - duplicate → notification warning (naranja): "Duplicate CLE ID record
     found. Case <#> has been created to Data Ops for review." (mock: generar
     un número de case aleatorio para reemplazar <#>, ej. Case #00234891)
   - no-match → notification error (rojo): "A request to create a new CLE ID
     is under review by Data Ops team. Case [case number] has been created."
     (mismo mock de número de case)

2. Ubicación del banner: ver corrección en Prompt 2b — no va arriba de todo
   .main-content, va debajo del grid de hdr-cards (Account name, Billing
   address, etc.) dentro de #section-account-info. No bloqueante, permanece
   visible hasta que el usuario resuelve la causa (no se auto-cierra ni tiene
   botón de cerrar, salvo high-confidence que sí puede auto-ocultarse o
   quedar como confirmación permanente — decisión de implementación, no
   crítica para el prototipo).

3. Actualizar el badge `acc-badge-gch` del accordion de Compliance (GCH —
  Customer Hierarchy) para reflejar el resultado, en los 4 casos:
   - high-confidence → badge verde "Confirmed" (equivalente al check verde del
     milestone CLE ID real).
   - duplicate / multiple-match / no-match → badge rojo o ámbar "Action
     required" (equivalente a la X roja del milestone CLE ID real) — usar
     badge--yellow si no hay una variante roja definida, no inventar una clase
     nueva de badge.

4. Para multiple-match: NO se muestra banner. Dentro de applyGchOutcome(outcome)
   (~línea 2702), la rama `else if (outcome === 'multiple-match')` hoy arma
   un banner warning con un botón "Open GCH search" que llama a
   showGchSearchTakeover(). Cambiar esa rama para que en vez de construir el
   banner, cierre #account-name-loading-modal (si sigue abierto) y llame
   directo a abrirGchSearchModal() (Prompt 3) — transición automática, sin
   clic del usuario para el primer intento. El botón persistente
   `#gch-action-btn` ("GCH search →") de Compliance se queda como entrada
   manual para reabrir esa misma búsqueda después, llamando a la misma
   abrirGchSearchModal() — no como el único disparador.

5. Mock de disparo: el resultado de runGchCheck() se controla con
   state.mockGchResult ('high-confidence' | 'duplicate' | 'multiple-match' |
   'no-match'). No usar un selector oculto de debug — el disparo de escenarios
   se hace desde el dropdown de Simulation existente (ver Prompt 4).
```

## Prompt 2b — Reubicar el banner + badge "Pending review" en Account name ✅ Listo

Objetivo: que la señal de resultado GCH se vea en el contexto correcto del
Account name (header cards) y no como elemento global fuera de sección.

```
En index.html (raíz del proyecto):

1. Ubicar `<div id="gch-result-banner" ...></div>` DENTRO de
  `#section-account-info`, justo después de `.account-header-band` y antes
  de la card "General". El id y la lógica de render se mantienen; solo cambia
  su posición de DOM para que aparezca junto al bloque de Account info.

2. Confirmar que `applyGchOutcome()` y `clearGchOutcomeBanner()` siguen
  funcionando igual con el nuevo lugar (solo cambia dónde se muestra).

3. Agregar badge local en la hdr-card de Account name:
  `<span class="badge badge--yellow hidden" id="acc-badge-accountname">Pending review</span>`
  junto al label "Account name", para mantener señal visible incluso cuando
  el banner salga de viewport.

4. Mostrar/ocultar ese badge en el MISMO bloque donde se actualiza
  `acc-badge-gch` (dentro de `updateProgress()`, sin función aparte):
  - duplicate / multiple-match / no-match → visible con texto
    "Pending review".
  - high-confidence → oculto.
  - estado inicial → oculto.

Estado implementado:
- `#gch-result-banner` dentro de `#section-account-info`.
- `#acc-badge-accountname` agregado en hdr-card de Account name.
- toggling del badge ligado a `state.compliance.gch` + `state.lastGchOutcome`
  dentro de `updateProgress()`.
```

## Prompt 2c — Espaciado de la notificación + botón para cerrarla ✅ Listo

Bugs de QA confirmados en el código real (`index.html`, raíz del proyecto):
- `.account-header-band` (~línea 188) tiene `margin-bottom: var(--space-6x)`
  (24px) — el espacio entre las cards de arriba y la notificación. Se pide
  bajarlo a 12px.
- **Actualización (QA después de aplicar lo anterior):** `.account-header-band`
  también tiene `padding: 0 0 var(--space-6x) 0` — un padding-bottom de 24px
  que se suma al margin-bottom y nunca se tocó. Por eso, aunque el
  margin-bottom ya haya quedado en 12px, el espacio real visible sigue
  siendo 24px (padding) + 12px (margin) = 36px, no 12px. Como
  `border-bottom: 0` y `background: transparent` en esta misma clase, ese
  padding-bottom no cumple ninguna función visual (no hay borde ni fondo que
  necesite ese aire) — se puede quitar por completo y dejar que el
  margin-bottom sea la única fuente de espacio.
- `.gch-result-banner-wrap` (~línea 665) tiene `margin-bottom: var(--space-5x)`
  — **ese token sigue sin existir** en el design system (los espaciados van
  de `--space-4x` a `--space-6x`, sin `5x` — este es el mismo bug que ya se
  había señalado antes y no llegó a corregirse en el código). La variable
  inválida cae en `initial` (0), por eso la notificación queda pegada al
  siguiente contenedor ("General").
- Hoy la notificación no tiene ninguna forma de cerrarse — no existe
  `.notification__close` en el design system, hay que construirlo nuevo.

```
En index.html (raíz del proyecto):

1. En `.account-header-band` (~línea 188), cambiar `margin-bottom:
   var(--space-6x)` a `margin-bottom: var(--space-3x)` (--space-3x = 12px,
   es el token real del DS que coincide con el valor pedido — no usar un
   12px suelto sin token), Y ADEMÁS cambiar `padding: 0 0 var(--space-6x) 0`
   a `padding: 0` (quitar el padding-bottom por completo — border-bottom ya
   es 0 y background transparent, no hay razón visual para mantenerlo, y es
   el que está sumando 24px extra de más al espacio real).

2. En `.gch-result-banner-wrap` (~línea 665), corregir el token inválido:
   cambiar `margin-bottom: var(--space-5x)` a `margin-bottom: var(--space-6x)`
   (24px), para que la notificación quede separada del contenedor "General"
   de abajo y dé sensación de tarjeta independiente, no pegada.

3. Botón para cerrar la notificación — no existe `.notification__close` en
   el DS, se construye nuevo reusando el mismo ícono X que ya usa
   `.modal__close` en este archivo (mismo `<svg viewBox="0 0 20 20">` con el
   path de la X), no un ícono nuevo de otra librería:
   - Agregar `.notification__close { position: absolute; top: var(--space-3x);
     right: var(--space-3x); width: 24px; height: 24px; background: none;
     border: none; cursor: pointer; display: flex; align-items: center;
     justify-content: center; color: inherit; }` (usa `.notification` que ya
     tiene `position: relative`, igual patrón que `.modal__close` sobre
     `.modal`).
   - Agregar el botón al template de `applyGchOutcome()` (dentro del
     `banner.innerHTML`, junto a `.notification__icon` y
     `.notification__body`): `<button class="notification__close"
     aria-label="Close" onclick="clearGchOutcomeBanner()">` + el mismo SVG
     de la X. Reusa `clearGchOutcomeBanner()`, que ya existe y ya oculta el
     banner — no crear una función nueva.
   - Aplica a los 3 resultados que sí muestran banner (high-confidence,
     duplicate, no-match) — multiple-match no lleva banner (ver Prompt 2).
```

## Prompt 2d — Badge verde "Verified" en Account name cuando GCH resuelve bien ✅ Listo

Hoy, si el resultado es high-confidence, el badge de Account name
(`#acc-badge-accountname`) simplemente se oculta — no queda ninguna señal
positiva en la card si el usuario cierra el banner (con el botón del Prompt
2c). Se agrega un tercer estado: verde "Verified" cuando el nombre ya quedó
confirmado, para que la card siempre refleje el estado real (sin badge antes
de correr el flujo, amarillo mientras hay algo pendiente, verde cuando
resolvió bien).

```
En index.html (raíz del proyecto), dentro de updateProgress() (~línea 2296,
justo donde hoy se hace el toggle de accountNameReviewBadge):

Reemplazar el bloque actual:

  const accountNameReviewBadge = document.getElementById('acc-badge-accountname');
  const needsAccountNameReview = state.compliance.gch === 'failed' && ['duplicate', 'multiple-match', 'no-match'].includes(state.lastGchOutcome);
  if (accountNameReviewBadge) {
    accountNameReviewBadge.textContent = 'Pending review';
    accountNameReviewBadge.classList.toggle('hidden', !needsAccountNameReview);
  }

Por:

  const accountNameReviewBadge = document.getElementById('acc-badge-accountname');
  const needsAccountNameReview = state.compliance.gch === 'failed' && ['duplicate', 'multiple-match', 'no-match'].includes(state.lastGchOutcome);
  const accountNameVerified = state.compliance.gch === 'confirmed';
  if (accountNameReviewBadge) {
    if (accountNameVerified) {
      accountNameReviewBadge.className = 'badge badge--green';
      accountNameReviewBadge.textContent = 'Verified';
      accountNameReviewBadge.classList.remove('hidden');
    } else if (needsAccountNameReview) {
      accountNameReviewBadge.className = 'badge badge--yellow';
      accountNameReviewBadge.textContent = 'Pending review';
      accountNameReviewBadge.classList.remove('hidden');
    } else {
      accountNameReviewBadge.classList.add('hidden');
    }
  }

No usa una clase de badge nueva — badge--green ya existe y ya se usa en
otros badges de esta misma función (acc-badge-general, acc-badge-payment,
acc-badge-gch, etc.), solo se aplica aquí también.
```

## Prompt 3 — Modal ancho GCH Search ✅ Listo

```
En index.html (raíz del proyecto), construir la vista de GCH Search como modal
ancho (`#gch-search-modal`, `.modal--wide`). Se abre de dos formas: (a)
automáticamente cuando applyGchOutcome() resuelve multiple-match, justo
después de cerrar #account-name-loading-modal (ver Prompt 2, punto 4 — SIN
banner intermedio), y (b) manualmente desde el botón persistente
`#gch-action-btn` ("GCH search →") del accordion GCH en Compliance, para
reabrir la búsqueda después. Ambas formas llaman a la misma función
abrirGchSearchModal().

Usar modal ancho (`.modal--wide`): por volumen de tabla + panel de búsqueda,
el modal estándar del DS no alcanza; esta variante mantiene el patrón de
`modal-overlay` sin navegar a otro archivo ni recargar.

⚠️ Nota de QA: el código real de `index.html (raíz del proyecto)` puede seguir
teniendo el takeover viejo (`#section-gch-search`, `showGchSearchTakeover()` /
`hideGchSearchTakeover()`, `openGchAction()`) si este prompt aún no se
ejecutó ahí — este prompt reemplaza esa implementación por completo, no
coexisten las dos.

Basarse en la pantalla real de Salesforce (confirmada por Stephanie Lopez +
screenshot de sandbox del 19 ago) en vez de en `#gch-subview` de Compliance —
esa queda como referencia de la lógica de selección/confirmación, no como
estructura visual final (la real es una tabla, no 2 tarjetas fijas).

0bis. Bug de QA encontrado: hoy hay DOS botones de texto "Cancel" — uno en
   el header de la vista (~línea 1396) y otro en el footer de acciones
   (~línea 1455), ambos llamando a hideGchSearchTakeover(). Solo debe quedar
   UNO: eliminar el botón "Cancel" del header. Si el header necesita cierre
   rápido, usar el ícono .modal__close (X) en vez de texto duplicado — el
   único botón de texto "Cancel" vive en el footer/modal__actions, junto a
   Update Account / Request Case / Create CID.

1. Estructura del modal (#gch-search-modal, .modal-overlay + .modal
   .modal--wide, ver detalle de la variante .modal--wide más abajo):
   - .modal__close (X) arriba a la derecha — único elemento de cierre en el
     header, sin botón de texto "Cancel" ahí (ver punto 0bis).
   - .modal__title: "GCH Search".
   - Panel de criterios de búsqueda (columna izquierda o franja superior):
     - Account name y Billing address precargados con el valor que el usuario
       acaba de guardar.
     - Un solo radio "Customer Info" seleccionado (no agregar Sites DUNS ni
       Global DUNS — pendiente de confirmar con Stephanie si alguno se queda,
       ver §3.1).
     - Botón "Search" que re-consulta (mock: vuelve a poblar la misma tabla mock).

2. Tabla de resultados (mock con 2-3 filas, reusar los 2 registros que ya
   existen en gch-opt-1/gch-opt-2 como base — Apex Construction LLC y ACME
   Logistics LLC — agregando DUNS y Confidence Score inventados a cada uno):
   - Columnas: DUNS, CLEID, **Name** (fusionar name + cleName en una sola
     columna — redundantes, confirmado por Stephanie y por el sandbox; usar
     "Name" como label), Confidence Score, Street, City, State, Postal Code,
     Country. DUNS y CLEID son valores distintos entre sí — no se fusionan.
   - Con el modal ancho la tabla puede mostrar todas las columnas sin
     truncar encabezados — usar esto a favor en vez del problema
     "confide..."/"postalC..." del sandbox.
   - Barra de búsqueda propia sobre la tabla que filtra las filas visibles
     (mock: filtro simple por texto en cualquier columna).
   - Encabezados de columna con sorting (asc/desc al hacer clic, mock con
     Array.sort en JS).
   - Selección de fila por radio button (igual que gch-dot-1/gch-dot-2 hoy).
   - Wrap/clip text por celda no es prioritario para el prototipo — dejar
     comentado como nice-to-have, no bloquea el prompt.

3. Acciones (footer del modal) — visibilidad basada en
   un mock de rol de usuario (state.userRole = 'sales-rep' | 'data-ops'):
   - **sales-rep** (default): con una fila seleccionada → botón primario
    "Update Account" (aplica el registro seleccionado, cierra el modal y
     vuelve a Account Setup — equivalente a confirmGchSelection() hoy) +
    botón secundario "Request Case" (crea un case mock, cierra el modal y
     muestra el banner de no-match del Prompt 2 — mismo destino que si el
     resultado del GCH check hubiera sido No Match) + "Cancel" (cierra
    el modal sin aplicar nada).
   - **data-ops**: mismo layout pero "Request Case" se reemplaza por
     "Create CID" (mock: solo muestra un toast confirmando creación, no hay
     flujo posterior definido todavía).
   - Si la cuenta mock ya tiene un "VIP name" asociado (state.accountInfo.
     vipNameLocked = true/false), deshabilitar Update Account / Request Case /
     Create CID — dejar solo Cancel activo, con un mensaje corto explicando
     que la cuenta ya está resuelta.

4. Mantener las funciones existentes (`selectGchOption`, `confirmGchSelection`,
   `gchRequestNew`) como base para la nueva lógica en vez de duplicar todo
  desde cero — adaptarlas a la tabla dinámica y al modal en vez de a las
   2 tarjetas fijas del subview de Compliance.
```

## Prompt 3b — Pulir el modal de GCH Search: quitar borde bajo el título y el selector de Search criteria ✅ Listo

Dos ajustes de QA sobre el modal ya construido (`#gch-search-modal`, ver
Prompt 3):

1. **Borde bajo el título**: `.gch-search-header` (`index.html`, ~línea 585)
   tiene `border-bottom: 1px solid var(--color-border);` — un divisor que no
   es parte del patrón estándar de `.modal__title` en el design system
   (ningún otro modal del archivo lo usa). Se quita.
2. **Search criteria innecesario**: el fieldset "Search criteria" (~línea
   1435-1441) solo tiene un radio, "Customer Info", ya marcado por defecto
   (esto porque Sites DUNS y Global DUNS se quitaron antes, ver §3.1) — con
   una sola opción no aporta nada mostrar un selector, se quita el fieldset
   completo del panel de búsqueda.

```
En index.html (raíz del proyecto):

1. En `.gch-search-header` (~línea 585), quitar la línea
   `border-bottom: 1px solid var(--color-border);` — el resto de la regla
   (padding, flex, etc.) se queda igual.

2. En el panel de búsqueda del modal (~línea 1427-1442, dentro de
   `.gch-search-panel`), eliminar por completo el bloque:

   <fieldset class="card card--outlined" style="padding: var(--space-3x);">
     <legend class="label text-body-small" style="margin-bottom: var(--space-2x);">Search criteria</legend>
     <label style="display:inline-flex; align-items:center; gap:8px;">
       <input type="radio" name="gch-search-criteria" checked>
       <span>Customer Info</span>
     </label>
   </fieldset>

   El panel queda solo con Account name, Billing address y el botón
   "Search" — verificado que `runGchTakeoverSearch()` no lee el valor de
   este radio en ningún lado, así que no hay que ajustar lógica JS, solo
   quitar el markup.
```

## Prompt 3c — Separar Billing address en 5 campos en el panel de GCH Search ✅ Listo

Hoy el panel de búsqueda del modal tiene un solo campo de texto
`#gch-search-billing-address` con la dirección completa en un string
("123 Industrial Pkwy, Sacramento, CA 95814"). Se pide separarlo en 5 campos:
Billing street, Billing city, Billing state (dropdown), Billing country
(dropdown), Billing postal code.

**No hay que construir esto desde cero** — ya existe exactamente este mismo
patrón en el modal de Billing address del propio Account info
(`#billing-address-modal`, ~línea 1722), con los campos `#bill-street`,
`#bill-country` (select), `#bill-city`, `#bill-state` (select),
`#bill-postal`, y las funciones `parseAddressString()` /
`composeAddressString()` que ya convierten entre el string combinado y estos
5 campos. Se reusa ese mismo patrón (mismas opciones de dropdown, mismos
labels) dentro del modal de GCH Search, con ids propios para no chocar con
los del modal de Billing address.

```
En index.html (raíz del proyecto):

1. En el panel de búsqueda del modal de GCH Search (dentro de
   .gch-search-panel, donde hoy está el único campo
   "Billing address" / #gch-search-billing-address), reemplazar por 5
   campos, copiando la estructura y las opciones exactas del bloque
   .shipping-address-grid de #billing-address-modal (~línea 1738-1774), con
   ids nuevos para este modal:

   - Billing Street → <input id="gch-search-billing-street">
   - Billing Country → <select id="gch-search-billing-country">, mismas
     opciones que #bill-country: "Select" (vacío), "USA" (value="US"),
     "Canada" (value="CA").
   - Billing City → <input id="gch-search-billing-city">
   - Billing State → <select id="gch-search-billing-state">, mismas
     opciones que #bill-state: "Select" (vacío), CA, FL, TX, NY.
   - Billing Postal Code → <input id="gch-search-billing-postal">

   Mismas clases que ya usa el resto del panel (.input / .select / .label
   .text-body-small), sin fieldset ni card alrededor — son campos sueltos,
   igual que Account name está hoy.

2. En showGchSearchTakeover() (~línea 2797-2807), donde hoy se hace
   document.getElementById('gch-search-billing-address').value =
   state.accountInfo.billingAddress || ''; reemplazar por el mismo patrón
   que ya usa openBillingAddressModal() (~línea 3410): parsear
   state.accountInfo.billingAddress con parseAddressString() y precargar
   cada uno de los 5 campos nuevos con su valor correspondiente
   (street/city/state/postal; country se fija en 'US' igual que hace
   openBillingAddressModal(), ya que hoy no se guarda el país por separado
   en el state).

3. Si runGchTakeoverSearch() o cualquier otra función leía
   #gch-search-billing-address, actualizarla para que en su lugar arme el
   string combinado con composeAddressString() a partir de los 5 campos
   nuevos, para no romper la búsqueda mock existente.
```

## Prompt 3d — Radios consistentes, tabla alineada a la izquierda, formato real de Confidence score ✅ Listo

Tres ajustes de QA sobre la tabla de resultados de GCH Search:

1. **Radio buttons sin estilo**: los radios de selección de fila
   (`<input type="radio" name="gch-search-select">`, dentro de
   `renderGchSearchTable()`, ~línea 2889) no tienen ningún estilo aplicado —
   se ven como el radio nativo del navegador. Ya existe un patrón de radio
   consistente en el resto de la app: `.payment-option input[type="radio"],
   .gch-option input[type="radio"] { accent-color: var(--color-black);
   width: 16px; height: 16px; margin: 0; flex-shrink: 0; }` (~línea 487).
   Se agrega el radio de la tabla a ese mismo selector en vez de crear un
   estilo nuevo.

2. **Alineación de la tabla**: `.gch-search-table th, td` ya tiene
   `text-align: left` por defecto, PERO `.gch-search-table .gch-row-selector`
   (la columna del radio, ~línea 630) lo sobreescribe a `text-align: center`
   — es la única columna que rompe la alineación del resto. Se quita ese
   `text-align: center` para que quede alineada a la izquierda igual que
   todas las demás columnas, incluyendo Confidence score (que ya hereda
   left por defecto, solo hay que confirmar que el cambio de formato del
   punto 3 no rompa eso).

3. **Formato real de Confidence score** (confirmado con screenshot de
   Salesforce sandbox que compartiste): no es un porcentaje — el formato
   real es "Tier=Score", ej. "Low=7", "Low=5", "Low=6" (sin espacios
   alrededor del "="). Hoy `gchSearchRows` (~línea 1940) guarda
   `confidence: 96 / 82 / 77` como número y `renderGchSearchTable()`
   (~línea 2893) lo pinta como `${row.confidence}%`.

```
En index.html (raíz del proyecto):

1. En la regla `.payment-option input[type="radio"], .gch-option
   input[type="radio"]` (~línea 487), agregar `.gch-search-table
   input[type="radio"]` a la lista de selectores (mismo bloque de estilos,
   no uno nuevo).

2. En `.gch-search-table .gch-row-selector` (~línea 630), quitar
   `text-align: center` (dejar solo el `width: 24px` si aplica, o eliminar
   la regla completa si no queda nada más en ella).

3. En gchSearchRows (~línea 1940), agregar un campo `confidenceTier` a cada
   registro mock y ajustar el valor de `confidence` para que quede en la
   misma escala que el sandbox (no porcentaje):
   - Apex Construction LLC: confidenceTier: 'Low', confidence: 7
   - ACME Logistics LLC: confidenceTier: 'Low', confidence: 5
   - Apex Mobility Services: confidenceTier: 'Low', confidence: 6

   En renderGchSearchTable() (~línea 2893), cambiar
   `<td>${row.confidence}%</td>` por
   `<td>${row.confidenceTier}=${row.confidence}</td>` (sin espacios
   alrededor del "="). El sort por 'confidence' (setGchTableSort) se queda
   igual, sigue ordenando por el número — ese campo no cambia de tipo, solo
   se le quita el "%" y se le antepone el tier al pintarlo.
```

## Prompt 3e — Panel de búsqueda en una sola columna (quitar el grid de 2 columnas) ✅ Listo

Verificado en el código real: los 5 campos de Billing (Street/Country/City/
State/Postal, agregados en el Prompt 3c) están envueltos en
`<div class="shipping-address-grid">` (~línea 1431), que es
`grid-template-columns: 1fr 1fr` — por eso Street queda al lado de Country,
y City al lado de State, en vez de uno debajo del otro. Se pide que todo el
panel quede en una sola columna, como ya está Account name (que no usa ese
wrapper).

```
En index.html (raíz del proyecto), dentro de .gch-search-panel (~línea
1426-1466):

1. Quitar la clase `shipping-address-grid` del `<div>` que envuelve los 5
   campos de Billing (~línea 1431) — puede quedar como `<div>` simple sin
   clase, o eliminarse el wrapper por completo y dejar los 5 `<div>` de
   campo (Street, Country, City, State, Postal) como hijos directos de
   `.gch-search-panel`, que ya es `display: grid` de una sola columna con
   `gap: var(--space-3x)` — así hereda el mismo espaciado vertical que ya
   tiene Account name arriba, sin necesidad de estilos nuevos.

2. Quitar también la clase `shipping-field-full` del campo Postal Code
   (~línea 1461) — esa clase solo tenía sentido dentro del grid de 2
   columnas (hacía que ocupara el ancho completo de las 2 columnas), ya no
   aplica en una sola columna.

3. Resultado esperado: Account name, Billing Street, Billing Country,
   Billing City, Billing State, Billing Postal Code y el botón "Search"
   quedan todos apilados uno debajo del otro, sin ningún campo al lado de
   otro.
```

## Prompt 3f — Espaciado de los campos, quitar borde del footer, más filas para scroll interno ✅ Listo

Verificado en el código real que el Prompt 3e quedó a medias: sí se quitó la
clase `shipping-address-grid`, pero el `<div>` que envuelve los 5 campos de
Billing (~línea 1431) se quedó sin quitar y sin ningún estilo propio — como
no tiene `display:grid` ni `gap`, sus 5 hijos (Street, Country, City, State,
Postal) se apilan por flujo normal de bloque con 0px de separación entre
ellos, mientras que el gap de 12px (`var(--space-3x)`) de `.gch-search-panel`
solo aplica ANTES y DESPUÉS de ese wrapper completo (entre Account name y el
wrapper, y entre el wrapper y el botón Search) — por eso Account name se ve
con aire y los 5 campos de abajo se ven pegados entre sí.

Además: `.gch-search-footer` tiene `border-top: 1px solid var(--color-border)`
(línea 639) — mismo patrón de borde que ya quitamos del header en el Prompt
3b, ahora en el footer. Y `gchSearchRows` solo tiene 3 registros mock, sin
altura fija en el contenedor de la tabla, así que nunca se ve scroll interno
(si crece, crece el modal completo, no la tabla).

```
En index.html (raíz del proyecto):

1. Terminar el Prompt 3e: eliminar por completo el `<div>` que envuelve los
   5 campos de Billing (~línea 1431, el que quedó sin clase), dejando esos
   5 `<div>` de campo como hijos DIRECTOS de `.gch-search-panel` (junto con
   el de Account name y el botón Search) — así los 7 quedan bajo el mismo
   `gap` del grid, sin wrapper intermedio.

2. En `.gch-search-panel` (~línea 599), cambiar `gap: var(--space-3x)` a
   `gap: var(--space-2x)` (8px, el valor pedido) — con el paso 1 ya
   aplicado, este gap queda uniforme entre los 7 elementos (Account name,
   los 5 campos de Billing, y el botón Search), no solo entre Account name
   y el resto.

3. En `.gch-search-footer` (~línea 634), quitar la línea
   `border-top: 1px solid var(--color-border);` — el resto de la regla
   (flex, padding, gap) se queda igual.

4. Agregar más filas mock a `gchSearchRows` (~línea 1940) para poder ver
   scroll interno — hoy solo hay 3. Agregar 7 más (10 en total), mismo
   formato que las existentes (duns, cleid, name, confidenceTier,
   confidence, street, city, state, postalCode, country: 'US'), ej.:
   Meridian Fleet Partners, Coastal Freight Solutions, Apex Distribution
   Group, Ironclad Transport LLC, Sunrise Logistics Co, Pine Valley
   Carriers, Redline Freight Systems — con DUNS/CLEID/direcciones
   inventados pero con formato realista (mismo patrón de 9 dígitos DUNS, 8
   dígitos CLEID que ya usan los 3 existentes), confidenceTier variado
   (Low/Medium/High) y confidence de 1 a 10.

5. Para que el scroll sea del contenedor de la tabla y no del modal
   completo: el `<div style="overflow:auto; border:1px solid
   var(--color-border); border-radius: var(--radius-100);">` que envuelve
   `<table class="gch-search-table">` (~línea 1476) necesita una altura
   máxima fija para que `overflow:auto` realmente dispare un scroll interno
   — agregar `max-height: 320px` (o el valor que se vea mejor probándolo)
   a ese mismo `style` inline, o mover esas reglas a una clase
   `.gch-search-table-wrap` si se prefiere no seguir usando estilos inline.
```

## Prompt 3g — Espacio filter→tabla (verificar) y tabla con los componentes reales del DS ✅ Listo

**Espacio entre "Filter results" y la tabla**: revisado en el código —
`.gch-search-results` (~línea 604) ya tiene `gap: var(--space-3x)` (12px)
entre el bloque del filtro y el wrapper de la tabla, y no encontré ningún
otro margin/padding que sume espacio extra ahí (no hay una regla `.label`
global que afecte, solo una scoped a `.shipping-address-form .label` que no
aplica a este bloque). Es decir, en el código YA está en 12px. Si en pantalla
se sigue viendo más grande, probablemente sea caché del navegador — no hay
nada que cambiar aquí a menos que después de refrescar se siga viendo mal,
en cuyo caso avisa con una captura para revisar de nuevo.

**Tabla sin los componentes reales del DS**: confirmado — `.gch-search-table`
usa estilos ad-hoc propios (`padding: 10px`, `font-size: 12px`,
`border-bottom: 1px solid var(--color-border)` en th/td) en vez de las
clases que el design system ya trae para esto: `.table-header-cell` (fondo
gris `--color-gray-100`, texto bold, padding `--space-2x`, borde
`--color-gray-200`) y `.table-body-cell` (texto regular, padding
`--space-3x --space-2x`, mismo borde). Esto rompe la regla obligatoria 1 del
plan (usar componentes del DS existentes en vez de estilos ad-hoc).

```
En index.html (raíz del proyecto):

1. Quitar la regla `.gch-search-table th, .gch-search-table td { ... }`
   completa (~línea 614-621, la del padding:10px/font-size:12px) — ya no
   hace falta, la reemplazan las clases del DS.

2. En el `<thead>` del modal de GCH Search (~línea 1479 en adelante),
   agregar la clase `table-header-cell` a cada `<th>` (excepto quizás
   `.gch-row-selector`, que puede quedarse solo con esa clase si no lleva
   texto). El `<button>` de sorting dentro de cada `<th>` se queda igual
   (su propia regla `.gch-search-table th button` no choca con
   `.table-header-cell`, que solo estiliza el `<th>` contenedor).

3. En `renderGchSearchTable()` (~línea 2893, donde se arma cada `<tr>` con
   template strings), agregar la clase `table-body-cell` a cada `<td>`
   (excepto `.gch-row-selector`, que puede mantener su propia clase para el
   ancho fijo de 24px).

4. Verificar que `.gch-search-table { border-collapse: collapse;
   table-layout: fixed; }` se mantenga (esas sí son necesarias para que la
   tabla funcione bien con columnas de ancho fijo) — solo se reemplazan los
   estilos de celda individuales, no la tabla completa.
```

## Prompt 3h — Headers de tabla realmente a la izquierda, más espacio reducido, panel de búsqueda con fondo propio ✅ Listo

Tres ajustes de QA sobre el modal de GCH Search:

1. **Headers de la tabla siguen sin verse a la izquierda**: aunque
   `.table-header-cell` ya tiene `text-align: left` (Prompt 3g), cada `<th>`
   contiene un `<button>` de sorting, y los navegadores le aplican
   `text-align: center` a los `<button>` por defecto en su propio estilo de
   usuario — ese default le gana a la alineación heredada del `<th>`. Hay
   que forzar la alineación en el botón mismo, no solo en la celda.

2. **Espacio filter→tabla**: aunque ya estaba en `var(--space-3x)` (12px, ver
   Prompt 3g), se pide reducirlo más — se baja a `var(--space-2x)` (8px),
   mismo valor que ya usa el panel izquierdo (Prompt 3f), para que ambas
   columnas del modal tengan el mismo ritmo de espaciado.

3. **Fondo propio para el panel de búsqueda**: para diferenciar visualmente
   el panel de criterios (izquierda) de los resultados (derecha), se le da
   fondo `var(--color-gray-100)` — el mismo gris que ya usa la app como
   fondo general de la página (`body`) y en paneles de soporte como el
   dropzone de subir documento (`.account-doc-upload`) — no es un color
   nuevo, es reusar un token ya establecido para "secciones insertadas".

```
En index.html (raíz del proyecto):

1. En `.gch-search-table th button` (~línea 614), agregar
   `text-align: left; display: block; width: 100%;` a la regla existente
   (se queda border:0, background:transparent, font:inherit,
   font-weight:bold, cursor:pointer, padding:0 tal cual están). Esto obliga
   al botón a ocupar todo el ancho de la celda y alinear su texto a la
   izquierda, sin depender del comportamiento por defecto del navegador.

2. En `.gch-search-results` (~línea 604), cambiar `gap: var(--space-3x)` a
   `gap: var(--space-2x)`.

3. En `.gch-search-panel` (~línea 599), agregar:
   `background: var(--color-gray-100); padding: var(--space-4x);
   border-radius: var(--radius-100);` a la regla existente (se queda el
   display:grid, gap y align-content tal cual). Verificar que con el padding
   nuevo el panel no se vea demasiado apretado contra `.gch-search-layout`
   (que ya tiene su propio padding) — ajustar el gap horizontal entre panel
   y resultados en `.gch-search-layout` si hace falta más aire.
```

## Prompt 3i — Hueco entre "Filter results" y la tabla (falta align-content: start) ✅ Listo

QA con captura de pantalla: aunque el `gap` de `.gch-search-results` ya está
en 8px (Prompt 3h), sigue apareciendo un hueco grande entre el input de
"Filter results" y la tabla. Causa real: `.gch-search-panel` (columna
izquierda) SÍ tiene `align-content: start`, pero `.gch-search-results`
(columna derecha) NO. `.gch-search-layout` es un grid de una sola fila con 2
columnas (panel + resultados) — como el panel izquierdo (con 6 campos + su
padding, ver Prompt 3h) es más alto que el contenido natural de la derecha
(filtro + tabla, esta con max-height:320px), la fila del grid se estira para
igualar esa altura. Sin `align-content: start`, `.gch-search-results`
reparte ese espacio extra dentro de sí misma en vez de mantener su contenido
pegado arriba — ahí aparece el hueco.

```
En index.html (raíz del proyecto), en `.gch-search-results` (~línea 607),
agregar `align-content: start;` a la regla existente (se queda display:grid,
gap:var(--space-2x) y min-width:0 tal cual). Mismo criterio que ya usa
`.gch-search-panel` al lado.
```

## Prompt 3j — Encuadrar panel + resultados en una card, botones del footer quedan claramente separados abajo ✅ Listo

Se pide que el bloque de búsqueda y resultados (`.gch-search-layout`, las 2
columnas: panel izquierdo + tabla derecha) quede encuadrado con un borde,
para que se perciba como una sola pieza funcional, y que los botones del
footer (Cancel / Request Case / Create CID / Update Account) queden
claramente por debajo de ese recuadro, no como si fueran parte de él.

No hay que inventar un borde nuevo — el design system ya tiene el
componente para esto: `.card--outlined` (fondo blanco, borde
`var(--color-gray-200)`, `border-radius: var(--radius-card)`, padding
`var(--space-6x)`), el mismo que ya usan otras cards de la app.

```
En index.html (raíz del proyecto):

1. Al `<div class="gch-search-layout">` (~línea 1425 aprox., el que envuelve
   .gch-search-panel y .gch-search-results) agregarle la clase
   `card--outlined`: `<div class="gch-search-layout card--outlined">`.

2. En la regla `.gch-search-layout` (~línea 593), quitar la línea
   `padding: var(--space-4x) var(--space-5x);` — ese padding lo va a dar
   ahora `.card--outlined` (var(--space-6x), 24px), no hace falta duplicarlo
   ni que compitan los dos valores. El resto de la regla (display:grid,
   grid-template-columns, gap) se queda igual.

3. El footer (.gch-search-footer, con Cancel / Request Case / Create CID /
   Update Account) no se toca — al quedar el bloque de arriba encuadrado en
   una card, el footer ya se percibe como una zona aparte por debajo, sin
   necesitar cambios propios.
```

## Prompt 3k — Código de color para Confidence score (High verde, Medium naranja, Low rojo, solo texto — sin badge) ✅ Listo

Color en el texto directamente, NO como badge/pill con fondo — corrección
sobre una versión anterior de este prompt que proponía envolverlo en
`.badge`. Tokens de color del DS a reusar (no inventar hex nuevos):
`var(--color-green-800)` (#008331, el mismo que usa `--color-success`),
`var(--color-orange-800)` (#b95319, el mismo que usa `--color-error`), y
`var(--color-brand-red)` (#e10014, el rojo de marca que ya se usa para
errores/campos requeridos en el resto del archivo — el DS no tiene una
escala `--color-red-*` propia, así que se reusa este token en vez de
inventar un hex nuevo).

```
En index.html (raíz del proyecto), dentro de renderGchSearchTable()
(~línea 2962-2975):

1. Agregar una función chica para mapear tier → color de texto:

   function gchConfidenceTextColor(tier) {
     if (tier === 'High') return 'var(--color-green-800)';
     if (tier === 'Medium') return 'var(--color-orange-800)';
     return 'var(--color-brand-red)'; // Low
   }

2. Cambiar la celda de Confidence score de:
   <td class="table-body-cell">${row.confidenceTier}=${row.confidence}</td>
   a:
   <td class="table-body-cell" style="color: ${gchConfidenceTextColor(row.confidenceTier)}; font-weight: var(--font-weight-bold);">${row.confidenceTier}=${row.confidence}</td>
   (el font-weight bold es opcional, para que el color resalte más sobre el
   resto de la tabla que es texto regular — quitar si se prefiere más
   sutil).

3. Verificar que los 10 registros mock de gchSearchRows (Prompt 3f) tengan
   confidenceTier con alguno de los 3 valores exactos 'High' | 'Medium' |
   'Low' (mismo capitalizado que ya se usa) para que el mapeo funcione en
   los tres colores, no solo en uno.
```

## Prompt 3l — Quitar el padding de la card para que el panel izquierdo quede pegado al borde ✅ Listo

`.card--outlined` (la clase que le dimos a `.gch-search-layout` en el
Prompt 3j) trae `padding: var(--space-6x)` (24px) en las 4 direcciones —
eso deja al panel gris de la izquierda flotando adentro del recuadro, con
aire alrededor en vez de tocar el borde. Se pide que el panel izquierdo (con
su fondo gris) quede completamente pegado al borde de la card, sin ese
padding.

No se toca `.card--outlined` en sí (es una clase compartida del DS, la usan
otras cards de la app) — se sobreescribe puntualmente para este contenedor,
y se compensa el aire que se pierde agregándoselo solo al lado de
resultados, que si no, quedaría con su contenido pegado al borde también.

```
En index.html (raíz del proyecto):

1. Agregar una regla más específica que gane sobre el padding de
   `.card--outlined` para este caso puntual:

   .gch-search-layout.card--outlined {
     padding: 0;
   }

2. Como `.gch-search-panel` (el gris) ya no tiene el padding externo de la
   card, pero su propio `padding: var(--space-4x)` (Prompt 3h) sigue dando
   aire interno a sus campos, no hace falta tocarlo — con el paso 1 su fondo
   gris queda pegado a los bordes izquierdo, superior e inferior de la card
   automáticamente.

3. En `.gch-search-results` (~línea 606), agregar
   `padding: var(--space-6x) var(--space-6x) var(--space-6x) 0;` (mismo
   valor que traía la card antes, pero solo arriba/derecha/abajo — sin
   padding-left, porque el gap del grid con el panel ya separa ambas
   columnas) para que la tabla y el filtro no queden pegados al borde
   derecho/superior/inferior de la card.
```

## Prompt 3m — Recuperar bordes redondeados de la card y ampliar el alto de la tabla ✅ Listo

Dos efectos secundarios del Prompt 3l:

1. Al dejar el panel gris (`.gch-search-panel`) pegado al borde de la card
   (padding:0 en `.gch-search-layout.card--outlined`), su propio
   `border-radius: var(--radius-100)` no coincide con el
   `border-radius: var(--radius-card)` de la card, y como la card no recorta
   a sus hijos, las esquinas cuadradas del panel gris tapan visualmente las
   esquinas redondeadas de la card (arriba-izquierda y abajo-izquierda). Se
   ve como si la card hubiera "perdido" el borde redondeado.

2. La tabla de resultados tiene un wrapper con estilos inline
   (`style="overflow:auto; max-height: 320px; ..."`, línea ~1474) que deja
   fijo el alto en 320px aunque el modal tiene espacio disponible de sobra —
   se puede ampliar para ver más filas sin perder el scroll interno.

```
En index.html (raíz del proyecto):

1. En la regla `.gch-search-layout.card--outlined` (~línea 598), agregar
   `overflow: hidden;` para que la card recorte a sus hijos según su propio
   border-radius, y el panel gris (y cualquier otro contenido flush) respete
   la esquina redondeada en vez de taparla:

   .gch-search-layout.card--outlined {
     padding: 0;
     overflow: hidden;
   }

2. Mover el estilo inline del wrapper de la tabla (línea ~1474,
   `<div style="overflow:auto; max-height: 320px; border:1px solid
   var(--color-border); border-radius: var(--radius-100);">`) a una clase
   nueva en el bloque de estilos, subiendo el alto máximo a 480px:

   .gch-search-table-wrap {
     overflow: auto;
     max-height: 480px;
     border: var(--border-width) solid var(--color-border);
     border-radius: var(--radius-100);
   }

   Y en el markup, reemplazar el `style="..."` inline por
   `class="gch-search-table-wrap"` en ese div.
```

## Prompt 3n — Bajarle el peso visual al botón Cancel del footer (ghost) ✅ Listo

Cancel se queda (Resuelto 19 ago con Stephanie: debe existir siempre en GCH
Search), pero hoy tiene el mismo peso visual (`btn--secondary`) que las
demás acciones del footer, y con 3 botones al mismo nivel (Cancel + Update
Account + Request Case/Create CID, nunca los 4 a la vez porque Request Case
y Create CID son excluyentes por rol) se siente ruidoso. Se separa Cancel
del grupo de acciones de confirmación y se le baja el peso con
`.btn--ghost` (ya existe en el DS).

```
En index.html (raíz del proyecto):

1. En `.gch-search-footer` (~línea 635), cambiar
   `justify-content: flex-end;` por `justify-content: space-between;` para
   que Cancel quede separado a la izquierda y el resto de acciones
   (Request Case/Create CID + Update Account) a la derecha.

2. En el botón Cancel del footer (~línea 1504,
   `<button class="btn btn--secondary btn--medium" onclick="hideGchSearchTakeover()">Cancel</button>`),
   cambiar la clase `btn--secondary` por `btn--ghost`.

3. Como el footer deja de ser un solo grupo alineado a la derecha, envolver
   Request Case/Create CID + Update Account en un `<div>` con
   `display:flex; gap: var(--space-3x);` para que ese subgrupo se mantenga
   junto a la derecha mientras Cancel queda solo a la izquierda.
```

## Prompt 3o — Reducir el gap entre columnas del GCH Search ✅ Listo

`.gch-search-layout` tiene `gap: var(--space-4x)` (16px) entre la columna
del panel izquierdo (300px) y la de resultados. Se reduce a
`var(--space-3x)` (12px) — mismo valor que ya se usa entre el filtro y la
tabla — para ganar esos 4px de vuelta para el contenido, sin quedar tan
apretado como para confundir las dos columnas.

```
En index.html (raíz del proyecto):

1. En `.gch-search-layout` (~línea 593), cambiar `gap: var(--space-4x);`
   por `gap: var(--space-3x);`.
```

## Prompt 3p — Scroll de la tabla visible solo en hover ✅ Listo

`.gch-search-table-wrap` (Prompt 3m) siempre reserva el espacio de la
scrollbar aunque no se esté usando. Se oculta por defecto y solo aparece al
pasar el mouse sobre la tabla, para ahorrar ese espacio visual.

```
En index.html (raíz del proyecto), agregar debajo de `.gch-search-table-wrap`:

.gch-search-table-wrap {
  scrollbar-width: none; /* Firefox: oculta por defecto */
}
.gch-search-table-wrap::-webkit-scrollbar {
  width: 8px; /* Chrome/Edge: reserva el ancho pero el thumb es transparente */
}
.gch-search-table-wrap::-webkit-scrollbar-thumb {
  background: transparent;
  border-radius: var(--radius-100);
}
.gch-search-table-wrap:hover {
  scrollbar-width: thin; /* Firefox: aparece en hover */
}
.gch-search-table-wrap:hover::-webkit-scrollbar-thumb {
  background: var(--color-gray-400); /* Chrome/Edge: aparece en hover */
}
```

## Prompt 3q — Más espacio entre los campos del panel izquierdo ✅ Listo

`.gch-search-panel` tiene `gap: var(--space-2x)` (8px) entre sus campos
(Account name, Billing street/country/city/state/postal). Se sube a
`var(--space-4x)` (16px).

```
En index.html (raíz del proyecto):

1. En `.gch-search-panel` (~línea 601), cambiar `gap: var(--space-2x);`
   por `gap: var(--space-4x);`.
```

## Prompt 3r — Alinear el tope de "Filter results" con el de "Account name" ✅ Listo

`.gch-search-panel` (izquierda) tiene `padding: var(--space-4x)` (16px
arriba) y `.gch-search-results` (derecha) tiene
`padding: var(--space-6x) var(--space-6x) var(--space-6x) 0` (24px arriba)
— por eso "Filter results" arranca 8px más abajo que "Account name". Se
iguala el padding-top de resultados al del panel (16px), dejando el resto
de lados igual.

```
En index.html (raíz del proyecto):

1. En `.gch-search-results` (~línea 614), cambiar
   `padding: var(--space-6x) var(--space-6x) var(--space-6x) 0;`
   por
   `padding: var(--space-4x) var(--space-6x) var(--space-6x) 0;`
```

## Prompt 3s — Confidence score: solo el número, sin el texto del tier ✅ Listo

Corrección al Prompt 3d/3k según la llamada del 25 ago (ver §3.1b): el
sandbox real de Salesforce solo muestra el número (ej. "10875"), nunca
"Low=7". Se quita el prefijo `${row.confidenceTier}=` de la celda — el color
por tier (Prompt 3k) se queda igual, es lo único que ahora comunica
High/Medium/Low.

```
En index.html (raíz del proyecto), en renderGchSearchTable() (~línea 2975):

1. Cambiar la celda de confidence score de:
   <td class="table-body-cell" style="color: ${gchConfidenceTextColor(row.confidenceTier)}; font-weight: var(--font-weight-bold);">${row.confidenceTier}=${row.confidence}</td>
   a:
   <td class="table-body-cell" style="color: ${gchConfidenceTextColor(row.confidenceTier)}; font-weight: var(--font-weight-bold);">${row.confidence}</td>

   (se quita `${row.confidenceTier}=`, se deja solo `${row.confidence}`; el
   color sigue calculándose igual con gchConfidenceTextColor(row.confidenceTier)).
```

## Prompt 3t — Renombrar "Request Case" a "Request CLEID" y corregir cuándo se habilita ✅ Listo

Según la llamada del 25 ago (§3.1b): el botón de sales-rep se renombra para
usar el mismo término que Data Ops ("CLEID"), y su lógica de habilitación
estaba invertida — se usa justo cuando NINGUNA fila es el match correcto,
así que no debe depender de tener una fila seleccionada.

```
En index.html (raíz del proyecto):

1. En el markup del botón (~línea 1505):
   <button class="btn btn--secondary btn--medium" id="gch-request-case-btn" onclick="requestGchCaseFromTakeover()">Request Case</button>
   cambiar el texto visible "Request Case" por "Request CLEID" (dejar el id
   y el onclick igual, son internos).

2. En renderGchTakeoverActions() (~línea 3060-3070):
   cambiar
   `if (requestBtn) requestBtn.disabled = locked || !hasSelection;`
   por
   `if (requestBtn) requestBtn.disabled = locked;`
   (deja de exigir hasSelection — sigue respetando `locked` hasta que se
   ejecute el Prompt 3u, que elimina ese concepto por completo).

3. En requestGchCaseFromTakeover() (~línea 3082):
   cambiar
   `if (!gchSearchState.selectedCleid || state.accountInfo.vipNameLocked) return;`
   por
   `if (state.accountInfo.vipNameLocked) return;`
   (ya no exige selectedCleid; applyGchOutcome('no-match') se dispara igual
   sin necesidad de haber seleccionado una fila).

   No tocar updateAccountFromGchTakeover() ni createCidFromTakeover() — Update
   Account sigue exigiendo selección, y Create CID no se tocó en esta
   conversación con Stephanie.
```

## Prompt 3u — Quitar por completo el concepto "VIP name" ✅ Listo

Stephanie confirmó en la llamada del 25 ago (§3.1b) que "VIP name" no es un
concepto real del negocio — se cuela por error en una transcripción
anterior. Se elimina el campo del Scenario builder y toda la lógica de
bloqueo asociada (deja de existir el estado "cuenta bloqueada" en el GCH
Search — Update Account/Request CLEID/Create CID solo dependen de selección
de fila, no de VIP).

```
En index.html (raíz del proyecto):

1. Quitar el campo completo del Scenario builder (~línea 1594-1600):
   <div>
     <label class="label text-body-small" for="scenario-vip-select">Account already has VIP name</label>
     <select class="select" id="scenario-vip-select">
       <option value="no">No</option>
       <option value="yes">Yes</option>
     </select>
   </div>

2. En syncScenarioBuilderForm() (~línea 2246-2257): quitar la línea
   `const vip = document.getElementById('scenario-vip-select');` y la línea
   `if (vip) vip.value = state.accountInfo.vipNameLocked ? 'yes' : 'no';`.

3. En applyScenarioBuilder() (~línea 2259-2285): quitar
   `const vip = document.getElementById('scenario-vip-select')?.value || 'no';`
   y `state.accountInfo.vipNameLocked = vip === 'yes';`. En el showToast final,
   quitar el fragmento `', VIP: ' + (state.accountInfo.vipNameLocked ? 'Yes' : 'No')`
   del mensaje.

4. Quitar la línea `state.accountInfo.vipNameLocked = false;` (~línea 1951) del
   estado inicial.

5. Quitar el bloque de notificación completo del modal de GCH Search
   (~línea 1521-1526):
   <div id="gch-vip-lock-note" class="notification notification--warning gch-vip-lock-note hidden">
     ...
   </div>
   y su regla CSS `.gch-vip-lock-note` (~línea 667).

6. En renderGchTakeoverActions() (~línea 3058-3070): quitar
   `const vipNote = document.getElementById('gch-vip-lock-note');`,
   `const locked = !!state.accountInfo.vipNameLocked;`, y
   `if (vipNote) vipNote.classList.toggle('hidden', !locked);`. Cambiar las 3
   líneas de disabled para que ya no usen `locked`:
   - `if (updateBtn) updateBtn.disabled = !hasSelection;`
   - `if (requestBtn) requestBtn.disabled = false;` (ver Prompt 3t, punto 2 —
     ya no depende de nada, siempre habilitado salvo que se agregue otra
     regla de negocio a futuro)
   - `if (createBtn) createBtn.disabled = !hasSelection;` (se queda como
     estaba antes de tocar VIP)

7. En updateAccountFromGchTakeover(), requestGchCaseFromTakeover() y
   createCidFromTakeover() (~línea 3078-3090): quitar
   `|| state.accountInfo.vipNameLocked` de cada guard `if (...) return;`
   (requestGchCaseFromTakeover() queda con el guard vacío, se puede quitar el
   `if` completo ya que no exige nada — revisar que no rompa la función).
```

## Prompt 4 — Modal "Scenario builder" para combinar escenarios del flujo GCH ✅ Listo

```
En index.html (raíz del proyecto) ya existe #simulation-select (dropdown
"Simulation" en sf-header) para alternar entre 'new' y 'existing' — ese
dropdown independiente se retira de sf-header y su selector se ABSORBE dentro
del Scenario builder como un campo más, para que todo el control de
escenarios (perfil de cuenta + flujo Void Contract → GCH) viva en un solo
lugar.

Agregar un control nuevo — un botón "Scenario builder" en sf-header (en el
lugar donde estaba el dropdown de Simulation) — que abre un modal (.modal /
.modal-overlay del design system) con selectores INDEPENDIENTES para cada
variable, de forma que se puedan combinar libremente en vez de depender de
combos fijos:

1. Modal #scenario-builder-modal, título "Scenario builder", con estos campos
   (usar [VDS] Dropdown Select / .select para cada uno):
   - "Account profile" → Select: "New account" | "Existing account" (controla
     state.simulationMode, mismo valor/lógica que hoy usa
     applySimulationPreset() — no crear un modo nuevo, solo mover el selector
     aquí).
   - "Contracts to void" → Select: "None" | "Found (shows void modal)"
     (controla state.mockHasContracts).
   - "GCH result" → Select: "High confidence" | "Duplicate" | "Multiple match"
     | "No match" (controla state.mockGchResult).
   - "GCH Search role" → Select: "Sales rep" | "Data Ops" (controla
    state.userRole del Prompt 3 — relevante cuando se abre el modal).
   - "Account already has VIP name" → Select: "No" | "Yes" (controla
     state.accountInfo.vipNameLocked del Prompt 3).

2. Footer del modal: botón secundario "Close" y botón primario "Apply
   scenario". Apply scenario:
   - Guarda los 5 valores elegidos en state (simulationMode, mockHasContracts,
     mockGchResult, userRole, accountInfo.vipNameLocked) — son las MISMAS
     variables que usan applySimulationPreset() (perfil de cuenta),
     hasExistingContracts() (Prompt 1), runGchCheck() (Prompt 2) y la vista de
     GCH Search (Prompt 3) cuando el flujo corre de verdad desde Edit account
     name — no crear variables duplicadas.
   - Si "Account profile" cambió respecto al valor actual, llamar
     applySimulationPreset(nuevoValor) igual que hacía el dropdown de
     Simulation antes de retirarse, para no perder ese comportamiento (este sí
     se refleja de inmediato en pantalla, porque es el perfil de datos base de
     toda la cuenta, no un paso del flujo GCH).
   - Apply scenario **NO** dispara el modal de void-contracts ni el banner de
     GCH result por sí solo — solo deja guardada la combinación en state. El
     modal (Prompt 1) y el banner (Prompt 2) deben aparecer únicamente cuando
     el usuario corre el flujo real de punta a punta (edita Account name →
     sube documento → "Save account name"), en el momento del flujo que le
     corresponde a cada uno, igual que pasaría sin el Scenario builder. La
     idea es poder armar el escenario de antemano y después demostrarlo
     completo desde cero, no saltar directo al resultado.
   - Cierra el modal y muestra un toast corto confirmando qué combinación
     quedó activa y que ya está lista para probarse desde Edit account name
     (ej. "Scenario applied — Existing account, Duplicate, Sales rep, VIP:
     No. Edit account name to try it.").

3. El objetivo es que estas mismas variables se respeten cuando después del
   Apply se edita account name y se da Save de verdad — el flujo en vivo debe
   leer la combinación elegida en el Scenario builder (state.mockHasContracts,
   state.mockGchResult, state.userRole, state.accountInfo.vipNameLocked) en
   vez de un valor fijo distinto, pero el disparo real de cada paso (loader,
   void-contracts, banner) sigue ocurriendo dentro de la secuencia de
   saveAccountNameFromModal() del Prompt 1, no desde el propio Apply scenario.
```

## Prompt 4b — Estilo del disparador "Scenario builder" (chip amarillo vivo + ícono de construcción) ✅ Listo

Hoy el disparador es `<button class="btn btn--secondary btn--small" onclick="openScenarioBuilderModal()">Scenario builder</button>`
(`index.html (raíz del proyecto)` ~línea 905).

Ajuste sobre la idea original (link con texto amarillo): un amarillo vivo
tipo `var(--color-yellow-600)` (#ffcd27) como color de TEXTO sobre fondo
blanco no pasa contraste de accesibilidad. La forma de tener ese amarillo
bien vivo sin ese problema es usarlo como fondo de un chip (texto negro
encima, alto contraste) — mismo truco que ya usa `.badge--yellow` en este
mismo archivo (`background-color: #ffcd27; color: #000;`). Así se ve mucho
más "vivo" que el texto amarillo oscuro planteado antes.

```
En index.html (raíz del proyecto), cambiar el disparador del Scenario builder
(~línea 905) de botón secundario a un chip:

1. Reemplazar el <button class="btn btn--secondary btn--small" ...> por un
   <button> (se queda como button, no como link, para que el chip se vea
   bien clickeable) con una clase nueva .chip--scenario-builder, fondo
   var(--color-yellow-600) (#ffcd27, el amarillo más vivo del DS), texto
   negro (var(--color-black)), border-radius var(--radius-max) (mismo
   radio que usan los badges/pills del DS), padding tipo badge/chip
   (var(--space-1x) var(--space-3x) aprox.), sin borde.

2. Ícono de construcción al inicio del texto: usar el set de íconos que ya
   está cargado en el archivo (Material Symbols Outlined — se ve en
   local_shipping, manage_accounts, arrow_forward ya usados en este mismo
   archivo). El ícono se llama "construction" en ese set — no importar un
   ícono nuevo de otra librería.
   <span class="material-symbols-outlined ui-icon--sm" aria-hidden="true">construction</span>
   seguido del texto "Scenario builder" (sin flecha "→" al final — el ícono
   de construcción ya al inicio es suficiente affordance, no hace falta
   repetir con flecha).

3. En :hover, oscurecer un poco el fondo (ej. var(--color-yellow-800) o un
   filter: brightness(0.95)) para dar feedback de interactivo, manteniendo
   el texto negro legible en todo momento.

4. Mantener el mismo onclick (openScenarioBuilderModal()) y la misma
   posición dentro de sf-header — solo cambia el estilo visual del
   disparador, no su comportamiento.
```

---

## Estado final del plan

Los prompts (1, 1b, 1c, 2, 2b, 2c, 2d, 3, 3b, 3c, 3d, 3e, 3f, 3g, 3h, 3i, 3j,
3k, 3l, 3m, 3n, 3o, 3p, 3q, 3r, 3s, 3t, 3u, 4, 4b) están ✅ Listos con datos
reales de Figma/Salesforce, ejecutables en orden. Cancel queda resuelto:
existe tanto en GCH Search (header y footer) como a lo largo de toda la
secuencia de actualización de Account name (Prompt 1, punto 3b). Queda solo
1 detalle menor sin bloquear la construcción (ver §3.1): si Sites
DUNS/Global DUNS se quitan del todo — se puede ajustar después con un
cambio pequeño una vez confirmado con Stephanie. También queda pendiente de
negocio (§3.1b, sin bloquear): si se necesita un botón independiente para
entrar a GCH Search en cualquier momento — Stephanie lo pregunta en la
reunión del 26 ago.
