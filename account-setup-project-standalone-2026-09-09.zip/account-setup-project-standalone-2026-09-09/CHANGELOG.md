# Changelog - Valu Cal Existing Accounts

All notable design changes to this flow are documented here.

---

## [2026-08-19]

### Added
- Unified Account name update loader sequence in `app/demos/account-setup.html` with staged states: "Reviewing existing contracts", contracts branch (Void Associated Contracts), and "Starting GCH review".
- Full-page GCH Search takeover in `app/demos/account-setup.html` with:
	- account/billing prefill,
	- Customer Info criteria,
	- searchable + sortable results table,
	- row selection,
	- role-based footer actions (Sales rep: Update Account / Request Case, Data Ops: Update Account / Create CID),
	- VIP lock handling.
- Scenario Builder modal in header with controls for:
	- contracts to void,
	- GCH result,
	- GCH Search role,
	- VIP lock state.

### Changed
- GCH action entrypoint now routes to the takeover experience for search/selection.
- GCH result handling now renders persistent page notifications for:
	- High confidence,
	- Duplicate,
	- Multiple match,
	- No match.
- Compliance GCH status copy now reflects specific outcome context (duplicate, multiple match, no match).

### Removed
- Retired legacy inline GCH subview block from Compliance section to avoid duplicated decision surfaces.

## [2026-07-10]

### Added
- Initial ecosystem flow for Valu Cal Existing Accounts linking to the imported valucal_existing_accounts.html screen.
