# Valu Cal Existing Accounts - Requirements

> **Purpose:** Provide an ecosystem-compliant entry point for the imported valucal_existing_accounts.html demo.

---

## Context

- **Tool area:** VaLu Cal
- **Target user role:** Sales Rep
- **Entry point:** From the VaLu Cal project list in the Prototype Viewer.

---

## User Stories

| ID    | As a...   | I want to...                                   | So that...                                     |
|-------|-----------|------------------------------------------------|------------------------------------------------|
| US-01 | Sales Rep | open the Existing Accounts prototype directly  | I can review the existing-account pricing flow |

---

## Acceptance Criteria

### US-01 - Open Existing Accounts screen
- **Given** I select Valu Cal Existing Accounts in the viewer
- **When** the flow page loads
- **Then** I can launch valucal_existing_accounts.html in a new tab

---

## States & Edge Cases

| State            | Trigger                             | Expected UI behavior                    |
|------------------|-------------------------------------|-----------------------------------------|
| default          | Flow page loads successfully        | Launch action is visible                |
| loading          | Opening or checking linked resource | Loading messaging can be shown          |
| validation-error | Linked file path is invalid         | Warning state indicates broken link     |

---

## Open Questions

- [ ] Should this flow remain a launch-wrapper page or be incrementally transformed into native ecosystem screens?
