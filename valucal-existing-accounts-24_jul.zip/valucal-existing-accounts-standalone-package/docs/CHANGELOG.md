# Changelog - Valu Cal Existing Accounts

All notable design changes to this flow are documented here.

---

## [2026-07-10]

### Added
- Initial ecosystem flow for Valu Cal Existing Accounts linking to the imported valucal_existing_accounts.html screen.
