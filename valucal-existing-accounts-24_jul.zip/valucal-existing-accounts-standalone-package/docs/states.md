# States - Valu Cal Existing Accounts

| State            | Trigger                       | Expected behavior                    | Deep link                 |
|------------------|-------------------------------|--------------------------------------|---------------------------|
| default          | Page loads                    | Launch button is visible             | `?state=default`          |
| loading          | Resource check in progress    | Loading indication may appear        | `?state=loading`          |
| validation-error | Linked path is missing/invalid| Validation warning is shown          | `?state=validation-error` |
