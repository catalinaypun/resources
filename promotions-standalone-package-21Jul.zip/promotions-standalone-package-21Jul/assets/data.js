(function () {
  var PLATFORM_OPTIONS = ["Reveal", "Fleet", "Reveal Starter", "Reveal+", "Reveal Pro", "Reveal Now"];
  var SEGMENT_OPTIONS = [
    "Micro", "SMB", "Government", "Enterprise", "Strategic", "Intl MICRO", "Intl SMB", "Intl MAJORS",
    "Intl Enterprise", "Intl Strategic", "Intl Government", "Reveal in Stores", "Mid Market"
  ];
  var COST_CENTER_OPTIONS = ["VZT TG ENT", "VZT TG F", "VZT TG SMB", "West", "WORKAUS1", "WORKIRL1", "WORKUK1"];
  var LEAD_SOURCE_OPTIONS = ["Marketing Inbound", "Partner Referral", "Outbound Cold"];
  var TRANSACTION_OPTIONS = [
    "Existing Business",
    "Re-Sign Business",
    "Existing Business - Blended",
    "Re-Sign Business - Blended",
    "New Business",
    "Rewrite Business"
  ];
  var INDUSTRY_OPTIONS = [
    "Transportation", "Construction", "Utilities", "Oil & Gas", "Healthcare", "Public Sector", "Retail", "Telecom"
  ];
  var PRICE_BOOK_OPTIONS = [
    { name: "US Standard Price Book", country: "USA", currency: "USD" },
    { name: "Canada Price Book", country: "CAN", currency: "CAD" },
    { name: "Mexico Price Book", country: "MEX", currency: "MXN" }
  ];
  /* placeholder - official product/feature list pending (Google Sheet from Subhojit) */
  var PRODUCT_CATALOG = {
    "VTU Only": { code: "P-10119" },
    "VTU + Forward Facing Camera": { code: "P-10120" },
    "VTU + Dual Camera": { code: "P-10121" },
    "Powered Asset": { code: "P-10122" },
    "Non-Powered Asset": { code: "P-10123" },
    "Vehicle Tracking Sub": { code: "P-10119" },
    "Asset Tracking": { code: "P-10124" },
    "Road Facing AI Dashcam": { code: "P-10125" },
    "Dual Channel AI Dashcam": { code: "P-10126" },
    "EVC Base": { code: "P-10127" },
    "EVC Premium": { code: "P-10128" },
    "Pro Installation": { code: "P-10129" },
    "Driver ID Keyfob": { code: "P-10130" },
    "NPAT": { code: "P-10131" },
    "VTU": { code: "P-10132" }
  };

  function tiers(basePrice, discountValue) {
    return [
      { minQty: 1, maxQty: 5, price: basePrice, discountValue: discountValue },
      { minQty: 6, maxQty: 19, price: +(basePrice - 2).toFixed(2), discountValue: discountValue },
      { minQty: 20, maxQty: 49, price: +(basePrice - 3.5).toFixed(2), discountValue: discountValue }
    ];
  }

  function child(id, name, terms, installType, deactivated, priceA, priceB, unlockPrice, discountType, discountValue) {
    return {
      id: id,
      name: name,
      terms: terms,
      freeMonthsRange: "1-5",
      unlockPrice: !!unlockPrice,
      discountType: discountType || "Percentage",
      installType: installType,
      transactionType: ["Existing Business", "New Business"],
      industry: ["Transportation", "Construction"],
      subType: "Expansion",
      deactivated: deactivated,
      products: [
        { productName: "NPAT", tiers: tiers(priceA, discountValue) },
        { productName: "VTU", tiers: tiers(priceB, discountValue) }
      ],
      pricingMatrix: []
    };
  }

  var PROMOTIONS = [
    {
      id: "PROMO-1001",
      name: "Flex Asset Promo - NEW: $50 BIC 100-199 UNITS",
      status: "Active",
      deactivated: false,
      startDate: "2025-12-01",
      endDate: "2026-06-30",
      extensionDate: "2026-07-31",
      submissionDate: "2025-11-15",
      owner: "Current User",
      manager: "Alicia Stone",
      description: "Q4 launch promo for mixed asset bundles and retention-ready discounts.",
      highlight: "$50 BIC for high-volume fleet installs",
      promotionType: "new-upsell-expansion",
      recordType: "Bundle",
      country: "USA",
      platform: ["Fleet", "Reveal+"],
      customerSegment: ["SMB", "Enterprise", "Mid Market"],
      costCenter: ["VZT TG ENT", "West"],
      leadSource: ["Marketing Inbound"],
      pricebook: "North America Commercial Pricebook",
      currency: "USD",
      promotionLanguage: "English",
      vbgVzwLead: true,
      adApprovalRequired: false,
      minMRR: 250,
      maxMRR: 12000,
      minTenure: 0,
      maxTenure: 60,
      contractFlexibility: true,
      purchaseType: "All-In Subscription Plan",
      pricingSheet: "FS-Q4-Enterprise-Primary",
      levelUpPricing: true,
      valueCalActive: true,
      valueCalPromoType: "Retention Bundle",
      children: [
        child("VZBUND12234", "10% OFF 36 MONTHS", 36, "CMI", false, 23, 22.5, true, "Percentage", 10),
        child("VZBUND12235", "$50 BIC 48 MONTHS", 48, "VCMI", false, 24, 23, true, "Dollar Off", 50)
      ]
    },
    {
      id: "PROMO-1002",
      name: "Reveal Starter Expansion Campaign - Government Lite 2026",
      status: "Developing",
      deactivated: false,
      startDate: "2026-01-10",
      endDate: "2026-09-30",
      extensionDate: "",
      submissionDate: "",
      owner: "Current User",
      manager: "Alicia Stone",
      description: "Pipeline campaign for government and public sector starter offers.",
      highlight: "Seasonal discount for public fleets",
      promotionType: "new-upsell-expansion",
      recordType: "Standalone",
      country: "CAN",
      platform: ["Reveal Starter", "Reveal"],
      customerSegment: ["Government", "Intl Government"],
      costCenter: [],
      leadSource: ["Partner Referral"],
      pricebook: "Canada Public Sector Pricebook",
      currency: "USD",
      promotionLanguage: "English/French",
      vbgVzwLead: false,
      adApprovalRequired: true,
      minMRR: 100,
      maxMRR: 8000,
      minTenure: 0,
      maxTenure: 36,
      contractFlexibility: false,
      purchaseType: "Equip Purchase w/no Commit",
      pricingSheet: "RS-GOV-2026",
      levelUpPricing: false,
      valueCalActive: false,
      valueCalPromoType: "",
      children: [
        child("VZBUND22010", "GOV 24M", 24, "CMI", false, 21.5, 21, false)
      ]
    },
    {
      id: "PROMO-1003",
      name: "Fleet Growth Bundle — Enterprise Strategic International",
      status: "Submitted",
      deactivated: false,
      startDate: "2026-02-01",
      endDate: "2026-12-31",
      extensionDate: "",
      submissionDate: "2026-01-15",
      owner: "Current User",
      manager: "Daniel Reeve",
      description: "Cross-market enterprise growth offer submitted for legal and finance review.",
      highlight: "Strategic accounts acceleration",
      promotionType: "new-upsell-expansion",
      recordType: "Bundle",
      country: "MEX",
      platform: ["Fleet", "Reveal Pro"],
      customerSegment: ["Strategic", "Intl Strategic", "Intl Enterprise"],
      costCenter: ["WORKUK1", "WORKIRL1"],
      leadSource: [],
      pricebook: "LATAM Enterprise Pricebook",
      currency: "USD",
      promotionLanguage: "Spanish",
      vbgVzwLead: true,
      adApprovalRequired: true,
      minMRR: 500,
      maxMRR: 20000,
      minTenure: 6,
      maxTenure: 72,
      contractFlexibility: true,
      purchaseType: "All-In Subscription Plan",
      pricingSheet: "FG-INTL-STRAT-2026",
      levelUpPricing: true,
      valueCalActive: true,
      valueCalPromoType: "Expansion",
      children: [
        child("VZBUND33001", "STRAT 36M", 36, "VCMI", false, 27, 26.5, true),
        child("VZBUND33002", "STRAT 48M", 48, "CMI", true, 26.5, 26, false),
        child("VZBUND33003", "STRAT 24M", 24, "CMI", false, 28, 27, true)
      ]
    },
    {
      id: "PROMO-1004",
      name: "Asset Tracking Re-Engagement Bundle — Mid Market Q3",
      status: "Active",
      deactivated: false,
      startDate: "2025-09-01",
      endDate: "2026-03-31",
      extensionDate: "2026-05-31",
      submissionDate: "2025-08-11",
      owner: "Current User",
      manager: "Maya Brooks",
      description: "Re-engagement offer for dormant mid market accounts with blended transactions.",
      highlight: "Win-back discount with fixed price",
      promotionType: "loyalty-retention",
      recordType: "Bundle",
      country: "USA",
      platform: ["Reveal", "Reveal+", "Reveal Pro"],
      customerSegment: ["Mid Market", "SMB"],
      costCenter: ["VZT TG SMB"],
      leadSource: ["Outbound Cold"],
      pricebook: "US Mid Market Pricebook",
      currency: "USD",
      promotionLanguage: "English",
      vbgVzwLead: false,
      adApprovalRequired: false,
      minMRR: 150,
      maxMRR: 9000,
      minTenure: 3,
      maxTenure: 48,
      contractFlexibility: true,
      purchaseType: "Equip Purchase w/no Commit",
      pricingSheet: "AT-MM-WINBACK",
      levelUpPricing: true,
      valueCalActive: false,
      valueCalPromoType: "",
      children: [
        child("VZBUND44001", "WINBACK 36M", 36, "CMI", false, 22, 21.5, false),
        child("VZBUND44002", "WINBACK 24M", 24, "VCMI", false, 23, 22, false)
      ]
    },
    {
      id: "PROMO-1005",
      name: "Legacy Fleet Compliance Offer — Sunset",
      status: "Expired",
      deactivated: true,
      startDate: "2024-01-01",
      endDate: "2024-12-31",
      extensionDate: "",
      submissionDate: "2023-12-15",
      owner: "Current User",
      manager: "Maya Brooks",
      description: "Legacy compliance promotion retained only for audit reference.",
      highlight: "Historical promotion",
      promotionType: "new-upsell-expansion",
      recordType: "Standalone",
      country: "USA",
      platform: ["Fleet"],
      customerSegment: ["Enterprise"],
      costCenter: ["VZT TG F"],
      leadSource: ["Marketing Inbound"],
      pricebook: "US Legacy Pricebook",
      currency: "USD",
      promotionLanguage: "English",
      vbgVzwLead: false,
      adApprovalRequired: false,
      minMRR: 0,
      maxMRR: 0,
      minTenure: 0,
      maxTenure: 0,
      contractFlexibility: false,
      purchaseType: "Equip Purchase w/no Commit",
      pricingSheet: "LEGACY-COMP",
      levelUpPricing: false,
      valueCalActive: false,
      valueCalPromoType: "",
      children: [
        child("VZBUND55001", "LEGACY 12M", 12, "CMI", true, 20, 19.5, false)
      ]
    },
    {
      id: "PROMO-1006",
      name: "New Business Reveal Now Offer — SMB Rapid Launch",
      status: "New",
      deactivated: false,
      startDate: "2026-04-15",
      endDate: "2026-11-30",
      extensionDate: "",
      submissionDate: "",
      owner: "Current User",
      manager: "Daniel Reeve",
      description: "Early-stage promo draft for Reveal Now accelerated onboarding.",
      highlight: "Fast start package",
      promotionType: "new-upsell-expansion",
      recordType: "Standalone",
      country: "CAN",
      platform: ["Reveal Now"],
      customerSegment: ["Micro", "SMB", "Intl SMB"],
      costCenter: [],
      leadSource: [],
      pricebook: "CAN SMB Launch Pricebook",
      currency: "USD",
      promotionLanguage: "English",
      vbgVzwLead: true,
      adApprovalRequired: false,
      minMRR: 75,
      maxMRR: 6000,
      minTenure: 0,
      maxTenure: 24,
      contractFlexibility: false,
      purchaseType: "All-In Subscription Plan",
      pricingSheet: "RN-SMB-LAUNCH",
      levelUpPricing: false,
      valueCalActive: true,
      valueCalPromoType: "Starter",
      children: [
        child("VZBUND66001", "SMB 24M", 24, "CMI", false, 24.5, 24, true)
      ]
    }
  ];

  function inferPromotionTypeFromName(name) {
    var text = String(name || "").toLowerCase();
    return /retention|re-?engagement|renewal|winback|loyalty/.test(text)
      ? "loyalty-retention"
      : "new-upsell-expansion";
  }

  function promo(id, name, status, startDate, endDate, country, platforms, segments, minMRR, maxMRR, childrenList) {
    return {
      id: id,
      name: name,
      status: status,
      deactivated: false,
      startDate: startDate,
      endDate: endDate,
      extensionDate: "",
      submissionDate: "",
      owner: "Current User",
      manager: "Alicia Stone",
      description: "Generated promotion for prototype list coverage.",
      highlight: "Prototype seeded data",
      promotionType: inferPromotionTypeFromName(name),
      recordType: "Bundle",
      country: country,
      platform: platforms,
      customerSegment: segments,
      costCenter: ["VZT TG ENT"],
      leadSource: ["Marketing Inbound"],
      pricebook: "Prototype Pricebook",
      currency: "USD",
      promotionLanguage: "English",
      vbgVzwLead: true,
      adApprovalRequired: false,
      minMRR: minMRR,
      maxMRR: maxMRR,
      minTenure: 0,
      maxTenure: 60,
      contractFlexibility: true,
      purchaseType: "All-In Subscription Plan",
      pricingSheet: "AUTO-SEED",
      levelUpPricing: true,
      valueCalActive: true,
      valueCalPromoType: "Expansion",
      children: childrenList
    };
  }

  PROMOTIONS = PROMOTIONS.concat([
    promo("PROMO-1007", "Q2 Expansion Sprint — Fleet + Reveal Pro", "Developing", "2026-05-01", "2026-12-15", "USA", ["Fleet", "Reveal Pro"], ["SMB", "Mid Market"], 200, 9500, [
      child("VZBUND77001", "EXP 24M", 24, "CMI", false, 23.5, 23, true),
      child("VZBUND77002", "EXP 36M", 36, "VCMI", false, 22.5, 22, true)
    ]),
    promo("PROMO-1008", "Public Sector Summer Push — Reveal Starter", "Submitted", "2026-06-01", "2026-10-31", "USA", ["Reveal Starter"], ["Government"], 100, 7000, [
      child("VZBUND88001", "GOV 18M", 18, "CMI", false, 21.5, 21, false)
    ]),
    promo("PROMO-1009", "Strategic Winback Initiative — International", "Active", "2026-03-01", "2026-12-31", "MEX", ["Fleet", "Reveal+"], ["Strategic", "Intl Strategic"], 600, 25000, [
      child("VZBUND99001", "STRAT 36M", 36, "VCMI", false, 28, 27.5, true),
      child("VZBUND99002", "STRAT 48M", 48, "VCMI", false, 27, 26.5, true)
    ]),
    promo("PROMO-1010", "SMB Jumpstart Bundle — Reveal + Fleet", "New", "2026-07-01", "2026-12-20", "CAN", ["Reveal", "Fleet"], ["Micro", "SMB"], 75, 5500, [
      child("VZBUND10101", "SMB 12M", 12, "CMI", false, 23, 22.5, true)
    ]),
    promo("PROMO-1011", "Enterprise Contract Booster — Reveal Pro", "Developing", "2026-08-01", "2027-01-31", "USA", ["Reveal Pro"], ["Enterprise", "Strategic"], 800, 30000, [
      child("VZBUND11101", "ENT 36M", 36, "VCMI", false, 29, 28.5, true)
    ]),
    promo("PROMO-1012", "Cross-Sell Momentum Offer — Reveal Now", "Submitted", "2026-05-15", "2026-11-15", "USA", ["Reveal Now", "Reveal+"], ["SMB", "Mid Market"], 180, 10000, [
      child("VZBUND12101", "MOMENTUM 24M", 24, "CMI", false, 24, 23.5, true),
      child("VZBUND12102", "MOMENTUM 36M", 36, "CMI", false, 23, 22.5, true)
    ]),
    promo("PROMO-1013", "Reveal+ Retention Accelerator — Mid Market", "Active", "2026-01-20", "2026-10-20", "USA", ["Reveal+"], ["Mid Market", "SMB"], 150, 11000, [
      child("VZBUND13101", "RET 24M", 24, "VCMI", false, 22.5, 22, true)
    ]),
    promo("PROMO-1014", "International Starter Drive — Fleet Essentials", "Developing", "2026-09-01", "2027-03-31", "MEX", ["Fleet"], ["Intl SMB", "Intl MICRO"], 60, 4500, [
      child("VZBUND14101", "INTL 18M", 18, "CMI", false, 21, 20.5, false)
    ]),
    promo("PROMO-1015", "Year-End Volume Builder — Enterprise Fleet", "Submitted", "2026-10-01", "2026-12-31", "USA", ["Fleet", "Reveal Pro"], ["Enterprise", "Strategic"], 900, 32000, [
      child("VZBUND15101", "VOL 36M", 36, "VCMI", false, 30, 29.5, true),
      child("VZBUND15102", "VOL 48M", 48, "VCMI", false, 29, 28.5, true)
    ]),
    promo("PROMO-1016", "Renewal Priority Track — Reveal Pro +", "Active", "2026-02-15", "2026-12-15", "CAN", ["Reveal Pro", "Reveal+"], ["Enterprise", "Mid Market"], 300, 14000, [
      child("VZBUND16101", "RENEW 24M", 24, "CMI", false, 25, 24.5, true)
    ])
  ]);

  var PRICING_TEMPLATES = [
    {
      id: "TPL-100",
      name: "Standard SMB Base Template",
      discountType: "Override Price",
      tiers: [
        { minQty: 1, maxQty: 5, value: 22.5 },
        { minQty: 6, maxQty: 19, value: 20.5 },
        { minQty: 20, maxQty: 49, value: 19.5 }
      ]
    },
    {
      id: "TPL-101",
      name: "Enterprise Volume Template",
      discountType: "% Off",
      tiers: [
        { minQty: 1, maxQty: 25, value: 8 },
        { minQty: 26, maxQty: 100, value: 12 }
      ]
    }
  ];

  window.APP_OPTIONS = {
    platform: PLATFORM_OPTIONS,
    customerSegment: SEGMENT_OPTIONS,
    costCenter: COST_CENTER_OPTIONS,
    leadSource: LEAD_SOURCE_OPTIONS,
    transactionType: TRANSACTION_OPTIONS,
    industry: INDUSTRY_OPTIONS,
    priceBooks: JSON.parse(JSON.stringify(PRICE_BOOK_OPTIONS)),
    countries: ["USA", "CAN", "MEX"],
    promotionTypes: ["new-upsell-expansion", "loyalty-retention"],
    purchaseType: ["--None--", "Equip Purchase w/no Commit", "All-In Subscription Plan"],
    valueCalPromoType: ["--None--", "Retention Bundle", "Expansion", "Starter", "Seasonal"]
  };
  window.PROMOTIONS = JSON.parse(JSON.stringify(PROMOTIONS));
  window.PRICING_TEMPLATES = JSON.parse(JSON.stringify(PRICING_TEMPLATES));
  window.PRODUCT_CATALOG = JSON.parse(JSON.stringify(PRODUCT_CATALOG));
  window.PROMOTIONS_SEED = window.PROMOTIONS;
  window.PRICING_TEMPLATES_SEED = window.PRICING_TEMPLATES;
}());
