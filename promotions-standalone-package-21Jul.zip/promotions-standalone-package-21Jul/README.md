# Promotions Standalone Package

Standalone package for sharing the Promotions Management prototype without depending on parent folders.

## Contents

- `index.html` - Promotions summary view
- `create-new.html` - Create/Edit promotion flow with child configuration
- `assets/ds/` - Verizon Design System assets (CSS, fonts, icons)
- `assets/slds-theme.css` - Flow-specific theme styles
- `assets/data.js` - Seed/options data used by the flow
- `assets/prototype-tools.js` - State/presenter helper utilities

## How to open

1. Open `index.html` in a browser.
2. Use the flow normally from that entry point.

## Notes

- All internal shared-asset paths were converted to local `./assets/...` references for portability.
- This package is intended for demo/review sharing.
