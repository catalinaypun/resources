/* ── Migrations (2026-11-04, low fidelity — per Leo / Shawnette, meetings 2026-11-03) ──────────────────────────────
   A legacy (non-MSA) account migrated to MSA. Same tool as Existing Business Renewal / Rewrap: the account on the
   left, the MSA options on the right. Differences:
   • Entry: Simulation Builder › Account type › "Legacy account (non-MSA)". The rep lands on the Proposal Dashboard; the
     top banner shows the legacy contracts summary; the dashboard's main button is "Migrate to MSA".
   • Top banner (where the MSA panel is): legacy contracts (count, out of renewal, next renewal), segment and the
     migration difficulty (how many inconsistencies to resolve — levels to be defined by Shawnette).
   • Left panel: totals Committed (what goes to the new contract) and Billing today; two sections Billing and To start
     billing (no status per line); alerts when vehicles with service (Reveal) don't match what's billed (One ERP).
   • Option 1 starts with everything committed; the rep decides what to keep.
   The demo data replaces existingOrders while the mode is on (restored when leaving it). Loaded after
   existing-accounts.js; it wraps renderMsaCommitmentPanel and the Simulation Builder (renderCurrentProposalCard asks
   migrationModeOn itself). */

var migrationModeOn = false;
var migrationDifficultySim = 'review'; // 'easy' (everything matches) | 'review' (vehicles with service not billed)
var migrationSavedExistingOrders = null;

const MIGRATION_LEGACY_ACCOUNT = {
  contractType: 'Flex', // legacy contract types to migrate: Flex, Fixed (Shawnette's doc 1.a.ii)
  contracts: 3,
  evergreen: 2, // auto-renewal (Evergreen) contracts
  nextRenewal: 'Feb 14, 2027', // next Evergreen renewal
  nextExpiration: 'Jun 30, 2027', // the non-Evergreen contract
  segment: 'SMB',
};

// Legacy lines (One ERP). serviced = vehicles with service in Reveal; it differs from billing by difficulty level.
function getMigrationLegacyLines() {
  const level = migrationDifficultySim;
  return [
    { id: 'lg-vtu', coreKey: 'vtu', coreName: 'VTU Only', qty: 10, basePrice: 35.00, stage: 'billing', serviced: level === 'easy' ? 10 : 20 },
    { id: 'lg-ffc', coreKey: 'vtu-ffc', coreName: 'VTU + Forward Facing Camera', qty: 10, basePrice: 65.00, stage: 'billing', serviced: 10 },
    { id: 'lg-powered', coreKey: 'asset-powered', coreName: 'Powered Asset', qty: 4, basePrice: 39.00, stage: 'billing', serviced: 4 },
    { id: 'lg-ffc-new', coreKey: 'vtu-ffc', coreName: 'VTU + Forward Facing Camera', qty: 6, basePrice: 65.00, stage: 'to-start', serviced: 0 },
  ].map(line => ({ ...line, baseCorePrice: line.basePrice, msaDiscountPct: 0, promoType: 'Standard', promoName: '', features: [] }));
}

function getMigrationAlerts() {
  const alerts = [];
  getMigrationLegacyLines().filter(l => l.stage === 'billing').forEach((line) => {
    if (line.serviced > line.qty) alerts.push(`${line.coreName}: ${line.serviced} vehicles with service, ${line.qty} billing \u2014 ${line.serviced - line.qty} not billed.`);
    else if (line.serviced < line.qty) alerts.push(`${line.coreName}: ${line.qty} billing, ${line.serviced} vehicles with service (could still be shipping or installing).`);
  });
  return alerts;
}

function getMigrationDifficulty() {
  return {
    easy: { text: 'Easy', tone: 'green' },
    review: { text: 'Needs review', tone: 'yellow' },
  }[migrationDifficultySim] || { text: 'Needs review', tone: 'yellow' };
}

// The committed lines become the account's "current" order, so options are seeded from them (createOptionFromCurrent).
function setMigrationData(on) {
  if (!Array.isArray(existingOrders)) return;
  if (on) {
    if (!migrationSavedExistingOrders) migrationSavedExistingOrders = existingOrders.splice(0, existingOrders.length);
    else existingOrders.splice(0, existingOrders.length);
    const committed = [];
    getMigrationLegacyLines().forEach((line) => {
      const same = committed.find(b => b.coreKey === line.coreKey && b.basePrice === line.basePrice);
      if (same) same.qty += line.qty;
      else committed.push({ ...line, id: line.id + '-committed', stage: undefined, serviced: undefined });
    });
    existingOrders.push({ id: 'legacy-contracts', name: 'Legacy contracts', term: 36, bundles: committed });
  } else if (migrationSavedExistingOrders) {
    existingOrders.splice(0, existingOrders.length, ...migrationSavedExistingOrders);
    migrationSavedExistingOrders = null;
  }
}

// ── Top banner (replaces the MSA panel) ──
function renderMigrationBanner() {
  const a = MIGRATION_LEGACY_ACCOUNT;
  // 2026-11-04 (Leo review): contract type next to Segment; contracts summary = how many, how many auto-renewal
  // (Evergreen), next renewal and next expiration. No migration difficulty until it's defined what determines it.
  return VC.accountSummaryPanel({
    headerTitle: 'Contract information', // 2026-11-04 (per Catalina): title; contract type first
    sections: [{
      metrics: [
        { label: 'Contract type', value: a.contractType, minWidth: 96 },
        { label: 'Contracts', value: String(a.contracts) },
        { label: 'Auto-renewal (Evergreen)', value: `${a.evergreen} of ${a.contracts}`, minWidth: 140 },
        { label: 'Next renewal', value: a.nextRenewal, minWidth: 96 },
        ...(a.contracts > a.evergreen ? [{ label: 'Next expiration', value: a.nextExpiration, minWidth: 96 }] : []),
        { label: 'Segment', value: a.segment, minWidth: 72 },
      ],
    }],
  });
}

// ── Left panel ──
function renderMigrationLegacyPanel() {
  const lines = getMigrationLegacyLines();
  const units = lines.reduce((sum, l) => sum + l.qty, 0);
  const priced = lines.map((line) => {
    const { unitPrice, monthly } = calcBundle(line, 36, 'Standard', units);
    const list = typeof getStandardUnitPrice === 'function' ? getStandardUnitPrice(line) : line.basePrice;
    return { line, unitPrice, monthly, list };
  });
  const sum = arr => arr.reduce((s, p) => s + p.monthly, 0);
  const billing = priced.filter(p => p.line.stage === 'billing');
  const toStart = priced.filter(p => p.line.stage === 'to-start');
  const row = p => ({
    name: p.line.coreName,
    qty: p.line.qty,
    monthlyHtml: formatMoney(p.monthly),
    unitHtml: formatMoney(p.unitPrice),
    listHtml: p.list - p.unitPrice > 0.005 ? formatMoney(p.list) : '',
  });
  // 2026-11-04 (per Catalina): committed shown as the sum of its parts (bar: Billing today / To start billing, in units
  // — QTY = vehicles), and Vehicles (Reveal) as a separate block: with service, and the mismatches.
  const qtyOf = arr => arr.reduce((s, p) => s + p.line.qty, 0);
  const committed = sum(priced);
  const billingShare = committed > 0 ? Math.round((sum(billing) / committed) * 100) : 0;
  const billingLines = lines.filter(l => l.stage === 'billing');
  const withService = billingLines.reduce((s, l) => s + l.serviced, 0);
  const notBilled = billingLines.reduce((s, l) => s + Math.max(0, l.serviced - l.qty), 0);
  const noService = billingLines.reduce((s, l) => s + Math.max(0, l.qty - l.serviced), 0);
  // 2026-11-04 (per Catalina): the vehicles count is the link to the vehicles modal (always); a warning icon with a
  // tooltip shows only when vehicles with service and billing don't match. No separate Vehicles block.
  // 2026-11-04 (Leo review): an explicit table — no mental math. Amounts (Billing, To start billing = Committed) with
  // the count before and dollars right-aligned; then the vehicles by status, incl. Service, not billed (overage).
  // 2026-11-04 (per Catalina): no Total row (it repeated the committed amount); every vehicle of the account is the link
  // to the vehicles modal, where the QTY used to be — "in total", since only Billing + To start billing are committed.
  const tableRow = (cls, label, count, amount) => `<tr class="${cls}"><td>${label}</td><td class="vc-migration-table__count">${count}</td><td class="vc-migration-table__amount">${amount}</td></tr>`;
  const totalVehicles = qtyOf(billing) + qtyOf(toStart) + notBilled;
  const totalsHtml = `<div class="vc-migration-totals">
      <div class="vc-migration-totals__head"><span class="vc-field-label">Committed</span><span class="current-proposal-total-qty">QTY <button type="button" class="text-link text-link--small" onclick="openMigrationVehicles()" aria-label="View the ${totalVehicles} vehicles">${totalVehicles}</button></span></div>
      <div class="monthly-amount">${formatMoney(committed)}<span>/month</span></div>
      <div class="vc-migration-bar" role="img" aria-label="${billingShare}% billing" style="--mig-billing-share:${billingShare}%"><span class="vc-migration-bar__billing"></span></div>
      <table class="vc-migration-table">
        <thead><tr><th>Vehicles</th><th class="vc-migration-table__count">QTY</th><th class="vc-migration-table__amount">Monthly</th></tr></thead>
        <tbody>
          ${tableRow('', '<span class="vc-migration-dot vc-migration-dot--billing"></span>Billing', qtyOf(billing), formatMoney(sum(billing)))}
          ${tableRow('', '<span class="vc-migration-dot"></span>To start billing', qtyOf(toStart), formatMoney(sum(toStart)))}
          ${notBilled ? tableRow('vc-migration-table__notbilled', '<span class="vc-migration-dot vc-migration-dot--notbilled"></span>Service, not billed', notBilled, '--') : ''}
        </tbody>
      </table>
    </div>`;
  // Account-level issues stay as a warning (vehicle mismatches are in the Vehicles block).
  const accountIssues = []; // account-level issues (e.g. missing primary contact) — none in the two demo scenarios
  const alertsHtml = accountIssues.length
    ? `<div class="notification notification--warning vc-migration-alert" role="status"><span class="material-symbols-outlined notification__icon" aria-hidden="true">warning</span><div class="notification__body"><div class="notification__title">Account information missing</div>${accountIssues.map(t => `<div class="notification__message">${t}</div>`).join('')}</div></div>`
    : '';
  return VC.currentSetupPanel({
    title: 'Legacy account',
    totalUnits: units,
    totalsHtml,
    alertsHtml,
    groups: [
      { title: 'Billing', icon: 'package_2', bundles: billing.map(row), emptyText: 'Nothing billing yet' },
      // 2026-11-04 (per Catalina): To start billing keeps its own clock icon; Billing uses the Current setup icon.
      { title: 'To start billing', icon: 'schedule', bundles: toStart.map(row), emptyText: 'Everything is billing' },
    ],
  });
}

// ── Vehicles (read only) ──
// 2026-11-04 (per Catalina): "View vehicles" (always on the legacy panel, not only with a mismatch) opens the Upsell
// vehicle table (same component, read only) in a modal. Status per vehicle = the Upsell statuses (Installed,
// Scheduled, Shipped, In fulfillment, Ordered); billing is a separate column of the vehicle row: Billing, To start
// billing, or "Not billed" (vehicle with service that isn't billed).
const MIGRATION_BILLING = { billing: 'Billing', toStart: 'To start', notBilled: 'Not billed' }; // vehicle table "Billing status"
function getMigrationVehicleRecords() {
  const records = [];
  let n = 1;
  const make = (line, billing, status) => {
    const serial = `LGC-${String(n).padStart(6, '0')}`;
    const sub = {
      id: `${line.id}-${n}`, serial, esn: serial,
      vin: `1LGC${String(n).padStart(5, '0')}VX${String(10 + (n * 7) % 89)}`,
      product: line.coreName, productKey: line.coreKey, features: line.features || [], bundleId: line.id,
      vehicleName: `Unit-${String(n).padStart(3, '0')}`,
      orderNumber: String(5003900000 + Math.floor(n / 6) * 37),
      techRef: `${1000000000 + n * 7919}-${2000000000 + n * 104729}`,
      subStatus: 'Active', deviceStatus: 'Active', isCore: true, linkedCoreSerial: null, parentEsn: '--',
    };
    n += 1;
    const r = vzVehicleRecord(sub);
    r.status = status;
    r.assigned = !['Ordered', 'In fulfillment'].includes(status);
    if (!r.assigned) { r.name = ''; r.vin = ''; r.make = ''; r.model = ''; r.plate = ''; r.year = ''; }
    r.hardware = vzSubscriptionHardware(sub, status);
    r.billingLabel = billing;
    return r;
  };
  const pending = ['Ordered', 'In fulfillment', 'Shipped', 'Scheduled'];
  getMigrationLegacyLines().forEach((line) => {
    if (line.stage === 'to-start') {
      for (let i = 0; i < line.qty; i++) records.push(make(line, MIGRATION_BILLING.toStart, pending[i % pending.length]));
      return;
    }
    const withService = Math.min(line.qty, line.serviced);
    for (let i = 0; i < withService; i++) records.push(make(line, MIGRATION_BILLING.billing, 'Installed'));
    for (let i = withService; i < line.qty; i++) records.push(make(line, MIGRATION_BILLING.billing, i % 2 ? 'Scheduled' : 'Shipped'));
    for (let i = line.qty; i < line.serviced; i++) records.push(make(line, MIGRATION_BILLING.notBilled, 'Installed'));
  });
  return records;
}
window.closeMigrationVehicles = function closeMigrationVehicles() {
  document.getElementById('migration-vehicles-overlay')?.remove();
  document.body.style.overflow = '';
};
window.openMigrationVehicles = function openMigrationVehicles() {
  if (typeof VZ_SEARCH_CHECKBOXES !== 'undefined') VZ_SEARCH_CHECKBOXES.migration = '.vz-migration-none';
  closeMigrationVehicles();
  const records = getMigrationVehicleRecords();
  document.body.insertAdjacentHTML('beforeend', `
    <div class="modal-overlay is-open" id="migration-vehicles-overlay" onclick="closeMigrationVehicles()">
      <div class="modal modal--lg migration-vehicles-modal" role="dialog" aria-modal="true" aria-labelledby="migration-vehicles-title" onclick="event.stopPropagation()">
        <button type="button" class="modal__close btn-icon btn-icon--ghost-vds btn-icon--vds-large" onclick="closeMigrationVehicles()" aria-label="Close"><span class="material-symbols-outlined" aria-hidden="true">close</span></button>
        <div class="modal__content migration-vehicles-modal__content">
          <div>
            <h2 class="modal__title" id="migration-vehicles-title">Vehicles</h2>
            <div class="bundle-modal-sub">Legacy account · ${records.length} vehicles and assets</div>
          </div>
          <div class="migration-vehicles-modal__body">${vzVehicleTableShellHtml('migration', '')}</div>
        </div>
      </div>
    </div>`);
  document.getElementById('gc-migration-thead').innerHTML = vzVehicleTableHeadHtml('migration', 4);
  document.getElementById('gc-migration-tbody').innerHTML = vzVehicleBlocksHtml(records, 'migration', []);
  vzInitVehicleSearch('migration');
  document.body.style.overflow = 'hidden';
};

// ── Vehicles with service, not billed → decided per option (2026-11-04, per Catalina — Leo, sync 11-03) ──
// Each option starts with what's committed. Vehicles with service that aren't billed are NOT in it. The rep decides with
// the customer which ones come over (they start billing in the MSA): all, some or none. Until then the option shows a
// warning with Manage vehicles; the modal lists them with checkboxes (none selected is valid) and, at the bottom, the
// customer's agreement ("the N selected will be billed, the M not selected won't be part of the MSA"), required to
// confirm. Once decided, the option shows a neutral line with the result and Manage to change it.
// What happens to the vehicles left out is still open (Leo / Shawnette — tracker Q-F9).
function getMigrationNotBilledRecords() {
  return getMigrationVehicleRecords().filter(r => r.billingLabel === MIGRATION_BILLING.notBilled);
}
window.migrationOptionNoticeHtml = function migrationOptionNoticeHtml(opt) {
  if (!migrationModeOn || !opt || opt.msaPreviewFor) return '';
  const total = getMigrationNotBilledRecords().length;
  if (!total) return '';
  const manage = `<button type="button" class="text-link text-link--small" onclick="openMigrationAddVehicles(${opt.id})">Manage vehicles</button>`;
  if (!opt.migrationNotBilledDecided) {
    return `<div class="notification notification--warning vc-migration-option-note" role="status"><span class="material-symbols-outlined notification__icon" aria-hidden="true">warning</span><div class="notification__body"><div class="notification__message">${total} vehicles have service but aren't billed. Decide with the customer which ones come over to the MSA. ${manage}</div></div></div>`;
  }
  const added = (opt.migrationAddedVehicleIds || []).length;
  const left = total - added;
  const result = added === total ? `All ${total} added` : added ? `${added} added · ${left} left out` : `None added · ${left} left out`;
  return `<div class="vc-migration-option-decision" role="status"><span class="vc-checklist__state vc-checklist__state--done vc-checklist__state--small" aria-hidden="true"><span class="material-symbols-outlined">check</span></span><span class="vc-migration-option-decision__text">Vehicles with service, not billed: <strong>${result}</strong></span>${manage}</div>`;
};
let migrationAddTargetOptId = null;
window.migrationSelectChanged = function migrationSelectChanged(selectionChanged = true) {
  const boxes = [...document.querySelectorAll('#gc-migration-select-tbody .gc-migsel-cb')];
  const n = boxes.filter(cb => cb.checked).length;
  const total = boxes.length;
  const all = document.getElementById('gc-migration-select-select-all');
  if (all) { all.checked = n === total && total > 0; all.indeterminate = n > 0 && n < total; }
  // The agreement names the numbers, so a new selection needs a new agreement.
  const agree = document.getElementById('migration-agree-check');
  if (agree && selectionChanged) agree.checked = false;
  const text = document.getElementById('migration-agree-text');
  if (text) {
    text.textContent = n === total
      ? `The customer agreed that all ${total} vehicles will be part of the MSA and start billing.`
      : n
        ? `The customer agreed that the ${n} selected vehicle${n === 1 ? '' : 's'} will be part of the MSA and start billing, and the ${total - n} not selected won't be part of it.`
        : `The customer agreed that none of these ${total} vehicles will be part of the MSA.`;
  }
  const btn = document.getElementById('migration-add-vehicles-btn');
  if (btn) btn.disabled = !(agree && agree.checked);
};
window.migrationSelectAll = function migrationSelectAll(checked) {
  document.querySelectorAll('#gc-migration-select-tbody .gc-migsel-cb').forEach(cb => { cb.checked = checked; });
  migrationSelectChanged();
};
window.closeMigrationAddVehicles = function closeMigrationAddVehicles() {
  document.getElementById('migration-add-vehicles-overlay')?.remove();
  document.body.style.overflow = '';
  migrationAddTargetOptId = null;
};
window.openMigrationAddVehicles = function openMigrationAddVehicles(optId) {
  const opt = options.find(o => o.id === optId);
  if (!opt) return;
  if (typeof VZ_SEARCH_CHECKBOXES !== 'undefined') VZ_SEARCH_CHECKBOXES['migration-select'] = '.gc-migsel-cb';
  closeMigrationAddVehicles();
  migrationAddTargetOptId = optId;
  const records = getMigrationNotBilledRecords();
  const optionLabel = typeof getOptionNumberText === 'function' ? getOptionNumberText(opt) : 'Option';
  document.body.insertAdjacentHTML('beforeend', `
    <div class="modal-overlay is-open" id="migration-add-vehicles-overlay" onclick="closeMigrationAddVehicles()">
      <div class="modal modal--lg migration-vehicles-modal" role="dialog" aria-modal="true" aria-labelledby="migration-add-vehicles-title" onclick="event.stopPropagation()">
        <button type="button" class="modal__close btn-icon btn-icon--ghost-vds btn-icon--vds-large" onclick="closeMigrationAddVehicles()" aria-label="Close"><span class="material-symbols-outlined" aria-hidden="true">close</span></button>
        <div class="modal__content migration-vehicles-modal__content">
          <div>
            <h2 class="modal__title" id="migration-add-vehicles-title">Vehicles with service, not billed</h2>
            <div class="bundle-modal-sub">${optionLabel} · select the ones that come over to the MSA (they start billing). You can leave all of them out.</div>
          </div>
          <div class="migration-vehicles-modal__body">${vzVehicleTableShellHtml('migration-select', '')}</div>
          <label class="checkbox migration-agree">
            <input type="checkbox" class="checkbox__input" id="migration-agree-check" onchange="migrationSelectChanged(false)">
            <span class="checkbox__content" id="migration-agree-text"></span>
          </label>
        </div>
        <div class="modal__actions migration-vehicles-modal__actions">
          <button type="button" class="btn btn--secondary btn--large" onclick="closeMigrationAddVehicles()">Cancel</button>
          <button type="button" class="btn btn--primary btn--large" id="migration-add-vehicles-btn" onclick="confirmMigrationAddVehicles()" disabled>Confirm</button>
        </div>
      </div>
    </div>`);
  document.getElementById('gc-migration-select-thead').innerHTML = vzVehicleTableHeadHtml('migration-select', 4);
  document.getElementById('gc-migration-select-tbody').innerHTML = vzVehicleBlocksHtml(records, 'migration-select', []);
  // The current decision comes preselected (editable).
  const added = new Set(opt.migrationAddedVehicleIds || []);
  document.querySelectorAll('#gc-migration-select-tbody .gc-migsel-cb').forEach(cb => { cb.checked = added.has(cb.value); });
  vzInitVehicleSearch('migration-select');
  migrationSelectChanged();
  document.body.style.overflow = 'hidden';
};
window.confirmMigrationAddVehicles = function confirmMigrationAddVehicles() {
  const opt = options.find(o => o.id === migrationAddTargetOptId);
  if (!opt) return closeMigrationAddVehicles();
  if (!document.getElementById('migration-agree-check')?.checked) return;
  const ids = [...document.querySelectorAll('#gc-migration-select-tbody .gc-migsel-cb:checked')].map(cb => cb.value);
  // Replace the previous decision: drop the lines it added, then add the new selection.
  opt.bundles = opt.bundles.filter(b => !b.migrationFromService);
  const records = getMigrationNotBilledRecords().filter(r => ids.includes(r.sub.id));
  const lines = getMigrationLegacyLines();
  const byLine = {};
  records.forEach(r => { byLine[r.sub.bundleId] = (byLine[r.sub.bundleId] || 0) + 1; });
  Object.entries(byLine).forEach(([lineId, qty]) => {
    const line = lines.find(l => l.id === lineId);
    if (!line) return;
    opt.bundles.push({
      ...line, id: `${lineId}-added-${Date.now()}`, qty, originalQty: qty, stage: undefined, serviced: undefined,
      migrationFromService: true,
    });
  });
  opt.migrationAddedVehicleIds = ids;
  opt.migrationNotBilledDecided = true;
  const total = getMigrationNotBilledRecords().length;
  const label = typeof getOptionNumberText === 'function' ? getOptionNumberText(opt) : 'the option';
  closeMigrationAddVehicles();
  renderOptions();
  if (typeof showSuccessBanner === 'function') {
    showSuccessBanner(`Vehicles updated in ${label}`, ids.length
      ? `${ids.length} of ${total} vehicles with service come over and start billing with the MSA.`
      : `None of the ${total} vehicles with service come over to the MSA.`);
  }
};

// ── Entry ──
window.startMigrationProposal = function startMigrationProposal() {
  if (typeof window.startRenewalRewrapProposal === 'function') window.startRenewalRewrapProposal();
};

function setMigrationMode(on) {
  if (migrationModeOn === on && !on) return;
  migrationModeOn = on;
  setMigrationData(on);
  document.body.classList.toggle('vc-migration-mode', on);
}

// ── Wraps ──
// Runs after every script (index.html declares the Simulation Builder functions after this file loads).
function wrapMigrationHooks() {
  // The left panel: renderCurrentProposalCard (scoped inside existing-accounts.js) checks migrationModeOn itself.
  const originalMsaPanel = typeof renderMsaCommitmentPanel === 'function' ? renderMsaCommitmentPanel : null;
  if (originalMsaPanel) {
    renderMsaCommitmentPanel = function (selectedVehicleCount, menuId, showKebab) {
      return migrationModeOn ? renderMigrationBanner() : originalMsaPanel.apply(this, arguments);
    };
  }
  // Confirm selection: a migration supersedes the legacy contracts and creates the MSA contract.
  const originalConfirm = typeof openConfirmSelectionForOption === 'function' ? openConfirmSelectionForOption : null;
  if (originalConfirm) {
    openConfirmSelectionForOption = function () {
      const result = originalConfirm.apply(this, arguments);
      const sub = document.getElementById('csm-option-subtext');
      const btn = document.getElementById('csm-confirm-btn');
      if (migrationModeOn) {
        if (sub) sub.textContent = 'This will lock the drafting session and generate the MSA contract that supersedes the legacy contracts.';
        if (btn) btn.textContent = 'Confirm & create contract';
      } else if (unifiedAccount && unifiedAccount.accountType === 'customer') {
        if (sub) sub.textContent = 'This will lock the drafting session and generate the order.';
        if (btn) btn.textContent = 'Confirm & create order';
      }
      return result;
    };
  }
  // Simulation Builder: "legacy" is a customer account in migration mode.
  const originalRead = typeof readSimulationBuilderAccount === 'function' ? readSimulationBuilderAccount : null;
  if (originalRead) {
    readSimulationBuilderAccount = function () {
      const account = originalRead.apply(this, arguments);
      if (document.getElementById('sim-builder-account-type-select')?.value === 'legacy') {
        account.accountType = 'customer';
        account.migration = true;
      }
      return account;
    };
  }
  const originalSync = typeof syncSimulationBuilderFields === 'function' ? syncSimulationBuilderFields : null;
  if (originalSync) {
    syncSimulationBuilderFields = function () {
      const result = originalSync.apply(this, arguments);
      const isLegacy = document.getElementById('sim-builder-account-type-select')?.value === 'legacy';
      document.getElementById('sim-builder-migration-difficulty-field')?.classList.toggle('hidden', !isLegacy);
      return result;
    };
  }
  const originalOpen = typeof openSimulationBuilderModal === 'function' ? openSimulationBuilderModal : null;
  if (originalOpen) {
    openSimulationBuilderModal = function () {
      const result = originalOpen.apply(this, arguments);
      const typeSelect = document.getElementById('sim-builder-account-type-select');
      if (typeSelect && migrationModeOn) typeSelect.value = 'legacy';
      const difficulty = document.getElementById('sim-builder-migration-difficulty-select');
      if (difficulty) difficulty.value = migrationDifficultySim;
      typeSelect?.dispatchEvent(new Event('change'));
      return result;
    };
  }
  const originalApply = typeof applySimulationBuilder === 'function' ? applySimulationBuilder : null;
  if (originalApply) {
    applySimulationBuilder = function () {
      const isLegacy = document.getElementById('sim-builder-account-type-select')?.value === 'legacy';
      const difficulty = document.getElementById('sim-builder-migration-difficulty-select')?.value;
      if (['easy', 'review'].includes(difficulty)) migrationDifficultySim = difficulty;
      if (isLegacy) setMigrationMode(true); else if (migrationModeOn) setMigrationMode(false);
      const result = originalApply.apply(this, arguments);
      if (isLegacy && typeof openQuotesList === 'function') openQuotesList(); // the migration starts on the dashboard
      return result;
    };
  }
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', wrapMigrationHooks); else wrapMigrationHooks();
