(function (global) {
  const configs = global.VC_UNIFIED_CONFIGS || (global.VC_UNIFIED_CONFIGS = {});

  configs['initial-sales'] = {
    id: 'initial-sales',
    label: 'Initial Sales',
    defaultRoute: 'dashboard',
    accountTypes: ['standard', 'pilot'],
    transactionTypes: [
      {
        id: 'new-account',
        label: 'New Account',
        entryPoint: 'initial-sales',
        accountTypes: ['standard', 'pilot'],
        optionModes: [],
      },
    ],
    routes: [
      'dashboard',
      'drafting',
      'account-validation',
      'configure-bundle',
      'discounts',
      'review',
      'contract',
      'fulfillment',
      'pilot-config',
    ],
  };
})(window);