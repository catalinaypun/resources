(function (global) {
  const configs = global.VC_UNIFIED_CONFIGS || {};
  const modules = [
    { id: 'proposal-table', label: 'Proposal table' },
    { id: 'msa-summary', label: 'MSA summary' },
    { id: 'pilot-summary', label: 'Pilot summary' },
    { id: 'options-board', label: 'Options board' },
  ];
  const moduleIds = new Set(modules.map(module => module.id));

  function resolve(search) {
    const params = new URLSearchParams(search || '');
    const flowId = params.get('flow') || 'initial-sales';
    const flow = configs[flowId];
    if (!flow) return { ok: false, error: 'unknown-flow' };

    const accountType = params.get('accountType') || flow.accountTypes[0];
    if (!flow.accountTypes.includes(accountType)) {
      return { ok: false, error: 'unknown-account-type' };
    }

    const requestedStatus = params.get('accountStatus');
    if ((requestedStatus !== null && (flowId !== 'existing-accounts' || !['active', 'inactive'].includes(requestedStatus)))) {
      return { ok: false, error: 'unknown-account-status' };
    }
    const accountStatus = flowId === 'existing-accounts' ? requestedStatus || 'active' : '';

    const pilotState = params.get('pilotState') || (accountType === 'pilot' ? 'not-configured' : '');
    if ((accountType === 'pilot' && !['not-configured', 'configured'].includes(pilotState)) ||
        (accountType !== 'pilot' && pilotState)) {
      return { ok: false, error: 'unknown-pilot-state' };
    }

    const pilotMsa = params.get('pilotMsa');
    if ((pilotMsa !== null && !['true', 'false'].includes(pilotMsa)) ||
        (pilotMsa !== null && (flowId !== 'initial-sales' || accountType !== 'pilot' || pilotState !== 'configured'))) {
      return { ok: false, error: 'unknown-pilot-msa' };
    }
    const pilotHasMsa = pilotMsa === 'true';

    const previousProposals = params.get('hasPreviousProposals');
    if ((previousProposals !== null && !['true', 'false'].includes(previousProposals)) ||
        (flowId === 'existing-accounts' && previousProposals !== null)) {
      return { ok: false, error: 'unknown-proposal-history' };
    }
    const hasPreviousProposals = previousProposals !== 'false';

    const accountValidation = params.get('accountValidation') || 'pending';
    if (!['ready', 'pending'].includes(accountValidation)) {
      return { ok: false, error: 'unknown-account-validation' };
    }

    const transactionTypeId = params.get('transactionType') || flow.transactionTypes[0]?.id;
    const transactionType = flow.transactionTypes.find(({ id }) => id === transactionTypeId);
    if (!transactionType) return { ok: false, error: 'unknown-transaction-type' };
    if (!transactionType.accountTypes.includes(accountType)) {
      return { ok: false, error: 'unsupported-account-transaction' };
    }

    const optionMode = params.get('optionMode') || transactionType.optionModes[0] || '';
    if (optionMode && !transactionType.optionModes.includes(optionMode)) {
      return { ok: false, error: 'unknown-option-mode' };
    }

    const requestedRoute = (params.get('route') || flow.defaultRoute || '').trim().toLowerCase();
    if (requestedRoute && !flow.routes.includes(requestedRoute)) {
      return { ok: false, error: 'unknown-route' };
    }
    const route = params.has('route') ? requestedRoute : (hasPreviousProposals ? requestedRoute : 'drafting');

    const modulesOff = (params.get('modulesOff') || '').split(',').filter(Boolean);
    if (modulesOff.some(id => !moduleIds.has(id)) ||
        new Set(modulesOff).size !== modulesOff.length) {
      return { ok: false, error: 'unknown-module' };
    }

    return {
      ok: true,
      selection: { flowId, accountType, accountStatus, pilotState, pilotHasMsa, hasPreviousProposals, accountValidation, transactionTypeId, optionMode, route, modulesOff },
      flow,
      transactionType,
    };
  }

  global.VC_UNIFIED_MODULES = modules;
  global.VC_UNIFIED = Object.assign(global.VC_UNIFIED || {}, { resolve });
})(window);