/* \u2500\u2500 Transaction configuration (Unified composer, 2026-10-09) \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
   One flow of reusable steps; each transaction picks its steps and gives values to the variables of
   each step's modules. The prototype reads this at runtime (js/flow-composer.js applies it), so what the
   composer shows is how the unified file is actually built.

   STEPS    \u2014 the step library (reused by every transaction).
   MODULES  \u2014 modules per step: where they render (selector), which accounts they exist for, variables.
              `locked` = decided by the account (domain model \u00a77: account-resolved), never by the admin.
   TRANSACTIONS \u2014 the transactions the unified file runs today (scenario = account + door). */
(function (global) {
  const STEPS = [
    { id: 'dashboard', name: 'Proposal Dashboard', optional: true, offNote: 'Skipped: the transaction starts in Drafting and the Proposals crumb goes away.' },
    { id: 'options', name: 'Proposal options', required: 'Every transaction builds its offer here.' },
    { id: 'configure-solution', name: 'Configure solution', optional: true, offNote: 'Skipped: options can\'t get new solutions (the + Add buttons go away).' },
    { id: 'send-proposal', name: 'Send proposal', optional: true, offNote: 'Skipped: no Send Proposal \u2014 the rep goes straight to Select & Create Contract.' },
    { id: 'contract', name: 'Contract', optional: true, offNote: 'Skipped: no Select & Create Contract \u2014 the transaction ends once the proposal is sent.' },
    { id: 'deal-result', name: 'Deal result', required: 'Every transaction records its result (won, lost, pending).' },
  ];

  // Option card: the variant (VC.OPTION_CARD_VARIANTS) brings its own texts (solutions title, + Add, main action).
  const OPTION_CARD_VARS = [
    { key: 'variant', label: 'Card variant', type: 'variant' },
    { key: 'maxOptions', label: 'Max options', type: 'select', options: [['', 'No limit'], ['1', '1'], ['2', '2'], ['3', '3'], ['4', '4'], ['5', '5']] },
  ];
  const VARIANT_LABELS = { new: 'New', pilot: 'Pilot', 'msa-preview': 'MSA preview (read-only)', modification: 'Modification', renewal: 'Renewal', rewrap: 'Rewrap', reactivation: 'Reactivation' };
  const ALL = ['prospect', 'pilot', 'customer'];
  // Each card variant runs on one scenario (the card's content comes from that account); choosing a variant
  // whose account differs moves the transaction to this scenario. msa-preview keeps the current one.
  const VARIANT_SCENARIOS = {
    new: { accountType: 'prospect', entryPoint: 'newProposal' },
    pilot: { accountType: 'pilot', contractedPilot: false, entryPoint: 'newProposal' },
    modification: { accountType: 'customer', cancellation: 'none', entryPoint: 'newProposal' },
    renewal: { accountType: 'customer', cancellation: 'none', entryPoint: 'renewalRewrap' },
    rewrap: { accountType: 'customer', cancellation: 'none', entryPoint: 'renewalRewrap' },
    reactivation: { accountType: 'customer', cancellation: 'full', entryPoint: 'reactivationReinstatement' },
  };

  // Every module of a screen is listed for every transaction.
  //   appliesTo: accounts where the screen can show it (otherwise listed, unchecked, with the reason).
  //   defaultOn: accounts where it starts checked (default: every account in appliesTo).
  //   selector: where it renders (unchecked hides it). Texts come from the component itself.
  //   render: the composer draws it itself (e.g. Account summary), so it works for any account.
  //   variants: option card parts \u2014 which card variants have them (the variant decides, not the account).
  const MODULES = [
    // 1 - Proposal Dashboard
    { id: 'account-summary', step: 'dashboard', name: 'Account summary', appliesTo: ALL, defaultOn: ['customer'], render: 'accountSummary', selector: '#msa-commitment-list-slot, #pilot-account-panel-slot',
      vars: [{ key: 'variant', label: 'Summary', type: 'select', options: [['msa', 'MSA (existing account)'], ['pilot', 'Pilot'], ['pilot-msa', 'Pilot + MSA conversion']] }] },
    { id: 'page-title', step: 'dashboard', name: 'Page title', appliesTo: ALL, selector: '#quotes-list-page-header-host .vc-page-header__title' },
    { id: 'page-subtitle', step: 'dashboard', name: 'Page description', appliesTo: ALL, selector: '#quotes-list-page-header-host .vc-page-header__subtitle' },
    { id: 'create-button', step: 'dashboard', name: 'Create proposal button', appliesTo: ALL, selector: '#btn-new-proposal' },
    { id: 'proposal-table', step: 'dashboard', name: 'Proposal table', appliesTo: ALL, selector: '#new-ql-table-host' },

    // 2 - Proposal options
    { id: 'msa-panel', step: 'options', name: 'MSA panel', appliesTo: ALL, defaultOn: ['customer'], render: 'msaDrafting', selector: '#msa-commitment-drafting-slot' },
    { id: 'approval-banner', step: 'options', name: 'Approval notification', appliesTo: ALL, selector: '#approval-snackbar-wrap', note: 'Shows when an option needs pricing approval' },
    { id: 'current-setup', step: 'options', name: 'Current / Previous setup', appliesTo: ['customer'], selector: '#current-proposal-panel' },
    { id: 'option-card', step: 'options', name: 'Option card', appliesTo: ALL, required: 'The options board is made of option cards', vars: OPTION_CARD_VARS },
    { id: 'transaction-switch', step: 'options', name: 'Renewal / Rewrap switch', parent: 'option-card', variants: ['renewal', 'rewrap'], selector: '.option-header-controls' },
    { id: 'pilot-summary', step: 'options', name: 'Pilot terms strip', parent: 'option-card', variants: ['pilot'], selector: '.pilot-summary' },
    { id: 'term', step: 'options', name: 'Contract term', parent: 'option-card', variants: ['new', 'renewal', 'rewrap'], selector: '.opt-term-cell' },
    { id: 'discounts-button', step: 'options', name: 'Discounts & Promotions', parent: 'option-card', variants: ['new', 'renewal', 'rewrap'], selector: '.opt-discount-cell' },
    { id: 'totals', step: 'options', name: 'Option totals', parent: 'option-card', appliesTo: ALL, selector: '.option-card-body > .opt-totals-row, .option-card-body > .bundle-stat-row' },
    { id: 'account-features', step: 'options', name: 'Account level features', parent: 'option-card', appliesTo: ALL, selector: '.bundles-label:has(+ .account-level-card), .account-level-card', note: 'Shows when the account has account-level features (Demo simulations)' },
    { id: 'solution-rows', step: 'options', name: 'Solution rows', parent: 'option-card', appliesTo: ALL, required: 'The solutions the option is made of' },

    // 3 - Configure solution
    { id: 'transaction-cards', step: 'configure-solution', name: 'Transaction type (first screen)', appliesTo: ['customer'], required: 'Existing accounts choose what the change does first' },
    { id: 'tx-upsell', step: 'configure-solution', name: 'Feature Upsell', parent: 'transaction-cards', appliesTo: ['customer'], selector: '#tx-card-upsell' },
    { id: 'tx-expansion', step: 'configure-solution', name: 'Expansion', parent: 'transaction-cards', appliesTo: ['customer'], selector: '#tx-card-add' },
    { id: 'tx-cancel', step: 'configure-solution', name: 'Cancel / Downgrade', parent: 'transaction-cards', appliesTo: ['customer'], selector: '#tx-card-cancel' },
    { id: 'tx-reactivate', step: 'configure-solution', name: 'Reactivate', parent: 'transaction-cards', appliesTo: ['customer'], selector: '#tx-card-reactivate', note: 'Only when something on the account was cancelled' },
    { id: 'solution-type', step: 'configure-solution', name: 'Bundle / \u00c0 la carte', appliesTo: ALL, locked: 'Decided by the account\'s Purchase mode (Scenario \u203a Account configuration)' },
    { id: 'cost-type', step: 'configure-solution', name: 'Opex / Capex', appliesTo: ALL, locked: 'Decided by the account\'s Cost type (Scenario \u203a Account configuration)' },
    { id: 'summary', step: 'configure-solution', name: 'Solution summary (right column)', appliesTo: ALL, selector: '#bundle-overlay .bundle-modal-preview' },

    // 4 - Send proposal
    { id: 'rep-info', step: 'send-proposal', name: 'Sales rep', appliesTo: ALL, selector: '#proposal-rep-inline-row' },
    { id: 'message', step: 'send-proposal', name: 'Customer message', appliesTo: ALL, selector: '.proposal-customization-thumb:has(#customization-message-preview)' },
    { id: 'pdf', step: 'send-proposal', name: 'Proposal PDF', appliesTo: ALL, selector: '.proposal-customization-thumb:has(#customization-pdf-preview)' },
    { id: 'case-studies', step: 'send-proposal', name: 'Case studies', appliesTo: ALL, selector: '#case-study-selector-wrap' },
    { id: 'roi', step: 'send-proposal', name: 'ROI calculator', appliesTo: ALL, selector: '#roi-config-section' },

    // 5 - Contract
    { id: 'readiness-gate', step: 'contract', name: 'Contract readiness gate', appliesTo: ALL, locked: 'Decided by the account readiness (Scenario \u203a Account configuration)' },
    { id: 'msa-panel', step: 'contract', name: 'MSA panel', appliesTo: ['customer'], selector: '#screen-contract > .msa-commitment-step-slot' },
    { id: 'contract-preview', step: 'contract', name: 'Contract preview', appliesTo: ALL, selector: '#contract-doc-viewer' },
    { id: 'contract-message', step: 'contract', name: 'Message to the customer', appliesTo: ALL, selector: '#contract-message-inline-fields, #contract-msg-preview-card' },
    { id: 'signature-tracking', step: 'contract', name: 'Signature and payment tracking', appliesTo: ALL, selector: '#sp-checklist-wrap' },

    // 6 - Deal result
    { id: 'msa-panel', step: 'deal-result', name: 'MSA panel', appliesTo: ['customer'], selector: '#screen-deal-result > .msa-commitment-step-slot' },
    { id: 'view-contract', step: 'deal-result', name: 'View Contract button', appliesTo: ALL, selector: '#deal-result-secondary-btn' },
  ];

  // Entry points of a step that can be removed (the flow skips it).
  const STEP_ENTRY_SELECTORS = {
    dashboard: '#breadcrumb-proposals-crumb, #breadcrumb-proposals-sep',
    'configure-solution': '.btn-add-bundle, #empty-state-btn',
    'send-proposal': '#drafting-review-btn, #footer-send',
    contract: '.btn-select-contract',
  };

  const allOn = { dashboard: true, options: true, 'configure-solution': true, 'send-proposal': true, contract: true, 'deal-result': true };
  const card = variant => ({ variant, maxOptions: '' });

  const TRANSACTIONS = [
    { id: 'initial-sale', name: 'Initial Sale', scenario: { accountType: 'prospect', entryPoint: 'newProposal' }, steps: { ...allOn },
      modules: { 'options.option-card': { on: true, vars: card('new') } } },
    { id: 'pilot', name: 'Pilot', scenario: { accountType: 'pilot', contractedPilot: false, entryPoint: 'newProposal' }, steps: { ...allOn },
      modules: { 'options.option-card': { on: true, vars: card('pilot') } } },
    { id: 'modification', name: 'Modification', scenario: { accountType: 'customer', cancellation: 'none', entryPoint: 'newProposal' }, steps: { ...allOn },
      modules: { 'options.option-card': { on: true, vars: card('modification') } } },
    { id: 'renewal-rewrap', name: 'Renewal / Rewrap', scenario: { accountType: 'customer', cancellation: 'none', entryPoint: 'renewalRewrap' }, steps: { ...allOn },
      modules: { 'options.option-card': { on: true, vars: card('renewal') } } },
    { id: 'reactivation', name: 'Reactivation', scenario: { accountType: 'customer', cancellation: 'full', entryPoint: 'reactivationReinstatement' }, steps: { ...allOn },
      modules: { 'options.option-card': { on: true, vars: card('reactivation') } } },
  ];

  global.VC_TX_CONFIG = { STEPS, MODULES, STEP_ENTRY_SELECTORS, TRANSACTIONS, VARIANT_LABELS, VARIANT_SCENARIOS };
})(window);
