(function (global) {
  const configs = global.VC_UNIFIED_CONFIGS || (global.VC_UNIFIED_CONFIGS = {});

  configs['existing-accounts'] = {
    id: 'existing-accounts',
    label: 'Existing Accounts',
    defaultRoute: 'dashboard',
    accountTypes: ['standard', 'pilot'],
    transactionTypes: [
      {
        id: 'new-proposal',
        label: 'New Proposal',
        entryPoint: 'newProposal',
        accountTypes: ['standard', 'pilot'],
        optionModes: ['Change'],
      },
      {
        id: 'renewal-rewrap',
        label: 'Renewal / Rewrap',
        entryPoint: 'renewalRewrap',
        accountTypes: ['standard', 'pilot'],
        optionModes: ['Renewal', 'Rewrap'],
      },
      {
        id: 'reactivation',
        label: 'Reactivation',
        entryPoint: 'reactivation',
        accountTypes: ['standard', 'pilot'],
        optionModes: ['Reactivation'],
      },
    ],
    routes: [
      'dashboard',
      'drafting',
      'account-validation',
      'configure-bundle',
      'select-transaction',
      'review',
    ],
  };
})(window);