/* ── Account validation + contract readiness gate (shared, 2026-10-09) ─────────────────────────
   Moved verbatim from both flows (they were identical). The flows keep the state they own
   (validationFields, accountValidationState, pendingContractSelectionId, clIdCompanyMatches…) and the
   screen markup; this file owns the readiness rule and the Account Validation field edits.
   Load after vc-drawer.js, before the flow's own script. */

function getContractBlockingValidationKeys() {
  return ['gch', 'billingAddress'].filter(key => !validationFields[key] || validationFields[key].status !== 'complete');
}

function isAccountReadyForContract() {
  return getContractBlockingValidationKeys().length === 0;
}

function applyAccountValidationSimulation(readiness) {
  const ready = readiness === 'ready';
  validationFields.gch.status = ready ? 'complete' : 'pending';
  validationFields.billingAddress.status = 'complete';
  accountValidationState.clId.status = ready ? 'assigned' : 'low-confidence';
  accountValidationState.billingAddress.status = 'valid';
  selectedClIdCompany = ready ? clIdCompanyMatches[0].id : '';
  requestedNewGch = false;
  renderValidationPageStatus();
  renderAccountValidationScreen();
}

function cancelAccountValidationGate() {
  pendingContractSelectionId = null;
  syncAccountValidationGateAction();
  closeAccountValidationModal();
}

function continueAfterAccountValidation() {
  const optionId = pendingContractSelectionId;
  if (optionId == null || !isAccountReadyForContract()) return;
  pendingContractSelectionId = null;
  closeAccountValidationModal();
  openConfirmSelectionForOption(optionId);
}

function renderValidationPageStatus() {
  const actionPendingKeys = ['gch', 'billingAddress'].filter((key) => validationFields[key].status !== 'complete');
  const confirmedKeys = Object.keys(validationFields).filter((key) => validationFields[key].status !== 'pending-confirmation');
  const completedCount = confirmedKeys.filter((key) => validationFields[key].status === 'complete').length;
  const totalConfirmed = confirmedKeys.length;
  const pct = totalConfirmed > 0 ? Math.round((completedCount / totalConfirmed) * 100) : 0;

  const allClear = actionPendingKeys.length === 0;

  const pendingEl = document.getElementById('validation-pending-count');
  if (pendingEl) pendingEl.textContent = allClear ? 'Ready to contract' : `${actionPendingKeys.length} action${actionPendingKeys.length === 1 ? '' : 's'} required before contract`;
  const completeEl = document.getElementById('validation-complete-count');
  if (completeEl) completeEl.textContent = allClear ? '' : `${completedCount} of ${totalConfirmed} complete`;
  const sepEl = document.getElementById('validation-progress-sep');
  if (sepEl) sepEl.style.display = allClear ? 'none' : '';
  const progressEl = document.getElementById('validation-progress-fill');
  if (progressEl) {
    progressEl.style.width = `${pct}%`;
    progressEl.style.background = allClear ? '#16A34A' : '#F59E0B';
  }

  // Hide Action items section and auto-expand Account information when all clear
  const actionSection = document.getElementById('validation-action-section');
  if (actionSection) actionSection.classList.toggle('hidden', allClear);
  if (allClear) validationSectionOpen['account-information'] = true;

  const actionBody = document.getElementById('validation-action-items-body');
  const actionHeader = actionBody?.previousElementSibling;
  const actionChipsWrap = document.getElementById('validation-action-chips');
  const actionCaret = actionHeader?.querySelector('.account-validation-accordion-caret');
  if (actionBody && actionHeader && actionCaret && actionChipsWrap) {
    const isOpen = !!validationSectionOpen['action-items'];
    actionBody.classList.toggle('hidden', !isOpen);
    actionHeader.classList.toggle('is-open', isOpen);
    actionCaret.textContent = isOpen ? 'expand_less' : 'expand_more';
    actionChipsWrap.classList.toggle('hidden', isOpen);
    actionChipsWrap.innerHTML = actionPendingKeys.map((key) => {
      const field = validationFields[key];
      return `<span class="account-validation-chip ${getValidationChipClass(field.status)}">${getValidationChipText(field, field.status)}</span>`;
    }).join('');
  }

  const accountBody = document.getElementById('validation-account-information-body');
  const accountHeader = accountBody?.previousElementSibling;
  const accountChipsWrap = document.getElementById('validation-account-chips');
  const accountCaret = accountHeader?.querySelector('.account-validation-accordion-caret');
  if (accountBody && accountHeader && accountCaret && accountChipsWrap) {
    const isOpen = !!validationSectionOpen['account-information'];
    accountBody.classList.toggle('hidden', !isOpen);
    accountHeader.classList.toggle('is-open', isOpen);
    accountCaret.textContent = isOpen ? 'expand_less' : 'expand_more';
    accountChipsWrap.classList.toggle('hidden', isOpen);
    const accountChipKeys = ['accountName', 'billingAddress', 'contractType', 'funnelStatus', 'totalFleet', 'totalAssets'];
    accountChipsWrap.innerHTML = accountChipKeys.map((key) => {
      const field = validationFields[key];
      return `<span class="account-validation-chip state-info">✓ ${field.label}</span>`;
    }).join('');
  }

  const actionRows = {
    gch: document.getElementById('validation-action-gch'),
    contact: document.getElementById('validation-action-contact'),
    billingAddress: document.getElementById('validation-action-billing'),
  };
  Object.entries(actionRows).forEach(([key, row]) => {
    if (!row) return;
    row.classList.toggle('hidden', validationFields[key].status === 'complete');
  });

  const infoRows = {
    gch: document.getElementById('validation-field-gch'),
    contact: document.getElementById('validation-field-contact'),
  };
  Object.entries(infoRows).forEach(([key, row]) => {
    if (!row) return;
    row.classList.toggle('hidden', validationFields[key].status !== 'complete');
  });

  const successEl = document.getElementById('validation-action-success');
  if (successEl) successEl.classList.toggle('hidden', actionPendingKeys.length !== 0);

  updateAccountBadgeFromValidation();
  syncAccountValidationGateAction();
}

function commitValidationFieldEdit(fieldKey) {
  const row = document.getElementById(`validation-field-${fieldKey}`);
  if (!row) return;
  const displayEl = row.querySelector('[data-display]');
  const inputEl = row.querySelector('[data-input]');
  if (!displayEl || !inputEl) return;
  let nextValue = '';
  if (inputEl.tagName === 'SELECT') {
    nextValue = inputEl.value.trim();
  } else {
    nextValue = inputEl.value.trim();
  }
  displayEl.textContent = nextValue || '—';
  displayEl.classList.remove('hidden');
  inputEl.classList.add('hidden');

  if (fieldKey === 'contract-type') {
    proposalData.contractType = nextValue || 'Flex';
    const vcmiContextEl = document.getElementById('header-prop-vcmi-context');
    if (vcmiContextEl) vcmiContextEl.textContent = getVcmiContextLabel();
  }

  if (fieldKey === 'billing-address') {
    const hasValue = !!nextValue;
    validationFields.billingAddress.status = hasValue ? 'complete' : 'pending';
    renderValidationPageStatus();
  }
}
