/* \u2500\u2500 Transaction composer (Unified, 2026-10-09) \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
   Lives in the Simulation Builder drawer ("Composer" tab). The real prototype behind the drawer is the
   live view: picking a transaction applies its scenario, picking a step opens that screen, and switching
   a module or changing a variable updates the screen right away.
   Data: config/transactions.config.js (steps, modules, base transactions). Transactions created here are
   copies of a base one with their own values; they are kept in this browser (localStorage). */
(function (global) {
  'use strict';
  const CFG = () => global.VC_TX_CONFIG;
  const STORE_KEY = 'valuCal.transactionComposer.v2';
  const esc = v => String(v == null ? '' : v).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const clone = o => JSON.parse(JSON.stringify(o));

  let transactions = [];      // base + custom, editable copies
  let activeId = 'initial-sale';
  let stepId = 'options';
  let message = '';
  let applied = false;        // the composer only drives the page once it has been opened

  function load() {
    transactions = clone(CFG().TRANSACTIONS);
    try {
      const saved = JSON.parse(global.localStorage.getItem(STORE_KEY) || 'null');
      if (saved && Array.isArray(saved.transactions)) {
        saved.transactions.forEach(tx => {
          const i = transactions.findIndex(t => t.id === tx.id);
          if (i >= 0) transactions[i] = tx; else transactions.push(tx);
        });
      }
    } catch (e) { /* storage unavailable: base transactions only */ }
  }
  function persist() {
    try {
      global.localStorage.setItem(STORE_KEY, JSON.stringify({ transactions }));
      return true;
    } catch (e) { return false; }
  }

  const active = () => transactions.find(t => t.id === activeId) || transactions[0];
  const accountOf = tx => tx.scenario.accountType;
  const ACCOUNT_LABELS = { prospect: 'new', pilot: 'pilot', customer: 'existing' };
  const modulesFor = sid => CFG().MODULES.filter(m => m.step === sid);
  const cardVariant = tx => (((tx.modules || {})['options.option-card'] || {}).vars || {}).variant || 'new';
  const available = (m, tx) => m.variants ? m.variants.includes(cardVariant(tx)) : (!m.appliesTo || m.appliesTo.includes(accountOf(tx)));
  const unavailableNote = (m, tx) => m.variants
    ? `Not part of the ${(CFG().VARIANT_LABELS || {})[cardVariant(tx)] || cardVariant(tx)} card`
    : `Needs ${m.appliesTo.map(a => (ACCOUNT_LABELS[a] === 'existing' ? 'an existing' : 'a ' + ACCOUNT_LABELS[a])).join(' or ')} account \u2014 change it in Scenario`;
  const key = m => `${m.step}.${m.id}`;
  function defaultVars(m, tx) {
    if (m.id === 'account-summary') return { variant: accountOf(tx) === 'pilot' ? (tx.scenario.pilotHasMsa ? 'pilot-msa' : 'pilot') : 'msa' };
    return {};
  }
  function moduleState(m, tx) {
    const s = (tx.modules || {})[key(m)];
    const defOn = available(m, tx) && (!m.defaultOn || m.defaultOn.includes(accountOf(tx)));
    return { on: s && s.on != null ? s.on !== false : defOn, vars: { ...defaultVars(m, tx), ...((s && s.vars) || {}) } };
  }
  function setModule(m, patch) {
    const tx = active();
    tx.modules = tx.modules || {};
    const cur = tx.modules[key(m)] || { on: true, vars: {} };
    tx.modules[key(m)] = { on: patch.on != null ? patch.on : cur.on, vars: { ...(cur.vars || {}), ...(patch.vars || {}) } };
  }
  const usedBy = sid => transactions.filter(t => t.steps[sid] !== false).length;

  // \u2500\u2500 Apply the active transaction to the page \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
  function styleEl() {
    let el = document.getElementById('tx-composer-rules');
    if (!el) { el = document.createElement('style'); el.id = 'tx-composer-rules'; document.head.appendChild(el); }
    return el;
  }
  function optionCardVars() {
    const tx = active();
    const m = CFG().MODULES.find(x => x.step === 'options' && x.id === 'option-card');
    return moduleState(m, tx).vars;
  }
  function applyRules() {
    if (!applied) return;
    const tx = active();
    const hidden = [];
    CFG().MODULES.forEach(m => {
      if (!m.selector || m.locked || m.required || !available(m, tx)) return;
      if (tx.steps[m.step] === false || !moduleState(m, tx).on) hidden.push(m.selector);
    });
    Object.entries(CFG().STEP_ENTRY_SELECTORS).forEach(([sid, sel]) => { if (tx.steps[sid] === false) hidden.push(sel); });
    const max = parseInt(optionCardVars().maxOptions, 10);
    const list = typeof options !== 'undefined' && Array.isArray(options) ? options : [];   // the page's `let options`
    const count = list.filter(o => !o.msaPreviewFor).length;
    if (max && count >= max) hidden.push('.add-option-card', '.option-card-header-actions .btn-icon[title="Clone"]');
    styleEl().textContent = hidden.length ? hidden.join(',\n') + ' { display: none !important; }' : '';
    // Modules the composer draws itself.
    CFG().MODULES.forEach(m => { if (m.render && RENDERERS[m.render]) RENDERERS[m.render](moduleState(m, tx), tx); });
  }
  // Account summary on the dashboard: MSA panel, Pilot, or Pilot + MSA (demo data), for any account.
  const RENDERERS = {
    msaDrafting(st, tx) {
      const slot = document.getElementById('msa-commitment-drafting-slot');
      if (!slot || !st.on || typeof global.renderMsaCommitmentPanel !== 'function') return;
      const extra = typeof global.getDraftingMsaAdditionalVehicles === 'function' ? global.getDraftingMsaAdditionalVehicles() : 0;
      slot.innerHTML = global.renderMsaCommitmentPanel(extra, 'msa-commitment-menu', false);
    },
    accountSummary(st) {
      const msaSlot = document.getElementById('msa-commitment-list-slot');
      const pilotSlot = document.getElementById('pilot-account-panel-slot');
      if (!msaSlot || !pilotSlot) return;
      if (!st.on) return;  // hidden by the selector rule
      const v = st.vars.variant || 'msa';
      if (v === 'msa') {
        pilotSlot.innerHTML = '';
        if (typeof global.renderMsaCommitmentPanel === 'function') msaSlot.innerHTML = global.renderMsaCommitmentPanel(0, 'msa-commitment-menu-list', typeof global.startRenewalRewrapProposal === 'function' && accountOf(active()) === 'customer');
      } else if (global.VC_UNIFIED && typeof global.VC_UNIFIED.configuredPilotSummary === 'function') {
        msaSlot.innerHTML = '';
        pilotSlot.innerHTML = global.VC.accountSummaryPanel(global.VC_UNIFIED.configuredPilotSummary(v === 'pilot-msa'));
      }
    },
  };

  // The option card variant reaches the shared card through its hook (assets-shared/js/vc-option-card.js);
  // the card's texts come from that variant.
  global.VC = global.VC || {};
  global.VC.optionCardVariables = function (variant) {
    if (!applied || variant === 'msa-preview') return null;
    const v = optionCardVars();
    const out = {};
    if (v.variant) out.variant = v.variant;
    return out;
  };
  function rerender() {
    if (typeof global.renderOptions === 'function') global.renderOptions();
    applyRules();
  }

  // Where the page is now, so opening the composer doesn't move it.
  function currentStep() {
    const shown = id => { const el = document.getElementById(id); return !!el && !el.classList.contains('hidden') && el.style.display !== 'none'; };
    const open = id => { const el = document.getElementById(id); return !!el && (el.classList.contains('is-open') || el.classList.contains('open') || el.style.display === 'flex' || el.style.display === 'block'); };
    if (shown('screen-deal-result')) return 'deal-result';
    if (shown('screen-contract')) return 'contract';
    if (open('proposal-review-overlay')) return 'send-proposal';
    if (open('bundle-overlay')) return 'configure-solution';
    if (shown('screen-quotes-list')) return 'dashboard';
    return 'options';
  }
  // The transaction that matches the scenario already on screen (built-in ones first).
  function matchingTransaction() {
    if (typeof unifiedAccount === 'undefined') return null;   // the page's `let unifiedAccount`
    const acc = unifiedAccount;
    const same = sc => Object.keys(sc).every(k => acc[k] === sc[k]);
    const tx = transactions.filter(t => !t.custom).find(t => same(t.scenario));
    return tx ? tx.id : null;
  }

  function applyTransaction() {
    const tx = active();
    applied = true;
    global.applyUnifiedAccount({ ...tx.scenario });
    // Without the Dashboard step the transaction starts in Drafting (the page's `let hasPreviousProposals`).
    if (typeof hasPreviousProposals !== 'undefined') hasPreviousProposals = tx.steps.dashboard !== false || tx.scenario.accountType === 'customer';
    if (typeof global.syncUnifiedScenarioUrl === 'function') global.syncUnifiedScenarioUrl();
    goToStep(stepId);
  }

  // Open the screen of a step for the active transaction (sample data where the flow has it).
  function goToStep(sid) {
    const tx = active();
    const type = tx.scenario.accountType;
    const door = tx.scenario.entryPoint;
    const openOptions = () => {
      if (type === 'customer') {
        if (door === 'renewalRewrap') global.startRenewalRewrapProposal();
        else if (door === 'reactivationReinstatement') global.startReactivationProposal();
        else global.openDraftingQuoteFromList();
      } else {
        global.openLibraryPreviewDrafting(type === 'pilot');
      }
    };
    // Close whatever the previous step left open (Configure Solution, Send Proposal, drawer).
    ['closeBundleModal', 'hideProposalReviewModal', 'closeOptPromoDrawer'].forEach(fn => { try { if (typeof global[fn] === 'function') global[fn](); } catch (e) { /* not open */ } });
    if (sid === 'dashboard') {
      if (tx.steps.dashboard === false) openOptions(); else global.openQuotesList();
    } else if (sid === 'configure-solution') {
      openOptions();
      setTimeout(() => { global.openConfigureBundle(); rerender(); }, 0);
    } else if (sid === 'send-proposal') {
      openOptions();
      if (typeof global.showProposalReviewModal === 'function') setTimeout(() => { global.showProposalReviewModal(); rerender(); }, 0);
    } else if (sid === 'contract') {
      openOptions();
      const first = typeof options !== 'undefined' && options.find(o => !o.msaPreviewFor);
      if (first && typeof global.createContract === 'function') { global.selectedOpt = first; try { global.createContract(first.id); } catch (e) { /* stays on options */ } }
    } else if (sid === 'deal-result') {
      openOptions();
      if (typeof global.enterDealResult === 'function') global.enterDealResult('won');
    } else {
      openOptions();
    }
    rerender();
  }

  // \u2500\u2500 Drawer UI \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
  function readBack(tx) {
    const lines = [`${tx.name} \u2014 ${tx.custom ? 'custom transaction based on ' + tx.basedOn : 'transaction'} \u00b7 account: ${accountOf(tx)} \u00b7 door: ${tx.scenario.entryPoint}`];
    CFG().STEPS.forEach((s, i) => {
      const on = tx.steps[s.id] !== false;
      lines.push(`Step ${i + 1}: ${s.name}${on ? '' : ' \u2014 skipped'}`);
      if (!on) return;
      modulesFor(s.id).forEach(m => {
        const st = moduleState(m, tx);
        const vars = Object.entries(st.vars).filter(([, v]) => v !== '' && v != null).map(([k, v]) => `${k}=${v}`).join(', ');
        lines.push(`  ${m.parent ? '  ' : ''}${m.name}: ${m.locked ? 'decided by the account' : m.required ? 'always' : !available(m, tx) ? 'n/a for this account' : (st.on ? 'on' : 'off')}${vars ? ' \u00b7 ' + vars : ''}`);
      });
    });
    return lines.join('\n');
  }

  function varField(m, v, value, vars) {
    const call = `VCFlowComposer.setVar('${m.step}','${m.id}','${v.key}',this.value)`;
    if (v.type === 'variant') {
      const labels = CFG().VARIANT_LABELS || {};
      const ids = Object.keys((global.VC && global.VC.OPTION_CARD_VARIANTS) || labels);
      return `<label class="tx-composer-var"><span>${esc(v.label)}</span><select class="select select--small" onchange="${call}">${ids.map(id => `<option value="${esc(id)}"${value === id ? ' selected' : ''}>${esc(labels[id] || id)}</option>`).join('')}</select></label>`;
    }
    return `<label class="tx-composer-var"><span>${esc(v.label)}</span><select class="select select--small" onchange="${call}">${v.options.map(([val, label]) => `<option value="${esc(val)}"${String(value || '') === val ? ' selected' : ''}>${esc(label)}</option>`).join('')}</select></label>`;
  }

  function moduleRow(m, tx) {
    const st = moduleState(m, tx);
    const can = available(m, tx);
    const call = `VCFlowComposer.toggleModule('${m.step}','${m.id}',this.checked)`;
    const control = m.locked
      ? `<span class="material-symbols-outlined tx-composer-lock" aria-hidden="true" title="Decided by the account">lock</span>`
      : m.required
        ? `<span class="material-symbols-outlined tx-composer-lock" aria-hidden="true" title="Always part of this screen">check_circle</span>`
        : `<input type="checkbox" class="checkbox__input" ${can && st.on ? 'checked' : ''} ${can ? '' : 'disabled'} onchange="${call}" aria-label="Show ${esc(m.name)}">`;
    const showVars = (m.required || (can && st.on)) && !m.locked;
    const vars = showVars ? (m.vars || []).map(v => varField(m, v, st.vars[v.key], st.vars)).join('') : '';
    const note = m.locked || m.required || (!can ? unavailableNote(m, tx) : m.note || '');
    return `<div class="tx-composer-module${m.parent ? ' tx-composer-module--child' : ''}${can ? '' : ' is-unavailable'}">
        <label class="tx-composer-module-row">${control}<span>${esc(m.name)}</span></label>
        ${note ? `<div class="tx-composer-note">${esc(note)}</div>` : ''}
        ${vars ? `<div class="tx-composer-vars">${vars}</div>` : ''}
      </div>`;
  }

  function render() {
    const host = document.getElementById('tx-composer');
    if (!host || !CFG()) return;
    const tx = active();
    const steps = CFG().STEPS;
    const step = steps.find(s => s.id === stepId) || steps[1];
    const stepOn = tx.steps[step.id] !== false;
    const mods = modulesFor(step.id);
    host.innerHTML = `
      <p class="tx-composer-lead">Every transaction runs the same steps with the same modules \u2014 only the variables change. Changes show on the screen behind the drawer.</p>
      <div class="tx-composer-tx">
        <label class="vc-field-label" for="tx-composer-select">Transaction</label>
        <select class="select" id="tx-composer-select" onchange="VCFlowComposer.selectTransaction(this.value)">
          ${transactions.map(t => `<option value="${esc(t.id)}"${t.id === tx.id ? ' selected' : ''}>${esc(t.name)}${t.custom ? ' (custom)' : ''}</option>`).join('')}
        </select>
        <div class="tx-composer-tx-actions">
          <button type="button" class="btn btn--secondary btn--small" onclick="VCFlowComposer.startNew()">New transaction</button>
          ${tx.custom ? `<button type="button" class="btn btn--secondary btn--small" onclick="VCFlowComposer.removeCustom()">Delete</button>` : ''}
        </div>
        <div class="tx-composer-new hidden" id="tx-composer-new">
          <label class="vc-field-label" for="tx-composer-new-name">Name (starts as a copy of ${esc(tx.name)})</label>
          <input class="input" id="tx-composer-new-name" placeholder="Fleet expansion with renewal">
          <button type="button" class="btn btn--primary btn--small" onclick="VCFlowComposer.createNew()">Create</button>
        </div>
      </div>

      <h3 class="sim-builder-section-title">Steps</h3>
      <ol class="tx-composer-steps">
        ${steps.map((s, i) => {
          const on = tx.steps[s.id] !== false;
          return `<li class="tx-composer-step${s.id === step.id ? ' is-active' : ''}${on ? '' : ' is-off'}">
            ${s.optional ? `<input type="checkbox" class="checkbox__input" ${on ? 'checked' : ''} onchange="VCFlowComposer.toggleStep('${s.id}',this.checked)" aria-label="Use step ${esc(s.name)}">` : '<span class="material-symbols-outlined tx-composer-lock" aria-hidden="true" title="Always part of the flow">check_circle</span>'}
            <button type="button" onclick="VCFlowComposer.selectStep('${s.id}')"><span>${i + 1} ${esc(s.name)}</span><small>${on ? `Reused by ${usedBy(s.id)} of ${transactions.length} transactions${s.required ? ' \u00b7 ' + esc(s.required) : ''}` : esc(s.offNote || 'Skipped in this transaction')}</small></button>
          </li>`;
        }).join('')}
      </ol>

      <h3 class="sim-builder-section-title">Modules \u00b7 ${esc(step.name)}</h3>
      <p class="tx-composer-note">${stepOn ? `${mods.length} modules on this screen. Switch them off or change their variables \u2014 the screen behind updates.` : esc(step.offNote || 'This step is skipped.')}</p>
      <div class="tx-composer-modules${stepOn ? '' : ' is-off'}">${mods.map(m => moduleRow(m, tx)).join('') || '<p class="tx-composer-note">No configurable modules on this step yet.</p>'}</div>

      <details class="tx-composer-readback">
        <summary>Configuration (what development implements)</summary>
        <pre>${esc(readBack(tx))}</pre>
      </details>
      <div class="tx-composer-status" role="status" aria-live="polite">${esc(message)}</div>`;
  }

  // \u2500\u2500 Actions \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
  const api = {
    render() { if (!transactions.length) load(); render(); },
    open() {
      if (!transactions.length) load();
      stepId = currentStep();
      const match = matchingTransaction();
      if (match) { activeId = match; applied = true; rerender(); }   // same scenario: stay on this screen
      else applyTransaction();                                       // other scenario: open this step for it
      render();
    },
    selectTransaction(id) { activeId = id; message = ''; applyTransaction(); render(); },
    selectStep(id) { stepId = id; goToStep(id); render(); },
    toggleStep(id, on) { active().steps[id] = !!on; message = ''; goToStep(stepId); render(); },
    toggleModule(sid, mid, on) {
      const m = CFG().MODULES.find(x => x.step === sid && x.id === mid);
      setModule(m, { on: !!on }); message = ''; rerender(); render();
    },
    setVar(sid, mid, k, value) {
      const m = CFG().MODULES.find(x => x.step === sid && x.id === mid);
      setModule(m, { vars: { [k]: value } }); message = '';
      // A card variant runs on its own account: move the transaction there so the card really changes.
      const sc = mid === 'option-card' && k === 'variant' && (CFG().VARIANT_SCENARIOS || {})[value];
      const tx = active();
      if (sc && Object.keys(sc).some(key => tx.scenario[key] !== sc[key])) {
        tx.scenario = { ...sc };
        message = `The ${(CFG().VARIANT_LABELS || {})[value] || value} card runs on ${({ prospect: 'a prospect', pilot: 'a pilot', customer: 'an existing' })[sc.accountType]} account \u2014 the screen moved to it.`;
        applyTransaction();
      } else rerender();
      render();
    },
    startNew() { document.getElementById('tx-composer-new')?.classList.remove('hidden'); document.getElementById('tx-composer-new-name')?.focus(); },
    createNew() {
      const name = (document.getElementById('tx-composer-new-name')?.value || '').trim();
      if (!name) { message = 'Enter a name for the new transaction.'; render(); api.startNew(); return; }
      const base = active();
      const tx = { ...clone(base), id: 'custom-' + Date.now().toString(36), name, custom: true, basedOn: base.custom ? base.basedOn : base.name };
      transactions.push(tx); activeId = tx.id;
      message = persist() ? `"${name}" created from ${base.name}. Adjust its steps and modules.` : `"${name}" created for this session.`;
      applyTransaction(); render();
    },
    removeCustom() {
      const tx = active(); if (!tx.custom) return;
      transactions = transactions.filter(t => t.id !== tx.id); activeId = 'initial-sale';
      persist(); message = `"${tx.name}" deleted.`; applyTransaction(); render();
    },
    save() {
      message = persist() ? 'Transactions saved in this browser.' : 'Saved for this session (browser storage unavailable).';
      render(); return true;
    },
    reapply: applyRules,
    // The Scenario tab took over: the composer stops driving the page until it is opened again.
    release() { if (!applied) return; applied = false; styleEl().textContent = ''; if (typeof global.renderOptions === 'function') global.renderOptions(); },
  };
  global.VCFlowComposer = api;

  // Keep the max-options rule right while options are added or removed.
  document.addEventListener('DOMContentLoaded', () => {
    const grid = document.getElementById('options-grid');
    if (grid && global.MutationObserver) new MutationObserver(() => applyRules()).observe(grid, { childList: true });
  });
})(window);
