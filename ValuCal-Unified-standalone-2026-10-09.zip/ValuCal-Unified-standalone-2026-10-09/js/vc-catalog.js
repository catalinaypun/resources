/* Valu Cal — shared product catalog (Initial Sales + Existing Accounts)
   One source for the pricing dictionaries used by Configure Solution / Expansion.
   2026-10-07 (Catalina): Existing Accounts adopts the Initial Sales catalog (adds DVIR,
   Roadside Assistance, DMS, Navigation, PTO, Fuel Card; Safety bundle as in Initial Sales).
   Bundles can be chosen at any contract term in both flows (no termRequired).
   PLACEHOLDER prices — real catalog pending from business.
   Loaded as a classic script before each flow's main script: these top-level consts are
   globals shared by both flows — do NOT redeclare them in the flow files. */

// Core subscriptions (per vehicle / asset, monthly list price)
const corePricing = {
  'vtu': { name: 'VTU Only', price: 35.00 },
  'vtu-ffc': { name: 'VTU + Forward Facing Camera', price: 65.00 },
  'vtu-dual': { name: 'VTU + Dual Camera Subscription', price: 75.00 },
  'asset-powered': { name: 'Powered Asset', price: 39.00 },
  'asset-nonpowered': { name: 'Non-Powered Asset', price: 19.00 },
};

// Features (per vehicle, monthly list price)
const featurePricing = { 'driver-id': 2.00, 'privacy': 1.00, 'adas': 5.00, 'evc': 15.00, 'logbook': 3.00, 'sd-256': 5.00, 'monitor': 12.00, 'dvir': 3.00, 'rsa': 4.00, 'dms': 8.00, 'navigation': 5.00, 'pto': 4.00, 'fuel-card': 2.00 };

// Bundle mode: niche features a rep can add on top of a bundle (EXAMPLE list — open question).
const BUNDLE_EXTRA_FEATURES = ['navigation', 'pto', 'driver-id'];

const featureLabels = {
  'sd-256': '256 GB SD Card',
  'adas': 'ADAS',
  'evc': 'Extended View Cameras',
  'monitor': 'In-Cab Monitor',
  'driver-id': 'Driver ID',
  'privacy': 'Privacy Button',
  'logbook': 'Logbook',
  'dvir': 'DVIR',
  'rsa': 'Roadside Assistance',
  'dms': 'Driver Monitoring System',
  'navigation': 'Navigation',
  'pto': 'PTO Monitoring',
  'fuel-card': 'Fuel Card Integration'
};

// Account-level features, switchable for a whole option (EXAMPLE list: RSA per Leo; DVIR, Fuel Card as samples).
const ACCOUNT_FEATURES = ['rsa', 'dvir', 'fuel-card'];

// Bundles / plans: same core + features a rep could pick a la carte, pre-packaged (no bundle-level discount).
const PREBUILT_BUNDLES = {
  'complete-safety': {
    name: 'Safety',
    category: 'Safety',
    tiers: [
      { key: 'vtu', coreKey: 'vtu', label: 'Essential', includedFeatures: ['dvir', 'rsa'], sdSize: null },
      { key: 'vtu-ffc', coreKey: 'vtu-ffc', label: 'Advanced', includedFeatures: ['dvir', 'rsa', 'adas'], sdSize: 128 },
      { key: 'vtu-dual', coreKey: 'vtu-dual', label: 'Premium', includedFeatures: ['dvir', 'rsa', 'adas', 'dms'], sdSize: 256 }
    ]
  },
  'productivity-suite': {
    name: 'Productivity',
    category: 'Productivity',
    tiers: [
      { key: 'standard', coreKey: 'vtu', label: 'Standard', includedFeatures: ['driver-id'], sdSize: null },
      { key: 'plus', coreKey: 'vtu', label: 'Plus', includedFeatures: ['driver-id', 'logbook'], sdSize: null },
      { key: 'max', coreKey: 'vtu', label: 'Max', includedFeatures: ['driver-id', 'logbook', 'privacy'], sdSize: null }
    ]
  }
};

// Real subscription-catalog names shown in summaries (per Catalina, 2026-09-24).
const REAL_SUBSCRIPTION_NAMES = {
  'Vehicle Tracking Subscription': 'Vehicle Tracking',
  'Powered Asset': 'Powered Asset Tracker',
  'Non-Powered Asset': 'Non-Powered Asset Tracker',
  'Extended View Cameras': 'EVC',
  '256 GB SD Card': 'SD Card',
};
