/* Valu Cal — Send Proposal / "Finalize Your Proposal Package" (shared modal)
   One implementation for Initial Sales and Existing Accounts (same modal, same functions —
   Catalina, 2026-10-07). Source: Initial Sales (reference, A5).
   Markup: VC.proposalReviewMarkup() — each flow drops it into #proposal-review-host.
   Flow-specific (stays in each flow): handleSend (what "Send Proposal" does next),
   calcOption / renderNav / updateSendBtn, customPromoHasAnyValue (drawer, A7). */

// Email / PDF images live in assets-shared/img/ (one copy for both flows). Absolute URL built
// from this script's own location so it works from any flow folder (and in the PDF download).
var VC_IMG = (function () {
  var src = (document.currentScript && document.currentScript.src) || '';
  return src ? src.replace(/js\/vc-proposal-review\.js[^/]*$/, 'img/') : 'app/assets/';
})();

window.VC = window.VC || {};
window.VC.proposalReviewMarkup = function () {
  return "<div class=\"modal-overlay\" id=\"proposal-review-overlay\" onclick=\"closeProposalReviewModal()\">\n    <div class=\"modal modal--full proposal-review-modal\" role=\"dialog\" aria-modal=\"true\" aria-labelledby=\"proposal-review-title\" onclick=\"handleProposalReviewModalClick(event); event.stopPropagation()\">\n\n    <!-- Unified Review Container \u2014 no separate header bar -->\n    <div class=\"review-master-container\" style=\"margin-top: 0;\">\n      <div class=\"review-header-bar vc-modal-header\">\n        <h2 id=\"proposal-review-title\" class=\"proposal-review-header-title modal__title\">Finalize Your Proposal Package</h2>\n        <button class=\"modal__close btn-icon btn-icon--ghost-vds btn-icon--vds-large\" type=\"button\" onclick=\"closeProposalReviewModal()\" aria-label=\"Close review modal\">\n          <span class=\"material-symbols-outlined\" aria-hidden=\"true\">close</span>\n        </button>\n      </div>\n\n      <div id=\"proposal-edit-message-inline-host\" class=\"proposal-edit-message-inline-host hidden\"></div>\n\n      <div id=\"proposal-edit-loader\" class=\"proposal-edit-loader hidden\" role=\"status\" aria-live=\"polite\" aria-label=\"Redirecting to email customization\">\n        <div class=\"proposal-edit-loader__inner\">\n          <div class=\"loader loader--small\" aria-hidden=\"true\"><svg class=\"loader__spinner\" viewBox=\"0 0 64 64\" fill=\"none\"><circle class=\"loader__track\" cx=\"32\" cy=\"32\" r=\"28\" stroke-width=\"6\" stroke-linecap=\"round\"/><path class=\"loader__arc\" d=\"M32 4 A28 28 0 0 1 60 32\" stroke-width=\"6\" stroke-linecap=\"round\" fill=\"none\"/></svg></div>\n          <div class=\"proposal-edit-loader__text\">Redirecting to email customization...</div>\n        </div>\n      </div>\n      \n      <div class=\"review-content-layout modal__scroll-area\" id=\"proposal-review-layout\">\n        <div class=\"proposal-review-summary-view\" id=\"proposal-review-summary-view\">\n          <div class=\"proposal-general-direct\">\n              <div class=\"proposal-general-card vds-card\">\n                <div class=\"proposal-header-inline\">\n                  <div class=\"proposal-rep-inline\" id=\"proposal-rep-inline-row\">\n                    <div id=\"proposal-rep-readonly-block\" class=\"proposal-rep-readonly-block\">\n                      <span class=\"proposal-rep-inline-text__label\">Rep Name:</span>\n                      <span id=\"gi-rep-name-text\" class=\"proposal-rep-inline-text__value\">Marcus Reid</span>\n                      <input type=\"hidden\" id=\"gi-rep-name\" value=\"Marcus Reid\">\n                      <span class=\"proposal-rep-inline-divider\" aria-hidden=\"true\">|</span>\n                      <span class=\"proposal-rep-inline-text__label\">Email:</span>\n                      <span id=\"gi-rep-email-text\" class=\"proposal-rep-inline-text__value\">marcus.reid@verizonconnect.com</span>\n                      <span class=\"proposal-rep-inline-divider\" aria-hidden=\"true\">|</span>\n                      <span class=\"proposal-rep-inline-text__label\">Phone:</span>\n                      <span id=\"gi-rep-phone-text\" class=\"proposal-rep-inline-text__value\">(800) 922-0220</span>\n                    </div>\n                    <button type=\"button\" id=\"proposal-rep-edit-btn\" class=\"btn-icon btn-icon--ghost-vds btn-icon--fit\" onclick=\"openProposalRepEditMode()\" aria-label=\"Edit representative information\" title=\"Edit representative information\">\n                      <span class=\"material-symbols-outlined\">edit</span>\n                    </button>\n                    <!-- 2026-09-28 (per Catalina \u2014 the pencil icon did nothing, it only\n                         called .focus() on a hidden input): ported the real rep-editor\n                         combobox from ValuCal-FutureVersion/index.html \u2014 the richer\n                         \"source\" implementation this flow's Send Proposal feature was\n                         migrated from but never fully carried over. -->\n                    <div class=\"proposal-rep-combobox hidden\" id=\"proposal-rep-combobox\">\n                      <div class=\"proposal-rep-edit-row\">\n                        <div class=\"proposal-review-label\">Rep:</div>\n                        <div class=\"proposal-rep-editor-box\">\n                          <input\n                            id=\"proposal-rep-editor-current-name\"\n                            type=\"text\"\n                            class=\"proposal-rep-editor-current\"\n                            aria-label=\"Rep\"\n                            aria-expanded=\"false\"\n                            aria-controls=\"proposal-rep-editor-options\"\n                            autocomplete=\"off\"\n                            onfocus=\"setProposalRepDropdownOpen(true)\"\n                            oninput=\"onProposalRepEditorMainInput(this.value)\">\n                          <span class=\"proposal-rep-editor-chevron\" aria-hidden=\"true\">\n                            <span class=\"material-symbols-outlined\">keyboard_arrow_down</span>\n                          </span>\n                          <div class=\"proposal-rep-editor-panel\">\n                            <div id=\"proposal-rep-editor-options\" class=\"proposal-rep-editor-options\" role=\"listbox\" aria-label=\"Rep options\"></div>\n                            <div class=\"proposal-rep-edit-actions\">\n                              <button id=\"proposal-rep-cancel-btn\" type=\"button\" class=\"btn btn--secondary btn--small\" onclick=\"cancelProposalRepEdit()\">Cancel</button>\n                              <button id=\"proposal-rep-confirm-btn\" type=\"button\" class=\"btn btn--primary btn--small\" onclick=\"saveProposalRepEdit()\">Confirm</button>\n                            </div>\n                          </div>\n                        </div>\n                      </div>\n                    </div>\n                    <input type=\"hidden\" id=\"gi-rep-email\" value=\"marcus.reid@verizonconnect.com\">\n                    <input type=\"hidden\" id=\"gi-rep-phone\" value=\"(800) 922-0220\">\n                  </div>\n                  <div id=\"rep-email-error\" class=\"input__error-text hidden\">Please enter a valid rep email.</div>\n\n                  <div class=\"proposal-general-priority-grid\">\n                    <div class=\"proposal-review-field proposal-review-field--close\">\n                      <div class=\"proposal-review-label\">Close date:</div>\n                      <div class=\"vc-date-field\">\n                        <input type=\"date\" id=\"proposal-close-date\" class=\"input proposal-date-input\" lang=\"en-US\" oninput=\"handleProposalGeneralInfoInput('v1')\" required>\n                        <span class=\"material-symbols-outlined vc-date-field__icon\" aria-hidden=\"true\">calendar_month</span>\n                      </div>\n                      <div id=\"close-date-error\" class=\"input__error-text hidden\">Close date cannot be earlier than today.</div>\n                    </div>\n                    <div class=\"proposal-review-field proposal-review-field--expiration\">\n                      <div class=\"proposal-review-label\">Expiration date:</div>\n                      <div class=\"vc-date-field\">\n                        <input type=\"date\" id=\"proposal-expiration-date\" class=\"input proposal-date-input\" lang=\"en-US\" oninput=\"onProposalExpirationChange(); handleProposalGeneralInfoInput('v1')\">\n                        <span class=\"material-symbols-outlined vc-date-field__icon\" aria-hidden=\"true\">calendar_month</span>\n                      </div>\n                      <div id=\"expiration-date-error\" class=\"input__error-text hidden\">Expiration date must be on or after close date.</div>\n                    </div>\n                  </div>\n                </div>\n              </div>\n          </div>\n\n          <div class=\"proposal-customization-wrap\">\n            <div class=\"proposal-customization-grid\">\n              <div class=\"proposal-customization-card proposal-customization-card--message\">\n                <div class=\"proposal-customization-card__head\">\n                  <div class=\"proposal-customization-card__title\">Email body</div>\n                  <button type=\"button\" class=\"btn btn--secondary btn--small proposal-customization-edit-btn\" onclick=\"openMessageCustomizationWithLoader()\">Edit</button>\n                </div>\n                <div class=\"proposal-customization-thumb\" aria-hidden=\"true\">\n                  <div id=\"customization-message-preview\" class=\"proposal-customization-thumb__inner\"></div>\n                  <div class=\"proposal-customization-thumb__fade\"></div>\n                </div>\n              </div>\n              <div class=\"proposal-customization-card proposal-customization-card--pdf\">\n                <div class=\"proposal-customization-card__head\">\n                  <div class=\"proposal-customization-card__title\">PDF</div>\n                  <div class=\"proposal-customization-head-actions\">\n                    <button\n                      type=\"button\"\n                      class=\"btn-icon btn-icon--solid btn-icon--vds-small\"\n                      onclick=\"downloadProposalPdfPreview()\"\n                      aria-label=\"Download proposal preview\"\n                      title=\"Download\">\n                      <span class=\"material-symbols-outlined\">download</span>\n                    </button>\n                    <button type=\"button\" class=\"btn btn--secondary btn--small proposal-customization-edit-btn\" onclick=\"openPdfCustomizationWithLoader()\">Edit</button>\n                  </div>\n                </div>\n                <div class=\"proposal-customization-thumb\" aria-hidden=\"true\">\n                  <div id=\"customization-pdf-preview\" class=\"proposal-customization-thumb__inner\"></div>\n                  <div class=\"proposal-customization-thumb__fade\"></div>\n                </div>\n              </div>\n            </div>\n          </div>\n        </div>\n\n        <div class=\"proposal-review-edit-shell hidden\" id=\"proposal-review-edit-shell\">\n          <div class=\"proposal-review-edit-view hidden\" id=\"proposal-review-edit-message\">\n            <div class=\"proposal-editor-topbar\">\n              <div class=\"proposal-editor-title-row\">\n                <button type=\"button\" class=\"btn btn--secondary btn--small\" onclick=\"backToProposalReviewSummary(true)\" aria-label=\"Back to summary\">\n                  <span class=\"material-symbols-outlined\" style=\"font-size:18px;\">arrow_back</span>\n                </button>\n                <div class=\"proposal-editor-title\">Edit message</div>\n                <span class=\"autosave-status\" id=\"autosave-msg-status\"></span>\n              </div>\n            </div>\n            <div id=\"proposal-message-inline-fields\" class=\"proposal-message-inline-fields\">\n              <div class=\"proposal-message-to-field\" style=\"margin-bottom: 24px;\">\n                <label class=\"vc-field-label\" for=\"prop-msg-to\">To</label>\n                <input type=\"text\" id=\"prop-msg-to\" class=\"input\" value=\"\" placeholder=\"Enter email...\" oninput=\"updateSendBtn(); updateProposalMessagePreview();\">\n              </div>\n\n              <div class=\"proposal-message-subject-field\" style=\"margin-bottom: 24px;\">\n                <label class=\"vc-field-label\" for=\"prop-msg-subject\">Subject</label>\n                <input type=\"text\" id=\"prop-msg-subject\" class=\"input\" value=\"\" placeholder=\"Enter subject...\" oninput=\"updateSendBtn(); updateProposalMessagePreview();\">\n              </div>\n            </div>\n            <div class=\"proposal-editor-columns\">\n              <div class=\"proposal-editor-options-col proposal-editor-options-col--message\">\n                <div class=\"proposal-msg-content-section\">\n                  <div class=\"vc-pane-head\"><span class=\"vc-pane-head__title\">Message content</span></div>\n                  <div id=\"proposal-msg-content-list\"></div>\n                </div>\n\n                <div id=\"prop-msg-body-host-v1\" style=\"position: relative; margin-bottom:24px;\">\n                  <label class=\"vc-field-label\" id=\"prop-msg-body-label\">Message</label>\n                  <div id=\"prop-msg-body\" contenteditable=\"true\" role=\"textbox\" aria-multiline=\"true\" aria-labelledby=\"prop-msg-body-label\" spellcheck=\"true\" style=\"width:100%; border:1px solid var(--black); border-radius:8px; padding:16px; min-height:320px; font-family:'VerizonNHGDS',sans-serif; font-size:14px; line-height:1.7; outline:none; overflow-y:auto; color:#1a1a1a; box-sizing:border-box; cursor:text;\" oninput=\"markProposalMessageEdited(); updateCharCount(this); updateProposalMessagePreview();\"></div>\n                  <div id=\"prop-char-count\" style=\"text-align:right; font-size: 11px; color: var(--black); margin-top:4px;\"><span id=\"char-count\">0</span>/2000</div>\n                </div>\n\n              </div>\n\n              <div class=\"proposal-editor-preview-col\" style=\"display:flex;flex-direction:column;\">\n                <div class=\"vc-pane-head vc-pane-head--bleed\">\n                  <span class=\"vc-pane-head__title\">Email</span>\n                  <div class=\"segmented-control\" role=\"group\" aria-label=\"Message format selector\">\n                    <button type=\"button\" id=\"proposal-message-format-plain\" class=\"segmented-control__option\" onclick=\"setProposalMessageFormat('plain')\">Plain text</button>\n                    <button type=\"button\" id=\"proposal-message-format-visual\" class=\"segmented-control__option segmented-control__option--active\" onclick=\"setProposalMessageFormat('visual')\">Visual email</button>\n                  </div>\n                </div>\n                <div class=\"message-preview-card\" style=\"margin-top:14px;\">\n                  <div class=\"message-preview-meta\"><strong>To:</strong> <span id=\"prop-msg-preview-to\">-</span></div>\n                  <div class=\"message-preview-meta\"><strong>Subject:</strong> <span id=\"prop-msg-preview-subject\">-</span></div>\n                  <div class=\"message-preview-body\" id=\"prop-msg-preview-body\"></div>\n                </div>\n              </div>\n            </div>\n          </div>\n\n          <div class=\"proposal-review-edit-view hidden\" id=\"proposal-review-edit-pdf\">\n            <div class=\"proposal-editor-topbar\">\n              <div class=\"proposal-editor-title-row\">\n                <div class=\"proposal-editor-title\">Edit PDF</div>\n                <span class=\"autosave-status\" id=\"autosave-pdf-status\"></span>\n              </div>\n              <button type=\"button\" class=\"btn btn--secondary btn--small\" onclick=\"backToProposalReviewSummary(true)\">Back to summary</button>\n            </div>\n            <div class=\"proposal-editor-columns\">\n              <div class=\"proposal-editor-options-col\">\n                <div class=\"proposal-review-field\">\n                  <div style=\"font-size:15px;font-weight:700;color:var(--black);margin-bottom:12px;padding-top:16px;\">Additional Materials</div>\n                  <div id=\"materials-menu\">\n                    <div class=\"materials-menu-item\" onclick=\"toggleMaterial(this)\">\n                      <input type=\"checkbox\" class=\"checkbox__input\" data-material-key=\"roi\" data-material-label=\"ROI Analysis\">\n                      <div><div style=\"font-size:13px;font-weight:700;\">ROI Analysis</div><div style=\"font-size:14px;color:var(--black);margin-top:2px;\">Business Impact Analysis with estimated monthly savings.</div></div>\n                    </div>\n                    <div class=\"materials-menu-item\" onclick=\"toggleMaterial(this)\">\n                      <input type=\"checkbox\" class=\"checkbox__input\" data-material-key=\"case-study\" data-material-label=\"Case Study\">\n                      <div><div style=\"font-size:13px;font-weight:700;\">Case Study</div><div style=\"font-size:14px;color:var(--black);margin-top:2px;\">ROI Success history \u2014 Safety &amp; Insurance customer story.</div></div>\n                    </div>\n                    <div id=\"case-study-selector-wrap\" class=\"case-study-selector-wrap hidden\">\n                      <div class=\"case-study-selector-label proposal-review-label\">Select case study</div>\n                      <div class=\"custom-select-wrap case-study-select-wrap\">\n                        <button type=\"button\" id=\"case-study-btn\" class=\"custom-select-btn selected case-study-select-btn\" aria-haspopup=\"listbox\" aria-expanded=\"false\" onclick=\"toggleCaseStudyDropdown('v1', event)\">\n                          <span id=\"case-study-label\">None</span>\n                          <span class=\"material-symbols-outlined\">expand_more</span>\n                        </button>\n                        <div id=\"case-study-dropdown\" class=\"custom-dropdown case-study-dropdown hidden\" role=\"listbox\" aria-label=\"Case study options\"></div>\n                      </div>\n                    </div>\n                    <div class=\"materials-menu-item\" onclick=\"toggleMaterial(this)\">\n                      <input type=\"checkbox\" class=\"checkbox__input\" data-material-key=\"onboarding\" data-material-label=\"Onboarding Flyer\">\n                      <div><div style=\"font-size:13px;font-weight:700;\">Onboarding Flyer</div><div style=\"font-size:14px;color:var(--black);margin-top:2px;\">Fast, no-hassle onboarding overview and three-step journey.</div></div>\n                    </div>\n                  </div>\n                </div>\n\n                <!-- ROI Configuration -->\n                <div class=\"roi-config-section hidden\" id=\"roi-config-section\">\n                  <div class=\"roi-config-body\" id=\"roi-config-body\">\n                    <div style=\"font-size:15px;font-weight:700;color:var(--black);margin-bottom:14px;padding-top:8px;\">ROI Calculator</div>\n\n                    <!-- Productivity -->\n                    <div class=\"roi-cat-card\">\n                      <div class=\"roi-cat-header\" onclick=\"toggleRoiCat('productivity')\">\n                        <input type=\"checkbox\" class=\"checkbox__input\" id=\"roi-productivity-enabled\" checked onchange=\"onRoiChange()\" onclick=\"event.stopPropagation()\">\n                        <span class=\"roi-cat-title\" id=\"roi-productivity-title\">Productivity</span>\n                      </div>\n                      <div class=\"roi-cat-body\" id=\"roi-cat-productivity\">\n                        <div class=\"roi-field-row\">\n                          <div class=\"roi-field\">\n                            <label>Billing Method</label>\n                            <select id=\"roi-billing-method\" class=\"select select--small\" onchange=\"onRoiChange()\">\n                              <option value=\"perJob\">Per Job</option>\n                              <option value=\"perHour\">Per Hour</option>\n                            </select>\n                          </div>\n                          <div class=\"roi-field\">\n                            <label>Avg Bill Rate ($)</label>\n                            <input type=\"number\" class=\"input\" id=\"roi-avg-bill-rate\" value=\"150\" min=\"0\" step=\"1\" oninput=\"onRoiChange()\">\n                          </div>\n                        </div>\n                        <div class=\"roi-field-row\">\n                          <div class=\"roi-field\">\n                            <label id=\"roi-jobs-label\">Jobs / Wk / Veh</label>\n                            <input type=\"number\" class=\"input\" id=\"roi-jobs-per-week\" value=\"12\" min=\"0\" step=\"1\" oninput=\"onRoiChange()\">\n                          </div>\n                          <div class=\"roi-field\">\n                            <label>Efficiency Gain (%)</label>\n                            <input type=\"number\" class=\"input\" id=\"roi-efficiency-gain\" value=\"15\" min=\"0\" max=\"100\" step=\"1\" oninput=\"onRoiChange()\">\n                          </div>\n                        </div>\n                      </div>\n                    </div>\n\n                    <!-- Fuel Savings -->\n                    <div class=\"roi-cat-card\">\n                      <div class=\"roi-cat-header\" onclick=\"toggleRoiCat('fuel')\">\n                        <input type=\"checkbox\" class=\"checkbox__input\" id=\"roi-fuel-enabled\" checked onchange=\"onRoiChange()\" onclick=\"event.stopPropagation()\">\n                        <span class=\"roi-cat-title\" id=\"roi-fuel-title\">Fuel Savings</span>\n                      </div>\n                      <div class=\"roi-cat-body\" id=\"roi-cat-fuel\">\n                        <div class=\"roi-field-row\">\n                          <div class=\"roi-field\">\n                            <label>Cost / Gallon ($)</label>\n                            <input type=\"number\" class=\"input\" id=\"roi-cost-per-gallon\" value=\"2.95\" min=\"0\" step=\"0.01\" oninput=\"onRoiChange()\">\n                          </div>\n                          <div class=\"roi-field\">\n                            <label>Gal Saved / Wk / Veh</label>\n                            <input type=\"number\" class=\"input\" id=\"roi-gal-saved\" value=\"2\" min=\"0\" step=\"0.5\" oninput=\"onRoiChange()\">\n                          </div>\n                        </div>\n                      </div>\n                    </div>\n\n                    <!-- Payroll & Maintenance -->\n                    <div class=\"roi-cat-card\">\n                      <div class=\"roi-cat-header\" onclick=\"toggleRoiCat('payroll')\">\n                        <input type=\"checkbox\" class=\"checkbox__input\" id=\"roi-payroll-enabled\" checked onchange=\"onRoiChange()\" onclick=\"event.stopPropagation()\">\n                        <span class=\"roi-cat-title\" id=\"roi-payroll-title\">Payroll &amp; Maint.</span>\n                      </div>\n                      <div class=\"roi-cat-body\" id=\"roi-cat-payroll\">\n                        <div class=\"roi-field-row\">\n                          <div class=\"roi-field\">\n                            <label>OT Hours Saved / Wk</label>\n                            <input type=\"number\" class=\"input\" id=\"roi-ot-hours\" value=\"1\" min=\"0\" step=\"0.5\" oninput=\"onRoiChange()\">\n                          </div>\n                          <div class=\"roi-field\">\n                            <label>Avg Hourly Rate ($)</label>\n                            <input type=\"number\" class=\"input\" id=\"roi-hourly-rate\" value=\"25\" min=\"0\" step=\"1\" oninput=\"onRoiChange()\">\n                          </div>\n                        </div>\n                        <label class=\"roi-inline-check\">\n                          <input type=\"checkbox\" class=\"checkbox__input\" id=\"roi-include-maint\" checked onchange=\"onRoiChange()\"> Include Maint.\n                        </label>\n                        <div class=\"roi-field-row single\" id=\"roi-maint-row\">\n                          <div class=\"roi-field\">\n                            <label>Annual Maint. Save / Veh ($)</label>\n                            <input type=\"number\" class=\"input\" id=\"roi-maint-save\" value=\"100\" min=\"0\" step=\"10\" oninput=\"onRoiChange()\">\n                          </div>\n                        </div>\n                      </div>\n                    </div>\n\n                    <!-- Safety & Cameras (auto) -->\n                    <div class=\"roi-cat-card\" id=\"roi-safety-card\">\n                      <div class=\"roi-cat-header roi-auto\">\n                        <span class=\"material-symbols-outlined\" style=\"font-size:16px;color:var(--black);\" id=\"roi-safety-icon\">videocam_off</span>\n                        <span class=\"roi-cat-title\" id=\"roi-safety-title\" style=\"color:var(--gray-400);\">Safety &amp; Cameras</span>\n                      </div>\n                      <div class=\"roi-cat-body\" id=\"roi-cat-safety\">\n                        <div class=\"roi-field-row\">\n                          <div class=\"roi-field\">\n                            <label>Avg Accident Cost ($)</label>\n                            <input type=\"number\" class=\"input\" id=\"roi-accident-cost\" value=\"25000\" min=\"0\" step=\"500\" oninput=\"onRoiChange()\">\n                          </div>\n                          <div class=\"roi-field\">\n                            <label>Est. Accidents / Year</label>\n                            <input type=\"number\" class=\"input\" id=\"roi-accidents-per-year\" value=\"1\" min=\"0\" step=\"0.1\" oninput=\"onRoiChange()\">\n                          </div>\n                        </div>\n                        <div class=\"roi-field-row single\">\n                          <div class=\"roi-field\">\n                            <label>Liability Reduction (%)</label>\n                            <input type=\"number\" class=\"input\" id=\"roi-liability-pct\" value=\"40\" min=\"0\" max=\"100\" step=\"1\" oninput=\"onRoiChange()\">\n                          </div>\n                        </div>\n                      </div>\n                    </div>\n\n                  </div>\n                </div>\n              </div>\n\n              <div class=\"proposal-editor-preview-col\">\n                <div class=\"vc-pane-head vc-pane-head--bleed\">\n                  <span class=\"vc-pane-head__title\">PDF</span>\n                  <button type=\"button\" class=\"btn-icon btn-icon--solid btn-icon--vds-small\" onclick=\"downloadProposalPdfPreview()\" title=\"Download PDF\" aria-label=\"Download PDF\">\n                    <span class=\"material-symbols-outlined\" aria-hidden=\"true\">download</span>\n                  </button>\n                </div>\n                <div class=\"review-preview-card\" style=\"margin-top:14px;\">\n                  <div class=\"doc-viewer\" id=\"prop-doc-viewer\">\n                    <!-- Proposal Content Injected by JS -->\n                  </div>\n                </div>\n              </div>\n            </div>\n          </div>\n        </div>\n      </div>\n      <div class=\"proposal-review-modal-actions modal__actions modal__actions--auto\">\n        <button type=\"button\" class=\"btn btn--secondary btn--large\" onclick=\"closeProposalReviewModal()\">Cancel</button>\n        <button type=\"button\" class=\"btn btn--primary btn--large\" id=\"review-send-proposal-btn\" onclick=\"handleSend()\" disabled>Send Proposal</button>\n      </div>\n    </div>\n  </div>\n  </div>";
};

const ADDITIONAL_LINKS_CATALOG = [
  { id: 'reveal-fleet', label: 'Reveal Demo - Fleet Maintenance', url: 'https://share.highspot.com/items/reveal-demo-fleet-maintenance' },
  { id: 'reveal-reports', label: 'Reveal Demo - Reports', url: 'https://share.highspot.com/items/reveal-demo-reports' },
  { id: 'reveal-geo', label: 'Reveal Demo - Geofences', url: 'https://share.highspot.com/items/reveal-demo-geofences' },
  { id: 'reveal-pdf', label: 'Reveal Reports', url: 'https://view.highspot.com/viewer/711d013133b327ca6d6267ff7e1bb38f' },
  { id: 'reveal-maps', label: 'Reveal Demo - Live Maps', url: 'https://share.highspot.com/items/reveal-demo-live-maps' },
  { id: 'casestudy-bam', label: 'Case Study - B.A.M. Trucking', url: 'https://share.highspot.com/items/case-study-bam-trucking-video' },
  { id: 'reveal-dispatch', label: 'Reveal Demo - Dispatch', url: 'https://share.highspot.com/items/reveal-demo-dispatch' },
  { id: 'reveal-driver', label: 'Reveal Demo - Driver Safety', url: 'https://share.highspot.com/items/reveal-demo-driver-safety' },
  { id: 'reveal-dashcam', label: 'Reveal Demo - Dashcam', url: 'https://share.highspot.com/items/reveal-demo-dashcam' }
];
const CASE_STUDY_LIBRARY = {
  none: {
    title: 'Case Study',
    company: 'Verizon Connect Customer',
    quote: 'A Verizon Connect customer improved operations and reduced avoidable risk with connected fleet data.',
    outcome: 'Demonstrated measurable operational and financial improvements.',
    challenges: ['Operational blind spots', 'Manual reporting', 'Limited real-time visibility'],
    solutions: ['Fleet tracking', 'Driver insights', 'Automated reporting']
  },
  landscaping: {
    title: 'Landscaping',
    company: 'Apex Landscaping',
    quote: 'GPS data helped verify real arrival/departure times and replace paper logs.',
    outcome: 'Improved verification and reduced manual admin work.',
    challenges: ['Verify hours', 'Prevent side jobs', 'Protect equipment'],
    solutions: ['Automated timesheets', 'Proof of service', 'Asset tracking']
  },
  towing: {
    title: 'Towing',
    company: 'Wrecker Service',
    quote: 'PTO monitoring exposed unauthorized work and improved dispatch confidence.',
    outcome: 'Recovered revenue and improved operational control.',
    challenges: ['Unauthorized jobs', 'ETA pressure', 'PTO monitoring'],
    solutions: ['PTO alerts', 'Closest-driver dispatch', 'Route visibility']
  },
  transportation: {
    title: 'Transportation',
    company: 'Redwey Transport',
    quote: 'Geofencing and visibility improved payroll accuracy and compliance.',
    outcome: 'Better ELD compliance and safer operations.',
    challenges: ['Passenger safety', 'Billable-hour verification', 'Compliance pressure'],
    solutions: ['Driver behavior monitoring', 'Arrival/departure proof', 'Automated reporting']
  },
  'plumbing-hvac': {
    title: 'Plumbing & HVAC',
    company: 'Bill Howe Plumbing',
    quote: 'Fleet visibility helped significantly reduce annual accidents.',
    outcome: 'Lower risk exposure and improved dispatch efficiency.',
    challenges: ['Emergency response', 'Hours verification', 'After-hours usage'],
    solutions: ['Closest-driver routing', 'Time verification', 'Usage oversight']
  },
  'pest-control': {
    title: 'Pest Control',
    company: 'Pest & Termite Consultants',
    quote: 'Proof-of-service reporting helped resolve customer disputes instantly.',
    outcome: 'Higher trust and fewer service disputes.',
    challenges: ['No-show claims', 'Tech tracking', 'Route inefficiency'],
    solutions: ['Proof of service', 'Route replay', 'Faster customer response']
  },
  construction: {
    title: 'Construction',
    company: 'J&M Contracting',
    quote: 'An alert led to quick recovery of high-value equipment.',
    outcome: '$50K asset protected from theft loss.',
    challenges: ['Asset theft', 'Unverified usage', 'Job cost control'],
    solutions: ['Asset tracking', 'Geofences', 'Utilization reports']
  },
  'oil-fields': {
    title: 'Oil Fields',
    company: '3C Oilfield Services',
    quote: 'Knowing teammate locations improved incident response in remote areas.',
    outcome: 'Improved lone-worker safety and response readiness.',
    challenges: ['Remote operations', 'Lone worker risk', 'Asset maintenance'],
    solutions: ['Live location visibility', 'Safer dispatch', 'Maintenance scheduling']
  },
  'theft-asset-recovery': {
    title: 'Theft & Asset Recovery',
    company: 'J&M Contracting',
    quote: 'Location data enabled fast police support and asset recovery.',
    outcome: 'Reduced theft downtime and avoided replacement costs.',
    challenges: ['Asset theft', 'High deductibles', 'Unauthorized usage'],
    solutions: ['Movement alerts', 'Geofence breaches', 'Asset trackers']
  },
  'payroll-savings': {
    title: 'Payroll Savings',
    company: 'Concrete Coring Company',
    quote: 'Automated time verification reduced payroll leakage.',
    outcome: 'Lower labor waste and cleaner time records.',
    challenges: ['Manual logs', 'Rounded timecards', 'Overtime uncertainty'],
    solutions: ['Automated timestamps', 'Route history checks', 'Smart reports']
  },
  'safety-insurance': {
    title: 'Safety & Insurance',
    company: 'B.A.M. Trucking',
    quote: 'Video evidence helped contest claims and lower insurance exposure.',
    outcome: 'Reduced accidents by 87% and supported claims defense.',
    challenges: ['False claims', 'Insurance costs', 'Driver safety'],
    solutions: ['Dashcams', 'Safety coaching', 'Driver scorecards']
  },
  'fuel-savings': {
    title: 'Fuel Savings',
    company: 'Tree-care Company',
    quote: 'Route and idling controls reduced monthly fuel spend significantly.',
    outcome: 'Approx. $2,000 monthly fuel savings.',
    challenges: ['Idling', 'Inefficient routes', 'Traffic delays'],
    solutions: ['Idling alerts', 'Route optimization', 'Traffic overlays']
  },
  'increase-revenue': {
    title: 'Increase Revenue',
    company: 'Pool Sure',
    quote: 'Fleet optimization enabled more daily jobs without adding vehicles.',
    outcome: 'Higher daily capacity and stronger utilization.',
    challenges: ['Missed opportunities', 'Limited emergency capacity', 'Low utilization'],
    solutions: ['Nearest-tech dispatch', 'More jobs per day', 'Fleet visibility']
  },
  'operational-insights': {
    title: 'Operational Insights / Zero At-Fault Accidents',
    company: 'Fleet Operations Team',
    quote: 'With proactive monitoring and coaching, teams reached extended periods with zero at-fault incidents.',
    outcome: 'Improved safety discipline and stronger operational consistency.',
    challenges: ['Inconsistent driving behavior', 'Limited coaching data', 'Reactive incident response'],
    solutions: ['Driver scorecards', 'Risk event alerts', 'Coaching workflows']
  }
};
const CASE_STUDY_OPTIONS = [
  { key: 'none', label: 'None' },
  { key: 'landscaping', label: 'Landscaping' },
  { key: 'towing', label: 'Towing' },
  { key: 'transportation', label: 'Transportation' },
  { key: 'plumbing-hvac', label: 'Plumbing & HVAC' },
  { key: 'pest-control', label: 'Pest Control' },
  { key: 'construction', label: 'Construction' },
  { key: 'oil-fields', label: 'Oil Fields' },
  { key: 'theft-asset-recovery', label: 'Theft & Asset Recovery' },
  { key: 'payroll-savings', label: 'Payroll Savings' },
  { key: 'safety-insurance', label: 'Safety & Insurance' },
  { key: 'fuel-savings', label: 'Fuel Savings' },
  { key: 'increase-revenue', label: 'Increase Revenue' },
  { key: 'operational-insights', label: 'Operational Insights / Zero At-Fault Accidents' }
];
const MESSAGE_BLOCK_IDS = {
  INTRO: 'intro',
  ADDITIONAL_INFORMATION: 'additionalInformation',
  NOTE: 'note',
  FOLLOW_UP: 'followUp',
  OPTION_INFORMATION: 'optionInformation',
  ADDITIONAL_LINKS: 'additionalLinks',
  PACKAGE_INCLUDES: 'packageIncludes',
  KEY_POINTS: 'keyPointsDiscussed',
  PRO_INSTALLATION: 'proInstallation',
  KEY_DIFFERENTIATORS: 'keyDifferentiators',
  CASE_STUDY: 'caseStudy',
  ONBOARDING: 'onboarding',
  YOUR_PACKAGE: 'yourPackage',
  WHY_VERIZON: 'whyVerizon'
};
const MESSAGE_FORMATS = { PLAIN: 'plain', VISUAL: 'visual' };
const MESSAGE_MODULE_STATE_KEY = 'valuCal.messageModules.v1';
const PROPOSAL_EDIT_LOADER_DELAY_MS = 1000;
const PROPOSAL_REP_DIRECTORY = {
  'Marcus Reid': { email: 'marcus.reid@verizonconnect.com', phone: '(800) 922-0220', isDefault: true },
  'Daniel Harper': { email: 'daniel.harper@verizonconnect.com', phone: '(800) 922-0205' },
  'Maya Patel': { email: 'maya.patel@verizonconnect.com', phone: '(800) 922-0206' },
  'Jordan Lee': { email: 'jordan.lee@verizonconnect.com', phone: '(800) 922-0207' },
  'Sofia Ramirez': { email: 'sofia.ramirez@verizonconnect.com', phone: '(800) 922-0208' },
  'Ethan Brooks': { email: 'ethan.brooks@verizonconnect.com', phone: '(800) 922-0209' },
  'Olivia Chen': { email: 'olivia.chen@verizonconnect.com', phone: '(800) 922-0210' },
  'Lucas Bennett': { email: 'lucas.bennett@verizonconnect.com', phone: '(800) 922-0211' },
  'Amelia Scott': { email: 'amelia.scott@verizonconnect.com', phone: '(800) 922-0212' },
  'Noah Turner': { email: 'noah.turner@verizonconnect.com', phone: '(800) 922-0213' },
  'Isabella Morris': { email: 'isabella.morris@verizonconnect.com', phone: '(800) 922-0214' },
  'Liam Cooper': { email: 'liam.cooper@verizonconnect.com', phone: '(800) 922-0215' },
  'Ava Reed': { email: 'ava.reed@verizonconnect.com', phone: '(800) 922-0216' },
  'Mason Kelly': { email: 'mason.kelly@verizonconnect.com', phone: '(800) 922-0217' },
  'Charlotte Ward': { email: 'charlotte.ward@verizonconnect.com', phone: '(800) 922-0218' },
  'James Foster': { email: 'james.foster@verizonconnect.com', phone: '(800) 922-0219' }
};
let _addLinksDragIdx = -1;
let _autosaveTimer = null;
const defaultProposalKeyPoints = [
  'Verizon guarantees service uptime of 99.9% or agreement becomes void',
  'No 3rd parties. Verizon provides in-house support, hardware, and network.',
  'Defaults to month-to-month intervals after initial agreement',
  'Largest network with minimal downtime',
  'True satellite and cell tower based system - no dead zones, only delayed zones',
  'Free and unlimited system trainings'
];
const messageModuleDefaults = {
  guarantees: 'detail',
  differentiators: 'detail',
  caseStudy: 'off',
  onboarding: 'off'
};
let proposalActiveMessageBlockId = 'intro';
let proposalCaseStudySelection = 'none';
let proposalEditLoaderTimer = null;
let proposalKeyPointDragIndex = -1;
let proposalMessageBlocksModel = null;
let proposalMessageModules = Object.assign({}, messageModuleDefaults);
let proposalRepDraftName = '';
let proposalRepDropdownOpen = false;
let proposalRepSaveLoaderTimer = null;
let proposalReviewLayoutTimer = null;
let proposalReviewPreviewOnly = false;

function optionHasActiveCustomDiscount(opt) {
  if (!opt) return false;
  const own = Array.isArray(opt.customPromotions) && opt.customPromotions.some(p => customPromoHasAnyValue(p));
  if (own) return true;
  const companion = (typeof options !== 'undefined' && opt.id != null) ? options.find(o => o.msaPreviewFor === opt.id) : null;
  return !!(companion && Array.isArray(companion.customPromotions) && companion.customPromotions.some(p => customPromoHasAnyValue(p)));
}

function optionHasUnapprovedDiscount(opt, discretionaryBoundaries) {
  // 2026-10-05 (per Catalina): any Custom Discount (MSA) or Custom Promotion
  // (Order) with a value requires approval — the option card's existing
  // "approval required · Request" notification shows again, and Select &
  // Create Contract stays blocked until it's approved. For a pilot, the
  // custom discounts configured on its MSA (companion option) count too.
  if (optionHasActiveCustomDiscount(opt)) return true;
  return !!(opt && opt.bundles && opt.bundles.some(b => (b.msaDiscountPct || 0) > discretionaryBoundaries.autoApproved));
}

function getOptionApprovalInfo(calcOpt, opt) {
  const optionPromoType = getOptionPromotion(calcOpt);
  const { totalUnits, msaTierUnits } = calcOption(calcOpt, optionPromoType);
  // Placeholder approval rule shared by both flows (vc-approval.js): Custom Discount / Promotion with a value
  // (or a discretionary discount above the auto-approval limit). Tier jumps don't trigger approval for now.
  const discretionaryBoundaries = getMsaDiscretionaryApprovalBoundaries(opt.term, msaTierUnits);
  const requiresApproval = optionHasUnapprovedDiscount(calcOpt, discretionaryBoundaries) && proposalData.approvalStatus !== 'Approved';
  const discretionaryApprovalLevel = getMsaDiscretionaryApprovalLevel(opt.msaDiscountPct || 0, discretionaryBoundaries);
  const role = discretionaryApprovalLevel === 2 ? 'Director' : 'Associate Director';
  return { requiresApproval, role };
}

function getNaturalTierIndex(qty) {
  const idx = volumeTiers.findIndex(t => qty >= t.min && qty <= t.max);
  return idx === -1 ? 0 : idx;
}

function getEffectiveTier(qty, forcedTierIndex = -1) {
  const natural = getNaturalTierIndex(qty);
  // If forcedTierIndex is provided, it must be at least the natural one to apply higher discount
  const effective = forcedTierIndex === -1 ? natural : Math.max(natural, forcedTierIndex);
  return { ...volumeTiers[effective], index: effective, naturalIndex: natural };
}

function getStandardUnitPrice(bundle) {
  return bundle.basePrice;
}

function getOptionPromotion(opt) {
  if (!opt) return proposalData.promoType;
  return opt.promoType || proposalData.promoType;
}

function formatUsDate(date) {
  return new Intl.DateTimeFormat('en-US').format(date);
}

function formatExpirationDisplayDate(date) {
  return formatUsDate(date);
}

function toIsoDate(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function startOfDay(date) {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate());
}

function addCalendarDays(date, days) {
  const next = new Date(date);
  next.setDate(next.getDate() + days);
  return next;
}

function getLastDayOfCurrentMonthIso() {
  const now = new Date();
  return toIsoDate(new Date(now.getFullYear(), now.getMonth() + 1, 0));
}

function parseProposalDate(value) {
  if (!value || typeof value !== 'string') return null;
  const raw = value.trim();
  if (!raw) return null;

  if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) {
    const [year, month, day] = raw.split('-').map(Number);
    const parsed = new Date(year, month - 1, day);
    return Number.isNaN(parsed.getTime()) ? null : parsed;
  }

  if (/^\d{1,2}\/\d{1,2}\/\d{4}$/.test(raw)) {
    const [month, day, year] = raw.split('/').map(Number);
    const parsed = new Date(year, month - 1, day);
    if (Number.isNaN(parsed.getTime())) return null;
    if (parsed.getFullYear() !== year || parsed.getMonth() !== month - 1 || parsed.getDate() !== day) return null;
    return parsed;
  }

  return null;
}

function getExpirationBounds() {
  const today = startOfDay(new Date());
  const maxDate = addCalendarDays(today, 60);
  return { minDate: today, maxDate };
}

function clampExpirationDate(date) {
  const { minDate, maxDate } = getExpirationBounds();
  if (date < minDate) return minDate;
  if (date > maxDate) return maxDate;
  return date;
}

function getDefaultExpirationDate() {
  const { minDate } = getExpirationBounds();
  // The default never falls before the proposal close date.
  // be on or after close date". The default now never lands before the
  // Close date (still capped at today + 60).
  let defaultDate = addCalendarDays(minDate, 14);
  const closeRaw = document.getElementById('proposal-close-date')?.value || proposalData.closeDate || '';
  const closeDate = closeRaw ? parseProposalDate(closeRaw) : null;
  if (closeDate && startOfDay(closeDate) > defaultDate) defaultDate = startOfDay(closeDate);
  return clampExpirationDate(defaultDate);
}

function getMsaTermEndDate(startIso, termMonths) {
  const start = parseProposalDate(startIso);
  if (!start || !Number.isFinite(termMonths) || termMonths <= 0) return null;
  const end = new Date(start);
  end.setMonth(end.getMonth() + termMonths);
  end.setDate(end.getDate() - 1);
  return end;
}

function getSelectedExpirationDate() {
  const ids = ['proposal-expiration-date', 'contract-expiration-date', 'contract-sign-expiration-date'];
  for (const id of ids) {
    const input = document.getElementById(id);
    const parsed = parseProposalDate(input?.value || '');
    if (parsed) return clampExpirationDate(startOfDay(parsed));
  }
  return getDefaultExpirationDate();
}

function configureExpirationInput(input) {
  if (!input) return;
  const { minDate, maxDate } = getExpirationBounds();
  input.min = toIsoDate(minDate);
  input.max = toIsoDate(maxDate);
}

function syncExpirationInputs(date) {
  const normalizedDate = clampExpirationDate(startOfDay(date));
  const isoValue = toIsoDate(normalizedDate);
  ['proposal-expiration-date', 'contract-expiration-date', 'contract-sign-expiration-date'].forEach((id) => {
    const input = document.getElementById(id);
    if (!input) return;
    configureExpirationInput(input);
    input.value = isoValue;
  });
}

function validateAndSyncExpirationFrom(sourceId) {
  const source = document.getElementById(sourceId);
  if (!source) {
    syncExpirationInputs(getSelectedExpirationDate());
    return true;
  }
  configureExpirationInput(source);
  const parsed = parseProposalDate(source.value || '');
  if (!parsed) {
    source.value = toIsoDate(getSelectedExpirationDate());
    return false;
  }
  const normalized = clampExpirationDate(startOfDay(parsed));
  syncExpirationInputs(normalized);
  return true;
}

function getOptionDisplayLabel(optionNumber, inSentence = false) {
  const indexedOption = options[Number(optionNumber) - 1];
  if (indexedOption?.msaPreviewFor) return 'MSA';
  // 2026-10-02 (per Catalina): pilots support multiple options again, so a
  // pilot option reads "Option N" like any other. N counts only real options,
  // skipping the hidden MSA companion options that sit in the same array.
  const userNumber = indexedOption
    ? options.filter(option => !option.msaPreviewFor).indexOf(indexedOption) + 1
    : Number(optionNumber);
  return `Option ${userNumber > 0 ? userNumber : optionNumber}`;
}

function getEvcTypeLabel(type) {
  const map = {
    'sides-rear-cargo': 'Sides, Rear & Cargo',
    'sides': 'Sides',
    'sides-rear': 'Sides & Rear',
    'rear-cargo': 'Rear and Cargo'
  };
  return map[type] || map['sides-rear-cargo'];
}

function getBundleEvcLabel(bundle) {
  if (!bundle || !bundle.evcType) return 'EVC';
  const extras = Array.isArray(bundle.evcAdditionalCameras) ? bundle.evcAdditionalCameras : [];
  if (!extras.length) return getEvcTypeLabel(bundle.evcType);
  const extraLabels = extras.map((item) => {
    if (item === 'side') return 'Side';
    if (item === 'rear') return 'Rear';
    if (item === 'cargo') return 'Cargo';
    return item;
  });
  return `${getEvcTypeLabel(bundle.evcType)} + ${extraLabels.join(' + ')}`;
}

function getMessageModulePreferenceStorageKey() {
  const repEmail = (document.getElementById('gi-rep-email')?.value || 'default-agent').trim().toLowerCase();
  const token = repEmail.replace(/[^a-z0-9._-]/g, '_') || 'default-agent';
  return MESSAGE_MODULE_STATE_KEY + '.' + token;
}

function loadMessageModulePreferences() {
  let loaded = null;
  try {
    loaded = JSON.parse(localStorage.getItem(getMessageModulePreferenceStorageKey()) || 'null');
  } catch (error) {
    loaded = null;
  }
  proposalMessageModules = Object.assign({}, messageModuleDefaults, loaded || {});
  renderMessageModuleControls();
}

function renderMessageModuleControls() {
  const mapping = {
    guarantees: 'msg-module-guarantees',
    differentiators: 'msg-module-differentiators',
    caseStudy: 'msg-module-case',
    onboarding: 'msg-module-onboarding'
  };
  Object.keys(mapping).forEach(function (key) {
    const control = document.getElementById(mapping[key]);
    if (!control) return;
    control.value = proposalMessageModules[key] || 'off';
  });
}

function getProposalMessageFormat() {
  const format = String(proposalData.messageFormat || '').trim();
  return format === MESSAGE_FORMATS.PLAIN ? MESSAGE_FORMATS.PLAIN : MESSAGE_FORMATS.VISUAL;
}

function setProposalMessageFormat(nextFormat) {
  const resolved = nextFormat === MESSAGE_FORMATS.VISUAL ? MESSAGE_FORMATS.VISUAL : MESSAGE_FORMATS.PLAIN;
  if (proposalData.messageFormat === resolved) return;
  proposalData.messageFormat = resolved;
  fillProposalMessageDefaults(true);
  renderProposalMessageFormatControl();
  updateProposalMessagePreview();
}

function renderProposalMessageFormatControl() {
  const plainBtn = document.getElementById('proposal-message-format-plain');
  const visualBtn = document.getElementById('proposal-message-format-visual');
  const format = getProposalMessageFormat();
  if (plainBtn) plainBtn.classList.toggle('segmented-control__option--active', format === MESSAGE_FORMATS.PLAIN);
  if (visualBtn) visualBtn.classList.toggle('segmented-control__option--active', format === MESSAGE_FORMATS.VISUAL);
}

function getDefaultProposalMessageBlockOrder() {
  return [
    MESSAGE_BLOCK_IDS.INTRO,
    MESSAGE_BLOCK_IDS.OPTION_INFORMATION,
    MESSAGE_BLOCK_IDS.NOTE,
    MESSAGE_BLOCK_IDS.PACKAGE_INCLUDES,
    MESSAGE_BLOCK_IDS.KEY_DIFFERENTIATORS,
    MESSAGE_BLOCK_IDS.ADDITIONAL_LINKS,
    MESSAGE_BLOCK_IDS.FOLLOW_UP
  ];
}

function createDefaultProposalMessageBlocksModel() {
  return {
    order: getDefaultProposalMessageBlockOrder(),
    blocks: {
      [MESSAGE_BLOCK_IDS.INTRO]: { visible: true, text: 'Thank you for your time today. As discussed, I have included your discounted pricing and customized fleet proposal attached to this email.' },
      [MESSAGE_BLOCK_IDS.ADDITIONAL_INFORMATION]: { visible: true, text: '' },
      [MESSAGE_BLOCK_IDS.NOTE]: { visible: true, text: 'Should you have any questions or wish to move forward before then, please don\'t hesitate to reach out directly.' },
      [MESSAGE_BLOCK_IDS.FOLLOW_UP]: { visible: true, date: toIsoDate(addCalendarDays(new Date(), 7)) },
      [MESSAGE_BLOCK_IDS.OPTION_INFORMATION]: { visible: true },
      [MESSAGE_BLOCK_IDS.ADDITIONAL_LINKS]: { visible: true, links: [
        { id: 'reveal-fleet', label: 'Reveal Demo - Fleet Maintenance', url: 'https://share.highspot.com/items/reveal-demo-fleet-maintenance', enabled: true },
        { id: 'reveal-reports', label: 'Reveal Demo - Reports', url: 'https://share.highspot.com/items/reveal-demo-reports', enabled: true },
        { id: 'reveal-geo', label: 'Reveal Demo - Geofences', url: 'https://share.highspot.com/items/reveal-demo-geofences', enabled: true },
        { id: 'reveal-pdf', label: 'Reveal Reports', url: 'https://view.highspot.com/viewer/711d013133b327ca6d6267ff7e1bb38f', enabled: true }
      ]},
      [MESSAGE_BLOCK_IDS.PACKAGE_INCLUDES]: { visible: true, items: [
        'Complete price lock guarantee on services',
        'Waived activation fees',
        'Waived equipment cost ($399-$699 value)',
        'On-site professional installation',
        '45-day rollout period'
      ]},
      [MESSAGE_BLOCK_IDS.KEY_POINTS]: { visible: true, items: defaultProposalKeyPoints.slice() },
      [MESSAGE_BLOCK_IDS.PRO_INSTALLATION]: { visible: true, text: 'Professional installation included.\n45 day rollout period applied.' },
      [MESSAGE_BLOCK_IDS.KEY_DIFFERENTIATORS]: { visible: true, level: 'detail', items: defaultProposalKeyPoints.slice() },
      [MESSAGE_BLOCK_IDS.CASE_STUDY]: { visible: true, level: 'brief' },
      [MESSAGE_BLOCK_IDS.ONBOARDING]: { visible: true, level: 'brief' },
      [MESSAGE_BLOCK_IDS.YOUR_PACKAGE]: { visible: true },
      [MESSAGE_BLOCK_IDS.WHY_VERIZON]: { visible: true }
    }
  };
}

function normalizeProposalKeyPoints(items) {
  if (!Array.isArray(items)) return [];
  return items.map(function(item) { return String(item == null ? '' : item); }).filter(function(item) { return item.trim().length > 0; });
}

function normalizeProposalMessageBlocksModel(model) {
  const fallback = createDefaultProposalMessageBlocksModel();
  if (!model || typeof model !== 'object') return fallback;
  const incomingBlocks = model.blocks && typeof model.blocks === 'object' ? model.blocks : {};
  const normalized = {
    order: Array.isArray(model.order) ? model.order.slice() : fallback.order.slice(),
    blocks: {}
  };
  const allIds = getDefaultProposalMessageBlockOrder();
  normalized.order = normalized.order.filter(function(id) { return allIds.includes(id); });
  allIds.forEach(function(id) { if (!normalized.order.includes(id)) normalized.order.push(id); });

  allIds.forEach(function(id) {
    const defaultBlock = fallback.blocks[id];
    const incoming = incomingBlocks[id] || {};
    if (id === MESSAGE_BLOCK_IDS.PACKAGE_INCLUDES || id === MESSAGE_BLOCK_IDS.KEY_DIFFERENTIATORS) {
      const incomingItems = normalizeProposalKeyPoints(incoming.items);
      normalized.blocks[id] = {
        visible: incoming.visible !== undefined ? !!incoming.visible : !!defaultBlock.visible,
        level: incoming.level || defaultBlock.level || 'detail',
        items: incomingItems.length ? incomingItems : (defaultBlock.items || []).slice()
      };
      return;
    }
    if (id === MESSAGE_BLOCK_IDS.CASE_STUDY || id === MESSAGE_BLOCK_IDS.ONBOARDING) {
      normalized.blocks[id] = {
        visible: incoming.visible !== undefined ? !!incoming.visible : !!defaultBlock.visible,
        level: incoming.level || defaultBlock.level || 'brief'
      };
      return;
    }
    if (id === MESSAGE_BLOCK_IDS.ADDITIONAL_LINKS) {
      const defaultLinks = Array.isArray(defaultBlock.links) ? defaultBlock.links : [];
      const incomingLinks = Array.isArray(incoming.links) ? incoming.links : [];
      const merged = defaultLinks.map(function(def) {
        const found = incomingLinks.find(function(l) { return l.id === def.id; });
        return found ? {
          id: def.id,
          label: String(found.label || def.label),
          url: String(found.url || def.url),
          enabled: found.enabled !== undefined ? !!found.enabled : !!def.enabled
        } : Object.assign({}, def);
      });
      const extraLinks = incomingLinks
        .filter(function(l) { return !defaultLinks.find(function(d) { return d.id === l.id; }); })
        .slice(0, Math.max(0, 5 - merged.length))
        .map(function(l) {
          return {
            id: String(l.id || Date.now()),
            label: String(l.label || ''),
            url: String(l.url || ''),
            enabled: !!l.enabled,
            custom: !!l.custom
          };
        });
      normalized.blocks[id] = {
        visible: incoming.visible !== undefined ? !!incoming.visible : !!defaultBlock.visible,
        links: merged.concat(extraLinks)
      };
      return;
    }
    normalized.blocks[id] = {
      visible: incoming.visible !== undefined ? !!incoming.visible : !!defaultBlock.visible,
      text: String(incoming.text != null ? incoming.text : (defaultBlock.text || '')),
      date: String(incoming.date != null ? incoming.date : (defaultBlock.date || ''))
    };
  });
  return normalized;
}

function getProposalMessageBlocksModel() {
  if (!proposalMessageBlocksModel) {
    proposalMessageBlocksModel = normalizeProposalMessageBlocksModel(proposalData.messageBlocksModel || null);
    proposalData.messageBlocksModel = JSON.parse(JSON.stringify(proposalMessageBlocksModel));
  }
  return proposalMessageBlocksModel;
}

function persistProposalMessageBlocksModel() {
  if (proposalMessageBlocksModel) {
    proposalData.messageBlocksModel = JSON.parse(JSON.stringify(proposalMessageBlocksModel));
  }
}

function onProposalMessageBlocksChanged(options) {
  const shouldRerenderEditor = !!(options && options.rerenderEditor);
  persistProposalMessageBlocksModel();
  fillProposalMessageDefaults(true);
  if (shouldRerenderEditor) renderProposalMsgContentChecklist();
}

function setActiveProposalMessageBlockTextarea(blockId) {
  if (!blockId) return;
  proposalActiveMessageBlockId = blockId;
}

function onProposalMessageBlockTextInput(blockId, value) {
  const model = getProposalMessageBlocksModel();
  const block = model.blocks[blockId];
  if (!block || typeof block.text !== 'string') return;
  block.text = String(value == null ? '' : value);
  persistProposalMessageBlocksModel();
  clearTimeout(window._msgBlockTextInputTimer);
  window._msgBlockTextInputTimer = setTimeout(function() { fillProposalMessageDefaults(true); }, 300);
}

function onProposalMessageBlockDateInput(blockId, value) {
  const model = getProposalMessageBlocksModel();
  const block = model.blocks[blockId];
  if (!block) return;
  block.date = String(value == null ? '' : value);
  onProposalMessageBlocksChanged({ rerenderEditor: false });
}

function onProposalMessageBlockListItemInput(blockId, itemIndex, value) {
  const model = getProposalMessageBlocksModel();
  const block = model.blocks[blockId];
  if (!block || !Array.isArray(block.items) || itemIndex < 0 || itemIndex >= block.items.length) return;
  block.items[itemIndex] = String(value == null ? '' : value);
  onProposalMessageBlocksChanged({ rerenderEditor: false });
}

function addProposalMessageBlockListItem(blockId) {
  const model = getProposalMessageBlocksModel();
  const block = model.blocks[blockId];
  if (!block || !Array.isArray(block.items)) return;
  block.items.push('');
  onProposalMessageBlocksChanged({ rerenderEditor: true });
}

function removeProposalMessageBlockListItem(blockId, itemIndex) {
  const model = getProposalMessageBlocksModel();
  const block = model.blocks[blockId];
  if (!block || !Array.isArray(block.items) || itemIndex < 0 || itemIndex >= block.items.length) return;
  block.items.splice(itemIndex, 1);
  if (!block.items.length) block.items.push('');
  onProposalMessageBlocksChanged({ rerenderEditor: true });
}

function onProposalMessageBlockItemDragStart(event, blockId, itemIndex) {
  proposalKeyPointDragIndex = itemIndex;
  const row = event.currentTarget.closest('.msg-inline-list-row');
  if (row) row.classList.add('is-dragging');
  document.body.classList.add('is-dragging-block');
  if (event.dataTransfer) event.dataTransfer.effectAllowed = 'move';
  event.currentTarget.dataset.dragBlockId = blockId;
}

function onProposalMessageBlockItemDragEnd(event) {
  proposalKeyPointDragIndex = -1;
  const row = event.currentTarget.closest('.msg-inline-list-row');
  if (row) row.classList.remove('is-dragging');
  document.body.classList.remove('is-dragging-block');
  document.querySelectorAll('.msg-inline-list-row.is-drag-over').forEach(function(el) {
    el.classList.remove('is-drag-over');
  });
}

function onProposalMessageBlockItemDragOver(event, blockId, itemIndex) {
  event.preventDefault();
  if (itemIndex === proposalKeyPointDragIndex) return;
  event.currentTarget?.classList.add('is-drag-over');
}

function onProposalMessageBlockItemDrop(event, blockId, targetIndex) {
  event.preventDefault();
  event.currentTarget?.classList.remove('is-drag-over');
  const fromIndex = proposalKeyPointDragIndex;
  const model = getProposalMessageBlocksModel();
  const block = model.blocks[blockId];
  if (!block || !Array.isArray(block.items)) return;
  if (fromIndex < 0 || fromIndex === targetIndex) return;
  const moved = block.items.splice(fromIndex, 1)[0];
  block.items.splice(targetIndex, 0, moved);
  onProposalMessageBlocksChanged({ rerenderEditor: true });
}

function onMsgContentItemToggle(blockId, checked) {
  const model = getProposalMessageBlocksModel();
  if (!model.blocks[blockId]) return;
  if (blockId === MESSAGE_BLOCK_IDS.INTRO) return;
  model.blocks[blockId].visible = checked;
  model.blocks[blockId]._touched = true;
  proposalData.messageBlocksModel = JSON.parse(JSON.stringify(model));
  renderProposalMsgContentChecklist();
  fillProposalMessageDefaults(true);
  renderCustomizationSummary();
}

function onMsgContentLevelChange(blockId, level) {
  const model = getProposalMessageBlocksModel();
  if (!model.blocks[blockId]) return;
  model.blocks[blockId].level = level;
  proposalData.messageBlocksModel = JSON.parse(JSON.stringify(model));
  fillProposalMessageDefaults(true);
  renderCustomizationSummary();
}

function _getAdditionalLinksBlock() {
  const model = getProposalMessageBlocksModel();
  return model.blocks[MESSAGE_BLOCK_IDS.ADDITIONAL_LINKS] || (model.blocks[MESSAGE_BLOCK_IDS.ADDITIONAL_LINKS] = { visible: true, links: [] });
}

function _refreshAdditionalLinksUI() {
  renderProposalMsgContentChecklist();
  clearTimeout(window._addLinksRefreshTimer);
  window._addLinksRefreshTimer = setTimeout(function() { fillProposalMessageDefaults(true); }, 120);
}

function onAdditionalLinkLabelInput(idx, value) {
  const block = _getAdditionalLinksBlock();
  if (block.links[idx]) {
    block.links[idx].label = String(value || '');
    persistProposalMessageBlocksModel();
    clearTimeout(window._addLinksRefreshTimer);
    window._addLinksRefreshTimer = setTimeout(function() { fillProposalMessageDefaults(true); }, 300);
  }
}

function onAdditionalLinkUrlInput(idx, value) {
  const block = _getAdditionalLinksBlock();
  if (block.links[idx]) {
    block.links[idx].url = String(value || '').trim();
    persistProposalMessageBlocksModel();
    clearTimeout(window._addLinksRefreshTimer);
    window._addLinksRefreshTimer = setTimeout(function() { fillProposalMessageDefaults(true); }, 300);
  }
}

function removeAdditionalLink(idx) {
  const block = _getAdditionalLinksBlock();
  block.links.splice(idx, 1);
  persistProposalMessageBlocksModel();
  _refreshAdditionalLinksUI();
}

function onAdditionalLinkDragStart(event, idx) {
  _addLinksDragIdx = idx;
  const row = event.currentTarget.closest('.msg-addlink-row');
  if (row) row.classList.add('is-dragging');
  document.body.classList.add('is-dragging-block');
  event.dataTransfer.effectAllowed = 'move';
}

function onAdditionalLinkDragEnd(event) {
  _addLinksDragIdx = -1;
  const row = event.currentTarget.closest('.msg-addlink-row');
  if (row) row.classList.remove('is-dragging');
  document.body.classList.remove('is-dragging-block');
  document.querySelectorAll('.msg-addlink-row').forEach(function(r) { r.classList.remove('is-drag-over'); });
}

function onAdditionalLinkDragOver(event, idx) {
  event.preventDefault();
  if (_addLinksDragIdx === -1 || _addLinksDragIdx === idx) return;
  event.currentTarget.classList.add('is-drag-over');
}

function onAdditionalLinkDrop(event, idx) {
  event.preventDefault();
  event.currentTarget.classList.remove('is-drag-over');
  if (_addLinksDragIdx === -1 || _addLinksDragIdx === idx) return;
  const block = _getAdditionalLinksBlock();
  const moved = block.links.splice(_addLinksDragIdx, 1)[0];
  block.links.splice(idx, 0, moved);
  _addLinksDragIdx = -1;
  persistProposalMessageBlocksModel();
  _refreshAdditionalLinksUI();
}

function _getAddLinksSuggestionsEl() { return document.getElementById('addlinks-suggestions'); }

function _getAddLinksSearchInput() { return document.getElementById('addlinks-search-input'); }

function showAddLinksSuggestions() {
  const input = _getAddLinksSearchInput();
  const el = _getAddLinksSuggestionsEl();
  if (!el || !input) return;
  const rect = input.getBoundingClientRect();
  el.style.top = (rect.bottom + 4) + 'px';
  el.style.left = rect.left + 'px';
  el.style.width = rect.width + 'px';
  filterAddLinksSuggestions(input.value || '');
}

function filterAddLinksSuggestions(query) {
  const el = _getAddLinksSuggestionsEl();
  if (!el) return;
  const block = _getAdditionalLinksBlock();
  const existingIds = new Set((block.links || []).map(function(l) { return l.id; }));
  const q = query.trim().toLowerCase();
  const results = ADDITIONAL_LINKS_CATALOG.filter(function(item) {
    return !existingIds.has(item.id) && (!q || item.label.toLowerCase().includes(q));
  });
  if (!results.length) {
    el.innerHTML = '<div class="addlinks-suggestion-empty">' + (q ? 'No results for "' + q + '"' : 'No more materials to add') + '</div>';
  } else {
    el.innerHTML = results.map(function(item) {
      return '<div class="addlinks-suggestion-item" onmousedown="selectAddLinkSuggestion(\'' + item.id + '\')">' +
        '<span class="material-symbols-outlined">link</span>' +
        '<span>' + item.label + '</span>' +
      '</div>';
    }).join('');
  }
  el.classList.remove('hidden');
}

function hideAddLinksSuggestionsDelayed() {
  setTimeout(function() {
    const el = _getAddLinksSuggestionsEl();
    const input = _getAddLinksSearchInput();
    if (el) el.classList.add('hidden');
    if (input) input.value = '';
  }, 180);
}

function selectAddLinkSuggestion(id) {
  const catalog = ADDITIONAL_LINKS_CATALOG.find(function(c) { return c.id === id; });
  if (!catalog) return;
  const block = _getAdditionalLinksBlock();
  if (block.links.length >= 5) return;
  block.links.push({ id: catalog.id, label: catalog.label, url: catalog.url, enabled: true });
  persistProposalMessageBlocksModel();
  _refreshAdditionalLinksUI();
  const el = _getAddLinksSuggestionsEl();
  const input = _getAddLinksSearchInput();
  if (el) el.classList.add('hidden');
  if (input) input.value = '';
}

function renderProposalMessageBlockTokenPicker() {
  const host = document.getElementById('proposal-message-token-picker');
  if (!host) return;
  const options = [
    { key: 'contactName', label: 'Contact Name' },
    { key: 'repName', label: 'Rep Name' },
    { key: 'repEmail', label: 'Rep Email' },
    { key: 'repPhone', label: 'Rep Phone' },
    { key: 'expirationDate', label: 'Expiration Date' }
  ];
  host.innerHTML = options.map(function(item) {
    return '<button type="button" class="proposal-token-chip-btn" onclick="insertProposalMessageBlockToken(\'' + proposalEscapeHtml(item.key) + '\')">+' + proposalEscapeHtml(item.label) + '</button>';
  }).join('');
}

function insertProposalMessageBlockToken(tokenKey) {
  const marker = '{{' + String(tokenKey || '') + '}}';
  const model = getProposalMessageBlocksModel();
  const activeBlockId = proposalActiveMessageBlockId || MESSAGE_BLOCK_IDS.INTRO;
  const activeBlock = model.blocks[activeBlockId];
  if (!activeBlock || typeof activeBlock.text !== 'string') return;
  const activeTextarea = document.getElementById('msg-inline-textarea-' + activeBlockId);
  if (!activeTextarea) {
    activeBlock.text += marker;
    onProposalMessageBlocksChanged({ rerenderEditor: true });
    return;
  }
  const start = activeTextarea.selectionStart || 0;
  const end = activeTextarea.selectionEnd || 0;
  const current = activeBlock.text || '';
  activeBlock.text = current.slice(0, start) + marker + current.slice(end);
  onProposalMessageBlocksChanged({ rerenderEditor: true });
}

function renderProposalMsgContentChecklist() {
  const host = document.getElementById('proposal-msg-content-list');
  if (!host) return;
  const model = getProposalMessageBlocksModel();
  const MANDATORY = [MESSAGE_BLOCK_IDS.INTRO];
  const OPTIONAL = [MESSAGE_BLOCK_IDS.OPTION_INFORMATION, MESSAGE_BLOCK_IDS.NOTE, MESSAGE_BLOCK_IDS.PACKAGE_INCLUDES, MESSAGE_BLOCK_IDS.KEY_DIFFERENTIATORS];
  const HAS_LEVEL = new Set([MESSAGE_BLOCK_IDS.CASE_STUDY, MESSAGE_BLOCK_IDS.ONBOARDING]);
  const HAS_TEXT = new Set([MESSAGE_BLOCK_IDS.INTRO]);
  const HAS_LIST = new Set([MESSAGE_BLOCK_IDS.PACKAGE_INCLUDES]);
  const LABELS = {
    intro: 'Intro',
    optionInformation: 'Pricing Summary',
    note: 'Expiration Date',
    packageIncludes: 'What\'s Included',
    keyDifferentiators: 'Key Differentiators',
    caseStudy: 'Case study mention',
    onboarding: 'Onboarding mention',
    followUp: 'Follow up'
  };

  function renderInlineEditor(blockId, block) {
    if (blockId === MESSAGE_BLOCK_IDS.FOLLOW_UP) {
      return '<div class="msg-content-item-editor"><label class="vc-field-label" style="display:block;font-weight:400;color:var(--black);font-size:11px;margin-bottom:6px;">Follow-up date</label><div class="vc-date-field"><input type="date" class="input" value="' + proposalEscapeHtml(block.date || '') + '" onchange="onProposalMessageBlockDateInput(\'' + blockId + '\', this.value)"><span class="material-symbols-outlined vc-date-field__icon" aria-hidden="true">calendar_month</span></div></div>';
    }
    if (HAS_TEXT.has(blockId)) {
      return '<div class="msg-content-item-editor"><textarea id="msg-inline-textarea-' + blockId + '" class="msg-inline-textarea" rows="3" onfocus="setActiveProposalMessageBlockTextarea(\'' + blockId + '\')" oninput="onProposalMessageBlockTextInput(\'' + blockId + '\', this.value)">' + proposalEscapeHtml(block.text || '') + '</textarea></div>';
    }
    if (HAS_LIST.has(blockId)) {
      const items = block.items || [];
      const rowsHtml = items.map(function(item, idx) {
        return '<div class="msg-inline-list-row" ondragover="onProposalMessageBlockItemDragOver(event,\'' + blockId + '\',' + idx + ')" ondragleave="event.currentTarget.classList.remove(\'is-drag-over\')" ondrop="onProposalMessageBlockItemDrop(event,\'' + blockId + '\',' + idx + ')"><span class="material-symbols-outlined msg-inline-drag-handle" draggable="true" ondragstart="onProposalMessageBlockItemDragStart(event,\'' + blockId + '\',' + idx + ')" ondragend="onProposalMessageBlockItemDragEnd(event)">drag_indicator</span><input type="text" class="msg-inline-item-input input" value="' + proposalEscapeHtml(item) + '" oninput="onProposalMessageBlockListItemInput(\'' + blockId + '\',' + idx + ',this.value)"><button type="button" class="btn-icon btn-icon--ghost-vds btn-icon--fit msg-inline-item-delete" aria-label="Delete" onclick="removeProposalMessageBlockListItem(\'' + blockId + '\',' + idx + ')"><span class="material-symbols-outlined" aria-hidden="true">delete</span></button></div>';
      }).join('');
      return '<div class="msg-content-item-editor"><div class="msg-inline-list">' + rowsHtml + '</div><button type="button" class="btn-dashed-add btn-dashed-add--pill" onclick="addProposalMessageBlockListItem(\'' + blockId + '\')">+ Add item</button></div>';
    }
    return '';
  }

  function renderItem(blockId, isMandatory) {
    const block = model.blocks[blockId] || {};
    const visible = isMandatory ? true : !!block.visible;
    const label = LABELS[blockId] || blockId;
    const hasLevel = HAS_LEVEL.has(blockId);
    const level = block.level || 'brief';
    const cbId = 'msg-cb-' + blockId;
    if (isMandatory) {
      return '<div class="msg-content-item msg-content-item--mandatory"><div class="msg-content-item-header"><span class="msg-content-item-title">' + proposalEscapeHtml(label) + '</span></div>' + renderInlineEditor(blockId, block) + '</div>';
    }
    const cb = '<label class="checkbox" onclick="event.stopPropagation()"><input type="checkbox" class="checkbox__input" id="' + cbId + '" aria-label="' + proposalEscapeHtml(label) + '"' + (visible ? ' checked' : '') + ' onclick="event.stopPropagation()" onchange="onMsgContentItemToggle(\'' + blockId + '\',this.checked)"><span class="checkbox__content"></span></label>';
    let editorHtml = '';
    if (visible) {
      if (hasLevel) {
        editorHtml = '<div class="msg-content-item-detail"><select class="select select--small" onchange="onMsgContentLevelChange(\'' + blockId + '\',this.value)"><option value="brief"' + (level === 'brief' ? ' selected' : '') + '>Brief mention</option><option value="detail"' + (level === 'detail' ? ' selected' : '') + '>Full detail</option></select></div>';
      } else {
        editorHtml = renderInlineEditor(blockId, block);
      }
    }
    return '<div class="msg-content-item"><div class="msg-content-item-header" onclick="var cb=document.getElementById(\'' + cbId + '\');cb.checked=!cb.checked;onMsgContentItemToggle(\'' + blockId + '\',cb.checked);">' + cb + '<span class="msg-content-item-title">' + proposalEscapeHtml(label) + '</span></div>' + editorHtml + '</div>';
  }

  function renderAdditionalMaterialsSection() {
    const block = model.blocks[MESSAGE_BLOCK_IDS.ADDITIONAL_LINKS] || {};
    const links = Array.isArray(block.links) ? block.links : [];
    const atMax = links.length >= 5;
    const rowsHtml = links.map(function(link, idx) {
      const isCustom = !!link.custom;
      if (isCustom) {
        return '<div class="msg-addlink-row msg-addlink-row--custom" data-idx="' + idx + '">' +
          '<span class="material-symbols-outlined msg-inline-drag-handle" draggable="true" ondragstart="onProposalMessageBlockItemDragStart(event,\'additionalLinks\',' + idx + ')" ondragend="onProposalMessageBlockItemDragEnd(event)">drag_indicator</span>' +
          '<input type="text" class="input msg-addlink-label" placeholder="Label" value="' + proposalEscapeHtml(link.label || '') + '" oninput="onAdditionalLinkLabelInput(' + idx + ',this.value)">' +
          '<input type="url" class="input msg-addlink-url" placeholder="https://" value="' + proposalEscapeHtml(link.url || '') + '" oninput="onAdditionalLinkUrlInput(' + idx + ',this.value)">' +
          '<button type="button" class="btn-icon btn-icon--ghost-vds btn-icon--fit msg-inline-item-delete" aria-label="Delete" onclick="removeAdditionalLink(' + idx + ')"><span class="material-symbols-outlined" aria-hidden="true">delete</span></button>' +
        '</div>';
      }
      return '<div class="msg-addlink-row" data-idx="' + idx + '" ondragover="onAdditionalLinkDragOver(event,' + idx + ')" ondragleave="event.currentTarget.classList.remove(\'is-drag-over\')" ondrop="onAdditionalLinkDrop(event,' + idx + ')">' +
        '<span class="material-symbols-outlined msg-inline-drag-handle" draggable="true" ondragstart="onAdditionalLinkDragStart(event,' + idx + ')" ondragend="onAdditionalLinkDragEnd(event)">drag_indicator</span>' +
        '<div class="msg-addlink-display">' + proposalEscapeHtml(link.label || 'Link') + '</div>' +
        '<button type="button" class="btn-icon btn-icon--ghost-vds btn-icon--fit msg-inline-item-delete" aria-label="Delete" onclick="removeAdditionalLink(' + idx + ')"><span class="material-symbols-outlined" aria-hidden="true">delete</span></button>' +
      '</div>';
    }).join('');
    return '<div class="msg-content-item">' +
      '<div class="msg-content-item-header" onclick="var cb=document.getElementById(\'addlinks-cb\');cb.checked=!cb.checked;onMsgContentItemToggle(\'additionalLinks\',cb.checked)">' +
        '<label class="checkbox" onclick="event.stopPropagation()"><input type="checkbox" class="checkbox__input" id="addlinks-cb" aria-label="Additional materials"' + (block.visible !== false ? ' checked' : '') + ' onclick="event.stopPropagation()" onchange="onMsgContentItemToggle(\'additionalLinks\',this.checked)"><span class="checkbox__content"></span></label>' +
        '<span class="msg-content-item-title">Additional materials</span>' +
        '<span class="msg-content-item-hint" style="font-size:11px;color:var(--gray-400);">' + links.length + '/5</span>' +
      '</div>' +
      (block.visible !== false ? '<div class="msg-content-item-editor" style="display:flex;flex-direction:column;gap:4px;">' +
        '<div id="addlinks-list" style="display:flex;flex-direction:column;gap:0;">' + rowsHtml + '</div>' +
        (!atMax ? '<div class="addlinks-search-wrap" style="margin-top:8px;">' +
          '<span class="material-symbols-outlined addlinks-search-icon">search</span>' +
          '<input type="text" class="addlinks-search-input" id="addlinks-search-input" placeholder="Search materials..." autocomplete="off" onfocus="showAddLinksSuggestions()" oninput="filterAddLinksSuggestions(this.value)" onblur="hideAddLinksSuggestionsDelayed()">' +
          '<div class="addlinks-suggestions hidden" id="addlinks-suggestions"></div>' +
        '</div>' : '<div style="font-size:11px;color:var(--gray-400);text-align:center;margin-top:8px;padding:6px 0;">Maximum 5 items</div>') +
      '</div>' : '') +
    '</div>';
  }

  host.innerHTML = '<div class="msg-content-list">' +
    MANDATORY.map(function(id) { return renderItem(id, true); }).join('') +
    OPTIONAL.map(function(id) { return renderItem(id, false); }).join('') +
    renderAdditionalMaterialsSection() +
    renderItem(MESSAGE_BLOCK_IDS.FOLLOW_UP, false) +
  '</div>';
  setTimeout(() => VC.initDatePickers(host), 0);
}

  function renderInlineEditor(blockId, block) {
    if (blockId === MESSAGE_BLOCK_IDS.FOLLOW_UP) {
      return '<div class="msg-content-item-editor"><label class="vc-field-label" style="display:block;font-weight:400;color:var(--black);font-size:11px;margin-bottom:6px;">Follow-up date</label><div class="vc-date-field"><input type="date" class="input" value="' + proposalEscapeHtml(block.date || '') + '" onchange="onProposalMessageBlockDateInput(\'' + blockId + '\', this.value)"><span class="material-symbols-outlined vc-date-field__icon" aria-hidden="true">calendar_month</span></div></div>';
    }
    if (HAS_TEXT.has(blockId)) {
      return '<div class="msg-content-item-editor"><textarea id="msg-inline-textarea-' + blockId + '" class="msg-inline-textarea" rows="3" onfocus="setActiveProposalMessageBlockTextarea(\'' + blockId + '\')" oninput="onProposalMessageBlockTextInput(\'' + blockId + '\', this.value)">' + proposalEscapeHtml(block.text || '') + '</textarea></div>';
    }
    if (HAS_LIST.has(blockId)) {
      const items = block.items || [];
      const rowsHtml = items.map(function(item, idx) {
        return '<div class="msg-inline-list-row" ondragover="onProposalMessageBlockItemDragOver(event,\'' + blockId + '\',' + idx + ')" ondragleave="event.currentTarget.classList.remove(\'is-drag-over\')" ondrop="onProposalMessageBlockItemDrop(event,\'' + blockId + '\',' + idx + ')"><span class="material-symbols-outlined msg-inline-drag-handle" draggable="true" ondragstart="onProposalMessageBlockItemDragStart(event,\'' + blockId + '\',' + idx + ')" ondragend="onProposalMessageBlockItemDragEnd(event)">drag_indicator</span><input type="text" class="msg-inline-item-input input" value="' + proposalEscapeHtml(item) + '" oninput="onProposalMessageBlockListItemInput(\'' + blockId + '\',' + idx + ',this.value)"><button type="button" class="btn-icon btn-icon--ghost-vds btn-icon--fit msg-inline-item-delete" aria-label="Delete" onclick="removeProposalMessageBlockListItem(\'' + blockId + '\',' + idx + ')"><span class="material-symbols-outlined" aria-hidden="true">delete</span></button></div>';
      }).join('');
      return '<div class="msg-content-item-editor"><div class="msg-inline-list">' + rowsHtml + '</div><button type="button" class="btn-dashed-add btn-dashed-add--pill" onclick="addProposalMessageBlockListItem(\'' + blockId + '\')">+ Add item</button></div>';
    }
    return '';
  }

  function renderItem(blockId, isMandatory) {
    const block = model.blocks[blockId] || {};
    const visible = isMandatory ? true : !!block.visible;
    const label = LABELS[blockId] || blockId;
    const hasLevel = HAS_LEVEL.has(blockId);
    const level = block.level || 'brief';
    const cbId = 'msg-cb-' + blockId;
    if (isMandatory) {
      return '<div class="msg-content-item msg-content-item--mandatory"><div class="msg-content-item-header"><span class="msg-content-item-title">' + proposalEscapeHtml(label) + '</span></div>' + renderInlineEditor(blockId, block) + '</div>';
    }
    const cb = '<label class="checkbox" onclick="event.stopPropagation()"><input type="checkbox" class="checkbox__input" id="' + cbId + '" aria-label="' + proposalEscapeHtml(label) + '"' + (visible ? ' checked' : '') + ' onclick="event.stopPropagation()" onchange="onMsgContentItemToggle(\'' + blockId + '\',this.checked)"><span class="checkbox__content"></span></label>';
    let editorHtml = '';
    if (visible) {
      if (hasLevel) {
        editorHtml = '<div class="msg-content-item-detail"><select class="select select--small" onchange="onMsgContentLevelChange(\'' + blockId + '\',this.value)"><option value="brief"' + (level === 'brief' ? ' selected' : '') + '>Brief mention</option><option value="detail"' + (level === 'detail' ? ' selected' : '') + '>Full detail</option></select></div>';
      } else {
        editorHtml = renderInlineEditor(blockId, block);
      }
    }
    return '<div class="msg-content-item"><div class="msg-content-item-header" onclick="var cb=document.getElementById(\'' + cbId + '\');cb.checked=!cb.checked;onMsgContentItemToggle(\'' + blockId + '\',cb.checked);">' + cb + '<span class="msg-content-item-title">' + proposalEscapeHtml(label) + '</span></div>' + editorHtml + '</div>';
  }

  function renderAdditionalMaterialsSection() {
    const block = model.blocks[MESSAGE_BLOCK_IDS.ADDITIONAL_LINKS] || {};
    const links = Array.isArray(block.links) ? block.links : [];
    const atMax = links.length >= 5;
    const rowsHtml = links.map(function(link, idx) {
      const isCustom = !!link.custom;
      if (isCustom) {
        return '<div class="msg-addlink-row msg-addlink-row--custom" data-idx="' + idx + '">' +
          '<span class="material-symbols-outlined msg-inline-drag-handle" draggable="true" ondragstart="onProposalMessageBlockItemDragStart(event,\'additionalLinks\',' + idx + ')" ondragend="onProposalMessageBlockItemDragEnd(event)">drag_indicator</span>' +
          '<input type="text" class="input msg-addlink-label" placeholder="Label" value="' + proposalEscapeHtml(link.label || '') + '" oninput="onAdditionalLinkLabelInput(' + idx + ',this.value)">' +
          '<input type="url" class="input msg-addlink-url" placeholder="https://" value="' + proposalEscapeHtml(link.url || '') + '" oninput="onAdditionalLinkUrlInput(' + idx + ',this.value)">' +
          '<button type="button" class="btn-icon btn-icon--ghost-vds btn-icon--fit msg-inline-item-delete" aria-label="Delete" onclick="removeAdditionalLink(' + idx + ')"><span class="material-symbols-outlined" aria-hidden="true">delete</span></button>' +
        '</div>';
      }
      return '<div class="msg-addlink-row" data-idx="' + idx + '" ondragover="onAdditionalLinkDragOver(event,' + idx + ')" ondragleave="event.currentTarget.classList.remove(\'is-drag-over\')" ondrop="onAdditionalLinkDrop(event,' + idx + ')">' +
        '<span class="material-symbols-outlined msg-inline-drag-handle" draggable="true" ondragstart="onAdditionalLinkDragStart(event,' + idx + ')" ondragend="onAdditionalLinkDragEnd(event)">drag_indicator</span>' +
        '<div class="msg-addlink-display">' + proposalEscapeHtml(link.label || 'Link') + '</div>' +
        '<button type="button" class="btn-icon btn-icon--ghost-vds btn-icon--fit msg-inline-item-delete" aria-label="Delete" onclick="removeAdditionalLink(' + idx + ')"><span class="material-symbols-outlined" aria-hidden="true">delete</span></button>' +
      '</div>';
    }).join('');
    return '<div class="msg-content-item">' +
      '<div class="msg-content-item-header" onclick="var cb=document.getElementById(\'addlinks-cb\');cb.checked=!cb.checked;onMsgContentItemToggle(\'additionalLinks\',cb.checked)">' +
        '<label class="checkbox" onclick="event.stopPropagation()"><input type="checkbox" class="checkbox__input" id="addlinks-cb" aria-label="Additional materials"' + (block.visible !== false ? ' checked' : '') + ' onclick="event.stopPropagation()" onchange="onMsgContentItemToggle(\'additionalLinks\',this.checked)"><span class="checkbox__content"></span></label>' +
        '<span class="msg-content-item-title">Additional materials</span>' +
        '<span class="msg-content-item-hint" style="font-size:11px;color:var(--gray-400);">' + links.length + '/5</span>' +
      '</div>' +
      (block.visible !== false ? '<div class="msg-content-item-editor" style="display:flex;flex-direction:column;gap:4px;">' +
        '<div id="addlinks-list" style="display:flex;flex-direction:column;gap:0;">' + rowsHtml + '</div>' +
        (!atMax ? '<div class="addlinks-search-wrap" style="margin-top:8px;">' +
          '<span class="material-symbols-outlined addlinks-search-icon">search</span>' +
          '<input type="text" class="addlinks-search-input" id="addlinks-search-input" placeholder="Search materials..." autocomplete="off" onfocus="showAddLinksSuggestions()" oninput="filterAddLinksSuggestions(this.value)" onblur="hideAddLinksSuggestionsDelayed()">' +
          '<div class="addlinks-suggestions hidden" id="addlinks-suggestions"></div>' +
        '</div>' : '<div style="font-size:11px;color:var(--gray-400);text-align:center;margin-top:8px;padding:6px 0;">Maximum 5 items</div>') +
      '</div>' : '') +
    '</div>';
  }

function renderMessageBlockTemplate(text, tokenMap) {
  let escaped = proposalEscapeHtml(String(text || ''));
  Object.keys(tokenMap).forEach(function(key) {
    const marker = '{{' + key + '}}';
    escaped = escaped.split(marker).join(tokenMap[key]);
  });
  return escaped.replace(/\n/g, '<br>');
}

function buildProposalPlainOptionSummaryHtml() {
  if (!Array.isArray(options) || !options.length) return '';

  return options.map(function (opt, optIdx) {
    if (!isOptionSendableInProposal(opt)) return '';
    let totalUnits = 0;
    opt.bundles.forEach(function (bundle) { totalUnits += bundle.qty; });
    const termMonths = parseInt(opt.term, 10);
    const result = calcOption(opt, getOptionPromotion(opt));

    const bundleLinesHtml = opt.bundles.map(function (bundle) {
      const bundleResult = calcBundle(bundle, opt.term, bundle.promoType || 'Standard', totalUnits);
      const featNames = (bundle.features || bundle.selectedFeatures || [])
        .map(function (featureKey) { return featureLabels[featureKey] || featureKey; })
        .filter(Boolean);
      const desc = featNames.length ? (bundle.coreName + ' + ' + featNames.join(' + ')) : bundle.coreName;
      return proposalEscapeHtml(bundle.qty + 'x ' + desc) + ' - ' + formatMoney(bundleResult.unitPrice) + '/mo';
    }).join('<br>');

    const vehicleWord = totalUnits === 1 ? 'vehicle' : 'vehicles';
    return '' +
      '<div>' +
        '<strong>' + proposalEscapeHtml(getOptionDisplayLabel(optIdx + 1)) + ' - ' + termMonths + ' Month</strong><br>' +
        bundleLinesHtml + '<br>' +
        '<strong>Total for ' + totalUnits + ' ' + vehicleWord + ': ' + formatMoney(result.totalMonthly) + '/mo</strong>' +
      '</div>';
  }).join('<br><br>');
}

function buildProposalPlainAdditionalMaterialsHtml(model) {
  if (!model || !model.blocks) return '';
  const block = model.blocks[MESSAGE_BLOCK_IDS.ADDITIONAL_LINKS];
  if (!block || block.visible === false) return '';
  const activeLinks = (block.links || []).filter(function(l) { return l.enabled && l.url; });
  if (!activeLinks.length) return '';
  const lines = activeLinks.map(function(l) {
    return proposalEscapeHtml(l.label || 'Link') + ': <a href="' + proposalEscapeHtml(l.url) + '" target="_blank" rel="noreferrer">' + proposalEscapeHtml(l.url) + '</a>';
  });
  return '<strong>Additional materials</strong><br>' + lines.join('<br>');
}

function buildProposalVisualSectionFromBlock(blockId, block, tokenMap, context) {
  if (!block || !block.visible) return '';

  if (blockId === MESSAGE_BLOCK_IDS.INTRO) {
    const greeting = tokenMap.contactName ? 'Hi <strong>' + tokenMap.contactName + '</strong>,<br>' : '';
    const intro = renderMessageBlockTemplate(block.text, tokenMap);
    return '<div class="vez-email__block vez-email__block--no-border">' +
      '<div>' + greeting + intro + '</div>' +
    '</div>';
  }

  if (blockId === MESSAGE_BLOCK_IDS.OPTION_INFORMATION) {
    if (!context.optionBlocksHtml) return '';
    return '<div class="vez-email__block">' +
      '<p>Here\'s a quick summary of what you\'ll find in the full proposal.</p>' +
      '<div class="vez-email__pricing">' + context.optionBlocksHtml + '</div>' +
    '</div>';
  }

  if (blockId === MESSAGE_BLOCK_IDS.ADDITIONAL_INFORMATION) {
    const text = renderMessageBlockTemplate(block.text, tokenMap);
    if (!text.trim()) return '';
    return '<div class="vez-email__block"><div>' + text + '</div></div>';
  }

  if (blockId === MESSAGE_BLOCK_IDS.NOTE) {
    const dateLine = tokenMap.expirationDate ? '<p class="vez-email__note-date">Valid through ' + tokenMap.expirationDate + '</p>' : '';
    const restText = renderMessageBlockTemplate(block.text, tokenMap);
    const restLine = restText.trim() ? '<p>' + restText + '</p>' : '';
    return '<div class="vez-email__note-block">' + dateLine + restLine + '</div>';
  }

  if (blockId === MESSAGE_BLOCK_IDS.FOLLOW_UP) {
    const followUpDate = parseProposalDate(block.date);
    if (!followUpDate) return '';
    return '<div class="vez-email__block">' +
      '<div class="vez-email__followup-grid">' +
        '<div class="vez-email__followup-title">Questions?</div>' +
        '<div class="vez-email__followup-copy">' +
          '<div>Reach me directly at <strong>' + tokenMap.repPhone + '</strong></div>' +
          '<div>I\'ll follow up with you as discussed on <strong>' + formatUsDate(followUpDate) + '</strong>.</div>' +
        '</div>' +
      '</div>' +
    '</div>';
  }

  if (blockId === MESSAGE_BLOCK_IDS.PACKAGE_INCLUDES) {
    const items = normalizeProposalKeyPoints(block.items || []);
    if (!items.length) return '';
    const rows = items.map(function (item) {
      return '<div class="vez-email__check-item"><span class="material-symbols-outlined">check_circle</span><span>' + proposalEscapeHtml(item) + '</span></div>';
    }).join('');
    return '<div class="vez-email__block"><h3 class="vez-email__block-label">What\'s included at no extra cost.</h3><div class="vez-email__check-list">' + rows + '</div></div>';
  }

  if (blockId === MESSAGE_BLOCK_IDS.KEY_POINTS) {
    const points = normalizeProposalKeyPoints(block.items || []);
    if (!points.length) return '';
    const rows = points.map(function (point) { return '<li>' + proposalEscapeHtml(point) + '</li>'; }).join('');
    return '<div class="vez-email__block"><h3 class="vez-email__block-label">Key points discussed.</h3><ul>' + rows + '</ul></div>';
  }

  if (blockId === MESSAGE_BLOCK_IDS.PRO_INSTALLATION) {
    const lines = String(block.text || '').split('\n').map(function (line) { return line.trim(); }).filter(Boolean);
    if (!lines.length) return '';
    const items = lines.map(function (line) {
      return '<div class="vez-email__check-item"><span class="material-symbols-outlined">check_circle</span><span>' + renderMessageBlockTemplate(line, tokenMap) + '</span></div>';
    }).join('');
    return '<div class="vez-email__block"><h3 class="vez-email__block-label">Professional installation.</h3><div class="vez-email__check-list">' + items + '</div></div>';
  }

  if (blockId === MESSAGE_BLOCK_IDS.ADDITIONAL_LINKS) {
    return '';
  }

  if (blockId === MESSAGE_BLOCK_IDS.KEY_DIFFERENTIATORS) {
    const level = block.level || 'detail';
    if (level === 'brief') {
      return '<div class="vez-email__block"><div>Verizon Connect key differentiators: 99.9% uptime guarantee, in-house support with no third parties, month-to-month flexibility, nationwide coverage, satellite + cell backup, and unlimited trainings.</div></div>';
    }
    const points = normalizeProposalKeyPoints(block.items || []);
    if (!points.length) return '';
    const rows = points.map(function (point) { return '<li>' + proposalEscapeHtml(point) + '</li>'; }).join('');
    return '<div class="vez-email__block">' +
      '<div style="display:grid;grid-template-columns:1.2fr 1fr;gap:20px;align-items:center;">' +
        '<div><h3 class="vez-email__block-label">Why Verizon Connect.</h3><ul>' + rows + '</ul></div>' +
        '<img src="' + VC_IMG + 'image_2.png" alt="Verizon Connect team" style="width:100%;height:100%;min-height:160px;border-radius:8px;object-fit:cover;">' +
      '</div>' +
    '</div>';
  }

  if (blockId === MESSAGE_BLOCK_IDS.CASE_STUDY) {
    const level = block.level || 'brief';
    const text = level === 'brief'
      ? 'A case study is attached showing real-world ROI results from a similar fleet.'
      : '<strong>Customer success story.</strong> We\'ve attached a case study from B.A.M Trucking showing how Verizon Connect helped reduce accidents by 87% and exonerate drivers from false claims — highly relevant for your operation.';
    return '<div class="vez-email__block"><div>' + text + '</div></div>';
  }

  if (blockId === MESSAGE_BLOCK_IDS.ONBOARDING) {
    const level = block.level || 'brief';
    const text = level === 'brief'
      ? 'An onboarding flyer is attached with the implementation journey and key milestones.'
      : '<strong>Onboarding included.</strong> We attached a step-by-step onboarding flyer outlining setup milestones, rollout ownership, and adoption checkpoints so your team knows exactly what to expect from day one.';
    return '<div class="vez-email__block" style="padding:0;">' +
      '<img src="' + VC_IMG + 'img_1.png" alt="Professional installation" style="width:100%;height:160px;object-fit:cover;display:block;">' +
      '<div style="padding:24px;"><div>' + text + '</div></div>' +
    '</div>';
  }

  if (blockId === MESSAGE_BLOCK_IDS.YOUR_PACKAGE) {
    return '<div class="vez-email__block">' +
      '<h3 class="vez-email__block-label">Your customized package includes.</h3>' +
      '<div class="vez-email__check-list">' +
        '<div class="vez-email__check-item"><span class="material-symbols-outlined">check_circle</span><span>Complete price lock guarantee on services</span></div>' +
        '<div class="vez-email__check-item"><span class="material-symbols-outlined">check_circle</span><span>Waived activation fees</span></div>' +
        '<div class="vez-email__check-item"><span class="material-symbols-outlined">check_circle</span><span>Waived equipment cost ($399-$699 value)</span></div>' +
        '<div class="vez-email__check-item"><span class="material-symbols-outlined">check_circle</span><span>On-site professional installation</span></div>' +
      '</div></div>';
  }

  if (blockId === MESSAGE_BLOCK_IDS.WHY_VERIZON) {
    return '<div class="vez-email__block" style="padding:0;">' +
      '<div style="display:grid;grid-template-columns:1fr 1fr;min-height:200px;">' +
        '<div style="padding:24px;display:flex;flex-direction:column;justify-content:center;">' +
          '<h3 class="vez-email__block-label">Why choose Verizon Connect over 3rd party providers.</h3>' +
          '<div class="vez-email__check-list">' +
            '<div class="vez-email__check-item"><span class="material-symbols-outlined">check_circle</span><span><strong>In-house support.</strong> No third parties — Verizon handles hardware, software, and support directly.</span></div>' +
            '<div class="vez-email__check-item"><span class="material-symbols-outlined">check_circle</span><span><strong>Network reliability.</strong> 99.9% uptime guarantee with satellite + cell tower backup. No dead zones.</span></div>' +
            '<div class="vez-email__check-item"><span class="material-symbols-outlined">check_circle</span><span><strong>Flexible terms.</strong> Defaults to month-to-month after the initial agreement — you\'re never locked in long-term.</span></div>' +
          '</div>' +
        '</div>' +
        '<img src="' + VC_IMG + 'image_2.png" alt="Verizon Connect team" style="width:100%;height:100%;min-height:200px;object-fit:cover;display:block;">' +
      '</div>' +
    '</div>';
  }

  return '';
}

function buildProposalMessageHtmlFromBlocks(context) {
  const model = getProposalMessageBlocksModel();
  let additionalMaterialsRendered = false;
  const tokenMap = {
    contactName: proposalEscapeHtml(context.contactName || 'Contact'),
    repName: proposalEscapeHtml(context.generalInfo.repName || 'Marcus Reid'),
    repEmail: proposalEscapeHtml(context.generalInfo.repEmail || 'marcus.reid@verizonconnect.com'),
    repPhone: proposalEscapeHtml(context.generalInfo.repPhone || '(800) 922-0220'),
    expirationDate: proposalEscapeHtml(context.generalInfo.expiration || '')
  };

  return model.order.map(function (blockId) {
    const block = model.blocks[blockId];
    if (!block || !block.visible) return '';

    if (blockId === MESSAGE_BLOCK_IDS.INTRO) {
      const greeting = tokenMap.contactName ? 'Hi <strong>' + tokenMap.contactName + '</strong>,<br>' : '';
      const intro = renderMessageBlockTemplate(block.text, tokenMap);
      return greeting + intro;
    }
    if (blockId === MESSAGE_BLOCK_IDS.OPTION_INFORMATION) {
      const summary = buildProposalPlainOptionSummaryHtml();
      if (!summary) return '';
      return 'Here\'s a quick summary of what you\'ll find in the full proposal.<br><br>' + summary;
    }
    if (blockId === MESSAGE_BLOCK_IDS.ADDITIONAL_INFORMATION) {
      return renderMessageBlockTemplate(block.text, tokenMap);
    }
    if (blockId === MESSAGE_BLOCK_IDS.NOTE) return renderMessageBlockTemplate(block.text, tokenMap);
    if (blockId === MESSAGE_BLOCK_IDS.FOLLOW_UP) {
      const followUpDate = parseProposalDate(block.date);
      if (!followUpDate) return '';
      return '<div><strong>Questions?</strong> Reach me directly at <strong>' + tokenMap.repPhone + '</strong></div>' +
        '<div>I\'ll follow up with you as discussed on <strong>' + formatUsDate(followUpDate) + '</strong>.</div>';
    }
    if (blockId === MESSAGE_BLOCK_IDS.PACKAGE_INCLUDES) {
      const items = normalizeProposalKeyPoints(block.items || []);
      if (!items.length) return '';
      return '<b>What\'s Included at No Extra Cost:</b><ul style="margin:6px 0 0;padding-left:22px;">' + items.map(function(p) { return '<li>' + proposalEscapeHtml(p) + '</li>'; }).join('') + '</ul>';
    }
    if (blockId === MESSAGE_BLOCK_IDS.KEY_POINTS) {
      const points = normalizeProposalKeyPoints(block.items || []);
      if (!points.length) return '';
      const rows = points.map(function (point) { return '<li>' + proposalEscapeHtml(point) + '</li>'; }).join('');
      return 'Key Points Discussed:<ul style="margin:6px 0 0;padding-left:22px;">' + rows + '</ul>';
    }
    if (blockId === MESSAGE_BLOCK_IDS.PRO_INSTALLATION) {
      return renderMessageBlockTemplate(block.text, tokenMap);
    }
    if (blockId === MESSAGE_BLOCK_IDS.ADDITIONAL_LINKS) {
      if (additionalMaterialsRendered) return '';
      const materialsHtml = buildProposalPlainAdditionalMaterialsHtml(model);
      if (materialsHtml) additionalMaterialsRendered = true;
      return materialsHtml;
    }
    if (blockId === MESSAGE_BLOCK_IDS.KEY_DIFFERENTIATORS) {
      const level = block.level || 'detail';
      if (level === 'brief') return 'Verizon Connect key differentiators: 99.9% uptime guarantee, in-house support with no third parties, month-to-month flexibility, nationwide coverage, satellite + cell backup, and unlimited trainings.';
      const points = normalizeProposalKeyPoints(block.items || []);
      if (!points.length) return '';
      const rows = points.map(function (point) { return '<li>' + proposalEscapeHtml(point) + '</li>'; }).join('');
      return 'Key Differentiators:<ul style="margin:6px 0 0;padding-left:22px;">' + rows + '</ul>';
    }
    if (blockId === MESSAGE_BLOCK_IDS.CASE_STUDY) {
      const level = block.level || 'brief';
      return level === 'brief'
        ? 'A case study is attached showing real-world ROI results from a similar fleet.'
        : '<b>Customer success story:</b> We\'ve attached a case study from B.A.M Trucking showing how Verizon Connect helped reduce accidents by 87% and exonerate drivers from false claims.';
    }
    if (blockId === MESSAGE_BLOCK_IDS.ONBOARDING) {
      const level = block.level || 'brief';
      return level === 'brief'
        ? 'An onboarding flyer is attached with the implementation journey and key milestones.'
        : '<b>Onboarding included:</b> We attached a step-by-step onboarding flyer outlining setup milestones, rollout ownership, and adoption checkpoints so your team knows exactly what to expect from day one.';
    }
    if (blockId === MESSAGE_BLOCK_IDS.YOUR_PACKAGE) {
      return '<b>Your Customized Package Includes:</b><ul style="margin:6px 0 0;padding-left:22px;"><li>Complete price lock guarantee on services</li><li>Waived Activation Fees</li><li>Waived Equipment Cost ($399-$699 value)</li><li>On-site professional installation</li></ul>';
    }
    if (blockId === MESSAGE_BLOCK_IDS.WHY_VERIZON) {
      return '<b>Why Choose Verizon Connect Over 3rd Party Providers:</b><ul style="margin:6px 0 0;padding-left:22px;"><li><b>In-house support:</b> No third parties — Verizon handles hardware, software, and support directly.</li><li><b>Network reliability:</b> 99.9% uptime guarantee with satellite + cell tower backup. No dead zones.</li><li><b>Flexible terms:</b> Defaults to month-to-month after the initial agreement — you\'re never locked in long-term.</li></ul>';
    }
    return '';
  }).filter(Boolean).join('<br><br>');
}

function buildProposalVisualMessageHtmlFromBlocks(context) {
  const model = getProposalMessageBlocksModel();
  const tokenMap = {
    contactName: proposalEscapeHtml(context.contactName || 'Contact'),
    repName: proposalEscapeHtml(context.generalInfo.repName || 'Marcus Reid'),
    repEmail: proposalEscapeHtml(context.generalInfo.repEmail || 'marcus.reid@verizonconnect.com'),
    repPhone: proposalEscapeHtml(context.generalInfo.repPhone || '(800) 922-0220'),
    expirationDate: proposalEscapeHtml(context.generalInfo.expiration || '')
  };

  const linkBlockIds = [MESSAGE_BLOCK_IDS.ADDITIONAL_LINKS];
  const linkButtons = [];
  const additionalLinksBlock = model.blocks[MESSAGE_BLOCK_IDS.ADDITIONAL_LINKS];
  if (additionalLinksBlock && additionalLinksBlock.visible !== false) {
    (additionalLinksBlock.links || []).filter(function(l) { return l.enabled && l.url; }).forEach(function(l) {
      linkButtons.push('<a class="vez-email__materials-link" href="' + proposalEscapeHtml(l.url) + '" target="_blank" rel="noreferrer"><span>' + proposalEscapeHtml(l.label || 'View') + '</span></a>');
    });
  }

  const sections = [];
  let materialsRendered = false;
  model.order.forEach(function (blockId) {
    if (linkBlockIds.includes(blockId)) {
      if (!materialsRendered && linkButtons.length) {
        sections.push(
          '<div class="vez-email__materials-block">' +
            '<p class="vez-email__materials-title">Additional materials to help you review and share with your team.</p>' +
            '<div class="vez-email__materials-actions">' + linkButtons.join('') + '</div>' +
          '</div>'
        );
        materialsRendered = true;
      }
      return;
    }
    const sectionHtml = buildProposalVisualSectionFromBlock(blockId, model.blocks[blockId], tokenMap, context);
    if (sectionHtml) sections.push(sectionHtml);
  });

  if (!materialsRendered && linkButtons.length) {
    sections.push(
      '<div class="vez-email__materials-block">' +
        '<p class="vez-email__materials-title">Additional materials to help you review and share with your team.</p>' +
        '<div class="vez-email__materials-actions">' + linkButtons.join('') + '</div>' +
      '</div>'
    );
  }

  const sectionsHtml = sections.join('');
  if (!sectionsHtml) return '';
  const year = new Date().getFullYear();

  const globalHeader =
    '<div class="vez-email__global-header">' +
      '<div class="vez-email__global-header-logo"><img src="' + VC_IMG + 'logo.svg" alt="Verizon Connect"></div>' +
    '</div>';

  const hero =
    '<div class="vez-email__hero">' +
      '<h1>Your Custom<br>Fleet Quote.</h1>' +
      '<p>A smarter way to run your fleet.</p>' +
    '</div>';

  const footer =
    '<div class="vez-email__footer">' +
      '<p style="margin:0 0 12px;font-size:13px;color:#1a1a1a;">© ' + year + ' Verizon. All rights reserved.</p>' +
      '<p style="margin:0 0 12px;font-size:13px;color:#1a1a1a;line-height:1.6;">This email was sent to you because you requested a proposal from Verizon Connect. We respect your privacy. Please review our <a href="#" style="color:#1a1a1a;">Privacy Policy</a>. You may <a href="#" style="color:#1a1a1a;">unsubscribe</a> at any time or update your wireless communication options at the <a href="#" style="color:#1a1a1a;">preference center</a>.</p>' +
      '<p style="margin:0 0 24px;font-size:13px;color:#1a1a1a;">Verizon, One Verizon Way, Mail Code: 180WVB, Basking Ridge, NJ 07920</p>' +
      '<img src="' + VC_IMG + 'logo.svg" alt="Verizon Connect" style="height:32px;display:block;">' +
    '</div>';

  return '<div class="vez-email">' + globalHeader + hero + '<div class="vez-email__body">' + sectionsHtml + '</div>' + footer + '</div>';
}

function buildProposalMessageHtmlBySelectedFormat(context) {
  if (getProposalMessageFormat() === MESSAGE_FORMATS.VISUAL) {
    return buildProposalVisualMessageHtmlFromBlocks(context);
  }
  return buildProposalMessageHtmlFromBlocks(context);
}

function getGeneralInfoValues() {
  const expirationRaw = document.getElementById('proposal-expiration-date')?.value || '';
  const parsedExpiration = expirationRaw ? parseProposalDate(expirationRaw) : null;
  const expirationText = parsedExpiration
    ? formatExpirationDisplayDate(clampExpirationDate(startOfDay(parsedExpiration)))
    : formatExpirationDisplayDate(getDefaultExpirationDate());

  return {
    businessName: (document.getElementById('gi-business-name')?.value || '').trim(),
    state: (document.getElementById('gi-state')?.value || '').trim(),
    closeDate: (document.getElementById('proposal-close-date')?.value || '').trim(),
    expiration: expirationText,
    repName: (document.getElementById('gi-rep-name')?.value || '').trim(),
    repEmail: (document.getElementById('gi-rep-email')?.value || '').trim(),
    repPhone: (document.getElementById('gi-rep-phone')?.value || '').trim()
  };
}

function inferContactNameFromRecipient(toValue) {
  const raw = String(toValue || '').trim().split('@')[0] || 'Contact';
  return raw
    .replace(/[._-]+/g, ' ')
    .split(' ')
    .filter(Boolean)
    .map(function (part) {
      return part.charAt(0).toUpperCase() + part.slice(1).toLowerCase();
    })
    .join(' ');
}

function getCaseStudyOptionLabel(key) {
  const match = CASE_STUDY_OPTIONS.find(function (option) { return option.key === key; });
  return match ? match.label : 'None';
}

function closeCaseStudyDropdowns() {
  document.getElementById('case-study-dropdown')?.classList.add('hidden');
  document.getElementById('case-study-btn')?.setAttribute('aria-expanded', 'false');
}

function updateCaseStudyDropdownUI() {
  const label = getCaseStudyOptionLabel(proposalCaseStudySelection);
  const labelV1 = document.getElementById('case-study-label');
  if (labelV1) labelV1.textContent = label;

  const rowsHtml = CASE_STUDY_OPTIONS.map(function (option) {
    const selected = option.key === proposalCaseStudySelection;
    return '<button type="button" class="dropdown-option' + (selected ? ' is-selected' : '') + '" role="option" aria-selected="' + (selected ? 'true' : 'false') + '" onclick="selectCaseStudyOption(\'' + option.key + '\')">'
      + '<span>' + proposalEscapeHtml(option.label) + '</span>'
      + '<span class="material-symbols-outlined case-check">check</span>'
      + '</button>';
  }).join('');

  const dropdownV1 = document.getElementById('case-study-dropdown');
  if (dropdownV1) dropdownV1.innerHTML = rowsHtml;
}

function toggleCaseStudyDropdown(source, event) {
  event?.stopPropagation();
  const targetId = 'case-study-dropdown';
  const targetBtnId = 'case-study-btn';
  const targetMenu = document.getElementById(targetId);
  if (!targetMenu) return;

  const willOpen = targetMenu.classList.contains('hidden');
  closeCaseStudyDropdowns();
  if (willOpen) {
    targetMenu.classList.remove('hidden');
    document.getElementById(targetBtnId)?.setAttribute('aria-expanded', 'true');
  }
}

function selectCaseStudyOption(caseStudyKey) {
  const key = Object.prototype.hasOwnProperty.call(CASE_STUDY_LIBRARY, caseStudyKey) ? caseStudyKey : 'none';
  proposalCaseStudySelection = key;
  updateCaseStudyDropdownUI();
  syncCaseStudySelectorVisibility();
  closeCaseStudyDropdowns();
  renderProposalDoc();
  fillProposalMessageDefaults(true);
  renderCustomizationSummary();
}

function getSelectedCaseStudyKey() {
  return Object.prototype.hasOwnProperty.call(CASE_STUDY_LIBRARY, proposalCaseStudySelection)
    ? proposalCaseStudySelection
    : 'none';
}

function getSelectedCaseStudyData() {
  const key = getSelectedCaseStudyKey();
  return CASE_STUDY_LIBRARY[key] || CASE_STUDY_LIBRARY.none;
}

function syncCaseStudySelectorVisibility() {
  const caseStudyCb = document.querySelector('#materials-menu input[data-material-key="case-study"]');
  const isEnabled = !!caseStudyCb?.checked;
  document.getElementById('case-study-selector-wrap')?.classList.toggle('hidden', !isEnabled);
}

function applyLinkedModuleDefaultsFromMaterials() {
  const selectedMaterials = getSelectedMaterials();
  const model = getProposalMessageBlocksModel();
  const linkedMap = {
    [MESSAGE_BLOCK_IDS.CASE_STUDY]: selectedMaterials.has('case-study'),
    [MESSAGE_BLOCK_IDS.ONBOARDING]: selectedMaterials.has('onboarding')
  };

  Object.keys(linkedMap).forEach(function(blockId) {
    if (model.blocks[blockId] && !model.blocks[blockId]._touched) {
      model.blocks[blockId].visible = linkedMap[blockId];
    }
  });

  renderProposalMsgContentChecklist();
}

function renderCustomizationSummary() {
  const materialsSummaryEl = document.getElementById('customization-materials-summary');
  const messageSummaryEl = document.getElementById('customization-message-summary');
  const selectedCaseStudy = getSelectedCaseStudyData();

  if (materialsSummaryEl) {
    const selectedLabels = Array.from(getSelectedMaterials()).map(function (key) {
      if (key === 'quote') return 'Quote';
      if (key === 'roi') return 'ROI Analysis';
      if (key === 'case-study') return selectedCaseStudy.title === 'Case Study' ? 'Case Study' : 'Case Study: ' + selectedCaseStudy.title;
      if (key === 'onboarding') return 'Onboarding Flyer';
      return key;
    });
    materialsSummaryEl.textContent = selectedLabels.join(' + ');
  }

  if (messageSummaryEl) {
    const activeModules = Object.keys(proposalMessageModules)
      .filter(function (key) { return proposalMessageModules[key] !== 'off'; })
      .map(function (key) {
        const labelMap = {
          guarantees: 'Guarantees',
          differentiators: 'Differentiators',
          caseStudy: 'Case study',
          onboarding: 'Onboarding'
        };
        const stateMap = {
          brief: 'brief',
          detail: 'detail'
        };
        return labelMap[key] + ' (' + (stateMap[proposalMessageModules[key]] || proposalMessageModules[key]) + ')';
      });
    messageSummaryEl.textContent = activeModules.length
      ? 'Core + ' + activeModules.join(', ')
      : 'Core only';
  }

  renderCustomizationThumbnails();
}

function scaleDocPagesInContainer(container) {
  if (!container) return;
  container.querySelectorAll('.doc-page-outer').forEach(function (outer) {
    const page = outer.querySelector('.vc-doc-shell');
    if (!page) return;
    const containerW = outer.clientWidth;
    if (!containerW) return;
    const sidePad = 8;
    const availW = Math.max(0, containerW - sidePad * 2);
    const scale = availW / 794;
    page.style.transform = 'scale(' + scale + ')';
    page.style.transformOrigin = 'top center';
    page.style.marginLeft = 'auto';
    page.style.marginRight = 'auto';
    outer.style.display = 'flex';
    outer.style.justifyContent = 'center';
    outer.style.height = Math.ceil(page.scrollHeight * scale + sidePad * 2) + 'px';
  });
}

function renderCustomizationThumbnails() {
  const pdfThumb = document.getElementById('customization-pdf-preview');
  const msgThumb = document.getElementById('customization-message-preview');
  const sourceDoc = document.getElementById('prop-doc-viewer');
  const bodyEl = document.getElementById('prop-msg-body');

  if (pdfThumb) {
    pdfThumb.innerHTML = '';
    const pages = sourceDoc ? Array.from(sourceDoc.querySelectorAll('.doc-page-outer')) : [];
    if (pages.length) {
      pages.forEach(function (page) {
        pdfThumb.appendChild(page.cloneNode(true));
      });
      requestAnimationFrame(function () {
        scaleDocPagesInContainer(pdfThumb);
      });
    } else {
      pdfThumb.innerHTML = '<div class="proposal-customization-empty">Preview unavailable</div>';
    }
  }

  if (msgThumb) {
    const messageHtml = bodyEl && bodyEl.innerHTML
      ? bodyEl.innerHTML
      : '<em>No message content yet.</em>';
    msgThumb.innerHTML = '<div class="proposal-customization-message-frame">' + messageHtml + '</div>';
  }
}

function initProposalGeneralInfoDefaults() {
  const accountName = (document.querySelector('.vc-account-name')?.textContent || '').trim() || 'Apex Construction LLC';
  const businessNameEl = document.getElementById('gi-business-name');
  const stateEl = document.getElementById('gi-state');
  const repNameEl = document.getElementById('gi-rep-name');
  const repEmailEl = document.getElementById('gi-rep-email');
  const repPhoneEl = document.getElementById('gi-rep-phone');

  if (businessNameEl && !businessNameEl.value) businessNameEl.value = accountName;
  if (stateEl && !stateEl.value) stateEl.value = 'TX';
  if (repNameEl && !repNameEl.value) repNameEl.value = 'Marcus Reid';
  if (repEmailEl && !repEmailEl.value) repEmailEl.value = 'marcus.reid@verizonconnect.com';
  if (repPhoneEl && !repPhoneEl.value) repPhoneEl.value = '(800) 922-0220';
  syncProposalRepReadonlySummary();
}

function syncProposalRepReadonlySummary() {
  const name = document.getElementById('gi-rep-name')?.value || 'Marcus Reid';
  const email = document.getElementById('gi-rep-email')?.value || 'marcus.reid@verizonconnect.com';
  const phone = document.getElementById('gi-rep-phone')?.value || '(800) 922-0220';
  const nameText = document.getElementById('gi-rep-name-text');
  const emailText = document.getElementById('gi-rep-email-text');
  const phoneText = document.getElementById('gi-rep-phone-text');
  if (nameText) nameText.textContent = name;
  if (emailText) emailText.textContent = email;
  if (phoneText) phoneText.textContent = phone;
}

function getProposalRepNames() {
  return Object.keys(PROPOSAL_REP_DIRECTORY);
}

function getDefaultProposalRepName() {
  const defaultName = getProposalRepNames().find(function (name) {
    return !!(PROPOSAL_REP_DIRECTORY[name] && PROPOSAL_REP_DIRECTORY[name].isDefault);
  });
  return defaultName || 'Marcus Reid';
}

function filterProposalRepNames(query) {
  const normalizedQuery = String(query || '').trim().toLowerCase();
  if (!normalizedQuery) return getProposalRepNames();
  return getProposalRepNames().filter(function (name) {
    const contact = PROPOSAL_REP_DIRECTORY[name] || {};
    return (
      String(name || '').toLowerCase().includes(normalizedQuery) ||
      String(contact.email || '').toLowerCase().includes(normalizedQuery) ||
      String(contact.phone || '').toLowerCase().includes(normalizedQuery)
    );
  });
}

function populateProposalRepEditor(preferredName) {
  const currentNameEl = document.getElementById('proposal-rep-editor-current-name');
  if (!currentNameEl) return;
  const selectedName = PROPOSAL_REP_DIRECTORY[preferredName] ? preferredName : getDefaultProposalRepName();
  proposalRepDraftName = selectedName;
  currentNameEl.value = selectedName;
  renderProposalRepEditorOptions('');
}

function renderProposalRepEditorOptions(query) {
  const optionsEl = document.getElementById('proposal-rep-editor-options');
  if (!optionsEl) return;
  const names = filterProposalRepNames(query);
  if (!names.length) {
    optionsEl.innerHTML = '<div class="proposal-rep-editor-empty">No reps found.</div>';
    return;
  }
  optionsEl.innerHTML = names.map(function (name) {
    const contact = PROPOSAL_REP_DIRECTORY[name] || {};
    const activeClass = name === proposalRepDraftName ? ' is-active' : '';
    const defaultBadge = contact.isDefault
      ? '<span class="badge badge--gray-low proposal-rep-editor-option__default">Default</span>'
      : '';
    const meta = [contact.email || '', contact.phone || ''].filter(Boolean).join(' - ');
    return '<button type="button" class="proposal-rep-editor-option' + activeClass + '" role="option" data-rep-name="' + proposalEscapeHtml(name) + '" aria-selected="' + (name === proposalRepDraftName ? 'true' : 'false') + '" onclick="selectProposalRepDraft(this.getAttribute(\'data-rep-name\'))">' +
      '<div class="proposal-rep-editor-option__name-row"><span class="proposal-rep-editor-option__name">' + proposalEscapeHtml(name) + '</span>' + defaultBadge + '</div>' +
      '<div class="proposal-rep-editor-option__meta">' + proposalEscapeHtml(meta) + '</div>' +
    '</button>';
  }).join('');
}

function onProposalRepEditorMainInput(query) {
  setProposalRepDropdownOpen(true);
  renderProposalRepEditorOptions(query);
}

function setProposalRepDropdownOpen(isOpen) {
  const editorBoxEl = document.querySelector('#proposal-rep-combobox .proposal-rep-editor-box');
  const triggerEl = document.querySelector('#proposal-rep-combobox .proposal-rep-editor-current');
  proposalRepDropdownOpen = !!isOpen;
  if (editorBoxEl) editorBoxEl.classList.toggle('is-open', proposalRepDropdownOpen);
  if (triggerEl) triggerEl.setAttribute('aria-expanded', proposalRepDropdownOpen ? 'true' : 'false');
}

function setProposalRepEditMode(isEditing) {
  const readonlyEl = document.getElementById('proposal-rep-readonly-block');
  const editBtn = document.getElementById('proposal-rep-edit-btn');
  const wrapper = document.getElementById('proposal-rep-combobox');
  const inputEl = document.getElementById('gi-rep-name');
  if (!readonlyEl || !editBtn || !wrapper || !inputEl) return;

  if (isEditing) {
    const selectedName = (inputEl.value || '').trim() || getDefaultProposalRepName();
    populateProposalRepEditor(selectedName);
    setProposalRepDropdownOpen(true);
    readonlyEl.classList.add('hidden');
    editBtn.classList.add('hidden');
    wrapper.classList.remove('hidden');
    return;
  }
  readonlyEl.classList.remove('hidden');
  editBtn.classList.remove('hidden');
  wrapper.classList.add('hidden');
  setProposalRepDropdownOpen(false);
  proposalRepDraftName = '';
}

function openProposalRepEditMode() {
  showProposalEditLoader('Loading reps...');
  window.setTimeout(function () {
    hideProposalEditLoader();
    setProposalRepEditMode(true);
  }, 400);
}

function closeProposalRepEditMode() {
  setProposalRepEditMode(false);
}

function setProposalRepSaveLoading(isLoading) {
  const confirmBtn = document.getElementById('proposal-rep-confirm-btn');
  const cancelBtn = document.getElementById('proposal-rep-cancel-btn');
  const loading = !!isLoading;
  if (confirmBtn) {
    confirmBtn.disabled = loading;
    confirmBtn.classList.toggle('is-loading', loading);
    confirmBtn.textContent = loading ? 'Saving...' : 'Confirm';
  }
  if (cancelBtn) cancelBtn.disabled = loading;
}

function saveProposalRepEdit() {
  if (proposalRepSaveLoaderTimer) return;
  const inputEl = document.getElementById('gi-rep-name');
  const selectedName = PROPOSAL_REP_DIRECTORY[proposalRepDraftName] ? proposalRepDraftName : getDefaultProposalRepName();
  if (!inputEl || !PROPOSAL_REP_DIRECTORY[selectedName]) return;
  setProposalRepSaveLoading(true);
  proposalRepSaveLoaderTimer = window.setTimeout(function () {
    proposalRepSaveLoaderTimer = null;
    const contact = PROPOSAL_REP_DIRECTORY[selectedName];
    inputEl.value = selectedName;
    const emailEl = document.getElementById('gi-rep-email');
    const phoneEl = document.getElementById('gi-rep-phone');
    if (emailEl) emailEl.value = contact.email;
    if (phoneEl) phoneEl.value = contact.phone;
    closeProposalRepEditMode();
    try {
      handleProposalGeneralInfoInput();
    } catch (err) {
      console.error('Proposal rep confirm post-update failed:', err);
    } finally {
      setProposalRepSaveLoading(false);
    }
  }, 400);
}

function cancelProposalRepEdit() {
  closeProposalRepEditMode();
}

function selectProposalRepDraft(repName) {
  if (!PROPOSAL_REP_DIRECTORY[repName]) return;
  proposalRepDraftName = repName;
  const currentNameEl = document.getElementById('proposal-rep-editor-current-name');
  if (currentNameEl) currentNameEl.value = repName;
  const optionEls = Array.from(document.querySelectorAll('#proposal-rep-editor-options .proposal-rep-editor-option'));
  optionEls.forEach(function (optionEl) {
    const isActive = optionEl.getAttribute('data-rep-name') === repName;
    optionEl.classList.toggle('is-active', isActive);
    optionEl.setAttribute('aria-selected', isActive ? 'true' : 'false');
  });
}

function handleProposalGeneralInfoInput() {
  onProposalExpirationChange();
  syncProposalRepReadonlySummary();
  renderProposalDoc();
  renderCustomizationSummary();
  fillProposalMessageDefaults(true);
  updateProposalMessagePreview();
  updateSendBtn();
}

function markProposalMessageEdited() {
  const bodyEl = document.getElementById('prop-msg-body');
  if (!bodyEl) return;
  bodyEl.dataset.userEdited = 'true';
}

function updateProposalMessagePreview() {
  const toEl = document.getElementById('prop-msg-to');
  const subjectEl = document.getElementById('prop-msg-subject');
  const bodyEl = document.getElementById('prop-msg-body');
  const previewTo = document.getElementById('prop-msg-preview-to');
  const previewSubject = document.getElementById('prop-msg-preview-subject');
  const previewBody = document.getElementById('prop-msg-preview-body');
  if (previewTo) previewTo.textContent = (toEl && toEl.value.trim()) || '—';
  if (previewSubject) previewSubject.textContent = (subjectEl && subjectEl.value.trim()) || '—';
  if (previewBody) previewBody.innerHTML = (bodyEl && bodyEl.innerHTML) || '';
  renderCustomizationThumbnails();
}

function syncProposalMessageInlineFieldsPlacement(kind) {
  const hostEl = document.getElementById('proposal-edit-message-inline-host');
  const fieldsEl = document.getElementById('proposal-message-inline-fields');
  const messageViewEl = document.getElementById('proposal-review-edit-message');
  const columnsEl = messageViewEl ? messageViewEl.querySelector('.proposal-editor-columns') : null;
  if (!hostEl || !fieldsEl || !messageViewEl || !columnsEl) return;

  if (kind === 'message') {
    if (fieldsEl.parentElement !== hostEl) hostEl.appendChild(fieldsEl);
    hostEl.classList.remove('hidden');
    return;
  }

  hostEl.classList.add('hidden');
  if (fieldsEl.parentElement !== messageViewEl) {
    messageViewEl.insertBefore(fieldsEl, columnsEl);
  }
}

function setProposalReviewHeaderEditorMode(kind) {
  const titleEl = document.getElementById('proposal-review-title');
  if (!titleEl) return;
  if (!titleEl.dataset.defaultTitle) {
    titleEl.dataset.defaultTitle = (titleEl.textContent || 'Finalize Your Proposal Package').trim();
  }

  if (!kind) {
    titleEl.textContent = titleEl.dataset.defaultTitle;
    return;
  }

  const label = kind === 'pdf' ? 'Edit PDF' : 'Edit message';
  titleEl.innerHTML = '' +
    '<button type="button" class="btn btn--secondary btn--small" onclick="backToProposalReviewSummary(true)" aria-label="Done">' +
      '<span class="material-symbols-outlined" style="font-size:16px;">arrow_back</span>' +
      'Done' +
    '</button>' +
    '<span class="proposal-review-title__text">' + proposalEscapeHtml(label) + '</span>';
  setTimeout(function() { initAutosaveIndicators(); }, 0);
}

function openProposalCustomizationEditor(kind) {
  const modalEl = document.querySelector('#proposal-review-overlay .proposal-review-modal');
  const summaryEl = document.getElementById('proposal-review-summary-view');
  const shellEl = document.getElementById('proposal-review-edit-shell');
  const pdfEl = document.getElementById('proposal-review-edit-pdf');
  const messageEl = document.getElementById('proposal-review-edit-message');
  if (!summaryEl || !shellEl || !pdfEl || !messageEl) return;

  shellEl.classList.remove('hidden');
  syncProposalMessageInlineFieldsPlacement(kind);
  pdfEl.classList.toggle('hidden', kind !== 'pdf');
  messageEl.classList.toggle('hidden', kind !== 'message');

  const activeEl = kind === 'pdf' ? pdfEl : messageEl;
  activeEl.classList.remove('is-leaving');
  activeEl.classList.add('is-entering');
  window.setTimeout(function () {
    activeEl.classList.remove('is-entering');
  }, 240);

  if (modalEl) modalEl.classList.add('is-editor-open');
  setProposalReviewHeaderEditorMode(kind);

  if (kind === 'pdf') {
    renderProposalDoc();
  } else {
    fillProposalMessageDefaults(false);
    renderProposalMessageBlockTokenPicker();
    renderProposalMsgContentChecklist();
    renderProposalMessageFormatControl();
  }
}

function triggerAutosaveIndicator(statusId) {
  const el = document.getElementById(statusId);
  if (!el) return;
  clearTimeout(_autosaveTimer);
  el.textContent = 'Saving\u2026';
  el.className = 'autosave-status saving';
  _autosaveTimer = setTimeout(() => {
    el.innerHTML = '<span class="material-symbols-outlined" style="font-size:13px;font-variation-settings:\'FILL\' 1;">check_circle</span> Saved';
    el.className = 'autosave-status saved';
    setTimeout(() => { el.textContent = 'All changes saved'; el.className = 'autosave-status'; }, 2200);
  }, 400);
}

function initAutosaveIndicators() {
  const editors = [
    { id: 'proposal-review-edit-message', statusId: 'autosave-msg-status' },
    { id: 'proposal-review-edit-pdf',     statusId: 'autosave-pdf-status' }
  ];
  editors.forEach(({ id, statusId }) => {
    const statusEl = document.getElementById(statusId);
    if (statusEl) statusEl.textContent = 'All changes saved';
    const el = document.getElementById(id);
    if (!el || el.dataset.autosaveBound === 'true') return;
    el.addEventListener('input',  () => triggerAutosaveIndicator(statusId), true);
    el.addEventListener('change', () => triggerAutosaveIndicator(statusId), true);
    el.dataset.autosaveBound = 'true';
  });
}

function backToProposalReviewSummary(showLoader) {
  const modalEl = document.querySelector('#proposal-review-overlay .proposal-review-modal');
  const summaryEl = document.getElementById('proposal-review-summary-view');
  const shellEl = document.getElementById('proposal-review-edit-shell');
  const pdfEl = document.getElementById('proposal-review-edit-pdf');
  const messageEl = document.getElementById('proposal-review-edit-message');
  if (!summaryEl || !shellEl || !pdfEl || !messageEl) return;

  const activeEl = !pdfEl.classList.contains('hidden') ? pdfEl : (!messageEl.classList.contains('hidden') ? messageEl : null);
  const shouldShowLoader = !!showLoader;
  const finishBack = function () {
    syncProposalMessageInlineFieldsPlacement(null);
    shellEl.classList.add('hidden');
    pdfEl.classList.add('hidden');
    messageEl.classList.add('hidden');
    if (activeEl) activeEl.classList.remove('is-leaving');
    if (modalEl) modalEl.classList.remove('is-editor-open');
    setProposalReviewHeaderEditorMode(null);
    renderCustomizationSummary();
    hideProposalEditLoader();
  };

  const runBackTransition = function () {
    if (activeEl) {
      activeEl.classList.remove('is-entering');
      activeEl.classList.add('is-leaving');
      window.setTimeout(finishBack, 180);
      return;
    }

    finishBack();
  };

  if (shouldShowLoader && activeEl) {
    if (proposalEditLoaderTimer) {
      clearTimeout(proposalEditLoaderTimer);
      proposalEditLoaderTimer = null;
    }
    showProposalEditLoader('Returning to summary...');
    proposalEditLoaderTimer = window.setTimeout(function () {
      proposalEditLoaderTimer = null;
      runBackTransition();
    }, PROPOSAL_EDIT_LOADER_DELAY_MS);
    return;
  }

  runBackTransition();
}

function fillProposalMessageDefaults(forceRebuild) {
  const toEl = document.getElementById('prop-msg-to');
  const subjectEl = document.getElementById('prop-msg-subject');
  const bodyEl = document.getElementById('prop-msg-body');
  if (!toEl || !subjectEl || !bodyEl) return;

  const alreadyFilled = bodyEl.dataset.autofilled === 'true';
  const shouldForce = !!forceRebuild;
  if (alreadyFilled && !shouldForce) {
    updateCharCount(bodyEl);
    updateSendBtn();
    updateProposalMessagePreview();
    return;
  }

  const generalInfo = getGeneralInfoValues();
  const defaultSubject = generalInfo.businessName
    ? ('Verizon Connect proposal for ' + generalInfo.businessName)
    : 'Verizon Connect info & pricing';
  subjectEl.value = subjectEl.value || defaultSubject;
  toEl.value = toEl.value || 'laura.mendez@acmelogistics.com';

  applyLinkedModuleDefaultsFromMaterials();

  const contactName = inferContactNameFromRecipient(toEl.value);
  const optionBlocksHtml = options.map(function (opt, optIdx) {
    if (!isOptionSendableInProposal(opt)) return '';
    let totalUnits = 0;
    opt.bundles.forEach(function (bundle) { totalUnits += bundle.qty; });
    const termMonths = parseInt(opt.term, 10);
    const result = calcOption(opt, getOptionPromotion(opt));

    const bundleLinesHtml = opt.bundles.map(function (bundle) {
      const bundleResult = calcBundle(bundle, opt.term, bundle.promoType || 'Standard', totalUnits);
      const featNames = (bundle.features || bundle.selectedFeatures || [])
        .map(function (featureKey) { return featureLabels[featureKey] || featureKey; })
        .filter(Boolean);
      const desc = featNames.length ? (bundle.coreName + ' + ' + featNames.join(' + ')) : bundle.coreName;
      return '<div class="vez-email__option-line"><span>' + proposalEscapeHtml(bundle.qty + 'x ' + desc) + '</span><span class="vez-email__option-line-price">' + formatMoney(bundleResult.unitPrice) + '/mo</span></div>';
    }).join('<br>');

    const vehicleWord = totalUnits === 1 ? 'vehicle' : 'vehicles';
    return '' +
      '<div class="vez-email__option-card">' +
        '<div class="vez-email__option-head">' +
          '<div class="vez-email__option-name">' + proposalEscapeHtml(getOptionDisplayLabel(optIdx + 1)) + '</div>' +
          '<div class="vez-email__option-term">' + termMonths + ' Month</div>' +
        '</div>' +
        '<div class="vez-email__option-divider"></div>' +
        bundleLinesHtml +
        '<div class="vez-email__option-divider"></div>' +
        '<div class="vez-email__option-total-line"><span>Total for ' + totalUnits + ' ' + vehicleWord + '</span><span>' + formatMoney(result.totalMonthly) + '/mo</span></div>' +
      '</div>';
  }).join('<br><br>');

  const coreBlock =
    proposalEscapeHtml(contactName) + ',<br><br>' +
    'Thank you for your time today. The quote and info we discussed are all below. If anything pops up between now and then, feel free to reach out directly at ' + proposalEscapeHtml(generalInfo.repPhone || '(800) 922-0220') + '.<br><br>' +
    optionBlocksHtml +
    '<br><br>Please note that this proposal and all associated pricing are valid through ' + proposalEscapeHtml(generalInfo.expiration || '') + '. Should you have any questions or wish to move forward before then, please don\'t hesitate to reach out directly.<br><br>' +
    'Best regards,<br>' +
    proposalEscapeHtml(generalInfo.repName || 'Marcus Reid') + '<br>' +
    proposalEscapeHtml(generalInfo.repEmail || 'marcus.reid@verizonconnect.com') + '<br>' +
    proposalEscapeHtml(generalInfo.repPhone || '(800) 922-0220');

  const messageBlocksHtml = buildProposalMessageHtmlBySelectedFormat({
    contactName: contactName,
    optionBlocksHtml: optionBlocksHtml,
    generalInfo: generalInfo,
    fallbackCoreBlock: coreBlock
  });
  bodyEl.innerHTML = messageBlocksHtml || coreBlock;
  bodyEl.dataset.autofilled = 'true';

  updateCharCount(bodyEl);
  renderCustomizationSummary();
  updateSendBtn();
  updateProposalMessagePreview();
}

function downloadProposalPdfPreview() {
  const viewer = document.getElementById('prop-doc-viewer');
  if (!viewer) return;

  const htmlDoc = `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Proposal Preview</title>
  <style>
    body { margin: 0; padding: 24px; background: #EBEBEB; font-family: Archivo, Arial, sans-serif; }
    .doc-page-outer { margin: 0 auto 16px; max-width: 900px; }
  </style>
</head>
<body>
  ${viewer.innerHTML}
</body>
</html>`;

  const blob = new Blob([htmlDoc], { type: 'text/html;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const datePart = new Date().toISOString().slice(0, 10);
  const a = document.createElement('a');
  a.href = url;
  a.download = `proposal-preview-${datePart}.html`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function showProposalEditLoader(messageText) {
  const loaderEl = document.getElementById('proposal-edit-loader');
  if (!loaderEl) return;
  const textEl = loaderEl.querySelector('.proposal-edit-loader__text');
  if (textEl && messageText) textEl.textContent = messageText;
  loaderEl.classList.remove('hidden');
}

function hideProposalEditLoader() {
  const loaderEl = document.getElementById('proposal-edit-loader');
  if (!loaderEl) return;
  loaderEl.classList.add('hidden');
}

function openMessageCustomizationWithLoader() {
  openProposalCustomizationWithLoader('message');
}

function openPdfCustomizationWithLoader() {
  openProposalCustomizationWithLoader('pdf');
}

function openProposalCustomizationWithLoader(kind) {
  if (proposalEditLoaderTimer) {
    clearTimeout(proposalEditLoaderTimer);
    proposalEditLoaderTimer = null;
  }
  const destination = kind === 'pdf' ? 'PDF' : 'email';
  showProposalEditLoader('Redirecting to ' + destination + ' customization...');
  proposalEditLoaderTimer = window.setTimeout(function () {
    proposalEditLoaderTimer = null;
    hideProposalEditLoader();
    openProposalCustomizationEditor(kind === 'pdf' ? 'pdf' : 'message');
  }, PROPOSAL_EDIT_LOADER_DELAY_MS);
}

function setProposalReviewLayout(previewOnly) {
  // Backward-compatible shim: reuse previous API to route to the dedicated editors.
  proposalReviewPreviewOnly = !!previewOnly;
  if (proposalReviewPreviewOnly) {
    openProposalCustomizationEditor('pdf');
  } else {
    backToProposalReviewSummary();
  }
}

function handleProposalReviewModalClick(event) {
  const clickedMaterialsDropdown = event.target.closest('#materials-btn, #materials-menu');
  if (document.getElementById('materials-btn') && !clickedMaterialsDropdown) {
    document.getElementById('materials-menu')?.classList.add('hidden');
  }
  const clickedCaseStudyDropdown = event.target.closest('#case-study-btn, #case-study-dropdown');
  if (!clickedCaseStudyDropdown) {
    closeCaseStudyDropdowns();
  }
}

function initProposalReviewSharedState() {
  // Close date first (its default feeds the default Expiration date), using
  // the local-date helper — toISOString() is UTC and could shift the day.
  const closeDateInput = document.getElementById('proposal-close-date');
  if (closeDateInput && !closeDateInput.value) {
    closeDateInput.value = getLastDayOfCurrentMonthIso();
  }
  syncExpirationInputs(getSelectedExpirationDate());
  initProposalGeneralInfoDefaults();
  handleProposalGeneralInfoInput('v1');
  loadMessageModulePreferences();
  const messageBlocksModel = getProposalMessageBlocksModel();
  if (messageBlocksModel && messageBlocksModel.blocks) {
    if (messageBlocksModel.blocks[MESSAGE_BLOCK_IDS.DEMO_VIDEO]) {
      messageBlocksModel.blocks[MESSAGE_BLOCK_IDS.DEMO_VIDEO].visible = true;
    }
    if (messageBlocksModel.blocks[MESSAGE_BLOCK_IDS.BROCHURE]) {
      messageBlocksModel.blocks[MESSAGE_BLOCK_IDS.BROCHURE].visible = true;
    }
  }
  renderProposalMessageFormatControl();
  renderProposalMessageBlockTokenPicker();
  renderProposalMsgContentChecklist();
  updateCaseStudyDropdownUI();
  renderProposalReviewInlineValidation();
  renderProposalDoc();
  fillProposalMessageDefaults(true);
  renderCustomizationSummary();
  initRoiConfigPanel();
  syncCaseStudySelectorVisibility();
}

function showProposalReviewModal() {
  if (proposalReviewLayoutTimer) {
    clearTimeout(proposalReviewLayoutTimer);
    proposalReviewLayoutTimer = null;
  }
  initProposalReviewSharedState();
  setProposalReviewLayout(false);
  syncProposalMessageInlineFieldsPlacement(null);
  setProposalReviewHeaderEditorMode(null);
  document.getElementById('proposal-review-overlay')?.classList.add('is-open');
  document.body.style.overflow = 'hidden';
}

function hideProposalReviewModal() {
  if (proposalEditLoaderTimer) {
    clearTimeout(proposalEditLoaderTimer);
    proposalEditLoaderTimer = null;
  }
  hideProposalEditLoader();
  document.getElementById('proposal-review-overlay')?.classList.remove('is-open');
  document.body.style.overflow = '';
  backToProposalReviewSummary();
  syncProposalMessageInlineFieldsPlacement(null);
  setProposalReviewHeaderEditorMode(null);
  // Reset autofill flag so re-opening regenerates the body from current option data
  const bodyEl = document.getElementById('prop-msg-body');
  if (bodyEl) bodyEl.dataset.autofilled = '';
}

function closeProposalReviewModal() {
  if (screen === 'review') {
    screen = 'drafting';
    renderNav();
  }
  document.getElementById('screen-drafting')?.classList.remove('hidden');
  document.getElementById('footer-back')?.classList.remove('visible');
  document.getElementById('footer-back')?.classList.add('hidden');
  document.getElementById('footer-send')?.classList.add('hidden');
  hideProposalReviewModal();
  updateSendBtn();
}

function roiHasVideo() {
  return options.some(opt => opt.bundles && opt.bundles.some(b => isVideoCore(b.coreKey)));
}

function toggleRoiCat(cat) {
  const body = document.getElementById(`roi-cat-${cat}`);
  if (body) body.classList.toggle('hidden');
}

function syncRoiSafetyState() {
  const hasVideo = roiHasVideo();
  const icon = document.getElementById('roi-safety-icon');
  const title = document.getElementById('roi-safety-title');
  const badge = document.getElementById('roi-safety-badge');
  const body = document.getElementById('roi-cat-safety');
  if (!icon) return;
  if (hasVideo) {
    icon.textContent = 'videocam';
    icon.style.color = 'var(--red)';
    if (title) { title.textContent = 'Safety & Cameras'; title.style.color = 'var(--black)'; }
    if (badge) { badge.textContent = 'Auto-enabled'; badge.style.color = 'var(--green)'; badge.style.borderColor = 'var(--green)'; }
    if (body) body.classList.remove('hidden');
  } else {
    icon.textContent = 'videocam_off';
    icon.style.color = 'var(--gray-400)';
    if (title) { title.textContent = 'Safety & Cameras'; title.style.color = 'var(--gray-400)'; }
    if (badge) { badge.textContent = 'No video options'; badge.style.color = 'var(--gray-400)'; badge.style.borderColor = 'var(--gray-300)'; }
    if (body) body.classList.add('hidden');
  }
}

function getRoiConfig() {
  const billingMethod = document.getElementById('roi-billing-method')?.value || 'perJob';
  return {
    productivity: {
      enabled: document.getElementById('roi-productivity-enabled')?.checked ?? true,
      billingMethod,
      avgBillRate:    parseFloat(document.getElementById('roi-avg-bill-rate')?.value)    || 150,
      jobsPerWeek:    parseFloat(document.getElementById('roi-jobs-per-week')?.value)    || 12,
      efficiencyGain: parseFloat(document.getElementById('roi-efficiency-gain')?.value)  || 15,
    },
    fuel: {
      enabled: document.getElementById('roi-fuel-enabled')?.checked ?? true,
      costPerGallon:      parseFloat(document.getElementById('roi-cost-per-gallon')?.value) || 2.95,
      galSavedPerWeekVeh: parseFloat(document.getElementById('roi-gal-saved')?.value)       || 2,
    },
    payroll: {
      enabled: document.getElementById('roi-payroll-enabled')?.checked ?? true,
      otHoursPerWeek: parseFloat(document.getElementById('roi-ot-hours')?.value)      || 1,
      hourlyRate:     parseFloat(document.getElementById('roi-hourly-rate')?.value)    || 25,
      includeMaint:   document.getElementById('roi-include-maint')?.checked ?? true,
      maintSavePerVeh: parseFloat(document.getElementById('roi-maint-save')?.value)   || 100,
    },
    safety: {
      hasVideo: roiHasVideo(),
      avgAccidentCost:    parseFloat(document.getElementById('roi-accident-cost')?.value)      || 25000,
      accidentsPerYear:   parseFloat(document.getElementById('roi-accidents-per-year')?.value) || 1,
      liabilityPct:       parseFloat(document.getElementById('roi-liability-pct')?.value)      || 40,
    }
  };
}

function onRoiChange() {
  // Keep billing method label in sync
  const method = document.getElementById('roi-billing-method')?.value;
  const label = document.getElementById('roi-jobs-label');
  if (label) label.textContent = method === 'perHour' ? 'Hrs / Wk / Veh' : 'Jobs / Wk / Veh';
  // Show/hide maint row
  const includeMaint = document.getElementById('roi-include-maint')?.checked;
  const maintRow = document.getElementById('roi-maint-row');
  if (maintRow) maintRow.classList.toggle('hidden', !includeMaint);
  // Re-render doc live if ROI page is selected
  const roiCb = document.querySelector('[data-material-key="roi"]');
  if (roiCb?.checked) renderProposalDoc();
}

function initRoiConfigPanel() {
  syncRoiSafetyState();
  onRoiChange();
}

function updateMaterialsLabel() {
  const labelEl = document.getElementById('materials-label');
  const btnEl = document.getElementById('materials-btn');
  const menuEl = document.getElementById('materials-menu');
  if (!menuEl) return;
  if (!labelEl || !btnEl) {
    renderCustomizationSummary();
    return;
  }

  const selectedLabels = Array.from(menuEl.querySelectorAll('.materials-menu-item input[type="checkbox"]'))
    .filter((cb) => cb?.checked)
    .map((cb) => cb?.dataset?.materialLabel?.trim())
    .filter(Boolean);

  if (!selectedLabels.length) {
    labelEl.textContent = 'Select materials';
    btnEl.classList.remove('has-selection');
    return;
  }

  labelEl.textContent = selectedLabels.join(' + ');
  btnEl.classList.add('has-selection');
  renderCustomizationSummary();
}

function getSelectedMaterials() {
  const menu = document.getElementById('materials-menu');
  const keys = new Set(['quote']); // always included
  if (!menu) return keys;
  menu.querySelectorAll('.materials-menu-item input[type="checkbox"]').forEach(cb => {
    if (cb.checked && cb.dataset.materialKey) keys.add(cb.dataset.materialKey);
  });
  return keys;
}

function toggleMaterial(el) {
  const cb = el.querySelector('input');
  if (!cb || cb.disabled) return;
  if (!(window.event && window.event.target === cb)) {
    cb.checked = !cb.checked;
  }
  syncCaseStudySelectorVisibility();
  applyLinkedModuleDefaultsFromMaterials();
  renderProposalDoc();
  fillProposalMessageDefaults(true);
  renderCustomizationSummary();
  // 2026-09-28 (per Catalina — "no aparecen las opciones del ROI"): this flow's
  // toggleMaterial() never showed/hid #roi-config-section at all, so checking
  // "ROI Analysis" never revealed the ROI Calculator inputs underneath it.
  // Ported the missing show/hide block from ValuCal-FutureVersion/index.html.
  const roiCb = document.querySelector('#materials-menu input[data-material-key="roi"]');
  const roiSection = document.getElementById('roi-config-section');
  if (roiSection) {
    roiSection.classList.toggle('hidden', !roiCb?.checked);
  }
}

function renderProposalDoc() {
  updateMaterialsLabel();
  const viewer = document.getElementById('prop-doc-viewer');
  if (!viewer) return;

  const dateStr = formatUsDate(new Date());
  const expirationInput = document.getElementById('proposal-expiration-date');
  let expirationStr;
  if (expirationInput && expirationInput.value) {
    const parsedExpiration = parseProposalDate(expirationInput.value);
    expirationStr = parsedExpiration ? formatExpirationDisplayDate(clampExpirationDate(startOfDay(parsedExpiration))) : formatExpirationDisplayDate(getDefaultExpirationDate());
  } else {
    expirationStr = formatExpirationDisplayDate(getDefaultExpirationDate());
  }

  const selectedMaterials = getSelectedMaterials();
  const pages = [];
  let pageNum = 1;

  const buildMsaContainerHtml = (optionTerm) => {
    // Flow hook (Existing Accounts, 2026-10-07): show the same MSA facts as the MSA panel on screen.
    const existingMsaSummary = typeof getProposalDocMsaSummary === 'function' ? getProposalDocMsaSummary() : null;
    if (existingMsaSummary) {
      const summary = existingMsaSummary;
      if (!summary.fields || !summary.fields.length) return '';
      const cell = (label, value) => `<div><div style="font-size:10px;font-weight:700;margin-bottom:3px;white-space:nowrap;">${label}</div><div style="font-size:10px;color:#222;white-space:nowrap;">${value}</div></div>`;
      return `<div style="background:#fff;border:1px solid #000;border-radius:4px;padding:10px 16px 12px;margin:8px 0 14px;">
      <div style="background:#000;color:#fff;font-size:10px;font-weight:700;padding:8px 16px;margin:-10px -16px 10px;border-radius:3px 3px 0 0;">Master Service Agreement${summary.title ? ` · ${summary.title}` : ''}</div>
      <div style="display:grid;grid-template-columns:repeat(${summary.fields.length}, auto);justify-content:space-between;gap:12px;font-size:10px;color:#222;">
        ${summary.fields.map(f => cell(f.label, f.value)).join('')}
      </div>
    </div>`;
    }
    if (!proposalData.msaId) return '';
    const startDate = parseProposalDate(proposalData.msaTermStart);
    const termMonths = Number(optionTerm) || Number(proposalData.msaMinimumServiceTerm) || 0;
    const endDate = getMsaTermEndDate(proposalData.msaTermStart, termMonths);
    const rangeLabel = startDate
      ? (endDate ? `${formatUsDate(startDate)} – ${formatUsDate(endDate)}` : formatUsDate(startDate))
      : '--';
    const minSpend = proposalData.msaMinimumSpendCommitment != null ? `${formatMoney(proposalData.msaMinimumSpendCommitment)}/mo` : '--';
    const termLabel = termMonths ? `${termMonths} months` : '--';
    const rampUp = proposalData.msaRampUpPeriod != null ? `${proposalData.msaRampUpPeriod} days` : '--';
    const field = (label, value) => `<div><div style="font-size:10px;font-weight:700;margin-bottom:3px;white-space:nowrap;">${label}</div><div style="font-size:10px;color:#222;white-space:nowrap;">${value}</div></div>`;
    return `<div style="background:#fff;border:1px solid #000;border-radius:4px;padding:10px 16px 12px;margin:8px 0 14px;">
      <div style="background:#000;color:#fff;font-size:10px;font-weight:700;padding:8px 16px;margin:-10px -16px 10px;border-radius:3px 3px 0 0;">Master Service Agreement</div>
      <div style="display:grid;grid-template-columns:1.15fr 1.25fr .8fr 1.1fr;gap:12px;font-size:10px;color:#222;">
        ${field('Min. spend commitment', minSpend)}
        ${field('Contract Date', rangeLabel)}
        ${field('Term', termLabel)}
        ${field('Ramp-up period', rampUp)}
      </div>
    </div>`;
  };

  // Shared page footer disclaimer
  const DISCLAIMER = 'This quotation is for illustrative purpose only and does not constitute a formal offer or contractual agreement. Final configurations and pricing may vary. For complete terms and conditions, please contact your sales representative.';
  const COPYRIGHT = '© 2026 Verizon Connect. All Rights Reserved.';
  const VZC_LOGO = `<img src="${VC_IMG}logo.svg" alt="Verizon Connect" style="height:25px;display:block;">`;

  function wrapPage(content, num) {
    return `<div class="doc-page-outer" style="margin-bottom:16px;"><div class="vc-doc-shell"><div class="vc-doc-brand-line"></div><div class="vc-doc-inner" style="min-height:1040px;padding-bottom:56px;position:relative;">${content}<div style="position:absolute;bottom:12px;left:0;right:0;border-top:1px solid #dcdcdc;padding-top:10px;text-align:center;background:#ffffff;"><div style="font-size:6.8px;color:#2f2f2f;line-height:1.35;max-width:640px;margin:0 auto;">${DISCLAIMER}</div><div style="font-size:7px;color:#111111;font-weight:700;margin-top:8px;">${COPYRIGHT}</div></div></div></div></div>`;
  }

  // Simple header used on pages 2-4
  function simpleHeader() {
    return `<div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:6px;"><div><div style="font-size:28px;font-weight:900;color:#ee001e;line-height:1.1;">Quote</div><div style="font-size:11px;color:#555;margin-top:3px;">${dateStr}&nbsp;&nbsp;<strong style="font-weight:600;">|</strong>&nbsp;&nbsp;<strong style="font-weight:600;">Ref</strong> Prop-9284</div></div>${VZC_LOGO}</div><div style="height:1px;background:#e0e0e0;margin:10px -24px 20px;"></div>`;
  }

  function getQuoteTermLabel(opt) {
    const base = `${opt.term} Month`;
    const hasSeasonalWindow = Boolean(seasonalConfig && seasonalConfig.startMonth && seasonalConfig.endMonth);
    if (!hasSeasonalWindow) return base;
    return `${base} | Seasonal 6mo/3 off`;
  }

  function getDefaultQuoteTermLabel() {
    const hasSeasonalWindow = Boolean(seasonalConfig && seasonalConfig.startMonth && seasonalConfig.endMonth);
    return hasSeasonalWindow ? '48 Month | Seasonal 6mo/3 off' : '36 Month';
  }

  // ── PAGE 1..N: Quote — one page per option ─────────────────────
  {
    function buildIncludedNoCostRows(startRowIndex) {
      // Figma-aligned placeholders for visual parity; not modeled system costs.
      const includedRows = [
        { title: 'On site professional installation', subtitle: 'Certified Technician Service' },
        { title: 'Hardware and equipment', subtitle: '' },
        { title: 'Standard Activation', subtitle: 'One-time fee per unit' }
      ];
      return includedRows.map(function (row, offset) {
        const rowBg = ((startRowIndex + offset) % 2 === 1) ? 'background:#f7f7f7;' : '';
        const subtitleHtml = row.subtitle
          ? '<div style="font-size:9px;color:#555;line-height:1.3;">' + proposalEscapeHtml(row.subtitle) + '</div>'
          : '';
        return '<tr style="' + rowBg + '">' +
          '<td style="padding:8px 6px;font-size:10px;vertical-align:top;border-bottom:1px solid #ededed;color:#222;">1</td>' +
          '<td style="padding:8px 6px;font-size:10px;vertical-align:top;border-bottom:1px solid #ededed;color:#222;"><div style="font-weight:700;line-height:1.25;">' + proposalEscapeHtml(row.title) + '</div>' + subtitleHtml + '</td>' +
          '<td style="padding:8px 6px;text-align:right;vertical-align:top;border-bottom:1px solid #ededed;white-space:nowrap;"><div style="font-size:8px;color:#777;text-decoration:line-through;line-height:1.2;">$100.00</div><div style="font-size:10px;color:#1a1a1a;line-height:1.25;">$0.00</div></td>' +
          '<td style="padding:8px 6px;text-align:right;vertical-align:top;border-bottom:1px solid #ededed;white-space:nowrap;"><div style="font-size:10px;font-weight:700;color:#16a34a;line-height:1.25;">$0.00</div></td>' +
        '</tr>';
      }).join('');
    }

    const buildQuoteTableHtml = (optionLabel, termLabel, rowsHtml, optTotal, standardTotal) => {
      const hasDiscountedTotal = Number.isFinite(standardTotal) && standardTotal > optTotal + 0.005;
      return `<div style="margin-bottom:16px;"><div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:5px;"><div style="font-size:22px;font-weight:900;color:#ee001e;line-height:1.05;">${optionLabel}</div><div style="font-size:18px;font-weight:700;color:#1a1a1a;line-height:1.1;">${termLabel}</div></div><div style="height:1px;background:#1a1a1a;margin-bottom:0;"></div><table style="width:100%;border-collapse:collapse;"><thead><tr style="border-bottom:1px solid #d8d8d8;"><th style="padding:7px 6px;text-align:left;font-size:10px;font-weight:700;color:#1a1a1a;">QTY</th><th style="padding:7px 6px;text-align:left;font-size:10px;font-weight:700;color:#1a1a1a;">Description</th><th style="padding:7px 6px;text-align:right;font-size:10px;font-weight:700;color:#1a1a1a;">Unit price</th><th style="padding:7px 6px;text-align:right;font-size:10px;font-weight:700;color:#1a1a1a;">Total</th></tr></thead><tbody>${rowsHtml || '<tr><td colspan="4" style="padding:10px 6px;font-size:10px;color:#888;text-align:center;">No solutions added</td></tr>'}</tbody></table><div style="display:flex;flex-direction:column;align-items:flex-end;padding:8px 0 2px;gap:3px;">${hasDiscountedTotal ? `<div style="display:flex;align-items:center;gap:6px;"><div style="font-size:9px;color:#666;">Standard Monthly Rate</div><div style="font-size:11px;color:#777;text-decoration:line-through;">${formatMoney(standardTotal)}</div></div>` : ''}<div style="display:flex;align-items:baseline;gap:6px;"><div style="font-size:10px;font-weight:800;color:#ee001e;">Total Monthly Payment</div><div style="font-size:15px;font-weight:900;color:#1a1a1a;">${formatMoney(optTotal)}</div></div><div style="font-size:7px;color:#999;">*Excludes applicable taxes</div></div></div>`;
    };

    const upperLegal = `<div style="margin-top:10px;font-size:6.8px;color:#666;line-height:1.3;">This promotion is available to select new and existing Verizon Business customers in the US only, excluding Reveal Starter customers, OEM customers, Work, Group Purchasing Organization customers (GPOs), seasonal contracts, month-to-month contracts, federal, state and local government entities, healthcare sector, and migrations. Minimum Purchase Required: 5 Reveal Vehicle Tracking Subscription or 5 Reveal Powered Asset Tracking or 5 Reveal Vehicle Tracking Subscription plus either 1 Road-facing AI Dashcam or 1 Dual Cam with AI Dashcam. Promo credits and eligibility requirements are no longer met. Early cancellation or termination fees and other taxes, fees and terms may apply. Offer valid through December 31, 2026 or while supplies last. © 2026 Verizon.</div>`;

    const quotePageHeaderHtml = `<div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:7px;"><div><div style="font-size:30px;font-weight:900;color:#ee001e;line-height:1.04;">Quote</div><div style="font-size:10px;color:#555;margin-top:3px;"><strong style="font-weight:700;">${dateStr}</strong>&nbsp;|&nbsp;<strong style="font-weight:700;">Ref</strong> Prop-9284</div></div><div style="padding-top:4px;">${VZC_LOGO}</div></div><div style="background:#f8f3e9;padding:10px 20px;margin:8px -24px 14px;display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;font-size:10px;color:#222;"><div><div style="font-weight:700;margin-bottom:3px;font-size:10px;">Prepared by</div><div>Lisa Sullivan</div><div style="color:#666;">lisa.sullivan@verizonconnect.com</div><div style="color:#666;">(304) 555-0192</div></div><div><div style="font-weight:700;margin-bottom:3px;font-size:10px;">Prepared for</div><div>Apex Logistics Corp</div><div style="color:#666;">123 Industrial PKWY, Tampa FL 33602, USA</div></div><div style="text-align:right;"><div style="font-weight:700;margin-bottom:3px;font-size:10px;">Valid until</div><div>${expirationStr}</div></div></div>`;

    const buildOptionPageHtml = (opt, i) => {
      let totalUnits = 0;
      opt.bundles.forEach(b => { totalUnits += b.qty; });
      const optionPromo = getOptionPromotion(opt);
      let optTotal = 0;
      let standardTotal = 0;

      const bundleRowsHtml = opt.bundles.map((b, rowIdx) => {
        const livePromo = b.promoType || optionPromo || 'Standard';
        const { unitPrice, monthly } = calcBundle(b, opt.term, livePromo, totalUnits);
        const standardUnitPrice = getStandardUnitPrice(b);
        const standardMonthly = standardUnitPrice * b.qty;
        optTotal += monthly;
        standardTotal += standardMonthly;

        const featNames = (b.features || b.selectedFeatures || []).map(k => {
          if (k === 'evc') return `EVC (${getBundleEvcLabel(b)})`;
          return featureLabels[k] || k;
        }).filter(Boolean);
        const featLine = featNames.length ? `<div style="font-size:9px;color:#555;line-height:1.3;">${featNames.join(', ')}</div>` : '';
        const hasDiscount = (standardUnitPrice - unitPrice) > 0.005;
        const rowBg = (rowIdx % 2 === 1) ? 'background:#f7f7f7;' : '';
        const bundleTermMonths = Number.parseInt(opt.term, 10) || 0;
        const totalSavings = (standardMonthly - monthly) * bundleTermMonths;
        const promoBadge = hasDiscount ? '<span style="display:inline-flex;align-items:center;background:#16a34a;color:#fff;border-radius:4px;font-size:8px;font-weight:700;padding:1px 5px;margin-top:3px;">Total Savings: ' + formatMoney(totalSavings) + '</span>' : '';

        return `<tr style="${rowBg}"><td style="padding:8px 6px;font-size:10px;vertical-align:top;border-bottom:1px solid #ededed;color:#222;">${b.qty}</td><td style="padding:8px 6px;font-size:10px;vertical-align:top;border-bottom:1px solid #ededed;color:#222;"><div style="font-weight:700;line-height:1.25;">${b.coreName}</div>${featLine}${promoBadge}</td><td style="padding:8px 6px;text-align:right;vertical-align:top;border-bottom:1px solid #ededed;white-space:nowrap;">${hasDiscount ? `<div style="font-size:8px;color:#777;text-decoration:line-through;line-height:1.2;">${formatMoney(standardUnitPrice)}</div>` : ''}<div style="font-size:10px;color:#1a1a1a;line-height:1.25;">${formatMoney(unitPrice)}</div></td><td style="padding:8px 6px;text-align:right;vertical-align:top;border-bottom:1px solid #ededed;white-space:nowrap;">${hasDiscount ? `<div style="font-size:8px;color:#777;text-decoration:line-through;line-height:1.2;">${formatMoney(standardMonthly)}</div>` : ''}<div style="font-size:10px;font-weight:700;color:#1a1a1a;line-height:1.25;">${formatMoney(monthly)}</div></td></tr>`;
      }).join('');
      const rowsHtml = bundleRowsHtml + buildIncludedNoCostRows(opt.bundles.length);

      const tableHtml = buildQuoteTableHtml(getOptionDisplayLabel(i + 1), `${opt.term} Month`, rowsHtml, optTotal, standardTotal);
      return `${quotePageHeaderHtml}${buildMsaContainerHtml(opt.term)}${tableHtml}${upperLegal}`;
    };

    if (options.length > 0) {
      options.forEach((opt, i) => {
        if (!isOptionSendableInProposal(opt)) return;
        pages.push(wrapPage(buildOptionPageHtml(opt, i), pageNum++));
      });
    } else {
      const defaultBaseRow = `<tr><td style="padding:8px 6px;font-size:10px;vertical-align:top;border-bottom:1px solid #ededed;color:#222;">25</td><td style="padding:8px 6px;font-size:10px;vertical-align:top;border-bottom:1px solid #ededed;color:#222;"><div style="font-weight:700;line-height:1.25;">Vehicle Tracking Subscription</div><div style="font-size:9px;color:#555;line-height:1.3;">Driver ID, Panic Button</div></td><td style="padding:8px 6px;text-align:right;vertical-align:top;border-bottom:1px solid #ededed;white-space:nowrap;"><div style="font-size:10px;color:#1a1a1a;line-height:1.25;">$42.00</div></td><td style="padding:8px 6px;text-align:right;vertical-align:top;border-bottom:1px solid #ededed;white-space:nowrap;"><div style="font-size:10px;font-weight:700;color:#1a1a1a;line-height:1.25;">$1,050.00</div></td></tr>`;
      const defaultRows = defaultBaseRow + buildIncludedNoCostRows(1);
      const defaultOptionTableHtml = buildQuoteTableHtml('Option 1', getDefaultQuoteTermLabel(), defaultRows, 1050, 1050);
      pages.push(wrapPage(`${quotePageHeaderHtml}${buildMsaContainerHtml()}${defaultOptionTableHtml}${upperLegal}`, pageNum++));
    }
  }

  let onboardingPageContent = null;
  let caseStudyPageContent = null;
  let roiPageContent = null;

  // ── OPTIONAL MATERIAL: Onboarding Flyer ──────────────────────
  if (selectedMaterials.has('onboarding')) {
    const HERO_IMG = `${VC_IMG}img_1.png`;
    const CREW_IMG = `${VC_IMG}image_2.png`;
    const page2 = `${simpleHeader()}<div style="position:relative;margin:0 -24px 24px;overflow:hidden;height:260px;background:#4a5568 url('${HERO_IMG}') center/cover no-repeat;"><div style="position:absolute;left:24px;top:24px;width:46%;background:#ee001e;color:#fff;padding:22px 18px 18px;"><div style="font-size:21px;font-weight:700;line-height:1.18;margin-bottom:10px;">Fast, no&#8209;hassle onboarding with Verizon Connect</div><div style="font-size:12px;line-height:1.4;">Minimize disruption,<br><strong>Maximize ROI.</strong></div></div></div><div style="display:grid;grid-template-columns:1fr 1fr;gap:24px;margin-bottom:26px;"><div style="font-size:12px;color:#222;line-height:1.65;">Running a fleet leaves you with little time to spare. That's why we designed an onboarding process that delivers <strong>fast results with minimal vehicle downtime.</strong> Here's what you can expect:</div><div>${[['Dedicated onboarding success expert','A single point of contact to guide you every step of the way'],['Flexible installation scheduling','Evenings and weekends available, so daily routes stay intact'],['Complete control, always','Pick the installation window that works for you. We handle the logistics']].map(([t,d]) => `<div style="margin-bottom:12px;"><div style="font-size:12px;font-weight:700;color:#1a1a1a;">${t}</div><div style="font-size:11px;color:#555;line-height:1.45;">${d}</div></div>`).join('')}</div></div><div><div style="font-size:18px;font-weight:800;color:#ee001e;margin-bottom:2px;">Your proven, three-step journey</div><div style="font-size:11px;color:#888;margin-bottom:16px;">Efficient. Predictable. Outcome-driven.</div><div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;align-items:start;"><div>${[['Plan for success','We help you prepare for a smooth rollout, minimizing disruption to your business and accelerating ROI.'],['Install with confidence','Our professional installers are experts at installing fleet management solutions, ensuring your installation goes right the first time to minimize fleet downtime.'],['Activate day-one impact','Gain instant access to live tracking, real-time alerts, and the insights required to improve driver safety and operational efficiency, reduce fuel costs, and stay compliant.']].map(([t,d]) => `<div style="margin-bottom:14px;"><div style="font-size:12px;font-weight:700;color:#1a1a1a;margin-bottom:4px;">${t}</div><div style="font-size:11px;color:#555;line-height:1.5;">${d}</div></div>`).join('')}</div><div style="background:#4a5568 url('${CREW_IMG}') center/cover no-repeat;min-height:220px;border-radius:4px;"></div></div></div>`;
    onboardingPageContent = page2;
  }

  // ── OPTIONAL MATERIAL: Case Study ────────────────────────────
  if (selectedMaterials.has('case-study')) {
    const selectedCaseStudy = getSelectedCaseStudyData();
    const challengesHtml = (selectedCaseStudy.challenges || []).map(function (item) {
      return '<li>' + proposalEscapeHtml(item) + '</li>';
    }).join('');
    const solutionsHtml = (selectedCaseStudy.solutions || []).map(function (item) {
      return '<li>' + proposalEscapeHtml(item) + '</li>';
    }).join('');
    const page3 = `${simpleHeader()}<div style="font-size:11px;font-weight:700;color:#555;margin-bottom:2px;">ROI Success history</div><div style="font-size:20px;font-weight:800;color:#ee001e;margin-bottom:18px;">${proposalEscapeHtml(selectedCaseStudy.title)}</div><div style="border:1px solid #e0e0e0;border-radius:8px;padding:18px 20px;margin-bottom:18px;"><div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;"><div style="color:#d4a800;font-size:18px;letter-spacing:3px;">&#9733;&#9733;&#9733;&#9733;&#9733;</div><div style="font-size:10px;font-weight:700;color:#555;border:1px solid #ccc;border-radius:4px;padding:3px 8px;">Verified result</div></div><div style="font-size:13px;color:#1a1a1a;margin-bottom:6px;">&quot;${proposalEscapeHtml(selectedCaseStudy.quote)}&quot;</div><div style="font-size:11px;color:#555;"><strong>Customer:</strong> ${proposalEscapeHtml(selectedCaseStudy.company)}</div><div style="background:#f8f3e9;border:1px solid #e9dfc9;border-radius:6px;padding:12px 14px;margin-top:14px;display:flex;align-items:flex-start;gap:10px;"><span class="material-symbols-outlined" style="font-size:16px;color:#555;flex-shrink:0;margin-top:1px;">verified_user</span><div><div style="font-size:11px;font-weight:700;color:#1a1a1a;margin-bottom:2px;">Proven outcome</div><div style="font-size:11px;color:#444;line-height:1.5;">${proposalEscapeHtml(selectedCaseStudy.outcome)}</div></div></div></div><div style="border:1px solid #e0e0e0;border-radius:8px;overflow:hidden;margin-bottom:24px;"><div style="display:grid;grid-template-columns:1fr 1fr;"><div style="padding:16px 18px;border-right:1px solid #e0e0e0;"><div style="font-size:12px;font-weight:700;margin-bottom:10px;">Common challenges</div><ul style="margin:0;padding-left:16px;font-size:11px;color:#444;line-height:1.9;">${challengesHtml}</ul></div><div style="padding:16px 18px;"><div style="font-size:12px;font-weight:700;margin-bottom:10px;">Verizon Connect Solution</div><ul style="margin:0;padding-left:16px;font-size:11px;color:#444;line-height:1.9;">${solutionsHtml}</ul></div></div></div><div style="background:#f5f5f5;margin:0 -24px -24px;padding:36px 24px;text-align:center;"><div style="margin-bottom:10px;"><span class="material-symbols-outlined" style="font-size:28px;color:#1a1a1a;">videocam</span></div><div style="font-size:17px;font-weight:800;color:#1a1a1a;margin-bottom:8px;">Want to see the full story?</div><div style="font-size:12px;color:#666;margin-bottom:22px;">Scan or click below to view the full success story and video testimonial.</div><div style="display:inline-block;color:#0B5FFF;font-size:13px;font-weight:700;text-decoration:underline;cursor:default;">View details</div></div>`;
    caseStudyPageContent = page3;
  }

  // ── OPTIONAL MATERIAL: ROI / Business Impact Analysis ────────
  if (selectedMaterials.has('roi')) {
    let totalUnitsAll = 0;
    options.forEach(opt => opt.bundles.forEach(b => { totalUnitsAll += b.qty; }));
    const fleetSize = totalUnitsAll || 50;
    const cfg = getRoiConfig();

    // Compute per-category monthly values
    const weeksPerMonth = 52 / 12;

    let grossMonthly = 0;
    const roiRows = [];

    // Productivity
    if (cfg.productivity.enabled) {
      const { billingMethod, avgBillRate, jobsPerWeek, efficiencyGain } = cfg.productivity;
      let monthlyGain;
      if (billingMethod === 'perHour') {
        monthlyGain = avgBillRate * jobsPerWeek * (efficiencyGain / 100) * fleetSize * weeksPerMonth;
      } else {
        monthlyGain = avgBillRate * jobsPerWeek * (efficiencyGain / 100) * fleetSize * weeksPerMonth;
      }
      grossMonthly += monthlyGain;
      const methodLabel = billingMethod === 'perHour' ? 'Hrs/Wk/Veh' : 'Jobs/Wk/Veh';
      roiRows.push({ icon: 'trending_up', title: 'Productivity', detail: `${methodLabel}: ${jobsPerWeek} &nbsp;|&nbsp; Rate: ${formatMoney(avgBillRate)} &nbsp;|&nbsp; Gain: ${efficiencyGain}%`, label: 'Monthly Gain', value: formatMoney(monthlyGain) });
    }

    // Fuel
    if (cfg.fuel.enabled) {
      const { costPerGallon, galSavedPerWeekVeh } = cfg.fuel;
      const monthlyGain = costPerGallon * galSavedPerWeekVeh * fleetSize * weeksPerMonth;
      grossMonthly += monthlyGain;
      roiRows.push({ icon: 'local_gas_station', title: 'Fuel Cost Reduction', detail: `Avg: ${formatMoney(costPerGallon)}/gal &nbsp;|&nbsp; Saved: ${galSavedPerWeekVeh} gal/wk`, label: 'Monthly Gain', value: formatMoney(monthlyGain) });
    }

    // Payroll & Maint
    if (cfg.payroll.enabled) {
      const { otHoursPerWeek, hourlyRate, includeMaint, maintSavePerVeh } = cfg.payroll;
      const payrollMonthly = hourlyRate * otHoursPerWeek * fleetSize * weeksPerMonth;
      const maintMonthly = includeMaint ? (maintSavePerVeh * fleetSize / 12) : 0;
      const totalMonthly = payrollMonthly + maintMonthly;
      grossMonthly += totalMonthly;
      const detail = `Rate: ${formatMoney(hourlyRate)}/hr &nbsp;|&nbsp; Reduced: ${otHoursPerWeek} hrs/wk${includeMaint ? ` &nbsp;|&nbsp; Maint: ${formatMoney(maintSavePerVeh)}/veh/yr` : ''}`;
      roiRows.push({ icon: 'attach_money', title: 'Payroll' + (includeMaint ? ' &amp; Maintenance' : ' Optimization'), detail, label: 'Monthly Savings', value: formatMoney(totalMonthly) });
    }

    // Safety & Cameras (auto)
    const safetyEnabled = cfg.safety.hasVideo;
    let estAnnualLiability = 0;
    if (safetyEnabled) {
      const { avgAccidentCost, accidentsPerYear, liabilityPct } = cfg.safety;
      estAnnualLiability = avgAccidentCost * accidentsPerYear * (liabilityPct / 100);
      const safetyMonthly = estAnnualLiability / 12;
      grossMonthly += safetyMonthly;
      roiRows.push({ icon: 'shield', title: 'Safety &amp; Cameras', detail: `Avg Accident: ${formatMoney(avgAccidentCost)} &nbsp;|&nbsp; Liability reduction: ${liabilityPct}%`, label: 'Est. Monthly Savings', value: formatMoney(safetyMonthly) });
    }

    let sysInvestment = 0;
    if (options.length > 0) {
      const firstOpt = options[0];
      const { totalMonthly } = calcOption(firstOpt, getOptionPromotion(firstOpt));
      sysInvestment = totalMonthly;
    }
    const netBenefit = grossMonthly - sysInvestment;
    const roiRatio = sysInvestment > 0 ? (grossMonthly / sysInvestment).toFixed(1) : '—';

    const roiRowsHtml = roiRows.map(r => `<div style="display:flex;justify-content:space-between;align-items:center;padding:13px 0;border-bottom:1px solid #f0f0f0;"><div style="display:flex;align-items:center;gap:12px;"><div style="width:36px;height:36px;border:1px solid #e0e0e0;border-radius:6px;display:flex;align-items:center;justify-content:center;flex-shrink:0;"><span class="material-symbols-outlined" style="font-size:18px;color:#555;">${r.icon}</span></div><div><div style="font-size:12px;font-weight:700;color:#1a1a1a;margin-bottom:2px;">${r.title}</div><div style="font-size:10px;color:#888;">${r.detail}</div></div></div><div style="text-align:right;flex-shrink:0;"><div style="font-size:10px;color:#888;margin-bottom:1px;">${r.label}</div><div style="font-size:14px;font-weight:700;color:#1a1a1a;">${r.value}</div></div></div>`).join('');

    const page4 = `${simpleHeader()}<div style="font-size:20px;font-weight:800;color:#ee001e;margin-bottom:4px;">Business Impact Analysis</div><div style="margin-bottom:18px;">${roiRowsHtml || '<div style="font-size:12px;color:#aaa;padding:16px 0;text-align:center;">No categories selected.</div>'}</div><div style="background:#f8f3e9;margin:0 -24px 22px;padding:20px 24px;text-align:center;"><div style="font-size:14px;font-weight:800;color:#ee001e;margin-bottom:2px;">Estimated Monthly Financial Impact</div><div style="font-size:10px;color:#888;margin-bottom:16px;">Based on fleet size: ${fleetSize}</div><div style="display:flex;align-items:center;justify-content:center;gap:14px;flex-wrap:wrap;"><div><div style="font-size:22px;font-weight:900;color:#1a1a1a;">${formatMoney(grossMonthly)}</div><div style="background:#16a34a;color:#fff;font-size:9px;font-weight:700;border-radius:3px;padding:2px 7px;margin-top:4px;display:inline-block;">Gross Monthly Savings</div></div><div style="font-size:22px;color:#555;font-weight:300;">−</div><div><div style="font-size:22px;font-weight:900;color:#1a1a1a;">${formatMoney(sysInvestment)}</div><div style="background:#1d4ed8;color:#fff;font-size:9px;font-weight:700;border-radius:3px;padding:2px 7px;margin-top:4px;display:inline-block;">System Investment</div></div><div style="font-size:22px;color:#555;font-weight:300;">=</div><div><div style="font-size:22px;font-weight:900;color:#1a1a1a;">${formatMoney(netBenefit)}</div><div style="background:#1d4ed8;color:#fff;font-size:9px;font-weight:700;border-radius:3px;padding:2px 7px;margin-top:4px;display:inline-block;">Net Monthly Benefit</div></div></div><div style="font-size:11px;color:#555;margin-top:12px;">ROI Ratio ${roiRatio}:1</div></div>${safetyEnabled ? `<div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;align-items:start;"><div><div style="font-size:14px;font-weight:800;color:#1a1a1a;margin-bottom:8px;">Video Safety ROI and Liability Protection</div><div style="font-size:11px;color:#444;line-height:1.65;">Implementing Video Telematics (Dash Cams) significantly reduces liability exposure by providing exonerating evidence in false claims and improving driver behavior. Industry data suggests commercial fleets can reduce accident frequency by up to 40%.*</div></div><div style="border:1px solid #e0e0e0;border-radius:8px;padding:16px;"><div style="margin-bottom:12px;"><div style="font-size:10px;color:#888;margin-bottom:2px;">AVG Cost of Accident</div><div style="font-size:13px;font-weight:700;color:#1a1a1a;">${formatMoney(cfg.safety.avgAccidentCost)}</div></div><div style="margin-bottom:12px;"><div style="font-size:10px;color:#888;margin-bottom:2px;">EST Accidents Avoided</div><div style="font-size:13px;font-weight:700;color:#1a1a1a;">${cfg.safety.accidentsPerYear} / Year</div></div><div><div style="font-size:10px;color:#888;margin-bottom:2px;">EST Annual Liability Savings</div><div style="font-size:14px;font-weight:800;color:#ee001e;">${formatMoney(estAnnualLiability)}</div><div style="font-size:10px;color:#888;">Non-recurring / Insurance</div></div></div></div>` : ''}`;
    roiPageContent = page4;
  }

  [roiPageContent, caseStudyPageContent, onboardingPageContent]
    .filter(Boolean)
    .forEach(content => pages.push(wrapPage(content, pageNum++)));

  viewer.innerHTML = pages.join('');
  fillProposalMessageDefaults();
  requestAnimationFrame(scaleDocPages);
}

  function wrapPage(content, num) {
    return `<div class="doc-page-outer" style="margin-bottom:16px;"><div class="vc-doc-shell"><div class="vc-doc-brand-line"></div><div class="vc-doc-inner" style="min-height:1040px;padding-bottom:56px;position:relative;">${content}<div style="position:absolute;bottom:12px;left:0;right:0;border-top:1px solid #dcdcdc;padding-top:10px;text-align:center;background:#ffffff;"><div style="font-size:6.8px;color:#2f2f2f;line-height:1.35;max-width:640px;margin:0 auto;">${DISCLAIMER}</div><div style="font-size:7px;color:#111111;font-weight:700;margin-top:8px;">${COPYRIGHT}</div></div></div></div></div>`;
  }

  function simpleHeader() {
    return `<div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:6px;"><div><div style="font-size:28px;font-weight:900;color:#ee001e;line-height:1.1;">Quote</div><div style="font-size:11px;color:#555;margin-top:3px;">${dateStr}&nbsp;&nbsp;<strong style="font-weight:600;">|</strong>&nbsp;&nbsp;<strong style="font-weight:600;">Ref</strong> Prop-9284</div></div>${VZC_LOGO}</div><div style="height:1px;background:#e0e0e0;margin:10px -24px 20px;"></div>`;
  }

  function getQuoteTermLabel(opt) {
    const base = `${opt.term} Month`;
    const hasSeasonalWindow = Boolean(seasonalConfig && seasonalConfig.startMonth && seasonalConfig.endMonth);
    if (!hasSeasonalWindow) return base;
    return `${base} | Seasonal 6mo/3 off`;
  }

  function getDefaultQuoteTermLabel() {
    const hasSeasonalWindow = Boolean(seasonalConfig && seasonalConfig.startMonth && seasonalConfig.endMonth);
    return hasSeasonalWindow ? '48 Month | Seasonal 6mo/3 off' : '36 Month';
  }

    function buildIncludedNoCostRows(startRowIndex) {
      // Figma-aligned placeholders for visual parity; not modeled system costs.
      const includedRows = [
        { title: 'On site professional installation', subtitle: 'Certified Technician Service' },
        { title: 'Hardware and equipment', subtitle: '' },
        { title: 'Standard Activation', subtitle: 'One-time fee per unit' }
      ];
      return includedRows.map(function (row, offset) {
        const rowBg = ((startRowIndex + offset) % 2 === 1) ? 'background:#f7f7f7;' : '';
        const subtitleHtml = row.subtitle
          ? '<div style="font-size:9px;color:#555;line-height:1.3;">' + proposalEscapeHtml(row.subtitle) + '</div>'
          : '';
        return '<tr style="' + rowBg + '">' +
          '<td style="padding:8px 6px;font-size:10px;vertical-align:top;border-bottom:1px solid #ededed;color:#222;">1</td>' +
          '<td style="padding:8px 6px;font-size:10px;vertical-align:top;border-bottom:1px solid #ededed;color:#222;"><div style="font-weight:700;line-height:1.25;">' + proposalEscapeHtml(row.title) + '</div>' + subtitleHtml + '</td>' +
          '<td style="padding:8px 6px;text-align:right;vertical-align:top;border-bottom:1px solid #ededed;white-space:nowrap;"><div style="font-size:8px;color:#777;text-decoration:line-through;line-height:1.2;">$100.00</div><div style="font-size:10px;color:#1a1a1a;line-height:1.25;">$0.00</div></td>' +
          '<td style="padding:8px 6px;text-align:right;vertical-align:top;border-bottom:1px solid #ededed;white-space:nowrap;"><div style="font-size:10px;font-weight:700;color:#16a34a;line-height:1.25;">$0.00</div></td>' +
        '</tr>';
      }).join('');
    }

function onProposalExpirationChange() {
  if (!validateAndSyncExpirationFrom('proposal-expiration-date')) return;
  renderProposalDoc();
}

function updateCharCount(el) { 
  const len = el.value !== undefined ? el.value.length : (el.textContent || '').length;
  document.getElementById('char-count').innerText = len; 
  updateSendBtn();
}

function isValidEmailAddress(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email || '').trim());
}

function getProposalReviewValidationState() {
  const to = document.getElementById('prop-msg-to')?.value.trim() ?? '';
  const closeDate = document.getElementById('proposal-close-date')?.value.trim() ?? '';
  const expiration = document.getElementById('proposal-expiration-date')?.value.trim() ?? '';
  const repEmail = document.getElementById('gi-rep-email')?.value.trim() ?? '';
  const closeDateObj = closeDate ? parseProposalDate(closeDate) : null;
  const expirationObj = expiration ? parseProposalDate(expiration) : null;

  const closeDateValid = !!closeDateObj;
  const expirationValid = !expirationObj || (!!closeDateObj && startOfDay(expirationObj) >= startOfDay(closeDateObj));
  const repEmailValid = !repEmail || isValidEmailAddress(repEmail);

  return {
    toValid: to.length > 0,
    closeDateValid,
    expirationValid,
    repEmailValid,
    isValid: to.length > 0 && closeDateValid && expirationValid && repEmailValid
  };
}

function renderProposalReviewInlineValidation() {
  const validation = getProposalReviewValidationState();
  const closeDateError = document.getElementById('close-date-error');
  const expirationError = document.getElementById('expiration-date-error');
  const repEmailError = document.getElementById('rep-email-error');

  if (closeDateError) closeDateError.classList.toggle('hidden', validation.closeDateValid);
  if (expirationError) expirationError.classList.toggle('hidden', validation.expirationValid);
  if (repEmailError) repEmailError.classList.toggle('hidden', validation.repEmailValid);
  document.getElementById('proposal-close-date')?.classList.toggle('input--error', !validation.closeDateValid);
  document.getElementById('proposal-expiration-date')?.classList.toggle('input--error', !validation.expirationValid);
}

function isOptionSendableInProposal(opt) {
  if (!opt) return false;
  if (opt.msaPreviewFor) return isOptionSendableInProposal(options.find(o => o.id === opt.msaPreviewFor));
  if (!opt.bundles || !opt.bundles.length) return true;
  return !getOptionApprovalInfo(opt, opt).requiresApproval;
}
