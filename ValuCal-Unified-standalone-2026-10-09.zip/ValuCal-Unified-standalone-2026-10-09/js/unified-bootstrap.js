/* Unified entry point — scenario bootstrap (2026-10-09).
   Unified/index.html is built from the Initial Sales flow (the most complete one) and keeps all of its
   behavior. This file applies the scenario in the URL before the first route opens.

   Account (Valu Cal domain model, assets-shared/js/vc-domain.js):
     account=prospect|pilot|customer · contractedPilot=true|false · cancellation=none|partial|full
     purchaseMode=mixed|bundle|a-la-carte · costType=mixed|opex|capex · paymentMethod=autopay|direct-bill
     entryPoint=newProposal|renewalRewrap|reactivationReinstatement|…
   Prototype options (config/flow-registry.js): hasPreviousProposals, accountValidation, route.
   Legacy: accountType=standard|pilot still works (standard = prospect). */
var UNIFIED_ACCOUNT_PARAMS = ['account', 'contractedPilot', 'pilotMsa', 'multipleContractAccounts', 'contractAccount', 'currentSetupContractAccount', 'cancellation', 'purchaseMode', 'costType', 'paymentMethod', 'entryPoint'];

function readUnifiedAccountFromUrl(search) {
  var params = new URLSearchParams(search || '');
  var legacy = params.get('accountType');
  var type = params.get('account') || (legacy === 'pilot' ? 'pilot' : 'prospect');
  var pick = function (name, list, fallback) { var v = params.get(name); return list.indexOf(v) !== -1 ? v : fallback; };
  var accountType = pick('account', ['prospect', 'pilot', 'customer'], type === 'pilot' ? 'pilot' : 'prospect');
  return {
    accountType: accountType,
    contractedPilot: params.get('contractedPilot') === 'true',
    pilotHasMsa: accountType === 'pilot' && params.get('contractedPilot') === 'true' && params.get('pilotMsa') === 'true',
    hasMultipleContractAccounts: accountType === 'customer' && params.get('multipleContractAccounts') === 'true',
    contractAccountId: accountType === 'customer' ? params.get('contractAccount') || '' : '',
    currentSetupContractAccountId: accountType === 'customer' ? params.get('currentSetupContractAccount') || 'all' : 'all',
    cancellation: pick('cancellation', ['none', 'partial', 'full'], 'none'),
    purchaseMode: pick('purchaseMode', ['mixed', 'bundle', 'a-la-carte'], 'mixed'),
    costType: pick('costType', ['mixed', 'opex', 'capex'], 'mixed'),
    paymentMethod: pick('paymentMethod', ['autopay', 'direct-bill'], 'autopay'),
    entryPoint: params.get('entryPoint') || 'newProposal',
  };
}

function isPilotDashboardSummaryScenario(account) {
  return !!account && account.accountType === 'pilot' && account.contractedPilot && account.entryPoint === 'newProposal';
}

function applyUnifiedScenario() {
  // 1. The account — only transactions available in this file are applied (see UNIFIED_TRANSACTION_STATUS).
  if (window.VC_DOMAIN && typeof applyUnifiedAccount === 'function') {
    var account = readUnifiedAccountFromUrl(window.location.search);
    var resolved = window.VC_DOMAIN.resolve(account);
    var status = (typeof UNIFIED_TRANSACTION_STATUS !== 'undefined' && UNIFIED_TRANSACTION_STATUS[resolved.transactionId]) || {};
    if (status.available || isPilotDashboardSummaryScenario(Object.assign({}, account, { entryPoint: resolved.entryPoint }))) {
      applyUnifiedAccount(Object.assign({}, account, { entryPoint: resolved.entryPoint }));
    }
  }
  // 2. Prototype options.
  if (!window.VC_UNIFIED || typeof window.VC_UNIFIED.resolve !== 'function') return;
  var params = new URLSearchParams(window.location.search);
  UNIFIED_ACCOUNT_PARAMS.forEach(function (name) { params.delete(name); });
  params.set('accountType', accountType === 'pilot' ? 'pilot' : 'standard');
  var result = window.VC_UNIFIED.resolve('?' + params.toString());
  window.VC_UNIFIED_SELECTION = result.ok ? result.selection : null;
  if (!result.ok) return;
  var s = result.selection;
  if (typeof hasPreviousProposals !== 'undefined' && hasPreviousProposals !== (s.hasPreviousProposals !== false)) {
    hasPreviousProposals = s.hasPreviousProposals !== false;
    var tableBody = document.getElementById('ql-table-body');
    if (tableBody) tableBody.innerHTML = '';
    if (typeof renderQuotesListTable === 'function') renderQuotesListTable();
  }
  if (typeof applyAccountValidationSimulation === 'function') applyAccountValidationSimulation(s.accountValidation);
}

/* Keeps the URL in sync with what the Simulation Builder applied, so a reload or a shared link opens the
   same scenario. */
function syncUnifiedScenarioUrl() {
  if (!window.history || typeof window.history.replaceState !== 'function') return;
  var params = new URLSearchParams(window.location.search);
  ['accountType', 'pilotState', 'pilotMsa', 'route'].forEach(function (name) { params.delete(name); });
  if (typeof unifiedAccount !== 'undefined') {
    params.set('account', unifiedAccount.accountType);
    if (unifiedAccount.accountType === 'pilot') {
      params.set('contractedPilot', String(!!unifiedAccount.contractedPilot));
      if (unifiedAccount.contractedPilot && unifiedAccount.pilotHasMsa) params.set('pilotMsa', 'true'); else params.delete('pilotMsa');
    } else {
      params.delete('contractedPilot');
      params.delete('pilotMsa');
    }
    if (unifiedAccount.accountType === 'customer') {
      params.set('cancellation', unifiedAccount.cancellation);
      if (unifiedAccount.hasMultipleContractAccounts) {
        params.set('multipleContractAccounts', 'true');
        params.set('contractAccount', unifiedAccount.contractAccountId);
        if (unifiedAccount.currentSetupContractAccountId !== 'all') params.set('currentSetupContractAccount', unifiedAccount.currentSetupContractAccountId);
        else params.delete('currentSetupContractAccount');
      } else {
        params.delete('multipleContractAccounts');
        params.delete('contractAccount');
        params.delete('currentSetupContractAccount');
      }
    } else {
      params.delete('cancellation');
      params.delete('multipleContractAccounts');
      params.delete('contractAccount');
      params.delete('currentSetupContractAccount');
    }
    params.set('purchaseMode', unifiedAccount.purchaseMode);
    params.set('costType', unifiedAccount.costType);
    params.set('paymentMethod', unifiedAccount.paymentMethod);
    params.set('entryPoint', unifiedAccount.entryPoint);
  }
  if (typeof hasPreviousProposals !== 'undefined') params.set('hasPreviousProposals', String(hasPreviousProposals));
  if (typeof isAccountReadyForContract === 'function') params.set('accountValidation', isAccountReadyForContract() ? 'ready' : 'pending');
  try { window.history.replaceState(null, '', window.location.pathname + '?' + params.toString()); } catch (e) { /* file:// in some browsers */ }
}
