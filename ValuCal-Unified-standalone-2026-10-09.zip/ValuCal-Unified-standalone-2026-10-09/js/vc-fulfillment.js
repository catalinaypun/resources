/* ── Fulfillment (on hold) (shared, 2026-10-07) ──────────────────────────────────────────
   Fulfillment cards, vehicles, addresses, contacts, mock data — the feature is on hold; kept as-is.
   Moved verbatim from Initial Sales and Existing Accounts, where they were identical (no behavior change).
   They use each flow's own globals (options, proposalData, screen, bld…) at call time. */
function openFulfillmentModal() {
  ensureVehicleArrays();

  // ── Seed ffWaves from contract-phase opt.waves (if wavesEnabled) ──────────
  // Only import waves that have been dispatched (processed) — Contracted = not yet processed.
  if (proposalData.wavesEnabled) {
    const opt = options.find(o => o.id === (typeof selectedOptionId !== 'undefined' ? selectedOptionId : null))
              || options.find(o => o.bundles && o.bundles.length > 0);
    if (opt && Array.isArray(opt.waves) && opt.waves.length > 0) {
      const PROCESSED_STATUSES = ['Dispatched', 'Pending Bind', 'Active-Billing'];
      const processedWaves = opt.waves.filter(w => PROCESSED_STATUSES.includes(w.slotStatus || ''));
      // Seed each bundle's ffWaves with processed contract waves (only if not yet seeded)
      getBundles().forEach(b => {
        if (!ffWaves[b.id]) ffWaves[b.id] = [];
        processedWaves.forEach(cw => {
          const alreadySeeded = ffWaves[b.id].some(fw => String(fw.contractWaveId) === String(cw.id));
          if (!alreadySeeded) {
            ffWaves[b.id].push({
              id: Date.now() + Math.random(),
              contractWaveId: cw.id,
              name: cw.name,
              targetDate: cw.targetDate || '',
              vehicleIds: [],
            });
          }
        });
      });
    }
  }

  ffMainTab = 'vehicles';
  ffActiveTab = getBundles()[0]?.id || 'default';
  ffReturnPending = false;
  document.getElementById('fftab-addresses').className = 'ff-tab';
  document.getElementById('fftab-vehicles').className  = 'ff-tab active';
  document.getElementById('fulfillment-overlay').classList.add('open');
  renderFF();
}

function openFulfillmentModalFromDealResult() {
  openFulfillmentModal();
  // If already submitted, open directly to summary tab
  if (proposalData.fulfillmentSubmitted) {
    switchFulfillmentMainTab('summary');
  }
}

function closeFulfillmentModal() {
  document.getElementById('fulfillment-overlay').classList.remove('open');
}

function switchFulfillmentMainTab(tab) {
  ffMainTab = tab;
  ffActiveTab = tab === 'addresses' ? 'addresses' : tab === 'summary' ? 'summary' : (getBundles()[0]?.id || 'default');
  ffReturnPending = false;
  document.getElementById('fftab-addresses').className = 'ff-tab' + (tab === 'addresses' ? ' active' : '');
  document.getElementById('fftab-vehicles').className  = 'ff-tab' + (tab === 'vehicles'  ? ' active' : '');
  document.getElementById('fftab-summary').className   = 'ff-tab' + (tab === 'summary'   ? ' active' : '');
  renderFF();
}

function switchFulfillmentTab(tabId) { /* legacy compat — no-op */ }

function ffSetTab(tab, pending = false) {
  ffActiveTab = tab;
  if (pending) ffReturnPending = true;
  renderFF();
}

function ffGoToAddresses(pending = false) {
  ffMainTab = 'addresses'; ffActiveTab = 'addresses';
  if (pending) ffReturnPending = true;
  document.getElementById('fftab-addresses').className = 'ff-tab active';
  document.getElementById('fftab-vehicles').className  = 'ff-tab';
  renderFF();
}

function ffGoToVehicles() {
  ffMainTab = 'vehicles';
  ffActiveTab = getBundles()[0]?.id || 'default';
  ffReturnPending = false;
  document.getElementById('fftab-addresses').className = 'ff-tab';
  document.getElementById('fftab-vehicles').className  = 'ff-tab active';
  renderFF();
}

function ffUpdateAddr(id, f, v) { ffAddresses = ffAddresses.map(a => a.id===id ? {...a,[f]:v} : a); }

function ffSaveAddress(id) {
  const a = ffAddresses.find(x => x.id===id);
  if (!a.addr1 || !a.zip) { alert('Please fill address line 1 and zip.'); return; }
  const name = a.addr1 + (a.city?', '+a.city:'') + (a.zip?' '+a.zip:'');
  ffAddresses = ffAddresses.map(x => x.id===id ? {...x, saved:true, name} : x);
  renderFF();
}

function ffRemoveAddress(id) { if (ffAddresses.length>1) { ffAddresses=ffAddresses.filter(a=>a.id!==id); renderFF(); } }

function ffAddAddress() { ffAddresses.push({id:Date.now(),saved:false,name:'',addr1:'',addr2:'',city:'',state:'',zip:'',country:'United States'}); renderFF(); }

function ffUpdateContact(id,f,v){ffContacts=ffContacts.map(c=>c.id===id?{...c,[f]:v}:c);}

function ffSaveContact(id){
  const c=ffContacts.find(x=>x.id===id);
  if(!c.name){alert('Please enter a name.');return;}
  ffContacts=ffContacts.map(x=>x.id===id?{...x,saved:true}:x);renderFF();
}

function ffRemoveContact(id){if(ffContacts.length>1){ffContacts=ffContacts.filter(c=>c.id!==id);renderFF();}}

function ffAddContact(){ffContacts.push({id:Date.now(),saved:false,name:'',phone:'',email:''});renderFF();}

function ffUpdateBundleForm(bundleId, field, value) {
  const form = getFFBundleForm(bundleId);
  form[field] = value;
}

function ffValidateBundleDetails(bundleId) {
  const form = getFFBundleForm(bundleId);
  if (!form.shipAddr1 || !form.shipCity || !form.shipZip) {
    alert('Please complete shipping address (Address 1, City, Zip/Postal Code).');
    return;
  }
  if (!form.contactName || !form.contactPhone) {
    alert('Please complete contact name and phone.');
    return;
  }

  // Validate install address when not same as shipping
  const bundle = getBundles().find(b => String(b.id) === String(bundleId));
  const requiresInstall = bundleRequiresInstallation(bundle || { id: bundleId });
  if (requiresInstall && !form.installSameAsShipping && !form.installAddressId) {
    alert('Please select or enter an installation address, or check "Installation Address is the same as shipping".');
    return;
  }

  const addressId = Date.now();
  const addressName = `${form.shipAddr1}${form.shipCity ? ', ' + form.shipCity : ''}${form.shipZip ? ' ' + form.shipZip : ''}`;
  ffAddresses.push({
    id: addressId,
    saved: true,
    name: addressName,
    addr1: form.shipAddr1,
    addr2: form.shipAddr2,
    city: form.shipCity,
    state: '',
    zip: form.shipZip,
    country: form.shipCountry || 'United States',
  });

  const contactId = Date.now() + 1;
  ffContacts.push({
    id: contactId,
    saved: true,
    name: form.contactName,
    phone: form.contactPhone,
    email: form.contactEmail,
  });

  form.shipAddressId = String(addressId);
  form.shipContactId = String(contactId);
  form.installAddressId = form.installSameAsShipping ? String(addressId) : form.installAddressId;
  form.installContactId = form.installSameAsShipping ? String(contactId) : form.installContactId;

  // Switch to view mode
  delete ffFormEditMode[bundleId];

  showSuccessBanner('Address validated', 'Shipping and contact details were saved for assignment.');
  renderFFContent();
}

function ffEnterEditMode(bundleId) {
  ffFormEditMode[bundleId] = true;
  renderFFContent();
}

function ffUseSavedAddress(bundleId, addressId, scope) {
  if (!addressId) return;
  const form = getFFBundleForm(bundleId);
  const addr = ffAddresses.find(a => String(a.id) === String(addressId));
  if (!addr) return;
  if (scope === 'ship') {
    form.shipAddressId = String(addressId);
    form.shipAddr1 = addr.addr1 || '';
    form.shipAddr2 = addr.addr2 || '';
    form.shipCity  = addr.city  || '';
    form.shipState = addr.state || '';
    form.shipZip   = addr.zip   || '';
    form.shipCountry = addr.country || 'United States';
    if (form.installSameAsShipping) {
      form.installAddressId = String(addressId);
    }
  } else {
    form.installAddressId = String(addressId);
  }
  renderFFContent();
}

function ffUseSavedContact(bundleId, contactId, scope) {
  if (!contactId) return;
  const form = getFFBundleForm(bundleId);
  const contact = ffContacts.find(c => String(c.id) === String(contactId));
  if (!contact) return;
  if (scope === 'ship') {
    form.shipContactId = String(contactId);
    form.contactName  = contact.name  || '';
    form.contactPhone = contact.phone || '';
    form.contactEmail = contact.email || '';
    if (form.installSameAsShipping) {
      form.installContactId = String(contactId);
    }
  } else {
    form.installContactId = String(contactId);
  }
  renderFFContent();
}

function getGlobalVinSet(excludeBundleId = null, excludeVehicleId = null) {
  const set = new Set();
  Object.keys(ffVehicles).forEach(bundleId => {
    if (excludeBundleId && String(bundleId) === String(excludeBundleId)) return;
    (ffVehicles[bundleId] || []).forEach(v => {
      if (excludeVehicleId && String(v.id) === String(excludeVehicleId)) return;
      if (!v.vin) return;
      set.add(v.vin.trim().toUpperCase());
    });
  });
  return set;
}

function ffProcessVins(bId) {
  if (!ffVinInput.trim()) return;
  if (!canAddVehiclesToBundle(bId)) return;
  const globalVins = getGlobalVinSet();
  const bundle = getBundles().find(b => String(b.id) === String(bId));
  const form = getFFBundleForm(bId);
  const qtyCap = getEffectiveBundleQtyCap(bId);
  let remaining = Math.max(0, qtyCap - (ffVehicles[bId] || []).length);
  let duplicateCount = 0;
  let overCapCount = 0;
  ffVinInput.split(',').map(s=>s.trim()).filter(Boolean).forEach(vin => {
    const normalized = vin.toUpperCase();
    if (globalVins.has(normalized)) { duplicateCount += 1; return; }
    if (remaining <= 0) { overCapCount += 1; return; }
    ffVehicles[bId].push({
      id:Date.now()+Math.random(),
      vin:normalized,ymm:'Vehicle',cls:'MD',telematics:'Standard',vehicleName:'',plate:'',
      installType: form.installType || 'vmi',
      shippingId:form.shipAddressId || '',
      shippingContactId:form.shipContactId || '',
      installAddressId:(form.installSameAsShipping ? (form.shipAddressId || '') : (form.installAddressId || '')),
      installContactId:(form.installSameAsShipping ? (form.shipContactId || '') : (form.installContactId || '')),
      activationContact:'', waveId:null,
      isEmergency: false, hasWheelchairLift: false, masterSwitchOff: false, hasCompetitorDevice: false,
    });
    globalVins.add(normalized);
    remaining -= 1;
  });
  if (duplicateCount > 0) alert(`${duplicateCount} duplicate VIN(s) were ignored.`);
  if (overCapCount > 0) alert(`${overCapCount} vehicle(s) were ignored due to solution quantity cap.`);
  ffVinInput=''; renderFF();
}

function ffAddYMM(bId) {
  if (!ffYmm.year||!ffYmm.make||!ffYmm.model) { alert('Fill Year, Make and Model.'); return; }
  if (!canAddVehiclesToBundle(bId)) return;
  const bundle = getBundles().find(b => String(b.id) === String(bId));
  const form = getFFBundleForm(bId);
  const qtyCap = getEffectiveBundleQtyCap(bId);
  const remaining = Math.max(0, qtyCap - (ffVehicles[bId] || []).length);
  const addCount = Math.min(ffYmm.qty, remaining);
  const telematics = detectTelematics(ffYmm.make, ffYmm.year);
  for(let i=0;i<addCount;i++) {
    ffVehicles[bId].push({
      id:Date.now()+Math.random(),
      vin:`TBD-${Date.now().toString(36)}-${i}`,
      ymm:`${ffYmm.year} ${ffYmm.make} ${ffYmm.model}`,
      cls:'MD',
      year: ffYmm.year,
      make: ffYmm.make,
      telematics,
      vehicleName:'',
      plate:'',
      installType: form.installType || 'vmi',
      shippingId:form.shipAddressId || '',
      shippingContactId:form.shipContactId || '',
      installAddressId:(form.installSameAsShipping ? (form.shipAddressId || '') : (form.installAddressId || '')),
      installContactId:(form.installSameAsShipping ? (form.shipContactId || '') : (form.installContactId || '')),
      activationContact:'', waveId:null,
      isEmergency: false, hasWheelchairLift: false, masterSwitchOff: false, hasCompetitorDevice: false,
    });
  }
  if (addCount < ffYmm.qty) alert(`${ffYmm.qty - addCount} vehicle(s) were ignored due to solution quantity cap.`);
  ffYmm={year:'',make:'',model:'',qty:1}; renderFF();
}

function ffAddDOT(bId) {
  if (!ffDot) { alert('Enter a DOT number.'); return; }
  if (!canAddVehiclesToBundle(bId)) return;
  const globalVins = getGlobalVinSet();
  const bundle = getBundles().find(b => String(b.id) === String(bId));
  const form = getFFBundleForm(bId);
  const qtyCap = getEffectiveBundleQtyCap(bId);
  let remaining = Math.max(0, qtyCap - (ffVehicles[bId] || []).length);
  let duplicateCount = 0;
  let overCapCount = 0;
  ['1HGBH41JXMN109186','2T1BURHE0JC074678','3VWDA2AJ4EM350125'].forEach(vin => {
    const normalized = vin.toUpperCase();
    if (globalVins.has(normalized)) { duplicateCount += 1; return; }
    if (remaining <= 0) { overCapCount += 1; return; }
    ffVehicles[bId].push({
      id:Date.now()+Math.random(),vin:normalized,ymm:'DOT Fleet Vehicle',cls:'MD',telematics:'Standard',vehicleName:'',plate:'',
      shippingId:form.shipAddressId || '',
      shippingContactId:form.shipContactId || '',
      installAddressId:(form.installSameAsShipping ? (form.shipAddressId || '') : (form.installAddressId || '')),
      installContactId:(form.installSameAsShipping ? (form.shipContactId || '') : (form.installContactId || '')),
      isEmergency: false, hasWheelchairLift: false, masterSwitchOff: false, hasCompetitorDevice: false,
    });
    globalVins.add(normalized);
    remaining -= 1;
  });
  if (duplicateCount > 0) alert(`${duplicateCount} duplicate VIN(s) were ignored.`);
  if (overCapCount > 0) alert(`${overCapCount} vehicle(s) were ignored due to solution quantity cap.`);
  ffDot=''; renderFF();
}

function ffRemoveVehicle(bId,vId) { ffVehicles[bId]=ffVehicles[bId].filter(v=>v.id!==vId); ffSelected=ffSelected.filter(id=>id!==vId); renderFF(); }

function ffUpdateVeh(bId,vId,f,v) { ffVehicles[bId]=ffVehicles[bId].map(vh=>String(vh.id)===String(vId)?{...vh,[f]:v}:vh); }

function ffToggleSel(vId,checked) { const sid=String(vId); ffSelected=checked?[...new Set([...ffSelected,sid])]:ffSelected.filter(id=>id!==sid); renderFFContent(); }

function ffToggleAll(bId,checked) {
  const ids=ffVehicles[bId].map(v=>String(v.id));
  ffSelected=checked?[...new Set([...ffSelected,...ids])]:ffSelected.filter(id=>!ids.includes(id));
  renderFFContent();
}

function ffToggleFiltered(bId, checked) {
  const bv = ffVehicles[bId] || [];
  const s = (ffSearch||'').toLowerCase();
  const filteredIds = bv.filter(v => !s || (v.vin||'').toLowerCase().includes(s)||(v.ymm||'').toLowerCase().includes(s)||(v.vehicleName||'').toLowerCase().includes(s)).map(v=>String(v.id));
  ffSelected = checked ? [...new Set([...ffSelected,...filteredIds])] : ffSelected.filter(id=>!filteredIds.includes(id));
  renderFFContent();
}

function ffAddDotSelected(bId) {
  const existing = getGlobalVinSet();
  const toAdd = FF_DOT_FLEET_MOCK.filter(v => ffDotSelected.includes(v.vin) && !existing.has(v.vin));
  if (!ffVehicles[bId]) ffVehicles[bId] = [];
  const bundle = getBundles().find(b => String(b.id) === String(bId));
  const form = getFFBundleForm(bId);
  const qtyCap = getEffectiveBundleQtyCap(bId);
  let remaining = Math.max(0, qtyCap - ffVehicles[bId].length);
  toAdd.forEach(v => {
    if (remaining <= 0) return;
    const telem = detectTelematics(v.make, v.year);
    ffVehicles[bId].push({
      id: Date.now()+Math.random(), vin: v.vin, ymm: v.ymm, year: v.year, make: v.make, cls: v.cls, telematics: telem,
      vehicleName:'', plate:'',
      installType: form.installType || 'vmi',
      shippingId: form.shipAddressId || '',
      shippingContactId: form.shipContactId || '',
      installAddressId: (form.installSameAsShipping ? (form.shipAddressId || '') : (form.installAddressId || '')),
      installContactId: (form.installSameAsShipping ? (form.shipContactId || '') : (form.installContactId || '')),
      activationContact:'', waveId:null,
      isEmergency:false, hasWheelchairLift:false, masterSwitchOff:false, hasCompetitorDevice:false,
    });
    remaining -= 1;
  });
  ffDotSelected = [];
  renderFFContent();
}

function ffCopyShipping(bId,vId) { ffVehicles[bId]=ffVehicles[bId].map(v=>v.id===vId?{...v,installAddressId:v.shippingId,installContactId:v.shippingContactId}:v); renderFFContent(); }

function ffVehicleDrop(bId,vId,f,val,tab) {
  if (val==='ADD_NEW') { ffGoToAddresses(true); return; }
  ffVehicles[bId]=ffVehicles[bId].map(v=>v.id===vId?{...v,[f]:val}:v); renderFFContent();
}

function ffBulkField(f,val,tab) {
  if (val==='ADD_NEW') { ffGoToAddresses(true); return; }
  ffBulkF[f]=val; renderFFContent();
}

function ffApplyBulk(bId) {
  ffVehicles[bId]=ffVehicles[bId].map(v=>{
    if (!ffSelected.includes(String(v.id))) return v;
    const u={};
    if (ffBulkType==='shipping') {
      if(ffBulkF.shippingId) u.shippingId=ffBulkF.shippingId;
      if(ffBulkF.shippingContactId) u.shippingContactId=ffBulkF.shippingContactId;
      if(ffBulkF.sameAsShipping){u.installAddressId=u.shippingId||v.shippingId;u.installContactId=u.shippingContactId||v.shippingContactId;}
    } else if(ffBulkType==='installation'){
      if(ffBulkF.installAddressId) u.installAddressId=ffBulkF.installAddressId;
      if(ffBulkF.installContactId) u.installContactId=ffBulkF.installContactId;
    } else if(ffBulkType==='wave'){
      u.waveId = ffBulkF.waveId ? Number(ffBulkF.waveId) : null;
    } else if(ffBulkType==='attributes'){
      u.isEmergency = ffBulkF.isEmergency;
      u.hasWheelchairLift = ffBulkF.hasWheelchairLift;
      u.masterSwitchOff = ffBulkF.masterSwitchOff;
      u.hasCompetitorDevice = ffBulkF.hasCompetitorDevice;
    } else if(ffBulkType==='installtype' && ffBulkF.installType){
      u.installType = ffBulkF.installType;
    }
    return{...v,...u};
  });
  ffSelected=[]; renderFF();
}

function ffAddWave(bId) {
  if (!ffWaves[bId]) ffWaves[bId] = [];
  const n = ffWaves[bId].length + 1;
  ffWaves[bId].push({ id: Date.now(), name: `Wave ${n}`, targetDate: '', vehicleIds: [] });
  renderFFContent();
}

function ffRemoveWave(bId, wId) {
  ffWaves[bId] = (ffWaves[bId] || []).filter(w => w.id !== Number(wId));
  (ffVehicles[bId] || []).forEach(v => { if (String(v.waveId) === String(wId)) v.waveId = null; });
  renderFF();
}

function ffUpdateWave(bId, wId, field, val) {
  const w = (ffWaves[bId] || []).find(x => x.id === Number(wId));
  if (w) w[field] = val;
}

function ffAssignVehicleWave(bId, vId, wId) {
  ffVehicles[bId] = ffVehicles[bId].map(v => v.id === vId ? {...v, waveId: wId ? Number(wId) : null} : v);
  renderFFContent();
}

function submitFulfillmentToOps() {
  const bundles = getBundles();
  // Validate: at least one vehicle per bundle
  const missingVehicles = bundles.filter(b => (ffVehicles[b.id] || []).length === 0);
  if (missingVehicles.length > 0) {
    alert(`Please add vehicles for: ${missingVehicles.map(b => b.coreName).join(', ')}`);
    return;
  }

  proposalData.fulfillmentSubmitted = true;
  proposalData.fulfillmentSubmittedDate = new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  logProposalEvent('Fulfillment submitted', 'Fulfillment configuration submitted to Ops.');

  // Serialize snapshot
  if (!proposalData.fulfillmentSnapshot) {
    proposalData.fulfillmentSnapshot = {
      addresses: ffAddresses.filter(a => a.saved),
      contacts:  ffContacts.filter(c => c.saved),
      bundleForms: JSON.parse(JSON.stringify(ffBundleForms)),
      waves: JSON.parse(JSON.stringify(ffWaves)),
    };
  }

  closeFulfillmentModal();
  if (typeof showSuccessBanner === 'function') showSuccessBanner('Fulfillment submitted to Ops', 'Your fulfillment configuration has been sent. The team will follow up shortly.');
  if (typeof updateFulfillmentBtn === 'function') updateFulfillmentBtn();
  if (typeof updateDealResultFulfillmentCta === 'function') updateDealResultFulfillmentCta();
}

function ffAmendFulfillment() {
  if (!confirm('Re-opening will allow you to edit the fulfillment configuration. Changes may require re-submission. Continue?')) return;
  proposalData.fulfillmentSubmitted = false;
  proposalData.fulfillmentSnapshot = null;
  renderFFContent();
}

function saveFulfillmentConfig() {
  const totalVehicles = Object.values(ffVehicles).reduce((sum, arr) => sum + arr.length, 0);
  const savedAddrs = ffAddresses.filter(a => a.saved).length;

  if (savedAddrs === 0 && totalVehicles === 0) {
    alert('Please add at least one address and some vehicles to continue.');
    return;
  }

  // Show syncing state  
  const saveBtn = document.querySelector('.fulfillment-footer .btn--primary');
  if (saveBtn) { saveBtn.textContent = 'Syncing...'; saveBtn.disabled = true; }

  setTimeout(() => {
    const badge = document.getElementById('account-badge');
    if (badge) { badge.className = 'vds-badge vds-badge-green badge-ready'; badge.textContent = 'Account ready'; }
    const banner = document.getElementById('warning-banner');
    if (banner) { banner.classList.add('hidden'); const body = document.getElementById('vc-body'); if(body) body.classList.remove('has-banner'); }
    // Serialize fulfillment data snapshot into proposalData for downstream use
    if (!proposalData.fulfillmentSnapshot) {
      proposalData.fulfillmentSnapshot = {
        addresses: ffAddresses.filter(a => a.saved),
        contacts:  ffContacts.filter(c => c.saved),
        bundleForms: JSON.parse(JSON.stringify(ffBundleForms)),
        waves: JSON.parse(JSON.stringify(ffWaves)),
      };
    }
    closeFulfillmentModal();
    if (typeof showSuccessBanner === 'function') showSuccessBanner('Fulfillment configured', 'Addresses and vehicles synchronized successfully.');
    if (saveBtn) { saveBtn.textContent = 'Save Configuration'; saveBtn.disabled = false; }
    if (typeof updateFulfillmentBtn === 'function') updateFulfillmentBtn();
  }, 1200);
}

function addMockLocation() { ffAddresses.push({id:Date.now(),saved:true,name:'Warehouse B · 456 Supply Dr, Austin TX 73301',addr1:'456 Supply Dr',addr2:'',city:'Austin',state:'TX',zip:'73301',country:'United States'}); openFulfillmentModal(); }

function addMockContact() { ffContacts.push({id:Date.now(),saved:true,name:'Mark Sloan',phone:'+1 555 111 2222',email:'mark@client.com'}); openFulfillmentModal(); }

function addMockVin() { ffAddYMM('default'); }

function deleteFulfillmentItem() {}

function renderFulfillmentTables() {}

function isFulfillmentComplete() {
  // All bundles must have at least 1 vehicle and required assignments.
  // Non-powered assets only require shipping + contact + vehicle name.
  const bundles = getBundles();
  if (!bundles || bundles.length === 0) return false;
  return bundles.every(b => {
    const bv = ffVehicles[b.id] || [];
    const requiresInstall = bundleRequiresInstallation(b);
    return bv.length > 0 && bv.every(v => {
      const hasShipping = v.shippingId && v.shippingContactId && v.vehicleName;
      if (!hasShipping) return false;
      if (!requiresInstall) return true;
      return v.installAddressId && v.installContactId;
    });
  });
}

function getFulfillmentProgressPercent() {
  const bundles = getBundles();
  if (!bundles || bundles.length === 0) return 10;

  let totalRequired = 0;
  let totalAdded = 0;
  let totalReady = 0;

  bundles.forEach((b) => {
    const qty = Math.max(0, Number(b.qty) || 0);
    if (qty === 0) return;
    totalRequired += qty;
    const bv = ffVehicles[b.id] || [];
    totalAdded += Math.min(bv.length, qty);
    const readyCount = bv.filter((v) => isVehicleReadyForBundle(v, b)).length;
    totalReady += Math.min(readyCount, qty);
  });

  if (totalRequired === 0) return 10;
  if (isFulfillmentComplete()) return 100;

  // Weighted progress: adding vehicles moves progress, fully configured vehicles move it faster.
  const weightedRatio = ((totalAdded * 0.55) + (totalReady * 0.45)) / totalRequired;
  const pct = Math.round(weightedRatio * 100);
  return Math.max(10, Math.min(99, pct));
}

function hasAnyFulfillmentVehicle() {
  const bundles = getBundles();
  if (!bundles || bundles.length === 0) return false;
  return bundles.some((b) => {
    const bv = ffVehicles[b.id] || [];
    return bv.length > 0;
  });
}
