/* ============================================================================
   Valu Cal — shared UI components (vanilla, no build step, works on file://)
   ----------------------------------------------------------------------------
   Every component is a plain function: props (variables) in → HTML string out.
   No access to any flow's globals (options, proposalData, …): each flow keeps
   its own pricing / gating logic and passes the result in as props.
   Styles live in assets-shared/css/shared-components.css.
   Catalog + live variants: ValuCal-MSA/componentization/component-library.html
   Started 2026-10-06 (componentization, batch 1: Solution row family).
   Rule: when the Design System has the piece (badge, button, select…), use
   it as is — custom components only for what VDS doesn't cover.
   ========================================================================== */
(function (global) {
  'use strict';

  const VC = global.VC || {};

  // Joins the truthy parts of a class list.
  function cx() {
    return Array.prototype.slice.call(arguments).filter(Boolean).join(' ');
  }

  function escapeAttr(value) {
    return String(value == null ? '' : value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/"/g, '&quot;');
  }

  VC.setNavigationDrawerOpen = function setNavigationDrawerOpen(open, ids) {
    ids = ids || {};
    const drawer = document.getElementById(ids.drawerId || 'sidebar');
    const overlay = document.getElementById(ids.overlayId || 'sidebar-overlay');
    if (!drawer || !overlay) return;
    drawer.classList.toggle('active', !!open);
    overlay.classList.toggle('active', !!open);
    drawer.setAttribute('aria-hidden', String(!open));
    overlay.setAttribute('aria-hidden', String(!open));
    document.body.style.overflow = open ? 'hidden' : '';
  };

  VC.navigationItem = function navigationItem(props) {
    props = props || {};
    const active = !!props.active;
    return `<a href="${escapeAttr(props.href || '#')}" class="sidebar-item${active ? ' active' : ''}"${active ? ' aria-current="page"' : ''}${props.onClick ? ` onclick="${escapeAttr(props.onClick)}"` : ''}>${escapeAttr(props.label)}</a>`;
  };

  VC.navigationDrawer = function navigationDrawer(props) {
    props = props || {};
    const items = props.items || [
      { label: 'Home', href: '#', active: true },
      { label: 'Resources', href: '#', onClick: 'openResourcesPage(event)' },
      { label: 'Case studies', href: '#', onClick: 'openCaseStudiesPage(event)' },
    ];
    const closeHandler = escapeAttr(props.onClose !== undefined ? props.onClose : (props.preview ? '' : 'toggleSidebar(false)'));
    const closeAttrs = closeHandler ? ` onclick="${closeHandler}"` : '';
    const isOpen = !!props.open;
    const overlayId = escapeAttr(props.overlayId || 'sidebar-overlay');
    const drawerId = escapeAttr(props.drawerId || 'sidebar');
    const markup = `<div id="${overlayId}" class="sidebar-overlay${isOpen ? ' active' : ''}" aria-hidden="${isOpen ? 'false' : 'true'}"${closeAttrs}></div>
<aside id="${drawerId}" class="sidebar${isOpen ? ' active' : ''}" aria-label="Main menu" aria-hidden="${isOpen ? 'false' : 'true'}">
  <div class="sidebar-header">
    <div class="sidebar-logo-group">
      <div class="sidebar-logo"><h2>valu</h2><span>Cal</span></div>
      <div class="sidebar-subtitle">Pricing Engine</div>
    </div>
    <button type="button" class="btn-icon btn-icon--ghost-vds btn-icon--vds-small" aria-label="Close main menu"${closeAttrs}>
      <span class="material-symbols-outlined" aria-hidden="true">close</span>
    </button>
  </div>
  <nav class="sidebar-nav" aria-label="Main navigation">${items.map(VC.navigationItem).join('')}</nav>
</aside>`;
    return props.preview ? `<div class="vc-main-menu-preview">${markup}</div>` : markup;
  };

  /* ---- Badge (VDS) --------------------------------------------------------
     Not a custom component: discount badges use the Design System badge
     (.badge + .badge--green / --blue from design-system.css), the
     same one Initial Sales' option cards already use. This helper only
     writes that markup.  props: { text, tone: 'green' | 'blue' }
       green → Account discount   blue → Promotion */
  function vdsBadge(props) {
    return `<span class="badge badge--${props.tone || 'green'}">${props.text}</span>`;
  }

  /* ---- Section strip -------------------------------------------------------
     Header strip inside an option card ("Solutions (N)", "Account Level
     Features (N)").
     props: { icon, title, count, rightHtml, follows }
       count     → shown as "(N)" when it's a number
       rightHtml → optional content on the right (e.g. a link)
       follows   → true when another section sits above it in the same card
                   (adds the top divider/spacing)                           */
  VC.sectionStrip = function sectionStrip(props) {
    const countText = typeof props.count === 'number' ? ` (${props.count})` : '';
    const iconHtml = props.icon ? `<span class="material-symbols-outlined bundles-label-icon" aria-hidden="true">${props.icon}</span>` : '';
    return `<div class="${cx('bundles-label', props.follows && 'bundles-label--section')}">
      <span class="bundles-label-left">${iconHtml}${iconHtml ? ' ' : ''}${props.title}${countText}</span>
      ${props.rightHtml ? `<div class="bundles-label-right">${props.rightHtml}</div>` : ''}
    </div>`;
  };

  /* ---- Data table header -----------------------------------------------
     Shared column heading renderer; column order and optional column classes
     remain configurable per flow. props: { columns: [{ label, className }] } */
  VC.dataTableHead = function dataTableHead(props) {
    props = props || {};
    const escapeHtml = value => String(value == null ? '' : value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
    const columns = Array.isArray(props.columns) ? props.columns : [];
    const head = columns.map(column => `<th class="table-header-cell${column.className ? ` ${escapeAttr(column.className)}` : ''}">${escapeHtml(column.label)}</th>`).join('');
    return `<tr>${head}</tr>`;
  };

  /* ---- Data table shell -------------------------------------------------
     Shared table shell for fully rendered tables. Flows with static/dynamic
     body markup can use dataTableHead and retain their own tbody. */
  VC.dataTable = function dataTable(props) {
    props = props || {};
    const tableClass = props.className || 'data-table';
    const bodyId = props.id ? ` id="${escapeAttr(props.id)}"` : '';
    const ariaLabel = props.ariaLabel ? ` aria-label="${escapeAttr(props.ariaLabel)}"` : '';
    const rows = Array.isArray(props.rowsHtml) ? props.rowsHtml.join('') : (props.rowsHtml || '');
    return `<table class="${escapeAttr(tableClass)}"${ariaLabel}><thead>${VC.dataTableHead({ columns: props.columns })}</thead><tbody${bodyId}>${rows}</tbody></table>`;
  };

  VC.QL_STATUS = {
    draft: { label: 'Draft', badge: 'badge--gray-low', doc: null },
    sent: { label: 'Proposal sent', badge: 'badge--blue', doc: 'pdf' },
    approval: { label: 'Pending approval', badge: 'badge--yellow', doc: 'pdf' },
    'contract-review': { label: 'Contract review', badge: 'badge--blue', doc: 'contract' },
    'awaiting-sig': { label: 'Awaiting signature', badge: 'badge--yellow', doc: 'contract' },
    payment: { label: 'Payment setup pending', badge: 'badge--yellow', doc: 'contract' },
    svt: { label: 'SVT validation pending', badge: 'badge--yellow', doc: 'contract' },
    signed: { label: 'Contract signed', badge: 'badge--green', doc: 'contract' },
    dead: { label: 'Dead', badge: 'badge--black', doc: 'pdf' },
  };
  VC.QL_STATUS_ACTIONS = {
    draft: ['clone', 'dead'], sent: ['clone', 'dead'], approval: ['clone', 'cancel-approval', 'dead'],
    'contract-review': ['clone', 'view-contract', 'send-portal', 'modify', 'dead'],
    'awaiting-sig': ['clone', 'view-contract', 'resend-portal', 'modify', 'dead'],
    payment: ['clone', 'view-contract'], svt: ['clone', 'view-contract'],
    signed: ['clone', 'view-contract'], dead: ['clone'],
  };
  VC.QL_ACTION_LABELS = {
    clone: 'Clone', dead: 'Mark as dead', 'cancel-approval': 'Cancel approval request',
    modify: 'Modify proposal', 'view-contract': 'View contract',
    'resend-portal': 'Resend Purchase Portal link', 'send-portal': 'Send Purchase Portal link',
  };

  VC.proposalTableRows = function proposalTableRows(props) {
    props = props || {};
    const html = value => String(value == null ? '' : value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
    const money = value => value == null ? '—' : '$' + Math.round(value).toLocaleString('en-US');
    return (props.proposals || []).map((proposal, index) => {
      const status = VC.QL_STATUS[proposal.status];
      if (!status) return '';
      const menuId = `ql-menu-${index + 1}`;
      const shown = proposal.selected != null ? proposal.selected : ((props.viewedOptions || {})[proposal.id] || 0);
      const options = proposal.options || [];
      const values = options[shown] || options[0] || [0, 0, null];
      const optionCell = proposal.selected != null || options.length < 2
        ? `Option ${shown + 1}`
        : `<select class="select select--small" data-vc-dropdown aria-label="Option shown for proposal ${html(proposal.id)}" onclick="event.stopPropagation()" onchange="${escapeAttr(props.onOptionChange && props.onOptionChange(proposal))}">${options.map((_, optionIndex) => `<option value="${optionIndex}"${optionIndex === shown ? ' selected' : ''}>Option ${optionIndex + 1}</option>`).join('')}</select>`;
      const documentLabel = status.doc === 'contract' ? proposal.contract : status.doc === 'pdf' ? 'Proposal PDF' : status.doc === 'quote' ? proposal.quote : '';
      const documentAction = documentLabel && props.onDocument && props.onDocument(proposal, status.doc);
      const documentHtml = !documentLabel ? '' : documentAction
        ? `<div class="text-body-small ql-cell-ref"><a href="#" class="record-link" onclick="event.preventDefault(); event.stopPropagation(); ${escapeAttr(documentAction)}">${html(documentLabel)}</a></div>`
        : `<div class="text-body-small ql-cell-ref">${html(documentLabel)}</div>`;
      const badge = proposal.status === 'dead' ? `<span class="badge badge--black badge__tooltip-wrap">Dead<span class="badge__tooltip-icon material-symbols-outlined" aria-hidden="true">info</span><div class="badge__tooltip-popup"><strong>Closure reason</strong><div>${html(proposal.deadReason || '')}</div></div></span>` : `<span class="badge ${status.badge}">${status.label}</span>`;
      const items = (VC.QL_STATUS_ACTIONS[proposal.status] || []).flatMap(action => [
        ...(action === 'dead' ? [{ type: 'divider' }] : []),
        { id: action === 'clone' ? `ql-clone-${index + 1}` : undefined, label: VC.QL_ACTION_LABELS[action], danger: action === 'dead', disabled: !(props.onAction && props.onAction(proposal, action, menuId)), onClick: props.onAction && props.onAction(proposal, action, menuId) },
      ]);
      const menu = VC.kebabMenu({ id: `ql-actions-${index + 1}`, panelId: menuId, onToggle: props.onToggle ? props.onToggle(proposal, menuId) : `toggleQlMenu(event, '${menuId}')`, items });
      const onOpen = props.onOpen && props.onOpen(proposal);
      return `<tr class="ql-table-row" data-proposal-id="${html(proposal.id)}" data-status="${html(proposal.status)}"${onOpen ? ` title="Open proposal" onclick="${escapeAttr(onOpen)}"` : ''}>
        <td class="table-body-cell">${html(proposal.id)}</td><td class="table-body-cell">${html(proposal.type)}</td>
        <td class="table-body-cell">${badge}</td><td class="table-body-cell">${html(proposal.created)}<div class="text-body-small ql-cell-ref">Modified ${html(proposal.modified)}</div></td>
        <td class="table-body-cell">${html(proposal.owner)}</td><td class="table-body-cell">${html(proposal.opp)}${documentHtml}</td>
        ${props.showContractAccount ? `<td class="table-body-cell">${html(proposal.contractAccount || '')}</td>` : ''}
        <td class="table-body-cell" onclick="event.stopPropagation()">${optionCell}</td>
        <td class="table-body-cell ql-col-num" data-ql="qty">${html(values[0])}</td><td class="table-body-cell ql-col-num" data-ql="standard">${money(values[1])}</td><td class="table-body-cell ql-col-num" data-ql="promo">${money(values[2])}</td>
        <td class="table-body-cell ql-col-actions" onclick="event.stopPropagation()"><div class="ql-actions-wrap">${menu}</div></td>
      </tr>`;
    }).join('');
  };

  /* ---- Stat row ------------------------------------------------------------
     Shared bundle-stat grid. Flows calculate values and select the layout.
     props: { cells: [{ label, value, unit, strike, note, valueHtml,
                       noteHtml, className }], className }
       valueHtml / noteHtml are trusted flow-rendered markup for badges,
       discount strikes and Capex notes; all pricing decisions stay local. */
  VC.statRow = function statRow(props) {
    props = props || {};
    const cells = props.cells || [];
    const className = cx('bundle-stat-row', props.className);
    const rowClass = cx(className, cells.length === 4 && !className.split(/\s+/).includes('bundle-stat-row--4col') && 'bundle-stat-row--4col');
    return `<div class="${rowClass}">
      ${cells.map(cell => `<div class="${cx('bundle-stat-cell', cell.className)}">
        <div class="bundle-stat-label">${cell.label}</div>
        <div class="bundle-stat-value">${cell.valueHtml !== undefined ? cell.valueHtml : `${cell.strike ? `<span class="bundle-stat-value-strike">${cell.strike}</span> ` : ''}${cell.value == null ? '' : cell.value}${cell.unit ? `<span>${cell.unit}</span>` : ''}`}</div>
        ${cell.noteHtml !== undefined ? cell.noteHtml : (cell.note ? `<div class="opt-totals-capex-note">${cell.note}</div>` : '')}
      </div>`).join('')}
    </div>`;
  };

  /* ---- Bundle row shell --------------------------------------------------
     Shared structure only; state, badges, metadata and stat-row content are
     prepared by each flow. Props are trusted flow-rendered HTML slots. */
  VC.bundleRow = function bundleRow(props) {
    props = props || {};
    return `<div class="${cx('bundle-row', props.className)}">
      <div class="bundle-row-top">
        ${props.actionsHtml || ''}
        <div class="bundle-row-header">${props.titleHtml || ''}${props.badgesHtml || ''}</div>
        ${props.metaHtml || ''}
      </div>
      <div class="bundle-row-bottom">${props.statRowHtml || ''}</div>
    </div>${props.afterHtml || ''}`;
  };

  /* ---- Account feature list ----------------------------------------------
     The content under the "Account Level Features (N)" strip: one line per
     account-configured feature, with a check and its price on the right.
     Uses the VDS checkbox (.checkbox / .checkbox__input / .checkbox__content).
     props: {
       items: [{ id, label, price, checked, onChange }],
         price    → already formatted (e.g. "$4.00")
         onChange → JS run on change; "this.checked" is the new value
     }
     Checked / unchecked is just the VDS checkbox's own state — no variants.                                                                      */
  VC.accountFeatureList = function accountFeatureList(props) {
    const items = props.items || [];
    return `<div class="account-feature-list">
      ${items.map(item => `<div class="account-feature-item">
        <label class="checkbox account-feature-check">
          <input type="checkbox" class="checkbox__input"${item.id ? ` id="${item.id}"` : ''}${item.checked ? ' checked' : ''}${item.onChange ? ` onchange="${item.onChange}"` : ''}>
          <span class="checkbox__content">${item.label}</span>
        </label>
        <span class="account-feature-price">${item.price}</span>
      </div>`).join('')}
    </div>`;
  };

  /* ---- Solution row --------------------------------------------------------
     Canonical renderer for a solution inside an option card. Flows own pricing
     and callbacks; semantic props cover common rows, while HTML slots keep rich
     legacy cases (plan metadata, custom stat cells) compatible.
     props: { name, eyebrow, badges, metaLines, actions, state, stats, afterHtml,
              className, titleHtml, badgesHtml, metaHtml, actionsHtml, statRowHtml } */
  VC.solutionRow = function solutionRow(props) {
    props = props || {};
    const state = props.state && props.state !== 'default' ? `bundle-row--${props.state.replace(/^bundle-row--/, '')}` : '';
    const actions = props.actions;
    const actionsHtml = props.actionsHtml != null ? props.actionsHtml : (actions ? `<div class="bundle-row-actions">
        ${actions.edit ? `<button type="button" class="btn-icon btn-icon--solid btn-icon--vds-small" title="Edit solution" aria-label="Edit solution" onclick="${actions.edit}"><span class="material-symbols-outlined" aria-hidden="true">edit</span></button>` : ''}
        ${actions.delete ? `<button type="button" class="btn-icon btn-icon--solid btn-icon--vds-small" title="Delete solution" aria-label="Delete solution" onclick="${actions.delete}"><span class="material-symbols-outlined" aria-hidden="true">delete</span></button>` : ''}
      </div>` : '');
    const badgesHtml = props.badgesHtml != null ? props.badgesHtml : (props.badges || []).map(vdsBadge).join('');
    const metaHtml = props.metaHtml != null ? props.metaHtml : (props.metaLines || []).map(line =>
      `<div class="bundle-feature-line">${line.label ? `<strong>${line.label}:</strong> ` : ''}${line.text}</div>`).join('');
    const titleHtml = props.titleHtml != null ? props.titleHtml : `<div class="bundle-row-title">
      ${props.eyebrow ? `<div class="bundle-row-eyebrow">${props.eyebrow}</div>` : ''}
      <div class="bundle-row-name">${props.name || ''}</div>
    </div>`;
    const statRowHtml = props.statRowHtml != null ? props.statRowHtml : VC.statRow(props.stats || { cells: [] });
    const actionsMode = props.actionsMode === 'hover' ? 'vc-solution-row--actions-hover' : '';
    return `<div class="${cx('bundle-row', 'vc-solution-row', state, actionsMode, props.className)}">
      <div class="bundle-row-top">
        <div class="bundle-row-header">
          ${titleHtml}
          <div class="vc-solution-row__tools">${badgesHtml ? `<div class="bundle-row-badges">${badgesHtml}</div>` : ''}${actionsHtml}</div>
        </div>
        ${metaHtml}
      </div>
      <div class="bundle-row-bottom">
        ${statRowHtml}
      </div>
    </div>${props.afterHtml || ''}`;
  };

  /* ---- Stage stepper ----------------------------------------------------
     Shared visual renderer for a linear workflow. Each flow owns the active
     stage and date values; this component only composes the cells.
      props: { activeStep, idPrefix?, steps: [{ num, label, date, milestones: [{ label, date }] }] } */
  VC.stageStepper = function stageStepper(props) {
    props = props || {};
    const steps = Array.isArray(props.steps) ? props.steps : [];
    const activeStep = Number(props.activeStep) || 1;
    const stepState = num => num < activeStep ? 'done' : num === activeStep ? 'active' : 'pending';
    const escapeHtml = value => String(value == null ? '' : value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
    const checkSvg = `<svg width="14" height="11" viewBox="0 0 14 11" fill="none">
      <path d="M1.5 5.5L5.5 9.5L12.5 1.5" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>`;
    const circle = (state, num) => state === 'done'
      ? `<div class="ns-circle done">${checkSvg}</div>`
      : state === 'active'
        ? `<div class="ns-circle active">${num}</div>`
        : `<div class="ns-circle pending">${num}</div>`;
    const chevron = (bgFill, borderColor) => `<div class="ns-chevron">
      <svg viewBox="0 0 12 72" fill="none" xmlns="http://www.w3.org/2000/svg" width="12" height="72" style="display:block;position:absolute;top:0;left:0;width:12px;height:72px;">
        <path d="M0 24L12 36L0 48Z" fill="${bgFill}"/>
        <path d="M0 0V24L12 36L0 48V72" stroke="${borderColor}" stroke-width="1" fill="none"/>
      </svg>
    </div>`;

    return steps.map((step, index) => {
      const state = stepState(step.num);
      const isFirst = index === 0;
      const isLast = index === steps.length - 1;
      const wrapClass = isFirst ? 'ns-wrap ns-first' : `ns-wrap ${state === 'pending' ? 'collapsed-phase' : 'active-phase'}`;
      const cellClass = `ns-cell ns-${state}${isLast ? ' ns-last' : ''}`;
      const cellStyle = isFirst ? '' : 'padding-left:6px;';
      const bgFill = state === 'active' ? '#F8F3E9' : (state === 'pending' ? '#F8F7F5' : '#fff');
      const milestones = Array.isArray(step.milestones) ? step.milestones : [];
      const tooltipId = `${props.idPrefix || 'stage-stepper'}-${step.num}-milestones`;
      const milestoneTooltip = state === 'done' && milestones.length ? `<button type="button" class="ns-info-wrap" aria-label="Show ${escapeHtml(step.label)} milestones" aria-describedby="${escapeHtml(tooltipId)}" onfocus="this.classList.add('is-open')" onblur="this.classList.remove('is-open')">
        <span class="material-symbols-outlined ns-info-icon" aria-hidden="true">info</span>
        <span class="ns-tooltip-card" id="${escapeHtml(tooltipId)}" role="tooltip">
          <span class="ns-tooltip-title">${escapeHtml(step.label)} milestones</span>
          <span class="ns-tooltip-body">${milestones.map(milestone => `<span class="ns-tooltip-row"><strong>${escapeHtml(milestone.label)}</strong>${milestone.date ? ` · ${escapeHtml(milestone.date)}` : ''}${milestone.description ? `<span class="ns-tooltip-description">${escapeHtml(milestone.description)}</span>` : ''}</span>`).join('')}</span>
        </span>
      </button>` : '';
      return `<div class="${wrapClass}" style="z-index:${4 - index};">
        <div class="${cellClass}" style="${cellStyle}">
          <div class="ns-content">
            ${circle(state, step.num)}
            <div class="ns-label ${state}">${step.label}</div>
            <div class="ns-date">${step.date || '--'}${milestoneTooltip}</div>
          </div>
        </div>
        ${!isLast ? chevron(bgFill, '#DDDAD4') : ''}
      </div>`;
    }).join('');
  };

  /* ---- Account context (custom molecule) -------------------------------
     Account icon, name and status badge. Stable IDs are kept for flow-local
     badge updates and click behavior.
    props: { accountName, subtitle, badgeText, onClick, triggerId, badgeId } */
  VC.accountContext = function accountContext(props) {
    props = props || {};
    const escapeHtml = value => String(value == null ? '' : value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
    const accountClick = props.onClick ? ` onclick="${escapeAttr(props.onClick)}"` : '';
    const accountKeyboard = props.onClick ? ' role="button" tabindex="0" onkeydown="if (event.key === \'Enter\' || event.key === \' \') { event.preventDefault(); this.click(); }"' : '';
    return `<div class="vc-header-right${props.onClick ? ' vc-header-right--interactive' : ''}" id="${escapeAttr(props.triggerId || 'account-status-trigger')}"${accountClick}${accountKeyboard}>
      <div class="vc-account-info">
        <div class="vc-account-heading-row">
          <div class="vc-account-icon"><span class="material-symbols-outlined" aria-hidden="true">domain</span></div>
          <div class="vc-account-heading">
            <div class="vc-account-name">${escapeHtml(props.accountName || '')}</div>
            <div id="${escapeAttr(props.subtitleId || 'account-subtitle')}" class="vc-account-subtitle${props.subtitle ? '' : ' hidden'}">${escapeHtml(props.subtitle || '')}</div>
          </div>
        </div>
        <div id="${escapeAttr(props.badgeId || 'account-badge')}" class="badge-pending">${escapeHtml(props.badgeText || '')}</div>
      </div>
      ${props.selectorHtml || ''}
    </div>`;
  };

  /* ---- Application header (organism) -----------------------------------
     Shared chrome; account data and click handlers remain flow-owned.
     props: { accountName, accountBadgeText, onMenuClick, onAccountClick,
              navHtml, preview } */
  VC.appHeader = function appHeader(props) {
    props = props || {};
    const menuClick = props.onMenuClick ? ` onclick="${escapeAttr(props.onMenuClick)}"` : '';
    return `<div class="vc-header${props.preview ? ' vc-header--preview' : ''}">
      <div class="vc-header-logo">
        <button type="button" class="btn-icon btn-icon--ghost-vds btn-icon--vds-small" aria-label="Open main menu"${menuClick}>
          <span class="material-symbols-outlined" aria-hidden="true">menu</span>
        </button>
        <div class="vc-logo-wrap">
          <div class="vc-logo-name">valu<em>Cal</em></div>
          <div class="vc-logo-sub">Pricing Engine</div>
        </div>
      </div>
      <div class="vc-nav" id="vc-nav">${props.navHtml || ''}</div>
      ${VC.accountContext({
        accountName: props.accountName,
        subtitle: props.accountSubtitle,
        badgeText: props.accountBadgeText,
        onClick: props.onAccountClick,
        selectorHtml: props.accountSelectorHtml,
      })}
    </div>`;
  };

  global.VC = VC;
})(window);

/* ── Kebab menu (custom molecule) ───────────────────────────────────────
  VC.kebabMenu({ id, panelId, label, triggerTitle, triggerIcon, open, align:'right'|'left', onToggle,
    items:[{ label, onClick, id, danger, disabled, hidden, title, selectable, selected }
            | { type:'label', label } | { type:'divider' }] })
   onToggle: inline JS string for the trigger (e.g. "toggleQlMenu(event, 3)"). */
(function () {
  function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;'); }
  function kebabMenu(p) {
    p = p || {};
    var items = (p.items || []).map(function (it) {
      if (it.type === 'divider') return '<div class="kebab-menu__divider" role="separator"></div>';
      if (it.type === 'label') return '<div class="kebab-menu__label">' + esc(it.label) + '</div>';
      var cls = 'kebab-menu__item' + (it.danger ? ' kebab-menu__item--danger' : '') + (it.selectable ? ' kebab-menu__item--selectable' : '') + (it.disabled ? ' is-disabled' : '') + (it.hidden ? ' hidden' : '');
      var role = it.selectable ? 'menuitemradio' : 'menuitem';
      var checked = it.selectable ? ' aria-checked="' + (!!it.selected) + '"' : '';
      var selectedMark = it.selected ? '<span class="material-symbols-outlined" aria-hidden="true">check</span>' : '';
      return '<button type="button" class="' + cls + '" role="' + role + '"' + checked + (it.id ? ' id="' + esc(it.id) + '"' : '') +
        (it.title ? ' title="' + esc(it.title) + '"' : '') + (it.disabled ? ' disabled aria-disabled="true"' : '') +
        (it.onClick ? ' onclick="' + esc(it.onClick) + '"' : '') + '><span>' + esc(it.label) + '</span>' + selectedMark + '</button>';
    }).join('');
      var panelId = p.panelId || (p.id ? p.id + '-panel' : '');
    var panelClassName = p.panelClassName ? ' ' + esc(p.panelClassName) : '';
    return '<div class="kebab-menu"' + (p.id ? ' id="' + esc(p.id) + '"' : '') + '>' +
      '<button type="button" class="btn-icon btn-icon--tonal btn-icon--vds-small" aria-label="' + esc(p.label || 'More actions') + '"' + (p.triggerTitle ? ' title="' + esc(p.triggerTitle) + '"' : '') + ' aria-haspopup="true" aria-expanded="' + (p.open ? 'true' : 'false') + '"' +
      (p.onToggle ? ' onclick="' + esc(p.onToggle) + '"' : '') + '><span class="material-symbols-outlined" aria-hidden="true">' + esc(p.triggerIcon || 'more_vert') + '</span></button>' +
      '<div class="kebab-menu__panel' + (p.align === 'left' ? ' kebab-menu__panel--left' : '') + (p.open ? '' : ' hidden') + panelClassName + '" role="menu"' + (panelId ? ' id="' + esc(panelId) + '"' : '') + '>' + items + '</div></div>';
  }
  window.VC = window.VC || {};
  window.VC.kebabMenu = kebabMenu;
})();

/* ── Account summary panel (custom organism) ──────────────────────────────
  VC.accountSummaryPanel({ headerTitle, actionsHtml, sections, layout })
  Flow-owned values/actions in; shared account/contract summary markup out.
  actionsHtml and section actionsHtml are trusted flow markup so menu handlers stay local. */
(function () {
  function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
  function accountSummaryPanel(p) {
    p = p || {};
    var headerTitle = p.headerTitle ? '<div class="vc-account-summary__header-title">' + esc(p.headerTitle) + '</div>' : '';
    var actions = p.actionsHtml ? '<div class="vc-account-summary__actions">' + p.actionsHtml + '</div>' : '';
    var header = headerTitle || actions ? '<div class="vc-account-summary__header">' + headerTitle + actions + '</div>' : '';
    var layoutClass = p.layout === 'split' ? ' vc-account-summary--split' : '';
    var sections = (p.sections || []).map(function (section) {
      var sectionTitle = section.title ? '<div class="vc-account-summary__section-title">' + esc(section.title) + (section.badge && section.badge.text ? '<span class="badge badge--' + (['green', 'blue', 'yellow'].indexOf(section.badge.tone) >= 0 ? section.badge.tone : 'blue') + '">' + esc(section.badge.text) + '</span>' : '') + '</div>' : '';
      var sectionActions = section.actionsHtml ? '<div class="vc-account-summary__section-actions">' + section.actionsHtml + '</div>' : '';
      var title = sectionTitle || sectionActions ? '<div class="vc-account-summary__section-heading">' + sectionTitle + sectionActions + '</div>' : '';
      var metrics = (section.metrics || []).map(function (metric) {
        var minWidth = Number(metric.minWidth);
        var widthStyle = Number.isFinite(minWidth) && minWidth > 0 ? ' style="min-width:' + minWidth + 'px"' : '';
        return '<div class="vc-account-summary__metric"' + widthStyle + '><div class="vc-account-summary__label">' + esc(metric.label) + '</div><div class="vc-account-summary__value">' + esc(metric.value) + '</div></div>';
      }).join('');
      return '<div class="vc-account-summary__section' + (section.dividerBefore ? ' vc-account-summary__section--divided' : '') + '">' + title + '<div class="vc-account-summary__metrics">' + metrics + '</div></div>';
    }).join('');
    return '<div class="vc-account-summary' + layoutClass + '">' + header + sections + '</div>';
  }
  window.VC = window.VC || {};
  window.VC.accountSummaryPanel = accountSummaryPanel;
})();

/* ── Page header (custom organism) ----------------------------------------
  VC.pageHeader({ title, subtitle, action, inset })
  The flow supplies its action label, id, button class and click handler. */
(function () {
  function escHtml(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char])); }
  function escAttr(s) { return escHtml(s); }
  function pageHeader(p) {
    p = p || {};
    var action = p.action || null;
    var actionHtml = action && action.label ? '<div class="vc-page-header__actions"><button type="' + escAttr(action.type || 'button') + '"' + (action.id ? ' id="' + escAttr(action.id) + '"' : '') + ' class="' + escAttr(action.className || 'btn btn--primary btn--medium') + '"' + (action.disabled ? ' disabled' : '') + (action.onClick ? ' onclick="' + escAttr(action.onClick) + '"' : '') + '>' + escHtml(action.label) + '</button></div>' : '';
    return '<header class="vc-page-header' + (p.inset ? ' vc-page-header--inset' : '') + '"><div class="vc-page-header__main"><h2 class="vc-page-header__title">' + escHtml(p.title || '') + '</h2>' + (p.subtitle ? '<p class="vc-page-header__subtitle">' + escHtml(p.subtitle) + '</p>' : '') + '</div>' + actionHtml + '</header>';
  }
  window.VC = window.VC || {};
  window.VC.pageHeader = pageHeader;
})();

/* ── Option card header (custom molecule) ---------------------------------
  VC.optionCardHeader({ titleHtml, beforeActionsHtml, actionsHtml, actionsHidden })
  Flow-owned title/controls/actions in; shared option-card header shell out. */
(function () {
  function optionCardHeader(p) {
    p = p || {};
    var actionsClass = 'option-card-header-actions' + (p.actionsHidden ? ' option-card-header-actions--hidden' : '');
    return '<div class="option-card-header">' + (p.titleHtml || '') + (p.beforeActionsHtml || '') + '<div class="' + actionsClass + '">' + (p.actionsHtml || '') + '</div></div>';
  }
  window.VC = window.VC || {};
  window.VC.optionCardHeader = optionCardHeader;
})();

/* ── Option totals row (custom molecule) ----------------------------------
  VC.optionTotalsRow({ cells, className })
  Flows calculate labels/values and choose the variant; this only composes
  the shared totals grid. valueHtml/noteHtml are trusted flow-rendered markup. */
(function () {
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char])); }
  function optionTotalsRow(p) {
    p = p || {};
    var cells = Array.isArray(p.cells) ? p.cells : [];
    var rowClass = 'opt-totals-row' + (p.className ? ' ' + esc(p.className) : '');
    var cellsHtml = cells.map(function (cell) {
      var cellClass = 'opt-totals-cell' + (cell.className ? ' ' + esc(cell.className) : '');
      var valueClass = 'opt-totals-value' + (cell.valueClassName ? ' ' + esc(cell.valueClassName) : '');
      return '<div class="' + cellClass + '"><div class="opt-totals-label">' + esc(cell.label) + '</div><div class="' + valueClass + '">' + (cell.valueHtml || '') + '</div>' + (cell.noteHtml || '') + '</div>';
    }).join('');
    return '<div class="' + rowClass + '">' + cellsHtml + '</div>';
  }
  window.VC = window.VC || {};
  window.VC.optionTotalsRow = optionTotalsRow;
})();

/* ── Add-on accordion (custom molecule) ─────────────────────────────────
   VC.accordion({ id, title, count, open, bodyHtml, onToggle })
   count: number of selected items (badge hidden when 0 / empty).
   onToggle: inline JS; default toggles .is-open on the wrapper. */
(function () {
  function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;'); }
  window.VC = window.VC || {};
  window.VC.accordion = function accordion(p) {
    p = p || {};
    var toggle = p.onToggle || "var a=this.closest('.vc-accordion');a.classList.toggle('is-open');this.setAttribute('aria-expanded',a.classList.contains('is-open'))";
    var count = p.count ? '<span class="badge vc-accordion__count">' + esc(p.count) + '</span>' : '';
    return '<div class="vc-accordion' + (p.open ? ' is-open' : '') + '"' + (p.id ? ' id="' + esc(p.id) + '"' : '') + '>' +
      '<button type="button" class="vc-accordion__header" aria-expanded="' + (p.open ? 'true' : 'false') + '" onclick="' + esc(toggle) + '">' +
      '<span class="vc-accordion__title">' + esc(p.title) + '</span>' +
      '<span class="vc-accordion__right">' + count + '<span class="material-symbols-outlined vc-accordion__chevron" aria-hidden="true">expand_more</span></span></button>' +
      '<div class="vc-accordion__body">' + (p.bodyHtml || '') + '</div></div>';
  };
})();

/* ── Date picker (custom atom) ──────────────────────────────────────────
   VC.initDatePickers(root, { inline })
   Attaches the Initial Sales calendar popup (flatpickr themed to VDS) to every
   input[type="date"] with class .input / .vds-input / .proposal-date-input inside root.
   Keeps the input's value as Y-m-d and fires 'input' + 'change' on pick.
   The popup opens aligned to the field's right edge when there's no room on the right,
   so it never gets clipped. Needs flatpickr loaded on the page. */
(function () {
  var MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December'];
  var WEEK_SHORT = ['S','M','T','W','T','F','S'];
  var WEEK_LONG = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
  function setTitle(fp) {
    var el = fp.calendarContainer && fp.calendarContainer.querySelector('.vc-fp-title');
    if (el) el.textContent = MONTHS[fp.currentMonth] + ' ' + fp.currentYear;
  }
  window.VC = window.VC || {};
  window.VC.initDatePickers = function initDatePickers(root, opts) {
    if (typeof window.flatpickr !== 'function') return [];
    root = root || document; opts = opts || {};
    var inputs = root.querySelectorAll('input[type="date"].input, input[type="date"].vds-input, input[type="date"].proposal-date-input');
    var out = [];
    Array.prototype.forEach.call(inputs, function (input) {
      if (input._flatpickr) { out.push(input._flatpickr); return; }
      out.push(window.flatpickr(input, {
        dateFormat: 'Y-m-d',
        allowInput: true,
        disableMobile: true,
        inline: !!opts.inline,
        locale: { weekdays: { shorthand: WEEK_SHORT, longhand: WEEK_LONG } },
        onReady: function (_, __, fp) {
          var months = fp.calendarContainer.querySelector('.flatpickr-months');
          if (!months) return;
          var current = months.querySelector('.flatpickr-current-month');
          if (current) current.style.visibility = 'hidden';
          var title = document.createElement('div');
          title.className = 'vc-fp-title';
          months.style.position = 'relative';
          months.appendChild(title);
          setTitle(fp);
        },
        onMonthChange: function (_, __, fp) { setTitle(fp); },
        onYearChange: function (_, __, fp) { setTitle(fp); },
        onOpen: function (_, __, fp) {
          var v = input.value;
          if (v && (!fp.selectedDates.length || fp.formatDate(fp.selectedDates[0], 'Y-m-d') !== v)) fp.setDate(v, false);
          // Keep the popup inside the viewport: align right when the field is near the right edge.
          var rect = input.getBoundingClientRect();
          var calW = (fp.calendarContainer && fp.calendarContainer.offsetWidth) || 320;
          fp.config.position = (rect.left + calW > window.innerWidth - 8) ? 'auto right' : 'auto left';
          if (typeof fp._positionCalendar === 'function') fp._positionCalendar();
        },
        onChange: function (_, dateStr) {
          input.value = dateStr;
          input.dispatchEvent(new Event('input', { bubbles: true }));
          input.dispatchEvent(new Event('change', { bubbles: true }));
        }
      }));
    });
    return out;
  };
})();

/* ── Selectable option row · Stage loader · Progress checklist (2026-10-06) ── */
(function () {
  function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;'); }
  var SPINNER = '<div class="loader"><svg class="loader__spinner" viewBox="0 0 64 64" fill="none" aria-hidden="true"><circle class="loader__track" cx="32" cy="32" r="28" stroke-width="6" stroke-linecap="round"/><path class="loader__arc" d="M32 4 A28 28 0 0 1 60 32" stroke-width="6" stroke-linecap="round" fill="none"/></svg></div>';
  window.VC = window.VC || {};

  /* VC.selectableOptionRow({ name, value, title, meta: [html…], badgeHtml, checked, onChange }) */
  window.VC.selectableOptionRow = function (p) {
    p = p || {};
    return '<label class="vc-option-row"><input type="radio" class="radio__input" name="' + esc(p.name) + '" value="' + esc(p.value) + '"' + (p.checked ? ' checked' : '') + (p.onChange ? ' onchange="' + esc(p.onChange) + '"' : '') + '>' +
      '<span class="vc-option-row__content"><span class="vc-option-row__head"><span class="vc-option-row__title">' + esc(p.title) + '</span>' + (p.badgeHtml || '') + '</span>' +
      (p.meta || []).map(function (m) { return '<span class="vc-option-row__meta">' + m + '</span>'; }).join('') + '</span></label>';
  };

  /* VC.stageLoader({ id, stages: ['Validation','Opportunity','Quote','Contract'], active: 0, headline, body, warning })
     Pass stages without 'Validation' when the option has no promotions / discounts. */
  window.VC.stageLoader = function (p) {
    p = p || {};
    var stages = p.stages || ['Opportunity', 'Quote', 'Contract'];
    var active = p.active || 0;
    var pct = stages.length > 1 ? Math.round((active / (stages.length - 1)) * 100) : 100;
    return '<div class="vc-stage-loader"' + (p.id ? ' id="' + esc(p.id) + '"' : '') + ' role="status" aria-live="polite">' +
      '<div class="vc-stage-loader__progress"><div class="vc-stage-loader__track"><div class="vc-stage-loader__fill" style="width:' + pct + '%"></div></div>' +
      '<div class="vc-stage-loader__labels">' + stages.map(function (s, i) { return '<span class="vc-stage-loader__label' + (i < active ? ' is-done' : i === active ? ' is-active' : '') + '">' + esc(s) + '</span>'; }).join('') + '</div></div>' +
      '<div class="vc-stage-loader__headline">' + esc(p.headline) + '</div>' +
      (p.body ? '<div class="vc-stage-loader__body">' + p.body + '</div>' : '') +
      '<div class="vc-stage-loader__warning">' + esc(p.warning || "Don't close or refresh this window") + '</div></div>';
  };

  /* VC.progressChecklist({ title, items: [{ id, label, sub, meta, state: 'done'|'progress'|'pending' }] }) */
  window.VC.progressChecklist = function (p) {
    p = p || {};
    return '<div class="vc-checklist">' + (p.title ? '<div class="vc-checklist__title">' + esc(p.title) + '</div>' : '') +
      (p.items || []).map(function (it) {
        var st = it.state || 'pending';
        var icon = st === 'done' ? '<span class="material-symbols-outlined" aria-hidden="true">check</span>' : st === 'progress' ? SPINNER : '';
        return '<div class="vc-checklist__row"' + (it.id ? ' id="' + esc(it.id) + '"' : '') + '><span class="vc-checklist__state vc-checklist__state--' + st + '" aria-hidden="true">' + icon + '</span>' +
          '<div><div class="vc-checklist__label">' + esc(it.label) + '</div>' + (it.sub ? '<div class="vc-checklist__sub">' + esc(it.sub) + '</div>' : '') + (it.meta ? '<div class="vc-checklist__meta">' + esc(it.meta) + '</div>' : '') + '</div></div>';
      }).join('') + '</div>';
  };
})();

/* ── Proposal panel (T6) · Proposal panel header (O16) · Options board (O17) — 2026-10-07 ── */
(function () {
  function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;'); }
  window.VC = window.VC || {};
  /* VC.proposalPanelHeader({ title, titleHtml, pillsHtml, metaHtml, actionsHtml })
     Options step: title ("Quote Options Comparison" / proposal name) + pills; Selection step: metaHtml (Name, Promotion, Close date…). */
  window.VC.proposalPanelHeader = function (p) {
    p = p || {};
    var main = p.metaHtml ? '<div class="vc-panel-header__meta">' + p.metaHtml + '</div>'
      : '<div class="vc-panel-header__title">' + (p.titleHtml || esc(p.title)) + '</div>' + (p.pillsHtml || '');
    return '<div class="vc-panel-header"><div class="vc-panel-header__main">' + main + '</div><div class="vc-panel-header__actions">' + (p.actionsHtml || '') + '</div></div>';
  };
  /* VC.optionsBoard({ id, cardsHtml, layout: 'row'|'wrap', empty: { title, body, actionLabel, onAction } }) — empty shows when cardsHtml is empty. */
  window.VC.optionsBoard = function (p) {
    p = p || {};
    var inner = p.cardsHtml || (p.empty ? '<div class="vc-options-board__empty"><div class="vc-options-board__empty-title">' + esc(p.empty.title) + '</div><div class="vc-options-board__empty-body">' + esc(p.empty.body) + '</div>' +
      (p.empty.actionLabel ? '<button type="button" class="btn btn--primary btn--large"' + (p.empty.onAction ? ' onclick="' + esc(p.empty.onAction) + '"' : '') + '>' + esc(p.empty.actionLabel) + '</button>' : '') + '</div>' : '');
    return '<div class="vc-options-board' + (p.layout === 'wrap' ? ' vc-options-board--wrap' : '') + '"' + (p.id ? ' id="' + esc(p.id) + '"' : '') + '>' + inner + '</div>';
  };
  /* VC.proposalPanel({ headerHtml, noticesHtml, boardHtml }) — template T6 */
  window.VC.proposalPanel = function (p) {
    p = p || {};
    return '<div class="vc-proposal-panel">' + (p.headerHtml || '') + '<div class="vc-panel-notices">' + (p.noticesHtml || '') + '</div>' + (p.boardHtml || '') + '</div>';
  };
})();

/* ── Side drawer (O2 / T4) ──────────────────────────────────────────────
   VC.drawer({ id, title, bodyHtml, actions: [{label, onClick, primary}], footer: 'fill'|'auto'|'column', wide, open, onClose })
   footer 'column' = Fill limited to the left configuration column (decided default for Discounts & Promotions).
   Renders backdrop + panel. Open/close by toggling .is-open on both (VC.setDrawerOpen). */
(function () {
  function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;'); }
  window.VC = window.VC || {};
  window.VC.drawer = function (p) {
    p = p || {};
    var id = p.id || 'vc-drawer', open = p.open ? ' is-open' : '', close = p.onClose || "VC.setDrawerOpen('" + id + "', false)";
    var actions = (p.actions || []).map(function (a) {
      return '<button type="button" class="btn btn--large ' + (a.primary ? 'btn--primary' : 'btn--secondary') + '"' + (a.id ? ' id="' + esc(a.id) + '"' : '') + (a.onClick ? ' onclick="' + esc(a.onClick) + '"' : '') + '>' + esc(a.label) + '</button>';
    }).join('');
    return '<div class="vc-drawer-backdrop' + open + '" id="' + esc(id) + '-backdrop" onclick="' + esc(close) + '"></div>' +
      '<aside class="vc-drawer' + (p.wide ? ' vc-drawer--wide' : '') + open + '" id="' + esc(id) + '" role="dialog" aria-modal="true" aria-labelledby="' + esc(id) + '-title">' +
      '<div class="vc-drawer__header"><h2 class="vc-drawer__title" id="' + esc(id) + '-title">' + esc(p.title) + '</h2>' +
      '<button type="button" class="btn-icon btn-icon--ghost-vds btn-icon--vds-large" aria-label="Close" onclick="' + esc(close) + '"><span class="material-symbols-outlined" aria-hidden="true">close</span></button></div>' +
      '<div class="vc-drawer__body">' + (p.bodyHtml || '') + '</div>' +
      (actions ? '<div class="vc-drawer__footer' + (p.footer === 'auto' ? ' vc-drawer__footer--auto' : p.footer === 'column' ? ' vc-drawer__footer--column' : '') + '">' + (p.footer === 'column' ? '<div class="vc-drawer__footer-actions">' + actions + '</div>' : actions) + '</div>' : '') + '</aside>';
  };
  window.VC.setDrawerOpen = function (id, open) {
    [document.getElementById(id), document.getElementById(id + '-backdrop')].forEach(function (el) { if (el) el.classList.toggle('is-open', !!open); });
  };
})();

/* ── Dropdown (custom list) ──────────────────────────────────────────────
   VC.enhanceSelect(select, {search}) wraps a native <select> with a VDS-looking
   trigger + our own option panel (kebab-menu look). The native select stays
   (visually hidden) as the source of truth: picking an option sets select.value
   and fires 'input' + 'change', so existing onchange handlers keep working.
   Programmatic select.value / selectedIndex changes, re-rendered options and
   disabled are mirrored automatically.
   VC.enhanceDropdowns(root) enhances every select[data-vc-dropdown] under root;
   VC.autoDropdowns(selector) also enhances ones rendered later (MutationObserver). */
(function () {
  window.VC = window.VC || {};
  var openDd = null, uid = 0, all = [];
  // Panels live in <body>; drop the ones whose select was re-rendered away.
  function purge() { all = all.filter(function (d) { if (d.sel.isConnected) return true; d.panel.remove(); return false; }); }
  var desc = {
    value: Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, 'value'),
    selectedIndex: Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, 'selectedIndex')
  };
  function closeOpen() { if (openDd) openDd.close(); }
  // Mirror programmatic changes made by the flows' own code (select.value = …).
  ['value', 'selectedIndex'].forEach(function (prop) {
    Object.defineProperty(HTMLSelectElement.prototype, prop, {
      configurable: true, enumerable: desc[prop].enumerable,
      get: function () { return desc[prop].get.call(this); },
      set: function (v) { desc[prop].set.call(this, v); if (this.__vcDropdown) this.__vcDropdown.refresh(); }
    });
  });
  document.addEventListener('mousedown', function (e) {
    if (openDd && !openDd.panel.contains(e.target) && !openDd.trigger.contains(e.target)) closeOpen();
  });
  window.addEventListener('resize', function () { if (openDd) openDd.place(); });
  document.addEventListener('scroll', function (e) { if (openDd && !openDd.panel.contains(e.target)) openDd.place(); }, true);

  window.VC.enhanceSelect = function (sel, opts) {
    if (!sel || sel.__vcDropdown) return sel && sel.__vcDropdown;
    opts = opts || {};
    var id = 'vc-dd-' + (++uid);
    var small = sel.classList.contains('select--small');
    var wrap = document.createElement('div');
    wrap.className = 'vc-dropdown' + (small ? ' vc-dropdown--small' : '');
    sel.parentNode.insertBefore(wrap, sel);
    wrap.appendChild(sel);
    sel.classList.add('vc-dropdown__native');
    sel.setAttribute('tabindex', '-1');
    sel.setAttribute('aria-hidden', 'true');

    var trigger = document.createElement('button');
    trigger.type = 'button';
    trigger.id = id + '-trigger';
    trigger.setAttribute('aria-haspopup', 'listbox');
    trigger.setAttribute('aria-expanded', 'false');
    trigger.setAttribute('aria-controls', id + '-panel');
    var lbl = sel.getAttribute('aria-label') || (sel.id && document.querySelector('label[for="' + sel.id + '"]') ? document.querySelector('label[for="' + sel.id + '"]').textContent : '');
    if (lbl) trigger.setAttribute('aria-label', lbl.trim());
    wrap.appendChild(trigger);

    var panel = document.createElement('div');
    panel.className = 'vc-dropdown__panel hidden' + (small ? ' vc-dropdown__panel--small' : '');
    panel.id = id + '-panel';
    document.body.appendChild(panel);

    var search = opts.search != null ? opts.search : (sel.dataset.vcSearch === 'true' || (sel.dataset.vcSearch !== 'false' && sel.options.length > 10));
    var dd = { sel: sel, trigger: trigger, panel: panel, active: -1, items: [], filter: '' };
    sel.__vcDropdown = dd; all.push(dd);

    function syncTrigger() {
      var o = sel.options[sel.selectedIndex];
      var placeholder = !o || o.value === '';
      var selectClasses = sel.className.replace(/\bvc-dropdown__native\b/, '').replace(/\bvds-select\b|\bterm-select\b/g, '').trim().split(/\s+/).filter(Boolean);
      if (selectClasses.indexOf('select') === -1) selectClasses.push('select');
      trigger.className = 'vc-dropdown__trigger ' + selectClasses.join(' ') + (placeholder ? ' is-placeholder' : '');
      trigger.textContent = o ? o.textContent : '';
      trigger.disabled = sel.disabled;
    }
    function build() {
      var q = dd.filter.toLowerCase(), html = '', n = 0;
      if (search) html += '<div class="vc-dropdown__search"><input type="text" placeholder="Search" aria-label="Search options" value="' + dd.filter.replace(/"/g, '&quot;') + '"></div>';
      html += '<div class="vc-dropdown__list" role="listbox" aria-labelledby="' + trigger.id + '">';
      Array.prototype.forEach.call(sel.children, function (node) {
        var opts2 = node.tagName === 'OPTGROUP' ? Array.prototype.slice.call(node.children) : [node];
        var rows = '';
        opts2.forEach(function (o) {
          if (o.tagName !== 'OPTION' || o.hidden) return;
          if (q && o.textContent.toLowerCase().indexOf(q) === -1) return;
          if (q && o.value === '') return;
          var selected = o.selected && o.value !== '';
          rows += '<button type="button" role="option" class="vc-dropdown__item' + (selected ? ' is-selected' : '') + '" data-index="' + o.index + '" aria-selected="' + selected + '"' + (o.disabled ? ' disabled' : '') + '><span>' + o.textContent.replace(/</g, '&lt;') + '</span><span class="material-symbols-outlined" aria-hidden="true">check</span></button>';
          n++;
        });
        if (rows && node.tagName === 'OPTGROUP') html += '<div class="vc-dropdown__group-label">' + node.label.replace(/</g, '&lt;') + '</div>';
        html += rows;
      });
      if (!n) html += '<div class="vc-dropdown__empty">No results</div>';
      panel.innerHTML = html + '</div>';
      dd.items = Array.prototype.slice.call(panel.querySelectorAll('.vc-dropdown__item:not(:disabled)'));
      var input = panel.querySelector('.vc-dropdown__search input');
      if (input) {
        input.addEventListener('input', function () { dd.filter = input.value; build(); dd.setActive(0); var i2 = panel.querySelector('.vc-dropdown__search input'); i2.focus(); i2.setSelectionRange(i2.value.length, i2.value.length); });
        input.addEventListener('keydown', onKey);
      }
    }
    dd.setActive = function (i) {
      dd.items.forEach(function (b) { b.classList.remove('is-active'); });
      if (!dd.items.length) { dd.active = -1; return; }
      dd.active = Math.max(0, Math.min(i, dd.items.length - 1));
      var b = dd.items[dd.active]; b.classList.add('is-active');
      var list = panel.querySelector('.vc-dropdown__list');
      if (b.offsetTop < list.scrollTop) list.scrollTop = b.offsetTop;
      else if (b.offsetTop + b.offsetHeight > list.scrollTop + list.clientHeight) list.scrollTop = b.offsetTop + b.offsetHeight - list.clientHeight;
    };
    dd.place = function () {
      var r = trigger.getBoundingClientRect(), vh = window.innerHeight, below = vh - r.bottom - 8, above = r.top - 8;
      panel.style.minWidth = r.width + 'px';
      panel.style.left = Math.max(8, Math.min(r.left, window.innerWidth - panel.offsetWidth - 8)) + 'px';
      if (below < 200 && above > below) { panel.style.top = ''; panel.style.bottom = (vh - r.top + 4) + 'px'; panel.style.maxHeight = Math.min(320, above) + 'px'; }
      else { panel.style.bottom = ''; panel.style.top = (r.bottom + 4) + 'px'; panel.style.maxHeight = Math.min(320, below) + 'px'; }
    };
    dd.open = function () {
      if (sel.disabled) return;
      closeOpen(); purge();
      dd.filter = ''; build();
      panel.classList.remove('hidden');
      trigger.setAttribute('aria-expanded', 'true');
      openDd = dd; dd.place();
      var cur = dd.items.findIndex(function (b) { return b.classList.contains('is-selected'); });
      dd.setActive(cur < 0 ? 0 : cur);
      var input = panel.querySelector('.vc-dropdown__search input');
      if (input) input.focus();
    };
    dd.close = function (focus) {
      panel.classList.add('hidden');
      trigger.setAttribute('aria-expanded', 'false');
      if (openDd === dd) openDd = null;
      if (focus) trigger.focus();
    };
    dd.choose = function (index) {
      var changed = sel.selectedIndex !== index;
      desc.selectedIndex.set.call(sel, index);
      syncTrigger(); dd.close(true);
      if (changed) { sel.dispatchEvent(new Event('input', { bubbles: true })); sel.dispatchEvent(new Event('change', { bubbles: true })); }
    };
    function onKey(e) {
      var isOpen = !panel.classList.contains('hidden');
      if (!isOpen) {
        if (['ArrowDown', 'ArrowUp', 'Enter', ' '].indexOf(e.key) > -1) { e.preventDefault(); dd.open(); }
        return;
      }
      if (e.key === 'ArrowDown') { e.preventDefault(); dd.setActive(dd.active + 1); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); dd.setActive(dd.active - 1); }
      else if (e.key === 'Home') { e.preventDefault(); dd.setActive(0); }
      else if (e.key === 'End') { e.preventDefault(); dd.setActive(dd.items.length - 1); }
      else if (e.key === 'Enter' || (e.key === ' ' && e.target === trigger)) { e.preventDefault(); if (dd.items[dd.active]) dd.choose(+dd.items[dd.active].dataset.index); }
      else if (e.key === 'Escape' || e.key === 'Tab') { if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); } dd.close(e.key === 'Escape'); }
      else if (!search && e.key.length === 1) {
        var k = e.key.toLowerCase(), start = dd.active + 1;
        for (var j = 0; j < dd.items.length; j++) { var b = dd.items[(start + j) % dd.items.length]; if (b.textContent.trim().toLowerCase().indexOf(k) === 0) { dd.setActive((start + j) % dd.items.length); break; } }
      }
    }
    trigger.addEventListener('click', function () { panel.classList.contains('hidden') ? dd.open() : dd.close(); });
    trigger.addEventListener('keydown', onKey);
    panel.addEventListener('mousedown', function (e) { if (!e.target.closest('input')) e.preventDefault(); });
    panel.addEventListener('click', function (e) { var b = e.target.closest('.vc-dropdown__item'); if (b && !b.disabled) dd.choose(+b.dataset.index); });
    panel.addEventListener('mousemove', function (e) { var b = e.target.closest('.vc-dropdown__item'); if (b) { var i = dd.items.indexOf(b); if (i > -1 && i !== dd.active) dd.setActive(i); } });

    // Programmatic select.value / selectedIndex changes are mirrored by the prototype patch below.
    new MutationObserver(function () { syncTrigger(); if (!panel.classList.contains('hidden')) build(); })
      .observe(sel, { childList: true, subtree: true, attributes: true, attributeFilter: ['disabled', 'class', 'selected'] });
    sel.addEventListener('change', syncTrigger);
    dd.refresh = syncTrigger;
    syncTrigger();
    return dd;
  };
  window.VC.enhanceDropdowns = function (root, selector) {
    (root || document).querySelectorAll(selector || 'select[data-vc-dropdown]').forEach(function (s) { VC.enhanceSelect(s); });
  };
  window.VC.autoDropdowns = function (selector) {
    selector = selector || 'select[data-vc-dropdown]';
    VC.enhanceDropdowns(document, selector);
    new MutationObserver(function (muts) {
      muts.forEach(function (m) { m.addedNodes.forEach(function (n) {
        if (n.nodeType !== 1) return;
        if (n.matches && n.matches(selector)) VC.enhanceSelect(n);
        if (n.querySelectorAll) n.querySelectorAll(selector).forEach(function (s) { VC.enhanceSelect(s); });
      }); });
    }).observe(document.body, { childList: true, subtree: true });
  };
})();

/* Date field calendar icon: pointer cursor + click opens the calendar (2026-10-07). */
document.addEventListener('click', function (e) {
  var icon = e.target.closest && e.target.closest('.vc-date-field__icon');
  if (!icon) return;
  var field = icon.closest('.vc-date-field');
  var input = field && field.querySelector('input');
  if (!input || input.disabled || input.readOnly) return;
  // open after the calendar library's own outside-click handler has run (it would close it again)
  if (input._flatpickr) { var fp = input._flatpickr; setTimeout(function () { fp.open(); }, 0); }
  else if (typeof input.showPicker === 'function') { try { input.showPicker(); } catch (err) { input.focus(); } }
  else input.focus();
}, true); // capture phase: modals stop click propagation (e.g. Send Proposal), so bubbling never reaches document

/* ── File upload (custom molecule — VDS has no file input; 2026-10-07, per Catalina) ──
  VC.fileUpload({ label, inputId, filenameId, onClick, onChange, errorId, errorText, text, accept })
  Label = .vc-field-label like every other input; box text = VDS input text (16px, secondary).
  Behavior stays in the flow (onClick opens the hidden input, onChange shows the filename). */
(function () {
  function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;'); }
  function fileUpload(p) {
    p = p || {};
    return '<div class="vc-file-upload">' +
      (p.label ? '<label class="vc-field-label"' + (p.inputId ? ' for="' + esc(p.inputId) + '"' : '') + '>' + esc(p.label) + '</label>' : '') +
      '<button type="button" class="vc-file-upload__box"' + (p.onClick ? ' onclick="' + esc(p.onClick) + '"' : '') + '>' +
        '<span class="material-symbols-outlined vc-file-upload__icon" aria-hidden="true">upload</span>' +
        '<span class="vc-file-upload__text">' + esc(p.text || 'Click to upload or drag and drop') + '</span>' +
      '</button>' +
      '<input type="file" class="vc-file-upload__input"' + (p.inputId ? ' id="' + esc(p.inputId) + '"' : '') + (p.accept ? ' accept="' + esc(p.accept) + '"' : '') + (p.onChange ? ' onchange="' + esc(p.onChange) + '"' : '') + '>' +
      '<div class="vc-file-upload__filename hidden"' + (p.filenameId ? ' id="' + esc(p.filenameId) + '"' : '') + '></div>' +
      (p.errorId ? '<div id="' + esc(p.errorId) + '" class="input__error-text hidden">' + esc(p.errorText || '') + '</div>' : '') +
      '</div>';
  }
  window.VC = window.VC || {};
  window.VC.fileUpload = fileUpload;
})();

/* ── Approval notification (VDS Notification · warning, 2026-10-07) ────────────────────
  VC.approvalNotification({ title, message, action: { label, onClick }, compact, className })
  Full size (default): VDS Notification as specified — 16px bold title, 14px message, 20px icon;
  the action is the VDS Secondary Small button on the title row. Used above the options.
  compact: title-only chip inside an option card (13px) — it stays readable in the 530px card.
  Flows decide when it shows and what it says (roles, pending state, which options). */
(function () {
  function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;'); }
  function approvalNotification(p) {
    p = p || {};
    var cls = 'notification notification--warning vc-approval-notification' + (p.compact ? ' vc-approval-notification--compact' : '') + (p.className ? ' ' + p.className : '');
    var action = p.action ? '<button type="button" class="btn btn--secondary btn--small"' + (p.action.onClick ? ' onclick="' + esc(p.action.onClick) + '"' : '') + '>' + esc(p.action.label) + '</button>' : '';
    var title = '<div class="notification__title">' + (p.title || '') + '</div>';
    return '<div class="' + cls + '" role="status">' +
      '<span class="material-symbols-outlined notification__icon" aria-hidden="true">warning</span>' +
      '<div class="notification__body">' +
        (action ? '<div class="vc-approval-notification__title-row">' + title + action + '</div>' : title) +
        (p.message ? '<div class="notification__message">' + p.message + '</div>' : '') +
      '</div></div>';
  }
  window.VC = window.VC || {};
  window.VC.approvalNotification = approvalNotification;
})();
