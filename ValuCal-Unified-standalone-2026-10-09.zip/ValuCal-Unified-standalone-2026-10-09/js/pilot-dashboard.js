(function (global) {
  const unified = global.VC_UNIFIED || (global.VC_UNIFIED = {});

  unified.configuredPilotSummary = function configuredPilotSummary(hasMsa) {
    const pilot = {
      title: 'Pilot',
      metrics: [
        { label: 'Pilot term', value: 'Oct 6, 2026 - Oct 5, 2027 (12 mo)' },
        { label: 'Pricing', value: hasMsa ? 'Paid: 50% off subscriptions' : 'Free' },
        { label: 'When the pilot ends', value: hasMsa ? 'Auto-convert to MSA' : 'Auto-cancel' },
      ],
    };
    return { layout: hasMsa ? 'split' : undefined, sections: hasMsa ? [pilot, {
      title: 'MSA',
      dividerBefore: true,
      metrics: [
        { label: 'Contract term', value: 'Oct 6, 2027 - Oct 5, 2030 (36 mo)' },
        { label: 'Tier/Term', value: '18%' },
        { label: 'Account Discount', value: 'Enterprise (4%)' },
      ],
    }] : [pilot] };
  };
})(window);