/* ── Discounts & Promotions drawer (shared, 2026-10-07 — phase 1) ─────────────────────────
   Initial Sales is the reference; Existing Accounts adopts it. Phase 1 = the helpers that were nearly
   identical in both flows (save / remove promotion, discount program, durations, close, hardware row…).
   Still per flow (phase 2+): tabs (order / contract promotions, custom promotion), summary column,
   price list and totals.
   Data-model hooks — the option's discretionary discount lives in a different field per flow:
     getOptionDiscountPct(opt, bundle) / setOptionDiscountPct(opt, pct)
   Defaults below = Initial Sales (opt.msaDiscountPct); Existing Accounts defines its own versions
   (opt.discretionaryDiscountPct), which replace these because the flow script loads later. */

function getOptionDiscountPct(opt, bundle) {
  if (typeof opt?.msaDiscountPct === 'number') return opt.msaDiscountPct;
  return typeof bundle?.msaDiscountPct === 'number' ? bundle.msaDiscountPct : 0;
}

function setOptionDiscountPct(opt, pct) {
  opt.msaDiscountPct = pct;
  opt.bundles.forEach(b => { b.msaDiscountPct = pct; });
}

function getCustomPromotions(opt) {
  if (!Array.isArray(opt.customPromotions)) opt.customPromotions = [];
  return opt.customPromotions;
}

function getDefaultPromoDurationMonths(opt) {
  const available = getAvailablePromoDurationPresets(opt);
  const termMonths = Math.max(1, Number(opt && opt.term) || 1);
  return available.includes(termMonths) ? termMonths : (available[0] || termMonths);
}

function getAvailablePromoDurationPresets(opt) {
  const termMonths = Math.max(1, Number(opt && opt.term) || 1);
  return PROMO_DURATION_MONTH_PRESETS.filter((months) => months <= termMonths);
}

function closeOptPromoDrawer() {
  openOptPromoPanelId = null;
  optPromoDraft = null;
  if (typeof openOptPromoScope !== 'undefined') openOptPromoScope = 'promotions';
  document.getElementById('opt-promo-drawer')?.classList.remove('vc-drawer--wide');
  VC.setDrawerOpen('opt-promo-drawer', false);
  applyOptionFocusMode(null);
}

function closeSubPriceListModal() {
  document.getElementById('sub-price-list-modal-overlay')?.classList.remove('is-open');
  if (typeof subPriceListModalOptId !== 'undefined') subPriceListModalOptId = null;
}

function getSelectedOptionSummary() {
  const selectedId = bld.selectedOptionId;
  const opt = options.find((o) => o.id === selectedId);
  if (!opt) return null;
  const optionNumber = Math.max(1, options.findIndex((o) => o.id === selectedId) + 1);
  const { totalMonthly } = calcOption(opt, getOptionPromotion(opt));
  return {
    optionLabel: getOptionDisplayLabel(optionNumber),
    optionValue: `${formatMoney(totalMonthly)}/month`
  };
}

function saveOptPromoDraft() {
  if (!optPromoDraft || openOptPromoPanelId === null) { closeOptPromoDrawer(); return; }
  const opt = options.find(o => o.id === openOptPromoPanelId);
  if (!opt) { closeOptPromoDrawer(); return; }
  const optIndex = options.findIndex(o => o.id === opt.id);
  const effective = getSelectedPromoCombo(optPromoDraft);
  const hasActiveCustomPromotion = getCustomPromotions(opt).some(customPromoHasAnyValue);
  if (effective) {
    Object.keys(effective).forEach(ck => {
      const { promoType, promoName, dealCloser } = effective[ck];
      opt.bundles.forEach(b => {
        if (b.coreKey === ck) {
          b.promoType = promoType;
          b.promoName = promoName;
          b.dealCloser = dealCloser;
        }
      });
    });
  } else if (optPromoDraft.mode === 'packages' && optPromoDraft.selectedKey === null) {
    // No promotion selected (removed via "Remove promotion") — clear it from
    // every bundle in scope instead of leaving stale promo data in place.
    optPromoDraft.coreKeys.forEach(ck => {
      opt.bundles.forEach(b => {
        if (b.coreKey === ck) {
          b.promoType = 'Standard';
          b.promoName = '';
          b.dealCloser = '';
        }
      });
    });
  }
  closeOptPromoDrawer();
  renderOptions();
  if (screen === 'selection') renderSelectionOptions();
  showSuccessBanner(effective || hasActiveCustomPromotion ? 'Promotions applied' : 'Promotion removed', `${getOptionDisplayLabel(optIndex + 1, true)} has been updated.`);
}

function removeOptPromoSelection(optId) {
  if (!optPromoDraft) return;
  // Clear selection also clears an order-level Custom Promotion (2026-10-05).
  const clearOpt = options.find(o => o.id === optId);
  if (clearOpt) {
    clearOpt.customPromotions = getCustomPromotions(clearOpt).filter(p => p.level !== 'order');
    clearOpt.orderPromoMode = 'packages';
  }
  optPromoDraft.selectedKey = null;
  optPromoDraft.coreKeys.forEach(ck => {
    optPromoDraft.custom[ck] = { promoType: 'Standard', promoName: '', dealCloser: '' };
  });
  renderOptPromoDrawer();
  renderOptions();
  if (screen === 'selection') renderSelectionOptions();
}

function matrixSetContractDiscountProgram(optId, value) {
  const opt = options.find(o => o.id === optId);
  if (!opt) return;
  opt.customPromotions = getCustomPromotions(opt).filter(p => p.level !== 'contract');
  opt.contractPromoMode = 'programs';
  const program = DISCOUNT_PROGRAMS.find(p => p.key === value);
  opt.discountProgramKey = program ? program.key : null;
  setOptionDiscountPct(opt, program ? program.pct : 0);
  renderOptPromoDrawer();
  renderOptions();
  if (screen === 'selection') renderSelectionOptions();
}

function buildDrawerHardwareRowHtml(label, unitPrice, withQtyCell = false) {
  return `
          <tr class="bundle-summary-components-row--hardware">
            <td class="bundle-summary-components-cell bundle-summary-components-cell--name">${label}</td>
            ${withQtyCell ? '<td class="bundle-summary-components-cell bundle-summary-components-cell--num"></td>' : ''}
            <td class="bundle-summary-components-cell bundle-summary-components-cell--freq">One Time</td>
            <td class="bundle-summary-components-cell bundle-summary-components-cell--num">${formatMoney(unitPrice)}</td>
            <td class="bundle-summary-components-cell bundle-summary-components-cell--num">${formatMoney(unitPrice)}</td>
            <td class="bundle-summary-components-cell bundle-summary-components-cell--num">—</td>
            <td class="bundle-summary-components-cell bundle-summary-components-cell--num">${formatMoney(unitPrice)}</td>
          </tr>`;
}

/* ── Phase 2 (2026-10-07): Account Discount / Order Promotions tabs — shared, per Catalina:
   • approval notice on Create a Custom Discount / Promotion in both flows;
   • program and custom discount are mutually exclusive (never two selected);
   • "Reset" at the top of the custom builder (replaces the old "Remove promotion" link at the bottom);
   • fuller custom summary on the list card ("… (+N more custom …)").
   The custom-promotion TABLE (rows, values, current prices) stays per flow until the pricing phase. */

function buildCustomApprovalNoticeHtml(kind) {
  return `<div class="notification notification--warning custom-approval-notice" role="status">
    <span class="material-symbols-outlined notification__icon" aria-hidden="true">warning</span>
    <p class="notification__message">This type of ${kind} requires approval.</p>
  </div>`;
}

// Header of the custom builder: back · title · Reset (only when the custom has a value).
function buildCustomPromoHeaderHtml(opt, title, backOnclick, level, hasValue) {
  return `<div class="custom-promo-header-row">
          <button type="button" class="btn-icon btn-icon--ghost-vds btn-icon--vds-small" onclick="${backOnclick}" aria-label="Back" title="Back">
            <span class="material-symbols-outlined">arrow_back</span>
          </button>
          <span class="discount-matrix-section-title">${title}</span>
          ${hasValue ? `<button type="button" class="text-link text-link--small custom-promo-reset" onclick="resetCustomPromotion(${opt.id}, '${level}')">Reset</button>` : ''}
        </div>`;
}

// Reset clears the custom promotion / discount of that level (back to a fresh, empty one) and stays in the builder.
function resetCustomPromotion(optId, level) {
  const opt = options.find(o => o.id === optId);
  if (!opt) return;
  opt.customPromotions = getCustomPromotions(opt).filter(p => p.level !== level);
  opt.customPromotions.push(makeDefaultCustomPromotion(opt, level));
  renderOptPromoDrawer();
  renderOptions();
  if (screen === 'selection') renderSelectionOptions();
}

function getPackageSummaryGroups(combo, coreKeys) {
  const order = [];
  const subsByPromo = new Map();
  coreKeys.forEach(ck => {
    const promoName = combo[ck] && combo[ck].promoName;
    if (!promoName) return;
    const subName = displaySubscriptionName(corePricing[ck]?.name || ck);
    if (!subsByPromo.has(promoName)) {
      subsByPromo.set(promoName, []);
      order.push(promoName);
    }
    const subs = subsByPromo.get(promoName);
    if (!subs.includes(subName)) subs.push(subName);
  });
  return order.length
    ? order.map(promoName => ({ promoName, subNames: subsByPromo.get(promoName) }))
    : [{ promoName: 'No promotion applied', subNames: [] }];
}

// "Custom summary" on the list card: first custom's subscription + value, then "(+N more …)".
function buildCustomSummaryText(opt, activeCustoms, noun, emptyText) {
  if (!activeCustoms.length) return emptyText;
  const line = getCustomPromoSummaryLine(opt, activeCustoms[0]);
  const extra = activeCustoms.length - 1;
  return (line || `Custom ${noun} configured`) + (line && extra > 0 ? ` (+${extra} more custom ${noun}${extra > 1 ? 's' : ''})` : '');
}

function buildContractPromotionsTabHtml(opt) {
  const contractCustomPromos = getCustomPromotions(opt).filter(cp => cp.level === 'contract');
  const mode = opt.contractPromoMode === 'custom' ? 'custom' : 'programs';

  if (mode === 'custom') {
    if (contractCustomPromos.length === 0) getCustomPromotions(opt).push(makeDefaultCustomPromotion(opt, 'contract'));
    const cp = getCustomPromotions(opt).filter(cp => cp.level === 'contract')[0];
    return `
      <div class="ff-fadein">
        ${buildCustomPromoHeaderHtml(opt, 'Create a Custom Discount', `setContractPromoMode(${opt.id}, 'programs')`, 'contract', customPromoHasAnyValue(cp))}
        ${buildCustomApprovalNoticeHtml('discount')}
        ${buildCustomPromotionFieldsHtml(opt, cp)}
        <button type="button" class="btn btn--secondary btn--small custom-promo-apply-btn" ${customPromoHasAnyValue(cp) ? '' : 'disabled'} onclick="setContractPromoMode(${opt.id}, 'programs')">Save</button>
      </div>`;
  }

  // A program and a custom discount are mutually exclusive: an active custom deselects the programs.
  const activeContractCustoms = contractCustomPromos.filter(customPromoHasAnyValue);
  const hasContractCustom = activeContractCustoms.length > 0;
  const hasActiveDiscount = !!opt.discountProgramKey || (getOptionDiscountPct(opt, opt.bundles[0]) || 0) > 0;
  const programCardsHtml = DISCOUNT_PROGRAMS.map((p) => {
    const isSelected = !hasContractCustom && opt.discountProgramKey === p.key;
    return `
    <div class="opt-promo-package-card ${isSelected ?'opt-promo-package-card--selected' : ''}" onclick="matrixSetContractDiscountProgram(${opt.id}, '${p.key}')">
      <span class="opt-promo-package-radio material-symbols-outlined">${isSelected ? 'radio_button_checked' : 'radio_button_unchecked'}</span>
      <div class="opt-promo-package-body">
        <div class="opt-promo-package-head">
          <span class="opt-promo-package-label">${p.name}</span>
          <span class="opt-promo-recommended-price">${p.pct}%</span>
        </div>
      </div>
    </div>`;
  }).join('');
  const customCardHtml = `
    <div class="opt-promo-package-card ${hasContractCustom ?'opt-promo-package-card--selected' : ''}" onclick="setContractPromoMode(${opt.id}, 'custom')">
      <span class="opt-promo-package-radio material-symbols-outlined">${hasContractCustom ? 'radio_button_checked' : 'radio_button_unchecked'}</span>
      <div class="opt-promo-package-body">
        <div class="opt-promo-package-head">
          <span class="opt-promo-package-label">Create a Custom Discount</span>
          ${hasContractCustom ? `<button type="button" class="btn-icon btn-icon--ghost-vds btn-icon--fit" title="Edit custom discount" onclick="event.stopPropagation(); setContractPromoMode(${opt.id}, 'custom')" aria-label="Edit"><span class="material-symbols-outlined">edit</span></button>` : ''}
        </div>
        <div class="opt-promo-package-summary">${buildCustomSummaryText(opt, activeContractCustoms, 'discount', 'Build a one-off discount for this contract')}</div>
      </div>
    </div>`;
  return `
    ${buildDrawerListHeaderHtml('Account Discount programs', hasActiveDiscount || hasContractCustom, `matrixSetContractDiscountProgram(${opt.id}, '')`)}
    <div class="opt-promo-package-list">
      ${programCardsHtml}
      ${customCardHtml}
    </div>`;
}

function buildOrderPromotionsTabHtml(opt, draft) {
  const orderCustomPromos = getCustomPromotions(opt).filter(cp => cp.level === 'order');
  const orderCustomHasRealValue = orderCustomPromos.some(p => customPromoHasAnyValue(p));
  // A package and a custom promotion are mutually exclusive too.
  if (orderCustomHasRealValue && draft && draft.selectedKey !== null) {
    draft.selectedKey = null;
    draft.coreKeys.forEach(ck => {
      draft.custom[ck] = { promoType: 'Standard', promoName: '', dealCloser: '' };
      opt.bundles.forEach(b => {
        if (b.coreKey === ck) { b.promoType = 'Standard'; b.promoName = ''; b.dealCloser = ''; }
      });
    });
  }
  if (opt.orderPromoMode === 'custom') {
    if (orderCustomPromos.length === 0) getCustomPromotions(opt).push(makeDefaultCustomPromotion(opt, 'order'));
    const cp = getCustomPromotions(opt).filter(cp => cp.level === 'order')[0];
    return `
      <div class="ff-fadein">
        ${buildCustomPromoHeaderHtml(opt, 'Create a Custom Promotion', `setOrderPromoMode(${opt.id}, 'packages')`, 'order', customPromoHasAnyValue(cp))}
        ${buildCustomApprovalNoticeHtml('promotion')}
        ${buildCustomPromotionFieldsHtml(opt, cp)}
        <button type="button" class="btn btn--secondary btn--small custom-promo-apply-btn" ${customPromoHasAnyValue(cp) ? '' : 'disabled'} onclick="setOrderPromoMode(${opt.id}, 'packages')">Save</button>
      </div>`;
  }

  if (draft.mode === 'custom') {
    const groupsByCore = getGroupsByCore(opt, draft.coreKeys);
    return draft.coreKeys.map(ck => {
      const groupBundles = groupsByCore[ck];
      const c = draft.custom[ck];
      const coreName = groupBundles[0]?.coreName || ck;
      return `
      <div class="opt-promo-drawer-section">
        <div class="opt-promo-drawer-section-title">${coreName}</div>
        <div class="vc-field-label">Promotion Name</div>
        <div class="custom-select-wrap">
          <button class="custom-select-btn" onclick="toggleCustomPromoNameDropdown(${opt.id}, '${ck}', event)">
            <span>${c.promoName || 'None'}</span>
            <span class="material-symbols-outlined">expand_more</span>
          </button>
          <div class="custom-dropdown hidden" id="opt-promo-name-dd-${opt.id}-${ck}">
            ${buildCustomPromoNameRows(opt, ck, c.promoName)}
          </div>
        </div>
        <div class="vc-field-label opt-promo-field-gap">Deal Closer</div>
        <div class="custom-select-wrap">
          <button class="custom-select-btn" onclick="toggleCustomDealCloserDropdown(${opt.id}, '${ck}', event)">
            <span>${c.dealCloser || 'None'}</span>
            <span class="material-symbols-outlined">expand_more</span>
          </button>
          <div class="custom-dropdown hidden" id="opt-deal-closer-dd-${opt.id}-${ck}">
            ${buildCustomDealCloserRows(opt, ck, c.dealCloser)}
          </div>
        </div>
      </div>`;
    }).join('<hr class="opt-promo-drawer-divider">')
      + `<button type="button" class="text-link text-link--small opt-promo-back-link" onclick="setOptPromoDrawerMode(${opt.id}, 'packages')">← Back to suggested packages</button>`;
  }

  const entries = draft.packages.map((p, idx) => ({ p, key: idx }));
  if (draft.customEntry) entries.push({ p: draft.customEntry, key: 'custom' });

  const packageCardsHtml = entries.length === 0
    ? `<div class="opt-promo-empty">No promotions available for this term</div>`
    : entries.map(({ p, key }, i) => {
        const isSelected = draft.selectedKey !== null && draft.selectedKey === key;
        const label = key === 'custom' ? 'Your selection' : `Package ${i + 1}${i === 0 ? ' · Best value' : ''}`;
        const summaryHtml = getPackageSummaryGroups(p.combo, draft.coreKeys).map(g => `
          <div class="opt-promo-package-summary-group">
            <div class="opt-promo-package-summary-title">${g.promoName}</div>
            ${g.subNames.map(subName => `<div class="opt-promo-package-summary-sub">${subName}</div>`).join('')}
          </div>`).join('');
        return `
        <div class="opt-promo-package-card ${isSelected ?'opt-promo-package-card--selected' : ''}" onclick="selectPromoPackage(${opt.id}, ${key === 'custom' ? "'custom'" : key})">
          <span class="opt-promo-package-radio material-symbols-outlined">${isSelected ? 'radio_button_checked' : 'radio_button_unchecked'}</span>
          <div class="opt-promo-package-body">
            <div class="opt-promo-package-head">
              <span class="opt-promo-package-label">${label}</span>
              ${key === 'custom' ? `<button type="button" class="btn-icon btn-icon--ghost-vds btn-icon--fit" title="Edit combination" onclick="event.stopPropagation(); setOptPromoDrawerMode(${opt.id}, 'custom')" aria-label="Edit"><span class="material-symbols-outlined">edit</span></button>` : ''}
              <span class="opt-promo-recommended-price">${formatMoney(p.totalMonthly)}/mo</span>
            </div>
            <div class="opt-promo-package-summary">${summaryHtml}</div>
          </div>
        </div>`;
      }).join('');

  const activeOrderCustomPromos = orderCustomPromos.filter(customPromoHasAnyValue);
  const hasOrderCustom = activeOrderCustomPromos.length > 0;
  const orderCustomDurationBadge = (hasOrderCustom && activeOrderCustomPromos[0].durationMode === 'months'
    && activeOrderCustomPromos[0].durationMonths && activeOrderCustomPromos[0].durationMonths !== Number(opt.term))
    ? `<span class="badge badge--gray opt-promo-duration-badge">${activeOrderCustomPromos[0].durationMonths}mo</span>` : '';
  const customPromoCardHtml = `
    <div class="opt-promo-package-card ${hasOrderCustom ?'opt-promo-package-card--selected' : ''}" onclick="setOrderPromoMode(${opt.id}, 'custom')">
      <span class="opt-promo-package-radio material-symbols-outlined">${hasOrderCustom ? 'radio_button_checked' : 'radio_button_unchecked'}</span>
      <div class="opt-promo-package-body">
        <div class="opt-promo-package-head">
          <span class="opt-promo-package-label">Create a Custom Promotion${orderCustomDurationBadge}</span>
          ${hasOrderCustom ? `<button type="button" class="btn-icon btn-icon--ghost-vds btn-icon--fit" title="Edit custom promotion" onclick="event.stopPropagation(); setOrderPromoMode(${opt.id}, 'custom')" aria-label="Edit"><span class="material-symbols-outlined">edit</span></button>` : ''}
        </div>
        <div class="opt-promo-package-summary">${buildCustomSummaryText(opt, activeOrderCustomPromos, 'promotion', 'Build a one-off promotion for this order')}</div>
      </div>
    </div>`;

  return `
    ${buildDrawerListHeaderHtml('Order Promotions', draft.selectedKey !== null || hasOrderCustom, `removeOptPromoSelection(${opt.id})`)}
    <div class="opt-promo-package-list">
      ${packageCardsHtml}
      ${customPromoCardHtml}
    </div>
  `;
}

function buildCustomPromotionFieldsHtml(opt, cp) {
  // Order promotions have a Duration (timeline + presets, the one matching the term marked "Current");
  // Contract discounts always run for the life of the contract. Then the per-subscription table.
  const durationMode = cp.durationMode === 'months' ? 'months' : 'term';
  const termMonths = Math.max(1, Number(opt.term) || 1);
  const availableDurationPresets = getAvailablePromoDurationPresets(opt);
  const hasExactTermPreset = availableDurationPresets.includes(termMonths);
  const durationHtml = cp.level === 'contract' ? '' : `
      <div class="vc-field-label">Duration</div>
      <div class="custom-promo-duration-block">
        ${buildPromoDurationTimelineHtml(opt, cp, durationMode)}
        <div class="segmented-control promo-duration-segmented">
          ${availableDurationPresets.map(months => {
            const isActive = durationMode === 'term' ? months === termMonths : cp.durationMonths === months;
            const isCurrentContractLength = months === termMonths;
            return `
          <button type="button" class="segmented-control__option promo-duration-option ${isActive ?'segmented-control__option--active' : ''}" onclick="setCustomPromotionDurationMonths(${opt.id}, '${cp.id}', ${months})">
            <span class="promo-duration-option-value">${months}mo</span>
            ${isCurrentContractLength ? '<span class="promo-duration-option-caption">(Current)</span>' : ''}
          </button>`;
          }).join('')}
        </div>
        ${hasExactTermPreset ? '' : `<div class="text-body-small custom-promo-term-note">Contract length: ${termMonths} months</div>`}
      </div>`;
  return `
    <div class="custom-promo-fields">
      ${durationHtml}
      ${buildCustomPromoRowsTableHtml(opt, cp)}
    </div>`;
}

function setContractPromoMode(optId, mode) {
  const opt = options.find(o => o.id === optId);
  if (!opt) return;
  opt.contractPromoMode = mode === 'custom' ? 'custom' : 'programs';
  // Program and Custom are mutually exclusive: entering Custom clears the program discount.
  if (opt.contractPromoMode === 'custom') {
    opt.discountProgramKey = null;
    setOptionDiscountPct(opt, 0);
  }
  renderOptPromoDrawer();
  const body = document.getElementById('opt-promo-drawer-body');
  if (body) body.scrollTop = 0;
  renderOptions();
  if (screen === 'selection') renderSelectionOptions();
}

function setOrderPromoMode(optId, mode) {
  const opt = options.find(o => o.id === optId);
  if (!opt) return;
  opt.orderPromoMode = mode === 'custom' ? 'custom' : 'packages';
  if (mode === 'custom' && optPromoDraft) {
    optPromoDraft.selectedKey = null;
    optPromoDraft.coreKeys.forEach(ck => {
      optPromoDraft.custom[ck] = { promoType: 'Standard', promoName: '', dealCloser: '' };
      opt.bundles.forEach(bundle => {
        if (bundle.coreKey === ck) {
          bundle.promoType = 'Standard';
          bundle.promoName = '';
          bundle.dealCloser = '';
        }
      });
    });
  }
  renderOptPromoDrawer();
  const body = document.getElementById('opt-promo-drawer-body');
  if (body) body.scrollTop = 0;
  renderOptions();
  if (screen === 'selection') renderSelectionOptions();
}

/* ── Phase 3 (2026-10-07): drawer shell — layout, tabs and the summary column, shared.
   Flow hooks:
     getDrawerLayout(opt, draft) → { unified, tabs }   which layout and tabs (default below = Initial Sales)
     buildDrawerSolutionSummaryHtml(opt, draft)        "Solution Summary" tab content
     buildDrawerPriceListHtml(opt)                     "Price List" tab content */

function getDrawerLayout(opt, draft) {
  const scope = typeof openOptPromoScope !== 'undefined' ? openOptPromoScope : 'unified';
  return { unified: scope === 'unified', tabs: ['contract', 'order'] };
}

function setDrawerSummaryView(view) {
  drawerSummaryView = view === 'list-price' ? 'list-price' : 'bundle';
  const opt = options.find(o => o.id === openOptPromoPanelId);
  const summaryCol = document.getElementById('discount-matrix-summary-col');
  if (opt && optPromoDraft && summaryCol) {
    summaryCol.innerHTML = buildDrawerSummaryColHtml(opt, optPromoDraft);
  } else {
    renderOptPromoDrawer();
  }
}

function buildDrawerSummaryColHtml(opt, draft) {
  const isPriceList = drawerSummaryView === 'list-price';
  const tabsHtml = `
    <div class="tabs">
      <button type="button" class="tabs__item ${!isPriceList ? 'tabs__item--active' : ''}" onclick="setDrawerSummaryView('bundle')">Solution Summary${!isPriceList ? '<span class="tabs__indicator"></span>' : ''}</button>
      <button type="button" class="tabs__item ${isPriceList ? 'tabs__item--active' : ''}" onclick="setDrawerSummaryView('list-price')">Price List${isPriceList ? '<span class="tabs__indicator"></span>' : ''}</button>
    </div>`;
  return tabsHtml + (isPriceList ? buildDrawerPriceListHtml(opt) : buildDrawerSolutionSummaryHtml(opt, draft));
}

function renderOptPromoDrawer() {
  const body = document.getElementById('opt-promo-drawer-body');
  const titleEl = document.getElementById('opt-promo-drawer-title');
  if (!body) return;
  const opt = options.find(o => o.id === openOptPromoPanelId);
  const saveBtn = document.getElementById('opt-promo-save-btn');
  // Initial Sales only: standalone discretionary matrix (no promotions).
  if (typeof openOptPromoScope !== 'undefined' && openOptPromoScope === 'matrix') {
    if (!opt) { body.innerHTML = ''; return; }
    const optIndex = options.findIndex(o => o.id === opt.id);
    if (titleEl) setOptPromoDrawerTitle('Discretionary discount', getOptionDisplayLabel(optIndex + 1));
    if (saveBtn) saveBtn.textContent = 'Done';
    body.innerHTML = buildDiscretionaryMatrixTableHtml(opt, { showPromoColumn: false });
    return;
  }
  if (saveBtn) saveBtn.textContent = 'Save';
  const draft = optPromoDraft;
  if (!opt || !draft) { body.innerHTML = ''; return; }
  const layout = getDrawerLayout(opt, draft);
  document.getElementById('opt-promo-drawer')?.classList.toggle('vc-drawer--wide', !!layout.unified);
  const optIndex = options.findIndex(o => o.id === opt.id);
  const showBothTabs = layout.unified && layout.tabs.length > 1;
  if (titleEl) setOptPromoDrawerTitle(showBothTabs ? 'Discounts & promotions' : 'Promotions', getOptionDisplayLabel(optIndex + 1));
  if (saveBtn) saveBtn.disabled = false;
  if (!layout.unified) {
    body.innerHTML = buildOrderPromotionsTabHtml(opt, draft);
    return;
  }
  const tab = showBothTabs ? (matrixDrawerTab || 'contract') : layout.tabs[0];
  const tabContentHtml = tab === 'contract' ? buildContractPromotionsTabHtml(opt) : buildOrderPromotionsTabHtml(opt, draft);
  const tabsHtml = !showBothTabs ? '' : `
    <div class="tabs">
      <button type="button" class="tabs__item ${tab ==='contract' ? 'tabs__item--active' : ''}" onclick="setMatrixDrawerTab('contract')"><span>Account Discount</span><span class="discount-matrix-tab-sublabel">(Discretionary)</span>${tab === 'contract' ? '<span class="tabs__indicator"></span>' : ''}</button>
      <button type="button" class="tabs__item ${tab ==='order' ? 'tabs__item--active' : ''}" onclick="setMatrixDrawerTab('order')"><span>Order Discount</span><span class="discount-matrix-tab-sublabel">(Promotions)</span>${tab === 'order' ? '<span class="tabs__indicator"></span>' : ''}</button>
    </div>`;
  body.innerHTML = `
    <div class="discount-matrix-layout">
      <div class="discount-matrix-config-col">
        ${tabsHtml}
        <div class="discount-matrix-tab-panel">${tabContentHtml}</div>
      </div>
      <div class="discount-matrix-summary-col" id="discount-matrix-summary-col">
        ${buildDrawerSummaryColHtml(opt, draft)}
      </div>
    </div>
  `;
}


/* ── Phase 4 (2026-10-07): Custom Discount / Promotion table and its editing actions — shared (Initial Sales
   version). Per-row values live on each {bundleId, component} target. Contract-level → "Discount", Order-level →
   "Promotion" in the type header. Bundle (plan) rows appear when the flow's getCustomPromoTableRows returns them.
   Flow hooks: getSubscriptionRowsForOption / getCustomPromoTableRows (rows), getCustomPromoCurrentPrice(opt, row,
   level) (current price per row — default below = Initial Sales), getCustomPromoAmountForBundle (pricing). */

function getCustomPromoCurrentPrice(opt, row, level) {
  if (row.isPlan) return getCustomPromoTableRowCurrentPrice(opt, row, level);
  const pr = computeSubscriptionPriceList(opt).find(p => p.name === row.name);
  return pr ? (level === 'contract' ? (pr.listUnit - pr.tierTermUnit) : pr.msaUnit) : 0;
}

function findCustomPromotion(opt, promoId) {
  return getCustomPromotions(opt).find(p => p.id === promoId);
}

function formatCustomPromoValue(cp, rawValue) {
  const v = Number(rawValue) || 0;
  if (cp.type === 'dollar') return `-${formatMoney(v)}`;
  if (cp.type === 'target') return `${formatMoney(v)} target`;
  return `-${v}%`;
}

function makeDefaultCustomPromotion(opt, level) {
  const firstRow = getSubscriptionRowsForOption(opt)[0];
  const isContract = level === 'contract';
  return {
    id: `cp-${nextCustomPromoId++}`,
    level: isContract ? 'contract' : 'order',
    // Contract-level starts empty — its per-subscription table has no
    // pre-selected row, unlike the Order tab's single dropdown/value flow.
    targets: isContract ? [] : (firstRow ? firstRow.targets.slice() : []),
    type: 'pct',
    value: 0,
    // 2026-09-25 (per Catalina): with the standalone "Contract length"
    // button gone, a fresh Order Promotion now starts pre-selected on the
    // preset matching the contract's actual term (see
    // getDefaultPromoDurationMonths) instead of an unset 'term' mode with no
    // real month count.
    durationMode: 'months',
    durationMonths: getDefaultPromoDurationMonths(opt),
  };
}

function getCustomPromoRowValue(cp, row) {
  const targets = (cp.targets || []).filter(x => row.targets.some(rt => rt.bundleId === x.bundleId && rt.component === x.component));
  if (!targets.length || targets[0].value == null) return '';
  if (row.isPlan && (cp.type === 'dollar' || cp.type === 'target')) {
    const sum = targets.reduce((total, target) => total + (Number(target.value) || 0), 0);
    return String(Math.round(sum * 100) / 100);
  }
  return String(targets[0].value);
}

function getCustomPromoSummaryLine(opt, cp) {
  const rows = getSubscriptionRowsForOption(opt);
  const entries = rows
    .map(r => ({ name: r.name, value: getCustomPromoRowValue(cp, r) }))
    .filter(e => e.value !== '');
  if (!entries.length) return null;
  const shown = entries.slice(0, 2).map(e => `${e.name} ${formatCustomPromoValue(cp, e.value)}`);
  const extra = entries.length - shown.length;
  return shown.join(', ') + (extra > 0 ? ` +${extra} more` : '');
}

function setCustomPromotionType(optId, promoId, type) {
  const opt = options.find(o => o.id === optId);
  if (!opt) return;
  const cp = findCustomPromotion(opt, promoId);
  if (!cp) return;
  cp.type = type === 'dollar' ? 'dollar' : type === 'target' ? 'target' : 'pct';
  // 2026-09-24 (per Catalina/Leo — extended from Contract to Order the same
  // day): both levels now carry an independent value per row, so a number
  // entered as a % doesn't carry any sensible meaning as a $ amount or a
  // Target Price — clear the per-row values on any type switch rather than
  // keep stale numbers under a new label. Target Price no longer needs to
  // collapse to a single subscription at either level, since every row can
  // hold its own target now.
  cp.targets = [];
  renderOptPromoDrawer();
  renderOptions();
  if (screen === 'selection') renderSelectionOptions();
}

function setCustomPromotionDurationMonths(optId, promoId, months) {
  const opt = options.find(o => o.id === optId);
  if (!opt) return;
  const cp = findCustomPromotion(opt, promoId);
  if (!cp) return;
  cp.durationMode = 'months';
  cp.durationMonths = Math.min(Math.max(1, Number(months) || 1), Math.max(1, Number(opt.term) || 1));
  renderOptPromoDrawer();
  // 2026-09-24 (bug fix, per Catalina — "apliqué una order promo custom de
  // seis meses en una card de 36 y no veo que se aplique... el badge, y
  // tampoco veo que diga que es por seis meses"): every other custom-promo
  // setter (setCustomPromoRowValue, setCustomPromotionType, ...) also calls
  // renderOptions() so the bundle-row badge outside the drawer stays in
  // sync — this one only re-rendered the drawer itself, so a duration
  // picked without any further row edit afterward never reached the badge
  // (or its "for Nmo" suffix) until something else happened to trigger a
  // full option re-render.
  renderOptions();
  if (screen === 'selection') renderSelectionOptions();
}

function setCustomPromoRowValue(optId, promoId, rowName, rawValue) {
  const opt = options.find(o => o.id === optId);
  if (!opt) return;
  const cp = findCustomPromotion(opt, promoId);
  if (!cp) return;
  const row = getCustomPromoTableRows(opt).find(r => r.name === rowName);
  if (!row) return;
  cp.targets = (cp.targets || []).filter(t => !row.targets.some(rt => rt.bundleId === t.bundleId && rt.component === t.component));
  if (rawValue !== '') {
    const value = Math.max(0, Number(rawValue) || 0);
    if (row.isPlan && (cp.type === 'dollar' || cp.type === 'target')) {
      const currentPrice = getCustomPromoTableRowCurrentPrice(opt, row, cp.level);
      const { msaTierUnits } = calcOption(opt, getOptionPromotion(opt));
      const tierTermPct = getTierTermDiscountPct(opt.term, msaTierUnits);
      row.targets.forEach(target => {
        const bundle = opt.bundles.find(item => item.id === target.bundleId);
        const component = bundle ? getBundleComponentPrices(bundle, tierTermPct).find(item => item.name === target.component) : null;
        const componentPrice = component ? (cp.level === 'contract' ? component.afterTierTermUnit : component.msaUnit) : 0;
        cp.targets.push({ ...target, value: currentPrice > 0 ? value * (componentPrice / currentPrice) : 0 });
      });
    } else {
      row.targets.forEach(t => cp.targets.push({ ...t, value }));
    }
  }
  renderOptPromoDrawer();
  renderOptions();
  if (screen === 'selection') renderSelectionOptions();
}

function setCustomPromoAllRows(optId, promoId, rawValue) {
  const opt = options.find(o => o.id === optId);
  if (!opt) return;
  const cp = findCustomPromotion(opt, promoId);
  if (!cp) return;
  const rows = getCustomPromoTableRows(opt);
  if (rawValue === '') {
    cp.targets = [];
  } else {
    const value = Math.max(0, Number(rawValue) || 0);
    cp.targets = rows.reduce((acc, r) => acc.concat(r.targets.map(t => ({ ...t, value }))), []);
  }
  renderOptPromoDrawer();
  renderOptions();
  if (screen === 'selection') renderSelectionOptions();
}

function buildCustomPromoRowsTableHtml(opt, cp) {
  const rows = getCustomPromoTableRows(opt);
  if (!rows.length) return `<p class="text-body-small custom-promo-empty">No subscriptions configured yet.</p>`;
  const hasPlans = rows.some(row => row.isPlan);
  const isDollar = cp.type === 'dollar';
  const isTarget = cp.type === 'target';
  const isContract = cp.level === 'contract';
  const noun = isContract ? 'Discount' : 'Promotion';
  // 2026-09-24 (per Catalina — "el discount type lo podríamos manipular
  // desde la misma columna en el header... en vez de mostrar el porcentaje
  // entre paréntesis, le ponemos ahí pues como el selector"): the value
  // column's header is now the Type selector itself — a dropdown that
  // fires the same setCustomPromotionType() the old segmented control did
  // — instead of a plain label naming whichever type happens to be active.
  const valueHeaderSelectHtml = `
    <span class="custom-promo-type-select-wrap">
      <select class="select select--small custom-promo-type-select" data-vc-dropdown onchange="setCustomPromotionType(${opt.id}, '${cp.id}', this.value)">
        <option value="pct" ${!isDollar && !isTarget ? 'selected' : ''}>${noun} (%)</option>
        <option value="dollar" ${isDollar ? 'selected' : ''}>${noun} ($)</option>
        <option value="target" ${isTarget ? 'selected' : ''}>Target Price</option>
      </select>
    </span>`;
  // 2026-09-24 (per Catalina/Leo): for %, a rep can either apply one value
  // to every subscription at once (this row) or set each row individually
  // below — the two aren't mutually exclusive UI modes here like
  // Program/Custom are; "Apply to all" is just a fill-down convenience.
  // 2026-09-24, later the same day (per Catalina — "quitemos el apply all
  // cuando es un monto o un target price, solamente hagámoslo para
  // porcentaje"): $ and Target Price are inherently per-subscription
  // (different subscriptions have different current prices, so one shared $
  // or target doesn't mean the same thing across rows the way a % does) —
  // "Apply to all" is now percentage-only.
  // 2026-09-24 (bug fix, per Catalina — "cuando le pongo un descuento en
  // apply all... se me resetea y no veo que quede el número"): this field
  // never carried a `value` at all, so it always rendered blank right after
  // applying — the fill-down DID work (every row below got the number), but
  // the field itself looked like it forgot what was typed. Now it shows the
  // shared value when every row currently holds that same number, so it
  // reads as "applied," not "reset."
  const uniformRowValue = (() => {
    const vals = rows.map(r => getCustomPromoRowValue(cp, r));
    if (!vals.length || vals.some(v => v === '')) return '';
    return vals.every(v => v === vals[0]) ? vals[0] : '';
  })();
  const bulkRowHtml = (!isDollar && !isTarget) ? `
    <tr class="contract-discount-row contract-discount-row--bulk">
      <td class="sub-price-cell sub-price-cell--name">Apply to all</td>
      <td class="sub-price-cell sub-price-cell--num">—</td>
      <td class="sub-price-cell sub-price-cell--num sub-price-cell--promo">
        <span class="promo-value-input-wrap promo-value-input-wrap--suffix">
          <input type="number" class="matrix-discretionary-input promo-value-input" min="0" step="0.01" value="${uniformRowValue}" placeholder="0"
            onchange="setCustomPromoAllRows(${opt.id}, '${cp.id}', this.value)">
          <span class="promo-value-input-affix promo-value-input-affix--suffix">%</span>
        </span>
      </td>
      <td class="sub-price-cell sub-price-cell--num">—</td>
    </tr>` : '';
  const subscriptionRowHtml = (r) => {
    const currentPrice = getCustomPromoCurrentPrice(opt, r, cp.level);
    const rawValue = getCustomPromoRowValue(cp, r);
    const valuePlaceholder = isTarget ? formatMoney(currentPrice).replace(/^\$/, '') : isDollar ? '0.00' : '0';
    let afterPrice = currentPrice;
    let overCurrentPrice = false;
    if (rawValue !== '') {
      const v = Number(rawValue) || 0;
      if (isTarget) {
        overCurrentPrice = v > currentPrice + 0.005;
      } else {
        afterPrice = isDollar ? Math.max(0, currentPrice - v) : Math.max(0, currentPrice * (1 - v / 100));
      }
    }
    return `
    <tr class="contract-discount-row">
      <td class="sub-price-cell sub-price-cell--name">${r.isPlan ? formatBundleDisplayName(r.name) : r.name}</td>
      <td class="sub-price-cell sub-price-cell--num">${formatMoney(currentPrice)}</td>
      <td class="sub-price-cell sub-price-cell--num sub-price-cell--promo">
        <span class="promo-value-input-wrap ${isDollar || isTarget ?'promo-value-input-wrap--prefix' : 'promo-value-input-wrap--suffix'}">
          <input type="number" class="matrix-discretionary-input promo-value-input" min="0" step="0.01" value="${rawValue}" placeholder="${valuePlaceholder}"
            onchange="setCustomPromoRowValue(${opt.id}, '${cp.id}', '${r.name}', this.value)">
          <span class="promo-value-input-affix promo-value-input-affix--${isDollar || isTarget ?'prefix' : 'suffix'}">${isDollar || isTarget ? '$' : '%'}</span>
        </span>
        ${overCurrentPrice ? `<div class="notification notification--warning notification--inline custom-promo-over-note" role="status"><span class="material-symbols-outlined notification__icon" aria-hidden="true">warning</span><p class="notification__message">Above current price</p></div>` : ''}
      </td>
      ${isTarget ? '' : `<td class="sub-price-cell sub-price-cell--num sub-price-cell--bold">${formatMoney(afterPrice)}</td>`}
    </tr>`;
  };
  const rowsHtml = rows.map(subscriptionRowHtml).join('');
  // 2026-09-24 (per Catalina — "cuando el discount cambia a target price...
  // hacer como una transición leve del cambio de visualización de la
  // tabla... para que no se sienta como forzado"): Target Price drops the
  // "Price After" column, so the table's structure itself changes on a type
  // switch, not just cell values. Since the drawer fully replaces this
  // table's HTML on every render anyway, adding .ff-fadein (the same
  // fade+slide already used elsewhere for mode transitions in this drawer)
  // is enough to soften every re-render, structural or not.
  return `
    <table class="sub-price-table contract-discount-table ff-fadein">
      <thead>
        <tr>
          <th class="sub-price-header">${hasPlans ? 'Bundle / Subscriptions' : 'Subscription'}</th>
          <th class="sub-price-header sub-price-header--num">Current Price</th>
          <th class="sub-price-header sub-price-header--num sub-price-header--promo">${valueHeaderSelectHtml}</th>
          ${isTarget ? '' : `<th class="sub-price-header sub-price-header--num">Price After</th>`}
        </tr>
      </thead>
      <tbody>${bulkRowHtml}${rowsHtml}</tbody>
    </table>`;
}
