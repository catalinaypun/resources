/* Valu Cal — Service Order Schedule (shared modal, markup + logic)
   Same modal in Initial Sales and Existing Accounts (2026-10-07, batch 8). Source: Initial Sales.
   Flow-specific (stays in each flow): saveScheduleAndProceedContract (what Save does next),
   openContractScheduleModal / openOptionScheduleFromCard (entry points), calcOption. */
window.VC = window.VC || {};
window.VC.serviceOrderScheduleMarkup = function () {
  return "<div class=\"modal-overlay\" id=\"schedule-modal-overlay\" onclick=\"closeScheduleModal()\" style=\"z-index:5005;\">\n  <div class=\"modal modal--lg schedule-modal\" role=\"dialog\" aria-modal=\"true\" aria-labelledby=\"schedule-modal-title\" onclick=\"event.stopPropagation()\">\n    <button type=\"button\" class=\"modal__close btn-icon btn-icon--ghost-vds btn-icon--vds-large\" onclick=\"closeScheduleModal()\" aria-label=\"Close service order schedule\"><span class=\"material-symbols-outlined\" aria-hidden=\"true\">close</span></button>\n    <div class=\"modal__content modal__scroll-area\">\n    <h2 class=\"modal__title\" id=\"schedule-modal-title\">Service Order Schedule</h2>\n    <p class=\"schedule-status-text\" id=\"schedule-validation-text\">Checking order quantities...</p>\n\n    <div class=\"schedule-header-lite\">\n      <span class=\"schedule-header-lite-title\" id=\"sched-opt-name\">Option 1</span>\n      <span class=\"schedule-header-lite-subtitle\" id=\"sched-total-units\">0 units total</span>\n    </div>\n\n    <div class=\"schedule-matrix-wrap\">\n      <table class=\"schedule-matrix\" aria-label=\"Service order schedule matrix\">\n        <thead id=\"schedule-matrix-head\"></thead>\n        <tbody id=\"schedule-matrix-body\"></tbody>\n      </table>\n    </div>\n\n    <div style=\"margin-bottom:12px;\">\n      <button type=\"button\" class=\"btn-dashed-add btn-dashed-add--pill\" onclick=\"addSchedulePhaseRow()\">+ Add order</button>\n    </div>\n\n    <p class=\"schedule-disclaimer\"></p>\n\n    </div>\n    <div class=\"schedule-actions modal__actions modal__actions--fill-container\">\n      <button type=\"button\" class=\"btn btn--secondary btn--large\" onclick=\"closeScheduleModal()\">Cancel</button>\n      <button type=\"button\" class=\"btn btn--primary btn--large\" id=\"schedule-submit-btn\" onclick=\"saveScheduleAndProceedContract()\">Save</button>\n    </div>\n  </div>\n</div>";
};

const SCHEDULE_ORDER_OFFSET_OPTIONS = [30, 60, 90];
let scheduleDraft = {
  optionId: null,
  // 2026-09-28 (per Catalina / Leo's transcript): phases are scheduled as a
  // number of days after contract signature (e.g. 30, 60), not a fixed
  // calendar date — daysAfterSignature is the rep-editable field; targetDate
  // is still derived (see getSchedulePhaseTargetDate) for the few downstream
  // consumers (wave aggregation, appropriations expiry checks, contract doc)
  // that expect an absolute date.
  phases: []   // [{ id, name, daysAfterSignature, allocations: { [bundleId]: qty } }]
};

function generateScheduleOrderId() {
  return `Order ${Math.floor(1000 + Math.random() * 9000)}`;
}

function buildScheduleDefaultPhases() {
  return [
    { id: `phase-${Date.now()}-1`, name: generateScheduleOrderId(), daysAfterSignature: 0, allocations: {} }
  ];
}

function ensureSchedulePhaseModel(opt) {
  const bundles = Array.isArray(opt && opt.bundles) ? opt.bundles : [];
  const phaseBuckets = [];
  const seen = new Map();

  bundles.forEach((b) => {
    if (!Array.isArray(b.waves)) return;
    b.waves.forEach((w) => {
      const key = w.id || `${w.name || 'legacy'}|${w.targetDate || ''}`;
      let phase = seen.get(key);
      if (!phase) {
        // 2026-09-28 (per Catalina / Leo's transcript): legacy saved waves
        // stored an absolute targetDate — derive an equivalent day-offset
        // from today as a one-time migration so older data still shows a
        // sensible value in the new "days after signature" input.
        const legacyDays = w.targetDate
          ? Math.max(0, Math.round((new Date(w.targetDate + 'T00:00:00') - new Date(new Date().toDateString())) / 86400000))
          : 30;
        phase = {
          id: w.id || `legacy-phase-${phaseBuckets.length}`,
          name: w.name || generateScheduleOrderId(),
          daysAfterSignature: legacyDays,
          allocations: {}
        };
        seen.set(key, phase);
        phaseBuckets.push(phase);
      }
      phase.allocations[b.id] = Number(w.qty || 0) || 0;
    });
  });

  scheduleDraft.phases = phaseBuckets.length ? phaseBuckets : buildScheduleDefaultPhases();

  // Make sure every current bundle has an allocation entry in every phase row.
  scheduleDraft.phases.forEach((phase) => {
    bundles.forEach((b) => {
      if (phase.allocations[b.id] === undefined) phase.allocations[b.id] = 0;
    });
  });
}

function scheduleColumnAllocated(bundleId) {
  return scheduleDraft.phases.reduce((sum, phase) => sum + (Number(phase.allocations[bundleId]) || 0), 0);
}

function openScheduleModal(opt) {
  const optionNumber = Math.max(1, options.findIndex((o) => o.id === opt.id) + 1);
  const { totalUnits } = calcOption(opt, getOptionPromotion(opt));

  scheduleDraft.optionId = opt.id;
  ensureSchedulePhaseModel(opt);

  document.getElementById('sched-opt-name').textContent = getOptionDisplayLabel(optionNumber);
  document.getElementById('sched-total-units').textContent = `${totalUnits} units total`;

  const submitBtn = document.getElementById('schedule-submit-btn');
  const disclaimerEl = document.querySelector('.schedule-disclaimer');
  if (screen === 'contract-review') {
    if (submitBtn) submitBtn.textContent = 'Save and Update Contract';
    if (disclaimerEl) disclaimerEl.textContent = 'Saving will update the service order schedule in the contract agreement.';
  } else {
    // 2026-09-25 (per Catalina): this modal is now reachable from the option
    // card kebab menu at any point — well before a contract exists — so a
    // "Proceed to Contract" label (and the disclaimer explaining that it
    // locks the quoting session / starts contract generation) no longer
    // describes what this action actually does. Just "Save".
    if (submitBtn) submitBtn.textContent = 'Save';
    if (disclaimerEl) disclaimerEl.textContent = '';
  }

  renderScheduleModalContent();
  const overlay = document.getElementById('schedule-modal-overlay');
  if (overlay) overlay.classList.add('is-open');
}

function closeScheduleModal() {
  const overlay = document.getElementById('schedule-modal-overlay');
  if (overlay) overlay.classList.remove('is-open');
}

function renderScheduleModalContent() {
  renderScheduleMatrix();
  validateScheduleMatrix();
}

function renderScheduleMatrix() {
  const head = document.getElementById('schedule-matrix-head');
  const body = document.getElementById('schedule-matrix-body');
  if (!head || !body) return;

  const opt = options.find(o => o.id === scheduleDraft.optionId);
  const bundles = Array.isArray(opt && opt.bundles) ? opt.bundles : [];
  syncScheduleOrders();
  const phases = Array.isArray(scheduleDraft.phases) ? scheduleDraft.phases : [];

  const headerCells = ['<th class="table-header-cell" style="width:120px;">Order</th>', '<th class="table-header-cell" style="width:200px;">Timing</th>'];
  bundles.forEach((b) => {
    const total = Number(b.qty) || 0;
    const allocated = scheduleColumnAllocated(b.id);
    const complete = allocated === total;
    headerCells.push(`
      <th class="table-header-cell" style="min-width:110px;">
        <div class="schedule-col-header">
          <span>${escapeContractDocHtml(b.coreName || 'Solution')}</span>
          <span class="badge ${complete ?'badge--green' : 'badge--orange'}">${allocated}/${total}</span>
        </div>
      </th>
    `);
  });
  const showDeleteColumn = phases.length > 1;
  if (showDeleteColumn) headerCells.push('<th class="table-header-cell" style="width:40px;"></th>');
  head.innerHTML = `<tr>${headerCells.join('')}</tr>`;

  if (!bundles.length) {
    body.innerHTML = '<tr><td class="table-body-cell" colspan="999" style="text-align:center;color:var(--gray-500);">No solutions in this option.</td></tr>';
    return;
  }
  if (!phases.length) {
    body.innerHTML = '<tr><td class="table-body-cell" colspan="999" style="text-align:center;color:var(--gray-500);">No orders yet — add one below.</td></tr>';
    return;
  }

  body.innerHTML = phases.map((phase, idx) => {
    // 2026-09-28 (per Catalina): Phase 1's effective date isn't something a
    // rep configures — it's whenever the contract gets signed. Only Phase 2+
    // (later, planned phases) get an actual date picker.
    const dateCellHtml = buildScheduleTimingCellHtml(phase, idx);
    const rowCells = [
      `<td class="table-body-cell schedule-phase-id-cell"><span class="schedule-phase-id-label">${getScheduleOrderNumber(phase)}</span></td>`,
      dateCellHtml
    ];
    bundles.forEach((b) => {
      const value = Number(phase.allocations[b.id] || 0);
      rowCells.push(`<td class="table-body-cell"><input type="number" min="0" step="1" class="input schedule-alloc-input" value="${value}" onchange="updateScheduleAllocation('${phase.id}', ${b.id}, this.value)"></td>`);
    });
    if (showDeleteColumn) rowCells.push(`<td class="table-body-cell"><button class="btn-icon btn-icon--ghost-vds btn-icon--vds-small" type="button" aria-label="Remove order" title="Remove order" onclick="removeSchedulePhaseRow('${phase.id}')"><span class="material-symbols-outlined">close</span></button></td>`);
    return `<tr>${rowCells.join('')}</tr>`;
  }).join('');
}

function snapScheduleOrderOffset(days) {
  const value = Number(days) || 30;
  return SCHEDULE_ORDER_OFFSET_OPTIONS.reduce((best, option) => Math.abs(option - value) < Math.abs(best - value) ? option : best, 30);
}

function getScheduleOrderNumber(phase) {
  const match = /^Order (\d{6})$/.exec(phase && phase.name || '');
  return match ? match[1] : '';
}

function syncScheduleOrders() {
  let cumulative = 0;
  let previousLegacyDays = 0;
  const used = new Set(scheduleDraft.phases.map(getScheduleOrderNumber).filter(Boolean));
  scheduleDraft.phases.forEach((phase, idx) => {
    if (!getScheduleOrderNumber(phase)) {
      let number;
      do { number = String(Math.floor(100000 + Math.random() * 900000)); } while (used.has(number));
      used.add(number);
      phase.name = `Order ${number}`;
    }
    if (idx === 0) { phase.daysAfterPrevious = 0; phase.daysAfterSignature = 0; previousLegacyDays = 0; return; }
    if (!SCHEDULE_ORDER_OFFSET_OPTIONS.includes(Number(phase.daysAfterPrevious))) {
      const legacyDays = Number(phase.daysAfterSignature) || 0;
      phase.daysAfterPrevious = snapScheduleOrderOffset(legacyDays - previousLegacyDays);
      previousLegacyDays = legacyDays;
    }
    cumulative += Number(phase.daysAfterPrevious);
    phase.daysAfterSignature = cumulative;
  });
}

function buildScheduleTimingCellHtml(phase, idx) {
  if (idx === 0) return '<td class="table-body-cell"><span class="schedule-phase-date-locked">Contract sales confirmed</span></td>';
  const current = Number(phase.daysAfterPrevious) || 30;
  return `<td class="table-body-cell"><span class="schedule-phase-days-input-wrap"><select class="vds-select" aria-label="Order ${getScheduleOrderNumber(phase)} timing" onchange="updateScheduleOrderOffset('${phase.id}', this.value)">${SCHEDULE_ORDER_OFFSET_OPTIONS.map(days => `<option value="${days}" ${days === current ? 'selected' : ''}>+${days} days</option>`).join('')}</select> after order ${getScheduleOrderNumber(scheduleDraft.phases[idx - 1])}</span></td>`;
}

function updateScheduleOrderOffset(phaseId, value) {
  const phase = scheduleDraft.phases.find((p) => p.id === phaseId);
  if (!phase) return;
  phase.daysAfterPrevious = snapScheduleOrderOffset(value);
  syncScheduleOrders();
}

function addSchedulePhaseRow() {
  const opt = options.find(o => o.id === scheduleDraft.optionId);
  const bundles = Array.isArray(opt && opt.bundles) ? opt.bundles : [];
  const nextIndex = scheduleDraft.phases.length + 1;
  const allocations = {};
  bundles.forEach((b) => { allocations[b.id] = 0; });
  scheduleDraft.phases.push({
    id: `phase-${Date.now()}-${nextIndex}`,
    name: generateScheduleOrderId(),
    daysAfterPrevious: 30,
    daysAfterSignature: 30,
    allocations
  });
  renderScheduleModalContent();
}

function removeSchedulePhaseRow(phaseId) {
  if (scheduleDraft.phases.length <= 1) return;
  scheduleDraft.phases = scheduleDraft.phases.filter((phase) => phase.id !== phaseId);
  renderScheduleModalContent();
}

function updateScheduleAllocation(phaseId, bundleId, value) {
  const phase = scheduleDraft.phases.find((p) => p.id === phaseId);
  if (!phase) return;
  phase.allocations[bundleId] = Number(value) || 0;
  renderScheduleModalContent();
}

function validateScheduleMatrix() {
  const bundles = Array.isArray(options.find(o => o.id === scheduleDraft.optionId)?.bundles) ? options.find(o => o.id === scheduleDraft.optionId).bundles : [];
  const allComplete = bundles.length > 0 && bundles.every((b) => {
    const total = Number(b.qty) || 0;
    return scheduleColumnAllocated(b.id) === total;
  });

  const textEl = document.getElementById('schedule-validation-text');
  const submitBtn = document.getElementById('schedule-submit-btn');

  // 2026-09-25 (per Catalina — "el save de este modal tiene que estar activo
  // en cualquier momento porque puedes adelantar un scheduling y guardarlo y
  // después continuar"): Save is no longer gated on every bundle being fully
  // allocated. A rep can partially schedule an option, save that progress,
  // and come back to finish it later — the status text below still reflects
  // completion, it just no longer blocks saving.
  if (submitBtn) submitBtn.disabled = false;
  if (textEl) textEl.textContent = allComplete
    ? 'All solutions are fully scheduled.'
    : 'Complete the order quantities so each solution totals its committed units, or save now and continue later.';
}

function escapeContractDocHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
