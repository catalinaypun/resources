/* \u2500\u2500 Existing Accounts mode for the unified file (2026-10-09) \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
   Migration step 1 (homologation-map.md): everything Existing Accounts has, in the single file.
   \u2022 Existing-only state and functions (transaction forms, Renewal / Rewrap, Cancel MC, non-renewal,
     account price list\u2026) \u2014 moved verbatim from ExistingAccounts/index.html; no name clashes.
   \u2022 EXISTING_ACCOUNTS_OVERRIDES \u2014 the Existing version of each step that differs from Initial Sales.
     setExistingAccountsMode(true) swaps them in for a customer scenario and restores the Initial Sales
     ones otherwise. Each entry is a convergence TODO: once merged into one shared function with account
     variables (homologation-map.md \u00a72\u2013\u00a74), it is deleted from this list.
   Loaded by Unified/index.html after the shared modules (needs vc-existing-accounts.js). */

// \u2500\u2500 Existing-only state \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
let selectedSubIds = new Set();
let txPreselectedSubIds = [];
let upsellViewMode  = 'vehicle';
let cancelViewMode  = 'vehicle';
let vzUpsellPreSelected = [];
let vzUpsellPreSelectedFeatures = [];
let vzReactivationPreSelected = [];
let upsellMode = 'vehicles';
let vzSubFilter = { products: [], statuses: [] };
let selectedTxTypeVZ = null;
let vzUpsellDiscountPct = 0;
let accountPriceListGroupBy = 'subscription';
let accountPriceListModalOptId = null;
const ELIGIBLE_SUBSCRIPTION_ROW_NAMES = new Set(['Vehicle Tracking', 'Forward Facing Camera Subscription', 'Dual Camera Subscription']);
const DEMO_PREVIOUSLY_DEACTIVATED_UNITS = [
  { id: 'deact-1', coreKey: 'vtu-ffc', coreName: 'VTU + Forward Facing Camera', qty: 3, deactivatedDate: '2026-08-01', reason: 'downgrade' },
  { id: 'deact-2', coreKey: 'asset-powered', coreName: 'Powered Asset', qty: 2, deactivatedDate: '2026-07-15', reason: 'cancellation' },
];
const HARDWARE_VALUES = {
  'vtu': 150.00,
  'vtu-ffc': 220.00,
  'vtu-dual': 280.00,
  'asset-powered': 120.00,
  'asset-nonpowered': 90.00,
};
const HARDWARE_RETURN_WINDOW_DAYS = 30;
const CANCEL_PENALTY_WAVES = [
  { id: 'loyalty', name: 'Loyalty Wave \u2014 25% off', pct: 25 },
  { id: 'retention', name: 'Retention Wave \u2014 50% off', pct: 50 },
  { id: 'hardship', name: 'Hardship Wave \u2014 100% waived', pct: 100 },
];
const VZ_UPSELL_FEATURES = [
  // Video Features
  { key: 'ffc',      label: 'Forward Facing Camera',      price: 30.00, category: 'video' },
  { key: 'dual',     label: 'Dual Camera Subscription',   price: 40.00, category: 'video' },
  { key: 'evc',      label: 'Extended View Cameras',      price: 15.00, category: 'video' },
  { key: 'monitor',  label: 'In-Cab Monitor',             price: 12.00, category: 'video' },
  { key: 'adas',     label: 'ADAS',                       price:  5.00, category: 'video' },
  { key: 'sd',       label: '256 GB SD Card',             price:  5.00, category: 'video' },
  // Vehicle Features
  { key: 'eld',      label: 'Electronic Logging (ELD)',   price: 15.00, category: 'vehicle' },
  { key: 'driverid', label: 'Driver ID',                  price:  2.00, category: 'vehicle' },
  { key: 'logbook',  label: 'Logbook',                    price:  3.00, category: 'vehicle' },
  { key: 'privacy',  label: 'Privacy Button',             price:  1.00, category: 'vehicle' },
];
const vzProductLabels = {
  'vts':   'Vehicle Tracking (VTS)',
  'pat':   'Powered Asset (PAT)',
  'npat':  'Non-Powered Asset (NPAT)',
  'ffc':   'Forward Facing Camera',
  'dual':  'Dual Camera Subscription',
  'adas':  'ADAS Camera',
  'sd':    'SD Card Upgrade',
  'driverid': 'Driver ID',
  'eld':   'Electronic Logging (ELD)',
  'rsa':   'Roadside Assistance',
  'monitor': 'In-Cab Monitor',
  'evc':   'Extended View Cameras',
  'privacy': 'Privacy Button',
  'logbook': 'Logbook',
};
const VZ_UPSELL_FEATURE_TO_CATALOG_KEY = { driverid: 'driver-id' };
const VZ_UPSELL_CORE_ALIAS = { ffc: 'vtu-ffc', dual: 'vtu-dual' };
const VZ_UPSELL_CORE_RANK = { vtu: 0, 'vtu-ffc': 1, 'vtu-dual': 2 };

// \u2500\u2500 Existing-only functions \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
function getTierEligibilityQty(totalUnits) {
  const qty = Number(totalUnits || 0);
  const minimumCommitment = Number(DEMO_MSA.minQuantityCommitment || 0);
  if (minimumCommitment > 0) {
    return Math.max(qty, minimumCommitment);
  }
  return qty;
}

function getApplicableTierIndex(totalUnits) {
  return getNaturalTierIndex(getTierEligibilityQty(totalUnits));
}

function matchPrebuiltTierForCombo(coreKey, featureKeys) {
  const sorted = [...featureKeys].sort();
  for (const bundleKey of Object.keys(PREBUILT_BUNDLES)) {
    const bundle = PREBUILT_BUNDLES[bundleKey];
    for (const tier of bundle.tiers) {
      if (tier.coreKey !== coreKey) continue;
      const tierSorted = [...(tier.includedFeatures || [])].sort();
      if (tierSorted.length === sorted.length && tierSorted.every((f, i) => f === sorted[i])) {
        return { bundleKey, bundle, tier };
      }
    }
  }
  return null;
}

function findClosestPrebuiltTier(coreKey, featureKeys) {
  const exact = matchPrebuiltTierForCombo(coreKey, featureKeys);
  if (exact) return exact;
  const targetSet = new Set(featureKeys);
  let best = null;
  let bestScore = -Infinity;
  Object.keys(PREBUILT_BUNDLES).forEach((bundleKey) => {
    const bundle = PREBUILT_BUNDLES[bundleKey];
    bundle.tiers.forEach((tier) => {
      const tierSet = new Set(tier.includedFeatures || []);
      const shared = [...tierSet].filter((f) => targetSet.has(f)).length;
      const differing = [...tierSet].filter((f) => !targetSet.has(f)).length
        + [...targetSet].filter((f) => !tierSet.has(f)).length;
      const coreMatchScore = tier.coreKey === coreKey ? 100 : 0;
      const score = coreMatchScore + shared * 2 - differing;
      if (score > bestScore) {
        bestScore = score;
        best = { bundleKey, bundle, tier };
      }
    });
  });
  return best;
}

function isOptionTierLocked(opt) {
  return !!opt && opt.transactionMode !== 'Rewrap' && opt.transactionMode !== 'Reactivation';
}

function getAccountMsaTierUnits() {
  return sumMsaTierQty((Array.isArray(existingOrders) ? existingOrders : []).flatMap(order => order.bundles || []));
}

function getActiveCustomPromotionsForPricing(opt, level) {
  if (!opt) return [];
  const isNewProposalChange = opt.transactionMode === 'Change' && proposalData.entryPoint === 'newProposal';
  const isRenewalRewrap = isSpecialOptionMode(opt);
  if (!isNewProposalChange && !isRenewalRewrap) return [];
  return getCustomPromotions(opt).filter(promotion => {
    if (!customPromoHasAnyValue(promotion)) return false;
    if (isNewProposalChange && promotion.level !== 'order') return false;
    return !level || promotion.level === level;
  });
}

function isSpecialOptionMode(opt) {
  return opt?.transactionMode === 'Renewal' || opt?.transactionMode === 'Rewrap';
}

function getDefaultEffectiveDate(mode) {
  if (mode === 'Renewal') {
    const endDate = parseProposalDate(DEMO_MSA.endDate);
    return endDate ? toIsoDate(addCalendarDays(endDate, 1)) : toIsoDate(new Date());
  }
  const today = new Date();
  return toIsoDate(new Date(today.getFullYear(), today.getMonth() + 1, 1));
}

function setOptionTransactionMode(id, mode) {
  const opt = options.find(o => o.id === id);
  if (!opt) return;
  opt.transactionMode = mode;
  // 2026-09-18 (R21.3, per Catalina): only Rewrap carries an effective date \u2014
  // Renewal (like Change) doesn't use one at all.
  if (mode === 'Change' || mode === 'Renewal') {
    opt.effectiveDate = '';
    opt.reason = '';
  } else if (!opt.effectiveDate || opt.effectiveDate < getDefaultEffectiveDate(mode)) {
    opt.effectiveDate = getDefaultEffectiveDate(mode);
  }
  renderOptions();
}

function renderOptionHeaderControls(opt) {
  // 2026-09-18 (R21.2, per Catalina): the Transaction control only exists
  // inside the Renewal/Rewrap flow, with exactly two choices (Renewal /
  // Rewrap) \u2014 "Create new proposal" cards never show this control at all,
  // because they only ever represent a single punctual change, not a choice
  // between renewing or rewrapping the whole contract.
  if (proposalData.entryPoint !== 'renewalRewrap' || opt.transactionMode === 'Reactivation') return '';
  const mode = (opt.transactionMode === 'Rewrap') ? 'Rewrap' : 'Renewal';
  // 2026-09-18 (per Catalina, replacing a toggle-switch attempt from earlier
  // this session): a segmented control keeps both option names visible at
  // all times, so there's no ambiguity about which mode "off" represents \u2014
  // see CSS comment above .segmented-pill's former local rules for the accepted tradeoff if a
  // third transaction type is added later.
  return `<div class="option-header-controls">
    <div class="segmented-pill segmented-pill--on-dark" role="group" aria-label="Transaction type">
      <button type="button" class="segmented-pill__btn ${mode ==='Rewrap' ? 'is-active' : ''}" aria-pressed="${mode === 'Rewrap'}" onclick="setOptionTransactionMode(${opt.id}, 'Rewrap')">Rewrap</button>
      <button type="button" class="segmented-pill__btn ${mode ==='Renewal' ? 'is-active' : ''}" aria-pressed="${mode === 'Renewal'}" onclick="setOptionTransactionMode(${opt.id}, 'Renewal')">Renewal</button>
    </div>
  </div>`;
}

function openOptionListPriceFromCard(optId) {
  const opt = options.find(option => option.id === optId);
  if (!opt || !opt.bundles.length) return;
  const optionIndex = options.findIndex(option => option.id === optId);
  const titleEl = document.getElementById('sub-price-list-modal-title');
  const bodyEl = document.getElementById('sub-price-list-modal-body');
  if (titleEl) titleEl.textContent = `List Price \u2014 Option ${Math.max(1, optionIndex + 1)}`;
  if (bodyEl) bodyEl.innerHTML = buildAccountPriceListHtml(opt, 'modal');
  document.getElementById('sub-price-list-modal-overlay')?.classList.add('is-open');
}

function renderOptionMotionControls(opt, termFieldHtml) {
  const mode = opt.transactionMode || 'Change';
  const defaultDate = getDefaultEffectiveDate(mode);
  const discount = getOptionDiscountPct(opt, opt.bundles[0]);
  const editable = isSpecialOptionMode(opt);
  if (!editable || mode === 'Reactivation') return '';
  if (mode === 'Rewrap') opt.effectiveDate = defaultDate;
  const termCellHtml = termFieldHtml || '<div></div>';
  // 2026-10-02 (per Catalina \u2014 Renewal / Rewrap use exactly the same model as
  // Initial Sales): the inline Discretionary Discount bar is replaced by the
  // single "Discounts & Promotions" button, which opens the shared drawer
  // with its MSA Discount (Discretionary) and Order Discount (Promotions)
  const discountBodyHtml = `<button type="button" class="btn btn--secondary btn--large btn-discounts-promotions" onclick="toggleOptPromoPanel(${opt.id})"><span class="material-symbols-outlined">sell</span> Discounts &amp; Promotions</button>`;
  return `<div class="opt-term-discount-row">
    <div class="opt-term-cell">${termCellHtml}</div>
    <div class="opt-discount-cell">${discountBodyHtml}</div>
  </div>`;
}

function buildAccountSetupPricingPayload() {
  const mapLineItem = (b, opt, status) => {
    const promoType = b.promoType || getOptionPromotion(opt);
    let netPrice = null;
    try {
      netPrice = calcBundle(b, opt.term, promoType).unitPrice;
    } catch (_) { /* leave null if a bundle is mid-configuration and missing fields */ }
    return {
      product: b.coreName,
      discretionaryDiscountPct: (typeof b.msaDiscountPct === 'number') ? b.msaDiscountPct : null,
      term: parseInt(opt.term) || null,
      qty: b.qty,
      listPrice: getStandardUnitPrice(b),
      netPrice,
      optionName: opt.name,
      optionId: opt.id,
      status, // 'Existing' (already under contract) or 'New' (being drafted in this session)
    };
  };

  // Account level = everything already contracted (existingOrders, seeded
  // above) PLUS whatever new order(s) are being drafted right now (options).
  const existingLineItems = existingOrders.flatMap(opt => (opt.bundles || []).map(b => mapLineItem(b, opt, 'Existing')));
  const draftLineItems = options.flatMap(opt => (opt.bundles || []).map(b => mapLineItem(b, opt, 'New')));
  const accountLineItems = [...existingLineItems, ...draftLineItems];

  // Order level: if the rep is actively drafting a new order in this session
  // (bld.selectedOptionId set), show that. Otherwise, per Catalina (2026-09-16):
  // don't model a second, empty "order" as if it already existed \u2014 an order
  // isn't really created until the contract process finishes, so there's
  // nothing real to show for it yet. Default to the one order that DOES
  // already exist (existingOrders[0]) instead of an empty state, so the demo
  // always shows something real rather than "(no order selected)".
  const draftOpt = options.find(o => o.id === bld.selectedOptionId) || null;
  const currentOpt = draftOpt || existingOrders[0] || null;
  const currentOptStatus = draftOpt ? 'New' : 'Existing';
  const orderLineItems = currentOpt ? (currentOpt.bundles || []).map(b => mapLineItem(b, currentOpt, currentOptStatus)) : [];

  return {
    account: { lineItems: accountLineItems },
    order: {
      id: currentOpt ? currentOpt.id : null,
      name: currentOpt ? currentOpt.name : null,
      lineItems: orderLineItems,
    },
  };
}

function sendAccountSetupPricingData(frame) {
  if (!frame) return;
  const send = () => {
    try {
      // 2026-09-21 (per Catalina): also push the current auto-renewal state
      // so Account Setup reflects it on open \u2014 e.g. after "Disable
      // auto-renewal" is used from the MSA kebab, Account Setup should show
      // "No" (with reason/file) instead of defaulting back to "Yes".
      frame.contentWindow.postMessage({
        type: 'account-setup-pricing-data',
        ...buildAccountSetupPricingPayload(),
        msaAutoRenewal: DEMO_MSA.autoRenewalEnabled === false ? 'no' : 'yes',
        msaAutoRenewalReason: DEMO_MSA.autoRenewalCancellation?.reason || '',
        msaAutoRenewalFileName: DEMO_MSA.autoRenewalCancellation?.fileName || '',
        msaEndDate: DEMO_MSA.endDate,
      }, '*');
    } catch (_) { /* cross-origin under file:// \u2014 same known limitation as the close handshake */ }
  };
  // The iframe may already be loaded (re-opening the overlay) or still loading
  // (first open) \u2014 cover both rather than guessing which applies.
  send();
  frame.addEventListener('load', send, { once: true });
}

function openAccountSetupEntry() {
  const overlay = document.getElementById('account-setup-embed-overlay');
  const frame = document.getElementById('account-setup-embed-frame');
  if (!overlay || !frame) return;

  const params = new URLSearchParams({
    section: 'msa',
    msaSubscription: proposalData.msaSubscription,
    msaMinimumSpendCommitment: proposalData.msaMinimumSpendCommitment,
    msaTermStart: proposalData.msaTermStart,
    msaContractTerm: proposalData.msaContractTerm,
    msaServiceOrderTerm: proposalData.msaServiceOrderTerm,
    msaRampUpPeriod: proposalData.msaRampUpPeriod,
    msaDiscretionaryDiscountPct: proposalData.msaDiscretionaryDiscountPct,
  });
  frame.setAttribute('src', `app/demos/account-setup.html?${params.toString()}`);
  sendAccountSetupPricingData(frame);
  overlay.classList.add('is-open');
  document.body.style.overflow = 'hidden';
}

function _resetBundleTxTypeStep() {
  ['same-as-current','upsell','add','cancel','reactivate'].forEach(t => {
    const card = document.getElementById('tx-card-' + t);
    if (card) card.classList.remove('selected');
  });
  const btn = document.getElementById('btn-tx-type-continue');
  if (btn) { btn.disabled = true; btn.style.opacity = '0.4'; btn.style.cursor = 'not-allowed'; }
  bld.txType = null;
  // 2026-09-18 (R21.2, per Catalina): "Same as Current" only makes sense when
  // creating a brand-new option ("+ Add option", bld.targetOptId is null)
  // while inside the Renewal/Rewrap flow \u2014 that's the only place a whole
  // extra full-mirror-of-Current option is meaningful.
  // 2026-09-18 (correction, per Catalina \u2014 live-testing review): the original
  // condition only checked entryPoint, so it still showed "Same as Current"
  // from "+ Add modification" WITHIN an already-existing Renewal/Rewrap
  // option \u2014 but that option already IS the full mirror of Current, and
  // selecting "Same as Current" there doesn't add anything to it; it silently
  // spawns a whole separate new option instead, which is confusing. Now also
  // gated on bld.targetOptId being null (a brand-new option), not just on
  // entryPoint \u2014 so it's hidden for every "+ Add modification" call
  // regardless of entry point, and only ever shown from "+ Add option".
  const sameAsCurrentCard = document.getElementById('tx-card-same-as-current');
  if (sameAsCurrentCard) {
    const isNewOption = bld.targetOptId === null || bld.targetOptId === undefined;
    sameAsCurrentCard.classList.toggle('hidden', !isNewOption || proposalData.entryPoint !== 'renewalRewrap');
  }
  const cancelCardLabel = document.querySelector('#tx-card-cancel .tx-type-card-name');
  const targetOption = bld.targetOptId ? options.find(option => option.id === bld.targetOptId) : null;
  if (cancelCardLabel) cancelCardLabel.textContent = targetOption?.transactionMode === 'Reactivation' ? 'Reduce scope' : 'Cancel / Downgrade';
  // Per Leo (MSA Process Workshop, 2026-09-21): "if they have never
  // cancelled anything then they don't have anything to reactivate. So we
  // will not list it here" \u2014 the card only ever appears when the mock has
  // at least one previously deactivated unit for this account.
  const reactivateCard = document.getElementById('tx-card-reactivate');
  if (reactivateCard) {
    reactivateCard.classList.toggle('hidden', !(DEMO_PREVIOUSLY_DEACTIVATED_UNITS.length > 0));
  }
}

function selectBundleTxType(type) {
  ['same-as-current','upsell','add','cancel','reactivate'].forEach(t => {
    const card = document.getElementById('tx-card-' + t);
    if (card) card.classList.toggle('selected', t === type);
  });
  bld.txType = type;
  const btn = document.getElementById('btn-tx-type-continue');
  if (btn) { btn.disabled = false; btn.style.opacity = '1'; btn.style.cursor = 'pointer'; }
}

function eaNormalizeExpansionBundle(bundle) {
  if (!bundle) return bundle;
  const isPrebuilt = bundle.isPrebuilt ?? !!bundle.prebuiltBundleKey;
  return { ...bundle, isPrebuilt, bundleKey: bundle.bundleKey || bundle.prebuiltBundleKey || null, tierKey: bundle.tierKey || bundle.prebuiltTierKey || null };
}

function eaExpansionDiscountPct(optId) {
  const opt = optId ? options.find(o => o.id === optId) : null;
  if (opt && opt.discretionaryDiscountPct != null) return Number(opt.discretionaryDiscountPct) || 0;
  return Number(proposalData.msaDiscretionaryDiscountPct) || 0;
}

function eaOpenExpansionForm(optId, bundle) {
  if (bundle) csLoadBundle(optId, eaNormalizeExpansionBundle(bundle));
  else csResetForm(optId);
  bld.msaDiscountPct = eaExpansionDiscountPct(optId);
  bld._msaDiscountInitialized = true;
  const btnCreate = document.getElementById('btn-create');
  if (btnCreate) btnCreate.innerText = bundle ? 'Update Expansion' : 'Add Expansion';
  const term = optId ? (options.find(o => o.id === optId)?.term || 36) : 36;
  const termBadge = document.getElementById('preview-term-badge');
  if (termBadge) termBadge.innerText = `${term} month term contract`;
  renderPlanModeUI(term);
  syncBundleModeToggle(term);
  updateBundlePreview();
}

function confirmBundleTxType() {
  if (!bld.txType) return;
  if (bld.txType === 'same-as-current') {
    window.duplicateCurrentAsOption();
    closeBundleModal();
    return;
  }
  // Renewal/Rewrap operates on a full mirror of Current so R22 can match and
  // move real units. Create New Proposal keeps an isolated card instead: the
  // picker still reads the real contract, but only the transaction line is
  // placed in the visible option (R21.9).
  if (proposalData.entryPoint !== 'renewalRewrap' && !bld.targetOptId && (bld.txType === 'upsell' || bld.txType === 'cancel' || bld.txType === 'reactivate')) {
    const isolated = window.createEmptyTransactionOption(bld.txType);
    if (isolated) bld.targetOptId = isolated.id;
  }
  if (proposalData.entryPoint === 'renewalRewrap' && bld.txType === 'cancel' && !bld.targetOptId) {
    const seeded = window.createOptionFromCurrent();
    if (seeded) bld.targetOptId = seeded.id;
  }
  if (proposalData.entryPoint === 'renewalRewrap' && !bld.targetOptId && (bld.txType === 'upsell' || bld.txType === 'reactivate')) {
    const seeded = window.createOptionFromCurrent();
    if (seeded) bld.targetOptId = seeded.id;
  }
  const labels = { upsell: 'Feature Upsell', add: 'Expansion', cancel: 'Cancel / Downgrade', reactivate: 'Reactivate' };
  document.getElementById('bundle-modal-title').innerText = labels[bld.txType] || 'Configure Solution';
  document.getElementById('bundle-step-tx-type').style.display = 'none';
  document.getElementById('bundle-step-configure').style.display = 'flex';
  document.querySelector('.bundle-mode-toggle')?.classList.toggle('hidden', bld.txType !== 'add');

  const modal = document.querySelector('#bundle-overlay .bundle-modal');
  if (modal) {
    modal.classList.remove('modal--md', 'bundle-modal--compact');
    modal.classList.add('modal--lg');
    modal.classList.toggle('bundle-modal--configure-solution', bld.txType === 'add');
    modal.classList.toggle('bundle-modal--transaction', bld.txType !== 'add');
    modal.classList.add('bundle-modal--summary-shell');
  }
  const panelTx  = document.getElementById('bundle-panel-tx');
  const panelAdd = document.getElementById('bundle-panel-add');

  if (bld.txType === 'add') {
    // Show original Configure Bundle form
    if (modal) modal.classList.remove('bundle-modal--wide');
    panelTx.style.display  = 'none';
    panelAdd.style.display = 'flex';
    const existingExpansion = bld.targetOptId && bld.targetBundleId
      ? options.find(option => option.id === bld.targetOptId)?.bundles.find(bundle => bundle.id === bld.targetBundleId)
      : null;
    eaOpenExpansionForm(bld.targetOptId, existingExpansion?.isolatedTransactionType === 'add' ? existingExpansion : null);
  } else {
    // Show dynamic TX form (upsell / cancel)
    if (modal) modal.classList.toggle('bundle-modal--wide', true);
    panelAdd.style.display = 'none';
    panelTx.style.display  = 'flex';
    selectedTxTypeVZ = bld.txType;
    // Always reset the footer's left action to Cancel when (re)opening this
    // panel fresh \u2014 Upsell's step 2 swaps it to Back, which must not leak
    // into a new Cancel/Reactivate form or a fresh Upsell session.
    const cancelBackBtnReset = document.getElementById('gc-tx-cancel-back-btn');
    if (cancelBackBtnReset) { cancelBackBtnReset.textContent = 'Cancel'; cancelBackBtnReset.onclick = closeBundleModal; }
    if (bld.txType === 'upsell') {
      renderVZUpsellForm();
    }
    else if (bld.txType === 'cancel') renderVZCancelForm();
    else if (bld.txType === 'reactivate') renderVZReactivationForm();
  }
}

function escapeHtml(value) {
  return String(value == null ? '' : value).replace(/[&<>"']/g, function (ch) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch];
  });
}

function buildUnifiedOrderPromoDraft(opt) {
  const coreKeys = [...new Set(opt.bundles.map(bundle => bundle.coreKey))];
  const groupsByCore = getGroupsByCore(opt, coreKeys);
  const { tierQty: msaTierUnits } = calcOption(opt, getOptionPromotion(opt));
  const packages = getOptionPromoPackages(opt, coreKeys, groupsByCore, msaTierUnits);
  const currentCombo = {}, currentDealClosers = {};
  coreKeys.forEach(coreKey => {
    const first = groupsByCore[coreKey][0];
    currentCombo[coreKey] = { promoType: (first && first.promoType) || 'Standard', promoName: (first && first.promoName) || '' };
    currentDealClosers[coreKey] = (first && first.dealCloser) || '';
  });
  const { selectedKey, customEntry } = resolveSelectionForCombo(opt, coreKeys, groupsByCore, packages, currentCombo, currentDealClosers, msaTierUnits);
  const custom = {};
  coreKeys.forEach(coreKey => {
    custom[coreKey] = selectedKey === 'custom' && customEntry
      ? { ...customEntry.combo[coreKey], dealCloser: customEntry.dealClosers[coreKey] || '' }
      : packages[selectedKey]
        ? { ...packages[selectedKey].combo[coreKey], dealCloser: '' }
        : { promoType: 'Standard', promoName: '', dealCloser: '' };
  });
  opt.orderPromoMode = 'packages';
  return { mode: 'unified', coreKeys, packages, customEntry, selectedKey, custom };
}

function getOrderPromotionComponents(bundle) {
  const featureKeys = bundle.features || [];
  const featureTotal = featureKeys.reduce((sum, key) => sum + (featurePricing[key] || 0), 0);
  const coreInfo = corePricing[bundle.coreKey];
  const corePrice = Number.isFinite(Number(bundle.baseCorePrice))
    ? Number(bundle.baseCorePrice)
    : Math.max(0, (Number(bundle.basePrice) || 0) - featureTotal);
  // 2026-10-02 (per Catalina \u2014 same breakdown as Initial Sales): the VTU core
  // reads as "Vehicle Tracking", and a VTU + Forward Facing Camera / VTU +
  // Dual Camera bundle splits into its two subscriptions (camera priced as the
  // delta over VTU only), exactly like New Accounts' getBundleComponentPrices.
  // Only those two bundles combine two subscriptions; every other core stays
  // one row.
  const vtuBase = corePricing['vtu']?.price || 0;
  const cameraNameByCore = { 'vtu-ffc': 'Forward Facing Camera Subscription', 'vtu-dual': 'Dual Camera Subscription' };
  const components = (cameraNameByCore[bundle.coreKey] && vtuBase > 0)
    ? [
        { name: 'Vehicle Tracking', listUnit: vtuBase },
        { name: cameraNameByCore[bundle.coreKey], listUnit: Math.max(0, corePrice - vtuBase) },
      ]
    : [{
        name: bundle.coreKey === 'vtu' ? 'Vehicle Tracking' : (bundle.coreName || coreInfo?.name || bundle.coreKey),
        listUnit: corePrice,
      }];
  featureKeys.forEach(key => components.push({
    name: featureLabels[key] || key,
    listUnit: featurePricing[key] || 0,
  }));
  const remainder = (Number(bundle.basePrice) || 0) - components.reduce((sum, item) => sum + item.listUnit, 0);
  if (components.length) components[0].listUnit += remainder;
  return components;
}

function getDrawerSummaryOption(opt) {
  return { ...opt, bundles: opt.bundles.filter(bundle => bundle.isolatedTransactionType !== 'cancel') };
}

function computeAccountPriceList(opt) {
  const rows = [];
  const currentBundles = existingOrders.flatMap(order => order.bundles || []);
  const accountMsaTierUnits = sumMsaTierQty(currentBundles);
  const accountMsaTermMonths = DEMO_MSA?.termMonths || existingOrders[0]?.term || 36;
  const historicalTierTermPct = getTierTermDiscountPct(accountMsaTermMonths, accountMsaTierUnits);
  existingOrders.forEach(order => (order.bundles || []).forEach(bundle => {
    const listUnit = Number(bundle.basePrice) || 0;
    const discretionaryPct = Number(bundle.msaDiscountPct) || 0;
    const priceBreakdown = VC.priceListUnitBreakdown({ listUnit, tierTermPct: historicalTierTermPct, discretionaryPct });
    rows.push({ bundle, name: bundle.coreName || corePricing[bundle.coreKey]?.name || bundle.coreKey, source: 'existing', billingModel: bundle.billingModel === 'capex' ? 'capex' : 'opex', qty: bundle.qty, eligibleQty: eligibleComponentsCountForCore(bundle.coreKey) * bundle.qty, listUnit, tierTermUnit: priceBreakdown.tierTermUnit, tierTermPct: historicalTierTermPct, discretionaryUnit: priceBreakdown.afterTierTermUnit * discretionaryPct / 100, msaUnit: priceBreakdown.msaUnit, oneTimeUnit: bundle.billingModel === 'capex' ? getEstimatedHardwareUnitPrice(bundle) : 0 });
  }));
  const { tierQty, term } = calcOption(opt, getOptionPromotion(opt));
  opt.bundles.forEach(bundle => {
    const discretionaryPct = getOptionDiscountPct(opt, bundle);
    const calc = calcBundle({ ...bundle, msaDiscountPct: discretionaryPct, promoName: '' }, term, 'Standard', tierQty);
    const isIsolatedCancel = bundle.isMsaAuxiliary && bundle.isolatedTransactionType === 'cancel';
    const listUnit = Number(bundle.basePrice) || 0;
    // 2026-10-02: contract-level Custom Discount (Renewal / Rewrap) lowers MSA Price.
    const contractCustomUnit = getCustomPromoAmountForBundle(bundle, getActiveCustomPromotionsForPricing(opt, 'contract'), 0, calc.unitPrice);
    const tierTermPct = calc.tierTermPct || 0;
    const priceBreakdown = VC.priceListUnitBreakdown({
      listUnit,
      tierTermPct,
      discretionaryPct,
      msaUnitOverride: isIsolatedCancel ? calc.unitPrice : Math.max(0, calc.unitPrice - contractCustomUnit),
    });
    rows.push({ bundle, name: bundle.coreName || corePricing[bundle.coreKey]?.name || bundle.coreKey, source: 'proposal', billingModel: bundle.billingModel === 'capex' ? 'capex' : 'opex', qty: bundle.qty, eligibleQty: eligibleComponentsCountForCore(bundle.coreKey) * bundle.qty, listUnit, tierTermUnit: priceBreakdown.tierTermUnit, tierTermPct, discretionaryUnit: priceBreakdown.afterTierTermUnit * discretionaryPct / 100, msaUnit: priceBreakdown.msaUnit, oneTimeUnit: bundle.billingModel === 'capex' ? getEstimatedHardwareUnitPrice(bundle) : 0 });
  });
  return rows;
}

function splitPriceListRowBySubscription(row) {
  const components = getOrderPromotionComponents(row.bundle);
  if (components.length === 1) return [{
    ...row,
    name: components[0].name,
    eligibleQty: ELIGIBLE_SUBSCRIPTION_ROW_NAMES.has(components[0].name) ? row.qty : 0,
  }];
  if (!components.length) return [row];

  const totalListCents = Math.round(row.listUnit * 100);
  const totalMsaCents = Math.round(row.msaUnit * 100);
  let allocatedListCents = 0;
  let allocatedMsaCents = 0;
  return components.map((component, index) => {
    const isLast = index === components.length - 1;
    const listCents = isLast ? totalListCents - allocatedListCents : Math.round(component.listUnit * 100);
    const msaCents = isLast ? totalMsaCents - allocatedMsaCents : Math.round(totalMsaCents * listCents / totalListCents);
    allocatedListCents += listCents;
    allocatedMsaCents += msaCents;
    return {
      ...row,
      name: component.name,
      listUnit: listCents / 100,
      msaUnit: msaCents / 100,
      eligibleQty: ELIGIBLE_SUBSCRIPTION_ROW_NAMES.has(component.name) ? row.qty : 0,
      hardwareName: row.name,
      oneTimeUnit: isLast ? row.oneTimeUnit : 0,
    };
  });
}

function buildAccountPriceListHtml(opt, context = 'modal') {
  // Subscription rows split combined vehicle/camera bundles. Capex hardware
  // remains a single, bundle-level row after its final subscription.
  const rows = computeAccountPriceList(opt).flatMap(splitPriceListRowBySubscription);
  if (!rows.length) return `<p class="text-body-small" style="color:var(--gray-600);">No subscriptions on this MSA yet.</p>`;
  const showOneTime = accountBillingModel === 'both';
  const colspan = showOneTime ? 6 : 5;
  const renderRow = (row) => {
    const isCapex = row.billingModel === 'capex';
    const mainRow = `<tr class="sub-price-row"><td class="sub-price-cell sub-price-cell--name">${row.name}</td>${showOneTime ? `<td class="sub-price-cell">${isCapex ? 'Capex' : 'Opex'}</td>` : ''}<td class="sub-price-cell sub-price-cell--num">${formatMoney(row.listUnit)}</td><td class="sub-price-cell sub-price-cell--msa">${buildMsaPriceCellHtml(row.msaUnit, false, 0)}</td><td class="sub-price-cell sub-price-cell--num">${row.qty}</td><td class="sub-price-cell sub-price-cell--num">${row.eligibleQty}</td></tr>`;
    const hardwareRow = (showOneTime && isCapex && row.oneTimeUnit > 0.005)
      ? `<tr class="sub-price-row sub-price-row--hardware"><td class="sub-price-cell sub-price-cell--name">${row.hardwareName || row.name} Hardware</td><td class="sub-price-cell">Capex</td><td class="sub-price-cell sub-price-cell--num">${formatMoney(row.oneTimeUnit)}</td><td class="sub-price-cell sub-price-cell--msa">${buildMsaPriceCellHtml(row.oneTimeUnit, false, 0)}</td><td class="sub-price-cell sub-price-cell--num">${row.qty}</td><td class="sub-price-cell sub-price-cell--num">0</td></tr>`
      : '';
    return mainRow + hardwareRow;
  };
  const groups = [{ label: 'Current contract', items: rows.filter(row => row.source === 'existing') }, { label: 'This proposal', items: rows.filter(row => row.source === 'proposal') }].filter(group => group.items.length);
  const tableHtml = `<table class="sub-price-table${showOneTime ?' sub-price-table--unified' : ''}"><thead><tr><th class="sub-price-header">Solution</th>${showOneTime ? '<th class="sub-price-header">Billing model</th>' : ''}<th class="sub-price-header sub-price-header--num">List Price</th><th class="sub-price-header sub-price-header--msa">${buildMsaPriceHeaderLabelHtml()}</th><th class="sub-price-header sub-price-header--num">QTY</th><th class="sub-price-header sub-price-header--num">Eligible Subs</th></tr></thead>${groups.map(group => `<tbody><tr class="price-list-source-row"><td colspan="${colspan}" class="price-list-source-cell">${group.label}</td></tr>${group.items.map(row => renderRow(row)).join('')}</tbody>`).join('')}</table>`;
  return `<div class="subscription-summary-scroll">${tableHtml}</div>`;
}

function openEditProposalModal() {
  // Segment radios
  const seg = proposalData.segment || 'SMB';
  document.querySelectorAll('input[name="edit-segment"]').forEach(r => {
    r.checked = r.value === seg;
  });
  _syncEditSegmentSections(seg);
  // Enterprise
  const poEl = document.getElementById('edit-po-number');
  const ccEl = document.getElementById('edit-cost-center');
  if (poEl) poEl.value = proposalData.poNumber || '';
  if (ccEl) ccEl.value = proposalData.costCenter || '';
  // Government
  const govPoEl = document.getElementById('edit-gov-po');
  const cvEl   = document.getElementById('edit-contract-vehicle');
  const coName = document.getElementById('edit-co-name');
  const coEmail= document.getElementById('edit-co-email');
  const coPhone= document.getElementById('edit-co-phone');
  if (govPoEl) govPoEl.value = proposalData.poNumber || '';
  if (cvEl)    cvEl.value    = proposalData.contractVehicle || '';
  if (coName)  coName.value  = proposalData.contractingOfficerName || '';
  if (coEmail) coEmail.value = proposalData.contractingOfficerEmail || '';
  if (coPhone) coPhone.value = proposalData.contractingOfficerPhone || '';

  document.getElementById('edit-proposal-overlay').classList.add('is-open');
}

function closeEditProposalModal() {
  document.getElementById('edit-proposal-overlay').classList.remove('is-open');
}

function onEditSegmentChange() {
  const sel = document.querySelector('input[name="edit-segment"]:checked');
  if (sel) _syncEditSegmentSections(sel.value);
}

function _syncEditSegmentSections(seg) {
  const entSection = document.getElementById('edit-ent-section');
  const govSection = document.getElementById('edit-gov-section');
  if (entSection) entSection.classList.toggle('hidden', seg !== 'Enterprise');
  if (govSection) govSection.classList.toggle('hidden', seg !== 'Government');
}

function saveProposalInfo() {
  // Segment
  const selSeg = document.querySelector('input[name="edit-segment"]:checked');
  const newSeg = selSeg ? selSeg.value : (proposalData.segment || 'SMB');
  proposalData.segment = newSeg;

  // Segment-specific fields
  if (newSeg === 'Enterprise') {
    proposalData.poNumber   = (document.getElementById('edit-po-number')  || {}).value || '';
    proposalData.costCenter = (document.getElementById('edit-cost-center') || {}).value || '';
    proposalData.contractVehicle = '';
    proposalData.contractingOfficerName = '';
    proposalData.contractingOfficerEmail = '';
    proposalData.contractingOfficerPhone = '';
  } else if (newSeg === 'Government') {
    proposalData.poNumber           = (document.getElementById('edit-gov-po')          || {}).value || '';
    proposalData.contractVehicle    = (document.getElementById('edit-contract-vehicle') || {}).value || '';
    proposalData.contractingOfficerName  = (document.getElementById('edit-co-name')    || {}).value || '';
    proposalData.contractingOfficerEmail = (document.getElementById('edit-co-email')   || {}).value || '';
    proposalData.contractingOfficerPhone = (document.getElementById('edit-co-phone')   || {}).value || '';
    proposalData.costCenter = '';
  } else {
    // SMB \u2014 clear all deal-classification fields
    proposalData.poNumber = '';
    proposalData.costCenter = '';
    proposalData.contractVehicle = '';
    proposalData.contractingOfficerName = '';
    proposalData.contractingOfficerEmail = '';
    proposalData.contractingOfficerPhone = '';
  }

  updateSegmentHeader();
  closeEditProposalModal();
  renderOptions();
  logProposalEvent('Proposal settings updated', `Segment: ${newSeg}.`);
}

function openTierSettingsFromMenu(event) {
  if (event) event.stopPropagation();
  document.getElementById('more-menu-draft')?.classList.add('hidden');
  document.getElementById('draft-more-btn')?.setAttribute('aria-expanded', 'false');
  openEditProposalModal();
  document.getElementById('edit-prop-tier')?.focus();
}

function getContractCreatedBanner() {
  return ['Contract has been created', 'Review the terms and send the contract to the customer.'];
}

function syncNewProposalButton() {
  const host = document.getElementById('quotes-list-page-header-host');
  if (host && !document.getElementById('btn-new-proposal')) {
    host.innerHTML = VC.pageHeader({
      title: 'Proposal Dashboard',
      subtitle: 'View and manage proposals for this account or lead.',
      inset: true,
      action: {
        id: 'btn-new-proposal',
        label: 'Create new proposal',
        onClick: 'options = []; nextOptId = 1; openDraftingRoute()',
      },
    });
  }
  const button = document.getElementById('btn-new-proposal');
  if (!button) return;
  const isInactive = accountStatus === 'inactive';
  button.textContent = isInactive ? 'Reactivate' : 'Create new proposal';
  button.onclick = isInactive
    ? startReactivationProposal
    : () => { options = []; nextOptId = 1; openDraftingRoute(); };
}

function startRenewalRewrapProposal() {
  options = [];
  nextOptId = 1;
  openDraftingRoute('renewalRewrap');
  if (!options.length) {
    const opt = window.createOptionFromCurrent('Option 1');
    if (opt) {
      opt.transactionMode = 'Rewrap';
      opt.discretionaryDiscountPct = 0;
      // 2026-09-18 (R21.3, per transcript \u2014 Catalina/Leo, 2026-09-17 meeting):
      // promotions are order-specific and never carry over to a renewal/rewrap
      // ("in this option they are not promotions because the promotions are
      // different between orders... maybe the price is going to increase") \u2014
      // reset alongside the discount, not just copy Current's old promo as-is.
      opt.bundles.forEach(b => { b.msaDiscountPct = 0; b.promoType = 'Standard'; b.promoName = ''; });
      opt.effectiveDate = '';
      renderOptions();
      document.getElementById('empty-state')?.classList.add('hidden');
      document.getElementById('options-grid')?.classList.remove('hidden');
    }
  }
}

function startReactivationProposal() {
  options = [];
  nextOptId = 1;
  openDraftingRoute('reactivation');
  const opt = window.createOptionFromCurrent('Option 1');
  if (!opt) return;
  opt.transactionMode = 'Reactivation';
  opt.discretionaryDiscountPct = 0;
  opt.bundles.forEach(b => { b.msaDiscountPct = 0; b.promoType = 'Standard'; b.promoName = ''; });
  opt.effectiveDate = '';
  opt.term = 36;
  renderOptions();
  document.getElementById('empty-state')?.classList.add('hidden');
  document.getElementById('options-grid')?.classList.remove('hidden');
}

function getMcCancellationPenalty(opt) {
  const status = getMsaCommitmentStatus();
  const totalMonthly = calcOption(opt, getOptionPromotion(opt)).totalMonthly;
  const endDate = new Date(status.msaEndDate + 'T00:00:00');
  const remainingMonths = Math.max(0, Math.ceil((endDate - new Date()) / (1000 * 60 * 60 * 24 * 30.44)));
  const grossAmount = remainingMonths * totalMonthly;
  const wave = CANCEL_PENALTY_WAVES.find(w => w.id === opt.cancelPenaltyWaveId) || null;
  const waveDiscountPct = wave ? wave.pct : 0;
  const amount = grossAmount * (1 - waveDiscountPct / 100);
  return { amount, grossAmount, remainingMonths, totalMonthly, wave, waveDiscountPct };
}

function getUnreturnedHardwareValue(opt) {
  const bundles = Array.isArray(opt?.bundles) ? opt.bundles : [];
  const breakdown = bundles.map(b => {
    const unitValue = HARDWARE_VALUES[b.coreKey] || 0;
    const qty = Number(b.qty) || 0;
    return { coreKey: b.coreKey, name: b.coreName || corePricing[b.coreKey]?.name || b.coreKey, qty, unitValue, subtotal: unitValue * qty };
  }).filter(row => row.qty > 0);
  const totalValue = breakdown.reduce((sum, row) => sum + row.subtotal, 0);
  const returnByDate = new Date(Date.now() + HARDWARE_RETURN_WINDOW_DAYS * 24 * 60 * 60 * 1000);
  return { breakdown, totalValue, returnByDate };
}

function getHardwareAccordionHtml(opt, uid) {
  // 2026-09-28 (per Catalina/Leo \u2014 point 4 of Capex/Opex support): under a
  // Capex billing model the customer already owns the hardware outright (it
  // was a one-time purchase, not something Verizon is still carrying), so
  // there's no "unreturned hardware" penalty to speak of. Only suppressed for
  // a pure Capex account; kept for Opex and for "Both" (mixed accounts still
  // have Opex-billed units this could apply to, and this prototype doesn't
  // yet track billing model per unit/bundle in Existing Accounts \u2014 see
  // requirements.md Open Questions).
  if (accountBillingModel === 'capex') return '';
  const hw = getUnreturnedHardwareValue(opt);
  if (!hw.breakdown.length) return '';
  const returnByLabel = hw.returnByDate.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
  const rowsHtml = hw.breakdown.map(row => `
    <div style="display:flex;justify-content:space-between;gap:12px;padding:6px 0;font-size:12px;color:var(--gray-700);">
      <span>${row.name} \u00d7 ${row.qty}</span>
      <span>${formatMoney(row.unitValue)}/unit \u2014 <strong style="color:var(--black);">${formatMoney(row.subtotal)}</strong></span>
    </div>`).join('');
  return `
    <div class="cancel-mc-penalty" style="flex-direction:column;align-items:stretch;gap:6px;">
      <div style="display:flex;justify-content:space-between;align-items:center;">
        <span class="cancel-mc-penalty-label">Unreturned hardware value (if not returned by ${returnByLabel})</span>
        <strong class="cancel-mc-card-penalty-value">${formatMoney(hw.totalValue)}</strong>
      </div>
      <div class="vc-accordion" id="hw-acc-${uid}">
        <button type="button" class="vc-accordion__header" aria-expanded="false" onclick="toggleAddonAccordion('hw-acc-${uid}')">
          <span class="vc-accordion__title">See itemized hardware value</span>
          <span class="vc-accordion__right"><span class="material-symbols-outlined vc-accordion__chevron" aria-hidden="true">expand_more</span></span>
        </button>
        <div class="vc-accordion__body">${rowsHtml}</div>
      </div>
    </div>`;
}

function getCancelPenaltyWaveDropdownHtml(opt) {
  const optionsHtml = CANCEL_PENALTY_WAVES.map(w => `<option value="${w.id}" ${opt.cancelPenaltyWaveId === w.id ? 'selected' : ''}>${w.name}</option>`).join('');
  return `
    <div class="approval-field" style="margin-top:8px;">
      <label for="cancel-wave-select-${opt.id}" class="vc-field-label">Cancellation promotion (optional)</label>
      <select id="cancel-wave-select-${opt.id}" class="select" data-vc-dropdown onchange="setCancelPenaltyWave(${opt.id}, this.value)">
        <option value="">None</option>
        ${optionsHtml}
      </select>
    </div>`;
}

function setCancelPenaltyWave(optId, waveId) {
  const opt = options.find(o => o.id === optId);
  if (!opt) return;
  opt.cancelPenaltyWaveId = waveId || null;
  if (document.getElementById('cancel-mc-modal-overlay')?.classList.contains('is-open')) {
    renderCancelMcModalPenalty();
  } else {
    renderOptions();
  }
}

function getCancelMcSummaryHtml() {
  const currentOrders = Array.isArray(existingOrders) ? existingOrders : [];
  const currentBundles = currentOrders.flatMap(order => order.bundles || []);
  const totalUnits = currentBundles.reduce((sum, bundle) => sum + (Number(bundle.qty) || 0), 0);
  const totalMonthly = currentOrders.reduce((sum, order) => sum + calcOption({ bundles: order.bundles || [], term: order.term || 36 }, 'Standard').totalMonthly, 0);
  const subs = currentBundles.reduce((sum, bundle) => sum + getMsaTierQty(bundle.qty, bundle.coreKey), 0);
  const tier = getMsaDiscountTier(subs);
  const tierRange = tier.max >= 9999 ? `${tier.min}+` : `${tier.min}-${tier.max}`;
  const bundlesHtml = currentBundles.map(bundle => {
    const order = currentOrders.find(candidate => (candidate.bundles || []).includes(bundle));
    const pricing = calcBundle(bundle, order?.term || 36, bundle.promoType || 'Standard', totalUnits);
    return `<div style="padding:10px 0;border-top:1px solid var(--gray-200);">
      <div style="font-size:13px;font-weight:700;color:var(--black);">${bundle.coreName}</div>
      <div style="display:flex;justify-content:space-between;gap:12px;margin-top:4px;font-size:11px;color:var(--gray-600);">
        <span>QTY: ${bundle.qty}</span><span>${formatMoney(pricing.unitPrice)}/unit</span><strong style="color:var(--black);">${formatMoney(pricing.monthly)}/month</strong>
      </div>
    </div>`;
  }).join('');
  return `<div style="font-size:11px;font-weight:700;color:var(--gray-500);text-transform:uppercase;letter-spacing:.05em;margin-bottom:8px;">Current solutions</div>
    ${bundlesHtml}
    <div style="display:flex;justify-content:space-between;gap:16px;border-top:1px solid var(--gray-300);margin-top:4px;padding-top:10px;"><span>Monthly total</span><strong>${formatMoney(totalMonthly)}/month</strong></div>
    <div style="margin-top:8px;color:var(--gray-600);font-size:12px;">${totalUnits} units \u00b7 ${subs} subs \u00b7 Tier/Term ${tierRange}</div>`;
}

function renderCancelMcModalPenalty() {
  const opt = options.find(o => o.id === bld.selectedOptionId);
  if (!opt) return;
  const penalty = getMcCancellationPenalty(opt);
  const monthsLabel = `${penalty.remainingMonths} month${penalty.remainingMonths === 1 ? '' : 's'} remaining`;
  document.getElementById('cancel-mc-modal-penalty-label').textContent = `Early termination fee (${monthsLabel})`;
  document.getElementById('cancel-mc-modal-penalty').textContent = formatMoney(penalty.amount);
  document.getElementById('cancel-mc-modal-wave-line').textContent = penalty.wave ? `${penalty.wave.name} applied \u2014 was ${formatMoney(penalty.grossAmount)}` : '';
  document.getElementById('cancel-mc-modal-wave-dropdown').innerHTML = getCancelPenaltyWaveDropdownHtml(opt);
}

function closeCancelMcModal() {
  document.getElementById('cancel-mc-modal-overlay')?.classList.remove('is-open');
}

function acceptCancelMc() {
  closeCancelMcModal();
  navigateToContractReviewFromSelection();
}

function closeCancelAutoRenewalModal() {
  document.getElementById('cancel-auto-renewal-modal-overlay')?.classList.remove('is-open');
}

function updateCancelAutoRenewalSubmitState() {
  const reason = document.getElementById('car-reason')?.value.trim() || '';
  const reasonError = document.getElementById('car-reason-error');
  if (reasonError && reason) reasonError.classList.add('hidden');
  if (reason) document.getElementById('car-reason')?.classList.remove('input--error');
}

function triggerCancelAutoRenewalUpload() {
  document.getElementById('car-upload-input')?.click();
}

function handleCancelAutoRenewalUploadChange(input) {
  const fileNameEl = document.getElementById('car-upload-filename');
  const uploadError = document.getElementById('car-upload-error');
  const fileName = input?.files?.[0]?.name || '';
  if (!fileNameEl) return;
  if (!fileName) {
    fileNameEl.classList.add('hidden');
    fileNameEl.textContent = '';
    return;
  }
  fileNameEl.textContent = `Attached: ${fileName}`;
  fileNameEl.classList.remove('hidden');
  if (uploadError) uploadError.classList.add('hidden');
}

function confirmCancelAutoRenewal() {
  const reason = document.getElementById('car-reason')?.value.trim() || '';
  const fileName = document.getElementById('car-upload-input')?.files?.[0]?.name || '';
  let hasError = false;
  if (!reason) {
    document.getElementById('car-reason-error')?.classList.remove('hidden');
    document.getElementById('car-reason')?.classList.add('input--error');
    hasError = true;
  }
  if (!fileName) {
    document.getElementById('car-upload-error')?.classList.remove('hidden');
    hasError = true;
  }
  if (hasError) {
    if (!reason) document.getElementById('car-reason')?.focus();
    return;
  }
  DEMO_MSA.autoRenewalEnabled = false;
  DEMO_MSA.autoRenewalCancellation = { reason, fileName, date: new Date().toISOString().slice(0, 10) };
  closeCancelAutoRenewalModal();
  showSuccessBanner('Auto-renewal disabled', 'The auto-renewal has been turned off for this MSA.');
}

function setVZTxFooter(html) {
  const el = document.getElementById('gc-tx-footer-actions');
  if (!el) return;

  el.innerHTML = html;

  const upsellNextBtn = el.querySelector('#gc-upsell-next-btn');
  if (upsellNextBtn) {
    upsellNextBtn.type = 'button';
    upsellNextBtn.disabled = false;
    upsellNextBtn.onclick = function (event) {
      event.preventDefault();
      vzGoUpsellStep2();
    };
  }

  const upsellAddBtn = el.querySelector('#gc-upsell-add-btn');
  if (upsellAddBtn) {
    upsellAddBtn.type = 'button';
    upsellAddBtn.onclick = function (event) {
      event.preventDefault();
      vzAddUpsellToOrder();
    };
  }

  const cancelNextBtn = el.querySelector('#gc-cancel-next-btn');
  if (cancelNextBtn) {
    cancelNextBtn.type = 'button';
    cancelNextBtn.onclick = function (event) {
      event.preventDefault();
      vzGoCancelStep2();
    };
  }
}

function vzMonthsUntil(dateStr) {
  const d = new Date(dateStr);
  const now = new Date();
  return Math.max(0, Math.round((d - now) / (30.44 * 24 * 60 * 60 * 1000)));
}

function vzFmtDate(d) {
  if (!d) return '\u2014';
  const dt = new Date(d + 'T00:00:00');
  return dt.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

function vzSubStartFromEnd(subEnd, termMonthsFallback = 24) {
  if (!subEnd) return '';
  const dt = new Date(subEnd + 'T00:00:00');
  if (Number.isNaN(dt.getTime())) return '';
  const monthsToSubtract = Math.max(1, Number(termMonthsFallback) || 24);
  dt.setMonth(dt.getMonth() - monthsToSubtract);
  return dt.toISOString().slice(0, 10);
}

function vzMockVehicleDetails(serial) {
  let h = 0;
  for (let i = 0; i < serial.length; i++) h = Math.imul(h * 31 + serial.charCodeAt(i), 1) | 0;
  h = Math.abs(h);
  const makes = [
    { make: 'Ford',       models: ['F-150', 'Transit', 'E-350', 'F-250'] },
    { make: 'Toyota',     models: ['Camry', 'Tacoma', 'Sienna', 'Tundra'] },
    { make: 'Chevrolet',  models: ['Silverado', 'Express', 'Colorado'] },
    { make: 'Ram',        models: ['1500', 'ProMaster', '2500'] },
    { make: 'GMC',        models: ['Sierra', 'Savana', 'Canyon'] },
  ];
  const { make, models } = makes[h % makes.length];
  const model = models[(h >> 4) % models.length];
  const year  = 2018 + ((h >> 8) % 7);
  const L = 'ABCDEFGHJKLMNPRSTUVWXYZ';
  const plate = L[(h >> 12) % L.length] + L[(h >> 16) % L.length] + L[(h >> 20) % L.length]
              + '-' + String(1000 + (h >> 4) % 8999);
  return { year, make, model, plate };
}

function vzGenerateSubscriptions() {
  const subs = [];
  let subId = 1;
  const opt = bld.targetOptId ? options.find(o => o.id === bld.targetOptId) : null;
  const sourceBundles = proposalData.entryPoint === 'renewalRewrap'
    ? (opt ? (opt.bundles || []).filter(bundle => bundle.originalQty !== undefined) : [])
    : (Array.isArray(existingOrders) ? existingOrders : []).flatMap(order => order.bundles || []);
  const bundles = sourceBundles;
  const excludedCancelIds = new Set((opt?.bundles || [])
    .filter(bundle => bundle.isolatedTransactionType === 'cancel' && bundle.id !== bld.targetBundleId)
    .flatMap(bundle => Array.isArray(bundle.selectedSubIds) ? bundle.selectedSubIds : []));
  const totalUnits = bundles.reduce((sum, b) => sum + (Number(b.qty) || 0), 0);
  const msaEndDate = (proposalData && proposalData.msaEndDate) || '2028-01-01';
  const contractType = (proposalData && proposalData.contractType) || 'Flex';
  const remain = vzMonthsUntil(msaEndDate);
  const term = (opt && opt.term) || 36;

  bundles.forEach((bundle, bundleIndex) => {
    const qty = Math.max(0, Math.floor(Number(bundle.qty) || 0));
    if (!qty) return;
    let unitPrice = bundle.basePrice || 0;
    try {
      unitPrice = calcBundle(bundle, term, bundle.promoType || 'Standard', totalUnits).unitPrice;
    } catch (_) {}

    for (let i = 0; i < qty; i++) {
      const stableSubId = window.getVZBundleSubscriptionId(bundle, i);
      if (excludedCancelIds.has(stableSubId)) continue;
      const serial = `VZC-${String(subId).padStart(6, '0')}`;
      const vin = `1VZC${String(subId).padStart(5,'0')}VX${String(Math.floor(Math.random()*90)+10)}`;
      subs.push({
        id: stableSubId,
        erp: `ERP-${Math.floor(Math.random()*90000)+10000}`,
        techRef: `${String(Math.floor(Math.random()*9000000000)+1000000000)}-${String(Math.floor(Math.random()*9000000000)+1000000000)}`,
        product: bundle.coreName,
        productKey: bundle.coreKey,
        features: Array.isArray(bundle.features) ? bundle.features : [],
        bundleId: bundle.id,
        subStatus: 'Active',
        renewalType: contractType,
        subEnd: msaEndDate,
        deviceStatus: 'Active',
        rate: unitPrice,
        serial: serial,
        vin: vin,
        ecfEnd: msaEndDate,
        minCommit: term,
        remainMonths: remain,
        esn: serial,
        orderNumber: `ORD-${String(subId).padStart(6, '0')}`,
        subStart: vzSubStartFromEnd(msaEndDate, term) || vzSubStartFromEnd(msaEndDate, 24),
        vehicleName: `Unit-${String(subId).padStart(3,'0')}`,
        parentEsn: '\u2014',
        isCore: true,
        linkedCoreSerial: null,
      });
      subId++;
    }
  });

  return subs;
}

function vzGetAlreadyUpsoldSubIds() {
  const opt = bld.targetOptId ? options.find(o => o.id === bld.targetOptId) : null;
  return new Set((opt?.bundles || [])
    .filter(bundle => bundle.isolatedTransactionType === 'upsell' && bundle.id !== bld.targetBundleId)
    .flatMap(bundle => Array.isArray(bundle.selectedSubIds) ? bundle.selectedSubIds : []));
}

function vzApplySubFilter(subs) {
  return subs.filter(s => {
    const productOk = vzSubFilter.products.length === 0 || vzSubFilter.products.includes(s.productKey);
    const statusOk  = vzSubFilter.statuses.length === 0 || vzSubFilter.statuses.includes(s.deviceStatus);
    return productOk && statusOk;
  });
}

function renderVZUpsellForm() {
  vzUpsellPreSelected = txPreselectedSubIds.length > 0 ? [...txPreselectedSubIds] : [];
  upsellViewMode = 'vehicle';
  txPreselectedSubIds = [];
  vzUpsellDiscountPct = Number(proposalData.msaDiscretionaryDiscountPct) || 0;

  const allSubs = vzGenerateSubscriptions();
  const subs = allSubs.filter(s => s.isCore);

  const area = document.getElementById('gc-tx-form-area');
  area.innerHTML = `
    <!-- Mode selector -->
    <div style="display:flex; align-items:center; gap:8px; margin-bottom:16px;">
      <span style="font-size:13px; font-weight:600; color:var(--black);">Start with</span>
      <select class="select select--small" data-vc-dropdown onchange="vzSetUpsellMode(this.value)">
          <option value="vehicles" ${upsellMode === 'vehicles' ? 'selected' : ''}>selecting vehicles</option>
          <option value="features" ${upsellMode === 'features' ? 'selected' : ''}>selecting features</option>
        </select>
    </div>
    <div style="border-top:1px solid var(--gray-200); margin-bottom:16px;"></div>

    <div class="gc-tx-step active" id="gc-tx-upsell-step1">
      ${upsellMode === 'vehicles' ? `
      <!-- VEHICLES MODE: toolbar + table -->
      <div style="display:flex; align-items:center; justify-content:flex-end; gap:10px; margin-bottom:10px;">
        <span style="font-size:11px; font-weight:700; color:var(--gray-500);">Sort by:</span>
          <select class="select select--small" id="gc-upsell-view-select" data-vc-dropdown onchange="vzSetUpsellViewMode(this.value)">
              <option value="vehicle">Vehicle</option>
              <option value="subscription">Subscription</option>
            </select>
      </div>
      <div style="border:1px solid var(--gray-200); border-radius:8px; overflow-x:auto; overflow-y:hidden;">
        <table class="gc-sub-table" style="width:100%; min-width:980px;" id="gc-upsell-table">
          <thead id="gc-upsell-thead"></thead>
          <tbody id="gc-upsell-tbody"></tbody>
        </table>
      </div>
      ` : `
      <!-- FEATURES MODE: categorized feature grid -->
      ${['video', 'vehicle'].map(cat => {
        const catFeatures = VZ_UPSELL_FEATURES.filter(f => f.category === cat);
        const catLabel = cat === 'video' ? 'Video Features' : 'Vehicle Features';
        return `<div style="margin-bottom:16px;">
          <div style="font-size:11px; font-weight:700; letter-spacing:0.06em; color:var(--gray-500); margin-bottom:8px;">${catLabel}</div>
          <div class="gc-tx-feature-grid">
            ${catFeatures.map(f => `<label class="gc-tx-feature-option" onclick="this.classList.toggle('selected'); vzUpdateUpsellPreview()"><input type="checkbox" class="gc-upsell-feature-cb checkbox__input" value="${f.key}" data-price="${f.price}"><div><div class="gc-tx-feature-name">${f.label}</div><div class="gc-tx-feature-price">+${formatMoney(f.price)}/unit/mo</div></div></label>`).join('')}
          </div>
        </div>`;
      }).join('')}
      `}
    </div>

    <div class="gc-tx-step" id="gc-tx-upsell-step2">
      <div class="gc-tx-step-header">
        <div class="gc-tx-step-title">${upsellMode === 'features' ? 'Select Vehicles' : 'Choose Features to Add'}</div>
      </div>
      <div id="gc-upsell-step2-body"></div>
    </div>`;

  // Initialize right-side preview pane
  vzUpdateUpsellPreview();

  // Sync sort select width to selected option
  setTimeout(() => vzSyncSelectWidth(document.getElementById('gc-upsell-view-select')), 0);

  // Footer: back button + Add Upsell (disabled until step 2 complete)
  if (upsellMode === 'vehicles') {
    setVZTxFooter(`
      <button class="btn btn--primary btn--large" id="gc-upsell-next-btn" onclick="vzGoUpsellStep2()" style="flex:none; padding:10px 24px; font-size:14px; gap:8px;">Choose features</button>
    `);
    vzRenderUpsellTable();
  } else {
    setVZTxFooter(`<button class="btn btn--primary btn--large" onclick="vzGoUpsellStep2()" style="flex:none; padding:10px 24px; font-size:14px; gap:8px;">Select vehicles</button>`);
  }
}

function vzSetUpsellMode(mode) {
  upsellMode = mode;
  renderVZUpsellForm();
}

function vzToggleUpsellAll(el) {
  document.querySelectorAll('.gc-upsell-vehicle-cb').forEach(cb => cb.checked = el.checked);
  vzUpdateUpsellCount();
}

function vzUpdateUpsellCount() {
  const count = document.querySelectorAll('.gc-upsell-vehicle-cb:checked').length;
  const btn = document.getElementById('gc-upsell-next-btn');
  if (btn) {
    btn.disabled = count === 0;
    btn.style.opacity = count === 0 ? '0.45' : '1';
    btn.style.cursor = count === 0 ? 'not-allowed' : 'pointer';
  }
  vzUpdateUpsellPreview();
  vzRefreshMsaCommitmentPanel();
}

function vzSyncSelectWidth(sel) {
  // 2026-10-07: these selects are VDS Select S now (width follows the content) \u2014 nothing to measure.
  if (sel) sel.style.width = '';
}

function vzSetUpsellViewMode(mode) {
  upsellViewMode = mode;
  const sel = document.getElementById('gc-upsell-view-select');
  if (sel) { sel.value = mode; vzSyncSelectWidth(sel); }
  vzRenderUpsellTable();
}

function vzRenderUpsellTable() {
  const allSubs = vzGenerateSubscriptions();
  const coreSubs = allSubs.filter(s => s.isCore);
  const subs = vzApplySubFilter(coreSubs);

  // Build add-on map: coreSerial \u2192 [addon subs]
  const addOnMap = {};
  allSubs.filter(s => !s.isCore).forEach(s => {
    if (s.linkedCoreSerial) {
      if (!addOnMap[s.linkedCoreSerial]) addOnMap[s.linkedCoreSerial] = [];
      addOnMap[s.linkedCoreSerial].push(s);
    }
  });

  const thead = document.getElementById('gc-upsell-thead');
  const tbody = document.getElementById('gc-upsell-tbody');
  if (!thead || !tbody) return;

  if (upsellViewMode === 'vehicle') {
    thead.innerHTML = `
      <tr style="background:var(--white); border-bottom:2px solid var(--gray-200);">
        <th style="width:32px; padding:10px 8px; text-transform:none; font-size:13px; color:var(--black); letter-spacing:0;">
          <input type="checkbox" class="checkbox__input" onchange="vzToggleUpsellAll(this)" style="flex-shrink:0;width:16px;height:16px;">
        </th>
        <th style="padding:10px 12px; text-transform:none; font-size:13px; color:var(--black); letter-spacing:0;">Vehicle/Asset</th>
        <th style="padding:10px 12px; text-transform:none; font-size:13px; color:var(--black); letter-spacing:0;">Name</th>
        <th style="padding:10px 12px; text-transform:none; font-size:13px; color:var(--black); letter-spacing:0;">License Plate</th>
        <th style="padding:10px 12px; text-transform:none; font-size:13px; color:var(--black); letter-spacing:0;">Order</th>
        <th style="padding:10px 12px; text-transform:none; font-size:13px; color:var(--black); letter-spacing:0;">Start Date</th>
        <th style="padding:10px 12px; text-transform:none; font-size:13px; color:var(--black); letter-spacing:0;">End Date</th>
        <th></th>
      </tr>`;

    tbody.innerHTML = subs.slice(0, 50).map(s => {
      const checked = vzUpsellPreSelected.includes(s.id) ? 'checked' : '';
      const vd = vzMockVehicleDetails(s.serial);
      const addons = addOnMap[s.serial] || [];
      const allVehicleSubs = [s, ...addons];

      const vehicleRow = `<tr style="background:var(--gray-100); border-top:2px solid var(--gray-200); cursor:pointer;"
          onclick="var cb=this.querySelector('.gc-upsell-vehicle-cb'); cb.checked=!cb.checked; vzUpdateUpsellCount();">
        <td style="padding:10px 8px; width:32px;" onclick="event.stopPropagation();">
          <label style="margin:0;">
            <input type="checkbox" class="gc-upsell-vehicle-cb checkbox__input"
              value="${s.id}" ${checked} onchange="vzUpdateUpsellCount()" style="width:16px;height:16px;">
          </label>
        </td>
        <td style="padding:10px 12px;">
          <div style="display:flex;align-items:center;gap:10px;">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="flex-shrink:0;color:var(--gray-600);"><path d="M7.55556 11.9999C7.55556 12.2197 7.49039 12.4345 7.3683 12.6172C7.24621 12.7999 7.07268 12.9423 6.86965 13.0264C6.66662 13.1105 6.44321 13.1325 6.22768 13.0897C6.01214 13.0468 5.81416 12.941 5.65877 12.7856C5.50338 12.6302 5.39756 12.4322 5.35468 12.2167C5.31181 12.0011 5.33381 11.7777 5.41791 11.5747C5.50201 11.3717 5.64442 11.1981 5.82714 11.076C6.00987 10.954 6.22469 10.8888 6.44444 10.8888C6.73913 10.8888 7.02174 11.0059 7.23012 11.2142C7.43849 11.4226 7.55556 11.7052 7.55556 11.9999ZM16.4444 11.9999C16.4444 12.2197 16.5096 12.4345 16.6317 12.6172C16.7538 12.7999 16.9273 12.9423 17.1304 13.0264C17.3334 13.1105 17.5568 13.1325 17.7723 13.0897C17.9879 13.0468 18.1858 12.941 18.3412 12.7856C18.4966 12.6302 18.6024 12.4322 18.6453 12.2167C18.6882 12.0011 18.6662 11.7777 18.5821 11.5747C18.498 11.3717 18.3556 11.1981 18.1729 11.076C17.9901 10.954 17.7753 10.8888 17.5556 10.8888C17.2609 10.8888 16.9783 11.0059 16.7699 11.2142C16.5615 11.4226 16.4444 11.7052 16.4444 11.9999ZM22 10.8888C21.9999 11.1834 21.8828 11.466 21.6744 11.6743C21.4661 11.8827 21.1835 11.9998 20.8889 11.9999H20.84L20.8889 12.2166V20.8888H16.4444V18.2866H7.55556V20.8888H3.11111V12.2166L3.16 11.9999H3.11111C2.81643 11.9999 2.53381 11.8828 2.32544 11.6745C2.11706 11.4661 2 11.1835 2 10.8888C2 10.5941 2.11706 10.3115 2.32544 10.1031C2.53381 9.89474 2.81643 9.77768 3.11111 9.77768H3.66111L4.68222 5.24101C4.83477 4.62492 5.19179 4.07879 5.69494 3.69189C6.19808 3.30499 6.81759 3.10021 7.4522 3.11101H16.5478C17.1823 3.10006 17.8017 3.30481 18.3047 3.69175C18.8077 4.07869 19.1645 4.62491 19.3166 5.24101L20.3389 9.77768H20.8889C21.1835 9.77778 21.4661 9.89487 21.6744 10.1032C21.8828 10.3116 21.9999 10.5941 22 10.8888ZM6.30556 18.2843H4.36111V19.6388H6.30556V18.2843ZM19.6389 18.2843H17.6944V19.6388H19.6389V18.2843ZM19.6389 12.3555L18.0978 5.51546C18.0066 5.17691 17.8041 4.8789 17.523 4.66948C17.2418 4.46005 16.8983 4.35139 16.5478 4.36101H7.45222C7.10175 4.35139 6.75824 4.46005 6.47705 4.66948C6.19587 4.87891 5.99338 5.17691 5.90222 5.51546L4.36111 12.3555V17.0343H19.6389V12.3555Z" fill="currentColor"/></svg>
            <div>
              <div style="font-weight:700; font-size:13px; line-height:1.3;">${vd.year} ${vd.make} ${vd.model}</div>
              <div style="font-size:11px; color:var(--gray-500); line-height:1.4;">VIN: ${s.vin}</div>
            </div>
          </div>
        </td>
        <td style="padding:10px 12px; font-size:12px; color:var(--gray-600);">${s.vehicleName}</td>
        <td style="padding:10px 12px; font-size:12px; color:var(--gray-600);">${vd.plate}</td>
        <td style="padding:10px 12px; font-size:12px; color:var(--gray-600);">${s.orderNumber || '\u2014'}</td>
        <td style="padding:10px 12px; font-size:12px; color:var(--gray-600);">${vzFmtDate(s.subStart)}</td>
        <td style="padding:10px 12px; font-size:12px; color:var(--gray-600);">${vzFmtDate(s.subEnd)}</td>
        <td></td>
      </tr>`;

      const isPlanMode = builderMode === 'plan';
      const subColHeaders = `<tr style="background:var(--white); border-bottom:1px solid var(--gray-200);">
        <td style="width:32px; padding:6px 8px;"></td>
        <td style="padding:6px 12px; font-size:12px; font-weight:600; color:var(--gray-500);">${isPlanMode ? 'Bundle' : 'Subscription'}</td>
        <td style="padding:6px 12px; font-size:12px; font-weight:600; color:var(--gray-500);">Hardware</td>
        <td style="padding:6px 12px; font-size:12px; font-weight:600; color:var(--gray-500);">Serial</td>
        <td style="padding:6px 12px;"></td>
        <td style="padding:6px 12px;"></td>
        <td style="padding:6px 12px;"></td>
      </tr>`;

      const subRows = allVehicleSubs.map(sub => {
        let hh = 0; for (let i = 0; i < sub.serial.length; i++) hh = (hh * 31 + sub.serial.charCodeAt(i)) | 0;
        const hwList = ['OBD-II', 'Hardwired', 'Asset Tracker', 'Trailer Tracker'];
        const hw = hwList[Math.abs(hh >> 2) % hwList.length];
        const isAddon = !sub.isCore;
        // In Plan mode (True Bundles), the vehicle's current subscription is
        // described by the plan it matches \u2014 but per Catalina, the plan name
        // alone isn't clear enough, so it's shown with the core + features
        // actually included underneath. Custom mode keeps showing the raw
        // product name as-is, with no plan/feature breakdown.
        let displayLabel = sub.product;
        if (isPlanMode) {
          const match = findClosestPrebuiltTier(sub.productKey, sub.features || []);
          if (match) {
            const coreLabel = corePricing[sub.productKey]?.name || sub.productKey;
            const featureNames = (sub.features || []).map(k => featureLabels[k] || k).join(', ');
            displayLabel = `<div style="font-weight:600;">${match.bundle.name} \u2014 ${match.tier.label}</div><div style="font-size:11px; color:var(--gray-600); margin-top:2px;">${coreLabel}${featureNames ? ' \u00b7 ' + featureNames : ''}</div>`;
          }
        }
        return `<tr style="background:var(--white); border-bottom:1px solid var(--gray-100);">
          <td style="padding:8px 8px;"></td>
          <td style="padding:8px 12px; font-size:12px;">${displayLabel}</td>
          <td style="padding:8px 12px; font-size:12px;">${hw}</td>
          <td style="padding:8px 12px; font-size:12px; color:var(--gray-600);">${sub.serial}</td>
          <td style="padding:8px 12px;"></td>
          <td style="padding:8px 12px;"></td>
          <td style="padding:8px 12px;"></td>
        </tr>`;
      }).join('');

      return vehicleRow + subColHeaders + subRows;
    }).join('');

  } else {
    // BY SUBSCRIPTION
    const groups = {};
    subs.forEach(s => {
      if (!groups[s.productKey]) groups[s.productKey] = { label: s.product, items: [] };
      groups[s.productKey].items.push(s);
    });

    thead.innerHTML = '';
    tbody.innerHTML = Object.entries(groups).map(([key, group]) => {
      const subHeader = `<tr style="background:var(--gray-100); border-top:2px solid var(--gray-200);">
        <td colspan="8" style="padding:10px 14px;">
          <div style="display:flex; align-items:center; gap:10px;">
            <label style="margin:0;flex-shrink:0;">
              <input type="checkbox" data-group="${key}" onchange="vzToggleUpsellGroup('${key}', this.checked)" class="checkbox__input" style="width:16px;height:16px;">
            </label>
            <span style="font-weight:700; font-size:13px;">${group.label}</span>
            <span style="font-size:10px;background:var(--stone);border:1px solid var(--gray-200);border-radius:999px;padding:2px 8px;">${group.items.length} vehicles</span>
          </div>
        </td>
      </tr>
      <tr style="background:var(--white); border-bottom:1px solid var(--gray-200);">
        <td style="width:32px; padding:6px 8px;"></td>
        <td style="padding:6px 12px; font-size:12px; font-weight:600; color:var(--gray-500);">Vehicle</td>
        <td style="padding:6px 12px; font-size:12px; font-weight:600; color:var(--gray-500);">Name</td>
        <td style="padding:6px 12px; font-size:12px; font-weight:600; color:var(--gray-500);">VIN</td>
        <td style="padding:6px 12px; font-size:12px; font-weight:600; color:var(--gray-500);">Plate</td>
        <td style="padding:6px 12px; font-size:12px; font-weight:600; color:var(--gray-500);">Order</td>
        <td style="padding:6px 12px; font-size:12px; font-weight:600; color:var(--gray-500);">Start Date</td>
        <td style="padding:6px 12px; font-size:12px; font-weight:600; color:var(--gray-500);">End Date</td>
      </tr>`;

      const vehicleRows = group.items.map(s => {
        const checked = vzUpsellPreSelected.includes(s.id) ? 'checked' : '';
        const vd = vzMockVehicleDetails(s.serial);
        return `<tr style="background:var(--white); border-bottom:1px solid var(--gray-100); cursor:pointer;"
            onclick="var cb=this.querySelector('.gc-upsell-vehicle-cb'); cb.checked=!cb.checked; vzUpdateUpsellCount();">
          <td style="padding:8px 8px; width:32px;" onclick="event.stopPropagation();">
            <label style="margin:0;">
              <input type="checkbox" class="gc-upsell-vehicle-cb checkbox__input"
                value="${s.id}" data-group="${key}" ${checked} onchange="vzUpdateUpsellCount()" style="width:16px;height:16px;">
            </label>
          </td>
          <td style="padding:8px 12px;">
            <div style="display:flex;align-items:center;gap:10px;">
              <div style="display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7.55556 11.9999C7.55556 12.2197 7.49039 12.4345 7.3683 12.6172C7.24621 12.7999 7.07268 12.9423 6.86965 13.0264C6.66662 13.1105 6.44321 13.1325 6.22768 13.0897C6.01214 13.0468 5.81416 12.941 5.65877 12.7856C5.50338 12.6302 5.39756 12.4322 5.35468 12.2167C5.31181 12.0011 5.33381 11.7777 5.41791 11.5747C5.50201 11.3717 5.64442 11.1981 5.82714 11.076C6.00987 10.954 6.22469 10.8888 6.44444 10.8888C6.73913 10.8888 7.02174 11.0059 7.23012 11.2142C7.43849 11.4226 7.55556 11.7052 7.55556 11.9999ZM16.4444 11.9999C16.4444 12.2197 16.5096 12.4345 16.6317 12.6172C16.7538 12.7999 16.9273 12.9423 17.1304 13.0264C17.3334 13.1105 17.5568 13.1325 17.7723 13.0897C17.9879 13.0468 18.1858 12.941 18.3412 12.7856C18.4966 12.6302 18.6024 12.4322 18.6453 12.2167C18.6882 12.0011 18.6662 11.7777 18.5821 11.5747C18.498 11.3717 18.3556 11.1981 18.1729 11.076C17.9901 10.954 17.7753 10.8888 17.5556 10.8888C17.2609 10.8888 16.9783 11.0059 16.7699 11.2142C16.5615 11.4226 16.4444 11.7052 16.4444 11.9999ZM22 10.8888C21.9999 11.1834 21.8828 11.466 21.6744 11.6743C21.4661 11.8827 21.1835 11.9998 20.8889 11.9999H20.84L20.8889 12.2166V20.8888H16.4444V18.2866H7.55556V20.8888H3.11111V12.2166L3.16 11.9999H3.11111C2.81643 11.9999 2.53381 11.8828 2.32544 11.6745C2.11706 11.4661 2 11.1835 2 10.8888C2 10.5941 2.11706 10.3115 2.32544 10.1031C2.53381 9.89474 2.81643 9.77768 3.11111 9.77768H3.66111L4.68222 5.24101C4.83477 4.62492 5.19179 4.07879 5.69494 3.69189C6.19808 3.30499 6.81759 3.10021 7.4522 3.11101H16.5478C17.1823 3.10006 17.8017 3.30481 18.3047 3.69175C18.8077 4.07869 19.1645 4.62491 19.3166 5.24101L20.3389 9.77768H20.8889C21.1835 9.77778 21.4661 9.89487 21.6744 10.1032C21.8828 10.3116 21.9999 10.5941 22 10.8888ZM6.30556 18.2843H4.36111V19.6388H6.30556V18.2843ZM19.6389 18.2843H17.6944V19.6388H19.6389V18.2843ZM19.6389 12.3555L18.0978 5.51546C18.0066 5.17691 17.8041 4.8789 17.523 4.66948C17.2418 4.46005 16.8983 4.35139 16.5478 4.36101H7.45222C7.10175 4.35139 6.75824 4.46005 6.47705 4.66948C6.19587 4.87891 5.99338 5.17691 5.90222 5.51546L4.36111 12.3555V17.0343H19.6389V12.3555Z" fill="currentColor"/></svg>
              </div>
              <div>
                <div style="font-size:12px; font-weight:700;">${vd.year} ${vd.make} ${vd.model}</div>
                <div style="font-size:11px; color:var(--gray-600);">${s.vehicleName}</div>
              </div>
            </div>
          </td>
          <td style="padding:8px 12px; font-size:12px; color:var(--gray-600);">${s.vehicleName}</td>
          <td style="padding:8px 12px; font-size:12px; color:var(--gray-600); font-family:monospace;">${s.vin}</td>
          <td style="padding:8px 12px; font-size:12px; color:var(--gray-600);">${vd.plate}</td>
          <td style="padding:8px 12px; font-size:12px; color:var(--gray-600);">${s.orderNumber || '\u2014'}</td>
          <td style="padding:8px 12px; font-size:12px; color:var(--gray-600);">${vzFmtDate(s.subStart)}</td>
          <td style="padding:8px 12px; font-size:12px; color:var(--gray-600);">${vzFmtDate(s.subEnd)}</td>
        </tr>`;
      }).join('');

      return subHeader + vehicleRows;
    }).join('');
  }

  vzUpdateUpsellCount();
}

function vzToggleUpsellGroup(groupKey, checked) {
  document.querySelectorAll(`.gc-upsell-vehicle-cb[data-group="${groupKey}"]`)
    .forEach(cb => cb.checked = checked);
  vzUpdateUpsellCount();
}

function vzSetUpsellStep(showStep2) {
  const step1 = document.getElementById('gc-tx-upsell-step1');
  const step2 = document.getElementById('gc-tx-upsell-step2');
  if (!step1 || !step2) return;

  step1.classList.toggle('active', !showStep2);
  step2.classList.toggle('active', showStep2);
  step1.style.display = showStep2 ? 'none' : 'block';
  step2.style.display = showStep2 ? 'block' : 'none';
}

function vzGoUpsellStep1() {
  vzSetUpsellStep(false);
  // Back to step 1: restore the forward button matching the current mode
  // (Choose features when picking vehicles first, Select vehicles when
  // picking features first) and restore Cancel as the footer's left action.
  if (upsellMode === 'vehicles') {
    setVZTxFooter(`
      <button class="btn btn--primary btn--large" id="gc-upsell-next-btn" onclick="vzGoUpsellStep2()" style="flex:none; padding:10px 24px; font-size:14px; gap:8px;">Choose features</button>
    `);
  } else {
    setVZTxFooter(`
      <button class="btn btn--primary btn--large" onclick="vzGoUpsellStep2()" style="flex:none; padding:10px 24px; font-size:14px; gap:8px;">Select vehicles</button>
    `);
  }
  const cancelBackBtn = document.getElementById('gc-tx-cancel-back-btn');
  if (cancelBackBtn) { cancelBackBtn.textContent = 'Cancel'; cancelBackBtn.onclick = closeBundleModal; }
  // Re-evaluate count in case vehicles are already selected
  vzUpdateUpsellCount();
}

function vzGoUpsellStep2() {
  const body = document.getElementById('gc-upsell-step2-body');
  if (!body) return;

  if (upsellMode === 'vehicles') {
    const selectedSubIds = [...document.querySelectorAll('.gc-upsell-vehicle-cb:checked')].map(cb => cb.value);
    const count = selectedSubIds.length;
    if (!count) {
      showToast('Tip: choose one or more vehicles before adding the upsell.');
      return;
    }
    // A feature already present on every selected vehicle isn't offered as an
    // upsell \u2014 per Catalina: e.g. a vehicle whose core is already VTU + FFC
    // shouldn't be able to check "Forward Facing Camera" again. Only hidden
    // when ALL selected vehicles already have it; still valid to add for a
    // mixed selection where some don't.
    const alreadyHasKeys = vzGetUpsellAlreadyHasFeatureKeys(selectedSubIds);
    body.innerHTML = ['video', 'vehicle'].map(cat => {
      const catFeatures = VZ_UPSELL_FEATURES.filter(f => f.category === cat && !alreadyHasKeys.has(f.key));
      if (!catFeatures.length) return '';
      const catLabel = cat === 'video' ? 'Video Features' : 'Vehicle Features';
      return `<div style="margin-bottom:16px;">
        <div style="font-size:11px; font-weight:700; letter-spacing:0.06em; color:var(--gray-500); margin-bottom:8px;">${catLabel}</div>
        <div class="gc-tx-feature-grid">
          ${catFeatures.map(f => `<label class="gc-tx-feature-option" onclick="this.classList.toggle('selected'); vzUpdateUpsellPreview()"><input type="checkbox" class="gc-upsell-feature-cb checkbox__input" value="${f.key}" data-price="${f.price}"><div><div class="gc-tx-feature-name">${f.label}</div><div class="gc-tx-feature-price">+${formatMoney(f.price)}/unit/mo</div></div></label>`).join('')}
        </div>
      </div>`;
    }).join('');
  } else {
    const selFeatures = document.querySelectorAll('.gc-upsell-feature-cb:checked').length;
    if (!selFeatures) { showToast('Select at least one feature'); return; }
    const allSubs = vzGenerateSubscriptions();
    const coreSubs = allSubs.filter(s => s.isCore);
    body.innerHTML = `
      <div style="display:flex; align-items:center; justify-content:flex-end; gap:16px; margin-bottom:10px;">
        <div style="display:flex; align-items:center; gap:10px;">
          <span style="font-size:14px; font-weight:700;">Sort by:</span>
          <select class="select select--small" id="gc-upsell-view-select" data-vc-dropdown onchange="vzSetUpsellViewMode(this.value)">
              <option value="vehicle">Vehicle</option>
              <option value="subscription">Subscription</option>
            </select>
        </div>
      </div>
      <div style="border:1px solid var(--gray-200); border-radius:8px; overflow-x:auto; overflow-y:hidden;">
        <table class="gc-sub-table" style="width:100%; min-width:980px;" id="gc-upsell-table">
          <thead id="gc-upsell-thead"></thead>
          <tbody id="gc-upsell-tbody"></tbody>
        </table>
      </div>`;
    vzRenderUpsellTable();
    vzUpdateUpsellCount();
    setTimeout(() => vzSyncSelectWidth(document.getElementById('gc-upsell-view-select')), 0);
  }

  vzSetUpsellStep(true);
  vzUpdateUpsellPreview();
  setVZTxFooter(`
    <button class="btn btn--primary btn--large" id="gc-upsell-add-btn" style="flex:none; padding:10px 24px; font-size:14px;">Add Upsell</button>
  `);
  // Step 2 of 2: swap the footer's left action from Cancel to Back so the
  // step-1 selections aren't lost \u2014 the top-right "X" remains the only
  // full-abandon control.
  const cancelBackBtn = document.getElementById('gc-tx-cancel-back-btn');
  if (cancelBackBtn) { cancelBackBtn.textContent = 'Back'; cancelBackBtn.onclick = vzGoUpsellStep1; }
}

function vzGetUpsellAlreadyHasFeatureKeys(selectedSubIds) {
  if (!selectedSubIds.length) return new Set();
  const allSubs = vzGenerateSubscriptions();
  const sourceBundles = vzGetSourceBundlesForPreview();
  let result = null;
  selectedSubIds.forEach((id) => {
    const sub = allSubs.find((s) => s.id === id);
    if (!sub) return;
    const sourceBundle = sourceBundles.find((b) => b.id === sub.bundleId);
    const currentFeatures = Array.isArray(sourceBundle?.features) ? sourceBundle.features : [];
    const has = new Set();
    VZ_UPSELL_FEATURES.forEach((f) => {
      const aliasCore = VZ_UPSELL_CORE_ALIAS[f.key];
      if (aliasCore) {
        if ((VZ_UPSELL_CORE_RANK[sub.productKey] || 0) >= (VZ_UPSELL_CORE_RANK[aliasCore] || 0)) has.add(f.key);
      } else {
        const catalogKey = VZ_UPSELL_FEATURE_TO_CATALOG_KEY[f.key] || f.key;
        if (currentFeatures.includes(catalogKey)) has.add(f.key);
      }
    });
    result = result === null ? has : new Set([...result].filter((k) => has.has(k)));
  });
  return result || new Set();
}

function vzGetSourceBundlesForPreview() {
  const opt = bld.targetOptId ? options.find(o => o.id === bld.targetOptId) : null;
  return proposalData.entryPoint === 'renewalRewrap'
    ? (opt ? (opt.bundles || []).filter(bundle => bundle.originalQty !== undefined) : [])
    : (Array.isArray(existingOrders) ? existingOrders : []).flatMap(order => order.bundles || []);
}

function vzResolveUpsellTarget(sub, checkedFeatureKeys, sourceBundles) {
  const sourceBundle = sourceBundles.find(b => b.id === sub.bundleId);
  let targetCore = sub.productKey;
  checkedFeatureKeys.forEach((key) => {
    const aliasCore = VZ_UPSELL_CORE_ALIAS[key];
    if (aliasCore && (VZ_UPSELL_CORE_RANK[aliasCore] || 0) > (VZ_UPSELL_CORE_RANK[targetCore] || 0)) {
      targetCore = aliasCore;
    }
  });
  const currentFeatures = Array.isArray(sourceBundle?.features) ? sourceBundle.features : [];
  const addedFeatureKeys = checkedFeatureKeys
    .filter((key) => !VZ_UPSELL_CORE_ALIAS[key])
    .map((key) => VZ_UPSELL_FEATURE_TO_CATALOG_KEY[key] || key);
  const targetFeatures = Array.from(new Set([...currentFeatures, ...addedFeatureKeys]));
  return { targetCore, targetFeatures, addedFeatureKeys };
}

function vzGetUpsellPlanGroups(checkedFeatureKeys, selectedSubIds) {
  if (!checkedFeatureKeys.length || !selectedSubIds.length) return [];
  const allSubs = vzGenerateSubscriptions();
  const sourceBundles = vzGetSourceBundlesForPreview();
  const groups = new Map();
  selectedSubIds.forEach((id) => {
    const sub = allSubs.find((s) => s.id === id);
    if (!sub) return;
    const { targetCore, targetFeatures, addedFeatureKeys } = vzResolveUpsellTarget(sub, checkedFeatureKeys, sourceBundles);
    const match = findClosestPrebuiltTier(targetCore, targetFeatures);
    if (!match) return;
    const groupKey = `${match.bundleKey}::${match.tier.key}`;
    if (!groups.has(groupKey)) {
      groups.set(groupKey, {
        label: `${match.bundle.name} \u2014 ${match.tier.label}`,
        coreLabel: corePricing[targetCore]?.name || targetCore,
        featureKeys: targetFeatures,
        addedFeatureKeys,
        count: 0,
      });
    }
    groups.get(groupKey).count += 1;
  });
  return [...groups.values()].sort((a, b) => b.count - a.count);
}

function vzRenderUpsellPlanGroupsHtml(groups) {
  if (!groups.length) return '';
  const cards = groups.map((g) => {
    const featuresHtml = g.featureKeys.map((k) => {
      const label = featureLabels[k] || k.toUpperCase();
      return g.addedFeatureKeys.includes(k)
        ? `<span class="upsell-plan-added-chip">${label} \u2014 added</span>`
        : label;
    }).join(', ');
    const icon = g.isPlan ? '<span class="material-symbols-outlined" style="font-size:14px;vertical-align:-2px;color:var(--gray-600);">trending_up</span> ' : '';
    return `<div class="upsell-plan-match-card">
      <div class="upsell-plan-match-title">${icon}${g.label} <span class="upsell-plan-match-count">\u00b7 ${g.count} ${g.count === 1 ? 'vehicle' : 'vehicles'}</span></div>
      <div class="upsell-plan-match-detail">${g.coreLabel}${featuresHtml ? ' \u00b7 ' + featuresHtml : ''}</div>
    </div>`;
  }).join('');
  return `<div class="upsell-plan-groups">${cards}</div>`;
}

function vzUpdateUpsellPreview() {
  const pane = document.getElementById('gc-tx-preview-area');
  if (!pane) return;
  const features = [...document.querySelectorAll('.gc-upsell-feature-cb:checked')];
  const vehicleCount = document.querySelectorAll('.gc-upsell-vehicle-cb:checked').length;
  const perUnit = features.reduce((s, f) => s + parseFloat(f.dataset.price || 0), 0);
  const term = bld.targetOptId ? (options.find(o => o.id === bld.targetOptId)?.term || 36) : 36;
  const upsellPricing = calcBundle({
    basePrice: perUnit,
    qty: vehicleCount,
    coreKey: 'transaction-upsell',
    msaDiscountPct: vzUpsellDiscountPct,
    isMsaAuxiliary: true,
    isolatedTransactionType: 'upsell',
  }, term, 'Standard', vehicleCount);
  const discountedPerUnit = upsellPricing.unitPrice;
  const totalMRR = discountedPerUnit * vehicleCount;
  const msaPriceLine = perUnit - discountedPerUnit > 0.005
    ? `<div class="preview-line" style="border-top:1px solid var(--gray-200);margin-top:4px;padding-top:6px;"><strong>Contracted Price</strong><strong>${formatMoney(discountedPerUnit)}</strong></div>`
    : '';
  const quantityLine = `<div class="preview-line"><span>QTY</span><span>${vehicleCount}</span></div>`;
  const monthlyTotalLine = `<div class="preview-line" style="border-top:1px solid var(--gray-300);margin-top:4px;padding-top:6px;"><strong>Monthly</strong><strong>${formatMoney(totalMRR)}</strong></div>`;

  // Plan detection (grouping selected vehicles by the True Bundle they'd land
  // on) is a Simulation Builder / Plan-mode concept only \u2014 per Catalina, Custom
  // mode never talks about plans, so this stays empty there.
  let planGroupsHtml = '';
  if (builderMode === 'plan') {
    const checkedFeatureKeys = features.map((f) => f.value);
    const selectedSubIds = [...document.querySelectorAll('.gc-upsell-vehicle-cb:checked')].map((cb) => cb.value);
    const planGroups = vzGetUpsellPlanGroups(checkedFeatureKeys, selectedSubIds);
    planGroupsHtml = vzRenderUpsellPlanGroupsHtml(planGroups);
  }

  pane.innerHTML = `
    <div class="preview-label">Upsell Preview</div>
    <div class="preview-price">$<span>${formatMoneyAmount(totalMRR)}</span><span>/month</span></div>
    <div class="preview-term-badge">${term} month term contract</div>
    <div style="border-top:1px solid var(--gray-200); padding-top:16px; margin-top:8px;">
      <div style="font-size:11px; font-weight:700; letter-spacing:0.06em; color:var(--gray-500); margin-bottom:4px;">Vehicles selected</div>
      <div style="font-size:13px; font-weight:600; color:var(--black); margin-bottom:16px;">${vehicleCount} ${vehicleCount === 1 ? 'vehicle' : 'vehicles'}</div>
      ${planGroupsHtml}
    </div>
    ${features.length ? `
    <div class="preview-line-items">
      ${features.map(f => `<div class="preview-line"><span>${vzProductLabels[f.value] || f.value}</span><span>${formatMoney(parseFloat(f.dataset.price || 0))}</span></div>`).join('')}
      <div class="preview-line" style="border-top:1px solid var(--gray-200);margin-top:4px;padding-top:6px;"><strong>List Price</strong><strong>${formatMoney(perUnit)}</strong></div>
      ${msaPriceLine}
      ${quantityLine}
      ${monthlyTotalLine}
      <div class="preview-line" style="font-weight:700; margin-top:8px; padding-top:8px; border-top:1px solid var(--gray-200);"><span>Annual impact</span><span style="color:var(--green);">+${formatMoney((Number(totalMRR.toFixed(2)) * 12))}/yr</span></div>
    </div>` : `<div style="color:var(--gray-500); font-size:12px; line-height:1.5; margin-top:16px;">${vehicleCount ? 'Now choose features to see impact' : 'Select vehicles and features to see impact'}</div>`}`;
}

function getUpsellTargetBundleLabel(featureKeys, fallbackLabel) {
  if (featureKeys.includes('dual')) return 'VTU + Dual Camera Subscription';
  if (featureKeys.includes('ffc')) return 'VTU + Forward Facing Camera';
  return fallbackLabel;
}

function vzAddUpsellToOrder() {
  const features = [...document.querySelectorAll('.gc-upsell-feature-cb:checked')];
  if (!features.length) { showToast('Select at least one feature'); return; }
  const selectedIds = [...document.querySelectorAll('.gc-upsell-vehicle-cb:checked')].map(cb => cb.value);
  if (!selectedIds.length) { showToast('Select at least one vehicle'); return; }

  const opt = options.find(o => o.id === bld.targetOptId);
  if (!opt) { showToast('No option to apply the upsell to'); return; }

  if (proposalData.entryPoint !== 'renewalRewrap') {
    const featureKeys = features.map(f => f.value);
    const featureLabel = features.map(f => vzProductLabels[f.value] || f.value).join(' + ');
    const targetBundleLabel = getUpsellTargetBundleLabel(featureKeys, featureLabel);
    const featurePrice = features.reduce((sum, f) => sum + Number(f.dataset.price || 0), 0);
    const isolatedBundle = {
      id: bld.targetBundleId || Date.now(),
      coreKey: 'transaction-upsell',
      coreName: targetBundleLabel,
      basePrice: featurePrice,
      baseCorePrice: featurePrice,
      features: featureKeys,
      qty: selectedIds.length,
      isMsaAuxiliary: true,
      isolatedTransactionType: 'upsell',
      selectedSubIds: selectedIds,
      txLabel: 'Feature Upsell',
      promoType: 'Standard',
      promoName: ''
    };
    const existingIndex = bld.targetBundleId
      ? opt.bundles.findIndex(bundle => bundle.id === bld.targetBundleId)
      : -1;
    if (existingIndex >= 0) opt.bundles[existingIndex] = isolatedBundle;
    else opt.bundles.push(isolatedBundle);
    closeBundleModal();
    renderOptions();
    document.getElementById('empty-state')?.classList.add('hidden');
    document.getElementById('options-grid')?.classList.remove('hidden');
    logProposalEvent('Option edited', `Upsell: ${featureLabel} on ${selectedIds.length} vehicle(s).`);
    return;
  }

  const isolatedFeatureKeys = features.map(f => f.value);
  const isolatedFeatureLabel = features.map(f => vzProductLabels[f.value] || f.value).join(' + ');
  const isolatedTargetBundleLabel = getUpsellTargetBundleLabel(isolatedFeatureKeys, isolatedFeatureLabel);
  const isolatedFeaturePrice = features.reduce((sum, f) => sum + Number(f.dataset.price || 0), 0);
  opt.bundles.push({
    id: bld.targetBundleId || Date.now(),
    coreKey: 'transaction-upsell',
    coreName: isolatedTargetBundleLabel,
    basePrice: isolatedFeaturePrice,
    baseCorePrice: isolatedFeaturePrice,
    features: isolatedFeatureKeys,
    qty: selectedIds.length,
    isMsaAuxiliary: true,
    isolatedTransactionType: 'upsell',
    selectedSubIds: selectedIds,
    txLabel: 'Feature Upsell',
    promoType: 'Standard',
    promoName: ''
  });
  closeBundleModal();
  renderOptions();
  document.getElementById('empty-state')?.classList.add('hidden');
  document.getElementById('options-grid')?.classList.remove('hidden');
  logProposalEvent('Option edited', `Upsell: ${isolatedFeatureLabel} on ${selectedIds.length} vehicle(s).`);
  return;

  const featureKeys = features.map(f => f.value);
  const featureLabel = features.map(f => vzProductLabels[f.value] || f.value).join(' + ');
  const featurePriceMap = {};
  VZ_UPSELL_FEATURES.forEach(f => { featurePriceMap[f.key] = f.price; });

  // Group the selected vehicles by which real bundle they currently belong to
  // (same source of truth the selection table itself was built from).
  const allSubs = vzGenerateSubscriptions();
  const countByBundleId = {};
  allSubs.forEach(s => {
    if (!selectedIds.includes(s.id)) return;
    countByBundleId[s.bundleId] = (countByBundleId[s.bundleId] || 0) + 1;
  });

  // 2026-09-18 (R22 correction, per the 2026-09-17 meeting transcript \u2014 Leo:
  // "in reality that goes with the second bundle"): 'ffc' and 'dual' aren't
  // plain addon features \u2014 they alias a full existing core SKU (vtu-ffc /
  // vtu-dual). Upselling "Forward Facing Camera" onto a vtu-only vehicle must
  // move it into the real vtu-ffc bundle, not create a separate "vtu + ffc
  // feature" line next to it. Resolve by rank so a vehicle never gets
  // downgraded by an unrelated feature pick.
  const CORE_ALIAS_BY_FEATURE = { ffc: 'vtu-ffc', dual: 'vtu-dual' };
  const CORE_RANK = { 'vtu': 0, 'vtu-ffc': 1, 'vtu-dual': 2 };

  let movedTotal = 0;
  Object.keys(countByBundleId).forEach(bundleIdKey => {
    const source = opt.bundles.find(b => String(b.id) === bundleIdKey);
    if (!source) return;
    const moveCount = Math.min(countByBundleId[bundleIdKey], Number(source.qty) || 0);
    if (moveCount <= 0) return;

    const existingFeatures = Array.isArray(source.features) ? source.features : [];
    const combinedKeys = Array.from(new Set([...existingFeatures, ...featureKeys]));

    const sourceRank = CORE_RANK[source.coreKey] ?? 0;
    const impliedRank = combinedKeys.reduce((max, k) => {
      const aliasCore = CORE_ALIAS_BY_FEATURE[k];
      return aliasCore ? Math.max(max, CORE_RANK[aliasCore]) : max;
    }, -1);
    const resultCoreKey = impliedRank > sourceRank
      ? Object.keys(CORE_RANK).find(k => CORE_RANK[k] === impliedRank)
      : source.coreKey;
    // ffc/dual are now represented at the core level (resultCoreKey) \u2014 don't
    // also keep them in the plain features array, or the bundle would double
    // up on the same thing.
    const resultFeatures = combinedKeys.filter(k => !CORE_ALIAS_BY_FEATURE[k]).sort();
    const resultSignature = resultFeatures.join(',');

    let target = opt.bundles.find(b =>
      b !== source &&
      b.coreKey === resultCoreKey &&
      (Array.isArray(b.features) ? [...b.features].sort() : []).join(',') === resultSignature
    );

    if (target) {
      if (target.originalQty === undefined) target.originalQty = target.qty;
      target.qty = (Number(target.qty) || 0) + moveCount;
    } else {
      const addonsPrice = resultFeatures.reduce((sum, k) => sum + (featurePriceMap[k] || 0), 0);
      // If the resulting core is a real, known SKU (vtu/vtu-ffc/vtu-dual),
      // use its real name/base price from corePricing instead of gluing the
      // feature label onto the source's name.
      const resolvedCore = corePricing[resultCoreKey];
      const baseCorePrice = resolvedCore ? resolvedCore.price : (source.baseCorePrice ?? source.basePrice);
      const coreName = resolvedCore ? resolvedCore.name : source.coreName;
      const remainingFeatureLabel = features
        .filter(f => !CORE_ALIAS_BY_FEATURE[f.value])
        .map(f => vzProductLabels[f.value] || f.value)
        .join(' + ');
      target = {
        id: Date.now() + Math.floor(Math.random() * 1000),
        coreKey: resultCoreKey,
        coreName: remainingFeatureLabel ? `${coreName} + ${remainingFeatureLabel}` : coreName,
        basePrice: baseCorePrice + addonsPrice,
        baseCorePrice,
        features: resultFeatures,
        evcType: source.evcType || null,
        qty: moveCount,
        msaDiscountPct: (typeof vzUpsellDiscountPct === 'number' ? vzUpsellDiscountPct : source.msaDiscountPct) || 0,
        promoType: source.promoType || 'Standard',
        promoName: source.promoName || '',
        txLabel: 'Feature Upsell',
      };
      opt.bundles.push(target);
    }

    // Preserve the source's baseline before reducing it (same pattern as
    // vzAddCancelToOrder) so its own delta visual (red border, "X of Y
    // units") keeps working correctly too.
    if (source.originalQty === undefined) source.originalQty = source.qty;
    source.qty = Math.max(0, (Number(source.qty) || 0) - moveCount);
    movedTotal += moveCount;
  });

  closeBundleModal();
  renderOptions();
  document.getElementById('empty-state')?.classList.add('hidden');
  document.getElementById('options-grid')?.classList.remove('hidden');
  logProposalEvent('Option edited', `Upsell: ${featureLabel} on ${movedTotal} vehicle(s).`);
}

function renderVZCancelForm() {
  cancelViewMode = 'vehicle';
  const vzCancelPreSelected = txPreselectedSubIds.length > 0 ? [...txPreselectedSubIds] : [];
  txPreselectedSubIds = [];

  const area = document.getElementById('gc-tx-form-area');
  area.innerHTML = `
    <div class="gc-tx-step active" id="gc-cancel-step1">
      <div style="display:flex; align-items:center; justify-content:flex-end; gap:10px; margin-bottom:10px;">
        <span style="font-size:11px; font-weight:700; color:var(--gray-500);">Sort by:</span>
        <select class="select select--small" id="gc-cancel-view-select" data-vc-dropdown onchange="vzSetCancelViewMode(this.value)">
            <option value="vehicle">Vehicle</option>
            <option value="subscription">Subscription</option>
          </select>
      </div>
      <div style="border:1px solid var(--gray-200); border-radius:8px; overflow-x:auto; overflow-y:hidden;">
        <table class="gc-sub-table" style="width:100%; border-collapse:separate;" id="gc-cancel-table">
          <thead id="gc-cancel-thead"></thead>
          <tbody id="gc-cancel-tbody"></tbody>
        </table>
      </div>
    </div>
    <div class="gc-tx-step" id="gc-cancel-step2">
      <div class="gc-tx-reason">
        <label class="vc-field-label" for="gc-cancel-reason">Cancellation Reason</label>
        <select class="select" id="gc-cancel-reason" data-vc-dropdown onchange="vzUpdateCancelPreview()">
          <!-- 2026-10-06 (per Catalina): official cancellation reasons list. Grouped by its
               own prefixes (Sale / Relationship / Financial / Installation); the option shows
               the reason without the prefix, the stored label keeps it. -->
          <option value="">Select reason...</option>
          <optgroup label="Sale">
            <option data-label="Sale - Oversold" value="sale-oversold">Oversold</option>
            <option data-label="Sale - Product Fit/Misrepresentation" value="sale-product-fit-misrepresentation">Product Fit/Misrepresentation</option>
            <option data-label="Sale - Buyers Remorse" value="sale-buyers-remorse">Buyers Remorse</option>
            <option data-label="Sale - Deferred to later - Customer not ready" value="sale-deferred-to-later-customer-not-ready">Deferred to later - Customer not ready</option>
          </optgroup>
          <optgroup label="Relationship">
            <option data-label="Relationship - VZC Experience" value="relationship-vzc-experience">VZC Experience</option>
            <option data-label="Relationship - VZC System/Process Issues" value="relationship-vzc-system-process-issues">VZC System/Process Issues</option>
            <option data-label="Relationship - Agent Response Time" value="relationship-agent-response-time">Agent Response Time</option>
            <option data-label="Relationship - Agent Response Quality" value="relationship-agent-response-quality">Agent Response Quality</option>
          </optgroup>
          <optgroup label="Financial">
            <option data-label="Financial - Out of Business" value="financial-out-of-business">Out of Business</option>
            <option data-label="Financial - Sold Company" value="financial-sold-company">Sold Company</option>
          </optgroup>
          <optgroup label="Installation">
            <option data-label="Installation - Installation Appointment" value="installation-installation-appointment">Installation Appointment</option>
            <option data-label="Installation - Onboarding Quality" value="installation-onboarding-quality">Onboarding Quality</option>
            <option data-label="Installation - Shipping Error" value="installation-shipping-error">Shipping Error</option>
          </optgroup>
          <optgroup label="Other reasons">
            <option data-label="Unable to Obtain VINs" value="unable-to-obtain-vins">Unable to Obtain VINs</option>
            <option data-label="Unresponsive Customer" value="unresponsive-customer">Unresponsive Customer</option>
            <option data-label="Inventory Shortages" value="inventory-shortages">Inventory Shortages</option>
          </optgroup>
        </select>
      </div>
      <div class="gc-tx-reason">
        <div class="textarea-field">
          <label class="textarea-field__label" for="gc-cancel-notes">Additional Notes</label>
          <div class="textarea-field__container"><textarea class="textarea-field__input" id="gc-cancel-notes" rows="3" placeholder="Describe the circumstances..."></textarea></div>
        </div>
      </div>
    </div>`;

  window._vzCancelPreSelected = vzCancelPreSelected;
  vzRenderCancelTable();
  vzUpdateCancelPreview();

  setVZTxFooter(`
    <button class="btn btn--primary btn--large" id="gc-cancel-next-btn" onclick="vzGoCancelStep2()" disabled style="flex:none; padding:10px 24px; font-size:14px; opacity:0.4; cursor:not-allowed;">Select reason</button>
  `);
}

function vzGoCancelStep1() {
  document.getElementById('gc-cancel-step1').classList.add('active');
  document.getElementById('gc-cancel-step2').classList.remove('active');
  setVZTxFooter(`
    <button class="btn btn--primary btn--large" id="gc-cancel-next-btn" onclick="vzGoCancelStep2()" disabled style="flex:none; padding:10px 24px; font-size:14px; opacity:0.4; cursor:not-allowed;">Select reason</button>
  `);
  // Back to step 1: restore Cancel as the footer's left action (matches the
  // Upsell flow's pattern \u2014 Back on the left replaces the separate ghost
  // link, so the footer never shows 3 actions at once).
  const cancelBackBtn = document.getElementById('gc-tx-cancel-back-btn');
  if (cancelBackBtn) { cancelBackBtn.textContent = 'Cancel'; cancelBackBtn.onclick = closeBundleModal; }
  vzUpdateCancelCount();
}

function vzGoCancelStep2() {
  const count = document.querySelectorAll('.gc-cancel-cb:checked').length;
  if (!count) { showToast('Select at least one subscription'); return; }
  document.getElementById('gc-cancel-step1').classList.remove('active');
  document.getElementById('gc-cancel-step2').classList.add('active');
  vzUpdateCancelPreview();
  setVZTxFooter(`
    <button class="btn btn--primary btn--large" id="gc-cancel-add-btn" onclick="vzAddCancelToOrder()" style="flex:none; padding:10px 24px; font-size:14px;">Add Cancellation</button>
  `);
  // Step 2 of 2: swap the footer's left action from Cancel to Back, same
  // pattern as Upsell \u2014 no separate ghost Back link, so the footer only
  // ever shows 2 actions.
  const cancelBackBtn = document.getElementById('gc-tx-cancel-back-btn');
  if (cancelBackBtn) { cancelBackBtn.textContent = 'Back'; cancelBackBtn.onclick = vzGoCancelStep1; }
}

function vzSetCancelViewMode(mode) {
  cancelViewMode = mode;
  const sel = document.getElementById('gc-cancel-view-select');
  if (sel) sel.value = mode;
  vzRenderCancelTable();
}

function vzUpdateCancelCount() {
  const count = document.querySelectorAll('.gc-cancel-cb:checked').length;
  // Enable/disable the step1 "Select reason" next button
  const nextBtn = document.getElementById('gc-cancel-next-btn');
  if (nextBtn) {
    nextBtn.disabled = count === 0;
    nextBtn.style.opacity = count === 0 ? '0.4' : '1';
    nextBtn.style.cursor = count === 0 ? 'not-allowed' : 'pointer';
  }
  vzUpdateCancelPreview();
}

function vzRenderCancelTable() {
  const allSubsRaw = vzGenerateSubscriptions();
  // A vehicle that already has a pending Upsell (in this same option) can't
  // also be cancelled here \u2014 per Catalina: "no podr\u00eda cancelar un veh\u00edculo
  // que ya tiene un upsell agregado por m\u00ed anteriormente." The reverse
  // (Upsell excluding already-cancelled units) is already handled inside
  // vzGenerateSubscriptions() via excludedCancelIds.
  const alreadyUpsoldIds = vzGetAlreadyUpsoldSubIds();
  const allSubs = allSubsRaw.filter(s => !s.isCore || !alreadyUpsoldIds.has(s.id));
  const coreSubs = allSubs.filter(s => s.isCore);
  const addOnMap = {};
  allSubs.filter(s => !s.isCore).forEach(s => {
    if (s.linkedCoreSerial) {
      if (!addOnMap[s.linkedCoreSerial]) addOnMap[s.linkedCoreSerial] = [];
      addOnMap[s.linkedCoreSerial].push(s);
    }
  });
  const subs = coreSubs;
  const preSelected = window._vzCancelPreSelected || [];
  const thead = document.getElementById('gc-cancel-thead');
  const tbody = document.getElementById('gc-cancel-tbody');
  if (!thead || !tbody) return;

  if (cancelViewMode === 'vehicle') {
    thead.innerHTML = `
      <tr style="background:var(--white); border-bottom:2px solid var(--gray-200);">
        <th style="width:32px; padding:10px 8px; text-transform:none; font-size:13px; color:var(--black); letter-spacing:0;">
          <input type="checkbox" class="checkbox__input" onchange="vzToggleCancelAll(this)" style="flex-shrink:0;width:16px;height:16px;">
        </th>
        <th style="padding:10px 12px; text-transform:none; font-size:13px; color:var(--black); letter-spacing:0;">Vehicle/Asset</th>
        <th style="padding:10px 12px; text-transform:none; font-size:13px; color:var(--black); letter-spacing:0;">Name</th>
        <th style="padding:10px 12px; text-transform:none; font-size:13px; color:var(--black); letter-spacing:0;">License Plate</th>
        <th></th>
        <th></th>
      </tr>`;

    tbody.innerHTML = subs.slice(0, 50).map(s => {
      const vd = vzMockVehicleDetails(s.serial);
      const addons = addOnMap[s.serial] || [];
      const allVehicleSubs = [s, ...addons];

      const vehicleRow = `<tr style="background:var(--gray-100); border-top:2px solid var(--gray-200); cursor:pointer;"
          onclick="vzToggleCancelVehicle('${s.serial}')">
        <td style="padding:10px 8px; width:32px;" onclick="event.stopPropagation();">
          <label style="margin:0;">
            <input type="checkbox" class="gc-cancel-vehicle-hdr checkbox__input" data-serial="${s.serial}"
              onchange="vzToggleCancelVehicle('${s.serial}', this.checked)" style="width:16px;height:16px;">
          </label>
        </td>
        <td style="padding:10px 12px;">
          <div style="display:flex;align-items:center;gap:10px;">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="flex-shrink:0;color:var(--gray-600);"><path d="M7.55556 11.9999C7.55556 12.2197 7.49039 12.4345 7.3683 12.6172C7.24621 12.7999 7.07268 12.9423 6.86965 13.0264C6.66662 13.1105 6.44321 13.1325 6.22768 13.0897C6.01214 13.0468 5.81416 12.941 5.65877 12.7856C5.50338 12.6302 5.39756 12.4322 5.35468 12.2167C5.31181 12.0011 5.33381 11.7777 5.41791 11.5747C5.50201 11.3717 5.64442 11.1981 5.82714 11.076C6.00987 10.954 6.22469 10.8888 6.44444 10.8888C6.73913 10.8888 7.02174 11.0059 7.23012 11.2142C7.43849 11.4226 7.55556 11.7052 7.55556 11.9999ZM16.4444 11.9999C16.4444 12.2197 16.5096 12.4345 16.6317 12.6172C16.7538 12.7999 16.9273 12.9423 17.1304 13.0264C17.3334 13.1105 17.5568 13.1325 17.7723 13.0897C17.9879 13.0468 18.1858 12.941 18.3412 12.7856C18.4966 12.6302 18.6024 12.4322 18.6453 12.2167C18.6882 12.0011 18.6662 11.7777 18.5821 11.5747C18.498 11.3717 18.3556 11.1981 18.1729 11.076C17.9901 10.954 17.7753 10.8888 17.5556 10.8888C17.2609 10.8888 16.9783 11.0059 16.7699 11.2142C16.5615 11.4226 16.4444 11.7052 16.4444 11.9999ZM22 10.8888C21.9999 11.1834 21.8828 11.466 21.6744 11.6743C21.4661 11.8827 21.1835 11.9998 20.8889 11.9999H20.84L20.8889 12.2166V20.8888H16.4444V18.2866H7.55556V20.8888H3.11111V12.2166L3.16 11.9999H3.11111C2.81643 11.9999 2.53381 11.8828 2.32544 11.6745C2.11706 11.4661 2 11.1835 2 10.8888C2 10.5941 2.11706 10.3115 2.32544 10.1031C2.53381 9.89474 2.81643 9.77768 3.11111 9.77768H3.66111L4.68222 5.24101C4.83477 4.62492 5.19179 4.07879 5.69494 3.69189C6.19808 3.30499 6.81759 3.10021 7.4522 3.11101H16.5478C17.1823 3.10006 17.8017 3.30481 18.3047 3.69175C18.8077 4.07869 19.1645 4.62491 19.3166 5.24101L20.3389 9.77768H20.8889C21.1835 9.77778 21.4661 9.89487 21.6744 10.1032C21.8828 10.3116 21.9999 10.5941 22 10.8888ZM6.30556 18.2843H4.36111V19.6388H6.30556V18.2843ZM19.6389 18.2843H17.6944V19.6388H19.6389V18.2843ZM19.6389 12.3555L18.0978 5.51546C18.0066 5.17691 17.8041 4.8789 17.523 4.66948C17.2418 4.46005 16.8983 4.35139 16.5478 4.36101H7.45222C7.10175 4.35139 6.75824 4.46005 6.47705 4.66948C6.19587 4.87891 5.99338 5.17691 5.90222 5.51546L4.36111 12.3555V17.0343H19.6389V12.3555Z" fill="currentColor"/></svg>
            <div>
              <div style="font-weight:700; font-size:13px; line-height:1.3;">${vd.year} ${vd.make} ${vd.model}</div>
              <div style="font-size:11px; color:var(--gray-500); line-height:1.4;">VIN: ${s.vin}</div>
            </div>
          </div>
        </td>
        <td style="padding:10px 12px; font-size:12px; color:var(--gray-600);">${s.vehicleName}</td>
        <td style="padding:10px 12px; font-size:12px; color:var(--gray-600);">${vd.plate}</td>
        <td></td>
        <td></td>
      </tr>`;

      const subColHeaders = `<tr style="background:var(--white); border-bottom:1px solid var(--gray-200);">
        <td style="width:32px; padding:6px 8px;"></td>
        <td style="padding:6px 12px; font-size:12px; font-weight:600; color:var(--gray-500);">Subscription</td>
        <td style="padding:6px 12px; font-size:12px; font-weight:600; color:var(--gray-500);">Tech Ref ID</td>
        <td style="padding:6px 12px; font-size:12px; font-weight:600; color:var(--gray-500);">Hardware</td>
        <td style="padding:6px 12px; font-size:12px; font-weight:600; color:var(--gray-500);">Rate / mo</td>
        <td style="padding:6px 12px; font-size:12px; font-weight:600; color:var(--gray-500);">Remain Mo</td>
      </tr>`;

      const subRows = allVehicleSubs.map(sub => {
        const checked = preSelected.includes(sub.id) ? 'checked' : '';
        let hh = 0; for (let i = 0; i < sub.serial.length; i++) hh = (hh * 31 + sub.serial.charCodeAt(i)) | 0;
        const hwList = ['OBD-II', 'Hardwired', 'Asset Tracker', 'Trailer Tracker'];
        const hw = hwList[Math.abs(hh >> 2) % hwList.length];
        return `<tr style="background:var(--white); border-bottom:1px solid var(--gray-100);">
          <td style="padding:8px 8px;">
            <label style="margin:0;">
              <input type="checkbox" class="gc-cancel-cb checkbox__input" data-serial="${s.serial}" data-product="${sub.product}" data-corekey="${sub.productKey}"
                value="${sub.id}" data-rate="${sub.rate}" data-remain="${sub.remainMonths}" ${checked} onchange="vzUpdateCancelCount(); vzSyncCancelVehicleHdr('${s.serial}')" style="width:16px;height:16px;">
            </label>
          </td>
          <td style="padding:8px 12px; font-size:12px;">${sub.product}</td>
          <td style="padding:8px 12px; font-size:12px; color:var(--gray-600);">${sub.techRef}</td>
          <td style="padding:8px 12px; font-size:12px;">${hw}</td>
          <td style="padding:8px 12px; font-size:12px; font-weight:700; color:var(--red);">-${formatMoney(sub.rate)}</td>
          <td style="padding:8px 12px; font-size:12px; color:var(--gray-600);">${sub.remainMonths} mo</td>
        </tr>`;
      }).join('');

      return vehicleRow + subColHeaders + subRows;
    }).join('');

  } else {
    // BY SUBSCRIPTION
    const groups = {};
    allSubs.forEach(s => {
      if (!groups[s.productKey]) groups[s.productKey] = { label: s.product, items: [] };
      groups[s.productKey].items.push(s);
    });

    thead.innerHTML = '';
    tbody.innerHTML = Object.entries(groups).map(([key, group]) => {
      const subHeader = `<tr style="background:var(--gray-100); border-top:2px solid var(--gray-200);">
        <td colspan="6" style="padding:10px 14px;">
          <div style="display:flex; align-items:center; gap:10px;">
            <label style="margin:0;flex-shrink:0;">
              <input type="checkbox" data-group="${key}" onchange="vzToggleCancelGroup('${key}', this.checked)" class="checkbox__input" style="width:16px;height:16px;">
            </label>
            <span style="font-weight:700; font-size:13px;">${group.label}</span>
            <span style="font-size:10px;background:var(--stone);border:1px solid var(--gray-200);border-radius:999px;padding:2px 8px;">${group.items.length} vehicles</span>
          </div>
        </td>
      </tr>
      <tr style="background:var(--white); border-bottom:1px solid var(--gray-200);">
        <td style="width:32px; padding:6px 8px;"></td>
        <td style="padding:6px 12px; font-size:12px; font-weight:600; color:var(--gray-500);">Vehicle</td>
        <td style="padding:6px 12px; font-size:12px; font-weight:600; color:var(--gray-500);">Name</td>
        <td style="padding:6px 12px; font-size:12px; font-weight:600; color:var(--gray-500);">Plate</td>
        <td style="padding:6px 12px; font-size:12px; font-weight:600; color:var(--gray-500);">Rate / mo</td>
        <td style="padding:6px 12px; font-size:12px; font-weight:600; color:var(--gray-500);">Remain Mo</td>
      </tr>`;

      const vehicleRows = group.items.map(s => {
        const checked = preSelected.includes(s.id) ? 'checked' : '';
        const vd = vzMockVehicleDetails(s.serial);
        return `<tr style="background:var(--white); border-bottom:1px solid var(--gray-100); cursor:pointer;"
            onclick="var cb=this.querySelector('.gc-cancel-cb'); cb.checked=!cb.checked; vzUpdateCancelCount();">
          <td style="padding:8px 8px; width:32px;" onclick="event.stopPropagation();">
            <label style="margin:0;">
              <input type="checkbox" class="gc-cancel-cb checkbox__input"
                value="${s.id}" data-group="${key}" data-product="${s.product}" data-corekey="${s.productKey}" data-rate="${s.rate}" data-remain="${s.remainMonths}" ${checked} onchange="vzUpdateCancelCount()" style="width:16px;height:16px;">
            </label>
          </td>
          <td style="padding:8px 12px;">
            <div style="font-size:12px; font-weight:700;">${vd.year} ${vd.make} ${vd.model}</div>
            <div style="font-size:11px; color:var(--gray-600);">${s.vin}</div>
          </td>
          <td style="padding:8px 12px; font-size:12px; color:var(--gray-600);">${s.vehicleName}</td>
          <td style="padding:8px 12px; font-size:12px; color:var(--gray-600);">${vd.plate}</td>
          <td style="padding:8px 12px; font-size:12px; font-weight:700; color:var(--red);">-${formatMoney(s.rate)}</td>
          <td style="padding:8px 12px; font-size:12px; color:var(--gray-600);">${s.remainMonths} mo</td>
        </tr>`;
      }).join('');

      return subHeader + vehicleRows;
    }).join('');
  }

  vzUpdateCancelCount();
}

function vzToggleCancelAll(el) {
  document.querySelectorAll('.gc-cancel-cb').forEach(cb => cb.checked = el.checked);
  vzUpdateCancelCount();
}

function vzToggleCancelVehicle(serial, checked) {
  const cbs = document.querySelectorAll(`.gc-cancel-cb[data-serial="${serial}"]`);
  const newState = checked !== undefined ? checked : !([...cbs].every(cb => cb.checked));
  cbs.forEach(cb => cb.checked = newState);
  vzSyncCancelVehicleHdr(serial);
  vzUpdateCancelCount();
}

function vzSyncCancelVehicleHdr(serial) {
  const hdr = document.querySelector(`.gc-cancel-vehicle-hdr[data-serial="${serial}"]`);
  if (!hdr) return;
  const cbs = [...document.querySelectorAll(`.gc-cancel-cb[data-serial="${serial}"]`)];
  hdr.checked = cbs.length > 0 && cbs.every(cb => cb.checked);
  hdr.indeterminate = !hdr.checked && cbs.some(cb => cb.checked);
}

function vzToggleCancelGroup(groupKey, checked) {
  document.querySelectorAll(`.gc-cancel-cb[data-group="${groupKey}"]`)
    .forEach(cb => cb.checked = checked);
  vzUpdateCancelCount();
}

function vzUpdateCancelPreview() {
  const pane = document.getElementById('gc-tx-preview-area');
  if (!pane) return;
  const selected = [...document.querySelectorAll('.gc-cancel-cb:checked')];
  const mrrLoss = selected.reduce((s, cb) => s + parseFloat(cb.dataset.rate || 0), 0);
  const ecf = selected.reduce((s, cb) => s + parseFloat(cb.dataset.rate || 0) * Math.max(0, parseInt(cb.dataset.remain) || 0) * 0.5, 0);
  const lossValue = selected.length ? `-${formatMoney(mrrLoss)}` : '$0.00';
  const lossColor = selected.length ? 'var(--red)' : 'var(--black)';

  // Build selected subscription list
  const subList = selected.length ? `
    <div style="font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:0.06em; color:var(--gray-500); margin-bottom:6px; margin-top:4px;">Selected subscriptions</div>
    <div style="font-size:13px; font-weight:600; color:var(--black); margin-bottom:12px;">${selected.length} subscription${selected.length === 1 ? '' : 's'}</div>
    <div class="preview-line-items">
      ${selected.slice(0, 6).map(cb => `<div class="preview-line" style="font-size:11px;"><span style="color:var(--gray-700);">${cb.dataset.product || cb.dataset.serial || 'Subscription'}</span><span style="color:var(--red);">-${formatMoney(parseFloat(cb.dataset.rate||0))}</span></div>`).join('')}
      ${selected.length > 6 ? `<div style="font-size:11px; color:var(--gray-500); margin-top:4px;">+${selected.length - 6} more</div>` : ''}
      <div class="preview-line" style="font-weight:700; margin-top:8px; padding-top:8px; border-top:1px solid var(--gray-200);"><span>Annual loss</span><span style="color:var(--red);">-${formatMoney((mrrLoss*12))}/yr</span></div>
      <div class="preview-line" style="margin-top:4px;"><span>Est. ECF</span><span style="color:var(--orange);">${formatMoney(ecf)}</span></div>
      <div style="font-size:10px; color:var(--gray-500); margin-top:2px;">ECF at 50% of remaining contract</div>
    </div>` : `<div style="color:var(--gray-500); font-size:12px; line-height:1.5;">Select subscriptions to see cancellation impact</div>`;

  pane.innerHTML = `
    <div class="preview-label" style="margin-bottom:6px;">Cancellation Preview</div>
    <div class="preview-price" style="color:${lossColor};">${lossValue}</div>
    <div style="font-size:12px; color:var(--gray-600); margin-bottom:20px;">/mo MRR reduction</div>
    ${subList}`;
}

function vzAddCancelToOrder() {
  const reason = document.getElementById('gc-cancel-reason');
  if (reason && !reason.value) { showToast('Select a cancellation reason'); return; }
  const selected = [...document.querySelectorAll('.gc-cancel-cb:checked')];
  if (!selected.length) { showToast('Select at least one subscription'); return; }
  const reasonOpt = reason ? reason.options[reason.selectedIndex] : null;
  const reasonLabel = reasonOpt ? (reasonOpt.dataset.label || reasonOpt.textContent.trim()) : '';
  const count = selected.length;

  const opt = bld.targetOptId ? options.find(o => o.id === bld.targetOptId) : null;
  if (!opt) { showToast('No option to apply the cancellation to'); return; }

  if (proposalData.entryPoint !== 'renewalRewrap') {
    const selectedIds = selected.map(cb => cb.value);
    const selectedCoreKeys = [...new Set(selected.map(cb => cb.dataset.corekey).filter(Boolean))];
    const realBundles = (Array.isArray(existingOrders) ? existingOrders : []).flatMap(order => order.bundles || []);
    const selectedBundles = selectedCoreKeys.map(coreKey => realBundles.find(bundle => bundle.coreKey === coreKey)).filter(Boolean);
    const unitRate = selectedBundles.length
      ? selectedBundles.reduce((sum, bundle) => sum + Number(calcBundle(bundle, 36, bundle.promoType || 'Standard', bundle.qty).unitPrice || 0), 0) / selectedBundles.length
      : 0;
    const productLabel = selectedBundles.map(bundle => bundle.coreName).join(' + ') || 'selected products';
    const isolatedBundle = {
      id: bld.targetBundleId || Date.now(),
      coreKey: 'transaction-cancel',
      coreName: `${productLabel}`,
      basePrice: -unitRate,
      baseCorePrice: -unitRate,
      features: [],
      qty: selected.length,
      isMsaAuxiliary: true,
      isolatedTransactionType: 'cancel',
      selectedSubIds: selectedIds,
      txLabel: 'Cancellation',
      promoType: 'Standard',
      promoName: '',
      cancellationReason: reasonLabel
    };
    const existingIndex = bld.targetBundleId
      ? opt.bundles.findIndex(bundle => bundle.id === bld.targetBundleId)
      : -1;
    if (existingIndex >= 0) opt.bundles[existingIndex] = isolatedBundle;
    else opt.bundles.push(isolatedBundle);
    closeBundleModal();
    renderOptions();
    document.getElementById('empty-state')?.classList.add('hidden');
    document.getElementById('options-grid')?.classList.remove('hidden');
    logProposalEvent('Option edited', `Cancellation: ${selected.length} subscription${selected.length > 1 ? 's' : ''} reduced. Reason: ${reasonLabel}.`);
    return;
  }

  const currentBundles = opt.bundles.filter(bundle => bundle.originalQty !== undefined);
  const selectedCoreKeys = [...new Set(selected.map(cb => cb.dataset.corekey).filter(Boolean))];
  const selectedBundles = selectedCoreKeys.map(coreKey => currentBundles.find(bundle => bundle.coreKey === coreKey)).filter(Boolean);
  const unitRate = selectedBundles.length
    ? selectedBundles.reduce((sum, bundle) => sum + Number(calcBundle(bundle, opt.term || 36, bundle.promoType || 'Standard', bundle.qty).unitPrice || 0), 0) / selectedBundles.length
    : 0;
  const productLabel = selectedBundles.map(bundle => bundle.coreName).join(' + ') || 'selected products';
  opt.bundles.push({
    id: bld.targetBundleId || Date.now(),
    coreKey: 'transaction-cancel',
    coreName: `${productLabel}`,
    basePrice: -unitRate,
    baseCorePrice: -unitRate,
    features: [],
    qty: selected.length,
    isMsaAuxiliary: true,
    isolatedTransactionType: 'cancel',
    selectedSubIds: selected.map(cb => cb.value),
    txLabel: 'Cancellation',
    promoType: 'Standard',
    promoName: '',
    cancellationReason: reasonLabel
  });
  closeBundleModal();
  renderOptions();
  document.getElementById('empty-state')?.classList.add('hidden');
  document.getElementById('options-grid')?.classList.remove('hidden');
  logProposalEvent('Option edited', `Cancellation: ${selected.length} subscription${selected.length > 1 ? 's' : ''} reduced. Reason: ${reasonLabel}.`);
  return;

  const removeByCore = {};
  selected.forEach(cb => {
    const key = cb.dataset.corekey;
    if (!key) return;
    removeByCore[key] = (removeByCore[key] || 0) + 1;
  });

  Object.entries(removeByCore).forEach(([coreKey, removeCount]) => {
    const bundle = opt.bundles.find(b => b.coreKey === coreKey);
    if (!bundle) return;
    if (bundle.originalQty === undefined) bundle.originalQty = bundle.qty;
    bundle.qty = Math.max(0, (Number(bundle.qty) || 0) - removeCount);
  });

  closeBundleModal();
  renderOptions();
  document.getElementById('empty-state')?.classList.add('hidden');
  document.getElementById('options-grid')?.classList.remove('hidden');
  const optionNumber = Math.max(1, options.findIndex(o => o.id === opt.id) + 1);
  logProposalEvent('Option edited', `${count} subscription${count > 1 ? 's' : ''} reduced on Option ${optionNumber}. Reason: ${reasonLabel}.`);
}

function renderVZReactivationForm() {
  vzReactivationPreSelected = txPreselectedSubIds.length > 0 ? [...txPreselectedSubIds] : [];
  txPreselectedSubIds = [];

  const area = document.getElementById('gc-tx-form-area');
  area.innerHTML = `
    <div class="gc-tx-step active" id="gc-reactivation-step1">
      <div class="gc-tx-step-header">
        <div class="gc-tx-step-title">Previously Deactivated Units</div>
      </div>
      <table class="gc-sub-table" style="width:100%; border:1px solid var(--gray-200); border-radius:8px; overflow:hidden; border-collapse:separate;" id="gc-reactivation-table">
        <thead id="gc-reactivation-thead"></thead>
        <tbody id="gc-reactivation-tbody"></tbody>
      </table>
    </div>`;

  vzRenderReactivationTable();
  vzUpdateReactivationPreview();

  setVZTxFooter(`
    <button class="btn btn--primary btn--large" id="gc-reactivation-add-btn" onclick="vzAddReactivationToOrder()" disabled style="flex:none; padding:10px 24px; font-size:14px; opacity:0.4; cursor:not-allowed;">Add Reactivation</button>
  `);
}

function vzRenderReactivationTable() {
  const thead = document.getElementById('gc-reactivation-thead');
  const tbody = document.getElementById('gc-reactivation-tbody');
  if (!thead || !tbody) return;
  const preSelected = Array.isArray(vzReactivationPreSelected) ? vzReactivationPreSelected : [];

  thead.innerHTML = `
    <tr style="background:var(--white); border-bottom:2px solid var(--gray-200);">
      <th style="width:32px; padding:10px 8px; text-transform:none; font-size:13px; color:var(--black); letter-spacing:0;">
        <input type="checkbox" class="checkbox__input" onchange="vzToggleReactivationAll(this)" style="flex-shrink:0;width:16px;height:16px;">
      </th>
      <th style="padding:10px 12px; text-transform:none; font-size:13px; color:var(--black); letter-spacing:0;">Vehicle/Asset</th>
      <th style="padding:10px 12px; text-transform:none; font-size:13px; color:var(--black); letter-spacing:0;">QTY</th>
      <th style="padding:10px 12px; text-transform:none; font-size:13px; color:var(--black); letter-spacing:0;">Deactivated</th>
      <th style="padding:10px 12px; text-transform:none; font-size:13px; color:var(--black); letter-spacing:0;">Reason</th>
    </tr>`;

  tbody.innerHTML = DEMO_PREVIOUSLY_DEACTIVATED_UNITS.map(unit => {
    const checked = preSelected.includes(unit.id) ? 'checked' : '';
    const reasonLabel = unit.reason === 'downgrade' ? 'Downgrade' : 'Cancellation';
    return `<tr style="background:var(--white); border-bottom:1px solid var(--gray-100);">
      <td style="padding:8px 8px; width:32px;">
        <label style="margin:0;">
          <input type="checkbox" class="gc-reactivation-cb checkbox__input" value="${unit.id}"
            data-corekey="${unit.coreKey}" data-corename="${unit.coreName}" data-qty="${unit.qty}"
            ${checked} onchange="vzUpdateReactivationCount()" style="width:16px;height:16px;">
        </label>
      </td>
      <td style="padding:8px 12px; font-size:13px; font-weight:700;">${unit.coreName}</td>
      <td style="padding:8px 12px; font-size:12px; color:var(--gray-600);">${unit.qty}</td>
      <td style="padding:8px 12px; font-size:12px; color:var(--gray-600);">${vzFmtDate(unit.deactivatedDate)}</td>
      <td style="padding:8px 12px; font-size:12px; color:var(--gray-600);">${reasonLabel}</td>
    </tr>`;
  }).join('');

  vzUpdateReactivationCount();
}

function vzToggleReactivationAll(el) {
  document.querySelectorAll('.gc-reactivation-cb').forEach(cb => cb.checked = el.checked);
  vzUpdateReactivationCount();
}

function vzUpdateReactivationCount() {
  const count = document.querySelectorAll('.gc-reactivation-cb:checked').length;
  const btn = document.getElementById('gc-reactivation-add-btn');
  if (btn) {
    btn.disabled = count === 0;
    btn.style.opacity = count === 0 ? '0.4' : '1';
    btn.style.cursor = count === 0 ? 'not-allowed' : 'pointer';
  }
  vzUpdateReactivationPreview();
}

function vzGetReactivationUnitPrice(coreKey, qty, term) {
  const core = corePricing[coreKey];
  const dummyBundle = { coreKey, basePrice: core?.price || 0, baseCorePrice: core?.price || 0, qty, features: [] };
  try { return calcBundle(dummyBundle, term, 'Standard', qty).unitPrice; } catch (_) { return core?.price || 0; }
}

function vzUpdateReactivationPreview() {
  const pane = document.getElementById('gc-tx-preview-area');
  if (!pane) return;
  const selected = [...document.querySelectorAll('.gc-reactivation-cb:checked')];
  const term = bld.targetOptId ? (options.find(o => o.id === bld.targetOptId)?.term || 36) : 36;

  const rows = selected.map(cb => {
    const qty = Number(cb.dataset.qty) || 0;
    const unitPrice = vzGetReactivationUnitPrice(cb.dataset.corekey, qty, term);
    return { coreName: cb.dataset.corename, qty, monthly: unitPrice * qty };
  });
  const totalMonthly = rows.reduce((sum, r) => sum + r.monthly, 0);

  const rowsHtml = rows.length ? `
    <div style="font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:0.06em; color:var(--gray-500); margin-bottom:6px; margin-top:4px;">Units to reactivate</div>
    <div class="preview-line-items">
      ${rows.map(r => `<div class="preview-line" style="font-size:12px;"><span>${r.coreName} \u00d7 ${r.qty}</span><span style="color:var(--green);">+${formatMoney(r.monthly)}/mo</span></div>`).join('')}
      <div class="preview-line" style="font-weight:700; margin-top:8px; padding-top:8px; border-top:1px solid var(--gray-200);"><span>Annual impact</span><span style="color:var(--green);">+${formatMoney((totalMonthly * 12))}/yr</span></div>
    </div>` : `<div style="color:var(--gray-500); font-size:12px; line-height:1.5;">Select units to see reactivation impact</div>`;

  pane.innerHTML = `
    <div class="preview-label" style="margin-bottom:6px;">Reactivation Preview</div>
    <div class="preview-price" style="color:var(--green);">+$<span>${formatMoneyAmount(totalMonthly)}</span></div>
    <div style="font-size:12px; color:var(--gray-600); margin-bottom:20px;">/mo MRR added</div>
    ${rowsHtml}`;
}

function vzAddReactivationToOrder() {
  const selected = [...document.querySelectorAll('.gc-reactivation-cb:checked')];
  if (!selected.length) { showToast('Select at least one unit to reactivate'); return; }

  const opt = bld.targetOptId ? options.find(o => o.id === bld.targetOptId) : null;
  if (!opt) { showToast('No option to apply the reactivation to'); return; }

  const term = opt.term || 36;
  const totalQty = selected.reduce((sum, cb) => sum + (Number(cb.dataset.qty) || 0), 0);
  const totalMonthly = selected.reduce((sum, cb) => {
    const qty = Number(cb.dataset.qty) || 0;
    return sum + vzGetReactivationUnitPrice(cb.dataset.corekey, qty, term) * qty;
  }, 0);
  const unitRate = totalQty ? totalMonthly / totalQty : 0;
  const productLabel = selected.map(cb => cb.dataset.corename).join(' + ');
  const selectedIds = selected.map(cb => cb.value);

  const isolatedBundle = {
    id: bld.targetBundleId || Date.now(),
    coreKey: 'transaction-reactivation',
    coreName: productLabel,
    basePrice: unitRate,
    baseCorePrice: unitRate,
    features: [],
    qty: totalQty,
    isMsaAuxiliary: true,
    isolatedTransactionType: 'reactivate',
    selectedSubIds: selectedIds,
    txLabel: 'Reactivation',
    promoType: 'Standard',
    promoName: ''
  };
  const existingIndex = bld.targetBundleId
    ? opt.bundles.findIndex(bundle => bundle.id === bld.targetBundleId)
    : -1;
  if (existingIndex >= 0) opt.bundles[existingIndex] = isolatedBundle;
  else opt.bundles.push(isolatedBundle);

  closeBundleModal();
  renderOptions();
  document.getElementById('empty-state')?.classList.add('hidden');
  document.getElementById('options-grid')?.classList.remove('hidden');
  logProposalEvent('Option edited', `Reactivation: ${totalQty} unit${totalQty === 1 ? '' : 's'} reactivated.`);
}

function vzRestoreUpsellFeatureSelection(container) {
  if (!container) return;
  const selected = new Set(vzUpsellPreSelectedFeatures || []);
  container.querySelectorAll('.gc-upsell-feature-cb').forEach((checkbox) => {
    if (!selected.has(checkbox.value)) return;
    checkbox.checked = true;
    checkbox.closest('.gc-tx-feature-option')?.classList.add('selected');
  });
}

function vzCaptureUpsellFeatureSelectionFromDom() {
  const featureInputs = [...document.querySelectorAll('.gc-upsell-feature-cb')];
  if (!featureInputs.length) return;
  vzUpsellPreSelectedFeatures = featureInputs
    .filter((checkbox) => checkbox.checked)
    .map((checkbox) => checkbox.value);
}

// \u2500\u2500 Existing-only globals and patches \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
window.startRenewalRewrapProposal = startRenewalRewrapProposal;

window.startReactivationProposal = startReactivationProposal;

window.setCancelPenaltyWave = setCancelPenaltyWave;

window.openCancelMcModal = function openCancelMcModal() {
  options = [];
  nextOptId = 1;
  const opt = window.createOptionFromCurrent('Cancel MC');
  if (!opt) return;
  opt.transactionMode = 'Cancel';
  bld.selectedOptionId = opt.id;
  document.getElementById('cancel-mc-modal-summary').innerHTML = getCancelMcSummaryHtml();
  document.getElementById('cancel-mc-modal-hardware').innerHTML = getHardwareAccordionHtml(opt, 'modal-' + opt.id);
  renderCancelMcModalPenalty();
  document.getElementById('cancel-mc-modal-overlay').classList.add('is-open');
};

window.openCancelAutoRenewalModal = function openCancelAutoRenewalModal() {
  const reasonInput = document.getElementById('car-reason');
  const reasonError = document.getElementById('car-reason-error');
  const uploadInput = document.getElementById('car-upload-input');
  const uploadFilename = document.getElementById('car-upload-filename');
  const uploadError = document.getElementById('car-upload-error');
  if (reasonInput) {
    reasonInput.value = '';
    reasonInput.classList.remove('input--error');
  }
  if (reasonError) reasonError.classList.add('hidden');
  if (uploadInput) uploadInput.value = '';
  if (uploadFilename) { uploadFilename.classList.add('hidden'); uploadFilename.textContent = ''; }
  if (uploadError) uploadError.classList.add('hidden');
  updateCancelAutoRenewalSubmitState();
  const endBlock = document.getElementById('car-contract-end-block');
  const endValueEl = document.getElementById('car-contract-end-value');
  if (endBlock && endValueEl) {
    if (DEMO_MSA.endDate) {
      const endDate = new Date(DEMO_MSA.endDate + 'T00:00:00');
      const now = new Date();
      const monthsLeft = Math.max(0, Math.round((endDate - now) / (1000 * 60 * 60 * 24 * 30.44)));
      const endDateLabel = endDate.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
      endValueEl.textContent = `${endDateLabel} \u2014 ${monthsLeft} month${monthsLeft === 1 ? '' : 's'} remaining`;
      endBlock.classList.remove('hidden');
    } else {
      endBlock.classList.add('hidden');
    }
  }
  document.getElementById('cancel-auto-renewal-modal-overlay')?.classList.add('is-open');
};

document.addEventListener('click', () => {
  document.querySelectorAll('.msa-commitment-menu').forEach(menu => setKebabMenuOpen(menu, false));
});

(function patchUpsellFeatureStatePersistence() {
  if (typeof window.confirmBundleTxType === 'function') {
    const originalConfirmBundleTxType = window.confirmBundleTxType;
    window.confirmBundleTxType = function patchedConfirmBundleTxType(...args) {
      const isUpsell = bld?.txType === 'upsell';
      if (isUpsell) {
        const existingUpsell = bld.targetOptId && bld.targetBundleId
          ? options.find((option) => option.id === bld.targetOptId)?.bundles.find((bundle) => bundle.id === bld.targetBundleId)
          : null;
        vzUpsellPreSelectedFeatures = existingUpsell?.isolatedTransactionType === 'upsell'
          ? [...(existingUpsell.features || [])]
          : [];
      }

      const result = originalConfirmBundleTxType.apply(this, args);

      if (isUpsell && typeof window.renderVZUpsellForm === 'function') {
        const area = document.getElementById('gc-tx-body') || document;
        if (upsellMode === 'features') {
          vzRestoreUpsellFeatureSelection(area);
        }
      }

      return result;
    };
  }

  if (typeof window.renderVZUpsellForm === 'function') {
    const originalRenderVZUpsellForm = window.renderVZUpsellForm;
    window.renderVZUpsellForm = function patchedRenderVZUpsellForm(...args) {
      const result = originalRenderVZUpsellForm.apply(this, args);
      const area = document.getElementById('gc-tx-body') || document;
      if (upsellMode === 'features') {
        vzRestoreUpsellFeatureSelection(area);
      }
      return result;
    };
  }

  if (typeof window.vzGoUpsellStep1 === 'function') {
    const originalVzGoUpsellStep1 = window.vzGoUpsellStep1;
    window.vzGoUpsellStep1 = function patchedVzGoUpsellStep1(...args) {
      vzCaptureUpsellFeatureSelectionFromDom();
      return originalVzGoUpsellStep1.apply(this, args);
    };
  }

  if (typeof window.vzGoUpsellStep2 === 'function') {
    const originalVzGoUpsellStep2 = window.vzGoUpsellStep2;
    window.vzGoUpsellStep2 = function patchedVzGoUpsellStep2(...args) {
      const result = originalVzGoUpsellStep2.apply(this, args);
      const body = document.getElementById('gc-tx-body') || document;
      vzRestoreUpsellFeatureSelection(body);
      if (typeof window.vzUpdateUpsellPreview === 'function') {
        window.vzUpdateUpsellPreview();
      }
      return result;
    };
  }

  if (typeof window.vzSetUpsellMode === 'function') {
    const originalVzSetUpsellMode = window.vzSetUpsellMode;
    window.vzSetUpsellMode = function patchedVzSetUpsellMode(...args) {
      vzCaptureUpsellFeatureSelectionFromDom();
      const result = originalVzSetUpsellMode.apply(this, args);
      const area = document.getElementById('gc-tx-body') || document;
      if (upsellMode === 'features') {
        vzRestoreUpsellFeatureSelection(area);
      }
      return result;
    };
  }
})();

// \u2500\u2500 Existing versions of steps that differ from Initial Sales (swapped in by setExistingAccountsMode) \u2500\u2500
const EXISTING_ACCOUNTS_OVERRIDES = {
  calcOption: function calcOption(opt, promoType = 'Standard', forcedTierIndex = -1) {
  const customPromotions = getActiveCustomPromotionsForPricing(opt);
  return VC.calcOption(opt, promoType, {
    prepareBundle: bundle => ({ ...bundle, msaDiscountPct: getOptionDiscountPct(opt, bundle) }),
    getTerm: option => proposalData.isAddOn && proposalData.segment !== 'Government' && !isSpecialOptionMode(option)
      ? (Number(option.term) || getMsaMonthsRemaining() || 36)
      : option.term,
    // Tier (Catalina, 2026-10-09): the MSA tier is already set, so it only changes with a Rewrap. Rewrap (and
    // Reactivation) count the vehicles contracted after the change \u2014 a partial cancellation lowers the count;
    // Create new proposal and Renewal keep the account's current MSA tier.
    getTierQty: (option, tierBundles, units) => isOptionTierLocked(option) ? getAccountMsaTierUnits() : units,
    getMsaTierUnits: bundle => bundle.isolatedTransactionType === 'cancel'
      ? -(Number(bundle.qty) || 0)
      : getMsaTierQty(bundle.qty, bundle.coreKey),
    getCustomPromotionAmount: (bundle, option, unitPrice) => customPromotions.length
      ? getCustomPromoAmountForBundle(bundle, customPromotions, 0, unitPrice)
      : 0,
    getBundleMonthly: (bundle, option, result, customPromoUnit) => bundle.isMsaAuxiliary && bundle.isolatedTransactionType === 'cancel'
      ? result.monthly
      : Math.max(0, result.monthly - customPromoUnit * bundle.qty),
  });
},

  getOptionDiscountPct: function getOptionDiscountPct(opt, bundle) {
  return typeof opt?.discretionaryDiscountPct === 'number'
    ? opt.discretionaryDiscountPct
    : (typeof bundle?.msaDiscountPct === 'number' ? bundle.msaDiscountPct : 0);
},

  setOptionDiscountPct: function setOptionDiscountPct(opt, pct) {
  opt.discretionaryDiscountPct = pct;
  opt.bundles.forEach(bundle => { bundle.msaDiscountPct = pct; });
},

  openAccountStatusDetails: function openAccountStatusDetails() { openAccountValidationScreen(); },

  setContractMsaCommitment: function setContractMsaCommitment() {},

  onStageNavRendered: function onStageNavRendered() { renderStepMsaCommitmentPanels(); },

  updateDraftingHeaderTitle: function updateDraftingHeaderTitle() {
  const titleEl = document.getElementById('drafting-header-title');
  if (!titleEl) return;
  titleEl.textContent = 'Quote Options Comparison';

  // Title is intentionally locked for this flow: keep editing controls disabled.
  inlineDraftTitleEditActive = false;
  const editBtn = document.getElementById('drafting-title-edit-btn');
  if (editBtn) {
    editBtn.style.display = 'none';
    editBtn.style.pointerEvents = 'none';
    editBtn.setAttribute('aria-hidden', 'true');
    editBtn.setAttribute('tabindex', '-1');
  }
  const wrapEl = document.getElementById('drafting-title-input-wrap');
  if (wrapEl) wrapEl.style.display = 'none';

  // Keep breadcrumb in sync
  const breadcrumb = document.getElementById('breadcrumb-quote-name');
  if (breadcrumb) breadcrumb.textContent = proposalData.proposalId ? String(proposalData.proposalId).trim() : 'Create new';
},

  startInlineDraftTitleEdit: function startInlineDraftTitleEdit() {
  return;
},

  openConfigureBundle: function openConfigureBundle(optId, bundleId) {
  bld.targetOptId = optId || null;
  bld.targetBundleId = bundleId || null;

  const optionLabelEl = document.getElementById('bundle-option-label');
  if (optionLabelEl) {
    if (optId) {
      const optionIndex = options.findIndex((o) => o.id === optId);
      optionLabelEl.innerText = `Option ${Math.max(1, optionIndex + 1)}`;
    } else {
      optionLabelEl.innerText = `Option ${options.length + 1}`;
    }
  }

  const modal = document.querySelector('#bundle-overlay .bundle-modal');
  modal?.classList.remove('bundle-modal--transaction', 'bundle-modal--summary-shell');
  if (bundleId) {
    // Editing existing bundle \u2014 skip tx type step, go straight to configure
    if (modal) {
      modal.classList.remove('modal--md', 'bundle-modal--compact');
      modal.classList.add('modal--lg', 'bundle-modal--configure-solution', 'bundle-modal--summary-shell');
    }
    document.getElementById('bundle-step-tx-type').style.display = 'none';
    document.getElementById('bundle-step-configure').style.display = 'flex';
    document.querySelector('.bundle-mode-toggle')?.classList.add('hidden');
    document.getElementById('bundle-modal-title').innerText = 'Configure Solution';
    const panelTxEdit = document.getElementById('bundle-panel-tx');
    const panelAddEdit = document.getElementById('bundle-panel-add');
    if (panelTxEdit) panelTxEdit.style.display = 'none';
    if (panelAddEdit) panelAddEdit.style.display = 'flex';
    const editBundle = options.find(o => o.id === optId)?.bundles.find(b => b.id === bundleId);
    eaOpenExpansionForm(optId, editBundle);
    document.getElementById('btn-create').innerText = 'Update Solution';
  } else {
    // New bundle \u2014 show tx type selection first (compact)
    if (modal) {
      modal.classList.remove('modal--lg', 'bundle-modal--wide', 'bundle-modal--configure-solution', 'bundle-modal--summary-shell');
      modal.classList.add('modal--md', 'bundle-modal--compact');
    }
    _resetBundleTxTypeStep();
    document.getElementById('bundle-step-tx-type').style.display = 'flex';
    document.getElementById('bundle-step-configure').style.display = 'none';
    document.querySelector('.bundle-mode-toggle')?.classList.add('hidden');
    // 2026-09-18 (per Catalina): "New item" undersold what this modal does \u2014
    // it opens straight into a Feature Upsell / Expansion / Cancel-Downgrade
    // choice, none of which is a generic "item". "Modification" reads more
    // accurately in both Renewal/Rewrap and Create New Proposal.
    document.getElementById('bundle-modal-title').innerText = 'New modification';
  }
  document.getElementById('bundle-overlay').classList.add('is-open');
},

  createBundle: function createBundle() {
  const wasEditingExistingBundle = !!bld.targetOptId && !!bld.targetBundleId;
  const wasAddingToExistingOption = !!bld.targetOptId && !bld.targetBundleId;
  const optId = bld.targetOptId || nextOptId++;
  const sharedBundle = csBuildBundleData();
  if (!sharedBundle) return;
  const bundleData = {
    ...sharedBundle,
    msaDiscountPct: bld.msaDiscountPct || 0,
    ...(bld.txType === 'add'
      ? { isolatedTransactionType: 'add', txLabel: 'Expansion' }
      : {}),
    ...(sharedBundle.isPrebuilt
      ? { prebuiltBundleKey: sharedBundle.bundleKey, prebuiltTierKey: sharedBundle.tierKey }
      : {})
  };
  
  if (bld.targetOptId) {
     const opt = options.find(o => o.id === bld.targetOptId);
     if(opt) {
       if (bld.targetBundleId) {
         const idx = opt.bundles.findIndex(b => b.id === bld.targetBundleId);
         // 2026-09-17 (per Catalina): editing an existing bundle (e.g. reducing
         // its qty via the row's "Edit bundle" action) must not wipe out
         // originalQty \u2014 that field is what getBundleDelta() uses to detect
         // and render the reduced/cancelled state. Previously this replaced
         // the whole bundle object, silently losing originalQty and making an
         // intentionally-reduced bundle look like a brand-new "added" one.
         if (idx > -1 && opt.bundles[idx].originalQty !== undefined) {
           bundleData.originalQty = opt.bundles[idx].originalQty;
         }
         opt.bundles[idx] = bundleData;
       } else {
         opt.bundles.push(bundleData);
       }
     }
  } else {
     // F2: co-term for add-on orders (non-Gov); default to MSA remaining months
     const isCoTerm = proposalData.isAddOn && proposalData.segment !== 'Government';
     const initTerm = isCoTerm ? (getMsaMonthsRemaining() ?? 36) : 36;
    options.push({ id: optId, name: 'Option ' + (options.length + 1), term: initTerm, bundles: [bundleData], waves: [], forcedTierIndex: -1, transactionMode: 'Change', effectiveDate: '', reason: '', discretionaryDiscountPct: proposalData.msaDiscretionaryDiscountPct || 0 });
  }
  
  closeBundleModal();
  renderOptions();
  document.getElementById('empty-state').classList.add('hidden');
  document.getElementById('options-grid').classList.remove('hidden');
  const optionNumber = options.findIndex((o) => o.id === optId) + 1;
  if (!bld.targetOptId) {
    logProposalEvent('Option created', `Option ${Math.max(1, optionNumber)} was created.`);
  } else if (wasEditingExistingBundle) {
    logProposalEvent('Option edited', `Option ${Math.max(1, optionNumber)} configuration was updated.`);
  } else if (wasAddingToExistingOption) {
    logProposalEvent('Option edited', `A new solution was added to Option ${Math.max(1, optionNumber)}.`);
  }
},

  toggleOptPromoPanel: function toggleOptPromoPanel(optId) {
  if (openOptPromoPanelId === optId) {
    closeOptPromoDrawer();
    return;
  }
  const opt = options.find(o => o.id === optId);
  if (!opt) return;
  openOptPromoPanelId = optId;

  // Renewal / Rewrap modify the Master Contract, so they get Account Discount
  // plus Order Promotions. A Change in a new proposal leaves the existing MC
  // configured as-is and gets Order Promotions only (see showMsaTab below).
  // Every open resets to the first applicable tab/list without losing saved
  // configuration.
  if ((opt.transactionMode === 'Change' && proposalData.entryPoint === 'newProposal') || isSpecialOptionMode(opt)) {
    matrixDrawerTab = isSpecialOptionMode(opt) ? 'contract' : 'order';
    opt.contractPromoMode = 'programs';
    optPromoDraft = buildUnifiedOrderPromoDraft(opt);
    renderOptPromoDrawer();
    VC.setDrawerOpen('opt-promo-drawer', true);
    applyOptionFocusMode(optId);
    return;
  }

  const coreKeys = [...new Set(opt.bundles.map(b => b.coreKey))];
  const groupsByCore = getGroupsByCore(opt, coreKeys);
  const { tierQty: msaTierUnits } = calcOption(opt, getOptionPromotion(opt));
  const packages = getOptionPromoPackages(opt, coreKeys, groupsByCore, msaTierUnits);

  const currentCombo = {}, currentDealClosers = {};
  coreKeys.forEach(ck => {
    const first = groupsByCore[ck][0];
    currentCombo[ck] = { promoType: (first && first.promoType) || 'Standard', promoName: (first && first.promoName) || '' };
    currentDealClosers[ck] = (first && first.dealCloser) || '';
  });

  const { selectedKey, customEntry } = resolveSelectionForCombo(opt, coreKeys, groupsByCore, packages, currentCombo, currentDealClosers, msaTierUnits);

  const custom = {};
  coreKeys.forEach(ck => {
    custom[ck] = (selectedKey === 'custom' && customEntry)
      ? { ...customEntry.combo[ck], dealCloser: customEntry.dealClosers[ck] || '' }
      : (packages[selectedKey] ? { ...packages[selectedKey].combo[ck], dealCloser: '' } : { promoType: 'Standard', promoName: '', dealCloser: '' });
  });

  optPromoDraft = { mode: 'packages', coreKeys, packages, customEntry, selectedKey, custom };

  renderOptPromoDrawer();
  VC.setDrawerOpen('opt-promo-drawer', true);
  applyOptionFocusMode(optId);
},

  selectPromoPackage: function selectPromoPackage(optId, key) {
  if (!optPromoDraft) return;
  if (optPromoDraft.mode === 'unified' && key !== null) {
    const opt = options.find(item => item.id === optId);
    if (opt) opt.customPromotions = getCustomPromotions(opt).filter(promotion => promotion.level !== 'order');
  }
  optPromoDraft.selectedKey = key;
  optPromoDraft.coreKeys.forEach(ck => {
    if (key === 'custom' && optPromoDraft.customEntry) {
      optPromoDraft.custom[ck] = { ...optPromoDraft.customEntry.combo[ck], dealCloser: optPromoDraft.customEntry.dealClosers[ck] || '' };
    } else if (optPromoDraft.packages[key]) {
      optPromoDraft.custom[ck] = { ...optPromoDraft.packages[key].combo[ck], dealCloser: '' };
    }
  });
  renderOptPromoDrawer();
  renderOptions();
  if (screen === 'selection') renderSelectionOptions();
},

  getSubscriptionRowsForOption: function getSubscriptionRowsForOption(opt) {
  const rows = {};
  opt.bundles
    .filter(bundle => bundle.isolatedTransactionType !== 'cancel')
    .forEach(bundle => {
    getOrderPromotionComponents(bundle).forEach(component => {
      if (!rows[component.name]) rows[component.name] = { name: component.name, qty: 0, targets: [] };
      rows[component.name].qty += bundle.qty;
      if (!rows[component.name].targets.some(target => target.bundleId === bundle.id && target.component === component.name)) {
        rows[component.name].targets.push({ bundleId: bundle.id, component: component.name });
      }
    });
  });
  return Object.values(rows);
},

  getCustomPromoTableRows: function getCustomPromoTableRows(opt) {
  return getSubscriptionRowsForOption(opt);
},

  getCustomPromoCurrentPrice: function getCustomPromoCurrentPrice(opt, row) {
  return getCustomPromoTableRowCurrentPrice(opt, row);
},

  getCustomPromoTableRowCurrentPrice: function getCustomPromoTableRowCurrentPrice(opt, row) {
  const { tierQty } = calcOption(opt, getOptionPromotion(opt));
  return row.targets.reduce((sum, target) => {
    const bundle = opt.bundles.find(item => item.id === target.bundleId);
    if (!bundle) return sum;
    const component = getOrderPromotionComponents(bundle).find(item => item.name === target.component);
    if (!component) return sum;
    const currentUnit = calcBundle({
      ...bundle,
      promoName: '',
      msaDiscountPct: getOptionDiscountPct(opt, bundle),
    }, opt.term, 'Standard', tierQty).unitPrice;
    const basePrice = Number(bundle.basePrice) || 1;
    return sum + currentUnit * (component.listUnit / basePrice);
  }, 0);
},

  getCustomPromoAmountForBundle: function getCustomPromoAmountForBundle(bundle, customPromotions, tierTermPct, rawNetPrice, onlyComponent) {
  const components = getOrderPromotionComponents(bundle);
  const basePrice = Number(bundle.basePrice) || 1;
  return VC.customPromotionAmount({
    bundleId: bundle.id,
    promotions: customPromotions,
    components,
    onlyComponent,
    getAmount: (promotion, target, component) => {
      const currentUnit = rawNetPrice * (component.listUnit / basePrice);
      const value = Number(target.value) || 0;
      const amount = promotion.type === 'dollar'
        ? value
        : promotion.type === 'target'
          ? Math.max(0, currentUnit - value)
          : currentUnit * (value / 100);
      return Math.min(currentUnit, amount);
    },
  });
},

  computeCustomPromoTimelineTotals: function computeCustomPromoTimelineTotals(opt, promotion) {
  // 2026-10-05 fix (per Leo, 2026-10-02 call): the legend now uses the same
  // engine as the drawer footer / option card (computeOptionSummaryTotals), so
  // "Promotion" = Monthly Promo Price and "After promo" = that monthly plus
  // this promotion's own $ amount.
  const { promoTotal } = computeOptionSummaryTotals(opt);
  const { tierQty, term } = calcOption(opt, getOptionPromotion(opt));
  const tierTermPct = getTierTermDiscountPct(term, tierQty);
  let promoAmount = 0;
  if (customPromoHasAnyValue(promotion)) {
    opt.bundles.forEach(bundle => {
      const bundlePromo = bundle.promoType || getOptionPromotion(opt);
      const pricedBundle = { ...bundle, msaDiscountPct: getOptionDiscountPct(opt, bundle) };
      const { unitPrice: rawNetPrice } = calcBundle(pricedBundle, term, bundlePromo, tierQty);
      promoAmount += getCustomPromoAmountForBundle(bundle, [promotion], tierTermPct, rawNetPrice) * bundle.qty;
    });
  }
  if (opt.pilot?.pricingMode === 'free') promoAmount = 0;
  return { totalCurrent: promoTotal + promoAmount, totalDuringPromo: promoTotal };
},

  computeBundlePriceList: function computeBundlePriceList(opt) {
  const { tierQty, term } = calcOption(opt, getOptionPromotion(opt));
  const activeCustomPromotions = getActiveCustomPromotionsForPricing(opt);
  return opt.bundles.map(bundle => {
    const promoType = bundle.promoType || getOptionPromotion(opt);
    const priced = { ...bundle, msaDiscountPct: getOptionDiscountPct(opt, bundle) };
    const netUnitBeforeCustom = calcBundle(priced, opt.term, promoType, tierQty).unitPrice;
    const noOrderPromoUnit = calcBundle({ ...priced, promoName: '' }, opt.term, 'Standard', tierQty).unitPrice;
    const customPromoUnit = getCustomPromoAmountForBundle(bundle, activeCustomPromotions, 0, netUnitBeforeCustom);
    const netUnit = Math.max(0, netUnitBeforeCustom - customPromoUnit);
    const orderPromoUnit = Math.max(0, noOrderPromoUnit - netUnitBeforeCustom) + customPromoUnit;
    const listUnit = Number(bundle.basePrice) || 0;
    const tierTermPct = calcBundle({ ...bundle, msaDiscountPct: 0, promoName: '' }, opt.term, 'Standard', tierQty).tierTermPct || 0;
    const afterTierTermUnit = listUnit * (1 - tierTermPct / 100);
    return {
      name: bundle.coreName || corePricing[bundle.coreKey]?.name || bundle.coreKey,
      qty: bundle.qty,
      listUnit,
      tierTermUnit: Math.max(0, listUnit - afterTierTermUnit),
      tierTermPct,
      discretionaryUnit: Math.max(0, afterTierTermUnit - noOrderPromoUnit),
      msaUnit: noOrderPromoUnit,
      orderPromoUnit,
      netUnit,
    };
  });
},

  getDrawerLayout: function getDrawerLayout(opt, draft) {
  const unified = (opt.transactionMode === 'Change' && proposalData.entryPoint === 'newProposal') || isSpecialOptionMode(opt);
  return { unified, tabs: isSpecialOptionMode(opt) ? ['contract', 'order'] : ['order'] };
},

  buildDrawerSolutionSummaryHtml: function buildDrawerSolutionSummaryHtml(opt, draft) {
  return buildSubscriptionPriceListHtml(getDrawerSummaryOption(opt), 'drawer', draft?.custom || null);
},

  buildDrawerPriceListHtml: function buildDrawerPriceListHtml(opt) {
  return buildAccountPriceListHtml(getDrawerSummaryOption(opt), 'drawer');
},

  buildSubscriptionPriceListHtml: function buildSubscriptionPriceListHtml(opt, context = 'drawer', promoDraftByCore = null) {
  // 2026-10-02 (per Catalina): Frequency column only for a mixed account
  // (Billing model = Both) with at least one Capex bundle in this option.
  const showFrequency = accountBillingModel === 'both' && opt.bundles.some(bundle => bundle.billingModel === 'capex');
  if (!opt.bundles.length) return `<p class="text-body-small" style="color:var(--gray-600);">No subscriptions configured yet.</p>`;
  const { tierQty, term } = calcOption(opt, getOptionPromotion(opt));
  const activeCustomPromotions = getActiveCustomPromotionsForPricing(opt);
  let monthlyBeforeChanges = 0;
  let monthlyAfterChanges = 0;
  let monthlyAfterTierTerm = 0;
  let orderPromoTotal = 0;
  const blocks = opt.bundles.map(bundle => {
    const draftPromo = promoDraftByCore ? promoDraftByCore[bundle.coreKey] : null;
    const previewBundle = draftPromo
      ? { ...bundle, promoType: draftPromo.promoType, promoName: draftPromo.promoName, dealCloser: draftPromo.dealCloser }
      : bundle;
    const promoType = draftPromo ? draftPromo.promoType : (bundle.promoType || getOptionPromotion(opt));
    const priced = { ...previewBundle, msaDiscountPct: getOptionDiscountPct(opt, bundle) };
    const netUnitBeforeCustom = calcBundle(priced, term, promoType, tierQty).unitPrice;
    const noOrderPromoUnit = calcBundle({ ...priced, promoName: '' }, term, 'Standard', tierQty).unitPrice;
    const tierTermPct = calcBundle({ ...bundle, msaDiscountPct: 0, promoName: '' }, term, 'Standard', tierQty).tierTermPct || 0;
    const discretionaryPct = getOptionDiscountPct(opt, bundle);
    const components = getOrderPromotionComponents(bundle).map(component => {
      const share = (Number(bundle.basePrice) || 1) > 0 ? component.listUnit / (Number(bundle.basePrice) || 1) : 0;
      const afterTierTerm = VC.priceListUnitBreakdown({ listUnit: component.listUnit, tierTermPct }).afterTierTermUnit;
      // 2026-10-02: a contract-level "Create a Custom Discount" (Renewal /
      // Rewrap MSA Discount tab) lowers the MSA Price itself \u2014 it replaces the
      // discount program \u2014 while order-level custom promotions stay in
      // Promotion / Discount. Same $ basis as the option card totals.
      const contractCustomAmount = getCustomPromoAmountForBundle(bundle, activeCustomPromotions.filter(promotion => promotion.level === 'contract'), tierTermPct, netUnitBeforeCustom, component.name);
      const orderCustomAmount = getCustomPromoAmountForBundle(bundle, activeCustomPromotions.filter(promotion => promotion.level !== 'contract'), tierTermPct, netUnitBeforeCustom, component.name);
      const msaUnit = VC.priceListUnitBreakdown({
        listUnit: component.listUnit,
        tierTermPct,
        discretionaryPct,
        msaUnitOverride: Math.max(0, afterTierTerm * (1 - discretionaryPct / 100) - contractCustomAmount),
      }).msaUnit;
      const afterPromo = Math.max(0, netUnitBeforeCustom * share - contractCustomAmount - orderCustomAmount);
      const orderPromo = Math.max(0, msaUnit - afterPromo);
      return { name: component.name, standardUnit: component.listUnit, discretionaryUnit: Math.max(0, afterTierTerm - msaUnit), msaUnit, orderPromo, afterPromo };
    });
    const monthlyBefore = components.reduce((sum, component) => sum + component.msaUnit, 0) * bundle.qty;
    const monthlyAfter = components.reduce((sum, component) => sum + component.afterPromo, 0) * bundle.qty;
    const bundleOrderPromo = components.reduce((sum, component) => sum + component.orderPromo, 0) * bundle.qty;
    monthlyBeforeChanges += monthlyBefore;
    monthlyAfterTierTerm += components.reduce((sum, component) => sum + component.msaUnit + component.discretionaryUnit, 0) * bundle.qty;
    monthlyAfterChanges += monthlyAfter;
    orderPromoTotal += bundleOrderPromo;
    const headerPrice = monthlyAfter;
    return `<div class="subscription-summary-block" data-bundle-id="${bundle.id}">
      <div class="subscription-summary-head"><span>${bundle.coreName}<span class="subscription-summary-head-sep"></span><span class="subscription-summary-head-qty"><span class="subscription-summary-head-qty-label">QTY</span> <span class="subscription-summary-head-qty-num">${bundle.qty}</span></span></span><span class="subscription-summary-head-price">${formatMoney(headerPrice)}</span></div>
      <table class="bundle-summary-components">
        <thead><tr><th class="bundle-summary-components-header">Subscriptions</th>${showFrequency ? '<th class="bundle-summary-components-header bundle-summary-components-header--freq">Frequency</th>' : ''}<th class="bundle-summary-components-header bundle-summary-components-header--num">List Price</th><th class="bundle-summary-components-header bundle-summary-components-header--num">Contracted Price</th><th class="bundle-summary-components-header bundle-summary-components-header--num">Promotions</th><th class="bundle-summary-components-header bundle-summary-components-header--num">Promo Price</th></tr></thead>
        <tbody>${components.map(component => `<tr><td class="bundle-summary-components-cell bundle-summary-components-cell--name">${component.name}</td>${showFrequency ? '<td class="bundle-summary-components-cell bundle-summary-components-cell--freq">Monthly</td>' : ''}<td class="bundle-summary-components-cell bundle-summary-components-cell--num">${formatMoney(component.standardUnit)}</td><td class="bundle-summary-components-cell bundle-summary-components-cell--num${component.discretionaryUnit > 0.005 ?' price-amount--msa-discount' : ''}">${formatMoney(component.msaUnit)}</td><td class="bundle-summary-components-cell bundle-summary-components-cell--num${component.orderPromo > 0.005 ?' price-amount--order-discount' : ''}">${component.orderPromo > 0.005 ? `-${formatMoney(component.orderPromo)}` : formatMoney(0)}</td><td class="bundle-summary-components-cell bundle-summary-components-cell--num">${formatMoney(component.afterPromo)}</td></tr>`).join('')}${accountBillingModel === 'both' && bundle.billingModel === 'capex' && getEstimatedHardwareUnitPrice(bundle) > 0.005 ? buildDrawerHardwareRowHtml('Hardware', getEstimatedHardwareUnitPrice(bundle)) : ''}</tbody>
      </table>
    </div>`;
  }).join('');
  // 2026-10-02 (per Leo): Order-discount-level amounts read blue.
  // 2026-10-02 (per Catalina): same footer as New Accounts \u2014 Monthly Total (at MSA
  // Price), one blue Promotion / Discount line, then Monthly Promo Price.
  const footerPromoAmount = Math.max(0, monthlyBeforeChanges - monthlyAfterChanges);
  // 2026-10-02 (per Catalina): MSA Discount line (green) \u2014 Monthly Total now starts after Tier/Term, so Monthly Total \u2212 MSA Discount \u2212 Promotion / Discount = Monthly Promo Price.
  const footerMsaDiscountAmount = Math.max(0, monthlyAfterTierTerm - monthlyBeforeChanges);
  const msaDiscountLine = footerMsaDiscountAmount > 0.005 ? `<div class="subscription-summary-line price-amount--msa-discount"><span>Account Discount</span><span>\u2212${formatMoney(footerMsaDiscountAmount)}</span></div>` : '';
  const orderPromoLine = footerPromoAmount > 0.005 ? `<div class="subscription-summary-line price-amount--order-discount"><span>Promotions</span><span>\u2212${formatMoney(footerPromoAmount)}</span></div>` : '';
  const totalsFooter = `<div class="subscription-summary-totals"><div class="subscription-summary-line"><span>Monthly Total</span><span>${formatMoney(monthlyAfterTierTerm)}</span></div>${msaDiscountLine}${orderPromoLine}<div class="subscription-summary-line subscription-summary-line--strong"><span>Monthly Promo Price</span><span>${formatMoney(monthlyAfterChanges)}</span></div></div>`;
  return `<div class="subscription-summary-scroll">${blocks}</div>${totalsFooter}`;
},

  computeOptionSummaryTotals: function computeOptionSummaryTotals(opt) {
  const { tierQty, term } = calcOption(opt, getOptionPromotion(opt));
  const tierTermPct = getTierTermDiscountPct(term, tierQty);
  const customPromotions = getCustomPromotions(opt).filter(promotion => customPromoHasAnyValue(promotion) && Array.isArray(promotion.targets) && promotion.targets.length > 0);
  return VC.aggregateOptionTotals(opt, bundle => {
    const isIsolatedCancel = bundle.isMsaAuxiliary && bundle.isolatedTransactionType === 'cancel';
    const listPrice = getStandardUnitPrice(bundle);
    const priceBreakdown = VC.priceListUnitBreakdown({
      listUnit: listPrice,
      tierTermPct: isIsolatedCancel ? 0 : tierTermPct,
      discretionaryPct: getOptionDiscountPct(opt, bundle),
    });
    const afterTierTerm = priceBreakdown.afterTierTermUnit;
    const msaPrice = priceBreakdown.msaUnit;
    const bundlePromo = bundle.promoType || getOptionPromotion(opt);
    const pricedBundle = { ...bundle, msaDiscountPct: getOptionDiscountPct(opt, bundle) };
    const { unitPrice: rawNetPrice, monthly: rawMonthly } = calcBundle(pricedBundle, term, bundlePromo, tierQty);
    const customAmountPerUnit = getCustomPromoAmountForBundle(bundle, customPromotions, tierTermPct, rawNetPrice);
    // 2026-10-02: a contract-level Custom Discount (MSA Discount tab) lowers
    // the card's MSA Price too, not just the promo total.
    const contractCustomPerUnit = getCustomPromoAmountForBundle(bundle, customPromotions.filter(promotion => promotion.level === 'contract'), tierTermPct, rawNetPrice);
    return {
      qty: bundle.qty,
      listTotal: listPrice * bundle.qty,
      msaTotal: isIsolatedCancel ? rawNetPrice * bundle.qty : Math.max(0, msaPrice - contractCustomPerUnit) * bundle.qty,
      promoTotal: isIsolatedCancel ? rawMonthly : Math.max(0, rawMonthly - customAmountPerUnit * bundle.qty),
    };
  }, {
    initialTotals: { qty: 0, listTotal: 0, msaTotal: 0, promoTotal: 0 },
    adjustTotals: totals => {
      if (opt.pilot?.pricingMode === 'free') totals.promoTotal = 0;
      return totals;
    },
  });
},

  buildOptionSummaryStripHtml: function buildOptionSummaryStripHtml(opt) {
  if (!opt.bundles.length) return '';
  const { qty, listTotal, msaTotal, promoTotal } = computeOptionSummaryTotals(opt);
  return VC.optionTotalsRow({ className: 'opt-totals-row--summary-strip', cells: [
    { label: 'QTY', valueClassName: 'opt-totals-value--qty', valueHtml: `${qty}<span> units</span>` },
    { label: 'List Price', valueHtml: `${formatMoney(listTotal)}<span>/mo</span>` },
    { label: 'Contracted Price/mo', valueHtml: formatMoney(msaTotal) },
    { label: 'Monthly', className: 'opt-totals-cell--final', valueHtml: formatMoney(promoTotal) },
  ] });
},

  renderOptions: function renderOptions() {
  setTimeout(() => { if (typeof updateApprovalSnackbar === 'function') { updateApprovalSnackbar(); updateMarkDeadBtn(); renderMsaContextBar(); } }, 0);
  updateDraftingHeaderTitle();
  const grid = document.getElementById('options-grid');
  grid.innerHTML = '';
  const currentPanel = document.getElementById('current-proposal-panel');
  if (currentPanel) {
    const wasCollapsed = currentPanel.classList.contains('is-collapsed');
    currentPanel.innerHTML = renderCurrentProposalCard();
    currentPanel.classList.toggle('is-collapsed', wasCollapsed);
    const toggleIcon = currentPanel.querySelector('[data-current-toggle-icon]');
    const toggleButton = currentPanel.querySelector('.current-proposal-header-actions button:last-child');
    if (toggleIcon) toggleIcon.textContent = wasCollapsed ? 'chevron_right' : 'chevron_left';
    if (toggleButton) {
      toggleButton.setAttribute('aria-label', wasCollapsed ? 'Expand Current' : 'Collapse Current');
      toggleButton.title = wasCollapsed ? 'Expand Current' : 'Collapse Current';
    }
  }

  // Update Header Labels
  const nameEls = document.querySelectorAll('.header-prop-name');
  nameEls.forEach(el => el.innerText = proposalData.name);
  
  const promoEls = document.querySelectorAll('.header-prop-promo');
  promoEls.forEach(el => el.innerText = proposalData.promoType);
  
  // Tier label \u2014 per-option now; show summary in header
  const tierEls = document.querySelectorAll('.header-prop-tier');
  const forcedOpts = options.filter(o => (o.forcedTierIndex !== undefined ? o.forcedTierIndex : -1) !== -1);
  const isApproved = proposalData.approvalStatus === 'Approved';
  const isForced = forcedOpts.length > 0;
  tierEls.forEach(el => {
    if (!isForced) {
      el.innerText = 'Auto';
    } else if (isApproved) {
      el.innerHTML = `Forced <span class="tier-status tier-status-approved">(Approved)</span>`;
    } else {
      el.innerHTML = `Forced <span class="tier-status tier-status-pending">(Approval required)</span>`;
    }
  });


window.setCurrentSetupContractAccount = function setCurrentSetupContractAccount(contractAccountId) {
  const validIds = new Set(['all', ...DEMO_CONTRACT_ACCOUNTS.map(account => account.id)]);
  if (!validIds.has(contractAccountId)) return;
  unifiedAccount.currentSetupContractAccountId = contractAccountId;
  if (typeof syncUnifiedScenarioUrl === 'function') syncUnifiedScenarioUrl();
  const panel = document.getElementById('current-proposal-panel');
  if (panel) panel.innerHTML = renderCurrentProposalCard();
};

function renderCurrentProposalCard() {
  const multipleContractAccounts = unifiedAccount.accountType === 'customer' && unifiedAccount.hasMultipleContractAccounts;
  const allCurrentOrders = multipleContractAccounts ? getContractAccountOrders() : (Array.isArray(existingOrders) ? existingOrders : []);
  const currentSetupContractAccountId = multipleContractAccounts ? (unifiedAccount.currentSetupContractAccountId || 'all') : 'all';
  const currentOrders = currentSetupContractAccountId === 'all'
    ? allCurrentOrders
    : allCurrentOrders.filter(order => order.contractAccountId === currentSetupContractAccountId);
  const isReactivation = options.some(option => option.transactionMode === 'Reactivation');
  const currentSetupTitle = isReactivation ? 'Previous setup' : 'Current setup';
  const currentSetupCaption = isReactivation
    ? 'Read-only reference \u00b7 last billed pricing'
    : 'Read-only reference \u00b7 active pricing';
  const currentBundles = currentOrders.flatMap((order) => order.bundles || []);
  const totalUnits = currentBundles.reduce((sum, bundle) => sum + (bundle.qty || 0), 0);
  const totalMonthly = multipleContractAccounts
    ? calcOption({ bundles: currentBundles, term: currentOrders[0]?.term || 36 }, 'Standard', -1).totalMonthly
    : currentOrders.reduce((sum, order) => {
        return sum + calcOption({ bundles: order.bundles || [], term: order.term || 36 }, 'Standard', -1).totalMonthly;
      }, 0);
  const avgUnit = totalUnits > 0 ? totalMonthly / totalUnits : 0;
  const orderLabel = currentOrders.length === 1 ? currentOrders[0].name : `${currentOrders.length} active orders`;
  // 2026-09-18 (R21.4 correction, per the 2026-09-17 meeting transcript \u2014 Leo:
  // "we need to add to the left we need to add the band... because we need to
  // say the band needs to say... the 32"): the subscription count (which
  // drives the band/tier, e.g. camera bundles count double) wasn't visible
  // anywhere on the account's real, currently-contracted setup \u2014 only the
  // vehicle count was. This lives on the "Current" panel itself (the one
  // already built in R17.5), not on Account Setup \u2014 that's a separate,
  // still-pending item (R16).
  const accountBundles = (Array.isArray(existingOrders) ? existingOrders : []).flatMap(order => order.bundles || []);
  const currentMsaTierUnits = sumMsaTierQty(accountBundles);
  // 2026-09-18 (per Catalina): show the tier's actual range alongside the
  // discount \u2014 reuses the same MSA_DISCOUNT_TIERS min/max already driving
  // the quantity band.
  const currentBandTier = getMsaDiscountTier(currentMsaTierUnits);
  const currentBandRange = currentBandTier.max >= 9999 ? `${currentBandTier.min}+` : `${currentBandTier.min}-${currentBandTier.max}`;
  // R29 (2026-09-23): the Tier/Term discount needs a term, not just quantity \u2014
  // uses the account's actual current MSA term (all current orders share it).
  const currentTierTermMonths = DEMO_MSA?.termMonths || currentOrders[0]?.term || 36;

  const parentAccountUnits = accountBundles.reduce((sum, bundle) => sum + (Number(bundle.qty) || 0), 0);
  const bundles = currentBundles.map((bundle) => {
    const order = currentOrders.find((candidate) => (candidate.bundles || []).includes(bundle));
    const { unitPrice, monthly } = calcBundle(bundle, order?.term || 36, bundle.promoType || 'Standard', parentAccountUnits);
    const standardUnitPrice = getStandardUnitPrice(bundle);
    const discountPct = standardUnitPrice > 0 ? Math.round((1 - unitPrice / standardUnitPrice) * 100) : 0;
    const isVideo = bundle.coreKey === 'vtu-ffc' || bundle.coreKey === 'vtu-dual';
    const hasNamedPromo = !!String(bundle.promoName || '').trim();
    const hasMediaPromo = bundle.promoType === 'Media' && isVideo;
    return {
      name: bundle.coreName,
      qty: bundle.qty,
      monthlyHtml: formatMoney(monthly),
      unitHtml: formatMoney(unitPrice),
      listHtml: discountPct > 0 ? formatMoney(standardUnitPrice) : '',
      discountPct: discountPct > 0 ? discountPct : 0,
      promoLabel: hasNamedPromo ? bundle.promoName : (hasMediaPromo ? 'Media Promo' : ''),
    };
  });

  return VC.currentSetupPanel({
    title: currentSetupTitle,
    caption: currentSetupCaption,
    totalUnits,
    monthlyHtml: formatMoney(totalMonthly),
    summaryHtml: `${formatMoney(avgUnit)}/unit (avg) &middot; Tier/Term ${currentBandRange}: ${getTierTermDiscountPct(currentTierTermMonths, currentMsaTierUnits)}% (${currentMsaTierUnits})`,
    bundles,
    filtersHtml: multipleContractAccounts ? `<label class="vc-current-setup-filter"><span>Contract Account</span><select class="select select--small" aria-label="Filter Current Setup by Contract Account" onchange="setCurrentSetupContractAccount(this.value)"><option value="all"${currentSetupContractAccountId === 'all' ? ' selected' : ''}>All</option>${DEMO_CONTRACT_ACCOUNTS.map(account => `<option value="${account.id}"${currentSetupContractAccountId === account.id ? ' selected' : ''}>${account.name}</option>`).join('')}</select></label>` : '',
  });
}


// 2026-09-17 (per Catalina): shared builder so any entry point that should
// "start from Current" (the Same as Current tx-type, and now Upsell/Add when
// creating a brand-new option) uses the exact same seed data \u2014 previously
// only the standalone Duplicate button used this, so Upsell/Add created a
// bare new option unrelated to Current instead of building on top of it.
window.createOptionFromCurrent = function createOptionFromCurrent(name) {
  const currentOrders = Array.isArray(existingOrders) ? existingOrders : [];
  if (!currentOrders.length) return null;
  const opt = {
    id: nextOptId++,
    name: name || ('Option ' + (options.length + 1)),
    term: currentOrders[0].term || 36,
    forcedTierIndex: -1,
    transactionMode: 'Change',
    effectiveDate: '',
    reason: '',
    discretionaryDiscountPct: proposalData.msaDiscretionaryDiscountPct || 0,
    // 2026-09-18 (R22 prep, per Catalina): bundles seeded straight from
    // existingOrders never had an `id` \u2014 harmless while Edit/Delete were the
    // only consumers (R21.5 now hides those buttons for any bundle with
    // originalQty anyway), but vzGenerateSubscriptions()'s bundleId grouping
    // (used by the Upsell matching engine, R22) needs a real, unique id per
    // bundle to tell them apart. Assign one if the source didn't have one.
    bundles: currentOrders.flatMap(order => order.bundles || []).map((bundle, i) => ({
      ...JSON.parse(JSON.stringify(bundle)),
      id: bundle.id ?? (Date.now() + i),
      originalQty: bundle.qty
    })),
    waves: []
  };
  options.push(opt);
  return opt;
}

window.createEmptyTransactionOption = function createEmptyTransactionOption(txType) {
  const currentOrders = Array.isArray(existingOrders) ? existingOrders : [];
  const opt = {
    id: nextOptId++,
    name: 'Option ' + (options.length + 1),
    term: currentOrders[0]?.term || 36,
    forcedTierIndex: -1,
    transactionMode: 'Change',
    effectiveDate: '',
    reason: '',
    discretionaryDiscountPct: proposalData.msaDiscretionaryDiscountPct || 0,
    bundles: [],
    waves: [],
    isolatedTransactionType: txType,
    pendingTransaction: true
  };
  options.push(opt);
  return opt;
}

const closeTransactionBundleModal = window.closeBundleModal;
window.closeBundleModal = function closeBundleModalWithTransactionCleanup() {
  const pendingCount = options.filter(opt => opt.pendingTransaction && !opt.bundles.length).length;
  options = options.filter(opt => !opt.pendingTransaction || opt.bundles.length);
  options.forEach(opt => { if (opt.pendingTransaction) delete opt.pendingTransaction; });
  closeTransactionBundleModal();
  if (pendingCount) {
    renderOptions();
    updateEmptyStateCopy();
    document.getElementById('empty-state')?.classList.toggle('hidden', options.length > 0);
    document.getElementById('options-grid')?.classList.toggle('hidden', !options.length);
  }
};

window.editIsolatedTransaction = function editIsolatedTransaction(optId, bundleId) {
  const opt = options.find(candidate => candidate.id === optId);
  const bundle = opt?.bundles?.find(candidate => candidate.id === bundleId);
  if (!bundle?.isolatedTransactionType) return openConfigureBundle(optId, bundleId);
  txPreselectedSubIds = Array.isArray(bundle.selectedSubIds) ? [...bundle.selectedSubIds] : [];
  openConfigureBundle(optId);
  bld.targetBundleId = bundleId;
  selectBundleTxType(bundle.isolatedTransactionType);
  confirmBundleTxType();
}

window.duplicateCurrentAsOption = function duplicateCurrentAsOption(event) {
  event?.stopPropagation();
  const opt = createOptionFromCurrent();
  if (!opt) return;
  renderOptions();
  document.getElementById('empty-state')?.classList.add('hidden');
  document.getElementById('options-grid')?.classList.remove('hidden');
  logProposalEvent('Option created', `Option ${options.length} was duplicated from Current.`);
}

function getBundleDelta(bundle) {
  if (bundle.originalQty === undefined) return { type: 'added', amount: bundle.qty || 0 };
  const originalQty = Number(bundle.originalQty) || 0;
  const qty = Number(bundle.qty) || 0;
  if (qty === 0 && originalQty > 0) return { type: 'cancelled', amount: originalQty };
  if (qty > 0 && qty < originalQty) return { type: 'reduced', amount: originalQty - qty };
  // 2026-09-18 (R22, per Catalina): a bundle that already existed (has an
  // originalQty) can also GROW \u2014 e.g. an Upsell moving units in from another
  // bundle once their features match this one. Treat that the same as
  // "added" visually (green border + badge), just with the exact count.
  if (qty > originalQty) return { type: 'increased', amount: qty - originalQty };
  return null;
}

window.getVZBundleSubscriptionId = function getVZBundleSubscriptionId(bundle, index) {
  const bundleKey = bundle.id ?? `${bundle.coreKey || 'bundle'}-${bundle.coreName || 'unknown'}`;
  return `SUB-VZ-${String(bundleKey)}-${index}`;
}

function getCurrentLineImpact(opt, currentBundle) {
  const currentIds = new Set(Array.from(
    { length: Math.max(0, Number(currentBundle.originalQty ?? currentBundle.qty) || 0) },
    (_, index) => window.getVZBundleSubscriptionId(currentBundle, index)
  ));
  const currentBundles = (opt.bundles || []).filter(bundle => bundle.originalQty !== undefined);
  return (opt.bundles || []).reduce((impact, bundle) => {
    if (!bundle.isolatedTransactionType || !Array.isArray(bundle.selectedSubIds)) return impact;
    const affected = bundle.selectedSubIds.filter(id => currentIds.has(id)).length;
    if (bundle.isolatedTransactionType === 'upsell') {
      const featureKeys = Array.isArray(bundle.features) ? bundle.features : [];
      const destinationCore = featureKeys.includes('dual')
        ? 'vtu-dual'
        : (featureKeys.includes('ffc') ? 'vtu-ffc' : null);
      if (destinationCore) {
        if (currentBundle.coreKey === destinationCore) {
          const movedFromOtherCore = bundle.selectedSubIds.filter(id => currentBundles.some(source => {
            if (source.coreKey === destinationCore) return false;
            const sourceQty = Number(source.originalQty ?? source.qty) || 0;
            return Array.from({ length: sourceQty }, (_, index) => window.getVZBundleSubscriptionId(source, index)).includes(id);
          })).length;
          impact.addedCount += movedFromOtherCore;
        } else {
          impact.cancelledCount += affected;
        }
      } else {
        impact.addedCount += affected;
      }
    }
    if (bundle.isolatedTransactionType === 'cancel') impact.cancelledCount += affected;
    return impact;
  }, { addedCount: 0, cancelledCount: 0 });
}

  if (!proposalData.closeDate) {
    proposalData.closeDate = getLastDayOfCurrentMonthIso();
  }
  const closeDateDisplayEl = document.getElementById('header-prop-close-date-display');
  const closeDateInputEl = document.getElementById('header-prop-close-date-input');
  const vcmiModeEl = document.getElementById('header-prop-vcmi-mode');
  const vcmiContextEl = document.getElementById('header-prop-vcmi-context');
  if (closeDateDisplayEl) {
    const parsedClose = parseProposalDate(proposalData.closeDate);
    closeDateDisplayEl.textContent = parsedClose ? formatUsDate(parsedClose) : '--/--/----';
  }
  if (closeDateInputEl) closeDateInputEl.value = proposalData.closeDate;
  if (vcmiModeEl) vcmiModeEl.textContent = proposalData.vcmiMode || 'VMI';
  if (vcmiContextEl) vcmiContextEl.textContent = getVcmiContextLabel();

  updateSeasonalPill();
  updateSegmentHeader();

  // Sync gov-mode card width on options grid
  const _grid = document.getElementById('options-grid');
  if (_grid) {
    _grid.classList.toggle('gov-mode', proposalData.wavesEnabled && proposalData.segment === 'Government');
  }

  // Hide Global Approval Banner as requested (moving to inline indicator)
  const banner = document.getElementById('global-approval-banner');
  if (banner) banner.classList.add('hidden');
  
  // Ensure layout doesn't keep extra padding if no other banners are present
  const warningBanner = document.getElementById('warning-banner');
  if (!warningBanner || warningBanner.classList.contains('hidden')) {
    document.getElementById('vc-body').classList.remove('has-banner');
  }

  // Update button state
  updateSendBtn();

  options.forEach((opt, i) => {
    const msaLockedTerm = Number(DEMO_MSA.termMonths) || 0;
    const shouldLockMsaTerm = msaLockedTerm > 0 && !isSpecialOptionMode(opt);
    if (shouldLockMsaTerm && Number(opt.term) !== msaLockedTerm) {
      opt.term = msaLockedTerm;
    }

    // 2026-09-18 (R21.2, per Catalina): band/tier is frozen for "Create new
    // proposal" options \u2014 it always reflects the contract's real, currently
    // committed unit count (not this isolated card's own small totalUnits),
    // and no manual tier override is allowed. Renewal/Rewrap options keep the
    // existing dynamic behavior (natural tier from the option's own \u2014 full,
    // mirrored \u2014 totalUnits, with the override dropdown still available).
    const isBandFrozen = proposalData.entryPoint !== 'renewalRewrap';
    const currentForcedTier = isBandFrozen ? -1 : ((opt.forcedTierIndex !== undefined) ? opt.forcedTierIndex : -1);
    const optionPromoType = getOptionPromotion(opt);
    const totalUnits = opt.bundles.reduce((sum, bundle) => sum + (bundle.qty || 0), 0);
    const applicableNaturalIdx = isBandFrozen ? getApplicableTierIndex(getContractCommittedUnits()) : getApplicableTierIndex(totalUnits);
    const optTier = currentForcedTier === -1
      ? applicableNaturalIdx
      : Math.max(currentForcedTier, applicableNaturalIdx);
    const { totalMonthly, avgUnit, tierQty: msaTierUnits } = calcOption(opt, optionPromoType, optTier);
    const tierObj = getEffectiveTier(getTierEligibilityQty(totalUnits), optTier);
    const tier = tierObj;
    const skip = tier.index - applicableNaturalIdx;
    // 2026-10-07 (per Catalina): same approval rule as Initial Sales \u2014 placeholder until the real rules:
    // a Custom Discount / Promotion with a value (shared: assets-shared/js/vc-approval.js).
    const requiresApproval = getOptionApprovalInfo(opt, opt).requiresApproval;

    let bundlesHtml = '';
    // 2026-09-21 (per Catalina): in "Create new proposal" (entryPoint ===
    // 'newProposal'), every bundle IS a modification being built from
    // scratch \u2014 there's no separate "current line" to diff against \u2014 so
    // they must all get the hover edit/delete controls, same as
    // Renewal/Rewrap's isolated-transaction bundles. This was silently
    // regressed when modificationBundles was scoped to renewalRewrap only.
    const currentLineBundles = proposalData.entryPoint === 'renewalRewrap'
      ? opt.bundles.filter(bundle => bundle.originalQty !== undefined)
      : (proposalData.entryPoint === 'newProposal' ? [] : opt.bundles);
    const modificationBundles = proposalData.entryPoint === 'renewalRewrap'
      ? opt.bundles.filter(bundle => bundle.isolatedTransactionType)
      : (proposalData.entryPoint === 'newProposal' ? opt.bundles : []);
    [...currentLineBundles, ...modificationBundles].forEach((b, bundleIndex) => {
      const isModification = modificationBundles.includes(b);
      if (isModification && bundleIndex === currentLineBundles.length && proposalData.entryPoint === 'renewalRewrap') {
        // 2026-09-21 (per Catalina): "Configure promotions" moves down into
        // this Contract Modifications sub-header for Renewal/Rewrap, instead
        // of sitting in the top Active Bundles header \u2014 promotions apply to
        // the new modification lines, not the read-only Current lines above.
        // 2026-10-02: "Configure promotions" removed from this sub-header \u2014
        // Renewal / Rewrap now have one entry point, the "Discounts &
        // Promotions" button next to Contract term (same as Initial Sales).
        bundlesHtml += VC.sectionStrip({ title: 'Contract modifications', count: modificationBundles.length, follows: true });
      }
      const bundlePromo = b.promoType || optionPromoType;
      const bundlePricing = calcBundle({ ...b, msaDiscountPct: getOptionDiscountPct(opt, b) }, opt.term, bundlePromo, msaTierUnits);
      const orderCustomPromotions = getActiveCustomPromotionsForPricing(opt);
      const customPromoAmount = orderCustomPromotions.length
        ? getCustomPromoAmountForBundle(b, orderCustomPromotions, 0, bundlePricing.unitPrice)
        : 0;
      const unitPrice = Math.max(0, bundlePricing.unitPrice - customPromoAmount);
      const monthly = unitPrice * b.qty;
      const bt = bundlePricing.tier;
      const bundleDelta = isModification ? null : getBundleDelta(b);
      const isCancelled = bundleDelta?.type === 'cancelled';
      // 2026-09-18 (R22, per Catalina): 'increased' (a bundle that already
      // existed and grew \u2014 e.g. an Upsell moved units in) gets the same
      // green-border treatment as 'added' (a brand-new bundle), just with a
      // "+N added" count instead of a plain "New" badge.
      const isAdded = proposalData.entryPoint === 'renewalRewrap' && (bundleDelta?.type === 'added' || bundleDelta?.type === 'increased');
      const impact = !isModification && proposalData.entryPoint === 'renewalRewrap'
        ? getCurrentLineImpact(opt, b)
        : { addedCount: 0, cancelledCount: 0 };
      const impactBadges = (impact.addedCount || impact.cancelledCount)
        ? `<span class="bundle-impact-badges">${impact.addedCount ? `<span class="badge badge--green">+${impact.addedCount}</span>` : ''}${impact.cancelledCount ? `<span class="badge badge--red">\u2212${impact.cancelledCount}</span>` : ''}</span>`
        : '';
      const qtyLabel = isModification ? `${b.qty}` : `${b.originalQty ?? b.qty}`;
      const qtyStatus = isModification
        ? ''
        : (bundleDelta?.type === 'reduced'
        ? `<span class="bundle-qty-delta">\u2212${bundleDelta.amount} cancelled</span>`
        : (isCancelled ? '<span class="bundle-cancelled-badge">Cancelled</span>' : (bundleDelta?.type === 'increased' ? `<span class="bundle-added-badge">+${bundleDelta.amount} added</span>` : (isAdded ? '<span class="bundle-added-badge">New</span>' : ''))));
      const standardUnitPrice = getStandardUnitPrice(b);
      const hasBundleDiscount = standardUnitPrice > unitPrice + 0.005;
      const isChangeOption = opt.transactionMode === 'Change';
      const { unitPrice: promoOnlyUnitPrice } = calcBundle({ ...b, msaDiscountPct: 0 }, opt.term, bundlePromo, msaTierUnits);
      const { unitPrice: trueListUnitPrice } = calcBundle({ ...b, msaDiscountPct: 0, dealCloser: '', promoName: '' }, opt.term, 'Standard', msaTierUnits);
      const discretionaryAmount = Math.max(0, promoOnlyUnitPrice - bundlePricing.unitPrice);
      const promoAmount = Math.max(0, trueListUnitPrice - promoOnlyUnitPrice);
      const hasCombinedDiscount = trueListUnitPrice > 0;
      const promoPctForTooltip = hasCombinedDiscount ? Math.round((promoAmount / trueListUnitPrice) * 100) : 0;
      const discretionaryPctForTooltip = hasCombinedDiscount ? Math.round((discretionaryAmount / trueListUnitPrice) * 100) : 0;
      const tierTermPctForBundleRow = getTierTermDiscountPct(opt.term, msaTierUnits);
      const badgeCustomPromos = getCustomPromotions(opt).filter(promotion => customPromoHasAnyValue(promotion) && Array.isArray(promotion.targets) && promotion.targets.some(target => target.bundleId === b.id));
      const customOrderAmountForBadge = getCustomPromoAmountForBundle(b, badgeCustomPromos.filter(promotion => promotion.level !== 'contract'), tierTermPctForBundleRow, bundlePricing.unitPrice);
      const customContractAmountForBadge = getCustomPromoAmountForBundle(b, badgeCustomPromos.filter(promotion => promotion.level === 'contract'), tierTermPctForBundleRow, bundlePricing.unitPrice);
      const customOrderPctForBadge = hasCombinedDiscount ? Math.round((customOrderAmountForBadge / trueListUnitPrice) * 100) : 0;
      const customContractPctForBadge = hasCombinedDiscount ? Math.round((customContractAmountForBadge / trueListUnitPrice) * 100) : 0;
      const totalOrderPctForBadge = promoPctForTooltip + customOrderPctForBadge;
      const totalContractPctForBadge = discretionaryPctForTooltip + customContractPctForBadge;
      const orderCustomFixedDuration = badgeCustomPromos.find(promotion => promotion.level !== 'contract' && promotion.durationMode === 'months' && promotion.durationMonths && promotion.durationMonths !== opt.term);
      const orderPromoDurationDiffersFromTerm = b.promoDurationMonths != null && b.promoDurationMonths > 0 && b.promoDurationMonths !== opt.term;
      const orderDurationMonthsForBadge = orderPromoDurationDiffersFromTerm ? b.promoDurationMonths : (orderCustomFixedDuration ? orderCustomFixedDuration.durationMonths : null);
      const afterTierTermUnit = standardUnitPrice * (1 - tierTermPctForBundleRow / 100);
      const msaPriceUnit = afterTierTermUnit * (1 - getOptionDiscountPct(opt, b) / 100);
      const isVideo   = b.coreKey === 'vtu-ffc' || b.coreKey === 'vtu-dual';
      const promoApplied = bundlePromo === 'Media' && isVideo;
      const featureKeys = Array.isArray(b.features) ? b.features : [];
      const videoFeatureKeys = ['sd-256', 'adas', 'evc', 'monitor'];
      const vehicleFeatureKeys = ['driver-id', 'privacy', 'logbook'];
      let videoFeatures = featureKeys
        .filter(k => videoFeatureKeys.includes(k))
        .map((k) => {
          if (k === 'evc') return `EVC (${getEvcTypeLabel(b.evcType)})`;
          return featureLabels[k] || k;
        });
      if (isVideo && !featureKeys.includes('sd-256')) {
        videoFeatures = ['128 GB SD Card', ...videoFeatures];
      }
      const vehicleFeatures = featureKeys
        .filter(k => vehicleFeatureKeys.includes(k))
        .map(k => featureLabels[k] || k);
      const featureMeta = `
        ${videoFeatures.length ? `<div class="bundle-feature-line"><strong>Video:</strong> ${videoFeatures.join(', ')}</div>` : ''}
        ${vehicleFeatures.length ? `<div class="bundle-feature-line"><strong>Vehicle features:</strong> ${vehicleFeatures.join(', ')}</div>` : ''}
      `;
      let discBadges = '';
      // 2026-10-06 (per Catalina): the old custom "Media Promo \u221220%", "Custom
      // promotion \u2212$X/unit" and "Jump N tier" pills (disc-badge) are no longer
      // shown \u2014 only the VDS badges used by the current design.
      if (isChangeOption && totalOrderPctForBadge > 0) discBadges += `<span class="badge badge--blue">\u2212${totalOrderPctForBadge}%${orderDurationMonthsForBadge ? ` for ${orderDurationMonthsForBadge}mo` : ''}</span> `;

      const bundleStatRowHtml = isChangeOption
        ? VC.statRow({ className: 'bundle-stat-row--4col', cells: [
          { label: 'QTY', valueHtml: `${qtyLabel}<span>${isCancelled ? '' : '/units'}</span>${qtyStatus}${isModification ? '' : impactBadges}` },
          { label: 'List Price', value: formatMoney(standardUnitPrice) },
          { label: 'Contracted Price/mo', value: formatMoney(msaPriceUnit) },
          { label: 'Monthly', valueHtml: `${monthly < (msaPriceUnit * b.qty - 0.005) ? `<span class="bundle-stat-value-strike">${formatMoney(msaPriceUnit * b.qty)}</span> ` : ''}${formatMoney(monthly)}` },
        ] })
        : VC.statRow({ cells: [
          { label: 'QTY', valueHtml: `${qtyLabel}<span>${isCancelled ? '' : '/units'}</span>${qtyStatus}${isModification ? '' : impactBadges}` },
          { label: 'Monthly unit price', valueHtml: `${hasBundleDiscount ? `<span class="bundle-stat-value-strike">${formatMoney(standardUnitPrice)}</span> ` : ''}${formatMoney(unitPrice)}` },
          { label: 'Monthly', valueHtml: `${formatMoney(monthly)}<span>/mo</span>` },
        ] });
      const bundleRowStateClass = isCancelled ? 'bundle-row--cancelled' : (bundleDelta?.type === 'reduced' ? 'bundle-row--reduced' : (isAdded ? 'bundle-row--added' : ''));
      const bundleActionsHtml = isModification ? `<div class="bundle-row-actions">
        <button type="button" class="btn-icon btn-icon--solid btn-icon--vds-small" title="Edit solution" aria-label="Edit solution" onclick="editIsolatedTransaction(${opt.id}, ${b.id})"><span class="material-symbols-outlined" aria-hidden="true">edit</span></button>
        <button type="button" class="btn-icon btn-icon--solid btn-icon--vds-small" title="Delete solution" aria-label="Delete solution" onclick="deleteBundle(${opt.id}, ${b.id})"><span class="material-symbols-outlined" aria-hidden="true">delete</span></button>
      </div>` : '';
      const bundleTitleHtml = `${b.txLabel ? `<div style="font-size:12px;font-weight:700;color:var(--black);margin-bottom:2px;">${b.txLabel}</div>` : ''}<div class="bundle-row-name">${b.coreName}</div>`;
      const bundleBadgesHtml = discBadges ? `<div style="flex-shrink:0;display:flex;gap:4px;flex-wrap:wrap;justify-content:flex-end;">${discBadges}</div>` : '';

      bundlesHtml += VC.solutionRow({
        actionsMode: 'hover',
        className: bundleRowStateClass,
        actionsHtml: bundleActionsHtml,
        titleHtml: bundleTitleHtml,
        badgesHtml: bundleBadgesHtml,
        metaHtml: featureMeta,
        statRowHtml: bundleStatRowHtml,
      });
    });

    const card = document.createElement('div');
    card.className = 'option-card';
    card.setAttribute('data-option-id', opt.id);

    // Main button: disabled (not hidden) while the option needs approval.
    const primaryAction = { onClick: `selectOption(${opt.id})`, disabled: requiresApproval };

    // Pre-compute per-option prices for term and tier dropdowns
    const _termPx = ['12','24','36','48','60'].map(t => {
      if (totalUnits === 0) return '';
      const { totalMonthly: tm } = calcOption({...opt, term: t}, optionPromoType, optTier);
      return ' \u2014 ' + formatMoney(tm) + '/mo';
    });

    // F2: co-term \u2014 lock term display when add-on (non-Gov)
    const isCoTerm = proposalData.isAddOn && proposalData.segment !== 'Government' && !isSpecialOptionMode(opt);
    const _termLabels = ['12 months','24 months','36 months','48 months','60 months'];
    const _termVals   = ['12','24','36','48','60'];
    const termRows = _termVals.map((tv, idx) => {
      const isSel = String(opt.term) === tv;
      const isLockedOut = shouldLockMsaTerm && Number(tv) !== msaLockedTerm;
      const priceStr = _termPx[idx] ? _termPx[idx].replace(' \u2014 ', '') : '';
      return `<div class="dropdown-option opt-term-row ${isSel ?'opt-term-row--selected' : ''} ${isLockedOut ? 'opt-term-row--disabled' : ''}" ${!isLockedOut ? `onclick="selectOptTerm(${opt.id}, '${tv}')"` : ''}>
        <span class="opt-term-row-label">${_termLabels[idx]}</span>
        ${priceStr ? `<span class="opt-term-row-price">${priceStr}</span>` : ''}
      </div>`;
    }).join('');


    // 2026-09-18 (per Catalina): the term's date-range caption needs the
    // right START date to compute correctly. proposalData.msaTermStart is the
    // ORIGINAL MSA's start date \u2014 correct for a Change card (co-term), but
    // wrong for Renewal (which starts the day after the current contract
    // ends) and wrong for Rewrap (which starts on the option's own Effective
    // Date, chosen separately per option, not at the account level).
    const optTermStartDate = opt.transactionMode === 'Rewrap'
      ? (opt.effectiveDate || getDefaultEffectiveDate('Rewrap'))
      : opt.transactionMode === 'Renewal'
        ? getDefaultEffectiveDate('Renewal')
        : proposalData.msaTermStart;
    const optTermRangeLabel = (() => {
      const start = parseProposalDate(optTermStartDate);
      if (!start) return `${opt.term} months`;
      const end = getMsaTermEndDate(optTermStartDate, Number(opt.term));
      if (!end) return `${opt.term} months`;
      const startLabel = opt.transactionMode === 'Rewrap'
        ? `<span style="color:var(--orange);font-weight:700;">${formatUsDate(start)}</span>`
        : formatUsDate(start);
      return `${startLabel} \u2013 ${formatUsDate(end)}`;
    })();

    const termFieldHtml = isCoTerm
      ? `<div>
           <div class="vc-field-label">Contract term</div>
           <div class="coterm-display">
             <strong>${optTermRangeLabel}</strong>&ensp;<span style="font-size:12px;color:var(--gray-600);">Co-term \u00b7 MSA ${proposalData.msaId}</span>
           </div>
         </div>`
      : `<div>
           <div class="vc-field-label">Contract term</div>
           <div class="custom-select-wrap">
             <button class="custom-select-btn selected" onclick="toggleOptTermDropdown(${opt.id}, event)">
               <span>${opt.term} months</span>
               <span class="material-symbols-outlined">expand_more</span>
             </button>
             <div class="custom-dropdown hidden" id="opt-term-dd-${opt.id}">
               ${termRows}
             </div>
           </div>
           <div style="font-size:11px;color:var(--gray-600);margin-top:4px;">${optTermRangeLabel}</div>
         </div>`;


    // 2026-10-07: card structure, header actions and transaction-type differences come from the shared
    // option card (assets-shared/js/vc-option-card.js) \u2014 same template as Initial Sales.
    const optionCardVariant = proposalData.entryPoint === 'newProposal'
      ? 'modification'
      : ({ Reactivation: 'reactivation', Rewrap: 'rewrap', Renewal: 'renewal' }[opt.transactionMode] || 'renewal');
    card.innerHTML = VC.optionCard({
      variant: optionCardVariant,
      optId: opt.id,
      titleHtml: `<span>Option ${i + 1}</span>`,
      headerControlsHtml: renderOptionHeaderControls(opt),
      menuItems: [
        ...(opt.transactionMode === 'Change' && proposalData.entryPoint === 'newProposal' && opt.bundles.length > 0 ? [{ label: 'View List Price', onClick: 'openOptionListPriceFromCard(' + opt.id + ')' }] : []),
        { label: 'Service Order Schedule', onClick: 'openOptionScheduleFromCard(' + opt.id + ')', disabled: !(totalUnits >= SCHEDULE_THRESHOLD_QTY), title: totalUnits >= SCHEDULE_THRESHOLD_QTY ? '' : 'Available for orders of ' + SCHEDULE_THRESHOLD_QTY + '+ units (currently ' + totalUnits + ')' },
      ],
      locked: requiresApproval && proposalData.approvalStatus === 'Pending',
      termRowHtml: renderOptionMotionControls(opt, termFieldHtml),
      summaryHtml: (opt.transactionMode === 'Change' && opt.bundles.length > 0 ? buildOptionSummaryStripHtml(opt) : '')
        + (opt.transactionMode !== 'Change' ? VC.optionTotalsRow({
           className: proposalData.entryPoint === 'newProposal' ? 'opt-totals-row--new-proposal' : '',
           cells: [
             { label: 'QTY', valueClassName: 'opt-totals-value--qty', valueHtml: `${totalUnits}<span> units</span>` },
             ...(proposalData.entryPoint !== 'newProposal' ? [{ label: `Tier/Term ${getMsaDiscountTier(msaTierUnits).min}-${msaTierUnits >= 100 ? '+' : getMsaDiscountTier(msaTierUnits).max}`, valueHtml: `${getTierTermDiscountPct(opt.term, msaTierUnits)}%<span> (${msaTierUnits})</span>` }] : []),
             { label: 'Avg unit price', valueHtml: `${totalUnits > 0 ? formatMoney(avgUnit) : '\u2014'}<span>${totalUnits > 0 ? '/unit' : ''}</span>` },
             { label: 'Monthly total', valueHtml: `${formatMoney(totalMonthly)}<span>/mo</span>` },
           ],
         }) : ''),
      notificationHtml: buildApprovalBannerHtml(opt, opt),
      primaryAction,
      sectionRightHtml: opt.bundles.length > 0 && proposalData.entryPoint !== 'renewalRewrap' && opt.transactionMode !== 'Reactivation'
        ? `<span class="bundles-label-divider"></span><button class="btn-opt-promo" onclick="toggleOptPromoPanel(${opt.id})"><span class="material-symbols-outlined">sell</span> Configure promotions</button>`
        : '',
      rowsHtml: bundlesHtml,
      rowsCount: opt.bundles.length,
      footerHtml: proposalData.wavesEnabled ? buildOptWavesHtml(opt, totalUnits) : '',
    });
    grid.appendChild(card);
  });

  const addCard = document.createElement('div');
  addCard.className = 'btn-dashed-add btn-dashed-add--card add-option-card';
  addCard.onclick = () => openConfigureBundle();
  addCard.innerHTML = `+ Add option ${options.length + 1}`;
  grid.appendChild(addCard);
  updateOptionsGridAlignment();
  renderDraftingMsaCommitmentPanel();
},

  updateTerm: function updateTerm(id, val) {
  if (proposalData.lockedTerm !== null) return; // F1: term frozen after option selection
  const msaLockedTerm = Number(DEMO_MSA.termMonths) || 0;
  const opt = options.find(o => o.id === id);
  if (msaLockedTerm > 0 && !isSpecialOptionMode(opt) && parseInt(val, 10) !== msaLockedTerm) return;
  if (opt) {
    opt.term = parseInt(val);
    renderOptions();
    const optionNumber = options.findIndex((o) => o.id === id) + 1;
    logProposalEvent('Option edited', `Option ${Math.max(1, optionNumber)} term was updated to ${val} months.`);
  }
},

  confirmSelectionAndProceed: function confirmSelectionAndProceed() {
  closeConfirmSelectionModal();
  // 2026-10-07 (Catalina): same as Initial Sales \u2014 stage loader (Opportunity / Quote / Contract, plus
  // Validation when promotions apply), then the shared Contract screen (assets-shared/js/vc-contract-step.js).
  const opt = options.find((o) => o.id === bld.selectedOptionId);
  if (opt) proposalData.msaMinimumServiceTerm = opt.term;
  showQuoteCreationLoader();
},

  handleSend: function handleSend() {
  if(screen === 'drafting') {
    const requiresApprovalGate = options.some(o => (o.forcedTierIndex ?? -1) !== -1) && proposalData.approvalStatus !== 'Approved';
    if (requiresApprovalGate) return;
    // Wave plan soft validation (F3)
    const waveIssues = getWavePlanIssues();
    if (waveIssues.length > 0) {
      if (!confirm('Wave plan has incomplete items:\n\n\u2022 ' + waveIssues.join('\n\u2022 ') + '\n\nContinue sending proposal anyway?\n(Waves can be updated before contract creation.)')) return;
    }
    logProposalEvent('Review & send started', 'Proposal moved to Review & send.');
    screen = 'review';
    showProposalReviewModal();
    document.getElementById('footer-send').classList.add('hidden');
    document.getElementById('footer-back').classList.remove('visible');
    document.getElementById('footer-back').classList.add('hidden');
    
    // Global stepper is relevant
    // sub-stepper removed \u2014 nav is in header

    // Update Steppers
    document.getElementById('substep-dot-1').className = 'prop-step-dot done';
    document.getElementById('substep-date-1').innerText = new Date().toLocaleDateString();
    document.getElementById('substep-dot-2').className = 'prop-step-dot active';
    document.getElementById('substep-line-1').className = 'prop-line done';
    document.getElementById('substep-label-2').classList.remove('muted');
    
    renderProposalDoc();
    fillProposalMessageDefaults();
    updateSendBtn();
    renderNav();
  } else if (screen === 'review') {
    const isResend = proposalWasSentToCustomer === true;
    proposalWasSentToCustomer = true;
    touchNavDate('proposal_review', true);
    logProposalEvent(isResend ? 'Proposal re-sent' : 'Proposal sent', 'Proposal email was sent from Review & send.');
    screen = 'drafting';
    hideProposalReviewModal();
    document.getElementById('screen-proposal-selection').classList.add('hidden');
    document.getElementById('screen-drafting').classList.remove('hidden');
    
    document.getElementById('substep-dot-2').className = 'prop-step-dot done';
    document.getElementById('substep-date-2').innerText = new Date().toLocaleDateString();
    document.getElementById('substep-dot-3').className = 'prop-step-dot pending';
    document.getElementById('substep-line-2').className = 'prop-line';
    document.getElementById('substep-label-3').classList.add('muted');

    showSuccessBanner('Proposal sent successfully', 'Your Fleet Solutions Proposal has been sent to acme.logistics@acmecorp.com');
    
    const sendBtn = document.getElementById('footer-send');
    sendBtn.innerText = 'Send Proposal';
    sendBtn.classList.add('hidden');
    sendBtn.disabled = false;
    
    renderOptions();
    updateMarkDeadBtn();
    updateSendBtn();
    renderNav();
  } else if (screen === 'contract-review') {
    // Validate message fields
    const to = document.getElementById('contract-msg-to').value.trim();
    if (!to) { alert('Please enter a recipient email.'); return; }
    // Switch to phase 2: Sign & Payment
    document.getElementById('contract-phase-review').classList.add('hidden');
    document.getElementById('contract-phase-signpay').classList.remove('hidden');
    document.getElementById('contract-sub-stepper')?.classList.add('hidden');
    // Sync doc viewer 2
    const v1 = document.getElementById('contract-doc-viewer');
    const v2 = document.getElementById('contract-doc-viewer2');
    if (v1 && v2) {
      v2.innerHTML = v1.innerHTML;
      // Recompute scale using the new container width in Signature phase.
      requestAnimationFrame(scaleDocPages);
    }
    // Stepper: step 1 done \u2192 step 2 active
    const d1 = document.getElementById('c-dot-1');
    const d2 = document.getElementById('c-dot-2');
    const l1 = document.getElementById('c-line-1');
    if (d1) { d1.className = 'c-step-dot done'; }
    if (l1) l1.className = 'c-line done';
    if (d2) d2.className = 'c-step-dot active';
    if (document.getElementById('c-dot-label-2')) document.getElementById('c-dot-label-2').className = 'c-step-label';
    const date1 = document.getElementById('contract-date-1');
    if (date1) date1.textContent = new Date().toLocaleDateString();
    // Show a basic loader before entering waiting/signature tracking state.
    setContractSendLoaderVisible(true);
    clearContractSendLoaderTimer();
    contractSendLoaderTimer = window.setTimeout(() => {
      contractSendLoaderTimer = null;
      setContractSendLoaderVisible(false);
      finalizeContractSendTransition();
    }, CONTRACT_SEND_LOADER_DELAY_MS);
  }
},

  renderSelectionOptions: function renderSelectionOptions() {
  const grid = document.getElementById('selection-grid');
  grid.innerHTML = options.map((opt, i) => {
    const optionPromoType = getOptionPromotion(opt);
    const { totalMonthly, totalUnits, avgUnit } = calcOption(opt, optionPromoType, (opt.forcedTierIndex ?? -1));
    const tier = getEffectiveTier(totalUnits, (opt.forcedTierIndex ?? -1));
    const skip = tier.index - tier.naturalIndex;
    const requiresApproval = getOptionApprovalInfo(opt, opt).requiresApproval;

    let tierBadgeHtml = '';
    if (tier && tier.discount > 0) {
      tierBadgeHtml = `<span class="tier-badge">${tier.label}</span>`;
    } else if (totalUnits > 0) {
      tierBadgeHtml = `<span class="tier-badge" style="background:var(--gray-100);color:var(--gray-600);">${tier ? tier.label : '1-9'}</span>`;
    }

    let actionHtml = '';
    if (requiresApproval) {
      const role = getApprovalRole(skip);
      const isPending = proposalData.approvalStatus === 'Pending';
      actionHtml = `
        <!-- 2026-10-06 (per Catalina): old orange "Request approval" button removed. -->
        <button class="btn btn--primary btn--large btn-select-contract" disabled>Select &amp; Create Contract</button>
      `;
    } else {
      actionHtml = `
        <button class="btn btn--primary btn--large btn-select-contract" onclick="selectOption(${opt.id})">Select &amp; Create Contract</button>
      `;
    }

    const videoFeatureKeys = ['sd-256', 'adas', 'evc', 'monitor'];
    const vehicleFeatureKeys = ['driver-id', 'privacy', 'logbook'];

    let bundlesHtml = '';
    opt.bundles.forEach(b => {
      const bundlePromo = b.promoType || optionPromoType;
      const { unitPrice, monthly, tier: bt } = calcBundle(b, opt.term, bundlePromo, totalUnits);
      const standardUnitPrice = getStandardUnitPrice(b);
      const hasBundleDiscount = standardUnitPrice > unitPrice + 0.005;
      const isVideo = b.coreKey === 'vtu-ffc' || b.coreKey === 'vtu-dual';
      const promoApplied = bundlePromo === 'Media' && isVideo;
      const featureKeys = Array.isArray(b.features) ? b.features : [];
      let videoFeatures = featureKeys
        .filter(k => videoFeatureKeys.includes(k))
        .map((k) => {
          if (k === 'evc') return `EVC (${getEvcTypeLabel(b.evcType)})`;
          return featureLabels[k] || k;
        });
      if (isVideo && !featureKeys.includes('sd-256')) {
        videoFeatures = ['128 GB SD Card', ...videoFeatures];
      }
      const vehicleFeatures = featureKeys
        .filter(k => vehicleFeatureKeys.includes(k))
        .map(k => featureLabels[k] || k);
      const featureMeta = `
        ${videoFeatures.length ? `<div class="bundle-feature-line"><strong>Video:</strong> ${videoFeatures.join(', ')}</div>` : ''}
        ${vehicleFeatures.length ? `<div class="bundle-feature-line"><strong>Vehicle features:</strong> ${vehicleFeatures.join(', ')}</div>` : ''}
      `;
      let discBadges = ''; // old "Media Promo \u221220%" pill removed 2026-10-06 (per Catalina)

      bundlesHtml += `
        <div class="bundle-row">
          <div class="bundle-row-name">${b.coreName} <span style="float:right;font-weight:400;font-size:11px;color:var(--gray-600)">QTY: ${b.qty}</span></div>
          ${featureMeta}
          <div class="bundle-row-price">${formatMoney(monthly)}<span>/month</span></div>
          <div class="bundle-row-unit">${hasBundleDiscount ? `<span class="bundle-stat-value-strike">${formatMoney(standardUnitPrice)}</span> ` : ''}${formatMoney(unitPrice)}/unit</div>
          <div style="margin-top:6px;">${discBadges}</div>
        </div>`;
    });

    return `
      <div class="option-card option-card--readonly">
        <div class="option-card-header">
          <span>Option ${i+1}</span>
        </div>
        <div class="option-card-body">
          <div class="monthly-total">
            <div class="vc-field-label" style="margin-top:12px;display:flex;align-items:center;justify-content:space-between;">
              <span>Monthly total</span>
              <div style="display:flex; align-items:center; gap:8px;">
                ${tierBadgeHtml}
                <span style="color:var(--gray-600); font-size:11px; font-weight:400;">QTY: ${totalUnits}</span>
              </div>
            </div>
            <div class="monthly-amount">${formatMoney(totalMonthly)}<span>/month</span></div>
            <div class="per-unit">${formatMoney(avgUnit)}/unit (avg)</div>
          </div>
          ${actionHtml}
          <div class="bundles-list">
            ${VC.sectionStrip({ icon: proposalData.entryPoint === 'newProposal' ? 'receipt_long' : 'package_2', title: proposalData.entryPoint === 'newProposal' ? 'Modifications' : 'Active Solutions', count: opt.bundles.length })}
            ${bundlesHtml || '<div style="font-size:11px;color:var(--gray-400);padding:16px;text-align:center;">No transactions yet</div>'}
          </div>
        </div>
      </div>`;
  }).join('');
},

  updateSendBtn: function updateSendBtn() {
  const btn = document.getElementById('footer-send');
  const draftingBtn = document.getElementById('drafting-review-btn');
  const reviewSendBtn = document.getElementById('review-send-proposal-btn');
  if (screen === 'drafting') {
    const hasAnyBundle = options.some(opt => opt.bundles && opt.bundles.length > 0);
    const requiresApprovalGate = options.some(o => (o.forcedTierIndex ?? -1) !== -1) && proposalData.approvalStatus !== 'Approved';
    const disableReviewSend = !hasAnyBundle || requiresApprovalGate;
    if (draftingBtn) draftingBtn.disabled = disableReviewSend;
    if (btn) btn.disabled = disableReviewSend;
  } else if (screen === 'review') {
    const to = document.getElementById('prop-msg-to')?.value.trim() ?? '';
    const closeDate = document.getElementById('proposal-close-date')?.value.trim() ?? '';
    const closeDateError = document.getElementById('close-date-error');
    const closeDateEmpty = closeDate === '';
    if (closeDateError) closeDateError.classList.toggle('hidden', !closeDateEmpty);
    document.getElementById('proposal-close-date')?.classList.toggle('input--error', closeDateEmpty);
    const disabled = (to === '') || closeDateEmpty;
    if (reviewSendBtn) reviewSendBtn.disabled = disabled;
    if (btn) btn.disabled = disabled;
  } else if (screen === 'selection') {
    btn.innerText = 'Select Winning Option';
    btn.disabled = true; // Enabled when a card is selected
  } else if (screen === 'contract-review') {
    const to = document.getElementById('contract-msg-to').value.trim();
    btn.disabled = (to === ""); 
  }
},

  openQuotesList: function openQuotesList() {
  const vcAppUi = document.getElementById('vc-app-ui');
  if (vcAppUi) vcAppUi.classList.remove('hidden');

  screen = 'quotes-list';
  document.getElementById('screen-quotes-list')?.classList.remove('hidden');
  document.getElementById('screen-drafting')?.classList.add('hidden');
  document.getElementById('screen-proposal-selection')?.classList.add('hidden');
  document.getElementById('screen-contract')?.classList.add('hidden');
  document.getElementById('screen-deal-result')?.classList.add('hidden');

  document.getElementById('vc-body').style.paddingTop = `${getAppTopOffset()}px`;
  document.getElementById('vc-nav')?.classList.add('hidden');

  const sendBtn = document.getElementById('footer-send');
  if (sendBtn) { sendBtn.classList.add('hidden'); }
  const backBtn = document.getElementById('footer-back');
  backBtn?.classList.remove('visible');
  backBtn?.classList.add('hidden');

  // Disable "New Proposal" if a Drafting row already exists in the table
  const hasDrafting = !!document.querySelector('#screen-quotes-list .badge--stone');
  syncNewProposalButton();
  const newProposalBtn = document.getElementById('btn-new-proposal');
  if (newProposalBtn) {
    newProposalBtn.disabled = hasDrafting;
    newProposalBtn.title = hasDrafting ? 'A proposal is already in Drafting' : '';
  }

  renderQuotesListMsaCommitmentPanel();
},

  openDraftingRoute: function openDraftingRoute(entryPoint) {
  const vcAppUi = document.getElementById('vc-app-ui');
  if (vcAppUi) vcAppUi.classList.remove('hidden');

  // 2026-09-18 (R21.2, per Catalina): default entry point is "Create new
  // proposal" (bare cards). The Renewal/Rewrap kebab entry point (R21.1, VS)
  // should call openDraftingRoute('renewalRewrap') \u2014 or, better, go through
  // startRenewalRewrapProposal() below, which also pre-seeds the option.
  proposalData.entryPoint = ['renewalRewrap', 'reactivation'].includes(entryPoint) ? entryPoint : 'newProposal';
  resetProposalProgress();

  // Auto-generate proposal name: AccountName_YYYY-MM-DD
  const accountName = (document.querySelector('.vc-account-name')?.textContent || 'Account').trim();

  const today = new Date();
  const dateStr = `${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,'0')}-${String(today.getDate()).padStart(2,'0')}`;
  proposalData.name = `${accountName}_${dateStr}`;
  proposalData.proposalId = getNextProposalId();
  proposalData.hasCustomName = false;
  proposalData.quoteReference = '';

  screen = 'drafting';
  document.getElementById('vc-nav')?.classList.remove('hidden');
  document.getElementById('screen-quotes-list')?.classList.add('hidden');
  document.getElementById('screen-drafting')?.classList.remove('hidden');
  hideProposalReviewModal();
  document.getElementById('screen-proposal-selection')?.classList.add('hidden');
  document.getElementById('screen-contract')?.classList.add('hidden');
  document.getElementById('screen-deal-result')?.classList.add('hidden');

  document.getElementById('vc-body').style.paddingTop = `${getAppTopOffset()}px`;
  document.getElementById('success-banner').style.top = `${getAppTopOffset()}px`;
  window.scrollTo(0, 0);

  const sendBtn = document.getElementById('footer-send');
  if (sendBtn) {
    sendBtn.classList.add('hidden');
    sendBtn.innerText = 'Send Proposal';
    sendBtn.onclick = handleSend;
  }
  const backBtn = document.getElementById('footer-back');
  backBtn?.classList.remove('visible');
  backBtn?.classList.add('hidden');

  updateDraftingHeaderTitle();
  renderDraftingMsaCommitmentPanel();
  renderOptions();
  // 2026-09-17 fix: this used to unconditionally un-hide BOTH #empty-state and
  // #options-grid, so a fresh proposal showed the "No pricing options yet" CTA
  // and the grid's own dashed "+ Add option" placeholder card at the same time
  // (on top of the Current panel) \u2014 toggle them the same way every other call
  // site in this file does, based on whether options actually exist.
  const hasOptions = Array.isArray(options) && options.length > 0;
  document.getElementById('empty-state')?.classList.toggle('hidden', hasOptions);
  document.getElementById('options-grid')?.classList.toggle('hidden', !hasOptions);
  renderNav();
},

  openDraftingQuoteFromList: function openDraftingQuoteFromList() {
  // Demo: restore an existing Drafting quote with pre-configured option cards.
  proposalData.name = 'Fleet Solutions';
  proposalData.quoteReference = 'Q-2025-0042';
  proposalData.hasCustomName = false;
  proposalData.promoType = 'Standard';
  proposalData.approvalStatus = 'None';
  proposalIsSaved = true;

  options = [
    {
      id: 1,
      name: 'Option 1',
      term: 36,
      forcedTierIndex: -1,
      bundles: [
        {
          id: 1001,
          coreKey: 'vtu',
          coreName: 'VTU Only',
          basePrice: 29.6,
          baseCorePrice: 29.6,
          features: ['driver-id'],
          qty: 1,
          promoType: 'Standard'
        }
      ],
      waves: []
    }
  ];
  nextOptId = 2;

  openDraftingRoute();
  proposalData.name = 'Fleet Solutions';
  proposalData.proposalId = '0524';
  proposalData.quoteReference = 'Q-2025-0042';
  updateDraftingHeaderTitle();
  renderOptions();

  const hasOptions = Array.isArray(options) && options.length > 0;
  document.getElementById('empty-state')?.classList.toggle('hidden', hasOptions);
  document.getElementById('options-grid')?.classList.toggle('hidden', !hasOptions);
  updateMarkDeadBtn();
  renderNav();
}
};

// Fields Existing Accounts' proposal / builder state carries on top of Initial Sales'.
const EXISTING_PROPOSAL_DEFAULTS = {
  entryPoint: 'newProposal', forcedTierIndex: -1, approvalStatus: 'None', lockedTerm: null,
  isAddOn: false, msaId: 'MSA-2024-0391', msaSubscription: '34.00', msaMinimumSpendCommitment: 870.00,
  msaTermStart: '2025-01-01', msaContractTerm: 36, msaServiceOrderTerm: '36', serviceOrderStartDate: '',
  serviceOrderEndDate: '', msaRampUpPeriod: 30, msaDiscretionaryDiscountPct: 7, msaEndDate: '', wavesEnabled: false,
  segment: 'SMB', poNumber: '', costCenter: '', contractVehicle: '', contractingOfficerName: '',
  contractingOfficerEmail: '', contractingOfficerPhone: '',
};

let existingAccountsModeOn = false;
const INITIAL_SALES_VERSIONS = {};
const INITIAL_SALES_PROPOSAL_VALUES = {};
function setExistingAccountsMode(on) {
  on = !!on;
  Object.keys(EXISTING_ACCOUNTS_OVERRIDES).forEach(name => {
    if (!(name in INITIAL_SALES_VERSIONS)) INITIAL_SALES_VERSIONS[name] = window[name];
    window[name] = on ? EXISTING_ACCOUNTS_OVERRIDES[name] : INITIAL_SALES_VERSIONS[name];
  });
  // The proposal takes the existing account's MSA facts while in this mode; Initial Sales' values come back after.
  if (on && !existingAccountsModeOn) {
    Object.keys(EXISTING_PROPOSAL_DEFAULTS).forEach(key => {
      INITIAL_SALES_PROPOSAL_VALUES[key] = { had: key in proposalData, value: proposalData[key] };
      proposalData[key] = EXISTING_PROPOSAL_DEFAULTS[key];
    });
    if (!('msaDiscountPct' in bld)) bld.msaDiscountPct = 0;
  } else if (!on && existingAccountsModeOn) {
    Object.keys(INITIAL_SALES_PROPOSAL_VALUES).forEach(key => {
      const saved = INITIAL_SALES_PROPOSAL_VALUES[key];
      if (saved.had) proposalData[key] = saved.value; else delete proposalData[key];
    });
    document.querySelectorAll('#msa-commitment-list-slot, #msa-commitment-drafting-slot, .msa-commitment-step-slot')
      .forEach(slot => { slot.innerHTML = ''; });
  }
  // Existing Accounts starts Configure Solution on \u00c0 la carte; Initial Sales on Bundle (when the account allows both).
  if (typeof getAllowedSolutionTypes === 'function') {
    const allowed = getAllowedSolutionTypes();
    const preferred = on ? 'custom' : 'plan';
    builderMode = allowed.includes(preferred) ? preferred : allowed[0];
  }
  existingAccountsModeOn = on;
  document.body.classList.toggle('vc-existing-mode', on);
  // Configure Solution reads "Expansion Summary" / "Add Expansion" for an existing account.
  if (on && typeof renderProposalMetaMsaSummary === 'function') renderProposalMetaMsaSummary();
  // Confirm selection copy: a new account generates its MSA; an existing account starts a quote on its MSA.
  const confirmSubtext = document.getElementById('csm-option-subtext');
  if (confirmSubtext) confirmSubtext.textContent = on
    ? 'This will lock the drafting session and initiate the quote generation process.'
    : 'This will lock the drafting session and generate the Master Service Agreement contract.';
  const summaryTitle = document.querySelector('#bundle-overlay .preview-label--title');
  if (summaryTitle) summaryTitle.textContent = on ? 'Expansion Summary' : 'Solution Summary';
}
