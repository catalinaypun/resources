/* ── Option card (shared template, 2026-10-07) ─────────────────────────────────────────
   One option card for Initial Sales and Existing Accounts. The flows keep the pricing math
   (rows, totals, notifications) and pass the pieces in; this file owns the card's structure,
   its header actions and the differences between transaction types (VC.OPTION_CARD_VARIANTS).
   Load after vc-components.js (uses VC.optionCardHeader, VC.kebabMenu, VC.sectionStrip).

   VC.optionCard({
     variant,              // key of VC.OPTION_CARD_VARIANTS (see below)
    variantConfig,        // per-instance overrides for sectionTitle/icon, addLabel, emptyText, primaryLabel, readOnly
    readOnly,             // optional per-instance override for the variant's read-only state
     optId,                // option id (used for menu ids and default handlers)
     titleHtml,            // "Option 1", "Pilot 1", "→ MSA"…
     headerControlsHtml,   // optional middle slot in the header (Existing: Renewal / Rewrap + Change summary)
    headerActionsHtml,    // optional flow-rendered action group; replaces shared kebab / clone / delete
    actionsHidden,        // hide header actions when controls are rendered elsewhere by the flow
     menuItems,            // VC.kebabMenu items for the ⋮ menu (flow decides which actions apply)
     afterHeaderHtml,      // optional strip between header and body (Initial Sales: Pilot summary)
     locked,               // body frozen while an approval request is pending
     topHtml,              // optional first block of the body (approval chip, One Card MSA strip…)
     termRowHtml,          // Contract term + Discounts & Promotions row (VC.optionTermDiscountRow or flow markup)
     summaryHtml,          // totals row / summary strip
     notificationHtml,     // option-level notification (approval)
     extraHtml,            // transaction-specific block below the notification (optional)
     primaryAction,        // { label?, onClick, disabled } — label defaults to the variant's; null hides it
     leadingSectionsHtml,  // sections above Solutions (Initial Sales: Account level)
     sectionFollows,       // Solutions strip follows another section (no top radius)
     sectionRightHtml,     // right side of the Solutions strip
     rowsHtml,             // solution rows (VC.bundleRow…)
     onAdd,                // "+ Add …" handler
     footerHtml,           // after the solutions list (waves)
   }) → inner HTML of <div class="option-card" data-option-id="…">
*/
(function () {
  window.VC = window.VC || {};

  /* Differences by transaction type — the column the future Simulation Builder matrix will drive. */
  var NEW = { sectionIcon: 'package_2', sectionTitle: 'Solutions', addLabel: '+ Add Solution', emptyText: 'No solutions yet', primaryLabel: 'Select &amp; Create Contract', readOnly: false };
  var EXISTING = { sectionIcon: 'package_2', sectionTitle: 'Active Solutions', addLabel: '+ Add modification', emptyText: 'No transactions yet', primaryLabel: 'Select &amp; Create Contract', readOnly: false };
  function extend(base, over) { var o = {}, k; for (k in base) o[k] = base[k]; for (k in over) o[k] = over[k]; return o; }
  VC.OPTION_CARD_VARIANTS = {
    'new': NEW,                                                                 // Initial Sales option
    'pilot': extend(NEW, {}),                                                   // Initial Sales pilot (One Card); independent defaults, Pilot content is supplied through slots
    'msa-preview': extend(NEW, { readOnly: true }),                             // pilot's post-conversion MSA (data only)
    'modification': extend(EXISTING, { sectionIcon: 'receipt_long', sectionTitle: 'Modifications' }), // Existing · new proposal
    'renewal': EXISTING,                                                        // Existing · Renewal
    'rewrap': EXISTING,                                                         // Existing · Rewrap
    'reactivation': EXISTING,                                                   // Existing · Reactivation
  };

  function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;'); }

  VC.optionCardActions = function (p) {
    var id = p.optId;
    var menu = '<div class="option-card-menu-wrap">' + VC.kebabMenu({
      id: 'option-card-menu-wrap-' + id, panelId: 'opt-card-menu-' + id,
      label: 'More actions', triggerTitle: 'Option menu', onToggle: p.onMenuToggle || ('toggleOptionCardMenu(' + id + ', event)'),
      items: p.menuItems || [],
    }) + '</div>';
    if (p.readOnly) return menu;
    return menu +
      '<button type="button" class="btn-icon btn-icon--vds-small" title="Clone" aria-label="Clone" onclick="duplicateOption(' + id + ')"><span class="material-symbols-outlined" aria-hidden="true">content_copy</span></button>' +
      '<button type="button" class="btn-icon btn-icon--vds-small btn-delete-option" title="Delete option" aria-label="Delete option" onclick="deleteOption(' + id + ')"><span class="material-symbols-outlined" aria-hidden="true">delete</span></button>';
  };

  /* Contract term + Discounts & Promotions row. { termHtml, discountHtml, showDiscount, unified } —
     showDiscount (default: discountHtml not empty) decides whether the discount column exists. */
  VC.optionTermDiscountRow = function (p) {
    var hasDiscount = p.showDiscount != null ? !!p.showDiscount : !!p.discountHtml;
    return '<div class="opt-term-discount-row' + (hasDiscount ? ' opt-term-discount-row--split' : '') + (hasDiscount && p.unified ? ' opt-term-discount-row--unified' : '') + '">' +
      '<div class="opt-term-cell">' + (p.termHtml || '') + '</div>' +
      (hasDiscount ? '<div class="opt-discount-cell">' + p.discountHtml + '</div>' : '') +
      '</div>';
  };

  VC.optionCard = function (p) {
    p = p || {};
    var baseVariant = VC.OPTION_CARD_VARIANTS[p.variant] || NEW;
    var v = extend(baseVariant, p.variantConfig || {});
    // Optional configuration hook (Unified composer, 2026-10-09): { variant, sectionTitle, addLabel,
    // primaryLabel } — swaps the card variant and/or its texts. Flows without the hook render as before.
    var conf = typeof VC.optionCardVariables === 'function' ? (VC.optionCardVariables(p.variant) || {}) : {};
    if (conf.variant && VC.OPTION_CARD_VARIANTS[conf.variant]) v = extend(VC.OPTION_CARD_VARIANTS[conf.variant], p.variantConfig || {});
    ['sectionTitle', 'addLabel', 'primaryLabel'].forEach(function (k) { if (conf[k]) v[k] = conf[k]; });
    var readOnly = p.readOnly == null ? !!v.readOnly : !!p.readOnly;
    var header = VC.optionCardHeader({
      titleHtml: p.titleHtml || '',
      beforeActionsHtml: p.headerControlsHtml || '',
      actionsHtml: p.headerActionsHtml != null ? p.headerActionsHtml : VC.optionCardActions({ optId: p.optId, menuItems: p.menuItems, onMenuToggle: p.onMenuToggle, readOnly: readOnly }),
      actionsHidden: readOnly || !!p.actionsHidden,
    });
    var pa = p.primaryAction;
    var primary = (readOnly || !pa) ? '' :
      '<button class="btn btn--primary btn--large btn-select-contract"' + (pa.disabled ? ' disabled' : '') + (pa.onClick ? ' onclick="' + esc(pa.onClick) + '"' : '') + '>' + (pa.label || v.primaryLabel) + '</button>';
    var list = '<div class="bundles-list">' +
      (readOnly ? '' : (p.leadingSectionsHtml || '')) +
      VC.sectionStrip({ icon: v.sectionIcon, title: v.sectionTitle, count: p.rowsCount != null ? p.rowsCount : 0, follows: !readOnly && !!p.sectionFollows, rightHtml: p.sectionRightHtml || '' }) +
      (p.rowsHtml || '<div class="vc-option-card__empty">' + v.emptyText + '</div>') +
      (readOnly ? '' : '<button class="btn-dashed-add btn-dashed-add--pill btn-add-bundle" onclick="' + esc(p.onAdd || ('openConfigureBundle(' + p.optId + ')')) + '">' + v.addLabel + '</button>') +
      '</div>';
    return header + (p.afterHeaderHtml || '') +
      '<div class="option-card-body' + (p.locked ? ' option-card-body--locked' : '') + '">' +
      (p.topHtml || '') + (p.termRowHtml || '') + (p.summaryHtml || '') + (p.notificationHtml || '') + (p.extraHtml || '') +
      primary + list + (p.footerHtml || '') +
      '</div>';
  };
})();


/* ── Current / Previous setup panel (shared, 2026-10-09) ──────────────────────────────────────────
   Moved from Existing Accounts. Read-only card on the left of the options board with what the account
   has today ("Previous setup" on Reactivation). The flow computes the numbers; this owns the markup.
   VC.currentSetupPanel({ title, caption, totalUnits, monthlyHtml, summaryHtml,
     bundles: [{ name, qty, monthlyHtml, unitHtml, listHtml, discountPct, promoLabel }] })
   Host: <aside class="current-proposal-panel" id="current-proposal-panel">; toggle: toggleCurrentProposalPanel(). */
(function () {
  window.VC = window.VC || {};
  VC.currentSetupPanel = function (p) {
    p = p || {};
    var bundles = p.bundles || [];
    var rows = bundles.map(function (b) {
      var meta = (b.discountPct || b.promoLabel)
        ? '<div class="current-proposal-bundle-meta">' +
            (b.discountPct ? '<span class="current-proposal-discount-pct">' + b.discountPct + '% off</span>' : '') +
            (b.promoLabel ? '<span class="current-proposal-promo-badge">' + b.promoLabel + '</span>' : '') +
          '</div>'
        : '';
      return '\n      <div class="bundle-row">' +
        '\n        <div class="bundle-row-name"><span class="current-proposal-bundle-name">' + b.name + '</span><span class="current-proposal-bundle-qty">QTY: ' + b.qty + '</span></div>' +
        '\n        <div class="bundle-row-price">' + b.monthlyHtml + '<span>/month</span></div>' +
        '\n        <div class="bundle-row-unit">' + b.unitHtml + '/unit' + (b.listHtml ? ' <span class="current-proposal-list-price">list ' + b.listHtml + '</span>' : '') + '</div>' +
        '\n        ' + meta +
        '\n      </div>';
    }).join('');
    return '<div class="option-card option-card--readonly current-proposal-card">' +
      '<div class="option-card-header">' +
        '<div class="current-proposal-header-actions">' +
          '<button type="button" onclick="window.toggleCurrentProposalPanel(event)" aria-label="Collapse Current" title="Collapse Current">' +
            '<span class="material-symbols-outlined" data-current-toggle-icon>chevron_left</span>' +
          '</button>' +
        '</div>' +
        '<span class="current-proposal-title">' + (p.title || 'Current setup') + '</span>' +
      '</div>' +
      '<div class="option-card-body">' +
        '<div class="current-proposal-caption">' + (p.caption || '') + '</div>' +
        (p.filtersHtml || '') +
        '<div class="monthly-total">' +
          '<div class="vc-field-label current-proposal-total-label"><span>Monthly total</span><span class="current-proposal-total-qty">QTY: ' + (p.totalUnits || 0) + '</span></div>' +
          '<div class="monthly-amount">' + (p.monthlyHtml || '') + '<span>/month</span></div>' +
          '<div class="per-unit">' + (p.summaryHtml || '') + '</div>' +
        '</div>' +
        '<div class="bundles-list">' +
          VC.sectionStrip({ icon: 'package_2', title: 'Active solutions', count: bundles.length }) +
          (rows || '<div class="current-proposal-empty">No active solutions</div>') +
        '</div>' +
      '</div>' +
    '</div>';
  };
})();

window.toggleCurrentProposalPanel = function toggleCurrentProposalPanel(event) {
  event?.stopPropagation();
  const panel = document.getElementById('current-proposal-panel');
  if (!panel) return;
  const collapsed = panel.classList.toggle('is-collapsed');
  const icon = panel.querySelector('[data-current-toggle-icon]');
  const button = panel.querySelector('.current-proposal-header-actions button:last-child');
  if (icon) icon.textContent = collapsed ? 'chevron_right' : 'chevron_left';
  if (button) {
    button.setAttribute('aria-label', collapsed ? 'Expand Current' : 'Collapse Current');
    button.title = collapsed ? 'Expand Current' : 'Collapse Current';
  }
}
