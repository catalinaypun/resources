/* ── Approval process (shared, 2026-10-07) ─────────────────────────────────────────────
   Same approval for Initial Sales and Existing Accounts. PLACEHOLDER RULE until the real approval rules
   are defined (per Catalina, 2026-10-07): an option needs approval when it has a Custom Discount (MSA) or a
   Custom Promotion (Order) with a value. (A discretionary discount above the 30% auto-approval limit also
   counts, but no program reaches it from the UI today — only the "Pending approval" demo proposal uses it.)
   Then: compact notification in the option card, "Select & Create Contract" disabled, and one notification
   above the options with "Request approval" → modal (Reason, Justification, optional upload) → Pending
   ("Awaiting … approval", "Cancel request", card frozen) → Approved.
   Markup: VC.approvalRequestModalMarkup() (host in each flow). Notifications: VC.approvalNotification.
   Flows provide options, proposalData, screen, calcOption, renderOptions, renderOptPromoDrawer,
   renderSelectionOptions, updateSendBtn, showSuccessBanner. */
window.VC = window.VC || {};
window.VC.approvalRequestModalMarkup = function () { 
  // The upload box is built here (VC.fileUpload) — an inline <script> inside markup injected with outerHTML never runs.
  return "\u003cdiv class=\"modal-overlay\" id=\"approval-request-overlay\" onclick=\"closeApprovalRequestModal()\">\n  \u003cdiv class=\"modal modal--md approval-request-modal\" role=\"dialog\" aria-modal=\"true\" aria-labelledby=\"approval-request-title\" onclick=\"event.stopPropagation()\">\n    \u003cbutton type=\"button\" class=\"modal__close btn-icon btn-icon--ghost-vds btn-icon--vds-large\" onclick=\"closeApprovalRequestModal()\" aria-label=\"Close\">\u003cspan class=\"material-symbols-outlined\" aria-hidden=\"true\">close\u003c/span>\u003c/button>\n    \u003cdiv class=\"modal__content\">\n      \u003ch2 id=\"approval-request-title\" class=\"modal__title\">Request Pricing Approval\u003c/h2>\n      \u003cdiv class=\"approval-request-body modal__body modal__scroll-area\">\n\n      \u003cdiv class=\"approval-field\">\n        \u003clabel class=\"vc-field-label\" for=\"approval-reason\">Reason\u003c/label>\n        \u003cselect id=\"approval-reason\" class=\"select\" data-vc-dropdown onchange=\"updateApprovalRequestSubmitState()\">\n          \u003coption value=\"\">Select reason...\u003c/option>\n          \u003coption value=\"Discretionary discount outside auto-approval limit\">Discretionary discount outside auto-approval limit\u003c/option>\n          \u003coption value=\"Custom pricing\">Custom pricing\u003c/option>\n          \u003coption value=\"Other\">Other\u003c/option>\n        \u003c/select>\n        \u003cdiv id=\"approval-reason-error\" class=\"input__error-text hidden\">Reason is required to submit the request.\u003c/div>\n      \u003c/div>\n\n      \u003cdiv class=\"approval-field\">\n        \u003cdiv class=\"textarea-field textarea-field--4x\">\n          \u003clabel class=\"textarea-field__label\" for=\"approval-justification\">Justification\u003c/label>\n          \u003cdiv class=\"textarea-field__container\">\u003ctextarea id=\"approval-justification\" class=\"textarea-field__input approval-justification-input\" rows=\"4\" placeholder=\"Provide business case for special pricing...\" oninput=\"updateApprovalRequestSubmitState()\">\u003c/textarea>\u003c/div>\n          \u003cdiv id=\"approval-justification-error\" class=\"input__error-text hidden\">Justification is required to submit the request.\u003c/div>\n        \u003c/div>\n      \u003c/div>\n\n      \u003cdiv class=\"approval-field\">\n        __UPLOAD__\n      \u003c/div>\n    \u003c/div>\n\n      \u003c/div>\n    \u003cdiv class=\"approval-request-actions modal__actions modal__actions--fill-container\">\n      \u003cbutton type=\"button\" class=\"btn btn--secondary btn--large\" onclick=\"closeApprovalRequestModal()\">Cancel\u003c/button>\n      \u003cbutton type=\"button\" class=\"btn btn--primary btn--large\" id=\"approval-submit-btn\" onclick=\"submitApprovalRequest()\" disabled>Submit Request\u003c/button>\n    \u003c/div>\n  \u003c/div>\n\u003c/div>".replace('__UPLOAD__', VC.fileUpload({ label: 'Supporting documentation (optional)', inputId: 'approval-upload-input', filenameId: 'approval-upload-filename', onClick: 'triggerApprovalUpload()', onChange: 'handleApprovalUploadChange(this)' }));
};

// Needs approval regardless of the request status (the status decides what the UI does with it).
function optionNeedsApproval(opt) {
  if (!opt || !opt.bundles || opt.bundles.length === 0) return false;
  const { msaTierUnits } = calcOption(opt, getOptionPromotion(opt));
  const discretionaryBoundaries = getMsaDiscretionaryApprovalBoundaries(opt.term, msaTierUnits);
  return optionHasUnapprovedDiscount(opt, discretionaryBoundaries);
}

function getApprovalDetails() {
  let targetOpt = (Array.isArray(options) ? options.find(optionNeedsApproval) : null) || (Array.isArray(options) && options[0]) || null;

  let role = 'Associate Director';
  if (targetOpt) {
    const { totalUnits, msaTierUnits } = calcOption(targetOpt, getOptionPromotion(targetOpt));
    const skip = 0; // tier jumps don't trigger approval under the placeholder rule
    const discretionaryBoundaries = getMsaDiscretionaryApprovalBoundaries(targetOpt.term, msaTierUnits);
    const discretionaryApprovalLevel = getMsaDiscretionaryApprovalLevel(targetOpt.msaDiscountPct || 0, discretionaryBoundaries);
    if (skip >= 2 || discretionaryApprovalLevel === 2) {
      role = 'Director';
    } else if (skip === 1 || discretionaryApprovalLevel === 1) {
      role = 'Associate Director';
    } else {
      role = (skip > 0 ? getApprovalRole(skip) : 'Associate Director');
    }
  }
  return { role, targetOpt };
}

function buildApprovalBannerHtml(calcOpt, opt) {
  const { requiresApproval, role } = getOptionApprovalInfo(calcOpt, opt);
  if (!requiresApproval) return '';
  const isPending = proposalData.approvalStatus === 'Pending';
  const req = proposalData.approvalRequest;
  return VC.approvalNotification({ compact: true, title: isPending ? `Awaiting ${req ? req.role : role} approval` : role + ' approval required' });
  // 2026-10-05 (per Catalina / meeting): the card notification is now only
  // informative — Request / Cancel request moved to the proposal-level
  // notification above the options (buildApprovalSummaryBannerHtml), so one
  // request covers every option that needs approval.
}

function buildApprovalSummaryBannerHtml() {
  if (proposalData.approvalStatus === 'Approved') return '';
  const pending = [];
  let role = 'Associate Director';
  options.forEach((opt, index) => {
    if (opt.msaPreviewFor || !opt.bundles || !opt.bundles.length) return;
    const info = getOptionApprovalInfo(opt, opt);
    if (!info.requiresApproval) return;
    pending.push(getOptionDisplayLabel(index + 1));
    if (info.role === 'Director') role = 'Director';
  });
  if (!pending.length) return '';
  const isPending = proposalData.approvalStatus === 'Pending';
  const req = proposalData.approvalRequest;
  const list = pending.length === 1 ? pending[0] : `${pending.slice(0, -1).join(', ')} and ${pending[pending.length - 1]}`;
  const message = isPending
    ? `${req ? `Req #${req.id} · ` : ''}${list} can't be selected until the request is approved.`
    : `${list} ${pending.length === 1 ? 'needs' : 'need'} approval before you can create a contract and ${pending.length === 1 ? 'is' : 'are'} left out of the proposal until approved.${pending.length > 1 ? ' One request covers all of them.' : ''}`;
  return VC.approvalNotification({
    className: 'approval-summary-banner',
    title: isPending ? `Awaiting ${req ? req.role : role} approval` : `${role} approval required`,
    message,
    action: isPending ? { label: 'Cancel request', onClick: 'cancelApprovalRequest()' } : { label: 'Request approval', onClick: 'requestApproval()' },
  });
}

function updateApprovalSnackbar() {
  const wrap = document.getElementById('approval-snackbar-wrap');
  if (!wrap) return;
  const isForced = Array.isArray(options) && options.some(optionNeedsApproval);
  const isApproved = proposalData.approvalStatus === 'Approved';
  const isPending  = proposalData.approvalStatus === 'Pending';
  const hasOptions = Array.isArray(options) && options.some(opt => opt.bundles && opt.bundles.length > 0);

  // 2026-10-05 (per Catalina / meeting): a proposal-level approval notification
  // is back above the options, with the single Request approval action; the
  // option cards keep an informative notification without a button.
  wrap.innerHTML = buildApprovalSummaryBannerHtml();
  if (screen === 'drafting' && typeof updateSendBtn === 'function') updateSendBtn();

  if (!isForced || isApproved) {
    document.querySelectorAll('.btn-select-contract').forEach(btn => {
      btn.disabled = false;
    });
    return;
  }

  // Text stays "Select & Create Quote" always — only the disabled state changes (2026-09-16, per Catalina).
  syncSelectContractButtons(opt => !!(opt.bundles && opt.bundles.length) && getOptionApprovalInfo(opt, opt).requiresApproval);
}

function getSelectContractButtonOption(btn) {
  const match = /selectOption\((\d+)\)/.exec(btn.getAttribute('onclick') || '');
  return match ? options.find(o => o.id === Number(match[1])) : null;
}

function syncSelectContractButtons(optionNeedsApproval, lockedLabel) {
  document.querySelectorAll('.btn-select-contract').forEach(btn => {
    const opt = getSelectContractButtonOption(btn);
    if (!opt) return;
    const locked = proposalData.approvalStatus !== 'Approved' && optionNeedsApproval(opt);
    btn.disabled = locked;
    if (lockedLabel) btn.textContent = locked ? lockedLabel : 'Select & Create Contract';
  });
}

function requestApproval() {
  if (!Array.isArray(options) || !options.some(opt => opt.bundles && opt.bundles.length > 0)) return;
  openApprovalRequestModal();
}

function cancelApprovalRequest() {
  proposalData.approvalStatus = 'None';
  proposalData.approvalRequest = null;
  renderOptions();
  renderOptPromoDrawer();
  if (screen === 'selection') renderSelectionOptions();
  updateApprovalSnackbar();
}

function openApprovalRequestModal() {
  const reasonSelect = document.getElementById('approval-reason');
  const reasonError = document.getElementById('approval-reason-error');
  const justificationInput = document.getElementById('approval-justification');
  const justificationError = document.getElementById('approval-justification-error');
  const uploadInput = document.getElementById('approval-upload-input');
  const uploadFileName = document.getElementById('approval-upload-filename');

  if (reasonSelect) {
    reasonSelect.value = '';
    reasonSelect.classList.remove('input--error');
  }
  if (reasonError) reasonError.classList.add('hidden');
  if (justificationInput) justificationInput.value = '';
  justificationInput?.closest('.textarea-field')?.classList.remove('textarea-field--error');
  if (justificationError) justificationError.classList.add('hidden');
  if (uploadInput) uploadInput.value = '';
  if (uploadFileName) {
    uploadFileName.textContent = '';
    uploadFileName.classList.add('hidden');
  }

  updateApprovalRequestSubmitState();
  const overlay = document.getElementById('approval-request-overlay');
  if (!overlay) return;
  overlay.classList.add('is-open');
  document.body.style.overflow = 'hidden';
}

function closeApprovalRequestModal() {
  const overlay = document.getElementById('approval-request-overlay');
  if (!overlay) return;
  overlay.classList.remove('is-open');
  document.body.style.overflow = '';
}

function updateApprovalRequestSubmitState() {
  const reason = document.getElementById('approval-reason')?.value || '';
  const reasonSelect = document.getElementById('approval-reason');
  const justification = document.getElementById('approval-justification')?.value.trim() || '';
  const submitBtn = document.getElementById('approval-submit-btn');
  const reasonError = document.getElementById('approval-reason-error');
  const justificationError = document.getElementById('approval-justification-error');

  if (reasonError && reason) reasonError.classList.add('hidden');
  if (justificationError && justification) justificationError.classList.add('hidden');
  if (reasonSelect && reason) reasonSelect.classList.remove('input--error');
  if (justification && document.getElementById('approval-justification')) {
    document.getElementById('approval-justification').closest('.textarea-field')?.classList.remove('textarea-field--error');
  }
  if (submitBtn) submitBtn.disabled = !reason || !justification;
}

function triggerApprovalUpload() {
  document.getElementById('approval-upload-input')?.click();
}

function handleApprovalUploadChange(input) {
  const fileNameEl = document.getElementById('approval-upload-filename');
  const fileName = input?.files?.[0]?.name || '';
  if (!fileNameEl) return;
  if (!fileName) {
    fileNameEl.classList.add('hidden');
    fileNameEl.textContent = '';
    return;
  }
  fileNameEl.textContent = `Attached: ${fileName}`;
  fileNameEl.classList.remove('hidden');
}

function submitApprovalRequest() {
  const reason = document.getElementById('approval-reason')?.value || '';
  const justification = document.getElementById('approval-justification')?.value.trim() || '';
  const reasonError = document.getElementById('approval-reason-error');
  const justificationError = document.getElementById('approval-justification-error');

  let hasError = false;
  if (!reason) {
    if (reasonError) reasonError.classList.remove('hidden');
    document.getElementById('approval-reason')?.classList.add('input--error');
    hasError = true;
  }
  if (!justification) {
    if (justificationError) justificationError.classList.remove('hidden');
    document.getElementById('approval-justification')?.closest('.textarea-field')?.classList.add('textarea-field--error');
    hasError = true;
  }
  if (hasError) {
    if (!reason) {
      document.getElementById('approval-reason')?.focus();
    } else {
      document.getElementById('approval-justification')?.focus();
    }
    return;
  }

  const { role } = getApprovalDetails();
  const fileName = document.getElementById('approval-upload-input')?.files?.[0]?.name || null;
  const now = new Date();
  const dateFormatted = now.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  const timeFormatted = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
  const submittedAt = `${dateFormatted} ${timeFormatted}`;
  const reqId = `APR-${now.getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;

  proposalData.approvalStatus = 'Pending';
  proposalData.approvalRequest = {
    id: reqId,
    submittedAt,
    timestamp: now.toISOString(),
    role,
    reason,
    justification,
    attachedFile: fileName
  };

  closeApprovalRequestModal();
  updateApprovalSnackbar();
  renderOptPromoDrawer();
  renderOptions();
  if (screen === 'selection') renderSelectionOptions();
  showSuccessBanner('Approval request submitted', `Request #${reqId} submitted for ${role} review.`);
}

function getApprovalRole(skip) {
  if (skip === 1) return 'Associate Director';
  if (skip >= 2) return 'Director';
  return 'System';
}
