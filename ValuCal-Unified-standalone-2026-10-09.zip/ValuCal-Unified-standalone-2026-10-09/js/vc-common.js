/* ── Common helpers (shared, 2026-10-07) ──────────────────────────────────────────
   Modals open/close, waves, seasonal, proposal history, account validation, nav dates, drawer helpers, banners.
   Moved verbatim from Initial Sales and Existing Accounts, where they were identical (no behavior change).
   They use each flow's own globals (options, proposalData, screen, bld…) at call time. */
function formatHistoryTimestamp(dateObj) {
  const d = dateObj instanceof Date ? dateObj : new Date(dateObj);
  return d.toLocaleString();
}

function logProposalEvent(title, description = '') {
  proposalHistoryEvents.push({
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    title,
    description,
    at: new Date()
  });
}

function getHistoryPhaseForEvent(evt) {
  const t = String(evt?.title || '').toLowerCase();
  if (
    t.includes('option') ||
    t.includes('proposal') ||
    t.includes('review & send') ||
    t.includes('review and send') ||
    t.includes('send proposal')
  ) return 'Proposal';
  if (
    t.includes('contract') ||
    t.includes('payment setup') ||
    t.includes('signature')
  ) return 'Contract';
  if (t.includes('deal result') || t.includes('closed-lost') || t.includes('closed won')) return 'Deal Result';
  return 'Other';
}

function renderProposalHistory() {
  const list = document.getElementById('proposal-history-list');
  if (!list) return;
  if (!proposalHistoryEvents.length) {
    list.innerHTML = '<div class="proposal-history-empty">No events yet.</div>';
    return;
  }
  const sorted = proposalHistoryEvents.slice().reverse();
  const grouped = sorted.reduce((acc, evt) => {
    const phase = getHistoryPhaseForEvent(evt);
    if (!acc[phase]) acc[phase] = [];
    acc[phase].push(evt);
    return acc;
  }, {});

  list.innerHTML = HISTORY_PHASE_ORDER
    .filter((phase) => Array.isArray(grouped[phase]) && grouped[phase].length > 0)
    .map((phase) => `
      <section class="proposal-history-phase">
        <div class="proposal-history-phase-title">${phase}</div>
        ${grouped[phase].map((evt) => `
          <div class="proposal-history-item">
            <div class="proposal-history-title">${evt.title}</div>
            ${evt.description ? `<div class="proposal-history-sub">${evt.description}</div>` : ''}
            <div class="proposal-history-date">${formatHistoryTimestamp(evt.at)}</div>
          </div>
        `).join('')}
      </section>
    `)
    .join('');
}

function openProposalHistoryModal() {
  renderProposalHistory();
  const overlay = document.getElementById('proposal-history-overlay');
  if (!overlay) return;
  overlay.classList.add('is-open');
  document.body.style.overflow = 'hidden';
}

function closeProposalHistoryModal() {
  const overlay = document.getElementById('proposal-history-overlay');
  if (!overlay) return;
  overlay.classList.remove('is-open');
  document.body.style.overflow = '';
}

function getAccountValidationDescriptors() {
  const cl = accountValidationState.clId || { status: 'no-match', matches: 0 };
  const billing = accountValidationState.billingAddress || { status: 'invalid' };
  const ecs = accountValidationState.ecsCompliance || { status: 'pending' };

  const clText = requestedNewGch
    ? '⟳ Request submitted'
    : cl.status === 'assigned'
    ? '✓ Assigned'
    : cl.status === 'low-confidence'
      ? `⚠ Low confidence (${Math.max(1, Number(cl.matches) || 1)} matches)`
      : '✗ No match';
  const clVariant = requestedNewGch ? 'pending' : (cl.status === 'assigned' ? 'ok' : (cl.status === 'low-confidence' ? 'pending' : 'error'));

  const billingText = billing.status === 'valid' ? '✓ Valid' : '✗ Invalid or missing';
  const billingVariant = billing.status === 'valid' ? 'ok' : 'error';

  const ecsText = ecs.status === 'ok'
    ? '✓ OK'
    : ecs.status === 'running'
      ? '⟳ Running'
      : '⚠ Pending';
  const ecsVariant = ecs.status === 'ok' ? 'ok' : 'pending';

  const clPending = cl.status === 'low-confidence' ? (!selectedClIdCompany && !requestedNewGch) : cl.status !== 'assigned';

  return [
    { key: 'clid', text: clText, variant: clVariant, pending: clPending },
    { key: 'billing', text: billingText, variant: billingVariant, pending: billing.status !== 'valid' },
    { key: 'ecs', text: ecsText, variant: ecsVariant, pending: ecs.status !== 'ok' },
  ];
}

function renderAccountValidationScreen() {
  const descriptors = getAccountValidationDescriptors();
  descriptors.forEach((item) => {
    const textEl = document.getElementById(`account-val-${item.key}-text`);
    const chipEl = document.getElementById(`account-val-${item.key}-chip`);
    if (textEl) textEl.textContent = item.text;
    if (chipEl) {
      chipEl.className = `account-validation-chip ${item.variant}`;
      chipEl.textContent = item.pending ? 'Pending' : 'Complete';
    }
  });

  const clIdOptionsWrap = document.getElementById('account-val-clid-options');
  if (clIdOptionsWrap) {
    clIdOptionsWrap.innerHTML = clIdCompanyMatches.map((company) => `
      <label class="account-validation-option-item">
        <input
          type="radio"
          class="radio__input"
          name="account-validation-clid-company"
          value="${company.id}"
          ${selectedClIdCompany === company.id ? 'checked' : ''}
          ${requestedNewGch ? 'disabled' : ''}
          onchange="selectClIdCompany('${company.id}')"
        >
        <span>
          <strong>${company.name}</strong><br>
          <span>${company.detail}</span><br>
          <span><strong>CLE ID:</strong> ${company.cleId}</span>
        </span>
      </label>
    `).join('');
  }

  const continueBtn = document.getElementById('account-val-continue-btn');
  if (continueBtn) {
    const mustSelectClId = accountValidationState.clId?.status === 'low-confidence';
    continueBtn.disabled = mustSelectClId && !selectedClIdCompany;
  }

  const gchRequestBtn = document.getElementById('gch-request-btn');
  if (gchRequestBtn) {
    gchRequestBtn.classList.toggle('active', requestedNewGch);
    gchRequestBtn.textContent = requestedNewGch ? 'Requested' : 'Request New';
  }

  const checklistTitleEl = document.getElementById('account-validation-checklist-title');
  const gchResolved = !(accountValidationState.clId?.status === 'low-confidence' && !selectedClIdCompany);
  const pendingCount = gchResolved ? 0 : 1;
  if (checklistTitleEl) {
    checklistTitleEl.textContent = `Action Items (Pending: ${pendingCount})`;
  }

  const gchPanel = document.getElementById('gch-pending-panel');
  const gchCaret = document.getElementById('gch-pending-caret');
  if (gchPanel && gchCaret) {
    gchPanel.classList.toggle('hidden', !gchPendingAccordionOpen);
    gchCaret.textContent = gchPendingAccordionOpen ? 'expand_less' : 'expand_more';
  }
}

function selectClIdCompany(companyId) {
  selectedClIdCompany = companyId;
  requestedNewGch = false;
  renderAccountValidationScreen();
  updateAccountBadgeFromValidation();
}

function updateAccountBadgeFromValidation() {
  const badge = document.getElementById('account-badge');
  if (!badge) return;
  const pendingCount = ['gch', 'billingAddress'].filter((key) => validationFields[key] && validationFields[key].status !== 'complete').length;
  if (pendingCount === 0) {
    badge.className = 'badge-ready';
    badge.textContent = 'Account ready';
  } else {
    badge.className = 'badge-pending';
    badge.textContent = `${pendingCount} pending action${pendingCount === 1 ? '' : 's'}`;
  }
}

function openAccountValidationScreen() {
  renderValidationPageStatus();
  renderAccountValidationScreen();
  updateAccountBadgeFromValidation();
  const overlay = document.getElementById('account-validation-overlay');
  if (!overlay) return;
  overlay.classList.add('is-open');
  document.body.style.overflow = 'hidden';
}

function closeAccountValidationModal() {
  const overlay = document.getElementById('account-validation-overlay');
  if (overlay) overlay.classList.remove('is-open');
  document.body.style.overflow = '';
}

function getValidationChipClass(status) {
  if (status === 'complete') return 'state-ok';
  if (status === 'pending-confirmation') return 'state-ok';
  return 'state-error';
}

function getValidationChipText(field, status) {
  if (status === 'complete') return `${field.label} ✓`;
  if (status === 'pending-confirmation') return `${field.label} ✓`;
  return `${field.label} ✕`;
}

function toggleValidationSection(sectionKey) {
  if (!Object.prototype.hasOwnProperty.call(validationSectionOpen, sectionKey)) return;
  validationSectionOpen[sectionKey] = !validationSectionOpen[sectionKey];
  renderValidationPageStatus();
}

function resolveValidationAction(fieldKey) {
  if (fieldKey === 'gch') {
    openGchSubview();
    return;
  }
  if (!validationFields[fieldKey]) return;
  validationFields[fieldKey].status = 'complete';
  renderValidationPageStatus();
}

function openGchSubview() {
  const subview = document.getElementById('gch-subview');
  const mainCard = document.getElementById('account-validation-main-card');
  const footer = document.querySelector('.account-validation-actions');
  if (!subview || !mainCard) return;
  const radios = subview.querySelectorAll('input[name="gch-selection"]');
  radios.forEach(r => r.checked = false);
  subview.classList.remove('hidden');
  mainCard.classList.add('hidden');
  if (footer) footer.classList.add('hidden');
}

function closeGchSubview() {
  const subview = document.getElementById('gch-subview');
  const mainCard = document.getElementById('account-validation-main-card');
  const footer = document.querySelector('.account-validation-actions');
  if (!subview || !mainCard) return;
  subview.classList.add('hidden');
  mainCard.classList.remove('hidden');
  if (footer) footer.classList.remove('hidden');
}

function requestNewGch() {
  const valueEl = document.querySelector('#validation-field-gch .account-validation-row-value');
  if (valueEl) valueEl.textContent = 'New GCH review requested';
  validationFields.gch.status = 'complete';
  closeGchSubview();
  renderValidationPageStatus();
}

function enterValidationFieldEdit(fieldKey) {
  const row = document.getElementById(`validation-field-${fieldKey}`);
  if (!row || !row.classList.contains('av-editable')) return;
  const displayEl = row.querySelector('[data-display]');
  const inputEl = row.querySelector('[data-input]');
  if (!displayEl || !inputEl || !inputEl.classList.contains('hidden') === false) return;
  displayEl.classList.add('hidden');
  inputEl.classList.remove('hidden');
  inputEl.focus();
  if (inputEl.select) inputEl.select();
}

function onValidationFieldKeydown(event, fieldKey) {
  if (event.key === 'Enter') {
    event.preventDefault();
    commitValidationFieldEdit(fieldKey);
  }
}

function getMsaMonthsRemaining() {
  if (!proposalData.msaEndDate) return null;
  const end = new Date(proposalData.msaEndDate + 'T00:00:00');
  const now = new Date();
  return Math.max(1, Math.round((end - now) / (1000 * 60 * 60 * 24 * 30.44)));
}

function isMsaAutoExtend() {
  const rem = getMsaMonthsRemaining();
  return rem !== null && rem <= 6;
}

function getMsaDiscountTier(fleetSize) {
  const idx = MSA_DISCOUNT_TIERS.findIndex(t => fleetSize >= t.min && fleetSize <= t.max);
  return MSA_DISCOUNT_TIERS[idx === -1 ? 0 : idx];
}

function getMsaNaturalTierIndex(fleetSize) {
  const idx = MSA_DISCOUNT_TIERS.findIndex(t => fleetSize >= t.min && fleetSize <= t.max);
  return idx === -1 ? 0 : idx;
}

function getMsaSelectedTierIndex(pct) {
  const idx = MSA_DISCOUNT_TIERS.findIndex(t => pct >= t.minPct && pct <= t.maxPct);
  return idx === -1 ? 0 : idx;
}

function toggleOptTermDropdown(optId, event) {
  event.stopPropagation();
  document.querySelectorAll('[id^="opt-term-dd-"]').forEach(el => {
    if (el.id !== `opt-term-dd-${optId}`) el.classList.add('hidden');
  });
  document.getElementById(`opt-term-dd-${optId}`)?.classList.toggle('hidden');
}

function toggleOptionCardMenu(optId, event) {
  event.stopPropagation();
  const targetMenuId = `opt-card-menu-${optId}`;
  const targetMenu = document.getElementById(targetMenuId);
  const willOpen = !!targetMenu?.classList.contains('hidden');
  document.querySelectorAll('[id^="opt-card-menu-"]').forEach(menu => {
    const isOpen = menu.id === targetMenuId && willOpen;
    menu.classList.toggle('hidden', !isOpen);
    menu.closest('.kebab-menu')?.querySelector('.btn-icon')?.setAttribute('aria-expanded', String(isOpen));
  });
}

function selectOptTerm(optId, val) {
  document.getElementById(`opt-term-dd-${optId}`)?.classList.add('hidden');
  updateTerm(optId, val);
}

function getGroupsByCore(opt, coreKeys) {
  const map = {};
  coreKeys.forEach(ck => { map[ck] = opt.bundles.filter(b => b.coreKey === ck); });
  return map;
}

function getPromoNameCandidatesForCore(coreKey, term) {
  const types = PROMOS.filter(p => !p.videoOnly || isVideoCore(coreKey)).map(p => p.key);
  const candidates = [];
  types.forEach(promoType => {
    getEligiblePromoNamesForTerm(promoType, term).forEach(promoName => {
      candidates.push({ promoType, promoName });
    });
  });
  return candidates;
}

function getOptionPromoPackages(opt, coreKeys, groupsByCore, msaTierUnits) {
  let combos = [{}];
  coreKeys.forEach(ck => {
    const candidates = [{ promoType: 'Standard', promoName: '' }, ...getPromoNameCandidatesForCore(ck, opt.term)];
    const next = [];
    combos.forEach(partial => { candidates.forEach(cand => { next.push({ ...partial, [ck]: cand }); }); });
    combos = next;
  });

  // Exclude the combo where all cores are default "Standard" (no promotion)
  const promoCombos = combos.filter(combo =>
    coreKeys.some(ck => combo[ck] && (combo[ck].promoName || combo[ck].promoType !== 'Standard'))
  );

  const scored = promoCombos.map(combo => {
    let totalMonthly = 0;
    coreKeys.forEach(ck => {
      const { promoType, promoName } = combo[ck];
      groupsByCore[ck].forEach(b => {
        const draftBundle = { ...b, promoType, promoName, dealCloser: '' };
        const { monthly } = calcBundle(draftBundle, opt.term, promoType, msaTierUnits);
        totalMonthly += monthly;
      });
    });
    return { combo, totalMonthly };
  });
  scored.sort((a, b) => a.totalMonthly - b.totalMonthly);

  const packages = [];
  scored.forEach(s => {
    if (packages.length >= 3) return;
    const isDup = packages.some(p => Math.abs(p.totalMonthly - s.totalMonthly) < 0.01);
    if (!isDup) packages.push(s);
  });

  return packages;
}

function findMatchingPackageIndex(combo, dealClosers, coreKeys, packages) {
  const anyDealCloser = coreKeys.some(ck => !!dealClosers[ck]);
  if (anyDealCloser) return -1;
  return packages.findIndex(pkg =>
    coreKeys.every(ck => pkg.combo[ck].promoName === combo[ck].promoName && pkg.combo[ck].promoType === combo[ck].promoType));
}

function calcComboMonthly(opt, coreKeys, groupsByCore, combo, dealClosers, msaTierUnits) {
  let totalMonthly = 0;
  coreKeys.forEach(ck => {
    groupsByCore[ck].forEach(b => {
      const draftBundle = { ...b, promoType: combo[ck].promoType, promoName: combo[ck].promoName, dealCloser: dealClosers[ck] || '' };
      const { monthly } = calcBundle(draftBundle, opt.term, combo[ck].promoType, msaTierUnits);
      totalMonthly += monthly;
    });
  });
  return totalMonthly;
}

function resolveSelectionForCombo(opt, coreKeys, groupsByCore, packages, combo, dealClosers, msaTierUnits) {
  const matchIndex = findMatchingPackageIndex(combo, dealClosers, coreKeys, packages);
  if (matchIndex !== -1) return { selectedKey: matchIndex, customEntry: null };
  const isAllDefault = coreKeys.every(ck => !combo[ck].promoName && combo[ck].promoType === 'Standard' && !dealClosers[ck]);
  if (isAllDefault) return { selectedKey: null, customEntry: null };
  const totalMonthly = calcComboMonthly(opt, coreKeys, groupsByCore, combo, dealClosers, msaTierUnits);
  return { selectedKey: 'custom', customEntry: { combo, dealClosers, totalMonthly } };
}

function getSelectedPromoCombo(draft) {
  if (!draft) return null;
  if (draft.mode === 'custom') return draft.custom;
  if (draft.selectedKey === 'custom' && draft.customEntry) {
    const out = {};
    draft.coreKeys.forEach(ck => { out[ck] = { ...draft.customEntry.combo[ck], dealCloser: draft.customEntry.dealClosers[ck] || '' }; });
    return out;
  }
  const pkg = draft.packages[draft.selectedKey];
  if (!pkg) return null;
  const out = {};
  draft.coreKeys.forEach(ck => { out[ck] = { ...pkg.combo[ck], dealCloser: '' }; });
  return out;
}

function setOptPromoDrawerMode(optId, mode) {
  if (!optPromoDraft) return;
  if (mode === 'packages') {
    // Leaving "Build my own" — recompute which package (if any) the edited
    // values now match, so the list doesn't show a stale selection.
    const opt = options.find(o => o.id === optId);
    if (opt) {
      const { coreKeys, packages } = optPromoDraft;
      const groupsByCore = getGroupsByCore(opt, coreKeys);
      const { msaTierUnits } = calcOption(opt, getOptionPromotion(opt));
      const combo = {}, dealClosers = {};
      coreKeys.forEach(ck => {
        combo[ck] = { promoType: optPromoDraft.custom[ck].promoType, promoName: optPromoDraft.custom[ck].promoName };
        dealClosers[ck] = optPromoDraft.custom[ck].dealCloser || '';
      });
      const resolved = resolveSelectionForCombo(opt, coreKeys, groupsByCore, packages, combo, dealClosers, msaTierUnits);
      optPromoDraft.selectedKey = resolved.selectedKey;
      optPromoDraft.customEntry = resolved.customEntry;
    }
  }
  optPromoDraft.mode = mode;
  renderOptPromoDrawer();
  renderOptions();
  if (screen === 'selection') renderSelectionOptions();
}

function setOptPromoDrawerTitle(title, sub) {
  const titleEl = document.getElementById('opt-promo-drawer-title');
  const subEl = document.getElementById('opt-promo-drawer-sub');
  if (titleEl) titleEl.textContent = title;
  if (subEl) subEl.textContent = sub || '';
}

function setMatrixDrawerTab(tab) {
  matrixDrawerTab = tab === 'contract' ? 'contract' : 'order';
  renderOptPromoDrawer();
}

function buildDrawerListHeaderHtml(title, hasSelection, clearOnclick) {
  if (!hasSelection) return '';
  return `<div class="discount-matrix-list-header"><button type="button" class="text-link text-link--small discount-matrix-clear-link" onclick="${clearOnclick}">Clear selection</button></div>`;
}

function eligibleComponentsCountForCore(coreKey) {
  if (coreKey === 'vtu') return 1;
  if (coreKey === 'vtu-ffc' || coreKey === 'vtu-dual') return 2;
  return 0;
}

function applyOptionFocusMode() {
  const grid = document.getElementById('options-grid');
  const addCardEl = grid ? grid.querySelector('.add-option-card') : null;
  document.querySelectorAll('.option-card').forEach(cardEl => {
    cardEl.classList.remove('opt-promo-focus-card');
    cardEl.style.display = '';
  });
  if (addCardEl) addCardEl.style.display = '';
}

function getEligiblePromoNamesForTerm(promoType, term) {
  const allNames = PROMO_NAME_OPTIONS_BY_TYPE[promoType] || [];
  return allNames.filter((name) => getPromoCodeTermMonths(name) === parseInt(term, 10));
}

function buildCustomPromoNameRows(opt, coreKey, currentPromoName) {
  const candidates = getPromoNameCandidatesForCore(coreKey, opt.term);
  const noneRow = `<div class="dropdown-option ${!currentPromoName ?'selected' : ''}" onclick="setCustomPromoName(${opt.id}, '${coreKey}', 'Standard', '')">None</div>`;
  if (!candidates.length) return noneRow;
  const rows = candidates.map(c => `<div class="dropdown-option ${currentPromoName === c.promoName ?'selected' : ''}" onclick="setCustomPromoName(${opt.id}, '${coreKey}', '${c.promoType}', '${c.promoName}')">${c.promoName}</div>`).join('');
  return noneRow + rows;
}

function toggleCustomPromoNameDropdown(optId, coreKey, event) {
  event.stopPropagation();
  const targetId = `opt-promo-name-dd-${optId}-${coreKey}`;
  document.querySelectorAll('[id^="opt-promo-name-dd-"]').forEach(el => { if (el.id !== targetId) el.classList.add('hidden'); });
  document.getElementById(targetId)?.classList.toggle('hidden');
}

function setCustomPromoName(optId, coreKey, promoType, promoName) {
  if (!optPromoDraft || !optPromoDraft.custom[coreKey]) return;
  optPromoDraft.custom[coreKey].promoType = promoType;
  optPromoDraft.custom[coreKey].promoName = promoName;
  renderOptPromoDrawer();
  renderOptions();
  if (screen === 'selection') renderSelectionOptions();
}

function buildCustomDealCloserRows(opt, coreKey, currentDealCloser) {
  const opts = getDealCloserOptionsForCore(coreKey);
  const noneRow = `<div class="dropdown-option ${!currentDealCloser ?'selected' : ''}" onclick="setCustomDealCloser(${opt.id}, '${coreKey}', '')">None</div>`;
  if (!opts.length) return noneRow;
  const rows = opts.map(dc => `<div class="dropdown-option ${currentDealCloser === dc ?'selected' : ''}" onclick="setCustomDealCloser(${opt.id}, '${coreKey}', '${dc}')">${dc}</div>`).join('');
  return noneRow + rows;
}

function toggleCustomDealCloserDropdown(optId, coreKey, event) {
  event.stopPropagation();
  const targetId = `opt-deal-closer-dd-${optId}-${coreKey}`;
  document.querySelectorAll('[id^="opt-deal-closer-dd-"]').forEach(el => { if (el.id !== targetId) el.classList.add('hidden'); });
  document.getElementById(targetId)?.classList.toggle('hidden');
}

function setCustomDealCloser(optId, coreKey, value) {
  if (!optPromoDraft || !optPromoDraft.custom[coreKey]) return;
  optPromoDraft.custom[coreKey].dealCloser = value;
  renderOptPromoDrawer();
  renderOptions();
  if (screen === 'selection') renderSelectionOptions();
}

function closeMarkDeadModal() {
  document.getElementById('mark-dead-overlay').classList.remove('is-open');
  document.getElementById('dead-reason-select').value = '';
  updateMarkDeadConfirmBtn();
}

function renderMsaContextBar() {
  const bar = document.getElementById('msa-context-bar');
  if (!bar) return;
  if (!proposalData.isAddOn) { bar.innerHTML = ''; return; }

  const rem = getMsaMonthsRemaining();
  const autoExtend = isMsaAutoExtend();
  const isGov = proposalData.segment === 'Government';

  const endDisplay = proposalData.msaEndDate
    ? new Date(proposalData.msaEndDate + 'T00:00:00').toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
    : '—';

  let chips = '';
  if (autoExtend && !isGov) {
    chips += `<span class="badge badge--yellow"><span class="material-symbols-outlined" style="font-size:13px;">autorenew</span> Auto-extend will apply</span>`;
  }
  if (isGov) {
    chips += `<span class="badge badge--gray-low"><span class="material-symbols-outlined" style="font-size:12px;">account_balance</span> Gov — separate contract terms apply</span>`;
  }

  bar.innerHTML = `
    <div class="msa-context-bar">
      <span class="material-symbols-outlined" style="font-size:16px; flex-shrink:0;">handshake</span>
      <span>Add-on to <span class="msa-bar-id">${proposalData.msaId}</span></span>
      <span class="msa-bar-sep">|</span>
      <span>MSA expires <strong>${endDisplay}</strong></span>
      ${rem !== null && !isGov ? `<span class="msa-bar-sep">|</span><span><strong>${rem}</strong> months remaining${autoExtend ? '' : ' — co-term applied'}</span>` : ''}
      ${chips}
    </div>`;
}

function navToday() {
  return formatUsDate(new Date());
}

function touchNavDate(key, overwrite = false) {
  if (!key) return;
  window._navDates = window._navDates || {};
  if (overwrite || !window._navDates[key]) window._navDates[key] = navToday();
}

function touchCurrentStepDates() {
  touchNavDate('proposal_drafting');
  if (screen === 'review') {
    touchNavDate('proposal_review');
  } else if (screen === 'selection') {
    touchNavDate('proposal_selection');
  } else if (screen === 'contract-review') {
    if (contractSubState === 'pre-send' || contractSubState === 'waiting') {
      touchNavDate('contract_review_send');
    } else {
      touchNavDate('contract_sign_pay');
    }
  } else if (screen === 'deal-result') {
    touchNavDate('result');
  }
}

function updateReviewBackToSelectionHint() {
  const btn = document.getElementById('btn-skip-to-selection');
  if (!btn) return;
  const canSkip = screen === 'review';
  btn.classList.toggle('hidden', !canSkip);
  btn.disabled = !canSkip;
}

function returnToOptionSelectionFromReview() {
  if (screen !== 'review') return;
  hideQuoteCreatedState();
  screen = 'selection';
  hideProposalReviewModal();
  document.getElementById('screen-drafting').classList.add('hidden');
  document.getElementById('screen-proposal-selection').classList.remove('hidden');
  const sendBtn = document.getElementById('footer-send');
  sendBtn.innerText = 'Select Winning Option';
  sendBtn.classList.add('hidden');
  sendBtn.disabled = true;
  const d2 = document.getElementById('substep-dot-2');
  const d3 = document.getElementById('substep-dot-3');
  const l2 = document.getElementById('substep-line-2');
  const l3 = document.getElementById('substep-label-3');
  if (d2) d2.className = 'prop-step-dot done';
  if (d3) d3.className = 'prop-step-dot active';
  if (l2) l2.className = 'prop-line done';
  if (l3) l3.classList.remove('muted');
  document.getElementById('footer-back')?.classList.remove('hidden');
  document.getElementById('footer-back')?.classList.add('visible');
  renderSelectionOptions();
  updateMarkDeadBtn();
  updateSendBtn();
  renderNav();
}

function closeSimulationBuilderModal() {
  document.getElementById('simulation-builder-modal-overlay')?.classList.remove('open');
}

function cancelInlineDraftTitleEdit() {
  const titleEl = document.getElementById('drafting-header-title');
  const wrapEl  = document.getElementById('drafting-title-input-wrap');
  if (!titleEl || !wrapEl) return;

  inlineDraftTitleEditActive = false;
  wrapEl.style.display = 'none';
  titleEl.classList.remove('hidden');
  const editBtn = document.getElementById('drafting-title-edit-btn');
  if (editBtn) editBtn.style.display = '';
  updateDraftingHeaderTitle();
}

function saveInlineDraftTitleEdit() {
  if (!inlineDraftTitleEditActive) return;
  const titleEl = document.getElementById('drafting-header-title');
  const wrapEl  = document.getElementById('drafting-title-input-wrap');
  const inputEl = document.getElementById('drafting-header-title-input');
  if (!titleEl || !inputEl || !wrapEl) return;

  const nextName = (inputEl.value || '').trim();
  const quoteRef = (proposalData && proposalData.quoteReference ? proposalData.quoteReference : '').trim();
  if (nextName) {
    proposalData.name = nextName;
    proposalData.hasCustomName = quoteRef ? nextName !== quoteRef : nextName !== 'New Proposal';
  }

  inlineDraftTitleEditActive = false;
  wrapEl.style.display = 'none';
  titleEl.classList.remove('hidden');
  const editBtn = document.getElementById('drafting-title-edit-btn');
  if (editBtn) editBtn.style.display = '';
  updateDraftingHeaderTitle();
}

function handleInlineDraftTitleKeydown(event) {
  if (!event) return;
  if (event.key === 'Enter') {
    event.preventDefault();
    saveInlineDraftTitleEdit();
    return;
  }
  if (event.key === 'Escape') {
    event.preventDefault();
    cancelInlineDraftTitleEdit();
  }
}

function showSuccessBanner(title, sub) {
  if (bannerTimer) clearTimeout(bannerTimer);
  document.getElementById('success-title').innerText = title;
  document.getElementById('success-sub').innerText = sub;
  document.getElementById('success-banner').classList.remove('hidden');
  document.getElementById('vc-body').classList.add('has-banner');
  window.scrollTo({ top: 0, behavior: 'smooth' });
  bannerTimer = setTimeout(dismissSuccessBanner, 4500);
}

function showNotif(title, sub) {
  showSuccessBanner(title, sub);
}

function toggleSidebar(open) {
  VC.setNavigationDrawerOpen(open);
}

function openCaseStudiesPage(event) {
  if (event) event.preventDefault();
  toggleSidebar(false);
  openCaseStudiesModal();
}

function openResourcesPage(event) {
  if (event) event.preventDefault();
  toggleSidebar(false);
  openResourcesModal();
}

function closeCaseStudiesModal() {
  const overlay = document.getElementById('case-studies-overlay');
  if (!overlay) return;
  overlay.classList.remove('is-open');
  document.body.style.overflow = '';
}

function openResourcesModal() {
  const overlay = document.getElementById('resources-overlay');
  const frame = document.getElementById('resources-frame');
  if (!overlay || !frame) return;
  if (frame.getAttribute('src') === 'about:blank') {
    frame.setAttribute('src', 'resources/valuCalResources.html');
  }
  overlay.classList.add('is-open');
  document.body.style.overflow = 'hidden';
}

function closeResourcesModal() {
  const overlay = document.getElementById('resources-overlay');
  if (!overlay) return;
  overlay.classList.remove('is-open');
  document.body.style.overflow = '';
}

function closeAccountSetupEmbed() {
  const overlay = document.getElementById('account-setup-embed-overlay');
  if (!overlay) return;
  overlay.classList.remove('is-open');
  document.body.style.overflow = '';
}

function closeBundleModal() { document.getElementById('bundle-overlay').classList.remove('is-open'); }

function scorePlanFinderTier(row) {
  const featureKeys = getPrebuiltTierFeatureKeys(row.tier).filter(f => f !== 'sd-256');
  const selected = planFinder.features;
  const overlap = featureKeys.filter(f => selected.includes(f)).length;
  const missing = selected.filter(f => !featureKeys.includes(f)).length;
  const extra = featureKeys.filter(f => !selected.includes(f)).length;
  const coreMatch = row.tier.coreKey === planFinder.coreKey;
  const exact = coreMatch && missing === 0 && extra === 0 && selected.length > 0;
  return { ...row, overlap, missing, extra, coreMatch, exact };
}

function getSelectedEvcType() {
  const el = document.getElementById('evc-type-select');
  return el ? el.value : 'sides-rear-cargo';
}

function updateSeasonalPill() {
  const toMonthShort = (month) => {
    if (!month || typeof month !== 'string') return '';
    const clean = month.trim();
    if (!clean) return '';
    return clean.slice(0, 3);
  };
  const slots = [
    document.getElementById('seasonal-pill-slot'),
    document.getElementById('seasonal-pill-slot-drafting')
  ].filter(Boolean);
  if (!slots.length) return;
  const { startMonth, endMonth } = seasonalConfig || {};
  if (!startMonth || !endMonth) {
    slots.forEach((slot) => {
      slot.classList.add('hidden');
      slot.innerHTML = '';
    });
    return;
  }
  slots.forEach((slot) => {
    slot.classList.remove('hidden');
    const startShort = toMonthShort(startMonth);
    const endShort = toMonthShort(endMonth);
    slot.innerHTML = `<span class="seasonal-badge"><span class="badge badge--blue">Seasonal: ${startShort}-${endShort}</span><button type="button" class="btn-icon btn-icon--ghost-vds btn-icon--vds-small" aria-label="Remove seasonal billing" title="Remove seasonal billing" onclick="clearSeasonalConfig(event)"><span class="material-symbols-outlined">close</span></button></span>`;
  });
}

function openSeasonalModal() {
  document.getElementById('more-menu-draft')?.classList.add('hidden');
  document.getElementById('draft-more-btn')?.setAttribute('aria-expanded', 'false');
  const startSel = document.getElementById('seasonal-start-month');
  const endSel = document.getElementById('seasonal-end-month');
  if (startSel && seasonalConfig.startMonth) startSel.value = seasonalConfig.startMonth;
  if (endSel && seasonalConfig.endMonth) endSel.value = seasonalConfig.endMonth;
  document.getElementById('seasonal-modal')?.classList.add('is-open');
}

function closeSeasonalModal() {
  document.getElementById('seasonal-modal')?.classList.remove('is-open');
}

function applySeasonalConfig() {
  const startMonth = document.getElementById('seasonal-start-month')?.value || '';
  const endMonth = document.getElementById('seasonal-end-month')?.value || '';
  seasonalConfig = { startMonth, endMonth };
  closeSeasonalModal();
  updateSeasonalPill();
  showNotif('Seasonal billing configured', `Active months: ${startMonth} to ${endMonth}.`);
}

function clearSeasonalConfig(event) {
  if (event) {
    event.preventDefault();
    event.stopPropagation();
  }
  seasonalConfig = { startMonth: '', endMonth: '' };
  updateSeasonalPill();
  showNotif('Seasonal billing removed', 'Seasonal billing window was cleared.');
}

function updateOptionsGridAlignment() {
  const grid = document.getElementById('options-grid');
  if (!grid) return;
  const hasOverflow = grid.scrollWidth > grid.clientWidth + 1;
  grid.classList.toggle('options-grid--has-overflow', hasOverflow);
}

function getVcmiContextLabel() {
  const contractType = (proposalData.contractType || 'Flex').toLowerCase();
  return contractType === 'fixed'
    ? 'CMI edit at order level (Fixed)'
    : 'CMI edit in bundle (Flex)';
}

function enterProposalMetaEdit(fieldKey) {
  if (fieldKey !== 'close-date') return;
  const field = document.getElementById('proposal-close-date-field');
  const display = document.getElementById('header-prop-close-date-display');
  const input = document.getElementById('header-prop-close-date-input');
  if (!field || !display || !input) return;
  field.classList.add('is-editing');
  display.classList.add('hidden');
  input.classList.remove('hidden');
  input.focus();
}

function saveProposalMetaField(fieldKey) {
  if (fieldKey !== 'close-date') return;
  const field = document.getElementById('proposal-close-date-field');
  const display = document.getElementById('header-prop-close-date-display');
  const input = document.getElementById('header-prop-close-date-input');
  if (!field || !display || !input) return;
  const parsed = parseProposalDate(input.value);
  proposalData.closeDate = parsed ? toIsoDate(parsed) : getLastDayOfCurrentMonthIso();
  input.value = proposalData.closeDate;
  display.textContent = formatUsDate(parseProposalDate(proposalData.closeDate));
  input.classList.add('hidden');
  display.classList.remove('hidden');
  field.classList.remove('is-editing');
  field.classList.add('is-saved');
  setTimeout(() => field.classList.remove('is-saved'), 900);
}

function toggleVcmiMode() {
  document.getElementById('more-menu-selection')?.classList.add('hidden');
  proposalData.vcmiMode = proposalData.vcmiMode === 'VMI' ? 'CMI' : 'VMI';
  const modeEl = document.getElementById('header-prop-vcmi-mode');
  const fieldEl = document.getElementById('proposal-vcmi-field');
  if (modeEl) modeEl.textContent = proposalData.vcmiMode;
  if (fieldEl) {
    fieldEl.classList.add('is-saved');
    setTimeout(() => fieldEl.classList.remove('is-saved'), 900);
  }
  renderOptions();
}

function saveProposalDraft() {
  proposalIsSaved = true;
  logProposalEvent('Proposal saved', 'Proposal draft was saved.');
  showSuccessBanner('Proposal saved', 'Your proposal draft has been saved successfully.');
}

function hasProposalName() {
  const name = (proposalData && proposalData.name ? proposalData.name : '').trim();
  return !!name && name !== 'New Proposal';
}

function generateProposalId() {
  const now = new Date();
  return `PROP-${now.getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
}

function handleDraftSaveClick() {
  if (!hasProposalName()) proposalData.name = generateProposalId();
  updateDraftingHeaderTitle();
  saveProposalDraft();
}

function confirmSaveAndLeaveProposal() {
  if (!hasProposalName()) proposalData.name = generateProposalId();
  updateDraftingHeaderTitle();
  saveProposalDraft();
  closeProposalSaveNameModal();
  openQuotesList();
}

function leaveWithoutSavingProposal() {
  closeProposalSaveNameModal();
  openQuotesList();
}

function navigateHome() {
  // From selection confirmed screen — go straight to proposals list
  openQuotesList();
}

function updateSegmentHeader() {
  const seg = proposalData.segment || 'SMB';
  const pill = document.getElementById('header-prop-segment-pill');
  const poWrap = document.getElementById('header-prop-po');
  const poVal  = document.getElementById('header-prop-po-val');
  if (pill) {
    pill.className = 'segment-pill ' + seg.toLowerCase();
    pill.textContent = seg;
  }
  if (poWrap && poVal) {
    const hasPO = proposalData.poNumber && proposalData.poNumber.trim().length > 0;
    poWrap.classList.toggle('hidden', !hasPO);
    if (hasPO) poVal.textContent = proposalData.poNumber;
  }
}

function cycleSegment() {
  const cycle = ['SMB', 'Enterprise', 'Government'];
  const idx = cycle.indexOf(proposalData.segment || 'SMB');
  proposalData.segment = cycle[(idx + 1) % cycle.length];
  // Changing segment clears deal-classification fields to avoid stale data
  proposalData.poNumber = '';
  proposalData.costCenter = '';
  proposalData.contractVehicle = '';
  proposalData.contractingOfficerName = '';
  proposalData.contractingOfficerEmail = '';
  proposalData.contractingOfficerPhone = '';
  updateSegmentHeader();
  renderOptions();
  logProposalEvent('Segment changed', `Proposal segment set to ${proposalData.segment}.`);
}

function handleRequestApproval() {
  if (proposalData.approvalStatus === 'Approved') return;
  openApprovalRequestModal();
}

function toggleMoreMenu() {
  let screenId = 'more-menu-draft';
  if (screen === 'review') screenId = 'more-menu-review';
  if (screen === 'selection') screenId = 'more-menu-selection';
  const menu = document.getElementById(screenId);
  if (menu) {
    setKebabMenuOpen(menu, menu.classList.contains('hidden'));
    if (screen === 'selection') {
      const trigger = document.querySelector('#screen-proposal-selection .btn-icon--tonal');
      const isOpen = !menu.classList.contains('hidden');
      trigger?.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    }
  }
}

function closeSelectionMoreMenu() {
  const menu = document.getElementById('more-menu-selection');
  if (menu) {
    setKebabMenuOpen(menu, false);
    const trigger = document.querySelector('#screen-proposal-selection .btn-icon--tonal');
    trigger?.setAttribute('aria-expanded', 'false');
  }
}

function viewProposalHistoryFromDraft() {
  if (!proposalWasSentToCustomer) return;
  viewProposalHistory();
}

function deleteBundle(optId, bundleId) {
  const opt = options.find(o => o.id === optId);
  if (opt) {
    opt.bundles = opt.bundles.filter(b => b.id !== bundleId);
    renderOptions();
  }
}

function closeConfirmSelectionModal() {
  const overlay = document.getElementById('confirm-selection-overlay');
  if (overlay) overlay.classList.remove('is-open');
}

function hideQuoteCreatedState() {
  document.getElementById('quote-created-state')?.classList.add('hidden');
  document.getElementById('selection-white-card')?.classList.remove('hidden');
}

function getFFBundleForm(bundleId) {
  if (!ffBundleForms[bundleId]) {
    ffBundleForms[bundleId] = {
      installType: 'vmi',
      shipAddr1: '',
      shipAddr2: '',
      shipCity: '',
      shipState: '',
      shipCountry: 'United States',
      shipZip: '',
      contactName: '',
      contactPhone: '',
      contactEmail: '',
      installSameAsShipping: true,
      shipAddressId: '',
      shipContactId: '',
      installAddressId: '',
      installContactId: '',
      coordinatorName: '',
      coordinatorPhone: '',
      coordinatorEmail: '',
      siteNotes: '',
    };
  }
  return ffBundleForms[bundleId];
}

function getBundles() {
  const opt = options.find(o => o.id === (typeof selectedOptionId !== 'undefined' ? selectedOptionId : null));
  if (opt && opt.bundles && opt.bundles.length > 0) return opt.bundles;
  // Fallback: use first option with bundles
  const fallback = options.find(o => o.bundles && o.bundles.length > 0);
  if (fallback) return fallback.bundles;
  return [{ id: 'default', coreName: 'Solution 1', qty: 10 }];
}

function ensureVehicleArrays() {
  getBundles().forEach(b => { if (!ffVehicles[b.id]) ffVehicles[b.id] = []; });
}

function renderFF() { renderFFSidebar(); renderFFContent(); }

function renderFFSidebar() {
  const s = document.getElementById('ff-sidebar');
  const bundles = getBundles();
  s.innerHTML = bundles.map(b => {
    const bv = ffVehicles[b.id] || [];
    const added = bv.length;
    const ready = bv.filter(v => isVehicleReadyForBundle(v, b)).length;
    const waveCount = (ffWaves[b.id] || []).length;
    const cap = getEffectiveBundleQtyCap(b.id);
    const isWaveCapped = cap < b.qty;
    const addedPct = Math.min((added / cap) * 100, 100);
    const readyPct = Math.min((ready / cap) * 100, 100);
    return `<div class="ff-sidebar-item ${ffActiveTab===b.id?'active':''}" onclick="ffSetTab('${b.id}')">
      <div class="ff-sidebar-item-label">${b.coreName}</div>
      <div class="ff-sidebar-item-sub">${added} / ${cap} added${isWaveCapped ? ` <span style="opacity:.7;">(of ${b.qty} total)</span>` : ''} · ${ready} ready</div>
      <div style="height:3px;background:#E5E7EB;border-radius:2px;margin:4px 0 2px;position:relative;overflow:hidden;">
        <div style="position:absolute;left:0;top:0;height:100%;width:${addedPct}%;background:#D1D5DB;border-radius:2px;"></div>
        <div style="position:absolute;left:0;top:0;height:100%;width:${readyPct}%;background:#1B5E20;border-radius:2px;"></div>
      </div>
      ${waveCount > 0 ? `<div class="ff-sidebar-item-sub" style="color:var(--brand-blue)">${waveCount} wave${waveCount!==1?'s':''}</div>` : ''}
    </div>`;
  }).join('');
}

function renderFFContent() {
  const c = document.getElementById('ff-body');
  if (ffMainTab === 'summary') { c.innerHTML = renderFFSummary(); return; }
  const activeBundleId = ffActiveTab === 'addresses' || ffActiveTab === 'contacts'
    ? (getBundles()[0]?.id || 'default')
    : ffActiveTab;
  c.innerHTML = renderFFVehicles(activeBundleId);
}

function renderFFAddresses() {
  const cards = ffAddresses.map((a, i) => `
    <div class="ff-card">
      <div class="ff-card-header">
        <div class="ff-card-title">Location ${i+1}</div>
        <div style="display:flex;gap:8px;align-items:center;">
          <span class="${a.saved?'ff-badge-saved':'ff-badge-unsaved'}">${a.saved?'✓ Saved':'Not saved'}</span>
          ${ffAddresses.length > 1 ? `<button class="ff-remove-btn" onclick="ffRemoveAddress(${a.id})"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/></svg></button>` : ''}
        </div>
      </div>
      <div class="ff-form-grid">
        <div class="ff-form-group" style="grid-column:span 2"><label class="ff-label">Address line 1 *</label>
          <input class="ff-input" type="text" value="${a.addr1}" placeholder="123 Main St" onchange="ffUpdateAddr(${a.id},'addr1',this.value)" ${a.saved?'disabled':''}></div>
        <div class="ff-form-group" style="grid-column:span 2"><label class="ff-label">Address line 2</label>
          <input class="ff-input" type="text" value="${a.addr2}" placeholder="Suite, floor…" onchange="ffUpdateAddr(${a.id},'addr2',this.value)" ${a.saved?'disabled':''}></div>
        <div class="ff-form-group"><label class="ff-label">Country</label>
          <select class="ff-select" onchange="ffUpdateAddr(${a.id},'country',this.value)" ${a.saved?'disabled':''}>
            <option ${(a.country||'United States')==='United States'?'selected':''}>United States</option>
            <option ${a.country==='Canada'?'selected':''}>Canada</option>
            <option ${a.country==='Mexico'?'selected':''}>Mexico</option>
          </select></div>
        <div class="ff-form-group"><label class="ff-label">City</label>
          <input class="ff-input" type="text" value="${a.city}" placeholder="Tampa" onchange="ffUpdateAddr(${a.id},'city',this.value)" ${a.saved?'disabled':''}></div>
        <div class="ff-form-group"><label class="ff-label">State</label>
          <input class="ff-input" type="text" value="${a.state}" placeholder="FL" onchange="ffUpdateAddr(${a.id},'state',this.value)" ${a.saved?'disabled':''}></div>
        <div class="ff-form-group"><label class="ff-label">Zip *</label>
          <input class="ff-input" type="text" value="${a.zip}" placeholder="33602" onchange="ffUpdateAddr(${a.id},'zip',this.value)" ${a.saved?'disabled':''}></div>
      </div>
      <div class="ff-action-row">
        <span style="font-size:12px;color:var(--gray-600);">${a.saved?'':'Fill address and zip to save'}</span>
        <button class="ff-save-btn ${a.saved?'done':''}" onclick="ffSaveAddress(${a.id})">${a.saved?'✓ Saved':'Validate &amp; save'}</button>
      </div>
    </div>`).join('');

  return `
    <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:14px;">
      <div><div style="font-size:15px;font-weight:700;margin-bottom:3px;">Account locations</div>
        <div style="font-size:12px;color:var(--gray-600);">Addresses used for shipping and installation.</div></div>
      ${ffReturnPending ? `<button class="ff-return-btn" onclick="ffGoToVehicles()">↩ Return to Vehicles</button>` : ''}
    </div>
    ${cards}
    <button class="ff-add-btn" onclick="ffAddAddress()">+ Add another location</button>`;
}

function renderFFContacts() {
  const cards = ffContacts.map((c, i) => `
    <div class="ff-card">
      <div class="ff-card-header">
        <div class="ff-card-title">Contact ${i+1}</div>
        <div style="display:flex;gap:8px;align-items:center;">
          <span class="${c.saved?'ff-badge-saved':'ff-badge-unsaved'}">${c.saved?'✓ Saved':'Not saved'}</span>
          ${ffContacts.length>1?`<button class="ff-remove-btn" onclick="ffRemoveContact(${c.id})"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/></svg></button>`:''}
        </div>
      </div>
      <div class="ff-form-grid">
        <div class="ff-form-group"><label class="ff-label">Name *</label>
          <input class="ff-input" type="text" value="${c.name}" placeholder="John Smith" onchange="ffUpdateContact(${c.id},'name',this.value)" ${c.saved?'disabled':''}></div>
        <div class="ff-form-group"><label class="ff-label">Phone</label>
          <input class="ff-input" type="text" value="${c.phone}" placeholder="+1 (555) 000-0000" onchange="ffUpdateContact(${c.id},'phone',this.value)" ${c.saved?'disabled':''}></div>
        <div class="ff-form-group" style="grid-column:span 2"><label class="ff-label">Email</label>
          <input class="ff-input" type="email" value="${c.email}" placeholder="john@company.com" onchange="ffUpdateContact(${c.id},'email',this.value)" ${c.saved?'disabled':''}></div>
      </div>
      <div class="ff-action-row"><span></span>
        <button class="ff-save-btn ${c.saved?'done':''}" onclick="ffSaveContact(${c.id})">${c.saved?'✓ Saved':'Save contact'}</button>
      </div>
    </div>`).join('');

  return `
    <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:14px;">
      <div><div style="font-size:15px;font-weight:700;margin-bottom:3px;">Account contacts</div>
        <div style="font-size:12px;color:var(--gray-600);">Contacts for receiving and coordinating installation.</div></div>
      ${ffReturnPending ? `<button class="ff-return-btn" onclick="ffGoToVehicles()">↩ Return to Vehicles</button>` : ''}
    </div>
    ${cards}
    <button class="ff-add-btn" onclick="ffAddContact()">+ Add another contact</button>`;
}

function bundleRequiresInstallation(bundle) {
  if (!bundle || bundle.coreKey === 'asset-nonpowered') return false;
  const form = getFFBundleForm(bundle.id);
  return form.installType !== 'cmi';
}

function vehicleRequiresInstallation(v, bundle) {
  if (!bundle || bundle.coreKey === 'asset-nonpowered') return false;
  const vType = v.installType || getFFBundleForm(bundle.id).installType || 'vmi';
  return vType !== 'cmi';
}

function isVehicleReadyForBundle(v, bundle) {
  if (v.telematics === 'OEM Detected') return !!(v.activationContact && v.vehicleName);
  const hasShipping = v.shippingId && v.shippingContactId && v.vehicleName;
  if (!hasShipping) return false;
  if (!vehicleRequiresInstallation(v, bundle)) return true;
  return !!(v.installAddressId && v.installContactId);
}

function getEffectiveBundleQtyCap(bundleId) {
  const bundle = getBundles().find(b => String(b.id) === String(bundleId));
  if (!bundle) return Infinity;
  if (!proposalData.wavesEnabled) return bundle.qty;
  const opt = options.find(o => o.id === (typeof selectedOptionId !== 'undefined' ? selectedOptionId : null))
            || options.find(o => o.bundles && o.bundles.length > 0);
  const cWaves = (opt && Array.isArray(opt.waves)) ? opt.waves : [];
  if (cWaves.length === 0) return bundle.qty; // no contract waves — full bundle available
  const PROCESSED = ['Dispatched', 'Pending Bind', 'Active-Billing'];
  const dispatchedQty = cWaves
    .filter(w => PROCESSED.includes(w.slotStatus || ''))
    .reduce((sum, w) => sum + (Number(w.qty) || 0), 0);
  // If no waves are dispatched yet, cap is 0 (nothing available)
  // Cap is also bounded by bundle.qty (can't exceed total contracted)
  return Math.min(dispatchedQty, bundle.qty);
}

function canAddVehiclesToBundle(bundleId) {
  const savedA = ffAddresses.filter(a => a.saved).length;
  const savedC = ffContacts.filter(c => c.saved).length;
  if (savedA === 0 || savedC === 0) {
    alert('Please save at least one address and one contact before assigning vehicles.');
    ffGoToAddresses(true);
    return false;
  }
  const cap = getEffectiveBundleQtyCap(bundleId);
  const used = (ffVehicles[bundleId] || []).length;
  if (cap === 0) {
    alert('No dispatched waves yet. Advance a wave to "Dispatched" status from the option card before assigning vehicles.');
    return false;
  }
  if (used >= cap) {
    const bundle = getBundles().find(b => String(b.id) === String(bundleId));
    const isWaveCapped = proposalData.wavesEnabled && cap < (bundle ? bundle.qty : Infinity);
    alert(isWaveCapped
      ? `Dispatched wave capacity reached (${cap} vehicles). Advance the next wave to "Dispatched" to unlock more.`
      : `QTY cap reached for this solution (${cap}).`);
    return false;
  }
  return true;
}

function renderFFVehicles(bundleId) {
  const bundle   = getBundles().find(b => String(b.id) === String(bundleId)) || { id: bundleId, coreName: 'Bundle', qty: 10 };
  const bv       = ffVehicles[bundleId] || [];
  const form     = getFFBundleForm(bundleId);
  const isCMI    = form.installType === 'cmi';
  const requiresInstall = bundleRequiresInstallation(bundle);
  const allOEM   = bv.length > 0 && bv.every(v => v.telematics === 'OEM Detected');
  if (!requiresInstall && ffBulkType === 'installation') ffBulkType = '';
  const readyN   = bv.filter(v => isVehicleReadyForBundle(v, bundle)).length;
  const partialN = bv.filter(v => {
    const hasAny = v.telematics === 'OEM Detected'
      ? (v.activationContact || v.vehicleName)
      : (v.shippingId||v.shippingContactId||v.installAddressId||v.installContactId||v.vehicleName);
    return hasAny && !isVehicleReadyForBundle(v, bundle);
  }).length;
  const selInB   = ffSelected.filter(id => bv.find(v => String(v.id) === String(id)));
  const savedA   = ffAddresses.filter(a=>a.saved);
  const savedC   = ffContacts.filter(c=>c.saved);
  const aOpts = `<option value="">Select address…</option>${savedA.map(a=>`<option value="${a.id}">${a.name||'Location '+a.id}</option>`).join('')}<option value="ADD_NEW" style="font-weight:700;color:var(--brand-blue)">+ Add new</option>`;
  const cOpts = `<option value="">Select contact…</option>${savedC.map(c=>`<option value="${c.id}">${c.name||'Contact '+c.id}</option>`).join('')}<option value="ADD_NEW" style="font-weight:700;color:var(--brand-blue)">+ Add new</option>`;
  const waves    = ffWaves[bundleId] || [];
  // isEditing: show form when no address saved yet, or user explicitly requested edit mode
  const isEditing = !form.shipAddressId || ffFormEditMode[bundleId] === true;

  // Contract wave context (used in both vehicle rows and wave panel)
  const PROCESSED_STATUSES = ['Dispatched', 'Pending Bind', 'Active-Billing'];
  const _contractOpt = proposalData.wavesEnabled
    ? (options.find(o => o.id === (typeof selectedOptionId !== 'undefined' ? selectedOptionId : null))
       || options.find(o => o.bundles && o.bundles.length > 0))
    : null;
  const contractWaves = (_contractOpt && Array.isArray(_contractOpt.waves)) ? _contractOpt.waves : [];
  // Effective cap — dispatched wave qty only (or full bundle.qty if no wave plan)
  const effectiveCap = getEffectiveBundleQtyCap(bundleId);
  const atQtyCap = bv.length >= effectiveCap;
  // Context label for progress bar
  const dispatchedWaveNames = contractWaves.filter(w => PROCESSED_STATUSES.includes(w.slotStatus||'')).map(w=>w.name);
  const pendingWaveQty = contractWaves
    .filter(w => !PROCESSED_STATUSES.includes(w.slotStatus||''))
    .reduce((s,w)=>s+(Number(w.qty)||0),0);
  const waveCapLabel = dispatchedWaveNames.length > 0
    ? ` (${dispatchedWaveNames.join(' + ')})`
    : '';
  const waveNextLabel = pendingWaveQty > 0
    ? `<span style="font-size:9px;color:var(--gray-400);margin-left:4px;">· ${pendingWaveQty} in pending wave${dispatchedWaveNames.length > 0 ? '' : 's'}</span>`
    : '';

  const filtered = bv.filter(v => {
    if (!ffSearch) return true;
    const s = ffSearch.toLowerCase();
    return (v.vin||'').toLowerCase().includes(s)||(v.ymm||'').toLowerCase().includes(s)||(v.vehicleName||'').toLowerCase().includes(s);
  });

  // Input method
  const methodMeta = {
    vin: { title: 'Option A: Bulk add via VIN', helper: 'Paste one or multiple VINs separated by commas.' },
    ymm: { title: 'Option B: Manual YMM entry', helper: 'Add vehicles by year, make, model and quantity.' },
    dot: { title: 'Option C: DOT fleet lookup', helper: 'Search by US DOT Number and add vehicles.' },
  };
  let inputHtml = '';
  if (ffInputMethod === 'vin') {
    const lines = ffVinInput.split(',').map(s=>s.trim()).filter(Boolean);
    const valid = lines.filter(v=>v.length===17).length;
    inputHtml = `<div class="ff-form-group" style="margin:0">
      <label class="ff-label" style="display:flex;justify-content:space-between;">
        <span>Paste one or multiple VINs</span>
        ${lines.length?`<span style="color:${valid===lines.length?'#1B5E20':'#dc2626'};font-weight:700">${valid}/${lines.length} valid</span>`:''}
      </label>
      <textarea class="ff-textarea" style="min-height:52px;" placeholder="Paste one or multiple VINs (comma-separated)..." oninput="ffVinInput=this.value;">${ffVinInput}</textarea>
      <button class="ff-save-btn" style="margin-top:7px;" onclick="ffProcessVins('${bundleId}')" ${atQtyCap?'disabled':''}>Process &amp; Add</button>
    </div>`;
  } else if (ffInputMethod === 'ymm') {
    const makeOpts = Object.keys(FF_MAKES_MODELS).sort().map(m =>
      `<option value="${m}" ${ffYmm.make===m?'selected':''}>${m}</option>`).join('');
    const modelOpts = (FF_MAKES_MODELS[ffYmm.make] || []).map(m =>
      `<option value="${m}" ${ffYmm.model===m?'selected':''}>${m}</option>`).join('');
    inputHtml = `<div style="display:flex;gap:8px;align-items:flex-end;flex-wrap:wrap;">
      <div class="ff-form-group" style="flex:0 0 88px;margin:0"><label class="ff-label">Year</label>
        <select class="ff-select" onchange="ffYmm.year=this.value;renderFFContent()">
          <option value="">Year…</option>
          ${FF_YEARS.map(y=>`<option value="${y}" ${ffYmm.year===y?'selected':''}>${y}</option>`).join('')}
        </select></div>
      <div class="ff-form-group" style="flex:1;min-width:120px;margin:0"><label class="ff-label">Make</label>
        <select class="ff-select" onchange="ffYmm.make=this.value;ffYmm.model='';renderFFContent()">
          <option value="">Make…</option>${makeOpts}
        </select></div>
      <div class="ff-form-group" style="flex:1.4;min-width:130px;margin:0"><label class="ff-label">Model</label>
        <select class="ff-select" ${!ffYmm.make?'disabled':''} onchange="ffYmm.model=this.value;renderFFContent()">
          <option value="">${ffYmm.make?'Model…':'Select make first'}</option>${modelOpts}
        </select></div>
      <div class="ff-form-group" style="margin:0;width:auto;"><label class="ff-label">QTY</label>
        <div style="display:flex;align-items:center;border:1.5px solid var(--gray-200);border-radius:999px;height:36px;padding:0 8px;gap:6px;background:white;">
          <button style="border:none;background:none;cursor:pointer;font-size:15px" onclick="ffYmm.qty=Math.max(1,ffYmm.qty-1);renderFFContent()">−</button>
          <span style="font-size:13px;font-weight:700;min-width:18px;text-align:center">${ffYmm.qty}</span>
          <button style="border:none;background:none;cursor:pointer;font-size:15px" onclick="ffYmm.qty++;renderFFContent()">+</button>
        </div>
      </div>
      <button class="ff-save-btn" style="height:36px;border-radius:999px;padding:0 18px;" onclick="ffAddYMM('${bundleId}')" ${atQtyCap||!ffYmm.year||!ffYmm.make||!ffYmm.model?'disabled':''}>Add</button>
    </div>`;
  } else {
    // Fleet registration list — no manual input needed
    const globalVinsSet = getGlobalVinSet();
    const availableDot = FF_DOT_FLEET_MOCK.filter(v => !globalVinsSet.has(v.vin));
    const dotRows = availableDot.map(v => {
      const sel = ffDotSelected.includes(v.vin);
      const telem = detectTelematics(v.make, v.year);
      return `<label style="display:flex;align-items:center;gap:10px;padding:6px 0;border-bottom:1px solid #f3f3f3;cursor:pointer;font-size:12px;">
        <input type="checkbox" class="vds-checkbox-ff" ${sel?'checked':''} onchange="ffDotSelected=this.checked?[...ffDotSelected,'${v.vin}']:ffDotSelected.filter(x=>x!=='${v.vin}');renderFFContent()">
        <span style="font-family:monospace;font-size:10px;color:var(--gray-600);width:140px;flex-shrink:0;">${v.vin}</span>
        <span style="flex:1;font-weight:600;">${v.ymm}</span>
        <span style="font-size:10px;color:var(--gray-600);width:26px;">${v.cls}</span>
        ${telem==='OEM Detected'?`<span class="ff-badge-oem" style="font-size:9px;padding:1px 5px;">OEM</span>`:`<span style="font-size:10px;color:var(--gray-400);">Std</span>`}
      </label>`;
    }).join('');
    inputHtml = `<div>
      <div style="font-size:11px;color:var(--gray-600);margin-bottom:6px;">Fleet registration on file — select vehicles to add to this solution:</div>
      <div style="max-height:180px;overflow-y:auto;border:1px solid var(--gray-200);border-radius:6px;padding:2px 10px;">
        ${dotRows || '<div style="font-size:12px;color:var(--gray-400);padding:8px 0;">All registered vehicles already assigned.</div>'}
      </div>
      <button class="ff-save-btn" style="margin-top:8px;" onclick="ffAddDotSelected('${bundleId}')" ${ffDotSelected.length===0||atQtyCap?'disabled':''}>Add ${ffDotSelected.length?ffDotSelected.length+' ':''}selected</button>
    </div>`;
  }

  // Bulk bar
  let bulkHtml = '';
  if (bv.length > 0) {
    if (!ffBulkOn) {
      bulkHtml = `<button class="ff-btn-start-bulk" onclick="ffBulkOn=true;renderFFContent()">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/></svg>
        Bulk action
      </button>`;
    } else {
      const actSel = `<select class="ff-select" style="width:190px;" onchange="ffBulkType=this.value;renderFFContent()">
        <option value="">Select action…</option>
        <option value="shipping" ${ffBulkType==='shipping'?'selected':''}>Shipping info</option>
        ${requiresInstall ? `<option value="installation" ${ffBulkType==='installation'?'selected':''}>Installation info</option>` : ''}
        ${waves.length > 0 ? `<option value="wave" ${ffBulkType==='wave'?'selected':''}>Assign to wave</option>` : ''}
        <option value="attributes" ${ffBulkType==='attributes'?'selected':''}>Set attributes</option>
        <option value="installtype" ${ffBulkType==='installtype'?'selected':''}>Install type (VMI/CMI)</option>
      </select>`;
      let flds = '';
      if (ffBulkType==='shipping') flds=`
        <div><select class="ff-select" style="min-width:160px;" onchange="ffBulkField('shippingId',this.value,'addresses')">${aOpts}</select></div>
        <div><select class="ff-select" style="min-width:160px;" onchange="ffBulkField('shippingContactId',this.value,'contacts')">${cOpts}</select></div>
        <label style="font-size:11px;display:flex;align-items:center;gap:5px;cursor:pointer;white-space:nowrap"><input type="checkbox" class="vds-checkbox-ff" ${ffBulkF.sameAsShipping?'checked':''} onchange="ffBulkF.sameAsShipping=this.checked"> Same as install</label>`;
      else if (ffBulkType==='installation') flds=`
        <div><select class="ff-select" style="min-width:160px;" onchange="ffBulkField('installAddressId',this.value,'addresses')">${aOpts}</select></div>
        <div><select class="ff-select" style="min-width:160px;" onchange="ffBulkField('installContactId',this.value,'contacts')">${cOpts}</select></div>`;
      else if (ffBulkType==='wave') flds=`
        <div><select class="ff-select" style="min-width:160px;" onchange="ffBulkField('waveId',this.value,'')">
          <option value="">Unassigned</option>
          ${waves.map(w=>`<option value="${w.id}">${w.name}</option>`).join('')}
        </select></div>`;
      else if (ffBulkType==='attributes') flds=`
        <label style="font-size:12px;display:flex;align-items:center;gap:5px;cursor:pointer;white-space:nowrap;"><input type="checkbox" class="vds-checkbox-ff" ${ffBulkF.isEmergency?'checked':''} onchange="ffBulkF.isEmergency=this.checked"> Emergency</label>
        <label style="font-size:12px;display:flex;align-items:center;gap:5px;cursor:pointer;white-space:nowrap;"><input type="checkbox" class="vds-checkbox-ff" ${ffBulkF.hasWheelchairLift?'checked':''} onchange="ffBulkF.hasWheelchairLift=this.checked"> Wheelchair lift</label>
        <label style="font-size:12px;display:flex;align-items:center;gap:5px;cursor:pointer;white-space:nowrap;"><input type="checkbox" class="vds-checkbox-ff" ${ffBulkF.masterSwitchOff?'checked':''} onchange="ffBulkF.masterSwitchOff=this.checked"> Master switch off</label>
        <label style="font-size:12px;display:flex;align-items:center;gap:5px;cursor:pointer;white-space:nowrap;"><input type="checkbox" class="vds-checkbox-ff" ${ffBulkF.hasCompetitorDevice?'checked':''} onchange="ffBulkF.hasCompetitorDevice=this.checked"> Competitor device</label>`;
      else if (ffBulkType==='installtype') flds=`
        <label style="font-size:12px;display:flex;align-items:center;gap:6px;cursor:pointer;white-space:nowrap;"><input type="radio" name="bulk-installtype" value="vmi" ${ffBulkF.installType==='vmi'?'checked':''} onchange="ffBulkF.installType=this.value"> VMI &mdash; Verizon installs</label>
        <label style="font-size:12px;display:flex;align-items:center;gap:6px;cursor:pointer;white-space:nowrap;"><input type="radio" name="bulk-installtype" value="cmi" ${ffBulkF.installType==='cmi'?'checked':''} onchange="ffBulkF.installType=this.value"> CMI &mdash; Customer installs</label>`;
      bulkHtml = `<div class="ff-bulk-bar ff-fadein">
        <div class="ff-bulk-hdr">
          <span class="ff-bulk-title">Bulk action</span>
          <button class="ff-remove-btn" onclick="ffBulkOn=false;ffBulkType='';renderFFContent()"><svg width="14" height="14" viewBox="0 0 15.185 15.185" fill="currentColor"><path d="M 8.889 7.593 L 15.185 13.889 L 13.889 15.185 L 7.593 8.889 L 1.296 15.185 L 0 13.889 L 6.296 7.593 L 0 1.296 L 1.296 0 L 7.593 6.296 L 13.889 0 L 15.185 1.296 L 8.889 7.593 Z"/></svg></button>
        </div>
        <div class="ff-bulk-fields">${actSel}${flds}</div>
        <div class="ff-bulk-footer">
          <span class="ff-bulk-count">Selected: <strong>${selInB.length}</strong></span>
          <button class="ff-bulk-apply" ${selInB.length===0||!ffBulkType?'disabled':''} onclick="ffApplyBulk('${bundleId}')">Apply</button>
        </div>
      </div>`;
    }
  }

  // Vehicle table — compact rows, per-column attribute checkboxes, expandable detail
  let rowsHtml = '';
  const allFilteredSel = filtered.length > 0 && filtered.every(v => ffSelected.includes(String(v.id)));
  const filterBar = `
    <div class="ff-select-all-row">
      <label style="display:flex;align-items:center;gap:7px;font-size:11px;font-weight:700;color:var(--gray-600);cursor:pointer">
        <input type="checkbox" class="vds-checkbox-ff" ${allFilteredSel?'checked':''} onchange="ffToggleFiltered('${bundleId}',this.checked)"> Select all${ffSearch?' (filtered)':''}
      </label>
      <div class="ff-filter-wrap">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
        <input class="ff-filter" type="text" placeholder="Filter VIN / YMM / name…" value="${ffSearch}" oninput="ffSearch=this.value;renderFFContent()">
      </div>
    </div>`;
  if (filtered.length === 0) {
    rowsHtml = filterBar + `<div class="ff-empty-state">${ffSearch ? 'No vehicles match "'+ffSearch+'"' : 'Add vehicles above to begin assignment'}</div>`;
  } else {
    rowsHtml = filterBar + `
    <table class="ff-v-table ff-v-table--compact">
      <thead>
        <tr>
          <th style="width:28px;"></th>
          <th style="text-align:left;">Vehicle</th>
          <th style="text-align:left;min-width:90px;">Name</th>
          <th style="text-align:left;min-width:80px;">Plate</th>
          <th style="width:26px;" title="Emergency vehicle"><span class="material-symbols-outlined" style="font-size:13px;color:#991B1B;">emergency</span></th>
          <th style="width:26px;" title="Wheelchair lift"><span class="material-symbols-outlined" style="font-size:13px;color:#3730A3;">accessible</span></th>
          <th style="width:26px;" title="Master switch off"><span class="material-symbols-outlined" style="font-size:13px;color:#374151;">power_off</span></th>
          <th style="width:26px;" title="Competitor device — removal at install"><span class="material-symbols-outlined" style="font-size:13px;color:#92400E;">build</span></th>
          <th style="width:58px;">Status</th>
          <th style="width:50px;"></th>
        </tr>
      </thead>
      <tbody>
        ${filtered.map(v => {
          const isReady = isVehicleReadyForBundle(v, bundle);
          const hasAny = v.telematics === 'OEM Detected'
            ? (v.activationContact || v.vehicleName)
            : (v.shippingId||v.shippingContactId||v.vehicleName);
          const isPartial = !!(hasAny && !isReady);
          const isOEM = v.telematics === 'OEM Detected';
          const assignedWave = waves.find(w => String(w.id) === String(v.waveId));
          const vInstallType = v.installType || form.installType || 'vmi';
          const vRequiresInstall = bundle.coreKey !== 'asset-nonpowered' && vInstallType !== 'cmi';
          const bundleInstallType = form.installType || 'vmi';
          const installOverridden = v.installType && v.installType !== bundleInstallType;
          const expanded = !!ffVehicleExpanded[String(v.id)];
          const vWaveOpts = `<option value="">Unassigned</option>${waves.map(w=>{
            const cw = contractWaves.find(c => String(c.id) === String(w.contractWaveId));
            const cwLabel = cw ? ` [${cw.slotStatus||'Contracted'}]` : '';
            return `<option value="${w.id}" ${String(w.id)===String(v.waveId)?'selected':''}>${w.name}${cwLabel}</option>`;
          }).join('')}`;
          const statusEl = isReady
            ? `<span style="color:var(--green);font-size:10px;font-weight:700;display:flex;align-items:center;gap:1px;"><span class="material-symbols-outlined" style="font-size:12px;">check_circle</span>Ready</span>`
            : isPartial
              ? `<span style="color:#f97316;font-size:10px;font-weight:700;display:flex;align-items:center;gap:1px;"><span class="material-symbols-outlined" style="font-size:12px;">pending</span>Partial</span>`
              : `<span style="color:var(--gray-400);font-size:10px;display:flex;align-items:center;gap:1px;"><span class="material-symbols-outlined" style="font-size:12px;">radio_button_unchecked</span>Empty</span>`;
          const detailRow = expanded ? `
            <tr class="ff-v-detail-row">
              <td colspan="10">
                <div style="padding:10px 12px 12px 28px;">
                  <div style="display:flex;align-items:center;gap:16px;margin-bottom:10px;padding-bottom:10px;border-bottom:1px solid var(--gray-200);">
                    <span style="font-size:11px;font-weight:700;color:var(--gray-600);">INSTALL TYPE</span>
                    <label style="display:flex;align-items:center;gap:5px;font-size:12px;cursor:pointer;white-space:nowrap;">
                      <input type="radio" name="vit-${v.id}" value="vmi" ${vInstallType==='vmi'?'checked':''} onchange="ffUpdateVeh('${bundleId}','${v.id}','installType','vmi');renderFFContent()"> VMI — Verizon installs
                    </label>
                    <label style="display:flex;align-items:center;gap:5px;font-size:12px;cursor:pointer;white-space:nowrap;">
                      <input type="radio" name="vit-${v.id}" value="cmi" ${vInstallType==='cmi'?'checked':''} onchange="ffUpdateVeh('${bundleId}','${v.id}','installType','cmi');renderFFContent()"> CMI — Customer installs
                    </label>
                    ${installOverridden ? `<span style="font-size:10px;font-weight:700;background:#FEF3C7;color:#92400E;border-radius:999px;padding:1px 7px;">Overrides solution default (${bundleInstallType.toUpperCase()})</span>` : ''}
                    <button type="button" class="text-link text-link--small" style="margin-left:auto;" onclick="ffUpdateVeh('${bundleId}','${v.id}','installType','${bundleInstallType}');renderFFContent()">Reset to solution default</button>
                  </div>
                  <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">
                  ${isOEM ? `
                    <div class="ff-form-group" style="margin:0;grid-column:1/-1;">
                      <label class="ff-label">Activation Contact <span style="color:var(--gray-400)">(fleet manager authorizing OEM access)</span></label>
                      <input class="ff-input" type="text" placeholder="Name and/or email" value="${v.activationContact||''}" onchange="ffUpdateVeh('${bundleId}','${v.id}','activationContact',this.value)">
                    </div>` : `
                    <div class="ff-form-group" style="margin:0;"><label class="ff-label">Shipping address</label>
                      <select class="ff-select" onchange="ffVehicleDrop('${bundleId}','${v.id}','shippingId',this.value,'addresses')">${aOpts.replace(`value="${v.shippingId||''}"`,`value="${v.shippingId||''}" selected`)}</select></div>
                    <div class="ff-form-group" style="margin:0;"><label class="ff-label">Shipping contact</label>
                      <select class="ff-select" onchange="ffVehicleDrop('${bundleId}','${v.id}','shippingContactId',this.value,'contacts')">${cOpts.replace(`value="${v.shippingContactId||''}"`,`value="${v.shippingContactId||''}" selected`)}</select></div>
                    ${vRequiresInstall ? `
                    <div style="grid-column:1/-1;"><button type="button" class="text-link text-link--small" onclick="ffCopyShipping('${bundleId}','${v.id}')">Copy shipping → installation</button></div>
                    <div class="ff-form-group" style="margin:0;"><label class="ff-label">Install address</label>
                      <select class="ff-select" onchange="ffVehicleDrop('${bundleId}','${v.id}','installAddressId',this.value,'addresses')">${aOpts.replace(`value="${v.installAddressId||''}"`,`value="${v.installAddressId||''}" selected`)}</select></div>
                    <div class="ff-form-group" style="margin:0;"><label class="ff-label">Install contact</label>
                      <select class="ff-select" onchange="ffVehicleDrop('${bundleId}','${v.id}','installContactId',this.value,'contacts')">${cOpts.replace(`value="${v.installContactId||''}"`,`value="${v.installContactId||''}" selected`)}</select></div>` : `
                    <div style="grid-column:1/-1;font-size:11px;color:var(--gray-600);padding:2px 0;">CMI — no installation address required.</div>`}`}
                  ${waves.length > 0 ? `<div class="ff-form-group" style="margin:0;"><label class="ff-label">Install wave</label>
                    <select class="ff-select" onchange="ffAssignVehicleWave('${bundleId}','${v.id}',this.value)">${vWaveOpts}</select></div>` : ''}
                  </div>
                </div>
              </td>
            </tr>` : '';
          return `
            <tr class="ff-v-row-main${ffSelected.includes(String(v.id))?' ff-v-row-sel':''}">
              <td style="padding:5px 4px;"><input type="checkbox" class="vds-checkbox-ff" ${ffSelected.includes(String(v.id))?'checked':''} onchange="ffToggleSel('${v.id}',this.checked)"></td>
              <td style="padding:5px 8px;">
                <div style="font-family:monospace;font-size:10px;color:var(--gray-600);" title="${v.vin}">${v.vin.length>13?v.vin.slice(0,10)+'…':v.vin}</div>
                <div style="font-size:11px;font-weight:600;">${v.ymm||'Vehicle'}</div>
                ${isOEM?`<span class="ff-badge-oem" style="font-size:9px;padding:1px 4px;">OEM</span>`:''}
                ${installOverridden?`<span style="font-size:9px;font-weight:700;background:#FEF3C7;color:#92400E;border-radius:3px;padding:0 4px;">${vInstallType.toUpperCase()}</span>`:''}
                ${assignedWave?`<span style="font-size:9px;color:var(--brand-blue);font-weight:700;">↗ ${assignedWave.name}</span>`:''}
              </td>
              <td style="padding:4px 6px;"><input class="ff-input" style="height:28px;font-size:12px;padding:2px 6px;" type="text" placeholder="Name…" value="${v.vehicleName||''}" onchange="ffUpdateVeh('${bundleId}','${v.id}','vehicleName',this.value)"></td>
              <td style="padding:4px 6px;"><input class="ff-input" style="height:28px;font-size:12px;padding:2px 6px;" type="text" placeholder="ABC-1234" value="${v.plate||''}" onchange="ffUpdateVeh('${bundleId}','${v.id}','plate',this.value)"></td>
              <td style="padding:4px;text-align:center;"><input type="checkbox" class="vds-checkbox-ff" ${v.isEmergency?'checked':''} onchange="ffUpdateVeh('${bundleId}','${v.id}','isEmergency',this.checked)"></td>
              <td style="padding:4px;text-align:center;"><input type="checkbox" class="vds-checkbox-ff" ${v.hasWheelchairLift?'checked':''} onchange="ffUpdateVeh('${bundleId}','${v.id}','hasWheelchairLift',this.checked)"></td>
              <td style="padding:4px;text-align:center;"><input type="checkbox" class="vds-checkbox-ff" ${v.masterSwitchOff?'checked':''} onchange="ffUpdateVeh('${bundleId}','${v.id}','masterSwitchOff',this.checked)"></td>
              <td style="padding:4px;text-align:center;"><input type="checkbox" class="vds-checkbox-ff" ${v.hasCompetitorDevice?'checked':''} onchange="ffUpdateVeh('${bundleId}','${v.id}','hasCompetitorDevice',this.checked)"></td>
              <td style="padding:4px 6px;">${statusEl}</td>
              <td style="padding:4px;text-align:right;white-space:nowrap;">
                <button type="button" class="btn-icon btn-icon--solid" style="width:24px;height:24px;min-width:24px;min-height:24px;padding:0;" title="${expanded?'Collapse':'Assignments'}" aria-label="${expanded?'Collapse':'Assignments'}" onclick="ffVehicleExpanded[String('${v.id}')]=!ffVehicleExpanded[String('${v.id}')];renderFFContent()">
                  <span class="material-symbols-outlined">${expanded?'expand_less':'expand_more'}</span>
                </button>
                <button class="ff-v-remove" onclick="ffRemoveVehicle('${bundleId}','${v.id}')"><svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/></svg></button>
              </td>
            </tr>
            ${detailRow}`;
        }).join('')}
      </tbody>
    </table>`;
  }

  // Wave management panel
  // (contractWaves, PROCESSED_STATUSES, contractWaves already defined above)
  const lockedContractWaves = contractWaves.filter(cw => !PROCESSED_STATUSES.includes(cw.slotStatus || ''));
  const hasContractWaves = contractWaves.length > 0;

  const wavePanel = `
    <div class="ff-wave-panel">
      ${hasContractWaves ? `
      <div style="background:#EFF6FF;border:1px solid #BFDBFE;border-radius:6px;padding:8px 10px;display:flex;gap:8px;font-size:11px;color:#1D4ED8;line-height:1.5;margin-bottom:10px;">
        <span class="material-symbols-outlined" style="font-size:14px;flex-shrink:0;margin-top:1px;">sync</span>
        <span>Waves are sourced from the contract. Only <strong>Dispatched</strong> or later waves are available for vehicle assignment. Advance wave status from the option card to unlock them.</span>
      </div>` : `
      <div style="background:#EFF6FF;border:1px solid #BFDBFE;border-radius:6px;padding:8px 10px;display:flex;gap:8px;font-size:11px;color:#1D4ED8;line-height:1.5;margin-bottom:10px;">
        <span class="material-symbols-outlined" style="font-size:14px;flex-shrink:0;margin-top:1px;">info</span>
        <span><strong>Waves</strong> split your fleet install into groups with separate target dates. Assign each vehicle to a wave using the expand (▾) button on any vehicle row above.</span>
      </div>`}
      <div class="ff-wave-panel-header">
        <span class="ff-panel-title" style="font-size:16px;">Installation Waves</span>
        <span style="font-size:11px;color:var(--gray-600)">${waves.length} available · ${bv.filter(v=>v.waveId).length} scheduled</span>
        ${!hasContractWaves ? `<button class="ff-wave-add-btn" onclick="ffAddWave('${bundleId}')">+ Add Wave</button>` : ''}
      </div>
      ${waves.length === 0 && lockedContractWaves.length === 0
        ? `<div style="font-size:12px;color:var(--gray-400);padding:4px 0;">${hasContractWaves ? 'No dispatched waves yet. Advance wave status from the option card.' : 'No waves defined. Add a wave to plan phased installation.'}</div>`
        : `${waves.map(w => {
            const wvCount = bv.filter(v => String(v.waveId) === String(w.id)).length;
            // Look up contract wave status if seeded from contract
            const cw = contractWaves.find(c => String(c.id) === String(w.contractWaveId));
            const cwSc = cw ? getSlotStatusConfig(cw.slotStatus || 'Contracted') : null;
            return `<div class="ff-wave-card">
              <div style="display:flex;align-items:center;gap:10px;flex:1;flex-wrap:wrap;">
                <input class="ff-input" type="text" value="${w.name}" style="font-weight:700;font-size:13px;max-width:130px;" onchange="ffUpdateWave('${bundleId}',${w.id},'name',this.value)">
                <div>
                  <label class="ff-label" style="font-size:10px;margin-bottom:2px;display:block;">Target date</label>
                  <input class="ff-input" type="date" value="${w.targetDate||''}" style="font-size:12px;" onchange="ffUpdateWave('${bundleId}',${w.id},'targetDate',this.value)">
                </div>
                ${cwSc ? `<span class="ss-chip ${cwSc.cssClass}" style="font-size:9px;padding:2px 7px;"><span class="material-symbols-outlined" style="font-size:11px;">${cwSc.icon}</span>${cwSc.label}</span>` : ''}
                <span class="ff-wave-count">${wvCount} vehicle${wvCount!==1?'s':''}</span>
              </div>
              ${!hasContractWaves ? `<button class="ff-remove-btn" onclick="ffRemoveWave('${bundleId}',${w.id})" title="Remove wave"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/></svg></button>` : ''}
            </div>`;
          }).join('')}
          ${lockedContractWaves.map(cw => {
            const sc = getSlotStatusConfig(cw.slotStatus || 'Contracted');
            return `<div class="ff-wave-card" style="opacity:0.55;pointer-events:none;background:#F9FAFB;">
              <div style="display:flex;align-items:center;gap:10px;flex:1;flex-wrap:wrap;">
                <span style="font-weight:700;font-size:13px;color:var(--gray-600);min-width:130px;">${cw.name}</span>
                ${cw.targetDate ? `<span style="font-size:11px;color:var(--gray-400);">${cw.targetDate}</span>` : ''}
                <span class="ss-chip ${sc.cssClass}" style="font-size:9px;padding:2px 7px;"><span class="material-symbols-outlined" style="font-size:11px;">${sc.icon}</span>${sc.label}</span>
                <span style="font-size:10px;color:var(--gray-400);font-style:italic;">Not yet dispatched — locked</span>
              </div>
            </div>`;
          }).join('')}`}
    </div>`;

  return `
    <div style="padding-bottom:16px;border-bottom:1px solid var(--gray-200);">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
        <div class="ff-panel-title" style="font-size:22px;">Shipping Details</div>
        ${!isEditing ? `<button class="ff-save-btn" style="background:transparent;border:1px solid var(--gray-300);color:var(--gray-600);padding:5px 12px;font-size:11px;display:flex;align-items:center;gap:4px;" onclick="ffEnterEditMode('${bundleId}')"><span class="material-symbols-outlined" style="font-size:13px;">edit</span> Edit</button>` : ''}
      </div>
      ${isEditing ? `
      ${allOEM ? `<div class="ff-oem-notice"><span class="ff-badge-oem">All OEM</span>&nbsp; All vehicles in this solution use OEM telematics — no hardware shipping required.</div>` : `
      ${savedA.length > 0 ? `<div style="background:#F0F9FF;border:1px solid #BAE6FD;border-radius:6px;padding:8px 10px;display:flex;gap:10px;align-items:center;margin-bottom:10px;flex-wrap:wrap;">
        <span class="material-symbols-outlined" style="font-size:15px;color:#0284C7;flex-shrink:0;">bookmark</span>
        <div style="display:flex;gap:8px;align-items:center;flex:1;flex-wrap:wrap;">
          <div style="display:flex;gap:6px;align-items:center;flex:1;min-width:180px;">
            <label style="font-size:11px;font-weight:700;color:#0369A1;white-space:nowrap;">Shipping address:</label>
            <select class="ff-select" style="flex:1;" onchange="ffUseSavedAddress('${bundleId}',this.value,'ship');this.value=''">
              <option value="">— select saved —</option>
              ${savedA.map(a=>`<option value="${a.id}" ${String(form.shipAddressId)===String(a.id)?'selected':''}>${a.name||'Location '+a.id}</option>`).join('')}
            </select>
          </div>
          ${savedC.length > 0 ? `<div style="display:flex;gap:6px;align-items:center;flex:1;min-width:160px;">
            <label style="font-size:11px;font-weight:700;color:#0369A1;white-space:nowrap;">Contact:</label>
            <select class="ff-select" style="flex:1;" onchange="ffUseSavedContact('${bundleId}',this.value,'ship');this.value=''">
              <option value="">— select saved —</option>
              ${savedC.map(c=>`<option value="${c.id}" ${String(form.shipContactId)===String(c.id)?'selected':''}>${c.name||'Contact '+c.id}</option>`).join('')}
            </select>
          </div>` : ''}
        </div>
        ${(form.shipAddressId||form.shipContactId) ? `<span style="font-size:10px;font-weight:700;color:#0369A1;white-space:nowrap;display:flex;align-items:center;gap:3px;"><span class="material-symbols-outlined" style="font-size:12px;">check_circle</span>Applied</span>` : ''}
      </div>` : ''}
      <div style="display:grid;grid-template-columns:1fr;gap:8px;">
        <div class="ff-form-group"><label class="ff-label">Address 1</label><input class="ff-input" type="text" value="${form.shipAddr1}" onchange="ffUpdateBundleForm('${bundleId}','shipAddr1',this.value)"></div>
        <div class="ff-form-group"><label class="ff-label">Address 2</label><input class="ff-input" type="text" value="${form.shipAddr2}" onchange="ffUpdateBundleForm('${bundleId}','shipAddr2',this.value)"></div>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:8px;margin-top:8px;">
        <div class="ff-form-group"><label class="ff-label">Country</label>
          <select class="ff-select" onchange="ffUpdateBundleForm('${bundleId}','shipCountry',this.value)">
            <option ${(form.shipCountry||'United States')==='United States'?'selected':''}>United States</option>
            <option ${form.shipCountry==='Canada'?'selected':''}>Canada</option>
            <option ${form.shipCountry==='Mexico'?'selected':''}>Mexico</option>
          </select>
        </div>
        <div class="ff-form-group"><label class="ff-label">City</label><input class="ff-input" type="text" value="${form.shipCity}" placeholder="Tampa" onchange="ffUpdateBundleForm('${bundleId}','shipCity',this.value)"></div>
        <div class="ff-form-group"><label class="ff-label">State / Province</label><input class="ff-input" type="text" value="${form.shipState||''}" placeholder="FL" onchange="ffUpdateBundleForm('${bundleId}','shipState',this.value)"></div>
        <div class="ff-form-group"><label class="ff-label">Zip/Postal Code</label><input class="ff-input" type="text" value="${form.shipZip}" onchange="ffUpdateBundleForm('${bundleId}','shipZip',this.value)"></div>
      </div>
      <div style="border-top:1px solid var(--gray-200);margin:12px 0 10px;"></div>
      <div class="ff-panel-title" style="font-size:13px;margin-bottom:8px;">Shipping Contact</div>
      <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;">
        <div class="ff-form-group"><label class="ff-label">Contact Name</label><input class="ff-input" type="text" value="${form.contactName}" onchange="ffUpdateBundleForm('${bundleId}','contactName',this.value)"></div>
        <div class="ff-form-group"><label class="ff-label">Phone</label><input class="ff-input" type="text" value="${form.contactPhone}" onchange="ffUpdateBundleForm('${bundleId}','contactPhone',this.value)"></div>
        <div class="ff-form-group"><label class="ff-label">Email</label><input class="ff-input" type="email" value="${form.contactEmail}" onchange="ffUpdateBundleForm('${bundleId}','contactEmail',this.value)"></div>
      </div>
      ${requiresInstall ? `<div style="border-top:1px solid var(--gray-200);margin:12px 0 8px;"></div>
      <div class="ff-panel-title" style="font-size:13px;margin-bottom:8px;">Installation Address</div>
      <label style="font-size:12px;display:flex;align-items:center;gap:8px;margin-bottom:8px;">
        <input type="checkbox" class="vds-checkbox-ff" ${form.installSameAsShipping ? 'checked' : ''} onchange="ffUpdateBundleForm('${bundleId}','installSameAsShipping',this.checked);renderFFContent()">
        Installation Address is the same as shipping
      </label>
      ${!form.installSameAsShipping ? `
        ${!form.installAddressId ? `<div style="background:#FFF3CD;border:1px solid #FFC107;border-radius:6px;padding:7px 10px;font-size:11px;color:#856404;margin-bottom:8px;display:flex;align-items:center;gap:6px;"><span class="material-symbols-outlined" style="font-size:14px;">warning</span>Select a saved installation address or enter one below.</div>` : ''}
        ${savedA.length > 0 ? `<div style="background:#F0F9FF;border:1px solid #BAE6FD;border-radius:6px;padding:8px 10px;display:flex;gap:10px;align-items:center;margin-bottom:8px;flex-wrap:wrap;">
          <span class="material-symbols-outlined" style="font-size:15px;color:#0284C7;flex-shrink:0;">bookmark</span>
          <div style="display:flex;gap:8px;align-items:center;flex:1;flex-wrap:wrap;">
            <div style="display:flex;gap:6px;align-items:center;flex:1;min-width:180px;">
              <label style="font-size:11px;font-weight:700;color:#0369A1;white-space:nowrap;">Install address:</label>
              <select class="ff-select" style="flex:1;" onchange="ffUseSavedAddress('${bundleId}',this.value,'install');this.value=''">
                <option value="">— select saved —</option>
                ${savedA.map(a=>`<option value="${a.id}" ${String(form.installAddressId)===String(a.id)?'selected':''}>${a.name||'Location '+a.id}</option>`).join('')}
              </select>
            </div>
            ${savedC.length > 0 ? `<div style="display:flex;gap:6px;align-items:center;flex:1;min-width:160px;">
              <label style="font-size:11px;font-weight:700;color:#0369A1;white-space:nowrap;">Contact:</label>
              <select class="ff-select" style="flex:1;" onchange="ffUseSavedContact('${bundleId}',this.value,'install');this.value=''">
                <option value="">— select saved —</option>
                ${savedC.map(c=>`<option value="${c.id}" ${String(form.installContactId)===String(c.id)?'selected':''}>${c.name||'Contact '+c.id}</option>`).join('')}
              </select>
            </div>` : ''}
          </div>
          ${(form.installAddressId||form.installContactId) ? `<span style="font-size:10px;font-weight:700;color:#0369A1;white-space:nowrap;display:flex;align-items:center;gap:3px;"><span class="material-symbols-outlined" style="font-size:12px;">check_circle</span>Applied</span>` : ''}
        </div>` : ''}
      ` : ''}
      ` : isCMI ? `<div class="ff-cmi-notice" style="margin-top:8px;"><span class="material-symbols-outlined" style="font-size:15px;vertical-align:middle;">info</span>&nbsp; CMI selected — customer arranges device installation. No Verizon technician will be dispatched.</div>` : ''}
      <div style="border-top:1px solid var(--gray-200);margin:12px 0 8px;"></div>
      <div class="ff-panel-title" style="font-size:13px;margin-bottom:6px;">On-site Fleet Coordinator <span style="font-weight:400;color:var(--gray-400);font-size:10px;">(optional)</span></div>
      <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;">
        <div class="ff-form-group"><label class="ff-label">Name</label><input class="ff-input" type="text" value="${form.coordinatorName}" placeholder="Jane Smith" onchange="ffUpdateBundleForm('${bundleId}','coordinatorName',this.value)"></div>
        <div class="ff-form-group"><label class="ff-label">Phone</label><input class="ff-input" type="text" value="${form.coordinatorPhone}" placeholder="+1 (555) 000-0000" onchange="ffUpdateBundleForm('${bundleId}','coordinatorPhone',this.value)"></div>
        <div class="ff-form-group"><label class="ff-label">Email</label><input class="ff-input" type="email" value="${form.coordinatorEmail}" placeholder="jane@fleet.com" onchange="ffUpdateBundleForm('${bundleId}','coordinatorEmail',this.value)"></div>
      </div>
      <div style="margin-top:8px;">
        <div class="ff-form-group"><label class="ff-label">Site Access &amp; Notes <span style="font-weight:400;color:var(--gray-400);">(gate codes, hours, PPE…)</span></label>
        <textarea class="ff-textarea" style="min-height:56px;" placeholder="e.g. Gate code #4521, access Mon–Fri 7am–5pm, hard hat required" oninput="ffUpdateBundleForm('${bundleId}','siteNotes',this.value)">${form.siteNotes||''}</textarea></div>
      </div>
      <button class="ff-save-btn" style="margin-top:10px;" onclick="ffValidateBundleDetails('${bundleId}')">Save &amp; Continue</button>
      `}
      ` : (() => {
        // View mode — compact summary card
        const shipAddr = ffAddresses.find(a => String(a.id) === String(form.shipAddressId));
        const shipContact = ffContacts.find(c => String(c.id) === String(form.shipContactId));
        const installAddr = form.installSameAsShipping ? shipAddr : ffAddresses.find(a => String(a.id) === String(form.installAddressId));
        const installContact = form.installSameAsShipping ? shipContact : ffContacts.find(c => String(c.id) === String(form.installContactId));
        return `<div style="background:#F8FAFC;border:1px solid var(--gray-200);border-radius:8px;padding:12px 14px;font-size:12px;display:grid;grid-template-columns:1fr 1fr;gap:10px 20px;">
          <div style="border:1px solid var(--gray-200);border-radius:6px;padding:8px 10px;background:#FFFFFF;align-self:start;">
            <div style="font-size:10px;font-weight:700;color:var(--gray-400);text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px;">Shipping Address</div>
            <div style="font-weight:600;">${shipAddr ? shipAddr.name : '—'}</div>
            ${shipContact ? `<div style="color:var(--gray-600);margin-top:2px;">${shipContact.name}${shipContact.phone ? ' · ' + shipContact.phone : ''}${shipContact.email ? ' · ' + shipContact.email : ''}</div>` : ''}
          </div>
          ${requiresInstall ? `<div>
            <div style="font-size:10px;font-weight:700;color:var(--gray-400);text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px;">Installation Address</div>
            ${form.installSameAsShipping ? `<div style="color:var(--gray-500);font-style:italic;">Same as shipping</div>` : `<div style="font-weight:600;">${installAddr ? installAddr.name : '—'}</div>${installContact ? `<div style="color:var(--gray-600);margin-top:2px;">${installContact.name}${installContact.phone ? ' · ' + installContact.phone : ''}</div>` : ''}`}
          </div>` : `<div>
            <div style="font-size:10px;font-weight:700;color:var(--gray-400);text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px;">Install Type</div>
            <div>${isCMI ? 'CMI – Customer installs' : 'VMI – Verizon installs'}</div>
          </div>`}
          ${form.coordinatorName ? `<div>
            <div style="font-size:10px;font-weight:700;color:var(--gray-400);text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px;">On-site Coordinator</div>
            <div style="color:var(--gray-600);">${form.coordinatorName}${form.coordinatorPhone ? ' · ' + form.coordinatorPhone : ''}</div>
          </div>` : ''}
          ${form.siteNotes ? `<div style="grid-column:1/-1;">
            <div style="font-size:10px;font-weight:700;color:var(--gray-400);text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px;">Site Notes</div>
            <div style="color:var(--gray-600);">${form.siteNotes}</div>
          </div>` : ''}
        </div>`;
      })()}
    </div>
    ${isEditing ? `<div style="padding-top:16px;"><div style="background:#FFF3CD;border:1px solid #FFC107;border-radius:8px;padding:14px 16px;display:flex;align-items:center;gap:10px;font-size:12px;color:#856404;">
        <span class="material-symbols-outlined" style="font-size:18px;color:#F59E0B;">lock</span>
        <span>Save address details above before assigning vehicles.</span>
      </div></div>` : `
    <div style="padding-top:16px;">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
        <span class="ff-panel-title" style="font-size:20px;">Vehicle Assignment</span>
        <div style="width:210px;">
          <div class="ff-progress-row"><span><strong>${bv.length}</strong> / ${effectiveCap}${waveCapLabel} added</span>${waveNextLabel}</div>
          <div class="ff-progress-track">
            <div style="position:absolute;left:0;top:0;height:100%;background:#D1D5DB;border-radius:999px;width:${Math.min((bv.length/effectiveCap)*100,100)}%;"></div>
            <div class="ff-progress-orange" style="width:${Math.min(((readyN+partialN)/effectiveCap)*100,100)}%"></div>
            <div class="ff-progress-green" style="width:${Math.min((readyN/effectiveCap)*100,100)}%"></div>
          </div>
          <div style="display:flex;gap:8px;margin-top:3px;font-size:9px;color:var(--gray-600);">
            ${readyN>0?`<span style="display:flex;align-items:center;gap:3px"><span style="width:6px;height:6px;background:#1B5E20;border-radius:1px;display:inline-block"></span>${readyN} ready</span>`:''}
            ${partialN>0?`<span style="display:flex;align-items:center;gap:3px"><span style="width:6px;height:6px;background:#f97316;border-radius:1px;display:inline-block"></span>${partialN} partial</span>`:''}
            ${(bv.length-readyN-partialN)>0?`<span style="display:flex;align-items:center;gap:3px"><span style="width:6px;height:6px;background:#E5E7EB;border-radius:1px;display:inline-block;border:1px solid #ccc"></span>${bv.length-readyN-partialN} empty</span>`:''}
            ${bv.length===0?`<span style="color:var(--gray-400)">Add vehicles below</span>`:''}
          </div>
        </div>
      </div>
      <div class="ff-method-tabs ff-method-tabs--vehicle">
        <button class="ff-method-tab ff-method-tab--vehicle ${ffInputMethod==='vin'?'active':''}" onclick="ffInputMethod='vin';renderFFContent()">Option A: Bulk add via VIN</button>
        <button class="ff-method-tab ff-method-tab--vehicle ${ffInputMethod==='ymm'?'active':''}" onclick="ffInputMethod='ymm';renderFFContent()">Option B: Manual YMM entry</button>
        <button class="ff-method-tab ff-method-tab--vehicle ${ffInputMethod==='dot'?'active':''}" onclick="ffInputMethod='dot';renderFFContent()">Option C: DOT fleet lookup</button>
      </div>
      <div class="ff-method-panel">
        <div class="ff-method-panel-title">${methodMeta[ffInputMethod].title}</div>
        <div class="ff-method-panel-helper">${methodMeta[ffInputMethod].helper}</div>
        ${inputHtml}
      </div>
    </div>
    <div class="ff-panel" style="min-height:260px;">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
        <span class="ff-panel-title">Inventory Assignment</span>
        <span style="font-size:11px;color:var(--gray-600)">${bv.length} vehicles</span>
      </div>
      ${bulkHtml}
      ${rowsHtml}
    </div>
    ${wavePanel}
    `}
`;
}

function detectTelematics(make, year) {
  const y = parseInt(year, 10);
  const mk = (make || '').trim().toLowerCase();
  if (!Number.isFinite(y)) return 'Standard';
  if ((mk === 'ford' || mk === 'lincoln') && y >= 2020) return 'OEM Detected';
  if (['chevrolet', 'gmc', 'buick', 'cadillac'].includes(mk) && y >= 2015) return 'OEM Detected';
  return 'Standard';
}

function renderFFSummary() {
  const bundles = getBundles();
  const savedA  = ffAddresses.filter(a => a.saved);
  const savedC  = ffContacts.filter(c => c.saved);
  const submitted     = proposalData.fulfillmentSubmitted;
  const submitDate    = proposalData.fulfillmentSubmittedDate || '';

  const warnings = [];
  bundles.forEach(b => {
    const form  = getFFBundleForm(b.id);
    const bv    = ffVehicles[b.id] || [];
    if (bv.length === 0) warnings.push(`<strong>${b.coreName}</strong>: No vehicles added`);
    const notReady = bv.filter(v => !isVehicleReadyForBundle(v, b)).length;
    if (notReady > 0) warnings.push(`<strong>${b.coreName}</strong>: ${notReady} vehicle${notReady!==1?'s':''} missing assignment data`);
    if (!form.contactName) warnings.push(`<strong>${b.coreName}</strong>: Missing shipping contact`);
  });
  if (savedA.length === 0) warnings.push('No validated addresses on file');

  const summaryContent = buildSummaryContent(bundles, savedA, savedC);

  if (submitted) {
    return `<div class="ff-summary-submitted-banner" style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px;flex-wrap:wrap;">
      <div style="display:flex;align-items:center;gap:10px;">
        <span class="material-symbols-outlined" style="font-size:22px;color:var(--green)">check_circle</span>
        <div>
          <div style="font-weight:700;font-size:14px;">Submitted to Ops</div>
          <div style="font-size:12px;color:var(--gray-600);">Sent on ${submitDate}</div>
        </div>
      </div>
      <button type="button" class="btn btn--secondary btn--large" style="font-size:12px;padding:4px 12px;" onclick="ffAmendFulfillment()">
        <span class="material-symbols-outlined" style="font-size:13px;vertical-align:middle;margin-right:3px;">edit</span>Amend
      </button>
    </div>
    <div style="display:flex;align-items:center;gap:0;margin:16px 0;padding:12px 16px;background:var(--gray-100);border-radius:6px;font-size:11px;overflow-x:auto;">
      <span style="font-weight:700;color:var(--green);white-space:nowrap;">&#10003; ValuCal</span>
      <span style="color:var(--gray-400);margin:0 6px;">→</span>
      <span style="font-weight:600;color:var(--gray-600);white-space:nowrap;">DealHub CPQ</span>
      <span style="color:var(--gray-400);margin:0 6px;">→</span>
      <span style="font-weight:600;color:var(--gray-600);white-space:nowrap;">Ops Portal</span>
      <span style="color:var(--gray-400);margin:0 6px;">→</span>
      <span style="font-weight:600;color:var(--gray-600);white-space:nowrap;">Salesforce</span>
    </div>
    ${summaryContent}`;
  }

  return `
    ${warnings.length > 0
      ? `<div class="ff-summary-warnings">
          <div style="font-size:12px;font-weight:700;margin-bottom:8px;color:#92400e;display:flex;align-items:center;gap:6px;">
            <span class="material-symbols-outlined" style="font-size:16px;">warning</span>
            ${warnings.length} item${warnings.length!==1?'s':''} need attention before submitting
          </div>
          ${warnings.map(w=>`<div class="ff-summary-warning-item">• ${w}</div>`).join('')}
        </div>`
      : `<div class="ff-summary-ready">
          <span class="material-symbols-outlined" style="font-size:18px;">check_circle</span>
          All information complete — ready to submit to ops.
        </div>`}
    ${summaryContent}
    <div style="margin-top:24px;padding-top:20px;border-top:2px solid var(--gray-200);display:flex;justify-content:flex-end;">
      <button class="btn btn--primary btn--large" style="min-width:200px;" onclick="submitFulfillmentToOps()">
        <span class="material-symbols-outlined" style="vertical-align:middle;font-size:16px;margin-right:6px;">send</span>
        Submit to Ops
      </button>
    </div>`;
}

function buildSummaryContent(bundles, savedA, savedC) {
  return `<div style="display:flex;flex-direction:column;gap:16px;">
    ${bundles.map(b => {
      const form      = getFFBundleForm(b.id);
      const bv        = ffVehicles[b.id] || [];
      const waves     = ffWaves[b.id] || [];
      const oemCount  = bv.filter(v => v.telematics === 'OEM Detected').length;
      const stdCount  = bv.length - oemCount;
      const readyCount = bv.filter(v => isVehicleReadyForBundle(v, b)).length;
      const isCMI    = form.installType === 'cmi';

      // Resolve saved addresses and contacts
      const shipAddr  = ffAddresses.find(a => String(a.id) === String(form.shipAddressId));
      const shipAddrLabel = shipAddr ? (shipAddr.name || [shipAddr.addr1, shipAddr.city, shipAddr.state, shipAddr.zip].filter(Boolean).join(', ')) : null;
      const installAddrSame = form.installSameAsShipping;
      const installAddr = installAddrSame ? shipAddr : ffAddresses.find(a => String(a.id) === String(form.installAddressId));
      const installAddrLabel = installAddr ? (installAddr.name || [installAddr.addr1, installAddr.city, installAddr.state, installAddr.zip].filter(Boolean).join(', ')) : null;
      const shipContact = ffContacts.find(c => String(c.id) === String(form.shipContactId));
      const installContact = installAddrSame ? shipContact : ffContacts.find(c => String(c.id) === String(form.installContactId));

      return `<div class="ff-summary-bundle">
        <div class="ff-summary-bundle-header">
          <span style="font-size:15px;font-weight:800;">${b.coreName}</span>
          <span class="ff-install-type-badge ${isCMI ?'cmi' : 'vmi'}">${isCMI ? 'CMI' : 'VMI'}</span>
          <span style="font-size:11px;color:var(--gray-600);margin-left:auto;">${readyCount}/${b.qty} ready</span>
        </div>
        <div class="ff-summary-grid">
          ${shipAddrLabel ? `<div class="ff-summary-row"><span class="ff-summary-label">Ship to</span><span>${shipAddrLabel}${shipContact ? ' · ' + shipContact.name : ''}</span></div>` : ''}
          ${!installAddrSame && installAddrLabel ? `<div class="ff-summary-row"><span class="ff-summary-label">Install at</span><span>${installAddrLabel}${installContact ? ' · ' + installContact.name : ''}</span></div>` : (shipAddrLabel ? `<div class="ff-summary-row"><span class="ff-summary-label">Install at</span><span style="color:var(--gray-400)">Same as shipping</span></div>` : '')}
          ${form.coordinatorName ? `<div class="ff-summary-row"><span class="ff-summary-label">Fleet Coordinator</span><span>${form.coordinatorName}${form.coordinatorPhone?' · '+form.coordinatorPhone:''}</span></div>` : ''}
          ${form.siteNotes ? `<div class="ff-summary-row"><span class="ff-summary-label">Site Notes</span><span style="white-space:pre-wrap">${form.siteNotes}</span></div>` : ''}
          <div class="ff-summary-row"><span class="ff-summary-label">Vehicles</span><span>${bv.length} total${oemCount > 0 ? ` (${oemCount} OEM activation, ${stdCount} standard)` : ''}</span></div>
          ${bv.filter(v=>v.isEmergency).length>0?`<div class="ff-summary-row"><span class="ff-summary-label">Emergency vehicles</span><span>${bv.filter(v=>v.isEmergency).length}</span></div>`:''}
          ${bv.filter(v=>v.hasWheelchairLift).length>0?`<div class="ff-summary-row"><span class="ff-summary-label">Wheelchair lift</span><span>${bv.filter(v=>v.hasWheelchairLift).length}</span></div>`:''}
          ${bv.filter(v=>v.masterSwitchOff).length>0?`<div class="ff-summary-row"><span class="ff-summary-label">Master switch off</span><span>${bv.filter(v=>v.masterSwitchOff).length}</span></div>`:''}
          ${bv.filter(v=>v.hasCompetitorDevice).length>0?`<div class="ff-summary-row" style="background:#FFFBEB;"><span class="ff-summary-label" style="color:#92400E;">&#9888; Competitor removal</span><span style="color:#92400E;">${bv.filter(v=>v.hasCompetitorDevice).length} vehicle${bv.filter(v=>v.hasCompetitorDevice).length!==1?'s':''} — removal required at install</span></div>`:''}
          ${waves.length > 0 ? `<div class="ff-summary-row"><span class="ff-summary-label">Install Waves</span>
            <div>${waves.map(w => {
              const cnt = bv.filter(v => String(v.waveId) === String(w.id)).length;
              return `<div style="font-size:12px;margin-bottom:3px;"><strong>${w.name}</strong> — ${cnt} vehicle${cnt!==1?'s':''}${w.targetDate ? ' · target: '+new Date(w.targetDate+'T00:00:00').toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'}) : ''}</div>`;
            }).join('')}</div>
          </div>` : ''}
        </div>
      </div>`;
    }).join('')}
  </div>`;
}

function closeConfirmModal() {
  document.getElementById('confirm-selection-overlay').classList.remove('is-open');
}

function confirmAndLockDeal() {
  closeConfirmModal();
  navigateToContractReviewFromSelection();
}

function viewSignedContract() {
  document.getElementById('more-menu-deal-result')?.classList.add('hidden');
  // Go back to contract screen in read-only mode
  document.getElementById('screen-deal-result').classList.add('hidden');
  document.getElementById('screen-contract').classList.remove('hidden');
  document.getElementById('footer-back').classList.add('visible');
  screen = 'contract-review';
}

function closeContractModifyConfirmModal() {
  contractConfirmProceedAction = null;
  document.getElementById('contract-modify-overlay')?.classList.remove('is-open');
}

function toggleDealResultMenu(event) {
  if (event) {
    event.preventDefault();
    event.stopPropagation();
  }
  const m = document.getElementById('more-menu-deal-result');
  if (!m) return;
  const shouldOpen = m.classList.contains('hidden');
  setKebabMenuOpen(m, shouldOpen);
}

function closePdfViewerModal() {
  const overlay = document.getElementById('pdf-viewer-overlay');
  if (!overlay) return;
  overlay.classList.remove('open');
  document.body.style.overflow = '';
}

function openPdfViewerModal({ title, sourceHtml, filename }) {
  if (!sourceHtml || !sourceHtml.trim()) return;
  const overlay = document.getElementById('pdf-viewer-overlay');
  const titleEl = document.getElementById('pdf-viewer-title');
  const contentEl = document.getElementById('pdf-viewer-content');
  if (!overlay || !titleEl || !contentEl) return;
  titleEl.textContent = title || 'Document preview';
  contentEl.innerHTML = sourceHtml;
  pdfViewerActiveFilename = filename || 'document.pdf';
  overlay.classList.add('open');
  document.body.style.overflow = 'hidden';
}

function printPdfFromModal() {
  const content = document.getElementById('pdf-viewer-content');
  if (!content) return;
  const win = window.open('', '_blank');
  if (!win) return;
  win.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>Print preview</title><link rel="stylesheet" href="styles.css"></head><body><div class="doc-viewer">${content.innerHTML}</div></body></html>`);
  win.document.close();
  win.focus();
  setTimeout(() => win.print(), 150);
}

function openProposalPdfTab() {
  const source = document.getElementById('prop-doc-viewer')?.innerHTML || '';
  openPdfViewerModal({
    title: 'Proposal preview',
    sourceHtml: source,
    filename: 'Fleet_Solutions_Proposal.pdf',
  });
}

function openContractPdfTab() {
  const source =
    document.getElementById('contract-doc-viewer')?.innerHTML ||
    document.getElementById('contract-doc-viewer2')?.innerHTML ||
    '';
  openPdfViewerModal({
    title: 'Purchase Agreement',
    sourceHtml: source,
    filename: 'Purchase_Agreement.pdf',
  });
}

function getSlotStatusConfig(status) {
  const map = {
    'Contracted':     { label: 'Contracted',          cssClass: 'ss-contracted',     icon: 'contract',       color: '#1D4ED8' },
    'Dispatched':     { label: 'Dispatched',           cssClass: 'ss-dispatched',     icon: 'local_shipping', color: '#C2410C' },
    'Pending Bind':   { label: 'Pending Bind',         cssClass: 'ss-pending-bind',   icon: 'link',           color: '#92400E' },
    'Active-Billing': { label: 'Active \u00b7 Billing', cssClass: 'ss-active-billing', icon: 'check_circle',   color: '#166534' },
    'Suspended':      { label: 'Suspended',            cssClass: 'ss-suspended',      icon: 'pause_circle',   color: '#7E22CE' },
    'Lapsed':         { label: 'Lapsed',               cssClass: 'ss-lapsed',         icon: 'block',          color: '#6B7280' },
    'Terminated':     { label: 'Terminated',           cssClass: 'ss-terminated',     icon: 'cancel',         color: '#9CA3AF' },
  };
  return map[status] || map['Contracted'];
}

function toggleWavesEnabled() {
  proposalData.wavesEnabled = !proposalData.wavesEnabled;
  // Update menu item text to reflect state
  const menuBtn = document.getElementById('menu-wave-plan-draft');
  if (menuBtn) {
    menuBtn.textContent = proposalData.wavesEnabled
      ? '\u2714 Deployment waves (on)'
      : 'Deployment waves';
  }
  // Close the dropdown
  document.getElementById('more-menu-draft')?.classList.add('hidden');
  document.getElementById('draft-more-btn')?.setAttribute('aria-expanded', 'false');
  renderOptions();
  if (proposalData.wavesEnabled) {
    showSuccessBanner('Wave plan enabled', 'Add deployment waves to each option below. Waves will appear in the contract document.');
  }
}

function addOptWave(optId) {
  const opt = options.find(o => o.id === optId);
  if (!opt) return;
  if (!Array.isArray(opt.waves)) opt.waves = [];
  const n = opt.waves.length + 1;
  opt.waves.push({ id: Date.now(), name: 'Wave ' + n, targetDate: '', qty: 0, slotStatus: 'Contracted', appropsRef: '', appropsExpiry: '' });
  renderOptions();
}

function removeOptWave(optId, waveId) {
  const opt = options.find(o => o.id === optId);
  if (!opt || !Array.isArray(opt.waves)) return;
  opt.waves = opt.waves.filter(w => w.id !== waveId);
  renderOptions();
}

function updateOptWave(optId, waveId, field, val) {
  const opt = options.find(o => o.id === optId);
  if (!opt || !Array.isArray(opt.waves)) return;
  const wave = opt.waves.find(w => w.id === waveId);
  if (wave) wave[field] = val;
  // Re-render only the alloc badge without full render to avoid losing focus
  // For qty changes, do a targeted update of the badge
  const card = document.querySelector(`.option-card [data-wave-alloc="${optId}"]`);
  if (card && field === 'qty') {
    const optionPromoType = getOptionPromotion(opt);
    const { totalUnits } = calcOption(opt, optionPromoType, (opt.forcedTierIndex ?? -1));
    card.outerHTML = buildWaveAllocBadgeHtml(opt, totalUnits);
  }
}

function advanceOptWaveNext(optId, waveId) {
  const opt = options.find(o => o.id === optId);
  if (!opt || !Array.isArray(opt.waves)) return;
  const wave = opt.waves.find(w => w.id === waveId);
  if (!wave) return;
  const curIdx = WAVE_ADVANCE_CHAIN.indexOf(wave.slotStatus || 'Contracted');
  if (curIdx < 0 || curIdx >= WAVE_ADVANCE_CHAIN.length - 1) return; // already at end
  const nextStatus = WAVE_ADVANCE_CHAIN[curIdx + 1];
  wave.slotStatus = nextStatus;
  // In-place DOM update — no full re-render, preserves input focus
  const sc = getSlotStatusConfig(nextStatus);
  const chipEl = document.querySelector(`[data-wave-chip="${optId}-${waveId}"]`);
  const btnEl  = document.querySelector(`[data-wave-advance="${optId}-${waveId}"]`);
  if (chipEl) {
    chipEl.className = `ss-chip ${sc.cssClass}`;
    chipEl.innerHTML = `<span class="material-symbols-outlined">${sc.icon}</span>${sc.label}`;
  }
  if (btnEl) {
    const newIdx  = WAVE_ADVANCE_CHAIN.indexOf(nextStatus);
    const newNext = newIdx < WAVE_ADVANCE_CHAIN.length - 1 ? WAVE_ADVANCE_CHAIN[newIdx + 1] : null;
    if (newNext) {
      btnEl.innerHTML = `<span class="material-symbols-outlined" style="font-size:12px;">arrow_forward</span> ${newNext}`;
    } else {
      btnEl.outerHTML = `<span class="wave-advance-done"><span class="material-symbols-outlined" style="font-size:12px;">check_circle</span> Active</span>`;
    }
  }
}

function buildWaveAllocBadgeHtml(opt, totalUnits) {
  const waves = opt.waves || [];
  const allocated = waves.reduce((s, w) => s + (Number(w.qty) || 0), 0);
  const delta = totalUnits - allocated;
  if (waves.length === 0) return `<span data-wave-alloc="${opt.id}" style="font-size:10px;color:var(--gray-400)">No waves yet</span>`;
  if (delta === 0) return `<span data-wave-alloc="${opt.id}" class="wave-plan-alloc-badge wave-plan-alloc-ok">\u2713 ${allocated}\u202f/\u202f${totalUnits} allocated</span>`;
  if (delta > 0)  return `<span data-wave-alloc="${opt.id}" class="wave-plan-alloc-badge wave-plan-alloc-warn">${allocated}\u202f/\u202f${totalUnits} (\u2212${delta} unscheduled)</span>`;
  return `<span data-wave-alloc="${opt.id}" class="wave-plan-alloc-badge wave-plan-alloc-over">${allocated}\u202f/\u202f${totalUnits} (+${Math.abs(delta)} over)</span>`;
}

function buildOptWavesHtml(opt, totalUnits) {
  const waves = Array.isArray(opt.waves) ? opt.waves : [];
  const isGov = proposalData.segment === 'Government';

  const rowsHtml = waves.map(w => {
    const sc = getSlotStatusConfig(w.slotStatus || 'Contracted');
    const curAdvIdx  = WAVE_ADVANCE_CHAIN.indexOf(w.slotStatus || 'Contracted');
    const nextStatus = curAdvIdx >= 0 && curAdvIdx < WAVE_ADVANCE_CHAIN.length - 1
      ? WAVE_ADVANCE_CHAIN[curAdvIdx + 1] : null;
    const safeName = (w.name || '').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    const safeAppRef = (w.appropsRef || '').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    // Appropriations expiry warning: if targetDate > appropsExpiry, flag it
    let appropWarn = '';
    if (isGov && w.appropsExpiry && w.targetDate && w.targetDate > w.appropsExpiry) {
      appropWarn = `<div class="approp-warn"><span class="material-symbols-outlined" style="font-size:11px;">warning</span>Wave date past approp. expiry</div>`;
    }
    const govCols = isGov ? `
        <td>
          <input class="wave-plan-name-input" type="text" value="${safeAppRef}" placeholder="FY26-OA-001"
            onchange="updateOptWave(${opt.id}, ${w.id}, 'appropsRef', this.value)" style="width:100px;">
          <input class="wave-plan-date-input" type="date" value="${w.appropsExpiry || ''}" style="margin-top:4px;"
            onchange="updateOptWave(${opt.id}, ${w.id}, 'appropsExpiry', this.value)" title="Appropriations expiry date">
          ${appropWarn}
        </td>` : '';
    return `<tr>
        <td><input class="wave-plan-name-input" type="text" value="${safeName}"
          onchange="updateOptWave(${opt.id}, ${w.id}, 'name', this.value)"></td>
        <td><input class="wave-plan-date-input" type="date" value="${w.targetDate || ''}"
          onchange="updateOptWave(${opt.id}, ${w.id}, 'targetDate', this.value)"></td>
        <td><input class="wave-plan-qty-input" type="number" min="0" value="${w.qty || ''}" placeholder="0"
          oninput="updateOptWave(${opt.id}, ${w.id}, 'qty', parseInt(this.value)||0)"></td>
        <td>
          <span class="ss-chip ${sc.cssClass}" data-wave-chip="${opt.id}-${w.id}">
            <span class="material-symbols-outlined">${sc.icon}</span>${sc.label}
          </span><br>
          ${nextStatus
            ? `<button class="wave-advance-btn" data-wave-advance="${opt.id}-${w.id}" onclick="advanceOptWaveNext(${opt.id}, ${w.id})">
                <span class="material-symbols-outlined" style="font-size:12px;">arrow_forward</span> ${nextStatus}
               </button>`
            : `<span class="wave-advance-done"><span class="material-symbols-outlined" style="font-size:12px;">check_circle</span> Active</span>`
          }
        </td>
        ${govCols}
        <td><button type="button" class="btn-icon btn-icon--ghost-vds btn-icon--vds-small" onclick="removeOptWave(${opt.id}, ${w.id})" title="Remove wave" aria-label="Remove wave">
          <span class="material-symbols-outlined" aria-hidden="true">delete</span>
        </button></td>
      </tr>`;
  }).join('');

  const govTh = isGov ? `<th>Approp. ref &amp; expiry</th>` : '';
  const tableHtml = waves.length > 0
    ? `<table class="wave-plan-table">
        <thead><tr>
          <th>Wave</th>
          <th>Target date</th>
          <th>Units</th>
          <th>Slot status <span style="font-size:9px;font-weight:400;opacity:.6;">(demo \u25b6)</span></th>
          ${govTh}
          <th></th>
        </tr></thead>
        <tbody>${rowsHtml}</tbody>
      </table>`
    : `<div style="font-size:11px;color:var(--gray-400);padding:4px 0 8px;">No waves defined yet. Add waves to plan phased deployment.</div>`;

  const footnote = isGov
    ? `Lifecycle: Contracted \u2192 Dispatched \u2192 Pending\u00a0Bind \u2192 Active-Billing.
       <strong>Lapsed</strong>: appropriation expires before dispatch \u2014 no billing, inventory released (no ECF).
       Commercial lapse: 30-day grace \u2192 pool floor billing (BR-44/45).`
    : `Lifecycle: Contracted \u2192 Dispatched \u2192 Pending\u00a0Bind \u2192 Active-Billing.
       Pool floor billing activates 30\u00a0days after target date lapses undispatched (BR-44/45).`;

  return `<div class="wave-plan-section">
    <div class="wave-plan-section-header">
      <div class="wave-plan-section-title">
        <span class="material-symbols-outlined" style="font-size:14px;">waves</span>
        Deployment Waves
        ${isGov ? '<span class="segment-pill government" style="cursor:default;pointer-events:none;margin-left:4px;">Gov</span>' : ''}
      </div>
      ${buildWaveAllocBadgeHtml(opt, totalUnits)}
    </div>
    ${tableHtml}
    <button type="button" class="btn-dashed-add btn-dashed-add--pill" onclick="addOptWave(${opt.id})">
      <span class="material-symbols-outlined" style="font-size:14px;">add</span> Add wave
    </button>
    <div style="font-size:10px;color:var(--gray-400);margin-top:8px;line-height:1.6;">${footnote}</div>
  </div>`;
}

function onContractExpirationChange(sourceId) {
  if (!validateAndSyncExpirationFrom(sourceId)) return;
  renderProposalDoc();
  if (selectedOpt) renderContractDoc(selectedOpt);
}

function openQuotePdfPreview(title) {
  document.getElementById('quote-pdf-title').textContent = title || 'Quote Preview';
  document.getElementById('quote-pdf-frame').src = 'app/assets/quote-example.pdf';
  document.getElementById('quote-pdf-overlay').classList.add('is-open');
  document.body.style.overflow = 'hidden';
}

function closeQuotePdfPreview() {
  document.getElementById('quote-pdf-overlay').classList.remove('is-open');
  document.getElementById('quote-pdf-frame').src = '';
  document.body.style.overflow = '';
}

function toggleQlMenu(e, id) {
  e.stopPropagation();
  const menu = document.getElementById(id);
  if (!menu) return;
  const isOpen = !menu.classList.contains('hidden');
  document.querySelectorAll('[id^="ql-menu-"]').forEach(closeQlMenu);
  if (!isOpen) {
    menu.classList.remove('hidden');
    menu.closest('.kebab-menu')?.querySelector('.btn-icon')?.setAttribute('aria-expanded', 'true');
    // Disable Clone if a draft already exists
    const hasDraft = !!document.querySelector('#screen-quotes-list .badge--stone');
    const cloneOpt = menu.querySelector('[id^="ql-clone-"]');
    if (cloneOpt) {
      cloneOpt.disabled = hasDraft;
      cloneOpt.setAttribute('aria-disabled', String(hasDraft));
      cloneOpt.classList.toggle('is-disabled', hasDraft);
      cloneOpt.title = hasDraft ? 'A proposal is already in draft' : '';
    }
  }
}

function closeQlMenu(id) {
  const menu = typeof id === 'string' ? document.getElementById(id) : id;
  if (!menu) return;
  menu.classList.add('hidden');
  menu.closest('.kebab-menu')?.querySelector('.btn-icon')?.setAttribute('aria-expanded', 'false');
}

function qlDelete(e, id) {
  e.stopPropagation();
  const menu = document.getElementById(id);
  const row = menu?.closest('tr');
  closeQlMenu(id);
  if (!row) return;
  // Store pending row and open the reason modal
  _qlClosePendingRow = row;
  document.getElementById('mark-dead-overlay').classList.add('is-open');
  updateMarkDeadConfirmBtn();
}


/* ── Proposal PDF download (moved from both flows, identical, 2026-10-09) ── */
async function ensureHtml2PdfLoaded() {
  if (window.html2pdf) return true;
  const existing = document.getElementById('html2pdf-lib');
  if (existing) {
    await new Promise((resolve, reject) => {
      existing.addEventListener('load', () => resolve(), { once: true });
      existing.addEventListener('error', () => reject(new Error('load failed')), { once: true });
    });
    return !!window.html2pdf;
  }
  const script = document.createElement('script');
  script.id = 'html2pdf-lib';
  script.src = 'https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js';
  document.head.appendChild(script);
  await new Promise((resolve, reject) => {
    script.onload = resolve;
    script.onerror = reject;
  });
  return !!window.html2pdf;
}

async function downloadPdfFromModal() {
  const content = document.getElementById('pdf-viewer-content');
  const btn = document.getElementById('pdf-viewer-download-btn');
  if (!content || !btn) return;
  const original = btn.textContent;
  btn.disabled = true;
  btn.textContent = 'Preparing...';
  try {
    const ready = await ensureHtml2PdfLoaded();
    if (!ready || !window.html2pdf) return;
    await window.html2pdf()
      .set({
        margin: 10,
        filename: pdfViewerActiveFilename,
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2, useCORS: true },
        jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' },
        pagebreak: { mode: ['css', 'legacy'] }
      })
      .from(content)
      .save();
  } catch (err) {
    console.error('PDF generation failed', err);
  } finally {
    btn.disabled = false;
    btn.textContent = original;
  }
}


/* ══ Homologated flow functions (2026-10-09, homologation-map.md §1) ══════════════════════════════
   The same step in Initial Sales and Existing Accounts — one function now (the Initial Sales version,
   or the more complete one). What really differs between account types is a variable / hook below;
   a flow overrides a hook by declaring a function with the same name in its own script. */

// Hook: top offset of the app body under the fixed header.
function getAppTopOffset() { return 159; }
// Hook: what the account status chip opens once the account is ready (Existing: Account Validation).
function openAccountStatusDetails() { openAccountSetupEmbed(); }
// Hook: a new account's MSA takes the selected option's monthly as its minimum spend commitment;
// an existing account already has its MSA (Existing overrides with a no-op).
function setContractMsaCommitment(opt) {
  proposalData.msaMinimumSpendCommitment = calcOption(opt, getOptionPromotion(opt)).totalMonthly;
}
// Hook: after the stage stepper renders (Existing refreshes the MSA panel on every step).
function onStageNavRendered() {}

function selectOption(id) {
  bld.selectedOptionId = id;
  const optionNumber = Math.max(1, options.findIndex((o) => o.id === id) + 1);
  logProposalEvent('Option selected', `${getOptionDisplayLabel(optionNumber)} was selected.`);
  const opt = options.find((o) => o.id === id);
  if (!opt) return;

  if (!isAccountReadyForContract()) {
    pendingContractSelectionId = id;
    renderValidationPageStatus();
    openAccountValidationScreen();
    return;
  }
  pendingContractSelectionId = null;
  closeAccountValidationModal();
  openConfirmSelectionForOption(id);
}

function openQuoteCreatedStep() {
  const selectedId = bld.selectedOptionId;
  const opt = options.find((o) => o.id === selectedId);
  if (!opt) return;

  const optionNumber = Math.max(1, options.findIndex((o) => o.id === selectedId) + 1);
  const { totalMonthly } = calcOption(opt, getOptionPromotion(opt));
  const copy = document.getElementById('quote-created-copy');
  if (copy) {
    copy.innerHTML = `Quote created successfully for <strong>${getOptionDisplayLabel(optionNumber, true)}</strong> with a value of <strong>${formatMoney(totalMonthly)}/month</strong>.`;
  }

  screen = 'selection';
  hideProposalReviewModal();
  document.getElementById('screen-drafting').classList.add('hidden');
  document.getElementById('screen-proposal-selection').classList.remove('hidden');

  const sendBtn = document.getElementById('footer-send');
  sendBtn.innerText = 'Select Winning Option';
  sendBtn.classList.add('hidden');
  sendBtn.disabled = true;

  const d2 = document.getElementById('substep-dot-2');
  const d3 = document.getElementById('substep-dot-3');
  const l2 = document.getElementById('substep-line-2');
  const l3 = document.getElementById('substep-label-3');
  if (d2) d2.className = 'prop-step-dot done';
  if (d3) d3.className = 'prop-step-dot active';
  if (l2) l2.className = 'prop-line done';
  if (l3) l3.classList.remove('muted');

  document.getElementById('quote-created-state')?.classList.remove('hidden');
  document.getElementById('selection-white-card')?.classList.add('hidden');
  updateMarkDeadBtn();
  updateSendBtn();
  touchNavDate('proposal_selection');
  renderNav();
}

function openConfirmSelectionForOption(id) {
  const opt = options.find((o) => o.id === id);
  if (!opt) return;
  const optionNumber = Math.max(1, options.findIndex((o) => o.id === id) + 1);
  // 2026-09-25 (per Catalina): "necesito quitar el modal de schedule order
  // cuando le doy en select and create contract, porque eso ya no va ahí, ya
  // sería el flujo normal sin eso." Scheduling used to only be reachable by
  // auto-opening this modal when a large-quantity option was selected; now
  // that it's its own standalone entry point in the option card's kebab menu
  // (see "Scheduling" item, gated by SCHEDULE_THRESHOLD_QTY), selecting an
  // option always follows the normal confirm-selection flow regardless of
  // quantity — it no longer interrupts with the Schedule modal.
  const { totalMonthly } = calcOption(opt, getOptionPromotion(opt));
  const textEl = document.getElementById('csm-option-text');
  if (textEl) {
    textEl.innerHTML = `You selected <strong>${getOptionDisplayLabel(optionNumber, true)}</strong> with a value of <strong>${formatMoney(totalMonthly)}/month</strong>.`;
  }
  const overlay = document.getElementById('confirm-selection-overlay');
  if (overlay) overlay.classList.add('is-open');
}

function deleteOption(id) {
  const optionNumber = options.findIndex((o) => o.id === id) + 1;
  options = options.filter(o => o.id !== id && o.msaPreviewFor !== id);
  if(options.length === 0) {
    updateEmptyStateCopy();
    document.getElementById('empty-state').classList.remove('hidden');
    document.getElementById('options-grid').classList.add('hidden');
  } else {
    renderOptions();
  }
  logProposalEvent('Option edited', `${getOptionDisplayLabel(Math.max(1, optionNumber), true)} was removed.`);
}

function duplicateOption(id) {
  // 2026-10-02 (per Catalina): Clone is back for pilot options too. The copy
  // gets its own pilot config (deep-copied) and its own MSA companion, built
  // on the next render by ensureMsaPreviewOption.
  const src = options.find(o => o.id === id);
  if (!src || src.msaPreviewFor) return;
  const copy = JSON.parse(JSON.stringify(src));
  copy.id = nextOptId++;
  copy.name = 'Option ' + (options.filter(o => !o.msaPreviewFor).length + 1);
  copy.msaPreviewFor = null;
  options.push(copy);
  renderOptions();
  const optionNumber = options.findIndex((o) => o.id === copy.id) + 1;
  logProposalEvent('Option created', `${getOptionDisplayLabel(Math.max(1, optionNumber))} was duplicated.`);
}

function getWavePlanIssues() {
  if (!proposalData.wavesEnabled) return [];
  const issues = [];
  options.forEach((opt, i) => {
    const waves = Array.isArray(opt.waves) ? opt.waves : [];
    if (waves.length === 0) return; // no waves defined = no validation needed
    const optionPromoType = getOptionPromotion(opt);
    const { totalUnits } = calcOption(opt, optionPromoType, (opt.forcedTierIndex ?? -1));
    const allocated = waves.reduce((s, w) => s + (Number(w.qty) || 0), 0);
    if (allocated !== totalUnits) {
      issues.push(`${getOptionDisplayLabel(i + 1)}: ${allocated} / ${totalUnits} units scheduled in waves`);
    }
    waves.forEach((w, wi) => {
      if (!w.targetDate) issues.push(`${getOptionDisplayLabel(i + 1)}, Wave ${wi + 1}: no target date set`);
    });
  });
  return issues;
}

function saveScheduleAndProceedContract() {
  const opt = options.find(o => o.id === scheduleDraft.optionId);
  if (!opt) return;
  syncScheduleOrders();

  opt.bundles.forEach((b) => {
    b.waves = scheduleDraft.phases
      .map((phase, phaseIdx) => ({ phase, phaseIdx }))
      .filter(({ phase }) => Number(phase.allocations[b.id] || 0) > 0)
      .map(({ phase, phaseIdx }) => ({
        id: phase.id,
        name: phase.name,
        qty: Number(phase.allocations[b.id] || 0),
        daysAfterSignature: phaseIdx === 0 ? 0 : phase.daysAfterSignature,
        targetDate: getSchedulePhaseTargetDate(phase, phaseIdx)
      }));
  });

  const aggregated = [];
  opt.bundles.forEach((b) => {
    scheduleDraft.phases.forEach((phase, phaseIdx) => {
      const qty = Number(phase.allocations[b.id] || 0);
      if (qty > 0) {
        aggregated.push({
          bundleId: b.id,
          coreName: b.coreName,
          name: phase.name,
          qty,
          daysAfterSignature: phaseIdx === 0 ? 0 : phase.daysAfterSignature,
          targetDate: getSchedulePhaseTargetDate(phase, phaseIdx)
        });
      }
    });
  });
  opt.waves = aggregated;

  closeScheduleModal();

  if (screen === 'contract-review') {
    selectedOpt = opt;
    renderContractDoc(opt);
    showSuccessBanner('Service order schedule updated', 'Contract terms and installation schedule were refreshed.');
    return;
  }

  // 2026-09-25 (per Catalina — "el save te debería como regresar a la
  // pantalla de las cards de opciones, no triggerar ningún otro proceso
  // adicional"): this modal is a standalone scheduling tool reachable from
  // the option card's kebab menu at any point, not a step that commits to
  // that option — Save just persists the schedule and returns to the option
  // cards screen, it no longer selects the option or advances the proposal
  // (previously called confirmSelectionAndProceed(), which moved past this
  // screen entirely).
  renderOptions();
  if (screen === 'selection') renderSelectionOptions();
  showSuccessBanner('Service order schedule saved', `${getOptionDisplayLabel(Math.max(1, options.findIndex((o) => o.id === opt.id) + 1), true)}'s schedule has been updated.`);
}

function openUnsavedProposalModal() {
  const overlay = document.getElementById('proposal-save-name-overlay');
  const title = document.getElementById('proposal-save-name-title');
  const body = document.getElementById('proposal-save-name-body');
  const actions = document.getElementById('proposal-save-name-actions');

  if (title) title.textContent = 'Unsaved proposal';
  if (body) body.textContent = 'Your proposal has not been saved. Do you want to save it before leaving?';
  if (actions) {
    actions.innerHTML = '<button type="button" class="btn btn--secondary btn--large" onclick="leaveWithoutSavingProposal()">Don\'t save</button>'
      + '<button type="button" class="btn btn--primary btn--large" onclick="confirmSaveAndLeaveProposal()">Save and leave</button>';
  }
  overlay?.classList.add('is-open');
}

function closeProposalSaveNameModal() {
  document.getElementById('proposal-save-name-overlay')?.classList.remove('is-open');
}

function openCaseStudiesModal() {
  const overlay = document.getElementById('case-studies-overlay');
  const frame = document.getElementById('case-studies-frame');
  if (!overlay || !frame) return;
  if (frame.getAttribute('src') === 'about:blank') {
    frame.setAttribute('src', 'case studies/caseStudies.html');
  }
  overlay.classList.add('is-open');
  document.body.style.overflow = 'hidden';
}

function goBack() { 
  if(screen==='review') { 
    closeProposalReviewModal();
  } else if (screen === 'selection') {
    screen = 'review';
    renderNav();
    document.getElementById('screen-proposal-selection').classList.add('hidden');
    document.getElementById('screen-drafting').classList.remove('hidden');
    showProposalReviewModal();

    document.getElementById('substep-dot-2').className = 'prop-step-dot active';
    document.getElementById('substep-dot-3').className = 'prop-step-dot pending';
    document.getElementById('substep-line-2').className = 'prop-line';
    document.getElementById('substep-label-3').classList.add('muted');
    
    renderProposalDoc();
  } else if (screen === 'contract-review') {
    // If in phase 2 (sign&pay), go back to phase 1 (review form)
    const phase2 = document.getElementById('contract-phase-signpay');
    if (phase2 && !phase2.classList.contains('hidden')) {
      clearSignatureCompletionSimulation();
      phase2.classList.add('hidden');
      document.getElementById('contract-phase-review').classList.remove('hidden');
      document.getElementById('contract-sub-stepper')?.classList.add('hidden');
      contractSubState = 'pre-send';
      // Restore stepper to step 1
      const d1=document.getElementById('c-dot-1');const d2=document.getElementById('c-dot-2');const l1=document.getElementById('c-line-1');
      if(d1)d1.className='c-step-dot active';if(d2)d2.className='c-step-dot pending';if(l1)l1.className='c-line';
      if(document.getElementById('c-dot-label-2'))document.getElementById('c-dot-label-2').className='c-step-label muted';
      const contractSendBtn = document.getElementById('contract-send-btn');
      if (contractSendBtn) {
        contractSendBtn.classList.remove('hidden');
        contractSendBtn.innerText='Send E-Sign Link';
      }
      document.getElementById('footer-back').classList.remove('visible');
      document.getElementById('footer-back').classList.add('hidden');
      return;
    }
    screen = 'selection'; 
    document.getElementById('screen-contract').classList.add('hidden');
    document.getElementById('screen-proposal-selection').classList.remove('hidden');
    // sub-stepper removed — nav is in header
    document.getElementById('vc-body').style.paddingTop = `${getAppTopOffset()}px`;
    document.getElementById('success-banner').style.top = `${getAppTopOffset()}px`;
    document.getElementById('footer-send').innerText = 'Select Winning Option';
    document.getElementById('footer-back').classList.remove('hidden');
    
    const sendBtn = document.getElementById('footer-send');
    sendBtn.onclick = () => {
       sendBtn.disabled = true;
    };
    
    renderSelectionOptions();
    updateMarkDeadBtn();
  }
}

function selectionMenuEditProposal() {
  closeSelectionMoreMenu();
  // Editing from Selection returns user to Drafting first.
  screen = 'drafting';
  document.getElementById('screen-proposal-selection').classList.add('hidden');
  hideProposalReviewModal();
  document.getElementById('screen-contract').classList.add('hidden');
  document.getElementById('screen-deal-result').classList.add('hidden');
  document.getElementById('screen-drafting').classList.remove('hidden');
  document.getElementById('vc-body').style.paddingTop = `${getAppTopOffset()}px`;
  document.getElementById('success-banner').style.top = `${getAppTopOffset()}px`;
  const sendBtn = document.getElementById('footer-send');
  sendBtn.classList.add('hidden');
  sendBtn.innerText = 'Send Proposal';
  sendBtn.onclick = handleSend;
  updateSendBtn();
  const backBtn = document.getElementById('footer-back');
  backBtn.classList.remove('visible');
  renderOptions();
  const hasOptions = Array.isArray(options) && options.length > 0;
  updateEmptyStateCopy();
  document.getElementById('empty-state')?.classList.toggle('hidden', hasOptions);
  document.getElementById('options-grid')?.classList.toggle('hidden', !hasOptions);
  updateMarkDeadBtn();
  renderNav();
}

function navigateToContractReviewFromSelection() {
  clearSignatureCompletionSimulation();
  const optId = bld.selectedOptionId;
  const opt = options.find((o) => o.id === optId);
  if (!opt) return false;
  const optionNumber = options.findIndex((o) => o.id === optId) + 1;

  proposalData.lockedTerm = opt.term;
  setContractMsaCommitment(opt);
  logProposalEvent('Contract created', `Created from ${getOptionDisplayLabel(optionNumber, true)} — ${opt.term}-month term locked.`);

  screen = 'contract-review';

  hideProposalReviewModal();
  document.getElementById('screen-proposal-selection').classList.add('hidden');
  document.getElementById('screen-drafting').classList.add('hidden');
  document.getElementById('options-grid').classList.add('hidden');

  document.getElementById('screen-contract').classList.remove('hidden');

  document.querySelector('.vc-main-stepper').classList.remove('hidden');
  document.getElementById('step-dot-1').className = 'vc-step-dot done';
  document.getElementById('step-dot-1').innerHTML =
    '<span class="material-symbols-outlined">check</span>';
  document.getElementById('step-label-1').classList.remove('muted');
  document.getElementById('step-dot-2').className = 'vc-step-dot active';
  document.getElementById('step-label-2').classList.remove('muted');

  document.getElementById('vc-body').style.paddingTop = `${getAppTopOffset()}px`;

  document.getElementById('footer-send').innerText = 'Send E-Sign Link';
  document.getElementById('footer-send').disabled = false;

  const banner = document.getElementById('success-banner');
  banner.style.top = `${getAppTopOffset()}px`;
  showSuccessBanner(
    'Contract has been created',
    'Your contract was successfully generated. Review the message and send the e-sign link.'
  );

  document.getElementById('screen-drafting').classList.add('hidden');

  touchNavDate('proposal');
  touchNavDate('proposal_selection');
  enterContractScreen(opt);
  renderNav();
  return true;
}

function scaleDocPages() {
  document.querySelectorAll('.doc-page-outer').forEach(outer => {
    const page = outer.querySelector('.vc-doc-shell');
    if (!page) return;
    const containerW = outer.clientWidth;
    if (!containerW) return;
    const sidePad = 16;
    const availW = containerW - sidePad * 2;
    const scale = availW / 794;
    const scaledW = 794 * scale;
    const offsetX = Math.max(sidePad, (containerW - scaledW) / 2);
    page.style.transform = `scale(${scale})`;
    page.style.transformOrigin = 'top left';
    page.style.marginLeft = offsetX + 'px';
    outer.style.height = Math.ceil(page.scrollHeight * scale + sidePad * 2) + 'px';
  });
}

function getSchedulePhaseTargetDate(phase, idx) {
  const days = idx === 0 ? 0 : Math.max(0, Number(phase.daysAfterSignature) || 0);
  const d = new Date();
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}

function openOptionScheduleFromCard(optId) {
  const opt = options.find(o => o.id === optId);
  if (!opt) return;
  openScheduleModal(opt);
}

function dismissSuccessBanner() {
  document.getElementById('success-banner')?.classList.add('hidden');
  document.getElementById('vc-body')?.classList.remove('has-banner');
}

function proceedContractModifyFromContract() {
  if (contractConfirmProceedAction === 'view-contract') {
    closeContractModifyConfirmModal();
    viewSignedContract();
    return;
  }
  closeContractModifyConfirmModal();
  clearSignatureCompletionSimulation();
  contractResendMode = false;
  contractResendReturnState = 'waiting';
  contractSubState = 'pre-send';
  logProposalEvent('Contract returned to drafting', 'Contract flow was sent back to Drafting.');
  selectionMenuEditProposal();
}

function applyAccountReadyState() {
  const badge = document.getElementById('account-badge');
  if (badge) {
    badge.className = 'badge-ready';
    badge.innerHTML = 'Account ready';
    badge.onclick = null;
    badge.style.cursor = 'default';
  }

  const trigger = document.getElementById('account-status-trigger');
  if (trigger) {
    trigger.onclick = openAccountStatusDetails;
    trigger.style.cursor = 'pointer';
  }

  const banner = document.getElementById('warning-banner');
  if (banner) {
    banner.classList.add('hidden');
    const body = document.getElementById('vc-body');
    if (body) body.classList.remove('has-banner');
  }
}

function updateMarkDeadBtn() {
  const hasAnyBundle = options.some(opt => opt.bundles && opt.bundles.length > 0);
  const draftMenuWrap = document.getElementById('draft-more-wrap');
  if (draftMenuWrap) draftMenuWrap.classList.remove('hidden');
  if (!hasAnyBundle) {
    document.getElementById('more-menu-draft')?.classList.add('hidden');
    document.getElementById('draft-more-btn')?.setAttribute('aria-expanded', 'false');
  }
  ['menu-mark-dead-draft', 'menu-mark-dead-selection'].forEach((id) => {
    const menuItem = document.getElementById(id);
    if (!menuItem) return;
    if (id === 'menu-mark-dead-selection') {
      menuItem.disabled = !hasAnyBundle;
      menuItem.setAttribute('aria-disabled', String(!hasAnyBundle));
      menuItem.classList.toggle('is-disabled', !hasAnyBundle);
    } else {
      menuItem.classList.toggle('is-disabled', !hasAnyBundle);
    }
    if (id === 'menu-mark-dead-draft') {
      menuItem.classList.toggle('hidden', !hasAnyBundle);
      document.getElementById('menu-mark-dead-draft-divider')?.classList.toggle('hidden', !hasAnyBundle);
    }
  });
  const historyItem = document.getElementById('menu-view-history-draft');
  if (historyItem) {
    historyItem.classList.toggle('is-disabled', !proposalWasSentToCustomer);
    historyItem.classList.toggle('hidden', !proposalWasSentToCustomer);
  }
}

function renderNav() {
  const el = document.getElementById('vc-nav');
  if (!el) return;
  touchCurrentStepDates();

  // ── Map screen → active step (1=Proposal, 2=Contract, 3=Deal Result) ──
  // Updated 2026-09-16 (R7 follow-up, per Catalina): this stepper was still showing
  // the old pre-Contract "Drafting / Review & send / Create Contract" proposal
  // sub-phases, collapsing to "all done" once the contract screen was reached —
  // it never actually surfaced "Contract" or "Deal Result" as real stages, even
  // though those screens have existed and worked since R7. Now matches the
  // Proposal → Contract → Deal Result top-level model already used in
  // ValuCal-FutureVersion/index.html (drafting/review/selection all collapse into
  // the single "Proposal" stage, same as that file's renderNav()).
  let activeStep = 1;
  if      (screen === 'drafting' || screen === 'review' || screen === 'selection') activeStep = 1;
  else if (screen === 'contract-review')                                           activeStep = 2;
  else if (screen === 'deal-result')                                               activeStep = 3;

  const dates = window._navDates || {};
  const milestoneLabels = {
    Proposal: new Map([
      ['Proposal saved', 'Draft saved'],
      ['Review & send started', 'Review started'],
      ['Proposal sent', 'Proposal sent'],
      ['Proposal re-sent', 'Proposal re-sent'],
    ]),
    Contract: new Map([
      ['Contract created', 'Contract created'],
      ['Contract sent', 'Contract sent'],
      ['Contract re-sent', 'Contract re-sent'],
      ['Payment setup configured', 'Payment setup completed'],
      ['Contract signed', 'Contract signed'],
    ]),
  };
  const formatStageMilestoneDate = value => {
    const date = value instanceof Date ? value : new Date(value);
    return Number.isNaN(date.getTime()) ? '--' : new Intl.DateTimeFormat('en-US', { month: 'short', day: 'numeric', year: 'numeric' }).format(date);
  };
  const stageMilestones = phase => proposalHistoryEvents
    .filter(event => getHistoryPhaseForEvent(event) === phase && milestoneLabels[phase]?.has(event.title))
    .slice()
    .sort((a, b) => new Date(a.at) - new Date(b.at))
    .map(event => ({ label: milestoneLabels[phase].get(event.title), date: formatStageMilestoneDate(event.at) }));

  const steps = [
    { num: 1, label: 'Proposal',    date: dates.proposal_selection, milestones: stageMilestones('Proposal') },
    { num: 2, label: 'Contract',    date: dates.contract_review_send, milestones: stageMilestones('Contract') },
    { num: 3, label: 'Deal Result', date: dates.result, milestones: stageMilestones('Deal Result') },
  ];

  el.innerHTML = VC.stageStepper({ idPrefix: 'main-stage', steps, activeStep });
  updateReviewBackToSelectionHint();
  onStageNavRendered();
}

function updateEmptyStateCopy() {
  const titleEl = document.getElementById('empty-state-title');
  const bodyEl = document.getElementById('empty-state-body');
  const btnEl = document.getElementById('empty-state-btn');
  if (!titleEl || !bodyEl || !btnEl) return;
  // 2026-10-09 (per Catalina): Pilot reuses the new-account copy (same components, same texts).
  titleEl.textContent = 'No pricing options yet';
  bodyEl.textContent = 'Start by adding your first pricing option. You can configure solutions and contract terms once you add an option.';
  btnEl.textContent = '+ Add option';
}

function openContractScheduleModal() {
  document.getElementById('more-menu-contract')?.classList.add('hidden');
  document.getElementById('more-menu-contract2')?.classList.add('hidden');
  document.getElementById('more-menu-contract-preview')?.classList.add('hidden');

  const opt = (typeof selectedOpt !== 'undefined' && selectedOpt) || options.find((o) => o.id === bld.selectedOptionId) || (Array.isArray(options) && options.length ? options[0] : null);
  if (!opt) return;
  openScheduleModal(opt);
}

function viewProposalHistory() {
  closeSelectionMoreMenu();
  document.getElementById('more-menu-draft')?.classList.add('hidden');
  document.getElementById('draft-more-btn')?.setAttribute('aria-expanded', 'false');
  document.getElementById('more-menu-contract')?.classList.add('hidden');
  document.getElementById('more-menu-contract2')?.classList.add('hidden');
  document.getElementById('more-menu-contract-preview')?.classList.add('hidden');
  openProposalHistoryModal();
}

function handleBreadcrumbProposals() {
  // Existing Accounts: Renewal / Rewrap / Reactivation return straight to the dashboard.
  if (proposalData.entryPoint && proposalData.entryPoint !== 'newProposal') {
    openQuotesList();
    return;
  }
  if (proposalIsSaved) {
    openQuotesList();
    return;
  }
  openUnsavedProposalModal();
}
