/* Valu Cal — pricing engine (shared by Initial Sales and Existing Accounts)
   Source: Initial Sales (reference). 2026-10-07 (Catalina): Existing adopts the Initial Sales rule —
   promotions with "MEDIA" in the name carry the Media type: −20% on camera solutions on top of the
   promotion's own discount and the discretionary discount.
   calcBundle(bundle, term, promoType, tierQty) — tierQty = MSA tier units used for the Tier/Term discount.
   Helpers it uses (getTierTermDiscountPct, getPromoMultiplier, getPromoNameMultiplier) live in
   vc-configure-solution.js for now; they move here when Initial Sales is wired to this file. */

function calcBundle(bundle, termStr, promoType, tierQty = null) {
  const term = parseInt(termStr) || 36;
  const qtyBasis = tierQty == null ? bundle.qty : tierQty;
  const promoMult = (1 - ((bundle.msaDiscountPct || 0) / 100)) * getPromoMultiplier(bundle.coreKey, promoType) * getDealCloserMultiplier(bundle.dealCloser);
  const promoNameMult = getPromoNameMultiplier(bundle.promoName, term);

  // Existing Accounts only: units of the current contract shown as auxiliary MSA rows
  // (no promotion name; Tier/Term only when they are a Feature Upsell).
  if (bundle.isMsaAuxiliary) {
    const auxTierTermPct = bundle.isolatedTransactionType === 'upsell' ? getTierTermDiscountPct(term, qtyBasis) : 0;
    const auxTierTermMult = 1 - (auxTierTermPct / 100);
    const auxPromoMult = 1 - ((bundle.msaDiscountPct || 0) / 100);
    const auxUnitPrice = bundle.basePrice * auxTierTermMult * auxPromoMult;
    return { unitPrice: auxUnitPrice, monthly: auxUnitPrice * bundle.qty, tier: { label: bundle.isolatedTransactionType === 'upsell' ? `${auxTierTermPct}%` : 'MSA auxiliary' }, tierTermPct: auxTierTermPct, tierTermMult: auxTierTermMult, tierMult: auxTierTermMult, promoMult: auxPromoMult, termMult: auxTierTermMult };
  }

  // R29 (2026-09-23): single combined Tier/Term discount, replacing the old
  // deck-price-at-36-months special case (quantity-only) and the term-only
  // multiplier used for every other term — see getTierTermDiscountPct above.
  const tierTermPct = getTierTermDiscountPct(term, qtyBasis);
  const tierTermMult = 1 - (tierTermPct / 100);
  const unitPrice = bundle.basePrice * tierTermMult * promoMult * promoNameMult;
  const monthly = unitPrice * bundle.qty;
  return { unitPrice, monthly, tier: { label: `${tierTermPct}%` }, tierTermPct, tierTermMult, promoMult, promoNameMult, termMult: tierTermMult };
}

// Shared option aggregation. Flow-specific band, eligibility, custom-promo,
// and pilot rules enter as hooks; the pricing loop and totals stay common.
window.VC = window.VC || {};
window.VC.standardTierTermDiscount = function standardTierTermDiscount(term, units) {
  const rows = [
    { min: 1, max: 24, pct: [5, 9, 14, 17] },
    { min: 25, max: 49, pct: [9, 13, 18, 21] },
    { min: 50, max: 99, pct: [14, 18, 23, 26] },
    { min: 100, max: 9999, pct: [18, 22, 27, 30] },
  ];
  const row = rows.find(item => units >= item.min && units <= item.max) || rows[0];
  const column = [12, 24, 36, 48].findIndex(months => (Number(term) || 12) <= months);
  return row.pct[column < 0 ? 3 : column];
};

window.VC.standardBaseOptionPrice = function standardBaseOptionPrice(option, catalog) {
  const bundles = option.bundles || [];
  const totalUnits = bundles.reduce((sum, bundle) => sum + bundle.qty, 0);
  const tierUnits = bundles.reduce((sum, bundle) => sum + (['vtu-ffc', 'vtu-dual'].includes(bundle.coreKey) ? bundle.qty * 2 : bundle.qty), 0);
  const discountPct = window.VC.standardTierTermDiscount(option.term, tierUnits);
  const listMonthly = bundles.reduce((sum, bundle) => sum + catalog[bundle.coreKey].price * bundle.qty, 0);
  return { totalUnits, tierUnits, discountPct, listMonthly, contractedMonthly: listMonthly * (1 - discountPct / 100) };
};

window.VC.calcOption = function calcOption(opt, promoType = 'Standard', hooks = {}) {
  const bundles = Array.isArray(opt?.bundles) ? opt.bundles : [];
  const includedBundles = bundles.filter(bundle => !hooks.includeBundle || hooks.includeBundle(bundle, opt));
  const totalUnits = includedBundles.reduce((sum, bundle) => sum + (Number(hooks.getUnits ? hooks.getUnits(bundle, opt) : bundle.qty) || 0), 0);
  const tierBundles = includedBundles.filter(bundle => !hooks.includeInTierUnits || hooks.includeInTierUnits(bundle, opt));
  const msaTierUnits = Math.max(0, tierBundles.reduce((sum, bundle) => sum + (Number(hooks.getMsaTierUnits ? hooks.getMsaTierUnits(bundle, opt) : (typeof getMsaTierQty === 'function' ? getMsaTierQty(bundle.qty, bundle.coreKey) : bundle.qty)) || 0), 0));
  const tierQty = hooks.getTierQty ? hooks.getTierQty(opt, tierBundles, msaTierUnits) : msaTierUnits;
  const term = hooks.getTerm ? hooks.getTerm(opt) : opt.term;
  let totalMonthly = 0;

  includedBundles.forEach(bundle => {
    const pricedBundle = hooks.prepareBundle ? hooks.prepareBundle(bundle, opt) : bundle;
    const bundlePromo = hooks.getBundlePromotion
      ? hooks.getBundlePromotion(bundle, opt, promoType)
      : (bundle.promoType || promoType);
    const result = calcBundle(pricedBundle, term, bundlePromo, tierQty);
    const customPromoUnit = hooks.getCustomPromotionAmount
      ? Number(hooks.getCustomPromotionAmount(bundle, opt, result.unitPrice, result, tierQty)) || 0
      : 0;
    const bundleMonthly = hooks.getBundleMonthly
      ? hooks.getBundleMonthly(bundle, opt, result, customPromoUnit)
      : Math.max(0, result.monthly - customPromoUnit * bundle.qty);
    totalMonthly += Number(bundleMonthly) || 0;
  });

  if (hooks.adjustTotalMonthly) totalMonthly = Number(hooks.adjustTotalMonthly(totalMonthly, opt)) || 0;
  const avgUnit = totalUnits > 0 ? totalMonthly / totalUnits : 0;
  return { totalMonthly, totalUnits, msaTierUnits, tierQty, term, avgUnit };
};

window.VC.customPromotionAmount = function customPromotionAmount(props = {}) {
  const { bundleId, promotions = [], components = [], onlyComponent, getAmount } = props;
  if (typeof getAmount !== 'function') return 0;
  let total = 0;
  promotions.forEach(promotion => {
    (promotion.targets || [])
      .filter(target => target.bundleId === bundleId && (!onlyComponent || target.component === onlyComponent))
      .forEach(target => {
        const component = components.find(item => item.name === target.component);
        if (component) total += Number(getAmount(promotion, target, component)) || 0;
      });
  });
  return total;
};

window.VC.aggregateOptionTotals = function aggregateOptionTotals(opt, getBundleTotals, hooks = {}) {
  const totals = { ...(hooks.initialTotals || {}) };
  const bundles = Array.isArray(opt?.bundles) ? opt.bundles : [];
  bundles.forEach(bundle => {
    if (hooks.includeBundle && !hooks.includeBundle(bundle, opt)) return;
    const bundleTotals = getBundleTotals(bundle, opt) || {};
    Object.keys(bundleTotals).forEach(key => {
      totals[key] = (Number(totals[key]) || 0) + (Number(bundleTotals[key]) || 0);
    });
  });
  return hooks.adjustTotals ? (hooks.adjustTotals(totals, opt) || totals) : totals;
};

window.VC.priceListUnitBreakdown = function priceListUnitBreakdown(props = {}) {
  const listUnit = Number(props.listUnit) || 0;
  const tierTermPct = Number(props.tierTermPct) || 0;
  const afterTierTermUnit = listUnit * (1 - tierTermPct / 100);
  const discretionaryUnit = props.discretionaryUnit != null
    ? Number(props.discretionaryUnit) || 0
    : afterTierTermUnit * ((Number(props.discretionaryPct) || 0) / 100);
  const contractCustomAmount = Number(props.contractCustomAmount) || 0;
  const msaUnit = props.msaUnitOverride != null
    ? Number(props.msaUnitOverride) || 0
    : afterTierTermUnit - Math.max(discretionaryUnit, contractCustomAmount);
  return {
    tierTermUnit: listUnit - afterTierTermUnit,
    afterTierTermUnit,
    discretionaryUnit,
    msaUnit,
  };
};

function getDealCloserMultiplier(dealCloser) {
  return dealCloser ? 0.9 : 1;
}

function formatMoney(n) {
  const value = Number(n) || 0;
  const abs = Math.abs(value).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  return (value < -0.004 ? '-$' : '$') + abs;
}

// Price cell (Contracted price with list price struck through + MSA tooltip) — shared, batch 8.
function buildMsaPriceCellHtml(msaUnit, isCapexSplit, oneTimeUnit) {
  if (!isCapexSplit) return `<div class="sub-price-msa-value">${formatMoney(msaUnit)}</div>`;
  return `<div class="sub-price-msa-split"><span class="sub-price-msa-split-label">Monthly</span><span>${formatMoney(msaUnit)}</span></div><div class="sub-price-msa-split"><span class="sub-price-msa-split-label">Hardware (one-time)</span><span>${oneTimeUnit > 0.005 ? formatMoney(oneTimeUnit) : '—'}</span></div>`;
}

// Contracted Price column header — plain label (2026-10-07, Catalina: tooltip removed).
function buildMsaPriceHeaderLabelHtml() {
  return '<span class="sub-price-msa-header">Contracted Price</span>';
}

/* ── Custom Promotion duration bar (Ramp-up → Promotion → After promo) ── */
function buildPromoDurationTimelineHtml(opt, cp, durationMode) {
  // Shared 2026-10-07 (from Initial Sales): Existing Accounts had lost the Ramp-up segment.
  // Needs flow globals: proposalData.msaRampUpPeriod, computeCustomPromoTimelineTotals, formatMoney.
  const termMonths = Math.max(1, Number(opt.term) || 1);
  const totalDays = termMonths * 30;
  const rampUpDays = Math.max(0, Number(proposalData.msaRampUpPeriod) || 30);
  const rampUpPct = Math.min(100, (rampUpDays / totalDays) * 100);
  const { totalCurrent, totalDuringPromo } = computeCustomPromoTimelineTotals(opt, cp);
  let rangeHtml = '';
  let showsAfterPromoSegment = false;
  // 2026-09-24, later the same day (per Catalina — "esto está mal porque no
  // hemos seleccionado la duración y ya está pintando azul"): the old
  // behavior painted the whole bar blue by default, since a fresh custom
  // promotion's durationMode defaults to 'term' — but the standalone "Same
  // as contract term" button was removed the same day (folded into the
  // preset row as "Contract length"), so 'term' is no longer a real choice
  // a rep can make — it's just the unset starting state before any preset
  // is clicked. Painting it blue made an unmade choice look already made.
  // Now the bar only turns blue once a preset (including "Contract length")
  // has actually been clicked, i.e. cp.durationMonths is set.
  const hasDurationSelected = durationMode === 'term' || (durationMode === 'months' && !!cp.durationMonths);
  if (hasDurationSelected) {
    const selectedDurationMonths = durationMode === 'term' ? termMonths : cp.durationMonths;
    // Promo always starts right after Ramp-up ends — no real contract/order
    // start date exists in this prototype, so there's nothing else to pick
    // a start point from.
    const widthPct = Math.max(0, Math.min(100 - rampUpPct, (selectedDurationMonths * 30 / totalDays) * 100));
    rangeHtml = `<div class="promo-timeline-range" style="left:${rampUpPct}%;width:${widthPct}%;" title="Promotion active — ${formatMoney(totalDuringPromo)}/mo"></div>`;
    // 2026-09-24 (per Catalina): once the promo's fixed duration ends
    // partway through the contract, the rest of the term goes back to
    // paying the regular (no-promo) price — call that out too, not just
    // ramp-up and the promo itself.
    showsAfterPromoSegment = (rampUpPct + widthPct) < 99.5;
  }
  const afterPromoLegendHtml = !showsAfterPromoSegment ? '' : `
        <span class="promo-timeline-legend-item promo-timeline-legend-item--end"><span class="promo-timeline-legend-swatch" style="background:var(--gray-300);"></span><strong class="promo-timeline-legend-label">After promo</strong> ${formatMoney(totalCurrent)}</span>`;
  // Same "nothing selected yet" fix applied to the legend: don't claim the
  // promotion is active (with a computed $/mo) before a duration preset has
  // actually been clicked.
  const promoLegendHtml = hasDurationSelected
    ? `<span class="promo-timeline-legend-item"><span class="promo-timeline-legend-swatch" style="background:var(--brand-blue);"></span><strong class="promo-timeline-legend-label">Promotion</strong> ${formatMoney(totalDuringPromo)}</span>`
    : `<span class="promo-timeline-legend-item" style="color:var(--gray-500);"><span class="promo-timeline-legend-swatch" style="background:var(--gray-300);"></span>Select a duration below</span>`;
  return `
    <div class="promo-timeline">
      <div class="promo-timeline-bar">
        <div class="promo-timeline-rampup" style="width:${rampUpPct}%;" title="Ramp-up period (${rampUpDays}d, no billing yet)"></div>
        ${rangeHtml}
      </div>
      <div class="promo-timeline-legend">
        <span class="promo-timeline-legend-item"><span class="promo-timeline-legend-swatch" style="background:var(--green);"></span><strong class="promo-timeline-legend-label">Ramp-up</strong> $0.00</span>
        ${promoLegendHtml}
        ${afterPromoLegendHtml}
      </div>
      <div class="promo-timeline-labels">
        <span>Start</span>
        <span>End (${termMonths}mo)</span>
      </div>
    </div>`;
}
