/* ── Valu Cal domain model (shared, 2026-10-09) ─────────────────────────────────────────────────
   Data + rules from Leo's "ValuCal MSA — how the pieces fit" (project spec §3–§4, engine 2026-10-07).
   The account and the door the rep uses decide the transaction type; the type decides the modes each
   Option may take; the mode (axis 1) and the account's Purchase Mode (axis 2) decide the motions a
   bundle may carry. Pure data and functions, no DOM.

   VC_DOMAIN.resolve({ accountType, contractedPilot, cancellation, purchaseMode, entryPoint })
     → { ok, transaction, modes, motionsByMode, bundleKinds, maxOptions, controls, … } */
(function (global) {
  var ACCOUNT_TYPES = [
    { id: 'prospect', label: 'Prospect (new account)' },
    { id: 'pilot', label: 'Pilot' },
    { id: 'customer', label: 'Customer (existing account)' },
  ];
  var CANCELLATION = [
    { id: 'none', label: 'None' },
    { id: 'partial', label: 'Partial' },
    { id: 'full', label: 'Full (inactive account)' },
  ];
  var PURCHASE_MODES = [
    { id: 'mixed', label: 'Mixed — plan bundles and à la carte' },
    { id: 'bundle', label: 'Bundle — plan bundles only' },
    { id: 'a-la-carte', label: 'À la carte only' },
  ];
  var COST_TYPES = [
    { id: 'mixed', label: 'Mixed — Capex and Opex' },
    { id: 'opex', label: 'Opex only' },
    { id: 'capex', label: 'Capex only' },
  ];
  var PAYMENT_METHODS = [
    { id: 'autopay', label: 'Autopay' },
    { id: 'direct-bill', label: 'Direct bill' },
  ];

  var ENTRY_POINTS = {
    newProposal: 'New proposal',
    renewalRewrap: 'Renewal / Rewrap',
    reactivationReinstatement: 'Reactivation / Reinstatement',
    pilotExtension: 'Pilot extension',
    pilotCancellation: 'Pilot cancellation',
    fullCancellation: 'Full cancellation',
    nonRenewal: 'Non-renewal (WNNR)',
  };

  // release: 'v1-screens' (v1 builds screens) · 'v1-engine' (rules in the engine, screens later) · 'v2'
  var TRANSACTIONS = {
    'pilot':                     { label: 'Pilot', shape: 'proposal', modes: [], noModeMotions: ['pilot'], touchesMsa: 'No', release: 'v1-screens' },
    'initial-sale':              { label: 'Initial Sale', shape: 'proposal', modes: [], noModeMotions: ['initial'], touchesMsa: 'Yes — writes it', release: 'v1-screens' },
    'pilot-conversion':          { label: 'Pilot Conversion', shape: 'proposal', modes: ['Pilot Conversion'], touchesMsa: 'Yes, with modifications', release: 'v1-engine' },
    'modification':              { label: 'Modification', shape: 'proposal', modes: ['Modification'], touchesMsa: 'No — quantities within the MSA', release: 'v1-engine' },
    'renewal-rewrap':            { label: 'Renewal / Rewrap', shape: 'proposal', modes: ['Renewal', 'Rewrap'], touchesMsa: 'Yes, with modifications', release: 'v1-engine' },
    'reactivation-reinstatement':{ label: 'Reactivation / Reinstatement', shape: 'proposal', modes: ['Reactivation', 'Reinstatement'], touchesMsa: 'Reactivation: yes, with modifications · Reinstatement: restores the prior state', release: 'v1-engine' },
    'pilot-extension':           { label: 'Pilot Extension', shape: 'proposal', modes: [], noModeMotions: ['pilot', 'cancel', 'retain'], touchesMsa: 'No', release: 'v2' },
    'pilot-cancellation':        { label: 'Pilot Cancellation', shape: 'notice', modes: [], touchesMsa: '—', release: 'v2' },
    'full-cancellation':         { label: 'Full Cancellation', shape: 'proposal', modes: ['Full Cancellation'], maxOptions: 1, touchesMsa: 'Yes — cancels it', release: 'v2' },
    'wnnr':                      { label: 'WNNR (non-renewal)', shape: 'notice', modes: [], touchesMsa: 'Takes effect at term end', release: 'v2' },
  };

  var MOTIONS = ['pilot', 'initial', 'add', 'upsell', 'upgrade', 'reactivate', 'reinstate', 'cancel', 'downgrade', 'retain'];
  // Axis 1 — motions each mode allows ('reactivate*' = only when something on the account was cancelled).
  var MODE_MOTIONS = {
    'Modification':      ['add', 'upsell', 'upgrade', 'reactivate*', 'cancel', 'downgrade'],
    'Renewal':           ['add', 'upsell', 'upgrade', 'reactivate*', 'cancel', 'downgrade', 'retain'],
    'Rewrap':            ['add', 'upsell', 'upgrade', 'reactivate*', 'cancel', 'downgrade', 'retain'],
    'Pilot Conversion':  ['add', 'upsell', 'upgrade', 'cancel', 'downgrade', 'retain'],
    'Reactivation':      ['add', 'upsell', 'upgrade', 'reactivate', 'cancel', 'downgrade'],
    'Reinstatement':     ['reinstate'],
    'Full Cancellation': ['cancel'],
  };
  // Axis 2 — motions each bundle kind allows; Purchase Mode → bundle kinds.
  var KIND_MOTIONS = {
    'plan':       ['pilot', 'initial', 'add', 'upgrade', 'downgrade', 'cancel', 'reactivate', 'reinstate', 'retain'],
    'a-la-carte': ['pilot', 'initial', 'add', 'upsell', 'cancel', 'reactivate', 'reinstate', 'retain'],
  };
  var PURCHASE_MODE_KINDS = { 'bundle': ['plan'], 'a-la-carte': ['a-la-carte'], 'mixed': ['plan', 'a-la-carte'] };

  // Which doors each account can use, and the transaction type each door resolves to (§3.2).
  function doorsFor(account) {
    var type = account.accountType;
    if (type === 'prospect') return [{ door: 'newProposal', transaction: 'initial-sale' }];
    if (type === 'pilot') {
      if (!account.contractedPilot) return [{ door: 'newProposal', transaction: 'pilot' }];
      return [
        { door: 'newProposal', transaction: 'pilot-conversion' },
        { door: 'pilotExtension', transaction: 'pilot-extension' },
        { door: 'pilotCancellation', transaction: 'pilot-cancellation' },
      ];
    }
    if (type === 'customer') {
      // Open question (spec §3.2): can a fully cancelled customer open a Modification or a Renewal / Rewrap?
      // The expected door is Reactivation / Reinstatement, so that is the only one offered here.
      if (account.cancellation === 'full') return [{ door: 'reactivationReinstatement', transaction: 'reactivation-reinstatement' }];
      return [
        { door: 'newProposal', transaction: 'modification' },
        { door: 'renewalRewrap', transaction: 'renewal-rewrap' },
        { door: 'fullCancellation', transaction: 'full-cancellation' },
        { door: 'nonRenewal', transaction: 'wnnr' },
      ];
    }
    return [];
  }

  function motionsFor(list, account, kinds) {
    var hasCancelled = account.cancellation === 'partial' || account.cancellation === 'full';
    return list
      .filter(function (m) { return m !== 'reactivate*' || hasCancelled; })
      .map(function (m) { return m.replace('*', ''); })
      .filter(function (m) { return kinds.some(function (k) { return KIND_MOTIONS[k].indexOf(m) !== -1; }); });
  }

  // The three account-resolved objects: their version comes from the account, never from the admin.
  // A single-valued attribute means the control is absent (not disabled).
  function accountControls(account) {
    return {
      costType: account.costType === 'mixed' ? 'toggle' : (account.costType + '-only'),
      bundleKind: account.purchaseMode === 'mixed' ? 'toggle' : (account.purchaseMode === 'bundle' ? 'plan-only' : 'a-la-carte-only'),
      paymentTerms: account.paymentMethod === 'direct-bill' ? 'shown' : 'hidden',
    };
  }

  function resolve(input) {
    var account = {
      accountType: input.accountType || 'prospect',
      contractedPilot: !!input.contractedPilot,
      cancellation: input.cancellation || 'none',
      purchaseMode: input.purchaseMode || 'mixed',
      costType: input.costType || 'mixed',
      paymentMethod: input.paymentMethod || 'autopay',
    };
    var doors = doorsFor(account);
    var chosen = doors.filter(function (d) { return d.door === input.entryPoint; })[0] || doors[0];
    if (!chosen) return { ok: false, error: 'no-door', account: account, doors: doors };
    var t = TRANSACTIONS[chosen.transaction];
    var kinds = PURCHASE_MODE_KINDS[account.purchaseMode] || PURCHASE_MODE_KINDS.mixed;
    var motionsByMode = {};
    if (t.modes.length) t.modes.forEach(function (mode) { motionsByMode[mode] = motionsFor(MODE_MOTIONS[mode], account, kinds); });
    else if (t.noModeMotions) motionsByMode['(no mode)'] = motionsFor(t.noModeMotions, account, kinds);
    return {
      ok: true,
      account: account,
      doors: doors,
      entryPoint: chosen.door,
      transactionId: chosen.transaction,
      transaction: t,
      modes: t.modes,
      motionsByMode: motionsByMode,
      bundleKinds: kinds,
      maxOptions: t.shape === 'notice' ? 0 : (t.maxOptions || 3),
      controls: accountControls(account),
    };
  }

  global.VC_DOMAIN = {
    ACCOUNT_TYPES: ACCOUNT_TYPES, CANCELLATION: CANCELLATION, PURCHASE_MODES: PURCHASE_MODES,
    COST_TYPES: COST_TYPES, PAYMENT_METHODS: PAYMENT_METHODS, ENTRY_POINTS: ENTRY_POINTS,
    TRANSACTIONS: TRANSACTIONS, MOTIONS: MOTIONS, MODE_MOTIONS: MODE_MOTIONS, KIND_MOTIONS: KIND_MOTIONS,
    PURCHASE_MODE_KINDS: PURCHASE_MODE_KINDS,
    doorsFor: doorsFor, resolve: resolve,
  };
})(typeof window !== 'undefined' ? window : globalThis);
