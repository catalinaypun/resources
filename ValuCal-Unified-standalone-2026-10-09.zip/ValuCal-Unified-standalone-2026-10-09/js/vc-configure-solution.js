/* Valu Cal — Configure Solution (shared modal logic)
   One implementation for Initial Sales "Configure Solution" and Existing Accounts "Expansion"
   (same function, only the title / primary button differ — Catalina, 2026-10-07).
   Source: Initial Sales (reference). Loaded as a classic script after vc-catalog.js; the
   functions are globals used by the modal markup (#bundle-overlay) in both flows.
   Flow-specific (stays in each flow): opening the modal, the save handler (createBundle),
   calcBundle / calcOption (pricing used across the whole flow), pilot setup on options.
   Globals each flow must define: bld, builderMode, planFinder, options, proposalData,
   simBuilderDraft, accountType, accountBillingModel, promoNameActiveOptionIndex,
   calcBundle(bundle, term, promoType), formatMoney(n). */

/* Shared markup for the Configure Solution / Expansion form (body + footer). 2026-10-07: one copy for
   both flows so they can't drift. Options: summaryTitle ("Solution Summary" / "Expansion Summary"),
   primaryLabel (initial label of the primary button; each flow's open function sets it too). */
window.VC = window.VC || {};
window.VC.configureSolutionMarkup = function (opts) {
  opts = opts || {};
  var html = "<div class=\"bundle-modal-body\">\n      <div class=\"bundle-modal-form\">\n\n        <!-- Core product + Quantity on one row -->\n        <div class=\"core-qty-row\">\n          <div class=\"core-select-wrap\" id=\"core-select-wrap\">\n            <div class=\"vc-field-label\">Core product</div>\n            <div class=\"custom-select-wrap\">\n              <button class=\"custom-select-btn\" id=\"core-btn\" onclick=\"toggleCoreDropdown()\">\n                <span id=\"core-label\">Select core...</span>\n                <span class=\"material-symbols-outlined\">expand_more</span>\n              </button>\n              <div class=\"custom-dropdown hidden\" id=\"core-dropdown\">\n                <div class=\"dropdown-group-label\">Vehicle tracking</div>\n                <div class=\"dropdown-option\" onclick=\"selectCore('vtu')\">VTU Only</div>\n                <div class=\"dropdown-option\" onclick=\"selectCore('vtu-ffc')\">VTU + Forward Facing Camera</div>\n                <div class=\"dropdown-option\" onclick=\"selectCore('vtu-dual')\">VTU + Dual Camera Subscription</div>\n                <div class=\"dropdown-group-label\">Asset Tracking</div>\n                <div class=\"dropdown-option\" onclick=\"selectCore('asset-powered')\">Powered Asset</div>\n                <div class=\"dropdown-option\" onclick=\"selectCore('asset-nonpowered')\">Non-Powered Asset</div>\n              </div>\n            </div>\n          </div>\n          <div class=\"core-select-wrap hidden\" id=\"plan-select-wrap\">\n            <div class=\"vc-field-label\" id=\"plan-select-label\">Bundle</div>\n            <div class=\"plan-dropdown-collapse open\" id=\"plan-dropdown-collapse\">\n              <div class=\"plan-dropdown-collapse-inner\">\n                <div class=\"custom-select-wrap\" id=\"plan-dropdown-wrap\">\n                  <button type=\"button\" class=\"custom-select-btn\" id=\"plan-btn\" aria-haspopup=\"listbox\" aria-expanded=\"false\" aria-controls=\"plan-dropdown\" onclick=\"togglePlanDropdown(event)\">\n                    <span id=\"plan-label\">Select bundle...</span>\n                    <span class=\"material-symbols-outlined\">expand_more</span>\n                  </button>\n                  <div class=\"custom-dropdown hidden\" id=\"plan-dropdown\"></div>\n                </div>\n              </div>\n            </div>\n            <div class=\"plan-finder-entry\" id=\"plan-finder-toggle-link\"><span class=\"plan-finder-entry-question\">Not sure which bundle?</span> <button type=\"button\" class=\"text-link text-link--small plan-finder-entry-link\" onclick=\"togglePlanFinderInline()\">Get a recommendation</button></div>\n          </div>\n          <div id=\"install-type-block\">\n            <div class=\"vc-field-label\">Install type</div>\n            <div id=\"vmi-segment\" class=\"segmented-control\" role=\"group\" aria-label=\"Install type\">\n              <button type=\"button\" id=\"seg-vmi\" class=\"segmented-control__option segmented-control__option--active\" onclick=\"selectInstallType('VMI')\">VMI</button>\n              <button type=\"button\" id=\"seg-cmi\" class=\"segmented-control__option\" onclick=\"selectInstallType('CMI')\">CMI</button>\n            </div>\n          </div>\n          <div class=\"qty-block\" id=\"qty-block\">\n            <div class=\"vc-field-label\">QTY</div>\n            <div class=\"input-stepper input-stepper--large\" id=\"bundle-qty-stepper\">\n              <button type=\"button\" class=\"input-stepper__btn\" onclick=\"changeQty(-1)\" aria-label=\"Decrease\"><span class=\"material-symbols-outlined\">remove</span></button>\n              <input class=\"input-stepper__value\" id=\"qty-display\" type=\"number\" min=\"1\" step=\"1\" value=\"1\" oninput=\"setQty(this.value)\" aria-label=\"Quantity\">\n              <button type=\"button\" class=\"input-stepper__btn\" onclick=\"changeQty(1)\" aria-label=\"Increase\"><span class=\"material-symbols-outlined\">add</span></button>\n            </div>\n          </div>\n        </div>\n\n        <!-- Plan finder \u2014 expands to the modal's full width, collapsed to zero height by default -->\n        <div class=\"plan-finder-collapse\" id=\"plan-finder-collapse\">\n          <div class=\"plan-finder-collapse-inner\">\n            <div id=\"plan-finder-inline\"></div>\n          </div>\n        </div>\n\n        <!-- Plan summary \u2014 what the selected plan includes (2026-09-22 per Catalina,\n             resolves US-05): shown right after picking a plan since the features\n             accordion below is collapsed by default and the included core/features\n             would otherwise stay hidden from view. -->\n        <div id=\"plan-summary-block\" class=\"hidden\">\n          <div class=\"plan-summary-title\" id=\"plan-summary-title\"></div>\n          <div id=\"plan-summary-content\" class=\"plan-summary-content\"></div>\n        </div>\n\n        <!-- Features accordion \u2014 shown after core is selected -->\n        <div id=\"addons-section\" class=\"hidden\" style=\"margin-top:18px;\">\n\n          <!-- Video group -->\n          <div class=\"vc-accordion\" id=\"acc-video\">\n            <button type=\"button\" class=\"vc-accordion__header\" aria-expanded=\"false\" onclick=\"toggleAddonAccordion('acc-video')\">\n              <span class=\"vc-accordion__title\" id=\"video-addons-title\">Video Add-ons</span>\n              <span class=\"vc-accordion__right\" id=\"acc-video-count-wrap\"><span class=\"material-symbols-outlined vc-accordion__chevron\" aria-hidden=\"true\">expand_more</span></span>\n            </button>\n            <div class=\"vc-accordion__body\">\n              <div id=\"addon-evc-row\">\n                <label class=\"vc-check-row\"><input type=\"checkbox\" class=\"checkbox__input\" id=\"addon-evc\" onchange=\"onAddonChange()\"> <span class=\"vc-check-row__text\" id=\"addon-evc-label-text\">Extended View Cameras (EVC) (+$15.00)</span></label>\n                <div id=\"addon-evc-options\" style=\"display:none; margin:8px 0 4px 24px;\">\n                  <div class=\"vc-field-label\">EVC Layout</div>\n                  <select id=\"evc-type-select\" class=\"term-select\" onchange=\"onAddonChange()\">\n                    <option value=\"sides-rear-cargo\">Sides, Rear &amp; Cargo</option>\n                    <option value=\"sides\">Sides</option>\n                    <option value=\"sides-rear\">Sides &amp; Rear</option>\n                    <option value=\"rear-cargo\">Rear and Cargo</option>\n                  </select>\n                  <div id=\"addon-monitor-row\" style=\"margin-top:10px;\">\n                    <label class=\"vc-check-row\"><input type=\"checkbox\" class=\"checkbox__input\" id=\"addon-monitor\" onchange=\"onAddonChange()\"><span class=\"vc-check-row__text\">In-Cab Monitor (+$12.00)</span></label>\n                  </div>\n                </div>\n              </div>\n              <div id=\"addon-sd-card-row\" style=\"margin:8px 0 4px 0;\">\n                <div style=\"font-size:13px; font-weight:700; margin-bottom:8px;\">SD Card Storage</div>\n                <div class=\"radio-group radio-group--inline\" style=\"margin-bottom:10px;\">\n                  <label class=\"vc-check-row\"><input type=\"radio\" class=\"radio__input\" id=\"sd-card-128\" name=\"sd-card\" value=\"128\" checked onchange=\"onAddonChange()\"><span class=\"vc-check-row__text\">128 GB</span></label>\n                  <label class=\"vc-check-row\"><input type=\"radio\" class=\"radio__input\" id=\"sd-card-256\" name=\"sd-card\" value=\"256\" onchange=\"onAddonChange()\"><span class=\"vc-check-row__text\">256 GB (+$5.00)</span></label>\n                </div>\n              </div>\n              <div id=\"addon-adas-row\">\n                <label class=\"vc-check-row\"><input type=\"checkbox\" class=\"checkbox__input\" id=\"addon-adas\" onchange=\"onAddonChange()\"><span class=\"vc-check-row__text\">ADAS (+$5.00)</span></label>\n              </div>\n            </div>\n          </div>\n\n          <!-- Vehicle group -->\n          <div class=\"vc-accordion\" id=\"acc-vehicle\">\n            <button type=\"button\" class=\"vc-accordion__header\" aria-expanded=\"false\" onclick=\"toggleAddonAccordion('acc-vehicle')\">\n              <span class=\"vc-accordion__title\" id=\"vehicle-features-title\">Vehicle Features</span>\n              <span class=\"vc-accordion__right\" id=\"acc-vehicle-count-wrap\"><span class=\"material-symbols-outlined vc-accordion__chevron\" aria-hidden=\"true\">expand_more</span></span>\n            </button>\n            <div class=\"vc-accordion__body\">\n              <div id=\"addon-driver-id-row\">\n                <label class=\"vc-check-row\"><input type=\"checkbox\" class=\"checkbox__input\" id=\"addon-driver-id\" onchange=\"onAddonChange()\"><span class=\"vc-check-row__text\">Driver ID (+$2.00)</span></label>\n                <div id=\"keyfob-section\" class=\"keyfob-section-block\" style=\"display:none;\">\n                  <div id=\"keyfob-label\" class=\"keyfob-label\">Keyfobs</div>\n                  <div class=\"input-stepper input-stepper--small\">\n                    <button type=\"button\" class=\"input-stepper__btn\" onclick=\"changeKeyfobQty(-1)\" aria-label=\"Decrease\"><span class=\"material-symbols-outlined\">remove</span></button>\n                    <input class=\"input-stepper__value\" id=\"keyfob-qty\" type=\"number\" min=\"1\" max=\"99\" step=\"1\" value=\"3\" oninput=\"setKeyfobQty(this.value)\" aria-label=\"Quantity\">\n                    <button type=\"button\" class=\"input-stepper__btn\" onclick=\"changeKeyfobQty(1)\" aria-label=\"Increase\"><span class=\"material-symbols-outlined\">add</span></button>\n                  </div>\n                  <p class=\"promo-eligibility-note\" style=\"margin-top:8px;font-size:11px;\">*Keyfob quantity is per vehicle. First 3 included at no extra cost.</p>\n                  <div class=\"keyfob-divider\"></div>\n                </div>\n              </div>\n              <div id=\"addon-privacy-row\"><label class=\"vc-check-row\"><input type=\"checkbox\" class=\"checkbox__input\" id=\"addon-privacy\" onchange=\"onAddonChange()\"><span class=\"vc-check-row__text\">Privacy Button (+$1.00)</span></label></div>\n              <div id=\"addon-logbook-row\"><label class=\"vc-check-row\"><input type=\"checkbox\" class=\"checkbox__input\" id=\"addon-logbook\" onchange=\"onAddonChange()\"><span class=\"vc-check-row__text\">Logbook (+$3.00)</span></label></div>\n            </div>\n          </div>\n\n        </div>\n      </div>\n      <div class=\"bundle-modal-preview\">\n        <!-- 2026-10-02 (per Leo, 2026-10-01 call): Billing model moved up next to\n             the \"Bundle Summary\" title as a small dropdown labeled just \"Model\". -->\n        <div class=\"preview-label-row\">\n          <div class=\"preview-label preview-label--title\">Solution Summary</div>\n          <div class=\"preview-model-field hidden\" id=\"bundle-billing-model-block\">\n            <!-- 2026-10-02 (per Catalina): dropdown replaced by the shared compact\n                 segmented control (.segmented-pill, same as Existing Accounts'\n                 Renewal/Rewrap switch). -->\n            <div class=\"segmented-pill\" id=\"bundle-billing-model-segment\" role=\"group\" aria-label=\"Billing model\">\n              <button type=\"button\" class=\"segmented-pill__btn is-active\" data-billing-model=\"opex\" aria-pressed=\"true\" onclick=\"setBundleBillingModel('opex')\">Opex</button>\n              <button type=\"button\" class=\"segmented-pill__btn\" data-billing-model=\"capex\" aria-pressed=\"false\" onclick=\"setBundleBillingModel('capex')\">Capex</button>\n            </div>\n          </div>\n        </div>\n        <!-- 2026-10-02 (per Catalina, option A of the header exploration): the\n             contract term badge moved right under the title row (badge style\n             kept, per Catalina's follow-up). -->\n        <div class=\"preview-term-badge\" id=\"preview-term-badge\">36 month term contract</div>\n        <div class=\"preview-price\">$<span id=\"preview-price-val\">--</span><span>/month</span></div>\n        <div id=\"preview-capex-summary\" class=\"preview-capex-summary hidden\">\n          <div class=\"preview-capex-box\">\n            <div class=\"preview-capex-box-title\">Month 1 total</div>\n            <div class=\"preview-capex-box-total\">$<span id=\"preview-capex-first-month\">--</span></div>\n            <div class=\"preview-capex-breakdown\"><span id=\"preview-capex-hardware-row\">incl. <span id=\"preview-capex-hardware\">--</span> hardware</span></div>\n          </div>\n          <div class=\"preview-capex-box\">\n            <div class=\"preview-capex-box-title\">Month 2+ total</div>\n            <div class=\"preview-capex-box-total\">$<span id=\"preview-capex-ongoing\">--</span><small>/mo</small></div>\n          </div>\n        </div>\n\n        <div class=\"preview-promo\" id=\"preview-promo-section\">\n          <div class=\"preview-promo-title\">Promotions</div>\n          <div class=\"preview-promo-grid\">\n            <div class=\"preview-promo-field\" id=\"bundle-promo-type-field\">\n              <div class=\"preview-promo-label\">Type</div>\n              <div class=\"custom-select-wrap\">\n                <button type=\"button\" class=\"custom-select-btn selected\" id=\"bundle-promo-btn\" onclick=\"togglePromoDropdown()\">\n                  <span id=\"bundle-promo-label\">Standard</span>\n                  <span class=\"material-symbols-outlined\">expand_more</span>\n                </button>\n                <div class=\"custom-dropdown hidden\" id=\"bundle-promo-dropdown\"></div>\n              </div>\n              <div id=\"promo-eligibility-note\" class=\"promo-eligibility-note\"></div>\n            </div>\n            <div class=\"preview-promo-field\" id=\"bundle-promo-name-field\">\n              <div class=\"preview-promo-label\">Name</div>\n              <div class=\"promo-name-combobox\" id=\"bundle-promo-name-combobox\" onclick=\"document.getElementById('bundle-promo-name-input')?.focus()\">\n                <input\n                  id=\"bundle-promo-name-input\"\n                  class=\"promo-name-input\"\n                  type=\"text\"\n                  autocomplete=\"off\"\n                  placeholder=\"Select promo\"\n                  role=\"combobox\"\n                  aria-autocomplete=\"list\"\n                  aria-expanded=\"false\"\n                  aria-controls=\"bundle-promo-name-options\"\n                  onfocus=\"onPromoNameInputFocus()\"\n                  oninput=\"onPromoNameInput()\"\n                  onkeydown=\"onPromoNameInputKeydown(event)\"\n                  onblur=\"onPromoNameInputBlur()\">\n                <div id=\"bundle-promo-name-options\" class=\"promo-name-search-options hidden\" role=\"listbox\" aria-label=\"Promo Name options\"></div>\n              </div>\n            </div>\n            <div id=\"bundle-incentives-block\" class=\"preview-incentives-block hidden\">\n              <div class=\"preview-promo-subtitle\">Incentives</div>\n              <div id=\"bundle-incentives-grid\" class=\"preview-incentives-grid\">\n                <div class=\"preview-promo-field hidden\" id=\"bundle-deal-closer-field\">\n                  <div class=\"preview-promo-label\">Deal Closer</div>\n                  <div class=\"custom-select-wrap\">\n                    <button type=\"button\" class=\"custom-select-btn\" id=\"bundle-deal-closer-btn\" onclick=\"toggleDealCloserDropdown(event)\">\n                      <span id=\"bundle-deal-closer-label\">Select</span>\n                      <span class=\"material-symbols-outlined\">expand_more</span>\n                    </button>\n                    <div class=\"custom-dropdown hidden\" id=\"bundle-deal-closer-dropdown\"></div>\n                  </div>\n                </div>\n              </div>\n            </div>\n          </div>\n        </div>\n\n        <!-- Tier price picker removed -->\n\n        <div id=\"preview-lines\" class=\"preview-line-items hidden\"></div>\n      </div>\n    </div>\n    <div class=\"bundle-modal-footer modal__actions modal__actions--fill-container\">\n      <button class=\"btn btn--secondary btn--large\" onclick=\"closeBundleModal()\">Cancel</button>\n      <button class=\"btn btn--primary btn--large\" id=\"btn-create\" onclick=\"createBundle()\" disabled>Create</button>\n    </div>";
  if (opts.summaryTitle) html = html.replace('>Solution Summary<', '>' + opts.summaryTitle + '<');
  if (opts.primaryLabel) html = html.replace('disabled>Create</button>', 'disabled>' + opts.primaryLabel + '</button>');
  return html;
};


function displaySubscriptionName(name) {
  return REAL_SUBSCRIPTION_NAMES[name] || name;
}

function getPrebuiltBundleByKey(bundleKey) {
  return PREBUILT_BUNDLES[bundleKey] || null;
}

function getPrebuiltTierByKey(bundleKey, tierKey) {
  const bundle = getPrebuiltBundleByKey(bundleKey);
  if (!bundle) return null;
  return bundle.tiers.find(t => t.key === tierKey) || null;
}

function getPrebuiltTierUnitPrice(bundleKey, tier, promoType = 'Standard') {
  const bundle = getPrebuiltBundleByKey(bundleKey);
  if (!bundle || !tier) return 0;
  const coreBase = corePricing[tier.coreKey]?.price || 0;
  const includedFeatureTotal = (tier.includedFeatures || []).reduce((sum, featureKey) => sum + (featurePricing[featureKey] || 0), 0);
  const sdSurcharge = tier.sdSize === 256 ? 5.00 : 0;
  const promoMult = getPromoMultiplier(tier.coreKey, promoType);
  return (coreBase + includedFeatureTotal + sdSurcharge) * promoMult;
}

function getPrebuiltTierFeatureKeys(tier) {
  const features = Array.isArray(tier?.includedFeatures) ? [...tier.includedFeatures] : [];
  if (tier?.sdSize === 256) features.push('sd-256');
  return features;
}

function getPrebuiltTierFeaturesText(tier) {
  const items = (tier.includedFeatures || []).map(k => featureLabels[k] || k.toUpperCase());
  if (tier.sdSize === 128) items.push('SD Card 128 GB');
  if (tier.sdSize === 256) items.push('256 GB SD Card');
  return items.join(' · ');
}

function canUsePrebuiltMode(term) {
  // 2026-10-07 (Catalina): bundles can be chosen at any contract term, in both flows.
  const t = parseInt(term, 10);
  return !Number.isNaN(t) && getAllowedSolutionTypes().includes('plan');
}

// Account Purchase Mode (Valu Cal domain model, 2026-10-09): 'mixed' → Bundle and A la carte (toggle shown);
// 'bundle' → plan bundles only; 'a-la-carte' → à la carte only. The toggle is absent when only one applies.
// Flows that don't define accountPurchaseMode behave as 'mixed' (unchanged).
function getAllowedSolutionTypes() {
  const mode = typeof accountPurchaseMode === 'string' ? accountPurchaseMode : 'mixed';
  if (mode === 'bundle') return ['plan'];
  if (mode === 'a-la-carte') return ['custom'];
  return ['plan', 'custom'];
}

function getTierTermTableRow(fleetSize) {
  const idx = MSA_TIER_TERM_DISCOUNT_TABLE.qtyRows.findIndex(t => fleetSize >= t.min && fleetSize <= t.max);
  return MSA_TIER_TERM_DISCOUNT_TABLE.qtyRows[idx === -1 ? 0 : idx];
}

function getTierTermTableColumn(term) {
  const t = parseInt(term) || 12;
  const buckets = MSA_TIER_TERM_DISCOUNT_TABLE.termBucketMonths;
  for (let i = 0; i < buckets.length; i++) {
    if (t <= buckets[i]) return i;
  }
  return buckets.length - 1; // 49+ months
}

function getTierTermDiscountPct(term, fleetSize) {
  const row = getTierTermTableRow(fleetSize);
  const col = getTierTermTableColumn(term);
  return row.pct[col];
}

function getMsaDiscretionaryApprovalBoundaries() {
  return { autoApproved: 30, associateDirector: 50 };
}

function getMsaDiscretionaryApprovalLevel(pct, boundaries) {
  if (pct <= boundaries.autoApproved) return 0;
  if (pct <= boundaries.associateDirector) return 1;
  return 2;
}

function getMsaTierQty(qty, coreKey) {
  return isVideoCore(coreKey) ? qty * 2 : qty;
}

function sumMsaTierQty(bundles, excludeBundleId) {
  return bundles.reduce((sum, b) => {
    if (excludeBundleId != null && b.id === excludeBundleId) return sum;
    return sum + getMsaTierQty(b.qty, b.coreKey);
  }, 0);
}

function getMsaFleetSizeForBundleModal() {
  const opt = bld.targetOptId ? options.find(o => o.id === bld.targetOptId) : null;
  const otherUnits = opt ? sumMsaTierQty(opt.bundles, bld.targetBundleId) : 0;
  return otherUnits + getMsaTierQty(bld.qty || 0, bld.coreKey);
}

function getMsaTermForBundleModal() {
  const opt = bld.targetOptId ? options.find(o => o.id === bld.targetOptId) : null;
  return opt ? (opt.term || 36) : 36;
}

function getPromoMultiplier(coreKey, promoType) {
  const isVideo = coreKey === 'vtu-ffc' || coreKey === 'vtu-dual';
  return (promoType === 'Media' && isVideo) ? 0.8 : 1.0;
}

function getPromoNameMultiplier(promoName, term) {
  const name = String(promoName || '').trim();
  if (!name) return 1;
  let mult = 1;
  if (/%\s*DISC/i.test(name)) mult *= 0.95;
  const freeMonthsMatch = name.match(/(\d+)\s*MF/i);
  const freeMonths = /w\/MF/i.test(name) ? 1 : (freeMonthsMatch ? parseInt(freeMonthsMatch[1], 10) : 0);
  if (freeMonths > 0 && term > 0) {
    mult *= Math.max(0, term - freeMonths) / term;
  }
  return mult;
}

function formatMoneyAmount(n) {
  return formatMoney(n).replace('$', '');
}

function getPaidPilotOffer(pilotConfig) {
  const id = pilotConfig && pilotConfig.paidOffer;
  return PAID_PILOT_OFFERS.find(offer => offer.id === id) || PAID_PILOT_OFFERS[0];
}

function getPilotConfigPriceFactor(pilotConfig) {
  if (!pilotConfig) return 1;
  if (pilotConfig.pricingMode === 'free') return 0;
  if (pilotConfig.pricingMode === 'paid') return getPaidPilotOffer(pilotConfig).factor;
  return 1;
}

function getBundleComponentPrices(b, tierTermPct) {
  const vtuBase = corePricing['vtu']?.price || 0;
  const components = [];
  if (b.coreKey === 'vtu') {
    components.push({ name: displaySubscriptionName('Vehicle Tracking Subscription'), listUnit: vtuBase });
  } else if (b.coreKey === 'vtu-ffc') {
    components.push({ name: displaySubscriptionName('Vehicle Tracking Subscription'), listUnit: vtuBase });
    components.push({ name: 'Forward Facing Camera Subscription', listUnit: (corePricing['vtu-ffc']?.price || 0) - vtuBase });
  } else if (b.coreKey === 'vtu-dual') {
    components.push({ name: displaySubscriptionName('Vehicle Tracking Subscription'), listUnit: vtuBase });
    components.push({ name: 'Dual Camera Subscription', listUnit: (corePricing['vtu-dual']?.price || 0) - vtuBase });
  } else {
    const coreInfo = corePricing[b.coreKey];
    components.push({ name: displaySubscriptionName(coreInfo?.name || b.coreName || b.coreKey), listUnit: coreInfo?.price || 0 });
  }
  (b.features || []).forEach(featureKey => {
    components.push({ name: displaySubscriptionName(featureLabels[featureKey] || featureKey), listUnit: featurePricing[featureKey] || 0 });
  });
  // Fold any rounding/keyfob remainder into the first component so the
  // components' listUnit always sum exactly to b.basePrice (the number
  // already used everywhere else) — keyfob cost isn't its own subscription.
  const sum = components.reduce((s, c) => s + c.listUnit, 0);
  const remainder = (b.basePrice || 0) - sum;
  if (Math.abs(remainder) > 0.0001 && components.length) components[0].listUnit += remainder;
  const discretionaryPct = b.msaDiscountPct || 0;
  return components.map(c => {
    const afterTierTerm = c.listUnit * (1 - tierTermPct / 100);
    const msaUnit = afterTierTerm * (1 - discretionaryPct / 100);
    return { name: c.name, listUnit: c.listUnit, afterTierTermUnit: afterTierTerm, msaUnit };
  });
}

function getEstimatedHardwareUnitPrice(bundle) {
  // TODO: pricing real de hardware pendiente.
  return Math.max(0, Number(bundle.basePrice) || 0) * 0.3;
}

function getHardwareBreakdownLabel(componentName) {
  const hardwareLabels = {
    'vehicle tracking': 'GPS / telematics device',
    'vehicle tracking subscription': 'GPS / telematics device',
    'powered asset': 'Powered asset GPS tracker',
    'powered asset tracker': 'Powered asset GPS tracker',
    'non-powered asset': 'Battery-powered GPS tracker',
    'non-powered asset tracker': 'Battery-powered GPS tracker',
    'forward facing camera subscription': 'Road-facing DVR camera',
    'dual camera subscription': 'Dual-facing DVR camera system',
    'extended view cameras': 'Auxiliary camera kit',
    'evc': 'Auxiliary camera kit',
    '256 gb sd card': '256 GB microSD card',
    'sd card': 'microSD card',
    'adas': 'ADAS camera module',
    'in-cab monitor': 'In-cab display monitor',
    'driver id': 'Driver ID reader',
    'privacy button': 'Privacy button',
    'logbook': 'Electronic logbook accessory',
    'dvir': 'Driver inspection device',
    'roadside assistance': 'Roadside assistance device',
    'driver monitoring system': 'Driver monitoring camera',
  };
  return hardwareLabels[String(componentName || '').trim().toLowerCase()] || `${componentName} hardware`;
}

function getEstimatedHardwareComponentUnitPrice(bundle, componentName, tierTermPct) {
  if (accountBillingModel !== 'both' || bundle.billingModel !== 'capex') return 0;
  const bundleBasePrice = Number(bundle.basePrice) || 0;
  if (!bundleBasePrice) return 0;
  if (bundle.isPrebuilt && componentName === bundle.coreName) return getEstimatedHardwareUnitPrice(bundle);
  const component = getBundleComponentPrices(bundle, tierTermPct).find(item => item.name === componentName);
  return component ? getEstimatedHardwareUnitPrice(bundle) * (component.listUnit / bundleBasePrice) : 0;
}

function getDefaultPilotConfig() {
  return { term: 6, pricingMode: 'free', paidOffer: 'subs-50', endAction: 'auto-cancel', msaTerm: 36 };
}

function setBundleBillingModel(value) {
  bld.billingModel = value === 'capex' ? 'capex' : 'opex';
  syncBundleBillingModelSegment();
  updateBundlePreview();
}

function syncBundleBillingModelSegment() {
  document.querySelectorAll('#bundle-billing-model-segment .segmented-pill__btn').forEach(btn => {
    const active = btn.dataset.billingModel === (bld.billingModel === 'capex' ? 'capex' : 'opex');
    btn.classList.toggle('is-active', active);
    btn.setAttribute('aria-pressed', String(active));
  });
}

function syncBundleBillingModelVisibility() {
  const block = document.getElementById('bundle-billing-model-block');
  if (block) block.classList.toggle('hidden', accountBillingModel !== 'both');
}

function syncBundleModeToggle(term) {
  const allowedTypes = getAllowedSolutionTypes();
  if (allowedTypes.length === 1) builderMode = allowedTypes[0];
  document.querySelector('.bundle-mode-toggle')?.classList.toggle('hidden', allowedTypes.length === 1);
  const planAvailable = canUsePrebuiltMode(term);
  const activeMode = builderMode === 'plan' && planAvailable ? 'plan' : 'custom';
  document.getElementById('bundle-mode-custom')?.classList.toggle('segmented-control__option--active', activeMode === 'custom');
  const planButton = document.getElementById('bundle-mode-plan');
  planButton?.classList.toggle('segmented-control__option--active', activeMode === 'plan');
  if (planButton) {
    planButton.disabled = !planAvailable;
    planButton.title = planAvailable ? '' : 'Bundle is not available for this contract term';
  }
}

function setBundleConstructionMode(mode) {
  if (mode !== 'custom' && mode !== 'plan') return;
  const term = bld.targetOptId ? (options.find(o => o.id === bld.targetOptId)?.term || 36) : 36;
  if (mode === 'plan' && !canUsePrebuiltMode(term)) return;

  builderMode = mode;
  simBuilderDraft.bundleConstruction = mode;
  const simulationSelect = document.getElementById('sim-builder-bundle-select');
  if (simulationSelect) simulationSelect.value = mode;

  bld.coreKey = null;
  bld.coreName = null;
  bld.corePrice = 0;
  bld.selectedFeatures = [];
  resetPrebuiltState();
  const coreLabel = document.getElementById('core-label');
  if (coreLabel) {
    coreLabel.textContent = 'Select core...';
    coreLabel.parentElement?.classList.remove('selected');
  }
  Object.keys(featurePricing).forEach(featureKey => {
    const checkbox = document.getElementById(`addon-${featureKey}`);
    if (checkbox) checkbox.checked = false;
  });
  document.getElementById('addons-section')?.classList.add('hidden');
  document.getElementById('preview-lines')?.classList.add('hidden');
  document.getElementById('preview-capex-summary')?.classList.add('hidden');
  document.querySelector('.bundle-modal-preview .preview-price')?.classList.remove('hidden');
  const previewPrice = document.getElementById('preview-price-val');
  if (previewPrice) previewPrice.textContent = '--';
  const createButton = document.getElementById('btn-create');
  if (createButton) createButton.disabled = true;

  renderPlanModeUI(term);
  syncBundleModeToggle(term);
}

function toggleCoreDropdown() { 
  document.getElementById('core-dropdown').classList.toggle('hidden');
}

function renderPlanDropdownOptions() {
  const dd = document.getElementById('plan-dropdown');
  if (!dd) return;
  const opt = bld.targetOptId ? options.find(o => o.id === bld.targetOptId) : null;
  const usedKeys = (opt ? opt.bundles : [])
    .filter(b => b.isPrebuilt && b.id !== bld.targetBundleId)
    .map(b => `${b.bundleKey}::${b.tierKey}`);

  dd.innerHTML = Object.keys(PREBUILT_BUNDLES).map((bundleKey) => {
    const bundle = PREBUILT_BUNDLES[bundleKey];
    const availableTiers = bundle.tiers.filter(t => !usedKeys.includes(`${bundleKey}::${t.key}`));
    if (!availableTiers.length) return '';
    const heading = `<div class="dropdown-group-label">${bundle.category || bundle.name}</div>`;
    const rows = availableTiers.map((t) => {
      const isSelected = bundleKey === bld.prebuiltBundleKey && t.key === bld.prebuiltTierKey;
      const price = getPrebuiltTierUnitPrice(bundleKey, t, bld.promoType || 'Standard');
      const coreName = corePricing[t.coreKey]?.name || t.coreKey;
      const featuresText = getPrebuiltTierFeaturesText(t);
      return `<div class="dropdown-option ${isSelected ?'selected' : ''}" onclick="selectPrebuiltPlanTier('${t.key}', '${bundleKey}')">
        <div style="display:flex;justify-content:space-between;">
          <span>${t.label}</span>
          <span style="color:var(--gray-600);font-size:12px;">${formatMoney(price)}/mo</span>
        </div>
        <div style="font-size:11px;color:var(--gray-600);margin-top:4px;line-height:1.5;">${coreName} · ${featuresText}</div>
      </div>`;
    }).join('');
    return `${heading}${rows}`;
  }).join('');
}

function togglePlanDropdown(e) {
  e?.stopPropagation();
  const dropdown = document.getElementById('plan-dropdown');
  if (dropdown && !dropdown.innerHTML.trim()) renderPlanDropdownOptions();
  const isOpen = dropdown?.classList.toggle('hidden') === false;
  document.getElementById('plan-btn')?.setAttribute('aria-expanded', String(isOpen));
}

function selectPrebuiltPlanTier(tierKey, bundleKey) {
  bld.prebuiltBundleKey = bundleKey;
  const bundle = getPrebuiltBundleByKey(bundleKey);
  const tier = getPrebuiltTierByKey(bundleKey, tierKey);
  if (!bundle || !tier) return;
  bld.prebuiltTierKey = tierKey;
  document.getElementById('plan-dropdown')?.classList.add('hidden');
  document.getElementById('plan-btn')?.setAttribute('aria-expanded', 'false');
  document.getElementById('plan-label').textContent = tier.label;
  document.getElementById('plan-btn')?.classList.add('selected');
  bld.coreKey = tier.coreKey;
  bld.coreName = `${bundle.name} — ${tier.label}`;
  bld.corePrice = getPrebuiltTierUnitPrice(bundleKey, tier, bld.promoType || 'Standard');
  bld.bundleExtras = (bld.bundleExtras || []).filter(key => !getPrebuiltTierFeatureKeys(tier).includes(key));
  bld.selectedFeatures = [...getPrebuiltTierFeatureKeys(tier), ...bld.bundleExtras];
  document.getElementById('btn-create').disabled = false;
  updateBundlePreview();
  renderPlanSummary();
}

function renderPlanSummary() {
  const block = document.getElementById('plan-summary-block');
  const title = document.getElementById('plan-summary-title');
  const content = document.getElementById('plan-summary-content');
  if (!block || !title || !content) return;
  const bundle = getPrebuiltBundleByKey(bld.prebuiltBundleKey);
  const tier = getPrebuiltTierByKey(bld.prebuiltBundleKey, bld.prebuiltTierKey);
  if (!bundle || !tier) {
    block.classList.add('hidden');
    return;
  }
  const coreName = corePricing[tier.coreKey]?.name || tier.coreKey;
  const featuresText = getPrebuiltTierFeaturesText(tier);
  title.textContent = `${bundle.name} — ${tier.label}`;
  content.innerHTML = `<div><strong>Core product:</strong> ${coreName}</div>` +
    (featuresText ? `<div><strong>Features:</strong> ${featuresText}</div>` : '') +
    buildBundleExtrasHtml(tier);
  block.classList.remove('hidden');
}

function buildBundleExtrasHtml(tier) {
  const included = getPrebuiltTierFeatureKeys(tier);
  const available = BUNDLE_EXTRA_FEATURES.filter(key => !included.includes(key));
  if (!available.length) return '';
  return `<div class="addon-divider"></div>
    <div class="plan-summary-subtitle">Add extra features</div>
    ${available.map(key => `<label class="vc-check-row bundle-extra-checkbox"><input type="checkbox" class="checkbox__input" id="bundle-extra-${key}" ${(bld.bundleExtras || []).includes(key) ? 'checked' : ''} onchange="toggleBundleExtra('${key}', this.checked)"><span class="vc-check-row__text">${featureLabels[key] || key} (+${formatMoney(featurePricing[key] || 0)})</span></label>`).join('')}`;
}

function getBldBillableFeatures() {
  return bld.mode === 'prebuilt' ? (bld.bundleExtras || []) : (bld.selectedFeatures || []);
}

function toggleBundleExtra(featureKey, checked) {
  const extras = new Set(bld.bundleExtras || []);
  if (checked) extras.add(featureKey); else extras.delete(featureKey);
  bld.bundleExtras = BUNDLE_EXTRA_FEATURES.filter(key => extras.has(key));
  const tier = getPrebuiltTierByKey(bld.prebuiltBundleKey, bld.prebuiltTierKey);
  bld.selectedFeatures = [...getPrebuiltTierFeatureKeys(tier), ...bld.bundleExtras];
  updateBundlePreview();
}

function resetPrebuiltState() {
  bld.bundleExtras = [];
  bld.prebuiltBundleKey = null;
  bld.prebuiltTierKey = null;
  const planLabel = document.getElementById('plan-label');
  if (planLabel) planLabel.textContent = 'Select bundle...';
  document.getElementById('plan-btn')?.classList.remove('selected');
  document.getElementById('plan-summary-block')?.classList.add('hidden');
  closePlanFinderInline();
}

function getPlanFinderCores() {
  return ['vtu', 'vtu-ffc', 'vtu-dual', 'asset-powered', 'asset-nonpowered'];
}

function getPlanFinderTierRows() {
  const rows = [];
  Object.entries(PREBUILT_BUNDLES).forEach(([bundleKey, bundle]) => {
    bundle.tiers.forEach(tier => rows.push({ bundleKey, bundle, tier }));
  });
  return rows;
}

function togglePlanFinderFeature(key) {
  const idx = planFinder.features.indexOf(key);
  if (idx === -1) planFinder.features.push(key); else planFinder.features.splice(idx, 1);
  planFinder.featureDropdownOpen = true;
  renderPlanFinder();
}

function selectPlanFinderCore(coreKey) {
  planFinder.coreKey = coreKey;
  planFinder.features = [];
  planFinder.featureDropdownOpen = false;
  renderPlanFinder();
}

function getPlanFinderFeatureKeys(coreKey) {
  if (!coreKey) return [];
  const keys = new Set();
  getPlanFinderTierRows()
    .filter(row => row.tier.coreKey === coreKey)
    .forEach(row => getPrebuiltTierFeatureKeys(row.tier).forEach(key => keys.add(key)));
  const customFeatureState = getFeatureState(coreKey, []);
  Object.entries(customFeatureState).forEach(([key, state]) => {
    if (state.visible && state.enabled) keys.add(key);
  });
  return Array.from(keys).filter(key => key !== 'sd-256');
}

function togglePlanFinderCoreDropdown(e) {
  e?.stopPropagation();
  document.getElementById('plan-finder-feature-dropdown')?.classList.add('hidden');
  const dropdown = document.getElementById('plan-finder-core-dropdown');
  const isOpen = dropdown?.classList.toggle('hidden') === false;
  document.getElementById('plan-finder-core-btn')?.setAttribute('aria-expanded', String(isOpen));
  document.getElementById('plan-finder-feature-btn')?.setAttribute('aria-expanded', 'false');
}

function togglePlanFinderFeatureDropdown(e) {
  e?.stopPropagation();
  if (!planFinder.coreKey) return;
  document.getElementById('plan-finder-core-dropdown')?.classList.add('hidden');
  planFinder.featureDropdownOpen = !planFinder.featureDropdownOpen;
  document.getElementById('plan-finder-feature-dropdown')?.classList.toggle('hidden', !planFinder.featureDropdownOpen);
  document.getElementById('plan-finder-feature-btn')?.setAttribute('aria-expanded', String(planFinder.featureDropdownOpen));
  document.getElementById('plan-finder-core-btn')?.setAttribute('aria-expanded', 'false');
}

function planFinderRowHtml(scored) {
  const featuresText = getPrebuiltTierFeaturesText(scored.tier);
  const price = getPrebuiltTierUnitPrice(scored.bundleKey, scored.tier, bld.promoType || 'Standard');
  const matchLabel = scored.exact
    ? ''
    : (planFinder.features.length ? `${scored.overlap} of ${planFinder.features.length} features match` : 'Pick features to compare');
  return `
    <div class="plan-finder-row${scored.exact ?' plan-finder-row--exact' : ''}">
      <div style="flex:1;min-width:0;">
        <div style="font-weight:700;font-size:13px;">${scored.bundle.name} — ${scored.tier.label}</div>
        <div style="font-size:11px;color:var(--gray-600);margin-top:2px;">${corePricing[scored.tier.coreKey]?.name || scored.tier.coreKey} · ${featuresText}</div>
        ${matchLabel ? `<div style="font-size:11px;margin-top:4px;">${matchLabel}</div>` : ''}
      </div>
      <div style="font-weight:700;font-size:13px;white-space:nowrap;">${formatMoney(price)}/mo</div>
      <button class="btn-opt-promo" onclick="selectPlanFromFinder('${scored.tier.key}','${scored.bundleKey}')">Select</button>
    </div>`;
}

function selectPlanFromFinder(tierKey, bundleKey) {
  const finder = document.getElementById('plan-finder-collapse');
  finder?.classList.add('is-closing');
  window.setTimeout(() => {
    selectPrebuiltPlanTier(tierKey, bundleKey);
    closePlanFinderInline();
  }, 180);
}

function renderPlanFinder() {
  const body = document.getElementById('plan-finder-inline');
  if (!body) return;
  const cores = getPlanFinderCores();
  const featureKeysInvolved = getPlanFinderFeatureKeys(planFinder.coreKey);
  const hasCore = Boolean(planFinder.coreKey);
  const isAssetCore = planFinder.coreKey === 'asset-powered' || planFinder.coreKey === 'asset-nonpowered';

  const vehicleCoreOptionsHtml = cores
    .filter(k => isVehicleCore(k))
    .map(k => `<div class="dropdown-option ${k === planFinder.coreKey ?'selected' : ''}" onclick="selectPlanFinderCore('${k}')">${corePricing[k]?.name || k}</div>`)
    .join('');
  const assetCoreOptionsHtml = cores
    .filter(k => k === 'asset-powered' || k === 'asset-nonpowered')
    .map(k => `<div class="dropdown-option ${k === planFinder.coreKey ?'selected' : ''}" onclick="selectPlanFinderCore('${k}')">${corePricing[k]?.name || k}</div>`)
    .join('');
  const coreOptionsHtml = `
    <div class="dropdown-group-label">Vehicle tracking</div>
    ${vehicleCoreOptionsHtml}
    <div class="dropdown-group-label">Asset Tracking</div>
    ${assetCoreOptionsHtml}`;
  const featureCheckboxesHtml = featureKeysInvolved.map(k => `
    <label class="dropdown-option checkbox plan-finder-feature-option" onclick="event.stopPropagation();">
      <input type="checkbox" class="checkbox__input" ${planFinder.features.includes(k) ? 'checked' : ''} onclick="event.stopPropagation();" onchange="togglePlanFinderFeature('${k}')">
      <span class="checkbox__content"><span>${featureLabels[k] || k}</span></span>
    </label>`).join('');
  const featureLabelText = !hasCore ? 'Select core first' : planFinder.features.length ? `${planFinder.features.length} feature${planFinder.features.length > 1 ? 's' : ''} selected` : 'Select features...';

  let resultsHtml = '<p class="plan-finder-empty-state">Select the features your customer needs to see recommended bundles.</p>';
  if (planFinder.features.length) {
    const scored = getPlanFinderTierRows().map(scorePlanFinderTier).sort((a, b) => {
      if (a.coreMatch !== b.coreMatch) return a.coreMatch ? -1 : 1;
      if (b.overlap !== a.overlap) return b.overlap - a.overlap;
      return a.extra - b.extra;
    });
    const exactMatch = scored.find(s => s.exact);
    const rest = scored.filter(s => s !== exactMatch).slice(0, 3);
    resultsHtml =
      (exactMatch ? `<div class="plan-finder-section-label">Exact match</div>${planFinderRowHtml(exactMatch)}` : '') +
      (rest.length ? `<div class="plan-finder-section-label">${exactMatch ? 'Other close bundles' : 'Recommended bundles'}</div>${rest.map(s => planFinderRowHtml(s)).join('')}` : '');
  }

  body.innerHTML = `
    <div class="plan-finder-header">
      <button type="button" class="btn-icon btn-icon--ghost-vds btn-icon--vds-small" aria-label="Back to bundle list" onclick="closePlanFinderInline()">
        <span class="material-symbols-outlined">arrow_back</span>
      </button>
      <div class="plan-finder-title">Bundle recommendation</div>
    </div>
    <p class="plan-finder-subtitle">Choose the core and the features your customer needs, and we'll recommend the closest bundle.</p>
    <div style="display:flex;gap:16px;flex-wrap:wrap;">
      <div class="plan-finder-core-field${isAssetCore ?' plan-finder-core-field--asset' : ''}" style="${isAssetCore ? 'flex:0 0 calc(50% - 8px);max-width:calc(50% - 8px);' : 'flex:1;min-width:200px;'}">
        <div class="plan-finder-field-label">Core product</div>
        <div class="custom-select-wrap plan-finder-select-wrap">
          <button type="button" class="custom-select-btn plan-finder-select-btn${hasCore ?' selected' : ''}" id="plan-finder-core-btn" aria-haspopup="listbox" aria-expanded="false" aria-controls="plan-finder-core-dropdown" onclick="togglePlanFinderCoreDropdown(event)">
            <span>${corePricing[planFinder.coreKey]?.name || 'Select core...'}</span>
            <span class="material-symbols-outlined">expand_more</span>
          </button>
          <div class="custom-dropdown hidden" id="plan-finder-core-dropdown" role="listbox" aria-label="Core options">${coreOptionsHtml}</div>
        </div>
      </div>
      ${isAssetCore ? '' : `<div style="flex:1;min-width:200px;">
        <div class="plan-finder-field-label">Features</div>
        <div class="custom-select-wrap plan-finder-select-wrap">
          <button type="button" class="custom-select-btn plan-finder-select-btn${planFinder.features.length ?' selected' : ''}" id="plan-finder-feature-btn" ${hasCore ? '' : 'disabled'} aria-haspopup="listbox" aria-expanded="${planFinder.featureDropdownOpen}" aria-controls="plan-finder-feature-dropdown" onclick="togglePlanFinderFeatureDropdown(event)">
            <span>${featureLabelText}</span>
            <span class="material-symbols-outlined">expand_more</span>
          </button>
          <div class="custom-dropdown ${planFinder.featureDropdownOpen ?'' : 'hidden'}" id="plan-finder-feature-dropdown" role="group" aria-label="Customer-requested features">${featureCheckboxesHtml}</div>
        </div>
      </div>`}
    </div>
    <h3 class="plan-finder-results-title">Results</h3>
    ${resultsHtml}
  `;
}

function togglePlanFinderInline() {
  const isOpen = document.getElementById('plan-finder-collapse')?.classList.contains('open');
  if (isOpen) closePlanFinderInline(); else openPlanFinderInline();
}

function openPlanFinderInline() {
  // 2026-10-05 (per Catalina): always start from scratch — no core pre-filled
  // from the bundle already selected.
  planFinder.coreKey = null;
  planFinder.features = [];
  renderPlanFinder();
  document.getElementById('plan-dropdown-collapse')?.classList.add('closed');
  document.getElementById('plan-finder-collapse')?.classList.add('open');
  document.querySelector('.core-qty-row')?.classList.add('plan-finder-active');
  document.getElementById('install-type-block')?.classList.add('hidden');
  document.getElementById('qty-block')?.classList.add('hidden');
  document.getElementById('plan-finder-toggle-link')?.classList.add('hidden');
  document.getElementById('plan-select-label')?.classList.add('hidden');
}

function closePlanFinderInline() {
  document.getElementById('plan-finder-collapse')?.classList.remove('open', 'is-closing');
  document.querySelector('.core-qty-row')?.classList.remove('plan-finder-active');
  document.getElementById('plan-dropdown-collapse')?.classList.remove('closed');
  document.getElementById('install-type-block')?.classList.remove('hidden');
  document.getElementById('qty-block')?.classList.remove('hidden');
  document.getElementById('plan-finder-toggle-link')?.classList.remove('hidden');
  document.getElementById('plan-select-label')?.classList.remove('hidden');
}

function renderPlanModeUI(term) {
  const isPlanMode = builderMode === 'plan' && canUsePrebuiltMode(term);
  bld.mode = isPlanMode ? 'prebuilt' : 'build';
  document.getElementById('core-select-wrap')?.classList.toggle('hidden', isPlanMode);
  document.getElementById('plan-select-wrap')?.classList.toggle('hidden', !isPlanMode);
  if (isPlanMode) {
    renderPlanDropdownOptions();
    // 2026-09-22 per Catalina (US-05): the plan already defines its features,
    // so the manual features accordion is hidden in Plan mode — the summary
    // above covers what's included instead.
    document.getElementById('addons-section')?.classList.add('hidden');
    renderPlanSummary();
  } else {
    document.getElementById('plan-summary-block')?.classList.add('hidden');
  }

  const hideBundlePromoFields = true;
  document.getElementById('preview-promo-section')?.classList.toggle('hidden', hideBundlePromoFields);
  // Note: Discretionary/Schedule discount are no longer their own card — they're
  // itemized $ lines inside #preview-lines (updateBundlePreview()), each shown only
  // when it actually reduces price, regardless of builder mode (2026-09-17).
}

function isVehicleCore(coreKey) {
  return coreKey === 'vtu' || coreKey === 'vtu-ffc' || coreKey === 'vtu-dual';
}

function isVideoCore(coreKey) {
  return coreKey === 'vtu-ffc' || coreKey === 'vtu-dual';
}

function getFeatureState(coreKey, selectedFeatures = []) {
  const isVehicle = isVehicleCore(coreKey);
  const isVideo = isVideoCore(coreKey);
  const hasEvc = selectedFeatures.includes('evc');
  return {
    'driver-id': { visible: isVehicle, enabled: isVehicle },
    'privacy': { visible: isVehicle, enabled: isVehicle },
    'logbook': { visible: isVehicle, enabled: isVehicle },
    'sd-256': { visible: isVideo, enabled: isVideo },
    'adas': { visible: isVideo, enabled: isVideo },
    'evc': { visible: isVideo, enabled: isVideo },
    'monitor': { visible: isVideo, enabled: isVideo && hasEvc }
  };
}

function syncAddonControls() {
  const section = document.getElementById('addons-section');
  if (!section) return;
  const state = getFeatureState(bld.coreKey, bld.selectedFeatures || []);
  const rowMap = {
    'driver-id': document.getElementById('addon-driver-id-row'),
    'privacy': document.getElementById('addon-privacy-row'),
    'logbook': document.getElementById('addon-logbook-row'),
    'adas': document.getElementById('addon-adas-row'),
    'evc': document.getElementById('addon-evc-row'),
    'monitor': document.getElementById('addon-monitor-row')
  };

  let visibleCount = 0;
  Object.keys(rowMap).forEach((featureKey) => {
    const checkbox = document.getElementById(`addon-${featureKey}`);
    const row = rowMap[featureKey];
    if (!checkbox || !row) return;
    const cfg = state[featureKey] || { visible: false, enabled: false };
    if (cfg.visible) visibleCount += 1;
    const shouldShowRow = featureKey === 'monitor'
      ? (cfg.visible && cfg.enabled)
      : cfg.visible;
    row.style.display = shouldShowRow ? 'block' : 'none';
    checkbox.disabled = !cfg.enabled;
    if (!shouldShowRow || !cfg.enabled) checkbox.checked = false;
  });

  const sdRow = document.getElementById('addon-sd-card-row');
  const sd128 = document.getElementById('sd-card-128');
  const sd256 = document.getElementById('sd-card-256');
  const sdVisible = !!(state['sd-256'] && state['sd-256'].visible);
  if (sdRow) sdRow.style.display = sdVisible ? 'block' : 'none';
  if (sd128 && sd256 && !sdVisible) {
    sd128.checked = true;
    sd256.checked = false;
  }
  if (sdVisible) visibleCount += 1;

  const hasVideo = isVideoCore(bld.coreKey);
  const hasVehicle = isVehicleCore(bld.coreKey);

  // Accordion visibility
  const accVideo = document.getElementById('acc-video');
  const accVehicle = document.getElementById('acc-vehicle');
  if (accVideo) accVideo.style.display = hasVideo ? 'block' : 'none';
  if (accVehicle) accVehicle.style.display = hasVehicle ? 'block' : 'none';

  // Auto-open accordion when core is first selected
  if (hasVideo && accVideo && !accVideo.classList.contains('is-open') && !accVideo.dataset.manualToggle) {
    accVideo.classList.add('is-open');
    accVideo.querySelector('.vc-accordion__header')?.setAttribute('aria-expanded', 'true');
  }
  if (hasVehicle && accVehicle && !accVehicle.classList.contains('is-open') && !accVehicle.dataset.manualToggle) {
    accVehicle.classList.add('is-open');
    accVehicle.querySelector('.vc-accordion__header')?.setAttribute('aria-expanded', 'true');
  }

  const syncAccordionCount = (wrapperId, count) => {
    const wrapper = document.getElementById(wrapperId);
    const right = wrapper?.querySelector('.vc-accordion__right');
    if (!right) return;
    let badge = document.getElementById(`${wrapperId}-badge`);
    if (count > 0) {
      if (!badge) {
        badge = document.createElement('span');
        badge.id = `${wrapperId}-badge`;
        badge.className = 'badge vc-accordion__count';
        right.insertBefore(badge, right.querySelector('.vc-accordion__chevron'));
      }
      badge.textContent = count;
    } else {
      badge?.remove();
    }
  };
  syncAccordionCount('acc-video', ['addon-evc', 'addon-monitor', 'addon-adas', 'sd-card-256'].filter(id => document.getElementById(id)?.checked).length);
  syncAccordionCount('acc-vehicle', ['addon-driver-id', 'addon-privacy', 'addon-logbook'].filter(id => document.getElementById(id)?.checked).length);

  const evcCheckbox = document.getElementById('addon-evc');
  const evcOptions = document.getElementById('addon-evc-options');
  const evcLabelText = document.getElementById('addon-evc-label-text');
  const showEvcOptions = hasVideo && !!(evcCheckbox && evcCheckbox.checked);
  if (evcOptions) evcOptions.style.display = showEvcOptions ? 'block' : 'none';
  if (evcLabelText) evcLabelText.style.fontWeight = showEvcOptions ? '700' : '400';
  if (!showEvcOptions) {
    const evcSelect = document.getElementById('evc-type-select');
    if (evcSelect) evcSelect.value = 'sides-rear-cargo';
  }

  bld.selectedFeatures = [];
  ['driver-id', 'privacy', 'logbook', 'adas', 'evc', 'monitor'].forEach((featureKey) => {
    const checkbox = document.getElementById(`addon-${featureKey}`);
    if (checkbox && checkbox.checked) bld.selectedFeatures.push(featureKey);
  });
  if (sdVisible && sd256 && sd256.checked) bld.selectedFeatures.push('sd-256');

  // Keyfob: show only when Driver ID is checked
  const driverIdChecked = !!(document.getElementById('addon-driver-id')?.checked);
  const keyfobSection = document.getElementById('keyfob-section');
  const keyfobQtyInput = document.getElementById('keyfob-qty');
  const keyfobLabelEl = document.getElementById('keyfob-label');
  if (keyfobSection) {
    keyfobSection.style.display = driverIdChecked ? 'block' : 'none';
    if (!driverIdChecked && keyfobQtyInput) keyfobQtyInput.value = 3;
  }
  if (keyfobLabelEl) {
    if (driverIdChecked) {
      const keyfobCost = getKeyfobPrice();
      const statusClass = keyfobCost === 0 ? 'keyfob-status included' : 'keyfob-status';
      const statusText = keyfobCost === 0 ? 'Included' : `+${formatMoney(keyfobCost)}`;
      keyfobLabelEl.innerHTML = `Keyfobs <span class="${statusClass}">(${statusText})</span>`;
    } else {
      keyfobLabelEl.textContent = 'Keyfobs';
    }
  }

  section.style.display = visibleCount > 0 ? 'block' : 'none';
}

function onAddonChange() {
  syncAddonControls();
  updateBundlePreview();
}

function getKeyfobPrice() {
  const driverIdChecked = document.getElementById('addon-driver-id')?.checked;
  if (!driverIdChecked) return 0;
  const qty = parseInt(document.getElementById('keyfob-qty')?.value, 10) || 3;
  return Math.max(0, qty - 3) * 5;
}

function changeKeyfobQty(delta) {
  const input = document.getElementById('keyfob-qty');
  if (!input) return;
  input.value = Math.max(1, (parseInt(input.value, 10) || 3) + delta);
  onAddonChange();
}

function setKeyfobQty(rawValue) {
  const n = parseInt(rawValue, 10);
  const input = document.getElementById('keyfob-qty');
  if (!isNaN(n) && input) input.value = Math.max(1, n);
  onAddonChange();
}

function toggleAddonAccordion(id) {
  const el = document.getElementById(id);
  if (!el) return;
  const isOpen = el.classList.toggle('is-open');
  el.querySelector('.vc-accordion__header')?.setAttribute('aria-expanded', String(isOpen));
  el.dataset.manualToggle = '1';
}

function togglePromoDropdown() {
  const btn = document.getElementById('bundle-promo-btn');
  const dropdown = document.getElementById('bundle-promo-dropdown');
  const isHidden = dropdown.classList.contains('hidden');
  document.getElementById('core-dropdown').classList.add('hidden');
  if (isHidden) {
    const rect = btn.getBoundingClientRect();
    dropdown.style.position = 'fixed';
    dropdown.style.top = `${rect.bottom + 4}px`;
    dropdown.style.left = `${rect.left}px`;
    dropdown.style.width = `${rect.width}px`;
    dropdown.classList.remove('hidden');
  } else {
    dropdown.classList.add('hidden');
  }
}

function isPromoTypeEligibleForCore(promoType, coreKey) {
  const promo = PROMOS.find((item) => item.key === promoType);
  if (!promo) return false;
  return !promo.videoOnly || isVideoCore(coreKey);
}

function getDealCloserOptionsForCore(coreKey) {
  return DEAL_CLOSER_OPTIONS_BY_CORE[coreKey] || [];
}

function inferDealCloserFromPromoName(name) {
  const value = String(name || '');
  if (/2nd\s*Pitch/i.test(value)) return '2nd Pitch';
  if (/Sweetener/i.test(value)) return 'Sweetener';
  return '';
}

function applyIncentivesCascadeFromPromoName() {
  const hasPromoName = !!String(bld.promoName || '').trim();
  const dealOpts = getDealCloserOptionsForCore(bld.coreKey);

  if (!hasPromoName) {
    bld.dealCloser = '';
    return;
  }

  const inferredDealCloser = inferDealCloserFromPromoName(bld.promoName);

  if (inferredDealCloser && dealOpts.includes(inferredDealCloser)) {
    bld.dealCloser = inferredDealCloser;
  } else if (!dealOpts.includes(bld.dealCloser)) {
    bld.dealCloser = '';
  }

}

function ensurePromoNameSelection() {
  const names = getEligiblePromoNames(bld.promoType);
  if (!names.length) { bld.promoName = ''; return; }
  if (!bld.promoName) return;
  if (!names.includes(bld.promoName)) bld.promoName = '';
}

function getCurrentPromoTerm() {
  const opt = bld.targetOptId ? options.find((o) => o.id === bld.targetOptId) : null;
  return parseInt(opt?.term || 36, 10);
}

function getPromoCodeTermMonths(name) {
  const match = String(name || '').match(/\/\s*(\d+)M\b/i);
  if (!match) return null;
  const parsed = parseInt(match[1], 10);
  return Number.isFinite(parsed) ? parsed : null;
}

function getEligiblePromoNames(promoType) {
  const allNames = PROMO_NAME_OPTIONS_BY_TYPE[promoType] || [];
  const currentTerm = getCurrentPromoTerm();
  return allNames.filter((name) => getPromoCodeTermMonths(name) === currentTerm);
}

function getPromoTypeBaseMonthly(promoType, termOverride = null) {
  if (!bld.coreKey) return Number.POSITIVE_INFINITY;
  const optId = bld.targetOptId;
  const term = termOverride || (optId ? (options.find((o) => o.id === optId)?.term || 36) : 36);
  const addOnBase = getBldBillableFeatures().reduce((sum, key) => sum + (featurePricing[key] || 0), 0);
  const basePrice = (bld.corePrice || 0) + addOnBase + getKeyfobPrice();
  const dummyBundle = { basePrice, qty: bld.qty || 1, coreKey: bld.coreKey || 'vtu' };
  const { monthly } = calcBundle(dummyBundle, term, promoType);
  return monthly;
}

function estimatePromoNameMonthly(name) {
  const promoTerm = getPromoCodeTermMonths(name) || getCurrentPromoTerm();
  const baseMonthly = getPromoTypeBaseMonthly(bld.promoType, promoTerm);
  if (!Number.isFinite(baseMonthly)) return Number.POSITIVE_INFINITY;
  return baseMonthly * getPromoNameMultiplier(name, promoTerm);
}

function getPromoNameGroups(query) {
  const allNames = getEligiblePromoNames(bld.promoType);
  const q = String(query || '').trim().toLowerCase();
  const filtered = !q ? allNames : allNames.filter((name) => name.toLowerCase().includes(q));

  const priced = filtered.map((name) => ({ name, estimatedMonthly: estimatePromoNameMonthly(name) }));
  priced.sort((a, b) => {
    if (a.estimatedMonthly !== b.estimatedMonthly) return a.estimatedMonthly - b.estimatedMonthly;
    return a.name.localeCompare(b.name);
  });

  const recommended = priced.slice(0, 3).map((item) => item.name);
  const recommendedSet = new Set(recommended);
  const other = priced.filter((item) => !recommendedSet.has(item.name)).map((item) => item.name);
  return { recommended, other };
}

function renderPromoCards() {
  const dropdown = document.getElementById('bundle-promo-dropdown');
  const labelEl  = document.getElementById('bundle-promo-label');
  const note     = document.getElementById('promo-eligibility-note');
  if (!dropdown) return;

  const isVideo   = isVideoCore(bld.coreKey);
  const optId     = bld.targetOptId;
  const term      = optId ? (options.find(o => o.id === optId)?.term || 36) : 36;
  const addOnBase = getBldBillableFeatures().reduce((sum, k) => sum + (featurePricing[k] || 0), 0);
  const basePrice = (bld.corePrice || 0) + addOnBase + getKeyfobPrice();
  const dummyBundle = { basePrice, qty: bld.qty || 1, coreKey: bld.coreKey || 'vtu' };
  const selected  = bld.promoType || 'Standard';

  // Pre-calc Standard price for savings comparison
  let stdUnit = 0;
  if (bld.coreKey) {
    ({ unitPrice: stdUnit } = calcBundle(dummyBundle, term, 'Standard'));
  }

  dropdown.innerHTML = PROMOS.filter(promo => !promo.videoOnly || isVideo).map(promo => {
    const isSel = selected === promo.key;
    let pricesHtml  = '';
    if (bld.coreKey) {
      const { unitPrice, monthly } = calcBundle(dummyBundle, term, promo.key);
      const savings = stdUnit - unitPrice;
      pricesHtml = `
        <div class="promo-dropdown-row-prices">
          <div class="promo-dropdown-row-unit">${formatMoney(unitPrice)}/unit</div>
          <div class="promo-dropdown-row-mo">${formatMoney(monthly)}/mo</div>
          ${savings > 0.005 ? `<div class="promo-dropdown-row-savings">−${formatMoney(savings)}/unit</div>` : ''}
        </div>`;
    }

    return `
      <div class="promo-dropdown-row ${isSel ?'selected' : ''}"
           onclick="selectPromoCard('${promo.key}')">
        <div class="promo-dropdown-row-left">
          <div>
            <div class="promo-dropdown-row-name">${promo.label}</div>
            <div class="promo-dropdown-row-sub">${promo.sub}</div>
          </div>
        </div>
        ${pricesHtml}
      </div>`;
  }).join('');

  document.querySelector('.bundle-modal-preview')?.addEventListener('scroll', function () {
    document.getElementById('bundle-promo-dropdown')?.classList.add('hidden');
  }, { once: true });

  // Update trigger label
  if (labelEl) {
    const p = PROMOS.find(p => p.key === selected);
    labelEl.innerText = p ? p.label : selected;
  }

  // Eligibility note below trigger
  if (note) {
    note.innerText = '';
  }

  ensurePromoNameSelection();
  const promoNameInput = document.getElementById('bundle-promo-name-input');
  if (promoNameInput) promoNameInput.value = bld.promoName || '';
  renderDealCloserDropdown();
}

function toggleDealCloserDropdown(event) {
  event?.stopPropagation();
  const btn = document.getElementById('bundle-deal-closer-btn');
  const dropdown = document.getElementById('bundle-deal-closer-dropdown');
  const isHidden = dropdown.classList.contains('hidden');
  document.getElementById('core-dropdown')?.classList.add('hidden');
  document.getElementById('bundle-promo-dropdown')?.classList.add('hidden');
  if (isHidden) {
    const rect = btn.getBoundingClientRect();
    dropdown.style.position = 'fixed';
    dropdown.style.top = `${rect.bottom + 4}px`;
    dropdown.style.left = `${rect.left}px`;
    dropdown.style.width = `${rect.width}px`;
    dropdown.classList.remove('hidden');
  } else {
    dropdown.classList.add('hidden');
  }
}

function updateIncentivesVisibility() {
  const block = document.getElementById('bundle-incentives-block');
  const dealField = document.getElementById('bundle-deal-closer-field');
  const grid = document.getElementById('bundle-incentives-grid');
  if (!block || !dealField || !grid) return;

  const hasPromoName = !!String(bld.promoName || '').trim();
  const dealOpts = getDealCloserOptionsForCore(bld.coreKey);
  dealField.classList.toggle('hidden', !dealOpts.length);

  const visibleCount = dealOpts.length ? 1 : 0;
  block.classList.toggle('hidden', !hasPromoName || visibleCount === 0);
  grid.classList.toggle('preview-incentives-grid--single', visibleCount === 1);
}

function updatePromoAndDiscountDisabledState() {
  const disabled = !bld.coreKey;
  const promoSection = document.getElementById('preview-promo-section');
  const promoTypeBtn = document.getElementById('bundle-promo-btn');
  const promoNameInput = document.getElementById('bundle-promo-name-input');
  const dealCloserBtn = document.getElementById('bundle-deal-closer-btn');

  promoSection?.classList.toggle('preview-promo--disabled', disabled);
  if (promoTypeBtn) promoTypeBtn.disabled = disabled;
  if (promoNameInput) promoNameInput.disabled = disabled;
  if (dealCloserBtn) dealCloserBtn.disabled = disabled;

  if (disabled) {
    document.getElementById('bundle-promo-dropdown')?.classList.add('hidden');
    document.getElementById('bundle-deal-closer-dropdown')?.classList.add('hidden');
    closePromoNameSearchDropdown();
  }
}

function renderDealCloserDropdown() {
  const label = document.getElementById('bundle-deal-closer-label');
  const btn = document.getElementById('bundle-deal-closer-btn');
  const dropdown = document.getElementById('bundle-deal-closer-dropdown');
  if (!label || !btn || !dropdown) return;

  const opts = getDealCloserOptionsForCore(bld.coreKey);
  if (!opts.includes(bld.dealCloser)) bld.dealCloser = '';
  label.textContent = bld.dealCloser || 'Select';
  btn.classList.toggle('selected', !!bld.dealCloser);
  dropdown.innerHTML = opts.map((opt) => {
    const selected = opt === bld.dealCloser;
    return `<div class="dropdown-option ${selected ?'selected' : ''}" onclick="selectDealCloser('${opt}')">${opt}</div>`;
  }).join('');
  updateIncentivesVisibility();
}

function selectDealCloser(value) {
  bld.dealCloser = value;
  document.getElementById('bundle-deal-closer-dropdown')?.classList.add('hidden');
  updateBundlePreview();
}

function renderPromoNameSearchOptions(query) {
  const optionsEl = document.getElementById('bundle-promo-name-options');
  if (!optionsEl) return;

  const groups = getPromoNameGroups(query);
  const ordered = [...groups.recommended, ...groups.other];
  if (!ordered.length) {
    promoNameActiveOptionIndex = -1;
    optionsEl.innerHTML = '<div class="promo-name-option promo-name-option--empty">No promo codes match this search</div>';
    return;
  }

  if (promoNameActiveOptionIndex >= ordered.length) promoNameActiveOptionIndex = -1;
  let runningIndex = 0;
  const renderSection = (title, names) => {
    if (!names.length) return '';
    const rows = names.map((name) => {
      const rowIndex = runningIndex;
      runningIndex += 1;
      const activeClass = rowIndex === promoNameActiveOptionIndex ? ' is-active' : '';
      return `<button type="button" class="promo-name-option${activeClass}" role="option" data-promo-name="${proposalEscapeHtml(name)}" aria-selected="${rowIndex === promoNameActiveOptionIndex ? 'true' : 'false'}" onmousedown="onPromoNameOptionMouseDown(event, '${proposalEscapeHtml(name)}')">${proposalEscapeHtml(name)}</button>`;
    }).join('');
    return `<div class="promo-name-group-label">${title}</div>${rows}`;
  };

  optionsEl.innerHTML = [
    renderSection('Recommended', groups.recommended),
    renderSection('Other', groups.other)
  ].join('');
}

function openPromoNameSearchDropdown(showAll) {
  const inputEl = document.getElementById('bundle-promo-name-input');
  const optionsEl = document.getElementById('bundle-promo-name-options');
  if (!inputEl || !optionsEl || !bld.coreKey) return;
  promoNameActiveOptionIndex = -1;
  renderPromoNameSearchOptions(showAll ? '' : inputEl.value);
  optionsEl.classList.remove('hidden');
  inputEl.setAttribute('aria-expanded', 'true');
}

function closePromoNameSearchDropdown() {
  const inputEl = document.getElementById('bundle-promo-name-input');
  const optionsEl = document.getElementById('bundle-promo-name-options');
  if (optionsEl) optionsEl.classList.add('hidden');
  if (inputEl) inputEl.setAttribute('aria-expanded', 'false');
  promoNameActiveOptionIndex = -1;
}

function selectPromoName(name) {
  bld.promoName = name;
  applyIncentivesCascadeFromPromoName();
  const inputEl = document.getElementById('bundle-promo-name-input');
  if (inputEl) inputEl.value = name;
  closePromoNameSearchDropdown();
  updateBundlePreview();
}

function onPromoNameInputFocus() {
  openPromoNameSearchDropdown(true);
}

function onPromoNameInput() {
  openPromoNameSearchDropdown(false);
}

function onPromoNameInputKeydown(event) {
  const optionsEl = document.getElementById('bundle-promo-name-options');
  if (!optionsEl) return;
  const optionEls = Array.from(optionsEl.querySelectorAll('.promo-name-option[data-promo-name]'));
  if (!optionEls.length) return;

  if (event.key === 'ArrowDown') {
    event.preventDefault();
    promoNameActiveOptionIndex = (promoNameActiveOptionIndex + 1 + optionEls.length) % optionEls.length;
    renderPromoNameSearchOptions(document.getElementById('bundle-promo-name-input')?.value || '');
    return;
  }
  if (event.key === 'ArrowUp') {
    event.preventDefault();
    promoNameActiveOptionIndex = (promoNameActiveOptionIndex - 1 + optionEls.length) % optionEls.length;
    renderPromoNameSearchOptions(document.getElementById('bundle-promo-name-input')?.value || '');
    return;
  }
  if (event.key === 'Enter') {
    event.preventDefault();
    if (promoNameActiveOptionIndex >= 0 && optionEls[promoNameActiveOptionIndex]) {
      selectPromoName(optionEls[promoNameActiveOptionIndex].getAttribute('data-promo-name') || '');
      return;
    }
    const typed = (document.getElementById('bundle-promo-name-input')?.value || '').trim().toLowerCase();
    const allNames = getEligiblePromoNames(bld.promoType);
    const exact = allNames.find((name) => name.toLowerCase() === typed);
    if (exact) selectPromoName(exact);
    return;
  }
  if (event.key === 'Escape') {
    closePromoNameSearchDropdown();
  }
}

function onPromoNameOptionMouseDown(event, promoName) {
  event.preventDefault();
  selectPromoName(promoName);
}

function onPromoNameInputBlur() {
  window.setTimeout(function () {
    const inputEl = document.getElementById('bundle-promo-name-input');
    if (!inputEl) return;
    const typed = inputEl.value.trim();
    const allNames = getEligiblePromoNames(bld.promoType);
    const exact = allNames.find((name) => name.toLowerCase() === typed.toLowerCase());
    if (exact) {
      bld.promoName = exact;
      inputEl.value = exact;
    } else {
      bld.promoName = '';
      inputEl.value = '';
    }
    applyIncentivesCascadeFromPromoName();
    closePromoNameSearchDropdown();
    updateBundlePreview();
  }, 120);
}

function renderMsaDiscountSlider() {
  // Read-only now — discretionary discount is set once, on the option card, and
  // applies to every bundle in that option.
  // Discretionary and tier/term discounts are reflected in Contracted Price; this
  // no-op remains for compatibility with the modal's render pipeline.
}

function getMsaDiscountApprovalNote() {
  const fleetSize = getMsaFleetSizeForBundleModal();
  const term = getMsaTermForBundleModal();
  const boundaries = getMsaDiscretionaryApprovalBoundaries(term, fleetSize);
  const pct = bld.msaDiscountPct || 0;
  const level = getMsaDiscretionaryApprovalLevel(pct, boundaries);
  const autoMax = Math.round(boundaries.autoApproved);
  const assocMax = Math.round(boundaries.associateDirector);
  if (level === 0) return `Auto-approval 0-${autoMax}%`;
  if (level === 1) return `Requires Associate Director approval ${autoMax + 1}-${assocMax}%`;
  return `Requires Director approval ${assocMax + 1}%+`;
}

function selectPromoCard(val) {
  if (!isPromoTypeEligibleForCore(val, bld.coreKey)) return;
  bld.promoType = val;
  bld.promoName = '';
  applyIncentivesCascadeFromPromoName();
  document.getElementById('bundle-promo-dropdown').classList.add('hidden');
  updateBundlePreview();
}

function selectCore(key) {
  const core = corePricing[key];
  bld.coreKey = key;
  bld.coreName = core.name;
  bld.corePrice = core.price;
  document.getElementById('core-label').innerText = core.name;
  document.getElementById('core-label').parentElement.classList.add('selected');
  document.getElementById('core-dropdown').classList.add('hidden');
  document.getElementById('addons-section').classList.remove('hidden');
  document.getElementById('addons-section').style.display = 'block';
  bld.selectedFeatures = [];
  Object.keys(featurePricing).forEach(featureKey => {
    const checkbox = document.getElementById(`addon-${featureKey}`);
    if (checkbox) checkbox.checked = false;
  });
  const sd128 = document.getElementById('sd-card-128');
  const sd256 = document.getElementById('sd-card-256');
  if (sd128 && sd256) {
    sd128.checked = true;
    sd256.checked = false;
  }
  syncAddonControls();
  document.getElementById('btn-create').disabled = false;
  updateBundlePreview();

  // Non-Powered Asset → force CMI, lock the segmented control
  const isNonPowered = key === 'asset-nonpowered';
  const segment = document.getElementById('vmi-segment');
  if (isNonPowered) {
    selectInstallType('CMI');
    if (segment) {
      segment.style.opacity = '0.45';
      segment.style.pointerEvents = 'none';
      segment.title = 'Non-Powered Asset requires CMI installation';
    }
  } else {
    if (segment) {
      segment.style.opacity = '';
      segment.style.pointerEvents = '';
      segment.title = '';
    }
  }
}

function changeQty(d) {
  bld.qty = Math.max(1, bld.qty + d);
  document.getElementById('qty-display').value = bld.qty;
  updateBundlePreview();
}

function setQty(rawValue) {
  const n = parseInt(rawValue, 10);
  if (Number.isNaN(n)) return;
  bld.qty = Math.max(1, n);
  document.getElementById('qty-display').value = bld.qty;
  updateBundlePreview();
}

function togglePreviewHardwareBreakdown() {
  const breakdown = document.getElementById('preview-hardware-breakdown');
  const toggle = breakdown?.previousElementSibling;
  if (!breakdown || !toggle) return;
  const isOpening = breakdown.classList.toggle('hidden');
  const expanded = !isOpening;
  toggle.setAttribute('aria-expanded', String(expanded));
  // 2026-10-01 (per Catalina): the chevron only rotates now (same glyph, same
  // size, always) instead of swapping between expand_more/expand_less — two
  // different glyphs could render at slightly different widths and nudge the
  // price beside it. A CSS transform never changes layout box size.
  const chevron = document.getElementById('preview-hardware-chevron');
  if (chevron) chevron.classList.toggle('preview-hardware-chevron--open', expanded);
}

function updateBundlePreview() {
  renderMsaDiscountSlider();
  renderPromoCards();
  updatePromoAndDiscountDisabledState();
  const isCapexBilling = accountBillingModel === 'both' && bld.billingModel === 'capex';
  if (!bld.coreKey) {
    document.querySelector('.bundle-modal-preview .preview-price')?.classList.toggle('hidden', isCapexBilling);
    document.getElementById('preview-capex-summary')?.classList.toggle('hidden', !isCapexBilling);
    document.getElementById('preview-lines')?.classList.toggle('hidden', !isCapexBilling);
    const previewPriceValue = document.getElementById('preview-price-val');
    if (!isCapexBilling && previewPriceValue) previewPriceValue.textContent = '--';
    if (isCapexBilling) {
      ['preview-capex-first-month', 'preview-capex-hardware', 'preview-capex-subscription', 'preview-capex-ongoing']
        .forEach(id => { const value = document.getElementById(id); if (value) value.textContent = '--'; });
      document.getElementById('preview-capex-hardware-row')?.classList.remove('hidden');
      document.getElementById('preview-lines').innerHTML = `
        <div class="preview-group">
          <div class="preview-group-header"><span>Subscription</span><span>--</span></div>
          <div class="preview-line" style="color:var(--gray-600);">Select a core product to see subscription pricing</div>
        </div>
        <div class="preview-group">
          <div class="preview-group-header"><span>Hardware</span><span>--</span></div>
        </div>`;
    }
    return;
  }

  const optId = bld.targetOptId;
  const opt = bld.targetOptId ? options.find(o => o.id === bld.targetOptId) : null;
  const pilotConfig = opt ? opt.pilot : (accountType === 'pilot' ? getDefaultPilotConfig() : null);
  const isFreePilot = !!(pilotConfig && pilotConfig.pricingMode === 'free');
  const term = opt ? (opt.term || 36) : 36;

  if (bld.mode !== 'prebuilt') syncAddonControls();

  // 2026-09-17 (per Catalina): the itemized subtotal is the LIST price, not the
  // 36-month deck price — otherwise the 36-month deck discount (VTU/VTU-FFC) has
  // nowhere to show up as a $ line. The deck price is still what's actually charged
  // (calcBundle looks it up internally by term+tier); it just isn't what's displayed
  // as the "before discount" reference anymore.
  const addOnBase = getBldBillableFeatures().reduce((sum, featureKey) => sum + (featurePricing[featureKey] || 0), 0);
  const keyfobCost = getKeyfobPrice();
  const monthlyBase = bld.corePrice + addOnBase;
  const basePrice = monthlyBase + keyfobCost;
  const qty = bld.qty || 1;
  const dummyBundle = {
    basePrice: bld.corePrice + addOnBase + keyfobCost,
    baseCorePrice: bld.corePrice,
    qty: bld.qty,
    coreKey: bld.coreKey,
    coreName: bld.coreName,
    features: bld.selectedFeatures || [],
    msaDiscountPct: bld.msaDiscountPct,
    promoName: '',
  };
  // Contracted Price includes tier/term and discretionary discounts; promotions
  // remain a separate step below.
  const { monthly, unitPrice } = calcBundle(dummyBundle, term, null);

  // 2026-09-25 (per Catalina — "aquí está la estructura de lo de la derecha"):
  // Promo is its own waterfall step, computed separately from MSA Price so a promo
  // selected in this same modal (Type/Name/Deal Closer above) shows its own %/$ line
  // instead of silently folding into MSA Price the way it used to. Net Price = MSA
  // Price with the promo applied; "Monthly after promo" = MSA Price × Qty, i.e. what
  // the fleet reverts to once the promo period ends — same convention as the
  // Bundle/Subscription Summary's own "once promotions end" line elsewhere.
  const promoBundle = { ...dummyBundle, promoName: bld.promoName || '', promoType: bld.promoType || 'Standard', dealCloser: bld.dealCloser || '' };
  const { unitPrice: netPrice } = calcBundle(promoBundle, term, promoBundle.promoType);
  const promoAmount = Math.max(0, unitPrice - netPrice);
  const promoPct = unitPrice > 0 ? Math.round((promoAmount / unitPrice) * 100) : 0;
  const hasPromo = promoAmount > 0.005;
  const promoDurationLabel = (bld.promoDurationMonths != null && bld.promoDurationMonths > 0 && bld.promoDurationMonths !== term)
    ? ` (${bld.promoDurationMonths} months)` : '';
  const promoLine = hasPromo
    ? `<div class="preview-line" style="color:var(--brand-blue);font-weight:600;"><span>Promo${promoDurationLabel} (−${promoPct}%)</span><span>−${formatMoney(promoAmount)}</span></div>`
    : '';
  const netPriceLine = hasPromo
    ? `<div class="preview-line" style="border-top:1px solid var(--gray-200);margin-top:4px;padding-top:6px;"><strong>Net Price</strong><strong>${formatMoney(netPrice)}</strong></div>`
    : '';

  // Quantity multiplication (2026-09-17, per Catalina): everything above is per
  // vehicle — spell out the x qty step so the fleet-wide Monthly Total below is
  // traceable back to the per-unit price, instead of jumping straight to it.
  // 2026-10-01 (per Catalina — "el quantity no tiene que ver solo con la
  // suscripción, sino también con el hardware... debería ser uno de esos
  // campos del final"): moved from inside the Subscription group's own line
  // list to a shared closing line below BOTH groups — Qty multiplies into the
  // Hardware group's total too (oneTimeHardwareTotal below is already ×qty),
  // so it belongs next to the other bundle-wide totals, not nested inside one
  // group as if it only applied to that group's math.
  const qtyLine = `<div class="preview-line"><span>QTY</span><strong>${qty}</strong></div>`;
  const monthlyBeforePilotDiscount = hasPromo ? netPrice * qty : monthly;
  const isPaidPilot = !!(pilotConfig && pilotConfig.pricingMode === 'paid');
  const pilotFactor = getPilotConfigPriceFactor(pilotConfig);
  const pilotDiscountAmount = monthlyBeforePilotDiscount * (1 - pilotFactor);
  const pilotDiscountLine = (isFreePilot || isPaidPilot)
    ? `<div class="preview-line" style="color:#1a7f37;font-weight:600;"><span>Pilot discount${isPaidPilot ? ` (${getPaidPilotOffer(pilotConfig).label})` : ''}</span><span>−${formatMoney(pilotDiscountAmount)}</span></div>`
    : '';
  const monthlyForDisplay = monthlyBeforePilotDiscount * pilotFactor;
  const hardwareUnitPrice = isCapexBilling ? getEstimatedHardwareUnitPrice(dummyBundle) : 0;
  const oneTimeHardwareTotal = hardwareUnitPrice * qty;
  // TODO: pricing real de hardware pendiente.
  const tierTermPctForHardware = getTierTermDiscountPct(term, qty);
  const hardwareEstimateBundle = { ...dummyBundle, billingModel: 'capex', isPrebuilt: bld.mode === 'prebuilt' };
  const hardwareComponents = getBundleComponentPrices(hardwareEstimateBundle, tierTermPctForHardware);
  const hardwareBreakdownHtml = hardwareComponents.map(component => {
    const componentHardware = getEstimatedHardwareComponentUnitPrice(hardwareEstimateBundle, component.name, tierTermPctForHardware) * qty;
    return `<div><span>${getHardwareBreakdownLabel(component.name)}</span><span>${formatMoney(componentHardware)}</span></div>`;
  }).join('');
  // 2026-10-01 (per Catalina — "un bordecito que los contenga... pero que por
  // defecto esté colapsado para ver solamente el valor total"): Hardware is now
  // its own group, sibling to Subscription, instead of a line injected partway
  // through Subscription's own breakdown. Collapsed by default (unchanged
  // behavior — only the layout around it changed).
  // 2026-10-01 (per Catalina — "subscription y hardware en un contenedor
  // negro y que la letra sea blanca"): restyled to the same full-bleed black
  // bar as the new Subscription header below, instead of plain text — the
  // toggle button itself IS that bar now (.preview-hardware-accordion-toggle).
  const hardwareGroupHtml = isCapexBilling
    ? `<div class="preview-group">
        <button type="button" class="preview-hardware-accordion-toggle" aria-expanded="false" onclick="togglePreviewHardwareBreakdown()">
          <span class="preview-hardware-accordion-label">Hardware<span class="preview-hardware-accordion-sublabel">One-time charge</span></span>
          <span class="preview-hardware-accordion-right"><strong>${formatMoney(oneTimeHardwareTotal)}</strong><span id="preview-hardware-chevron" class="material-symbols-outlined" aria-hidden="true">expand_more</span></span>
        </button>
        <div id="preview-hardware-breakdown" class="preview-hardware-breakdown hidden">${hardwareBreakdownHtml}</div>
      </div>`
    : '';
  const standardPriceEl = document.querySelector('.bundle-modal-preview .preview-price');
  const capexSummaryEl = document.getElementById('preview-capex-summary');
  standardPriceEl?.classList.toggle('hidden', isCapexBilling);
  capexSummaryEl?.classList.toggle('hidden', !isCapexBilling);
  const firstMonthEl = document.getElementById('preview-capex-first-month');
  const hardwareTotalEl = document.getElementById('preview-capex-hardware');
  const hardwareRowEl = document.getElementById('preview-capex-hardware-row');
  const subscriptionEl = document.getElementById('preview-capex-subscription');
  const ongoingEl = document.getElementById('preview-capex-ongoing');
  hardwareRowEl?.classList.toggle('hidden', !isCapexBilling);
  if (firstMonthEl) firstMonthEl.textContent = formatMoneyAmount((oneTimeHardwareTotal + monthlyForDisplay));
  if (hardwareTotalEl) hardwareTotalEl.textContent = formatMoney(oneTimeHardwareTotal);
  if (subscriptionEl) subscriptionEl.textContent = formatMoney(monthlyForDisplay);
  if (ongoingEl) ongoingEl.textContent = formatMoneyAmount(monthlyForDisplay);
  // 2026-10-01 (per Catalina): final round of Capex panel refinements —
  // "One-time (Hardware)" spells out which group it belongs to; "pon... en
  // regular el texto, pero en bold el valor" — the label is a plain <span>
  // now and only the number is <strong>, everywhere in this closing section
  // (qtyLine above included).
  // 2026-10-01 (per Catalina — "en el último contenedor solamente el
  // quantity y los valores del first month total y el from month to
  // onward"): the Capex closing band only needs Qty, First month total, and
  // the ongoing monthly amount. One-time (Hardware) and Monthly after promo
  // are no longer duplicated in this band — One-time already shows in the
  // Hardware group bar and the headline box; Monthly after promo stays
  // visible via the promo badge/line inside the Subscription group itself.
  // 2026-10-01, round 2 (per Catalina — "First month total" and "From month
  // 2 onward" "no sigue el mismo patrón"): relabeled to "Month 1 total" /
  // "Month 2+ total" everywhere this pair appears (this closing band AND the
  // headline box above it), so both names share the same "Month N total"
  // shape instead of two differently-worded phrases for parallel concepts.
  const monthlyLabel = isCapexBilling ? 'Month 2+ total' : 'Monthly';
  const monthlyAfterPromoLabel = isCapexBilling ? 'Monthly after promo (Subscription)' : 'Monthly after promo';
  const oneTimeTotalLine = isCapexBilling
    ? `<div class="preview-line"><span>One-time (Hardware)</span><strong>${formatMoney(oneTimeHardwareTotal)}</strong></div>`
    : '';
  const monthlyTotalLine = `<div class="preview-line"${isCapexBilling ? '' : ' style="border-top:1px solid var(--gray-300);margin-top:4px;padding-top:6px;"'}>${isCapexBilling ? `<span>${monthlyLabel}</span><strong>${formatMoney(monthlyForDisplay)}</strong>` : `<strong>${monthlyLabel}</strong><strong>${formatMoney(monthlyForDisplay)}</strong>`}</div>`;
  const firstMonthTotalLine = isCapexBilling
    ? `<div class="preview-line"><span>Month 1 total</span><strong>${formatMoney((oneTimeHardwareTotal + monthlyForDisplay))}</strong></div>`
    : '';
  const monthlyAfterPromoLine = hasPromo
    ? `<div class="preview-line">${isCapexBilling ? `<span>${monthlyAfterPromoLabel}</span><strong>${formatMoney((unitPrice * qty))}</strong>` : `<span>${monthlyAfterPromoLabel}</span><span>${formatMoney((unitPrice * qty))}</span>`}</div>`
    : '';

  // 2026-09-25 (per Catalina — same rounding-mismatch bug already fixed in
  // Bundle Summary: "arriba dice 42, abajo dice 42.14"): this big headline
  // number was rounding to the nearest whole dollar with Math.round(),
  // while the "Monthly" line in the receipt below it (monthlyForDisplay,
  // same variable) shows the real amount to the cent — so the two could
  // never actually match whenever the price wasn't already a round dollar
  // figure. Now shows the same number, to the cent, as the line below it.
  if (!isCapexBilling) document.getElementById('preview-price-val').innerText = formatMoneyAmount(monthlyForDisplay);
  document.getElementById('preview-lines').classList.remove('hidden');
  // 2026-09-25 (per Catalina, screenshot of a Plan's itemized features — "con los
  // planes no quiero que discrimine así, un plan tiene un precio completo"): a true
  // Plan is one all-in price, not core + line-per-feature the way a Custom bundle
  // is — matches Leo's original vision (2026-09-24 Priorities call, see session
  // log): "no quiero discriminado... el precio está a nivel del bando." So a Plan
  // shows a single line (name + full price), no feature/keyfob breakdown at all —
  // Custom keeps the existing itemized breakdown.
  const isPlanMode = bld.mode === 'prebuilt';
  // 2026-10-05 (per Catalina): in Bundle mode the extra features show as their
  // own lines right after the bundle (the bundle line excludes them).
  const planExtras = isPlanMode ? (bld.bundleExtras || []) : [];
  const planExtrasTotal = planExtras.reduce((sum, featureKey) => sum + (featurePricing[featureKey] || 0), 0);
  const featureLines = (isPlanMode ? planExtras : (bld.selectedFeatures || [])).map(featureKey =>
    `<div class="preview-line"><span>${featureLabels[featureKey] || featureKey}</span><span>${formatMoney(featurePricing[featureKey])}</span></div>`
  ).join('');
  const keyfobQty = parseInt(document.getElementById('keyfob-qty')?.value, 10) || 3;
  const hasKeyfob = !isPlanMode && bld.selectedFeatures.includes('driver-id');
  const keyfobLine = hasKeyfob
    ? `<div class="preview-line"><span>Keyfobs (×${keyfobQty})</span><span ${keyfobCost === 0 ? 'style="color:#1a7f37;font-weight:600;"' : 'style="color:var(--black);"'}>${keyfobCost > 0 ? formatMoney(keyfobCost) : 'Included'}</span></div>`
    : '';
  // List Price stays as the per-unit reference; Contracted Price below is the
  // net per-unit amount after tier/term and discretionary discounts. Qty remains
  // its own explicit step rather than being folded into either price.
  // 2026-09-25 (per Catalina — "no es redundante decir esto?"): the keyfob note
  // here just repeated what the "Keyfobs (×N)" line right above it already says
  // (including "Included" when the cost is $0) — removed rather than kept only
  // for the nonzero case, since it always duplicated keyfobLine either way.
  const subtotalLines = `
    <div class="preview-line" style="border-top:1px solid var(--gray-200);margin-top:4px;padding-top:6px;"><strong>List Price</strong><strong>${formatMoney(basePrice)}</strong></div>
  `;
  // Both billing models show one Contracted Price after tier/term and
  // discretionary discounts; promotions remain a separate pricing step.
  // In Capex the vertical list also includes Quantity, Monthly and Hardware.
  // 2026-10-02 (per Catalina): Monthly is spelled out right before the
  // hardware group (after QTY, so MSA Price × QTY is traceable), and the
  // hardware group itself is labeled "Hardware (one-time charge)" (renamed
  // from "One-time charge (first month)" per Catalina, so it reads as hardware
  // first; Month 1 total at the top already covers the timing).
  const capexMonthlyLine = `<div class="preview-line" style="border-top:1px solid var(--gray-200);margin-top:4px;padding-top:6px;"><strong>Monthly</strong><strong>${formatMoney(monthlyForDisplay)}</strong></div>`;
  const msaApprovalNote = bld.msaDiscountPct > 0 ? getMsaDiscountApprovalNote() : '';
  const capexMsaPriceLine = `<div class="preview-line" style="border-top:1px solid var(--gray-200);margin-top:4px;padding-top:6px;"><strong>Contracted Price</strong><strong>${formatMoney(unitPrice)}</strong></div>${msaApprovalNote ? `<div class="promo-eligibility-note" style="margin-top:-2px;margin-bottom:4px;">${msaApprovalNote}</div>` : ''}`;
  const subscriptionItemsHtml = `
    <div class="preview-line"><span>${bld.coreName}</span><span>${formatMoney((isPlanMode ? basePrice - planExtrasTotal : bld.corePrice))}</span></div>
    ${featureLines}
    ${keyfobLine}
    ${subtotalLines}
    ${capexMsaPriceLine}
    ${promoLine}
    ${netPriceLine}
    ${pilotDiscountLine}
  `;
  // 2026-10-01 (per Catalina, after a full visual exploration round):
  // Subscription and Hardware are both full-bleed black bars with white text
  // and the group's total inline ("un contenedor negro y que la letra sea
  // blanca... que vayan hasta el final del beige") — same treatment for both,
  // equal visual weight. Qty through First month total render inside their
  // own closing band (.preview-closing-group), set apart from the two groups
  // above as "la reunión de esas dos cosas". Non-Capex mode is unchanged
  // (single flat list, no groups, no bars, no closing band).
  // 2026-10-02 (per Catalina): the Capex list now ends at the Hardware
  // (one-time) group — the closing "Total" band (QTY / Month 1 total /
  // Month 2+ total) is no longer rendered, since Month 1 and Month 2+ already
  // show side by side at the top of the panel. Kept built here (unused) in
  // case it's wanted back.
  const closingGroupHtml = isCapexBilling
    ? `<div class="preview-closing-group">
        <div class="preview-closing-group-title">Total</div>
        ${qtyLine}
        ${firstMonthTotalLine}
        ${monthlyTotalLine}
      </div>`
    : '';
  document.getElementById('preview-lines').innerHTML = isCapexBilling
    ? `
      <div class="preview-group">
        <div class="preview-group-header"><span>Subscription</span><span>${formatMoney(monthlyForDisplay)}</span></div>
        ${subscriptionItemsHtml}
        ${qtyLine}
        ${capexMonthlyLine}
      </div>
      ${hardwareGroupHtml}
    `
    : `
      ${subscriptionItemsHtml}
      ${qtyLine}
      ${oneTimeTotalLine}
      ${monthlyTotalLine}
      ${firstMonthTotalLine}
      ${monthlyAfterPromoLine}
    `;
}

function selectInstallType(type) {
  const segVmi = document.getElementById('seg-vmi');
  const segCmi = document.getElementById('seg-cmi');
  const ACTIVE = 'segmented-control__option--active';
  if (segVmi) segVmi.classList.toggle(ACTIVE, type === 'VMI');
  if (segCmi) segCmi.classList.toggle(ACTIVE, type === 'CMI');
  proposalData.vcmiMode = type;
  const modeEl = document.getElementById('header-prop-vcmi-mode');
  if (modeEl) modeEl.textContent = type;
}

function proposalEscapeHtml(value) {
  return String(value == null ? '' : value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/\"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

// ── Form state helpers (2026-10-07: extracted from Initial Sales' openConfigureBundle / createBundle) ──
// Each flow keeps its own entry point (Initial Sales: openConfigureBundle; Existing Accounts:
// Select Transaction → Expansion) and its own save (what happens to the option after saving).

/** Reset the Configure Solution form for a new solution. */
function csResetForm(optId) {
  bld.qty = 1;
  bld.coreKey = null;
  // A new bundle added to an option that already has a discretionary discount
  // dialed in should inherit that %, not silently reset to 0 (2026-09-14, per Catalina).
  bld.msaDiscountPct = optId ? Number(options.find(o => o.id === optId)?.msaDiscountPct) || 0 : 0;
  bld.promoType = 'Standard';
  bld.promoName = '';
  bld.dealCloser = '';
  bld.promoDurationMonths = null;
  bld.selectedFeatures = [];
  resetPrebuiltState();
  document.getElementById('core-label').innerText = 'Select core...';
  document.getElementById('core-label').parentElement.classList.remove('selected');
  document.getElementById('qty-display').value = bld.qty;
  bld.billingModel = 'opex';
  syncBundleBillingModelSegment();
  syncBundleBillingModelVisibility();
  document.getElementById('addons-section').classList.add('hidden');
  Object.keys(featurePricing).forEach(featureKey => {
    const checkbox = document.getElementById(`addon-${featureKey}`);
    if (checkbox) checkbox.checked = false;
  });
  const evcSelect = document.getElementById('evc-type-select');
  if (evcSelect) evcSelect.value = 'sides-rear-cargo';
  const sd128 = document.getElementById('sd-card-128');
  const sd256 = document.getElementById('sd-card-256');
  if (sd128 && sd256) {
    sd128.checked = true;
    sd256.checked = false;
  }
  document.getElementById('btn-create').disabled = true;
  document.getElementById('preview-lines').classList.add('hidden');
  document.getElementById('preview-capex-summary')?.classList.add('hidden');
  document.querySelector('.bundle-modal-preview .preview-price')?.classList.remove('hidden');
  document.getElementById('preview-price-val').innerText = '--';
  // Reset accordion state so they open fresh on next core selection
  ['acc-video','acc-vehicle'].forEach(id => {
    const el = document.getElementById(id);
    if (el) {
      el.classList.remove('is-open');
      el.querySelector('.vc-accordion__header')?.setAttribute('aria-expanded', 'false');
      delete el.dataset.manualToggle;
    }
  });
}

/** Load an existing solution (bundle) into the form for editing. */
function csLoadBundle(optId, bundle) {
  const opt = options.find(o => o.id === optId) || {};
  builderMode = bundle.isPrebuilt ? 'plan' : 'custom';
  simBuilderDraft.bundleConstruction = builderMode;
  if (bundle.isPrebuilt) {
    bld.prebuiltBundleKey = bundle.bundleKey;
    bld.prebuiltTierKey = bundle.tierKey;
    bld.bundleExtras = Array.isArray(bundle.bundleExtras) ? [...bundle.bundleExtras] : [];
    const tier = getPrebuiltTierByKey(bundle.bundleKey, bundle.tierKey);
    const planLabel = document.getElementById('plan-label');
    if (planLabel) planLabel.textContent = tier?.label || 'Select bundle...';
    document.getElementById('plan-btn')?.classList.toggle('selected', !!tier);
  } else {
    resetPrebuiltState();
  }
  bld.qty = bundle.qty;
  // Discretionary discount is set at the option level (single source of truth) —
  // always read the option's live value here, never the bundle's own possibly-stale
  // copy, so this modal can't silently diverge from the option card's slider
  // (2026-09-14, per Catalina: "pongo 8% y en el discretionary discount me está
  // poniendo 7%" — the bug was this modal having its own independent value).
  bld.msaDiscountPct = Number(opt.msaDiscountPct) || 0;
  bld.promoType = bundle.promoType || 'Standard';
  bld.promoName = bundle.promoName || '';
  bld.dealCloser = bundle.dealCloser || '';
  bld.promoDurationMonths = bundle.promoDurationMonths != null ? bundle.promoDurationMonths : null;
  // Save features before selectCore() — it wipes bld.selectedFeatures internally
  const savedFeatures = (Array.isArray(bundle.features) ? [...bundle.features] : []).filter(key => !(bundle.accountAppliedFeatures || []).includes(key));
  selectCore(bundle.coreKey);
  // Restore features and re-check checkboxes after selectCore cleared them
  bld.selectedFeatures = savedFeatures;
  // 2026-10-05 fix (per Catalina): editing a bundle (Bundle mode) showed the
  // core's name and core-only price ("VTU + Forward Facing Camera") instead
  // of the bundle ("Safety — Advanced") — selectCore() overwrote them.
  if (bundle.isPrebuilt) {
    const editTier = getPrebuiltTierByKey(bundle.bundleKey, bundle.tierKey);
    if (editTier) {
      bld.coreName = bundle.coreName;
      bld.corePrice = getPrebuiltTierUnitPrice(bundle.bundleKey, editTier, bld.promoType || 'Standard');
    }
  }
  Object.keys(featurePricing).forEach(featureKey => {
    const checkbox = document.getElementById(`addon-${featureKey}`);
    if (checkbox) checkbox.checked = savedFeatures.includes(featureKey);
  });
  const evcSelect = document.getElementById('evc-type-select');
  if (evcSelect) evcSelect.value = bundle.evcType || 'sides-rear-cargo';
  const keyfobQtyEl = document.getElementById('keyfob-qty');
  if (keyfobQtyEl) keyfobQtyEl.value = bundle.keyfobQty ?? 3;
  const sd128 = document.getElementById('sd-card-128');
  const sd256 = document.getElementById('sd-card-256');
  if (sd128 && sd256) {
    const has256 = savedFeatures.includes('sd-256');
    sd256.checked = has256;
    sd128.checked = !has256;
  }
  syncAddonControls();
  document.getElementById('qty-display').value = bld.qty;
  bld.billingModel = bundle.billingModel || 'opex';
  syncBundleBillingModelSegment();
  syncBundleBillingModelVisibility();
}

/** Build the solution (bundle) object from the form. Returns null when a bundle tier is incomplete. */
function csBuildBundleData() {
const isPrebuilt = bld.mode === 'prebuilt';
const selectedPlan = isPrebuilt ? getPrebuiltBundleByKey(bld.prebuiltBundleKey) : null;
const selectedPlanTier = isPrebuilt ? getPrebuiltTierByKey(bld.prebuiltBundleKey, bld.prebuiltTierKey) : null;
if (isPrebuilt && (!selectedPlan || !selectedPlanTier)) return null;
if (!isPrebuilt) syncAddonControls();
const bundleExtras = isPrebuilt ? (bld.bundleExtras || []).filter(key => !getPrebuiltTierFeatureKeys(selectedPlanTier).includes(key)) : [];
const selectedFeatures = isPrebuilt ? [...getPrebuiltTierFeatureKeys(selectedPlanTier), ...bundleExtras] : [...(bld.selectedFeatures || [])];
const selectedCoreKey = isPrebuilt ? selectedPlanTier.coreKey : bld.coreKey;
const selectedCoreName = isPrebuilt ? `${selectedPlan.name} — ${selectedPlanTier.label}` : bld.coreName;
const selectedCorePrice = isPrebuilt
  ? getPrebuiltTierUnitPrice(bld.prebuiltBundleKey, selectedPlanTier, bld.promoType || 'Standard')
  : bld.corePrice;
const addOnBase = (isPrebuilt ? bundleExtras : selectedFeatures).reduce((sum, featureKey) => sum + (featurePricing[featureKey] || 0), 0);
const keyfobCost = getKeyfobPrice();
const keyfobQty = selectedFeatures.includes('driver-id')
  ? (parseInt(document.getElementById('keyfob-qty')?.value, 10) || 3)
  : 3;
const bundleData = {
  id: bld.targetBundleId || Date.now(),
  coreKey: selectedCoreKey,
  coreName: selectedCoreName,
  basePrice: selectedCorePrice + addOnBase + keyfobCost,
  baseCorePrice: selectedCorePrice,
  features: selectedFeatures,
  evcType: selectedFeatures.includes('evc') ? getSelectedEvcType() : null,
  keyfobQty,
  qty: bld.qty,
  // Always re-read the option's live discretionary discount at save time rather
  // than trusting bld.msaDiscountPct (which is just a display copy) — closes the
  // desync where this modal could silently overwrite a bundle with a stale %.
  msaDiscountPct: bld.targetOptId ? (Number(options.find(o => o.id === bld.targetOptId)?.msaDiscountPct) || 0) : 0,
  promoType: bld.promoType || 'Standard',
  promoName: bld.promoName || '',
  dealCloser: bld.dealCloser || '',
  promoDurationMonths: bld.promoDurationMonths != null ? bld.promoDurationMonths : null,
  isPrebuilt,
  bundleKey: isPrebuilt ? bld.prebuiltBundleKey : null,
  tierKey: isPrebuilt ? bld.prebuiltTierKey : null,
  bundleExtras,
  // Per-bundle Opex/Capex override — only meaningful when the account's Billing
  // model is "both"; otherwise the bundle just follows the account-wide model.
  billingModel: accountBillingModel === 'both'
    ? (bld.billingModel === 'capex' ? 'capex' : 'opex')
    : accountBillingModel,
};
  return bundleData;
}
