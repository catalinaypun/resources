/* Valu Cal — Contract step (shared: create-contract loader + Contract screen), 2026-10-07.
   One implementation for Initial Sales and Existing Accounts (A2 + A3). Source: Initial Sales.
   Markup: VC.contractScreenMarkup(), VC.quoteLoaderMarkup(), VC.promoValidationFailMarkup(),
   VC.contractPreviewMarkup() — each flow drops them into hosts.
   Flow hooks (stay per flow): confirmSelectionAndProceed (what happens before the loader), enterDealResult,
   renderNav, renderOptions / renderSelectionOptions, touchNavDate, showSuccessBanner, updateFulfillmentBtn,
   updateSendBtn, calcOption, logProposalEvent. Optional: getProposalDocMsaSummary() (MSA box in the
   contract), getContractCreatedBanner() → [title, body]. */
window.VC = window.VC || {};
window.VC.contractScreenMarkup = function () { return "<div id=\"screen-contract\" class=\"content-area hidden\" style=\"padding-bottom: 80px;\">\n\n    <!-- \u2500\u2500 PHASE 0: Contract Review gate (live DocuSign preview) \u2500\u2500 -->\n    <div id=\"contract-phase-contractpreview\" class=\"hidden\" style=\"margin-top:0;\">\n      <div class=\"contract-preview-step\">\n        <div class=\"contract-preview-step-head\">\n          <div class=\"contract-preview-step-head-copy\">\n            <h3>Contract Review</h3>\n            <p>Review the contract before sending it. It will be sent through the Purchase Portal to <strong id=\"contract-portal-recipient-email\">--</strong>.</p>\n          </div>\n          <div class=\"contract-preview-step-head-actions\">\n            <div class=\"kebab-menu\">\n            <button class=\"btn-icon btn-icon--tonal btn-icon--vds-small\" type=\"button\" onclick=\"toggleContractPreviewMenu(event)\" aria-label=\"More actions\" aria-haspopup=\"true\" aria-expanded=\"false\">\n              <span class=\"material-symbols-outlined\">more_vert</span>\n            </button>\n            <div id=\"more-menu-contract-preview\" class=\"kebab-menu__panel hidden\" role=\"menu\">\n              <button type=\"button\" class=\"kebab-menu__item\" role=\"menuitem\" onclick=\"openContractScheduleModal()\">Edit service order schedule</button>\n              <button type=\"button\" class=\"kebab-menu__item\" role=\"menuitem\" onclick=\"openContractModifyConfirmModal()\">Modify proposal</button>\n              <div id=\"sim-title-contract-preview\" class=\"kebab-menu__label simulation-title\">\n                Simulation\n              </div>\n              <button id=\"sim-contract-signed-contract-preview\" type=\"button\" class=\"kebab-menu__item simulation-action\" role=\"menuitem\" onclick=\"simulateContractSigned()\">Contract signed</button>\n              <button id=\"sim-payment-setup-contract-preview\" type=\"button\" class=\"kebab-menu__item simulation-action\" role=\"menuitem\" onclick=\"simulatePaymentSetup()\">Payment setup configured</button>\n              <div class=\"kebab-menu__divider\" role=\"separator\"></div>\n              <button type=\"button\" class=\"kebab-menu__item kebab-menu__item--danger\" role=\"menuitem\" onclick=\"openMarkDeadModal()\">Mark dead deal</button>\n            </div>\n            </div>\n            <!-- 2026-10-05 (per Leo / Catalina \u2014 Topic 5 of the 2026-10-01 call):\n                 the editable-email step is gone. The contract goes to the\n                 Customer Portal, which notifies the customer itself; no\n                 confirmation modal (per Leo) \u2014 the recipient is stated in the\n                 Contract Review subtitle (moved there from under the button,\n                 per Catalina, 2026-10-05: it read as cluttered). -->\n            <button type=\"button\" class=\"btn btn--primary btn--large\" onclick=\"sendContractToCustomerPortal()\">Send Purchase Portal Link</button>\n          </div>\n        </div>\n        <div class=\"contract-preview-live-note notification notification--info\" role=\"status\" aria-live=\"polite\">\n          <span class=\"notification__icon\" aria-hidden=\"true\"><span class=\"material-symbols-outlined\">info</span></span>\n          <div class=\"notification__body\">\n            <p class=\"notification__title\">This is a live preview from DocuSign.</p>\n            <p class=\"notification__message\">Nothing here is editable in ValuCal. To make changes, edit the contract directly in DocuSign. Updates will appear here automatically.</p>\n          </div>\n        </div>\n        <div class=\"contract-preview-doc-shell\">\n          <div class=\"contract-preview-viewer-toolbar\">\n            <button type=\"button\" class=\"btn-icon btn-icon--solid btn-icon--vds-small\" onclick=\"refreshContractPreview(this)\" aria-label=\"Refresh contract preview\" title=\"Refresh contract preview\"><span class=\"material-symbols-outlined\" aria-hidden=\"true\">refresh</span></button>\n          </div>\n          <div class=\"doc-viewer\" id=\"contract-doc-viewer\"></div>\n        </div>\n      </div>\n    </div>\n\n    <!-- \u2500\u2500 PHASE 1: Review & Send (proposal-style layout) \u2500\u2500 -->\n    <div id=\"contract-phase-review\" class=\"review-master-container hidden\" style=\"margin-top:0;\">\n      <div class=\"review-header-bar\">\n        <h2 class=\"ql-page-title\" style=\"flex:1; min-width:0; padding-right:12px; margin:0; font-family:var(--font-family-etext, 'VerizonNHGDS', sans-serif);\">\n          Contract Delivery Message\n        </h2>\n        <div style=\"display:flex; align-items:center; gap:8px; position:relative; flex-shrink:0;\">\n          <div class=\"kebab-menu\">\n          <button class=\"btn-icon btn-icon--tonal btn-icon--vds-small\" type=\"button\" onclick=\"toggleContractMenu(event)\" aria-label=\"More actions\" aria-haspopup=\"true\" aria-expanded=\"false\">\n            <span class=\"material-symbols-outlined\">more_vert</span>\n          </button>\n          <div id=\"more-menu-contract\" class=\"kebab-menu__panel hidden\" role=\"menu\">\n            <button type=\"button\" class=\"kebab-menu__item\" role=\"menuitem\" onclick=\"openContractScheduleModal()\">Edit service order schedule</button>\n            <button type=\"button\" class=\"kebab-menu__item\" role=\"menuitem\" onclick=\"openContractModifyConfirmModal()\">Modify proposal</button>\n            <div id=\"sim-title-contract\" class=\"kebab-menu__label simulation-title\">\n              Simulation\n            </div>\n            <button id=\"sim-contract-signed-contract\" type=\"button\" class=\"kebab-menu__item simulation-action\" role=\"menuitem\" onclick=\"simulateContractSigned()\">Contract signed</button>\n            <button id=\"sim-payment-setup-contract\" type=\"button\" class=\"kebab-menu__item simulation-action\" role=\"menuitem\" onclick=\"simulatePaymentSetup()\">Payment setup configured</button>\n            <div class=\"kebab-menu__divider\" role=\"separator\"></div>\n            <button type=\"button\" class=\"kebab-menu__item kebab-menu__item--danger\" role=\"menuitem\" onclick=\"openMarkDeadModal()\">Mark dead deal</button>\n          </div>\n          </div>\n          <button type=\"button\" class=\"btn btn--secondary btn--large\" onclick=\"openContractInDocuSign()\">View Contract</button>\n          <button type=\"button\" class=\"btn btn--primary btn--large\" id=\"contract-send-btn\" onclick=\"handleSend()\" disabled><svg width=\"18\" height=\"18\" viewBox=\"0 0 24 24\" fill=\"currentColor\" style=\"margin-right:4px;flex-shrink:0;\"><path d=\"M2.01 21L23 12 2.01 3 2 10l15 2-15 2z\"/></svg><span>Send Contract</span></button>\n        </div>\n      </div>\n      <div id=\"contract-message-inline-fields\" class=\"proposal-message-inline-fields\" style=\"padding:14px 32px 10px; border-bottom:1px solid var(--gray-200); margin-bottom:0;\">\n        <div class=\"vds-field proposal-message-to-field\" style=\"margin-bottom:0 !important;\">\n          <label class=\"vc-field-label\" for=\"contract-msg-to\">To</label>\n          <input class=\"input\" type=\"text\" id=\"contract-msg-to\" placeholder=\"Enter email...\" oninput=\"updateContractSendBtn()\">\n        </div>\n        <div class=\"vds-field proposal-message-subject-field\" style=\"margin-bottom:0 !important;\">\n          <label class=\"vc-field-label\" for=\"contract-msg-subject\">Subject</label>\n          <input class=\"input\" type=\"text\" id=\"contract-msg-subject\" placeholder=\"Enter subject...\" oninput=\"updateContractSendBtn()\">\n        </div>\n      </div>\n      <div class=\"review-content-layout\">\n        <!-- Left: message form -->\n        <div class=\"review-message-pane\">\n          <div style=\"font-size:20px; font-weight:700; margin-bottom:16px;\">Message</div>\n          <div class=\"vds-field\">\n            <div style=\"font-size:11px;font-weight:700;color:var(--gray-500);text-transform:uppercase;letter-spacing:0.04em;margin-bottom:6px;\">Message content</div>\n            <div id=\"contract-message-content-list\" style=\"display:flex;flex-direction:column;gap:8px;margin-bottom:12px;\"></div>\n            <div id=\"contract-msg-body\" contenteditable=\"true\" spellcheck=\"true\" style=\"display:none; width:100%; border:1px solid var(--black); border-radius:8px; padding:16px; min-height:360px; font-family:'VerizonNHGDS',sans-serif; font-size:14px; line-height:1.7; outline:none; overflow-y:auto; color:#1a1a1a; box-sizing:border-box; cursor:text; white-space:pre-wrap;\" oninput=\"onContractMessageInput()\"></div>\n            <div style=\"display:none; font-size:11px; color:var(--gray-400); text-align:right; margin-top:4px;\"><span id=\"contract-char-count\">0</span>/2000</div>\n          </div>\n        </div>\n        <!-- Right: contract email preview -->\n        <div class=\"review-preview-pane\">\n          <div class=\"review-preview-card\">\n            <div style=\"display:flex;align-items:center;justify-content:space-between;background:#f8f3e9;border-radius:10px 10px 0 0;padding:12px 16px;margin:-14px -14px 0;border-bottom:1px solid #e9dfc9;position:sticky;top:-14px;z-index:10;flex-shrink:0;\">\n              <div style=\"font-size:18px; font-weight:700;\">Email</div>\n              <div class=\"segmented-control\" role=\"group\" aria-label=\"Contract message format selector\">\n                <button type=\"button\" id=\"contract-message-format-plain\" class=\"segmented-control__option\" onclick=\"setContractMessageFormat('plain')\">Plain text</button>\n                <button type=\"button\" id=\"contract-message-format-visual\" class=\"segmented-control__option segmented-control__option--active\" onclick=\"setContractMessageFormat('visual')\">Visual email</button>\n              </div>\n            </div>\n            <div class=\"message-preview-card\" id=\"contract-msg-preview-card\" style=\"margin-top:14px;\">\n              <div class=\"message-preview-meta\"><strong>To:</strong> <span id=\"contract-msg-preview-to\">-</span></div>\n              <div class=\"message-preview-meta\"><strong>Subject:</strong> <span id=\"contract-msg-preview-subject\">-</span></div>\n              <div class=\"message-preview-body\" id=\"contract-msg-preview-body\"></div>\n            </div>\n          </div>\n        </div>\n      </div>\n    </div>\n\n    <!-- \u2500\u2500 PHASE 2: Sign & Payment (action bar + preview only) \u2500\u2500 -->\n    <div id=\"contract-phase-signpay\" class=\"hidden\" style=\"background:white; border:1px solid var(--gray-200); border-radius:8px; overflow:hidden;\">\n      <div class=\"review-header-bar\">\n        <h2 class=\"ql-page-title\" style=\"flex:1; min-width:0; padding-right:12px; margin:0; font-family:var(--font-family-etext, 'VerizonNHGDS', sans-serif);\">\n          Signature & Payment Tracking\n        </h2>\n        <div style=\"display:flex; gap:8px; align-items:center; position:relative;\">\n          <div class=\"kebab-menu\">\n          <button type=\"button\" class=\"btn-icon btn-icon--tonal btn-icon--vds-small\" onclick=\"toggleContractMenu2(event)\" aria-label=\"More actions\" aria-haspopup=\"true\" aria-expanded=\"false\">\n            <span class=\"material-symbols-outlined\">more_vert</span>\n          </button>\n          <div id=\"more-menu-contract2\" class=\"kebab-menu__panel hidden\" role=\"menu\">\n            <button type=\"button\" class=\"kebab-menu__item\" role=\"menuitem\" onclick=\"openContractScheduleModal()\">Edit service order schedule</button>\n            <button type=\"button\" class=\"kebab-menu__item\" role=\"menuitem\" onclick=\"resendContractLink()\">Resend Contract</button>\n            <button type=\"button\" class=\"kebab-menu__item\" role=\"menuitem\" onclick=\"openContractModifyConfirmModal()\">Modify proposal</button>\n            <div id=\"sim-title-contract2\" class=\"kebab-menu__label simulation-title\">\n              Simulation\n            </div>\n            <button id=\"sim-contract-signed-contract2\" type=\"button\" class=\"kebab-menu__item simulation-action\" role=\"menuitem\" onclick=\"simulateContractSigned()\">Contract signed</button>\n            <button id=\"sim-payment-setup-contract2\" type=\"button\" class=\"kebab-menu__item simulation-action\" role=\"menuitem\" onclick=\"simulatePaymentSetup()\">Payment setup configured</button>\n            <div class=\"kebab-menu__divider\" role=\"separator\"></div>\n            <button type=\"button\" class=\"kebab-menu__item kebab-menu__item--danger\" role=\"menuitem\" onclick=\"openMarkDeadModal()\">Mark dead deal</button>\n          </div>\n          </div>\n        </div>\n      </div>\n      <div id=\"contract-send-loader\" class=\"contract-send-loader hidden\" role=\"status\" aria-live=\"polite\">\n        <div class=\"contract-send-loader__inner\">\n          <div class=\"loader loader--small\" aria-hidden=\"true\"><svg class=\"loader__spinner\" viewBox=\"0 0 64 64\" fill=\"none\"><circle class=\"loader__track\" cx=\"32\" cy=\"32\" r=\"28\" stroke-width=\"6\" stroke-linecap=\"round\"/><path class=\"loader__arc\" d=\"M32 4 A28 28 0 0 1 60 32\" stroke-width=\"6\" stroke-linecap=\"round\" fill=\"none\"/></svg></div>\n          <div class=\"contract-send-loader__text\">Sending contract to customer...</div>\n        </div>\n      </div>\n      <div id=\"sp-waiting-message\" class=\"sp-waiting-message hidden is-waiting\" role=\"status\" aria-live=\"polite\">\n        <span id=\"sp-waiting-message-icon\" class=\"material-symbols-outlined\" aria-hidden=\"true\">mark_email_read</span>\n        <div>\n          <div id=\"sp-waiting-message-title\" class=\"sp-waiting-title\">Contract sent successfully</div>\n          <div id=\"sp-waiting-message-copy\" class=\"sp-waiting-copy\">The contract is now with the customer. We are waiting for signature and payment setup to complete before moving to Deal Result.</div>\n          <div class=\"sp-waiting-actions\">\n            <button type=\"button\" class=\"btn btn--secondary btn--large\" onclick=\"openContractInDocuSign()\">View Contract</button>\n          </div>\n        </div>\n      </div>\n      <div class=\"vc-checklist-wrap\" id=\"sp-checklist-wrap\">\n        <div class=\"vc-checklist\">\n          <div class=\"vc-checklist__title\">Contract progress</div>\n          <!-- 2026-10-05 (per Catalina): first, already-checked step stating\n               where the contract was sent. -->\n          <div class=\"vc-checklist__row hidden\" id=\"sp-row-portal\">\n            <span class=\"vc-checklist__state vc-checklist__state--done\" aria-hidden=\"true\"><span class=\"material-symbols-outlined\">check</span></span>\n            <div>\n              <div class=\"vc-checklist__label\">Sent to Purchase Portal</div>\n              <div class=\"vc-checklist__sub\" id=\"sp-portal-sub\">Contract sent to --</div>\n              <div class=\"vc-checklist__meta\" id=\"sp-portal-date\">--</div>\n            </div>\n          </div>\n          <div class=\"vc-checklist__row\" id=\"sp-row-signature\">\n            <span class=\"vc-checklist__state vc-checklist__state--progress\" id=\"sp-signature-state-icon\" aria-hidden=\"true\"><div class=\"loader\"><svg class=\"loader__spinner\" viewBox=\"0 0 64 64\" fill=\"none\" aria-hidden=\"true\"><circle class=\"loader__track\" cx=\"32\" cy=\"32\" r=\"28\" stroke-width=\"6\" stroke-linecap=\"round\"/><path class=\"loader__arc\" d=\"M32 4 A28 28 0 0 1 60 32\" stroke-width=\"6\" stroke-linecap=\"round\" fill=\"none\"/></svg></div></span>\n            <div>\n              <div class=\"vc-checklist__label\">Client Signature</div>\n              <div class=\"vc-checklist__sub\" id=\"sp-signature-sub\">Waiting for customer signature in DocuSign.</div>\n              <div class=\"vc-checklist__meta\" id=\"sp-signature-date\"></div>\n            </div>\n          </div>\n          <div class=\"vc-checklist__row\" id=\"sp-row-payment\">\n            <span class=\"vc-checklist__state vc-checklist__state--pending\" id=\"sp-payment-state-icon\" aria-hidden=\"true\"></span>\n            <div>\n              <div class=\"vc-checklist__label\">Payment Setup</div>\n              <div class=\"vc-checklist__sub\" id=\"sp-payment-sub\">Starts after contract signature is completed.</div>\n              <div class=\"vc-checklist__meta\" id=\"sp-payment-date\">Pending</div>\n            </div>\n          </div>\n        </div>\n      </div>\n    </div>\n\n  </div>"; };
window.VC.quoteLoaderMarkup = function () { return "<div class=\"vc-stage-loader-overlay\" id=\"quote-loader-overlay\" aria-live=\"polite\" aria-busy=\"true\">\n  <div class=\"vc-stage-loader\">\n    <div class=\"vc-stage-loader__progress\">\n      <div class=\"vc-stage-loader__track\">\n        <div class=\"vc-stage-loader__fill\" id=\"ql-fill\"></div>\n      </div>\n      <div class=\"vc-stage-loader__labels\">\n        <span class=\"vc-stage-loader__label is-active\" id=\"ql-label-0\">Validation</span>\n        <span class=\"vc-stage-loader__label\" id=\"ql-label-1\">Opportunity</span>\n        <span class=\"vc-stage-loader__label\" id=\"ql-label-2\">Quote</span>\n        <span class=\"vc-stage-loader__label\" id=\"ql-label-3\">Contract</span>\n      </div>\n    </div>\n\n    <div class=\"vc-stage-loader__headline\" id=\"ql-headline\">Validating promotions &amp; programs</div>\n    <div class=\"vc-stage-loader__body\" id=\"ql-body\">\n      Checking that the selected promotions and discount<br>programs are still valid for this proposal.\n    </div>\n\n    <div class=\"vc-stage-loader__warning\">Don't close or refresh this window</div>\n  </div>\n</div>"; };
window.VC.promoValidationFailMarkup = function () { return "<div class=\"modal-overlay\" id=\"promo-validation-fail-overlay\">\n  <div class=\"modal\" role=\"alertdialog\" aria-modal=\"true\" aria-labelledby=\"promo-validation-fail-title\" onclick=\"event.stopPropagation()\">\n    <button type=\"button\" class=\"modal__close btn-icon btn-icon--ghost-vds btn-icon--vds-large\" onclick=\"backToOptionsFromPromoValidation()\" aria-label=\"Close promotion validation message\"><span class=\"material-symbols-outlined\" aria-hidden=\"true\">close</span></button>\n    <div class=\"modal__content\">\n      <h2 class=\"modal__title\" id=\"promo-validation-fail-title\">A promotion no longer applies</h2>\n      <div class=\"modal__body\" id=\"promo-validation-fail-body\"></div>\n    </div>\n    <div class=\"modal__actions modal__actions--fill-container\">\n      <button class=\"btn btn--secondary btn--large\" onclick=\"backToOptionsFromPromoValidation()\">Back to options</button>\n      <button class=\"btn btn--primary btn--large\" onclick=\"removePromoAndContinue()\">Continue</button>\n    </div>\n  </div>\n</div>"; };
window.VC.contractPreviewMarkup = function () { return "<div id=\"contract-preview-overlay\" class=\"overlay\" onclick=\"handleContractPreviewOverlayClick(event)\">\n    <div class=\"contract-preview-modal\" role=\"dialog\" aria-modal=\"true\" aria-label=\"Contract preview from DocuSign\">\n      <div class=\"contract-preview-modal-head\">\n        <div>\n          <div class=\"contract-preview-modal-title\">Contract preview</div>\n          <div class=\"contract-preview-modal-sub\">Live preview from DocuSign. To make changes, edit the contract in DocuSign and the updated version will appear here automatically.</div>\n        </div>\n        <div class=\"contract-preview-modal-head-actions\">\n          <button type=\"button\" class=\"btn-icon btn-icon--ghost-vds btn-icon--vds-large\" onclick=\"closeContractPreviewModal()\" aria-label=\"Close contract preview\">\n            <span class=\"material-symbols-outlined\">close</span>\n          </button>\n        </div>\n      </div>\n      <div class=\"contract-preview-modal-body\">\n        <div class=\"contract-preview-viewer-toolbar\">\n          <button type=\"button\" class=\"btn-icon btn-icon--solid btn-icon--vds-small\" onclick=\"refreshContractPreview(this)\" aria-label=\"Refresh contract preview\" title=\"Refresh contract preview\"><span class=\"material-symbols-outlined\" aria-hidden=\"true\">refresh</span></button>\n        </div>\n        <div class=\"doc-viewer\" id=\"contract-doc-viewer-modal\"></div>\n      </div>\n    </div>\n  </div>"; };

// MSA box in the contract document (Existing: same facts as the MSA panel; Initial Sales: none).
function buildContractMsaBoxHtml() {
  if (typeof getProposalDocMsaSummary !== 'function') return '';
  const summary = getProposalDocMsaSummary();
  if (!summary || !summary.fields || !summary.fields.length) return '';
  const cell = (label, value) => `<div><div style="font-size:10px;font-weight:700;margin-bottom:3px;white-space:nowrap;">${label}</div><div style="font-size:11px;color:#222;white-space:nowrap;">${value}</div></div>`;
  return `<div style="background:#fff;border:1px solid #000;border-radius:4px;padding:10px 16px 12px;margin:0 0 18px;">
      <div style="background:#000;color:#fff;font-size:10px;font-weight:700;padding:8px 16px;margin:-10px -16px 10px;border-radius:3px 3px 0 0;">Master Service Agreement${summary.title ? ` · ${summary.title}` : ''}</div>
      <div style="display:grid;grid-template-columns:repeat(${summary.fields.length}, auto);justify-content:space-between;gap:12px;">${summary.fields.map(f => cell(f.label, f.value)).join('')}</div>
    </div>`;
}

const CONTRACT_MESSAGE_DEFAULT_MODULE_SELECTION = {
  contractSummary: true,
  signatureSteps: true,
  activationPlan: false,
  supportWindow: true,
};
const CONTRACT_MESSAGE_FORMATS = { PLAIN: 'plain', VISUAL: 'visual' };
const CONTRACT_MESSAGE_MODULE_OPTIONS = [
  {
    key: 'intro',
    label: 'Intro',
    kind: 'text',
    mandatory: true,
    text:
`Hi {{contactName}},

Your contract package for Option {{optionNumber}} is ready.
Please review the agreement details below and use the View Contract button to continue.`
  },
  {
    key: 'contractSummary',
    label: 'Contract summary',
    kind: 'list',
    visibleByDefault: true,
    items: [
      'Selected option: {{optionNumber}}',
      'Contract term: {{term}}',
      'Monthly investment: {{monthlyValue}}',
      'Total units: {{totalUnits}}'
    ]
  },
  {
    key: 'signatureSteps',
    label: 'Signature steps',
    kind: 'list',
    visibleByDefault: true,
    items: [
      'Open the View Contract button.',
      'Review all legal and pricing terms.',
      'Complete the e-signature fields and submit.'
    ]
  },
  {
    key: 'activationPlan',
    label: 'Activation plan',
    kind: 'list',
    visibleByDefault: false,
    items: [
      'Contract validation and payment setup.',
      'Provisioning and kickoff scheduling.',
      'Hardware and installation coordination.'
    ]
  },
  {
    key: 'supportWindow',
    label: 'Support window',
    kind: 'text',
    visibleByDefault: true,
    text:
`Support window:
- Direct contact: {{repName}} | {{repEmail}} | {{repPhone}}
- If legal review is needed, reply to this email and we will support your team`
  }
];
const CONTRACT_SEND_LOADER_DELAY_MS = 1100;
let contractConfirmProceedAction = null;
let contractResendMode = false;
let contractResendReturnState = 'waiting';
let contractSendLoaderTimer = null;
let contractSubState = 'waiting';
let hasSeenContractPreviewGate = false;
let pendingFailingPromotion = null;
let promoValidationSim = 'pass';
let selectedOpt = null;
let signatureModalCountdownTimer = null;
let signatureModalDelayTimer = null;
let svtPendingTransitionTimer = null;

function clearSignatureCompletionSimulation() {
  if (signatureModalDelayTimer) {
    clearTimeout(signatureModalDelayTimer);
    signatureModalDelayTimer = null;
  }
  if (signatureModalCountdownTimer) {
    clearInterval(signatureModalCountdownTimer);
    signatureModalCountdownTimer = null;
  }
}

function continueFromSignatureCompleted() {
  if (contractSubState !== 'waiting') {
    clearSignatureCompletionSimulation();
    return;
  }
  clearSignatureCompletionSimulation();
  contractSubState = 'signed';
  logProposalEvent('Contract signed', 'Customer signature was completed.');
  touchNavDate('contract', true);
  touchNavDate('contract_sign_pay', true);
  updateContractSubState();
  renderNav();
}

function optionHasPromotionsOrDiscounts(opt) {
  if (!opt) return false;
  const check = o => !!o && (
    (Number(o.msaDiscountPct) || 0) > 0 ||
    !!o.discountProgramKey ||
    (Array.isArray(o.customPromotions) && o.customPromotions.some(p => customPromoHasAnyValue(p))) ||
    (o.bundles || []).some(b => (Number(b.msaDiscountPct) || 0) > 0 || !!b.promoName || !!b.dealCloser || (b.promoType && b.promoType !== 'Standard'))
  );
  const companion = options.find(o => o.msaPreviewFor === opt.id);
  return check(opt) || check(companion);
}

function customPromoHasAnyValue(p) {
  if ((p.value || 0) > 0) return true;
  return (p.targets || []).some(t => (t.value || 0) > 0);
}

function openMarkDeadModal() {
  _qlClosePendingRow = null; // opened from within drafting/selection
  document.getElementById('mark-dead-overlay').classList.add('is-open');
  updateMarkDeadConfirmBtn();
}

function updateMarkDeadConfirmBtn() {
  const select = document.getElementById('dead-reason-select');
  const btn = document.getElementById('btn-confirm-rejection');
  if (!select || !btn) return;
  btn.disabled = !select.value;
}

function setKebabMenuOpen(menu, open) {
  if (!menu) return;
  menu.classList.toggle('hidden', !open);
  menu.closest('.kebab-menu')?.querySelector('.btn-icon')?.setAttribute('aria-expanded', String(open));
}

function createContract(optId) {
  const opt = options.find((o) => o.id === optId);
  if (!opt) return;
  const optionNumber = options.findIndex((o) => o.id === optId) + 1;
  proposalData.lockedTerm = opt.term; // F1: freeze term at selection
  const result = calcOption(opt, getOptionPromotion(opt));
  proposalData.msaMinimumSpendCommitment = result.totalMonthly;
  logProposalEvent('Contract created', `Created from ${getOptionDisplayLabel(Math.max(1, optionNumber), true)} — ${opt.term}-month term locked.`);

  screen = 'contract-review';

  hideProposalReviewModal();
  document.getElementById('screen-proposal-selection')?.classList.add('hidden');
  document.getElementById('screen-drafting')?.classList.add('hidden');
  document.getElementById('options-grid')?.classList.add('hidden');

  document.getElementById('screen-contract')?.classList.remove('hidden');

  document.querySelector('.vc-main-stepper')?.classList.remove('hidden');
  if (document.getElementById('step-dot-1')) {
    document.getElementById('step-dot-1').className = 'vc-step-dot done';
    document.getElementById('step-dot-1').innerHTML = '<span class="material-symbols-outlined" style="font-size:14px;">check</span>';
  }
  document.getElementById('step-label-1')?.classList.remove('muted');
  if (document.getElementById('step-dot-2')) document.getElementById('step-dot-2').className = 'vc-step-dot active';
  document.getElementById('step-label-2')?.classList.remove('muted');

  const l3 = document.getElementById('substep-label-3');
  if (l3) {
    l3.textContent = 'Create Contract';
    l3.classList.remove('muted');
  }

  document.getElementById('vc-body').style.paddingTop = '159px';

  document.getElementById('footer-send').innerText = 'Send E-Sign Link';
  document.getElementById('footer-send').disabled = false;

  const banner = document.getElementById('success-banner');
  if (banner) {
    banner.style.top = '159px';
    const createdBanner = typeof getContractCreatedBanner === 'function'
      ? getContractCreatedBanner()
      : ['Contract has been created', 'Your Master Service Agreement was successfully generated. Review the terms and send the e-sign link.'];
    showSuccessBanner(createdBanner[0], createdBanner[1]);
  }

  touchNavDate('proposal');
  touchNavDate('proposal_selection');
  enterContractScreen(opt);
  renderNav();
}

function showQuoteCreationLoader(validationAlreadyPassed = false) {
  const overlay = document.getElementById('quote-loader-overlay');
  if (!overlay) {
    createContract(bld.selectedOptionId);
    return;
  }

  function getLoaderLabelBaseText(labelEl) {
    if (!labelEl) return '';
    if (!labelEl.dataset.baseLabel) {
      labelEl.dataset.baseLabel = (labelEl.textContent || '').trim();
    }
    return labelEl.dataset.baseLabel;
  }

  function setLoaderProgressLabelState(labelEl, state) {
    if (!labelEl) return;
    const baseText = getLoaderLabelBaseText(labelEl);
    labelEl.className = `vc-stage-loader__label${state ? ` is-${state}` : ''}`;

    if (state === 'done') {
      labelEl.innerHTML = `<span class="material-symbols-outlined" aria-hidden="true">check</span> ${baseText}`;
      return;
    }

    labelEl.textContent = baseText;
  }

  // 2026-10-05 (per Leo, 2026-10-02 call): a "Validation" step runs first —
  // "Validating promotions & programs" — before Opportunity / Quote / Contract.
  // Follow-up (per Catalina): only when the selected option actually has a
  // promotion or discount applied; otherwise the loader keeps its original 3
  // steps. Each step takes ~2.5 s.
  const fill = document.getElementById('ql-fill');
  const lbl0 = document.getElementById('ql-label-0');
  const lbl1 = document.getElementById('ql-label-1');
  const lbl2 = document.getElementById('ql-label-2');
  const lbl3 = document.getElementById('ql-label-3');
  const allLoaderSteps = [
    { label: lbl0, validation: true, headline: 'Validating promotions & programs', body: 'Checking that the selected promotions and discount<br>programs are still valid for this proposal.' },
    { label: lbl1, headline: 'Creating Opportunity', body: 'Setting up the opportunity record in Salesforce.<br>This may take a moment.' },
    { label: lbl2, headline: 'Creating Quote', body: 'Generating your configured quote and<br>linking it to the opportunity record.' },
    { label: lbl3, headline: 'Creating Contract', body: 'Preparing the contract package and<br>routing it to the contract workspace.' },
  ];
  const needsValidation = validationAlreadyPassed || optionHasPromotionsOrDiscounts(options.find(o => o.id === bld.selectedOptionId));
  const loaderSteps = allLoaderSteps.filter(step => needsValidation || !step.validation);
  const stepCount = loaderSteps.length;
  const stepPct = 100 / stepCount;
  const stepMs = 2500;
  // 2026-10-05 (per Catalina): after "Remove and continue", the loader comes
  // back with Validation already checked and resumes at Opportunity.
  const firstIndex = validationAlreadyPassed ? 1 : 0;
  if (fill) { fill.style.transition = 'none'; fill.style.width = `${firstIndex * stepPct}%`; }
  loaderSteps.forEach((step, index) => setLoaderProgressLabelState(step.label, index < firstIndex ? 'done' : (index === firstIndex ? 'active' : '')));
  if (lbl0) lbl0.classList.toggle('hidden', !needsValidation);
  document.getElementById('ql-headline').textContent = loaderSteps[firstIndex].headline;
  document.getElementById('ql-body').innerHTML = loaderSteps[firstIndex].body;

  overlay.classList.add('is-open');

  const runStep = (index) => {
    const step = loaderSteps[index];
    setLoaderProgressLabelState(step.label, 'active');
    if (step.validation && lbl0) lbl0.classList.remove('hidden');
    document.getElementById('ql-headline').textContent = step.headline;
    document.getElementById('ql-body').innerHTML = step.body;
    requestAnimationFrame(() => requestAnimationFrame(() => {
      if (fill) { fill.style.transition = `width ${stepMs / 1000}s ease`; fill.style.width = `${(index + 1) * stepPct}%`; }
    }));
    setTimeout(() => {
      if (step.validation) {
        const failing = promoValidationSim === 'fail' ? findFailingPromotion(options.find(o => o.id === bld.selectedOptionId)) : null;
        if (failing) {
          overlay.classList.remove('open', 'is-open');
          openPromoValidationFailModal(failing);
          return;
        }
      }
      setLoaderProgressLabelState(step.label, 'done');
      if (index + 1 < loaderSteps.length) { runStep(index + 1); return; }
      setTimeout(() => {
        overlay.classList.remove('open', 'is-open');
        createContract(bld.selectedOptionId);
      }, 500);
    }, stepMs);
  };
  runStep(firstIndex);
}

  function getLoaderLabelBaseText(labelEl) {
    if (!labelEl) return '';
    if (!labelEl.dataset.baseLabel) {
      labelEl.dataset.baseLabel = (labelEl.textContent || '').trim();
    }
    return labelEl.dataset.baseLabel;
  }

  function setLoaderProgressLabelState(labelEl, state) {
    if (!labelEl) return;
    const baseText = getLoaderLabelBaseText(labelEl);
    labelEl.className = `vc-stage-loader__label${state ? ` is-${state}` : ''}`;

    if (state === 'done') {
      labelEl.innerHTML = `<span class="material-symbols-outlined" aria-hidden="true">check</span> ${baseText}`;
      return;
    }

    labelEl.textContent = baseText;
  }

function findFailingPromotion(opt) {
  if (!opt) return null;
  const companion = options.find(o => o.msaPreviewFor === opt.id);
  const holders = [opt, companion].filter(Boolean);
  for (const holder of holders) {
    const program = DISCOUNT_PROGRAMS.find(p => p.key === holder.discountProgramKey);
    if (program) return { kind: 'program', holderId: holder.id, key: program.key, label: `${program.name} (${program.pct}%)`, type: 'Account Discount program', reason: 'The account\'s Lead Source changed, so it no longer qualifies for this program.' };
  }
  for (const holder of holders) {
    const bundle = (holder.bundles || []).find(b => b.promoName);
    if (bundle) return { kind: 'promo', holderId: holder.id, key: bundle.promoName, label: bundle.promoName, type: 'Order promotion', reason: 'This promotion has ended or the account no longer meets its eligibility rules.' };
  }
  for (const holder of holders) {
    const bundle = (holder.bundles || []).find(b => b.dealCloser);
    if (bundle) return { kind: 'deal-closer', holderId: holder.id, key: bundle.dealCloser, label: bundle.dealCloser, type: 'Deal closer', reason: 'This deal closer has ended or the account no longer meets its eligibility rules.' };
  }
  return null;
}

function openPromoValidationFailModal(failing) {
  pendingFailingPromotion = failing;
  const opt = options.find(o => o.id === bld.selectedOptionId);
  const optionNumber = Math.max(1, options.findIndex(o => o.id === (opt && opt.id)) + 1);
  const body = document.getElementById('promo-validation-fail-body');
  if (body) {
    body.innerHTML = `<strong>${failing.label}</strong> (${failing.type}) no longer applies to ${getOptionDisplayLabel(optionNumber, true)}. ${failing.reason}<br><br>It has been removed from the option and the price was updated. Continue creating the contract, or go back to the options to review them first.`;
  }
  // Follow-up (per Catalina): removal isn't the rep's choice — it happens as
  // soon as the failure is found; the dialog only informs. Both buttons just
  // decide where to go next.
  removeFailingPromotion(false);
  document.getElementById('promo-validation-fail-overlay')?.classList.add('is-open');
}

function closePromoValidationFailModal() {
  document.getElementById('promo-validation-fail-overlay')?.classList.remove('is-open');
}

function removeFailingPromotion() {
  const failing = pendingFailingPromotion;
  pendingFailingPromotion = null;
  const holder = failing ? options.find(o => o.id === failing.holderId) : null;
  if (holder) {
    if (failing.kind === 'program') {
      holder.discountProgramKey = null;
      holder.msaDiscountPct = 0;
      holder.bundles.forEach(b => { b.msaDiscountPct = 0; });
    } else if (failing.kind === 'promo') {
      holder.bundles.forEach(b => { if (b.promoName === failing.key) { b.promoName = ''; b.promoType = 'Standard'; } });
    } else if (failing.kind === 'deal-closer') {
      holder.bundles.forEach(b => { if (b.dealCloser === failing.key) b.dealCloser = ''; });
    }
    if (typeof logProposalEvent === 'function') logProposalEvent('Promotion removed', `${failing.label} no longer applied and was removed at contract creation.`);
    renderOptions();
    if (screen === 'selection' && typeof renderSelectionOptions === 'function') renderSelectionOptions();
  }
}

function removePromoAndContinue() {
  closePromoValidationFailModal();
  setTimeout(() => showQuoteCreationLoader(true), 160);
}

function showToast(msg) { if (typeof showSuccessBanner === 'function') showSuccessBanner(msg, ''); }

function setContractSendButtonLabel(label) {
  const contractSendBtn = document.getElementById('contract-send-btn');
  if (!contractSendBtn) return;
  contractSendBtn.innerHTML = `<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" style="margin-right:4px;flex-shrink:0;"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg><span>${label}</span>`;
}

function clearSvtPendingTransition() {
  if (svtPendingTransitionTimer) {
    clearTimeout(svtPendingTransitionTimer);
    svtPendingTransitionTimer = null;
  }
}

function addProposalNotification(notif) {
  // Graceful stub for notification system
}

function getCurrentProposalIdForNotifications() {
  return (proposalData && proposalData.proposalId) ? String(proposalData.proposalId).trim() : '0524';
}

function clearContractSendLoaderTimer() {
  if (!contractSendLoaderTimer) return;
  clearTimeout(contractSendLoaderTimer);
  contractSendLoaderTimer = null;
}

function setContractSendLoaderVisible(isVisible) {
  const loader = document.getElementById('contract-send-loader');
  const waitingMessage = document.getElementById('sp-waiting-message');
  const checklistWrap = document.getElementById('sp-checklist-wrap');
  if (loader) loader.classList.toggle('hidden', !isVisible);
  if (waitingMessage) waitingMessage.classList.toggle('hidden', isVisible);
  if (checklistWrap) checklistWrap.classList.toggle('hidden', isVisible);
}

function finalizeContractSendTransition(isResend, returnState) {
  contractSubState = isResend ? returnState : 'waiting';
  logProposalEvent(isResend ? 'Contract re-sent' : 'Contract sent', isResend
    ? 'Contract was re-sent after editing the Sign & Payment message.'
    : `Contract was sent to the Purchase Portal (${getContractPortalRecipientEmail()}) for signature and payment setup.`);
  touchNavDate('contract_review_send', true);
  updateContractSubState();
  renderContractPortalSentRow(true);
  // 2026-10-05 (per Catalina): green success toast (same auto-dismissing
  // pattern used elsewhere) confirming the send and its recipient.
  showSuccessBanner('Contract sent', `The contract was sent through the Purchase Portal to ${getContractPortalRecipientEmail()}.`);
  document.getElementById('contract-send-btn')?.classList.add('hidden');
  document.getElementById('footer-back')?.classList.remove('hidden');
  document.getElementById('footer-back')?.classList.add('visible');
  contractResendMode = false;
  contractResendReturnState = 'waiting';
  renderNav();
}

function enterContractScreen(opt) {
  clearContractSendLoaderTimer();
  setContractSendLoaderVisible(false);
  clearSignatureCompletionSimulation();
  selectedOpt = opt;
  hasSeenContractPreviewGate = false;
  contractResendMode = false;
  contractResendReturnState = 'waiting';
  syncExpirationInputs(getSelectedExpirationDate());
  contractSubState = 'pre-send'; // before sending e-sign
  touchNavDate('contract_created');
  syncContractPortalRecipient();
  renderContractPortalSentRow(false);
  // Show phase 0 (preview gate), hide phase 1 and 2
  document.getElementById('contract-phase-contractpreview').classList.remove('hidden');
  document.getElementById('contract-phase-review').classList.add('hidden');
  document.getElementById('contract-phase-signpay').classList.add('hidden');
  // Stepper: step 1 active
  const d1 = document.getElementById('c-dot-1');
  const d2 = document.getElementById('c-dot-2');
  const l1 = document.getElementById('c-line-1');
  if (d1) d1.className = 'c-step-dot active';
  if (document.getElementById('c-dot-label-2')) document.getElementById('c-dot-label-2').className = 'c-step-label muted';
  if (d2) d2.className = 'c-step-dot pending';
  if (l1) l1.className = 'c-line';
  // Footer
  const contractSendBtn = document.getElementById('contract-send-btn');
  if (contractSendBtn) {
    contractSendBtn.classList.remove('hidden');
    setContractSendButtonLabel('Send Contract');
    contractSendBtn.disabled = false;
  }
  document.getElementById('footer-back').classList.remove('visible');
  document.getElementById('footer-back').classList.add('hidden');
  renderContractDoc(opt);
}

function getContractPortalRecipientEmail() {
  const to = (document.getElementById('prop-msg-to')?.value || '').trim();
  return to || 'acme.logistics@acmecorp.com';
}

function syncContractPortalRecipient() {
  const email = getContractPortalRecipientEmail();
  const el = document.getElementById('contract-portal-recipient-email');
  if (el) { el.textContent = email; el.title = email; }
}

function renderContractPortalSentRow(isSent) {
  const row = document.getElementById('sp-row-portal');
  if (!row) return;
  row.classList.toggle('hidden', !isSent);
  if (!isSent) return;
  const sub = document.getElementById('sp-portal-sub');
  const date = document.getElementById('sp-portal-date');
  if (sub) sub.textContent = `Contract sent to ${getContractPortalRecipientEmail()}`;
  if (date) date.textContent = (window._navDates && window._navDates.contract_review_send) || new Date().toLocaleDateString();
}

function sendContractToCustomerPortal() {
  if (!selectedOpt) return;
  hasSeenContractPreviewGate = true;
  document.getElementById('contract-phase-contractpreview')?.classList.add('hidden');
  sendContractNow();
}

function setSignPayStatusMessage(state) {
  const wrap = document.getElementById('sp-waiting-message');
  const icon = document.getElementById('sp-waiting-message-icon');
  const title = document.getElementById('sp-waiting-message-title');
  const copy = document.getElementById('sp-waiting-message-copy');
  if (!wrap || !icon || !title || !copy) return;

  const map = {
    waiting: {
      icon: 'mark_email_read',
      title: 'Contract sent successfully',
      copy: 'The contract is now with the customer. We are waiting for signature and payment setup to complete before moving to Deal Result.',
    },
    signed: {
      icon: 'how_to_reg',
      title: 'Signature completed',
      copy: 'The customer completed signature. We are waiting for payment setup confirmation.',
    },
    payment: {
      icon: 'task_alt',
      title: 'Customer actions completed',
      copy: 'Signature and payment setup are complete. Redirecting to Deal Result...',
    },
  };

  const cfg = map[state] || map.waiting;
  wrap.classList.remove('hidden', 'is-waiting', 'is-signed', 'is-payment');
  wrap.classList.add(`is-${state in map ? state : 'waiting'}`);
  icon.textContent = cfg.icon;
  title.textContent = cfg.title;
  copy.textContent = cfg.copy;
}

function updateContractSubState() {
  updateContractSimulationMenuVisibility();
  const waitingMessage = document.getElementById('sp-waiting-message');
  const checklistWrap = document.getElementById('sp-checklist-wrap');
  const dot2 = document.getElementById('c-dot-2');
  const line2 = document.getElementById('c-line-2');
  const dot3 = document.getElementById('c-dot-3');
  const date2 = document.getElementById('contract-date-2');
  const signatureIcon = document.getElementById('sp-signature-state-icon');
  const paymentIcon = document.getElementById('sp-payment-state-icon');
  const signatureSub = document.getElementById('sp-signature-sub');
  const paymentSub = document.getElementById('sp-payment-sub');
  const signatureDate = document.getElementById('sp-signature-date');
  const paymentDate = document.getElementById('sp-payment-date');
  const dates = window._navDates || {};

  function setChecklistState(signatureState, paymentState) {
    const setState = (icon, state) => {
      if (!icon) return;
      icon.className = `vc-checklist__state vc-checklist__state--${state}`;
      icon.innerHTML = state === 'done'
        ? '<span class="material-symbols-outlined" aria-hidden="true">check</span>'
        : state === 'progress'
          ? '<div class="loader"><svg class="loader__spinner" viewBox="0 0 64 64" fill="none" aria-hidden="true"><circle class="loader__track" cx="32" cy="32" r="28" stroke-width="6" stroke-linecap="round"/><path class="loader__arc" d="M32 4 A28 28 0 0 1 60 32" stroke-width="6" stroke-linecap="round" fill="none"/></svg></div>'
          : '';
    };
    setState(signatureIcon, signatureState);
    setState(paymentIcon, paymentState);
  }

  if (contractSubState === 'waiting') {
    clearSvtPendingTransition();
    setSignPayStatusMessage('waiting');
    if (checklistWrap) checklistWrap.classList.remove('hidden');
    if (signatureSub) signatureSub.textContent = 'Waiting for customer signature in DocuSign. Contact the customer to confirm receipt and assist with the digital signature.';
    if (paymentSub) paymentSub.textContent = 'Starts after contract signature is completed.';
    if (signatureDate) signatureDate.textContent = ''; // sent date now lives in the "Sent to Customer Portal" row
    if (paymentDate) paymentDate.textContent = `Sent ${dates.contract_review_send || '--'}`;
    setChecklistState('progress', 'pending');

  } else if (contractSubState === 'signed') {
    clearSvtPendingTransition();
    clearSignatureCompletionSimulation();
    setSignPayStatusMessage('signed');
    if (checklistWrap) checklistWrap.classList.remove('hidden');
    showSuccessBanner('Contract signed', 'The customer has successfully signed. They will now be redirected to the payment setup portal.');
    if (date2) date2.textContent = new Date().toLocaleDateString();
    if (signatureSub) signatureSub.textContent = 'Signature completed.';
    if (paymentSub) paymentSub.textContent = 'Waiting for payment setup confirmation.';
    if (signatureDate) signatureDate.textContent = `Signed ${dates.contract_sign_pay || '--'}`;
    if (paymentDate) paymentDate.textContent = `Sent ${dates.contract_review_send || '--'}`;
    setChecklistState('done', 'progress');

  } else if (contractSubState === 'payment') {
    clearSignatureCompletionSimulation();
    clearSvtPendingTransition();
    setSignPayStatusMessage('payment');
    if (checklistWrap) checklistWrap.classList.remove('hidden');
    touchNavDate('contract');
    touchNavDate('contract_sign_pay');
    touchNavDate('contract_payment_setup', true);
    touchNavDate('payment');
    showSuccessBanner('Payment method configured.', '');
    logProposalEvent('Payment setup configured', 'Payment setup was completed.');
    addProposalNotification({
      title: 'Payment setup configured',
      message: 'Customer payment setup has been completed.',
      target: 'deal-result-svt-pending',
      dedupeKey: `payment-setup-${getCurrentProposalIdForNotifications()}`
    });
    if (dot2) dot2.className = 'c-step-dot done';
    if (line2) line2.className = 'c-line done';
    if (dot3) dot3.className = 'c-step-dot active';
    if (date2) date2.textContent = new Date().toLocaleDateString();
    if (signatureSub) signatureSub.textContent = 'Signature completed.';
    if (paymentSub) paymentSub.textContent = 'Payment setup completed.';
    if (signatureDate) signatureDate.textContent = `Signed ${dates.contract_sign_pay || '--'}`;
    if (paymentDate) paymentDate.textContent = `Configured ${dates.contract_payment_setup || '--'}`;
    setChecklistState('done', 'done');

    svtPendingTransitionTimer = setTimeout(() => {
      svtPendingTransitionTimer = null;
      if (contractSubState !== 'payment') return;
      enterDealResult('svt-pending');
    }, 2200);
  }

  updateFulfillmentBtn();
}

  function setChecklistState(signatureState, paymentState) {
    const setState = (icon, state) => {
      if (!icon) return;
      icon.className = `vc-checklist__state vc-checklist__state--${state}`;
      icon.innerHTML = state === 'done'
        ? '<span class="material-symbols-outlined" aria-hidden="true">check</span>'
        : state === 'progress'
          ? '<div class="loader"><svg class="loader__spinner" viewBox="0 0 64 64" fill="none" aria-hidden="true"><circle class="loader__track" cx="32" cy="32" r="28" stroke-width="6" stroke-linecap="round"/><path class="loader__arc" d="M32 4 A28 28 0 0 1 60 32" stroke-width="6" stroke-linecap="round" fill="none"/></svg></div>'
          : '';
    };
    setState(signatureIcon, signatureState);
    setState(paymentIcon, paymentState);
  }

function formatContractDocMoney(value) {
  const num = Number(value);
  return Number.isFinite(num) ? formatMoney(num) : '--';
}

function generateContractEnvelopeId(seed) {
  const input = String(seed || 'VC-CONTRACT-DEMO');
  let state = 2166136261;
  for (let i = 0; i < input.length; i += 1) {
    state ^= input.charCodeAt(i);
    state = Math.imul(state, 16777619) >>> 0;
  }
  const hex = [];
  for (let i = 0; i < 32; i += 1) {
    state = (Math.imul(state, 1664525) + 1013904223) >>> 0;
    hex.push((state >>> 28).toString(16).toUpperCase());
  }
  const raw = hex.join('');
  return `${raw.slice(0, 8)}-${raw.slice(8, 12)}-${raw.slice(12, 16)}-${raw.slice(16, 20)}-${raw.slice(20, 32)}`;
}

function buildContractAdditionalTermsHtml() {
  const segment = proposalData.segment || 'SMB';
  if (segment === 'SMB') return '';

  const rows = [];
  if (proposalData.poNumber) rows.push(['Purchase Order #', proposalData.poNumber]);
  if (segment === 'Enterprise' && proposalData.costCenter) rows.push(['Cost center / GL', proposalData.costCenter]);
  if (segment === 'Government') {
    if (proposalData.contractVehicle) rows.push(['Contract vehicle', proposalData.contractVehicle]);
    if (proposalData.contractingOfficerName) rows.push(['Contracting Officer', proposalData.contractingOfficerName]);
    if (proposalData.contractingOfficerEmail) rows.push(['CO email', proposalData.contractingOfficerEmail]);
    if (proposalData.contractingOfficerPhone) rows.push(['CO phone', proposalData.contractingOfficerPhone]);
  }
  if (!rows.length) return '';

  const rowsHtml = rows.map(([key, value]) => `
    <tr>
      <td style="padding:8px 10px; border:1px solid #D1D5DB; width:38%; font-size:12px; font-weight:700; color:#111827;">${escapeContractDocHtml(key)}</td>
      <td style="padding:8px 10px; border:1px solid #D1D5DB; font-size:12px; color:#111827;">${escapeContractDocHtml(value)}</td>
    </tr>
  `).join('');

  return `
    <div style="margin-top:18px;">
      <div style="font-size:14px; font-weight:700; margin-bottom:8px; color:#111827;">4. Additional Terms</div>
      <table style="width:100%; border-collapse:collapse;">
        <tbody>${rowsHtml}</tbody>
      </table>
    </div>
  `;
}

function buildContractDocumentHtml(opt, context) {
  const customerName = escapeContractDocHtml(
    proposalData.accountName || proposalData.customerName || proposalData.account || 'Apex Construction LLC'
  );
  const customerAddress = escapeContractDocHtml(
    proposalData.accountAddress || proposalData.billingAddress || '123 Industrial Pkwy, Tampa FL 33602'
  );
  const envelopeId = generateContractEnvelopeId(opt?.id || `${customerName}-${context.dateStr}`);
  const agreementTitle = proposalData.isAddOn ? 'Service Order' : 'Purchase Agreement';
  const promoLine = context.optionPromoType && context.optionPromoType !== 'None'
    ? `<p style="margin:8px 0 0; font-size:12px; color:#111827;">A ${escapeContractDocHtml(context.optionPromoType)} promotion has been applied to this Agreement.</p>`
    : '';
  const totalMonthlyText = formatContractDocMoney(context.totalMonthly);
  const exhibitHtml = buildWaveInstallScheduleHtml(opt)
    ? `
      <div style="margin-top:24px; border-top:1px solid #D1D5DB; padding-top:14px;">
        <div style="font-size:14px; font-weight:700; margin-bottom:8px; color:#111827;">Exhibit A - Installation Schedule</div>
        ${buildWaveInstallScheduleHtml(opt)}
      </div>
    `
    : '';
  const shouldRenderSignedContract =
    screen === 'deal-result' ||
    contractSubState === 'signed' ||
    contractSubState === 'payment';
  const signedDate = context.dateStr;
  const customerSignerName = escapeContractDocHtml(
    proposalData.contactName || proposalData.customerContactName || 'Laura Mendez'
  );
  const verizonSignerName = escapeContractDocHtml(proposalData.repName || 'Jordan Rivera');

  const customerSignatureFieldHtml = shouldRenderSignedContract
    ? `<div style="display:inline-flex; align-items:center; gap:6px; padding:4px 8px; border:1px solid #0E9F6E; background:#ECFDF3; font-size:11px; font-weight:700; border-radius:3px; margin-right:6px; color:#065F46;"><span class="material-symbols-outlined" style="font-size:13px;">check_circle</span>Signed · ${customerSignerName}</div>
       <div style="display:inline-flex; align-items:center; padding:4px 8px; border:1px solid #0E9F6E; background:#ECFDF3; font-size:10px; font-weight:700; border-radius:3px; color:#065F46;">${signedDate}</div>`
    : `<span style="font-size:11px; color:#9CA3AF;">Awaiting signature</span>`;

  const verizonSignatureFieldHtml = shouldRenderSignedContract
    ? `<div style="display:inline-flex; align-items:center; gap:6px; padding:4px 8px; border:1px solid #0E9F6E; background:#ECFDF3; font-size:11px; font-weight:700; border-radius:3px; margin-right:6px; color:#065F46;"><span class="material-symbols-outlined" style="font-size:13px;">check_circle</span>Signed · ${verizonSignerName}</div>
       <div style="display:inline-flex; align-items:center; padding:4px 8px; border:1px solid #0E9F6E; background:#ECFDF3; font-size:10px; font-weight:700; border-radius:3px; color:#065F46;">${signedDate}</div>`
    : `<span style="font-size:11px; color:#9CA3AF;">Awaiting signature</span>`;

  return `
    <div class="doc-page-outer">
      <div class="vc-doc-shell">
        <div class="vc-doc-brand-line"></div>
        <div class="vc-doc-inner" style="background:#fff; color:#111827; font-family:'VerizonNHGDS',sans-serif;">
          <div style="font-family:monospace; font-size:10px; color:#6B7280; margin-bottom:16px;">Envelope ID: ${envelopeId}</div>

          <div style="text-align:center; margin-bottom:18px;">
            <div style="font-size:22px; letter-spacing:0.08em; font-weight:700;">${agreementTitle}</div>
          </div>

          <div style="display:grid; grid-template-columns:1fr 1fr; gap:18px; margin-bottom:18px;">
            <div>
              <div style="font-size:11px; font-weight:700; color:#4B5563; margin-bottom:4px;">Between:</div>
              <div style="font-size:13px; font-weight:700;">Verizon Connect</div>
              <div style="font-size:12px; color:#374151; line-height:1.45;">7701 Forsyth Blvd<br>St. Louis, MO 63105</div>
            </div>
            <div>
              <div style="font-size:11px; font-weight:700; color:#4B5563; margin-bottom:4px;">And:</div>
              <div style="font-size:13px; font-weight:700;">${customerName}</div>
              <div style="font-size:12px; color:#374151; line-height:1.45;">${customerAddress}</div>
              <div style="margin-top:8px; font-size:12px; color:#374151;"><strong>Effective Date:</strong> ${context.dateStr}</div>
            </div>
          </div>

          ${buildContractMsaBoxHtml()}
          <div style="margin-bottom:14px;">
            <div style="font-size:14px; font-weight:700; margin-bottom:8px; color:#111827;">1. Term</div>
            <p style="margin:0; font-size:12px; line-height:1.6; color:#111827;">This Agreement shall commence on the Effective Date and continue for a period of ${Number(opt?.term) || 36} months, unless terminated earlier in accordance with these terms.</p>
          </div>

          <div style="margin-bottom:14px;">
            <div style="font-size:14px; font-weight:700; margin-bottom:8px; color:#111827;">2. Equipment and Services</div>
            <table style="width:100%; border-collapse:collapse; font-size:12px;">
              <thead>
                <tr>
                  <th style="text-align:left; padding:8px 10px; border:1px solid #D1D5DB; font-weight:700;">Description</th>
                  <th style="text-align:left; padding:8px 10px; border:1px solid #D1D5DB; font-weight:700;">QTY</th>
                  <th style="text-align:left; padding:8px 10px; border:1px solid #D1D5DB; font-weight:700;">Unit / mo</th>
                  <th style="text-align:left; padding:8px 10px; border:1px solid #D1D5DB; font-weight:700;">Total / mo</th>
                </tr>
              </thead>
              <tbody>${context.rowsHtml}</tbody>
            </table>
          </div>

          <div style="margin-bottom:14px;">
            <div style="font-size:14px; font-weight:700; margin-bottom:8px; color:#111827;">3. Pricing and Payment</div>
            <p style="margin:0; font-size:12px; line-height:1.6; color:#111827;">Customer agrees to pay a recurring monthly amount of ${totalMonthlyText}. Billing cycle is monthly and subject to applicable taxes and fees.</p>
            ${promoLine}
          </div>

          ${buildContractAdditionalTermsHtml()}

          <div style="margin-top:18px;">
            <div style="font-size:14px; font-weight:700; margin-bottom:8px; color:#111827;">5. General Terms</div>
            <p style="margin:0; font-size:12px; line-height:1.6; color:#111827;">This agreement is subject to Verizon Connect Terms of Service. Pricing is valid until ${context.expirationStr}. Any changes to scope or pricing must be documented in writing by both parties.</p>
          </div>

          <div style="margin-top:26px; border-top:1px solid #D1D5DB; padding-top:16px;">
            <div style="font-size:14px; font-weight:700; margin-bottom:10px; color:#111827;">Signatures</div>
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:24px;">
              <div>
                <div style="height:1px; background:#111827; margin-bottom:8px;"></div>
                <div style="font-size:11px; color:#4B5563; margin-bottom:8px;">Customer signature &amp; date</div>
                ${customerSignatureFieldHtml}
              </div>
              <div>
                <div style="height:1px; background:#111827; margin-bottom:8px;"></div>
                <div style="font-size:11px; color:#4B5563; margin-bottom:8px;">Verizon Connect representative &amp; date</div>
                ${verizonSignatureFieldHtml}
              </div>
            </div>
          </div>

          ${exhibitHtml}
        </div>
      </div>
    </div>
  `;
}

function refreshContractPreview(triggerBtn) {
  const buttons = Array.from(document.querySelectorAll('[onclick="refreshContractPreview(this)"]'));
  buttons.forEach((btn) => btn.classList.add('is-spinning'));

  const activeOpt = window.selectedOpt || (Array.isArray(window.options) && window.options.length ? window.options[0] : null);
  if (activeOpt && typeof renderContractDoc === 'function') {
    window.selectedOpt = activeOpt;
    renderContractDoc(activeOpt);
  }

  window.setTimeout(() => {
    buttons.forEach((btn) => btn.classList.remove('is-spinning'));
  }, 680);

  if (typeof showToast === 'function') showToast('Contract synced from DocuSign');
}

function renderContractDocCore(opt) {
  if (!opt) return;

  const optTierDoc = (opt.forcedTierIndex !== undefined) ? opt.forcedTierIndex : -1;
  const optionPromoType = getOptionPromotion(opt);
  const { totalMonthly, totalUnits } = calcOption(opt, optionPromoType, optTierDoc);
  const dateStr = formatUsDate(new Date());
  const expirationDate = getSelectedExpirationDate();
  const expirationStr = formatExpirationDisplayDate(expirationDate);

  const bundles = Array.isArray(opt.bundles) ? opt.bundles : [];
  const rowsHtml = bundles.map((bundle) => {
    const bundlePromo = bundle.promoType || optionPromoType;
    const pricing = calcBundle(bundle, opt.term, bundlePromo, optTierDoc, totalUnits);
    const unitPrice = formatContractDocMoney(pricing.unitPrice);
    const monthly = formatContractDocMoney(pricing.monthly);
    return `
      <tr>
        <td style="padding:8px 10px; border:1px solid #D1D5DB;">${escapeContractDocHtml(bundle.coreName || '--')}</td>
        <td style="padding:8px 10px; border:1px solid #D1D5DB;">${escapeContractDocHtml(bundle.qty ?? '--')}</td>
        <td style="padding:8px 10px; border:1px solid #D1D5DB;">${unitPrice}</td>
        <td style="padding:8px 10px; border:1px solid #D1D5DB; font-weight:700;">${monthly}</td>
      </tr>
    `;
  }).join('');

  const docHtml = buildContractDocumentHtml(opt, {
    optionPromoType,
    totalMonthly,
    totalUnits,
    dateStr,
    expirationStr,
    rowsHtml,
  });

  const viewer = document.getElementById('contract-doc-viewer');
  if (viewer) viewer.innerHTML = docHtml;
  const modalViewer = document.getElementById('contract-doc-viewer-modal');
  if (modalViewer) modalViewer.innerHTML = docHtml;

  requestAnimationFrame(scaleDocPages);
  fillContractMessageDefaults(opt, totalMonthly);
}

function resendContractLink() {
  if (screen !== 'contract-review') return;
  document.getElementById('more-menu-contract')?.classList.add('hidden');
  document.getElementById('more-menu-contract2')?.classList.add('hidden');
  document.getElementById('more-menu-contract-preview')?.classList.add('hidden');

  const isSignPayVisible = !document.getElementById('contract-phase-signpay')?.classList.contains('hidden');
  contractResendReturnState = ['signed', 'payment'].includes(contractSubState) ? contractSubState : 'waiting';
  contractResendMode = true;

  document.getElementById('contract-phase-signpay')?.classList.add('hidden');
  document.getElementById('contract-phase-review')?.classList.remove('hidden');

  const contractSendBtn = document.getElementById('contract-send-btn');
  if (contractSendBtn) {
    contractSendBtn.classList.remove('hidden');
    setContractSendButtonLabel('Resend Contract');
    contractSendBtn.disabled = false;
  }

  document.getElementById('footer-back')?.classList.remove('hidden');
  document.getElementById('footer-back')?.classList.add('visible');

  logProposalEvent('Contract resend edit started', 'Contract message was reopened from Sign & Payment for edits before re-sending.');
  if (isSignPayVisible) {
    showSuccessBanner('Edit and resend contract', 'Update the message if needed, then click Resend Contract.');
  }
  updateSendBtn();
}

function simulateContractSigned() {
  if (contractSubState !== 'waiting') return;
  clearSignatureCompletionSimulation();
  document.getElementById('more-menu-contract')?.classList.add('hidden');
  document.getElementById('more-menu-contract2')?.classList.add('hidden');
  document.getElementById('more-menu-contract-preview')?.classList.add('hidden');
  continueFromSignatureCompleted();
}

function simulatePaymentSetup() {
  if (contractSubState !== 'signed' && contractSubState !== 'waiting') return;
  clearSignatureCompletionSimulation();
  clearSvtPendingTransition();
  contractSubState = 'payment';
  document.getElementById('more-menu-contract')?.classList.add('hidden');
  document.getElementById('more-menu-contract2')?.classList.add('hidden');
  document.getElementById('more-menu-contract-preview')?.classList.add('hidden');
  updateContractSubState();
  renderNav();
}

function openContractModifyConfirmModal() {
  document.getElementById('more-menu-contract')?.classList.add('hidden');
  document.getElementById('more-menu-contract2')?.classList.add('hidden');
  document.getElementById('more-menu-contract-preview')?.classList.add('hidden');
  const t = document.getElementById('contract-modify-title');
  const b = document.getElementById('contract-modify-body');
  const p = document.getElementById('contract-modify-proceed-btn');
  if (t) t.textContent = 'Modify proposal?';
  if (b) b.textContent = 'If you modify the proposal, you will return to the Proposal section and the current contract progress will be discarded. Are you sure you want to proceed?';
  if (p) p.textContent = 'Proceed';
  contractConfirmProceedAction = 'modify-proposal';
  document.getElementById('contract-modify-overlay')?.classList.add('is-open');
}

function updateContractSimulationMenuVisibility() {
  const showMarkSigned = contractSubState === 'waiting';
  const showContractSigned = contractSubState === 'waiting';
  const showPaymentSetup = contractSubState === 'waiting' || contractSubState === 'signed';
  const hasAnyAction = showMarkSigned || showContractSigned || showPaymentSetup;

  ['contract', 'contract2', 'contract-preview'].forEach((suffix) => {
    document.getElementById(`sim-title-${suffix}`)?.classList.toggle('hidden', !hasAnyAction);
    document.getElementById(`sim-mark-signed-${suffix}`)?.classList.toggle('hidden', !showMarkSigned);
    document.getElementById(`sim-contract-signed-${suffix}`)?.classList.toggle('hidden', !showContractSigned);
    document.getElementById(`sim-payment-setup-${suffix}`)?.classList.toggle('hidden', !showPaymentSetup);
  });
}

function toggleContractPreviewMenu(event) {
  if (event) {
    event.preventDefault();
    event.stopPropagation();
  }
  updateContractSimulationMenuVisibility();
  const m1 = document.getElementById('more-menu-contract');
  const m2 = document.getElementById('more-menu-contract2');
  const m3 = document.getElementById('more-menu-contract-preview');
  if (!m3) return;
  setKebabMenuOpen(m1, false);
  setKebabMenuOpen(m2, false);
  const shouldOpen = m3.classList.contains('hidden');
  setKebabMenuOpen(m3, shouldOpen);
}

function toggleContractMenu2(event) {
  if (event) {
    event.preventDefault();
    event.stopPropagation();
  }
  updateContractSimulationMenuVisibility();
  const m1 = document.getElementById('more-menu-contract');
  const m2 = document.getElementById('more-menu-contract2');
  const m3 = document.getElementById('more-menu-contract-preview');
  if (!m2) return;
  setKebabMenuOpen(m1, false);
  setKebabMenuOpen(m3, false);
  const shouldOpen = m2.classList.contains('hidden');
  setKebabMenuOpen(m2, shouldOpen);
}

function toggleContractMenu(event) {
  if (event) {
    event.preventDefault();
    event.stopPropagation();
  }
  updateContractSimulationMenuVisibility();
  const m1 = document.getElementById('more-menu-contract');
  const m2 = document.getElementById('more-menu-contract2');
  const m3 = document.getElementById('more-menu-contract-preview');
  if (!m1) return;
  setKebabMenuOpen(m2, false);
  setKebabMenuOpen(m3, false);
  const shouldOpen = m1.classList.contains('hidden');
  setKebabMenuOpen(m1, shouldOpen);
}

function renderContractDoc(opt) {
  renderContractDocCore(opt);
}

function fillContractMessageDefaults(opt, totalMonthly) {
  const optionId = opt?.id;
  const optionNumber = Math.max(1, options.findIndex((o) => o.id === optionId) + 1);
  const term = Number(opt?.term) || 36;
  const monthly = typeof totalMonthly === 'number' ? totalMonthly : 0;

  const msgTo = document.getElementById('contract-msg-to');
  if (msgTo) {
    msgTo.value = proposalWasSentToCustomer ? 'acme.logistics@acmecorp.com' : 'laura.mendez@acmelogistics.com';
  }

  const msgSub = document.getElementById('contract-msg-subject');
  if (msgSub) {
    msgSub.value = `Contract package ready - ${getOptionDisplayLabel(optionNumber)}`;
  }

  const msgBody = document.getElementById('contract-msg-body');
  if (msgBody) {
    proposalData.contractMessageModulesModel = null;
    getContractMessageModulesModel(true);
    syncContractMessageFromModules();
  }

  renderContractMessageContentChecklist();
  renderContractMessageFormatControl();
  updateContractSendBtn();
}

function totalUnitsForOption(opt) {
  if (!opt || !Array.isArray(opt.bundles)) return 0;
  return opt.bundles.reduce((sum, b) => sum + (Number(b.qty) || 0), 0);
}

function openContractInDocuSign() {
  const overlay = document.getElementById('contract-preview-overlay');
  const source = document.getElementById('contract-doc-viewer');
  const target = document.getElementById('contract-doc-viewer-modal');
  if (!overlay || !source || !target) return;
  const activeOpt = selectedOpt || (Array.isArray(options) && options.length ? options[0] : null);
  if (activeOpt && typeof renderContractDocCore === 'function') {
    renderContractDocCore(activeOpt);
  }
  target.innerHTML = source.innerHTML;
  overlay.classList.add('open');
  document.body.style.overflow = 'hidden';
  requestAnimationFrame(scaleDocPages);
}

function closeContractPreviewModal() {
  const overlay = document.getElementById('contract-preview-overlay');
  if (!overlay) return;
  overlay.classList.remove('open', 'is-open');
  document.body.style.overflow = '';
}

function handleContractPreviewOverlayClick(event) {
  if (event?.target?.id === 'contract-preview-overlay') {
    closeContractPreviewModal();
  }
}

function getContractMessageTokenMap() {
  const optionId = selectedOpt?.id;
  const optionNumber = Math.max(1, options.findIndex((o) => o.id === optionId) + 1);
  const term = Number(selectedOpt?.term) || 36;
  const totalMonthly = selectedOpt
    ? calcOption(selectedOpt, getOptionPromotion(selectedOpt), (selectedOpt.forcedTierIndex ?? -1)).totalMonthly
    : 0;

  return {
    contactName: 'Laura',
    optionNumber: String(optionNumber),
    term: term + ' months',
    monthlyValue: formatMoney(totalMonthly),
    totalUnits: String(totalUnitsForOption(selectedOpt)),
    repName: 'ValuCal Sales Team',
    repEmail: 'marcus.reid@verizonconnect.com',
    repPhone: '(800) 922-0220'
  };
}

function renderContractTemplate(text, tokenMap) {
  let output = String(text || '');
  Object.keys(tokenMap || {}).forEach(function(key) {
    const marker = '{{' + key + '}}';
    output = output.split(marker).join(String(tokenMap[key] || ''));
  });
  return output;
}

function getContractMessageModulesModel(forceReset = false) {
  if (!forceReset && proposalData.contractMessageModulesModel && proposalData.contractMessageModulesModel.blocks) {
    return proposalData.contractMessageModulesModel;
  }

  const model = { order: [], blocks: {} };
  CONTRACT_MESSAGE_MODULE_OPTIONS.forEach(function(def) {
    model.order.push(def.key);
    model.blocks[def.key] = {
      key: def.key,
      kind: def.kind,
      mandatory: !!def.mandatory,
      visible: def.mandatory ? true : !!(CONTRACT_MESSAGE_DEFAULT_MODULE_SELECTION[def.key] ?? def.visibleByDefault),
      text: String(def.text || ''),
      items: Array.isArray(def.items) ? def.items.slice() : []
    };
  });
  proposalData.contractMessageModulesModel = model;
  return model;
}

function buildContractMessagePlainTextFromModules() {
  const model = getContractMessageModulesModel();
  const tokenMap = getContractMessageTokenMap();
  const sections = [];

  model.order.forEach(function(blockId) {
    const block = model.blocks[blockId];
    if (!block) return;
    if (!block.mandatory && !block.visible) return;

    if (block.kind === 'text') {
      const text = renderContractTemplate(block.text || '', tokenMap).trim();
      if (text) sections.push(text);
      return;
    }

    if (block.kind === 'list') {
      const def = CONTRACT_MESSAGE_MODULE_OPTIONS.find(function(item) { return item.key === blockId; });
      const title = (def?.label || '').trim();
      const rows = (block.items || []).map(function(item, idx) {
        const line = renderContractTemplate(item, tokenMap).trim();
        if (!line) return '';
        if (blockId === 'signatureSteps') return (idx + 1) + '. ' + line;
        return '- ' + line;
      }).filter(Boolean);
      if (!rows.length) return;
      const section = title ? (title + ':\n' + rows.join('\n')) : rows.join('\n');
      sections.push(section);
    }
  });

  return sections.join('\n\n').trim();
}

function syncContractMessageFromModules() {
  setContractMessageText(buildContractMessagePlainTextFromModules());
}

function getContractMessageBodyElement() {
  return document.getElementById('contract-msg-body');
}

function getContractMessageFormat() {
  const format = String(proposalData.contractMessageFormat || '').trim();
  return format === CONTRACT_MESSAGE_FORMATS.PLAIN ? CONTRACT_MESSAGE_FORMATS.PLAIN : CONTRACT_MESSAGE_FORMATS.VISUAL;
}

function renderContractMessageFormatControl() {
  const plainBtn = document.getElementById('contract-message-format-plain');
  const visualBtn = document.getElementById('contract-message-format-visual');
  const format = getContractMessageFormat();
  if (plainBtn) plainBtn.classList.toggle('segmented-control__option--active', format === CONTRACT_MESSAGE_FORMATS.PLAIN);
  if (visualBtn) visualBtn.classList.toggle('segmented-control__option--active', format === CONTRACT_MESSAGE_FORMATS.VISUAL);
}

function getContractMessageText() {
  const bodyEl = getContractMessageBodyElement();
  if (!bodyEl) return '';
  const contentEl = bodyEl.querySelector('[data-contract-message-content]') || bodyEl;
  return (contentEl.innerText || '').replace(/\u00a0/g, ' ').trim();
}

function buildContractVisualEditableHtml(plainText) {
  const lines = String(plainText || '').split('\n');
  const parts = [];
  let buffer = [];
  lines.forEach((line) => {
    const trimmed = line.trim();
    if (!trimmed) {
      if (buffer.length) {
        parts.push('<p style="margin:0 0 14px;">' + proposalEscapeHtml(buffer.join(' ')) + '</p>');
        buffer = [];
      }
      return;
    }
    if (/^[-*]\s+/.test(trimmed)) {
      if (buffer.length) {
        parts.push('<p style="margin:0 0 14px;">' + proposalEscapeHtml(buffer.join(' ')) + '</p>');
        buffer = [];
      }
      parts.push('<p style="margin:0 0 8px 0;padding-left:14px;">• ' + proposalEscapeHtml(trimmed.replace(/^[-*]\s+/, '')) + '</p>');
      return;
    }
    buffer.push(trimmed);
  });
  if (buffer.length) {
    parts.push('<p style="margin:0 0 14px;">' + proposalEscapeHtml(buffer.join(' ')) + '</p>');
  }

  const now = new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  return '<div style="border:1px solid #E5E7EB;background:#FFFFFF;border-radius:12px;overflow:hidden;">' +
    '<div contenteditable="false" style="display:flex;align-items:center;justify-content:space-between;padding:12px 14px;border-bottom:1px solid #EEE;background:linear-gradient(90deg,#FFFFFF 0%,#FAFAFA 100%);">' +
      '<div style="display:flex;align-items:center;gap:10px;">' +
        '<span style="display:inline-flex;width:8px;height:8px;border-radius:999px;background:#EE001E;"></span>' +
        '<span style="font-size:12px;font-weight:700;letter-spacing:.04em;color:#111;text-transform:uppercase;">Contract Message</span>' +
      '</div>' +
      '<span style="font-size:11px;color:#6B7280;">' + proposalEscapeHtml(now) + '</span>' +
    '</div>' +
    '<div contenteditable="false" style="padding:14px 16px;border-bottom:1px solid #F1F1F1;background:#FFF8F8;">' +
      '<div style="font-size:18px;font-weight:800;line-height:1.2;color:#111;margin-bottom:6px;">Contract package ready for signature</div>' +
      '<div style="font-size:12px;line-height:1.5;color:#4B5563;">Review the final agreement details below and share the View Contract action with your customer.</div>' +
    '</div>' +
    '<div style="padding:16px;">' +
      '<div data-contract-message-content="1" style="font-size:14px;line-height:1.65;color:#1a1a1a;">' + (parts.join('') || '<p style="margin:0;"><br></p>') + '</div>' +
    '</div>' +
    '<div contenteditable="false" style="padding:12px 16px;border-top:1px solid #F3F4F6;background:#F9FAFB;">' +
      '<div style="font-size:11px;color:#6B7280;">Verizon Connect • Secure DocuSign workflow</div>' +
    '</div>' +
  '</div>';
}

function buildContractVisualPreviewHtml(plainText) {
  const model = getContractMessageModulesModel();
  const tokenMap = getContractMessageTokenMap();
  const contractActionBlock =
    '<div class="vez-email__block">' +
      '<h3 class="vez-email__block-label">Contract action</h3>' +
      '<div style="margin-bottom:12px;">Open the agreement in DocuSign to complete signature and payment setup.</div>' +
      '<a href="#" onclick="return false;" class="vez-email__link-btn">View contract</a>' +
    '</div>';

  const sections = [];
  let contractActionInserted = false;
  model.order.forEach(function(blockId) {
    const block = model.blocks[blockId];
    const def = CONTRACT_MESSAGE_MODULE_OPTIONS.find(function(item) { return item.key === blockId; });
    if (!block || !def) return;
    if (!block.mandatory && !block.visible) return;

    if (block.kind === 'text') {
      const text = renderContractTemplate(block.text || '', tokenMap).trim();
      if (!text) return;
      const rows = text.split('\n').filter(Boolean).map(function(line) {
        return '<p>' + proposalEscapeHtml(line) + '</p>';
      }).join('');
      if (blockId === 'intro') {
        sections.push('<div class="vez-email__block vez-email__block--no-border">' + rows + '</div>');
        sections.push(contractActionBlock);
        contractActionInserted = true;
      } else {
        sections.push('<div class="vez-email__block"><h3 class="vez-email__block-label">' + proposalEscapeHtml(def.label) + '</h3>' + rows + '</div>');
      }
      return;
    }

    if (block.kind === 'list') {
      const listRows = (block.items || []).map(function(item) {
        const line = renderContractTemplate(item, tokenMap).trim();
        if (!line) return '';
        return '<div class="vez-email__check-item"><span class="material-symbols-outlined">check_circle</span><span>' + proposalEscapeHtml(line) + '</span></div>';
      }).filter(Boolean).join('');
      if (!listRows) return;
      sections.push('<div class="vez-email__block"><h3 class="vez-email__block-label">' + proposalEscapeHtml(def.label) + '</h3><div class="vez-email__check-list">' + listRows + '</div></div>');
    }
  });

  if (!contractActionInserted) sections.push(contractActionBlock);

  const year = new Date().getFullYear();
  const header = '<div class="vez-email__global-header"><div class="vez-email__global-header-logo"><img src="app/assets/logo.svg" alt="Verizon Connect"></div></div>';
  const hero = '<div class="vez-email__hero"><h1>Your Contract<br>is Ready.</h1><p>Review terms and complete signature securely in DocuSign.</p></div>';
  const footer =
    '<div class="vez-email__footer">' +
      '<p style="margin:0 0 12px;font-size:13px;color:#1a1a1a;">© ' + year + ' Verizon. All rights reserved.</p>' +
      '<p style="margin:0 0 24px;font-size:13px;color:#1a1a1a;line-height:1.6;">This message contains contract details prepared for your fleet package selection.</p>' +
      '<img src="app/assets/logo.svg" alt="Verizon Connect" style="height:32px;display:block;">' +
    '</div>';

  return '<div class="vez-email">' + header + hero + '<div class="vez-email__body">' + sections.join('') + '</div>' + footer + '</div>';
}

function renderContractMessagePreview() {
  const toEl = document.getElementById('contract-msg-to');
  const subjectEl = document.getElementById('contract-msg-subject');
  const bodyEl = document.getElementById('contract-msg-preview-body');
  const toTarget = document.getElementById('contract-msg-preview-to');
  const subjectTarget = document.getElementById('contract-msg-preview-subject');
  const previewCard = document.getElementById('contract-msg-preview-card');
  if (!bodyEl || !toTarget || !subjectTarget || !previewCard) return;

  const to = (toEl?.value || '').trim();
  const subject = (subjectEl?.value || '').trim();
  const format = getContractMessageFormat();
  const plainText = getContractMessageText();

  toTarget.textContent = to || '—';
  subjectTarget.textContent = subject || '—';

  if (format === CONTRACT_MESSAGE_FORMATS.VISUAL) {
    previewCard.classList.add('is-visual-format');
    bodyEl.innerHTML = buildContractVisualPreviewHtml(plainText);
  } else {
    previewCard.classList.remove('is-visual-format');
    bodyEl.innerHTML = proposalEscapeHtml(plainText || '').replace(/\n/g, '<br>') || '<span style="color:var(--gray-400);">Start writing your message...</span>';
  }
}

function setContractMessageText(text) {
  const bodyEl = getContractMessageBodyElement();
  if (!bodyEl) return;
  const plain = String(text || '');
  bodyEl.dataset.plainText = plain;
  if (getContractMessageFormat() === CONTRACT_MESSAGE_FORMATS.VISUAL) {
    bodyEl.innerHTML = buildContractVisualEditableHtml(plain);
  } else {
    bodyEl.textContent = plain;
  }
  updateContractCharCount();
  renderContractMessagePreview();
}

function setContractMessageFormat(nextFormat) {
  const resolved = nextFormat === CONTRACT_MESSAGE_FORMATS.VISUAL ? CONTRACT_MESSAGE_FORMATS.VISUAL : CONTRACT_MESSAGE_FORMATS.PLAIN;
  if (proposalData.contractMessageFormat === resolved) return;
  const currentText = getContractMessageText();
  proposalData.contractMessageFormat = resolved;
  renderContractMessageFormatControl();
  setContractMessageText(currentText);
  updateContractSendBtn();
}

function onContractMessageInput() {
  const bodyEl = getContractMessageBodyElement();
  if (!bodyEl) return;
  bodyEl.dataset.plainText = getContractMessageText();
  updateContractCharCount();
  updateContractSendBtn();
}

function renderContractMessageContentChecklist() {
  const host = document.getElementById('contract-message-content-list');
  if (!host) return;
  const model = getContractMessageModulesModel();

  function renderListEditor(moduleKey, block) {
    const rows = (block.items || []).map(function(item, idx) {
      return '<div class="msg-inline-list-row">' +
        '<input type="text" class="msg-inline-item-input input" value="' + proposalEscapeHtml(item) + '" oninput="onContractMessageModuleListItemInput(\'' + moduleKey + '\',' + idx + ',this.value)">' +
        '<button type="button" class="btn-icon btn-icon--ghost-vds btn-icon--fit msg-inline-item-delete" aria-label="Delete" onclick="removeContractMessageModuleListItem(\'' + moduleKey + '\',' + idx + ')"><span class="material-symbols-outlined" aria-hidden="true">delete</span></button>' +
      '</div>';
    }).join('');
    return '<div class="msg-content-item-editor"><div class="msg-inline-list">' + rows + '</div><button type="button" class="btn-dashed-add btn-dashed-add--pill" onclick="addContractMessageModuleListItem(\'' + moduleKey + '\')">+ Add item</button></div>';
  }

  function renderTextEditor(moduleKey, block) {
    return '<div class="msg-content-item-editor"><textarea class="msg-inline-textarea" rows="3" oninput="onContractMessageModuleTextInput(\'' + moduleKey + '\', this.value)">' + proposalEscapeHtml(block.text || '') + '</textarea></div>';
  }

  host.innerHTML = '<div class="msg-content-list">' + CONTRACT_MESSAGE_MODULE_OPTIONS.map(function(def) {
    const block = model.blocks[def.key];
    if (!block) return '';
    const visible = block.mandatory ? true : !!block.visible;

    const editorHtml = block.kind === 'list'
      ? renderListEditor(def.key, block)
      : renderTextEditor(def.key, block);

    if (block.mandatory) {
      return '<div class="msg-content-item msg-content-item--mandatory"><div class="msg-content-item-header"><span class="msg-content-item-title">' + proposalEscapeHtml(def.label) + '</span></div>' + editorHtml + '</div>';
    }

    const cbId = 'contract-msg-cb-' + def.key;
    const contentHtml = visible ? editorHtml : '';
    return '<div class="msg-content-item">' +
      '<div class="msg-content-item-header" onclick="var cb=document.getElementById(\'' + cbId + '\');cb.checked=!cb.checked;toggleContractMessageModule(\'' + def.key + '\', cb.checked);">' +
        '<label class="checkbox" onclick="event.stopPropagation()"><input type="checkbox" class="checkbox__input" id="' + cbId + '" aria-label="' + proposalEscapeHtml(def.label) + '" ' + (visible ? 'checked ' : '') + 'onclick="event.stopPropagation()" onchange="toggleContractMessageModule(\'' + def.key + '\', this.checked)"><span class="checkbox__content"></span></label>' +
        '<span class="msg-content-item-title">' + proposalEscapeHtml(def.label) + '</span>' +
      '</div>' +
      contentHtml +
    '</div>';
  }).join('') + '</div>';
}

  function renderListEditor(moduleKey, block) {
    const rows = (block.items || []).map(function(item, idx) {
      return '<div class="msg-inline-list-row">' +
        '<input type="text" class="msg-inline-item-input input" value="' + proposalEscapeHtml(item) + '" oninput="onContractMessageModuleListItemInput(\'' + moduleKey + '\',' + idx + ',this.value)">' +
        '<button type="button" class="btn-icon btn-icon--ghost-vds btn-icon--fit msg-inline-item-delete" aria-label="Delete" onclick="removeContractMessageModuleListItem(\'' + moduleKey + '\',' + idx + ')"><span class="material-symbols-outlined" aria-hidden="true">delete</span></button>' +
      '</div>';
    }).join('');
    return '<div class="msg-content-item-editor"><div class="msg-inline-list">' + rows + '</div><button type="button" class="btn-dashed-add btn-dashed-add--pill" onclick="addContractMessageModuleListItem(\'' + moduleKey + '\')">+ Add item</button></div>';
  }

  function renderTextEditor(moduleKey, block) {
    return '<div class="msg-content-item-editor"><textarea class="msg-inline-textarea" rows="3" oninput="onContractMessageModuleTextInput(\'' + moduleKey + '\', this.value)">' + proposalEscapeHtml(block.text || '') + '</textarea></div>';
  }

function insertContractMessageModule(moduleKey) {
  const model = getContractMessageModulesModel();
  if (!model.blocks[moduleKey] || model.blocks[moduleKey].mandatory) return;
  model.blocks[moduleKey].visible = true;
  proposalData.contractMessageModulesModel = model;
  renderContractMessageContentChecklist();
  syncContractMessageFromModules();
  updateContractSendBtn();
}

function removeContractMessageModule(moduleKey) {
  const model = getContractMessageModulesModel();
  if (!model.blocks[moduleKey] || model.blocks[moduleKey].mandatory) return;
  model.blocks[moduleKey].visible = false;
  proposalData.contractMessageModulesModel = model;
  renderContractMessageContentChecklist();
  syncContractMessageFromModules();
  updateContractSendBtn();
}

function toggleContractMessageModule(moduleKey, checked) {
  if (checked) {
    insertContractMessageModule(moduleKey);
  } else {
    removeContractMessageModule(moduleKey);
  }
}

function onContractMessageModuleTextInput(moduleKey, value) {
  const model = getContractMessageModulesModel();
  const block = model.blocks[moduleKey];
  if (!block || block.kind !== 'text') return;
  block.text = String(value == null ? '' : value);
  proposalData.contractMessageModulesModel = model;
  syncContractMessageFromModules();
  updateContractSendBtn();
}

function onContractMessageModuleListItemInput(moduleKey, itemIndex, value) {
  const model = getContractMessageModulesModel();
  const block = model.blocks[moduleKey];
  if (!block || block.kind !== 'list' || !Array.isArray(block.items) || itemIndex < 0 || itemIndex >= block.items.length) return;
  block.items[itemIndex] = String(value == null ? '' : value);
  proposalData.contractMessageModulesModel = model;
  syncContractMessageFromModules();
  updateContractSendBtn();
}

function addContractMessageModuleListItem(moduleKey) {
  const model = getContractMessageModulesModel();
  const block = model.blocks[moduleKey];
  if (!block || block.kind !== 'list' || !Array.isArray(block.items)) return;
  block.items.push('');
  proposalData.contractMessageModulesModel = model;
  renderContractMessageContentChecklist();
  syncContractMessageFromModules();
  updateContractSendBtn();
}

function removeContractMessageModuleListItem(moduleKey, itemIndex) {
  const model = getContractMessageModulesModel();
  const block = model.blocks[moduleKey];
  if (!block || block.kind !== 'list' || !Array.isArray(block.items) || itemIndex < 0 || itemIndex >= block.items.length) return;
  block.items.splice(itemIndex, 1);
  if (!block.items.length) block.items.push('');
  proposalData.contractMessageModulesModel = model;
  renderContractMessageContentChecklist();
  syncContractMessageFromModules();
  updateContractSendBtn();
}

function updateContractSendBtn() {
  const to = document.getElementById('contract-msg-to')?.value.trim();
  const sub = document.getElementById('contract-msg-subject')?.value.trim();
  const body = getContractMessageText();
  const btn = document.getElementById('contract-send-btn');
  renderContractMessagePreview();
  if (btn && screen === 'contract-review') btn.disabled = !(to && sub && body);
}

  function updateContractCharCount() {
  const countEl = document.getElementById('contract-char-count');
  if (!countEl) return;
  countEl.innerText = String(getContractMessageText().length);
}

function buildWaveInstallScheduleHtml(opt) {
  const waves = Array.isArray(opt && opt.waves) ? opt.waves : [];
  if (!waves.length) return '';
  const isGov = proposalData.segment === 'Government';
  const govTh = isGov
    ? `<th style="text-align:left; padding:10px 16px; font-size:10px; font-weight:700; letter-spacing:0.02em; color:#7a7a7a; border-bottom:1px solid #efefef;">Approp. ref / expiry</th>`
    : '';
  const rows = waves.map(w => {
    const dateStr = w.targetDate
      ? new Date(w.targetDate + 'T00:00:00').toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
      : 'TBD';
    const qty = Number(w.qty) || 0;
    let govTd = '';
    if (isGov) {
      const ref = (w.appropsRef || '').replace(/</g, '&lt;') || '&mdash;';
      const expStr = w.appropsExpiry
        ? new Date(w.appropsExpiry + 'T00:00:00').toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
        : 'N/A';
      const warn = w.appropsExpiry && w.targetDate && w.targetDate > w.appropsExpiry
        ? ` <span style="color:#92400E;font-weight:700;font-size:10px;">\u26a0 Expiry before wave date</span>`
        : '';
      govTd = `<td style="padding:12px 16px; border-bottom:1px solid #f0f0f0; font-size:12px; color:#1a1a1a;">${ref}<br><span style="color:#6B7280;font-size:11px;">${expStr}</span>${warn}</td>`;
    }
    return `<tr>
        <td style="padding:12px 16px; border-bottom:1px solid #f0f0f0; font-size:13px; color:#1a1a1a; font-weight:600;">${(w.name || 'Wave').replace(/</g,'&lt;')}</td>
        <td style="padding:12px 16px; border-bottom:1px solid #f0f0f0; font-size:13px; color:#1a1a1a;">${dateStr}</td>
        <td style="padding:12px 16px; border-bottom:1px solid #f0f0f0; font-size:13px; color:#1a1a1a;">${qty}</td>
        <td style="padding:12px 16px; border-bottom:1px solid #f0f0f0; font-size:11px; font-weight:700; color:#1D4ED8;">Contracted \u2014 Not Billing</td>
        ${govTd}
      </tr>`;
  }).join('');
  const govFootnote = isGov
    ? ` Government slots may enter <strong>Lapsed</strong> if appropriation expires before dispatch (no ECF, inventory released). `
    : '';
  return `
    <div style="height:1px; background:#efefef; margin:28px 0;"></div>
    <div style="font-size:12px; font-weight:800; letter-spacing:0.02em; color:#1a1a1a; margin-bottom:14px;">Installation schedule</div>
    <table style="width:100%; border-collapse:collapse; border:1px solid #efefef; border-radius:8px; overflow:hidden; font-family:inherit;">
      <thead>
        <tr style="background:#fafafa;">
          <th style="text-align:left; padding:10px 16px; font-size:10px; font-weight:700; letter-spacing:0.02em; color:#7a7a7a; border-bottom:1px solid #efefef;">Wave</th>
          <th style="text-align:left; padding:10px 16px; font-size:10px; font-weight:700; letter-spacing:0.02em; color:#7a7a7a; border-bottom:1px solid #efefef;">Target date</th>
          <th style="text-align:left; padding:10px 16px; font-size:10px; font-weight:700; letter-spacing:0.02em; color:#7a7a7a; border-bottom:1px solid #efefef;">Units</th>
          <th style="text-align:left; padding:10px 16px; font-size:10px; font-weight:700; letter-spacing:0.02em; color:#7a7a7a; border-bottom:1px solid #efefef;">Initial slot status</th>
          ${govTh}
        </tr>
      </thead>
      <tbody>${rows}</tbody>
    </table>
    <div style="margin-top:10px; font-size:11px; color:#7a7a7a; line-height:1.6;">
      Units enter <strong>Active-Billing</strong> upon device activation. <strong>Pending Bind</strong> slots (on-site, not yet activated) do not count toward the billing floor.
      Contracted units undispatched 30\u00a0days past target date activate the pool floor per MSA \u00a74.2 (BR-44/45).${govFootnote}
    </div>`;
}

function sendContractNow() {
  {
    const isResend = contractResendMode;
    const returnState = ['signed', 'payment'].includes(contractResendReturnState)
      ? contractResendReturnState
      : 'waiting';

    // Switch to phase 2: Sign & Payment
    document.getElementById('contract-phase-review').classList.add('hidden');
    document.getElementById('contract-phase-signpay').classList.remove('hidden');
    // Sync doc viewer 2
    const v1 = document.getElementById('contract-doc-viewer');
    const v2 = document.getElementById('contract-doc-viewer2');
    if (v1 && v2) {
      v2.innerHTML = v1.innerHTML;
      // Recompute scale using the new container width in Signature phase.
      requestAnimationFrame(scaleDocPages);
    }
    // Stepper: step 1 done → step 2 active
    const d1 = document.getElementById('c-dot-1');
    const d2 = document.getElementById('c-dot-2');
    const l1 = document.getElementById('c-line-1');
    if (d1) { d1.className = 'c-step-dot done'; }
    if (l1) l1.className = 'c-line done';
    if (d2) d2.className = 'c-step-dot active';
    if (document.getElementById('c-dot-label-2')) document.getElementById('c-dot-label-2').className = 'c-step-label';
    const date1 = document.getElementById('contract-date-1');
    if (date1) date1.textContent = new Date().toLocaleDateString();

    // Show a basic loader before entering waiting/signature tracking state.
    setContractSendLoaderVisible(true);
    clearContractSendLoaderTimer();
    contractSendLoaderTimer = window.setTimeout(() => {
      contractSendLoaderTimer = null;
      setContractSendLoaderVisible(false);
      finalizeContractSendTransition(isResend, returnState);
    }, CONTRACT_SEND_LOADER_DELAY_MS);
  }
}


/* ── Deal Result (shared, 2026-10-08 — per Catalina: Contract and Deal Result are the same steps in both flows).
   Initial Sales version: won / signed, SVT pending (Close + View Contract), closed-lost. Fulfillment is on hold, so
   there is no fulfillment CTA here. Optional flow hook: captureCompletedPilotAccount() (Initial Sales pilots). */
let lastDealResultMode = null;
window.VC = window.VC || {};
window.VC.dealResultMarkup = function () { return "\u003cdiv id=\"screen-deal-result\" class=\"content-area hidden deal-result-screen\">\n    \u003cdiv id=\"deal-result-main-content\" class=\"deal-result-main\">\n      \u003cdiv id=\"deal-result-icon\" class=\"deal-result-icon\">\u003c/div>\n      \u003ch2 id=\"deal-result-title\" class=\"deal-result-title\">\u003c/h2>\n      \u003cp id=\"deal-result-subtitle\" class=\"deal-result-subtitle\">\u003c/p>\n      \u003cdiv class=\"deal-result-ctas\">\n        \u003cbutton type=\"button\" id=\"deal-result-primary-btn\" class=\"btn btn--primary btn--large btn-block\" onclick=\"closeDealResult()\">Close\u003c/button>\n        \u003cbutton type=\"button\" id=\"deal-result-secondary-btn\" class=\"btn btn--secondary btn--large btn-block hidden\" onclick=\"openDealResultViewContractConfirmModal()\">View Contract\u003c/button>\n      \u003c/div>\n    \u003c/div>\n  \u003c/div>"; };

function enterDealResult(mode = 'won') {
  clearSignatureCompletionSimulation();
  clearSvtPendingTransition();
  lastDealResultMode = mode;
  contractResendMode = false;
  contractResendReturnState = 'waiting';
  // Hide all main screens, show deal result
  document.getElementById('screen-drafting').classList.add('hidden');
  hideProposalReviewModal();
  document.getElementById('screen-proposal-selection').classList.add('hidden');
  document.getElementById('screen-contract').classList.add('hidden');
  document.getElementById('screen-deal-result').classList.remove('hidden');
  dismissSuccessBanner();

  // Update main stepper — both steps done
  const dot1 = document.getElementById('step-dot-1');
  const dot2m = document.getElementById('step-dot-2');
  if (dot1) { dot1.className = 'vc-step-dot done'; dot1.innerHTML = '<span class="material-symbols-outlined" style="font-size:14px;">check</span>'; }
  if (dot2m) { dot2m.className = 'vc-step-dot done'; dot2m.innerHTML = '<span class="material-symbols-outlined" style="font-size:14px;">check</span>'; }

  // Set deal result dates
  const today = new Date().toLocaleDateString();
  const d1 = document.getElementById('deal-date-1');
  const d2 = document.getElementById('deal-date-2');
  const d3 = document.getElementById('deal-date-3');
  if (d1) d1.textContent = today;
  if (d2) d2.textContent = today;
  if (d3) d3.textContent = today;

  // Footer — hide send, hide back
  document.getElementById('footer-send').classList.add('hidden');
  document.getElementById('footer-back').classList.remove('visible');
  document.getElementById('footer-back').style.display = 'none';

  touchNavDate('result', true);
  const iconWrap = document.getElementById('deal-result-icon');
  const title = document.getElementById('deal-result-title');
  const subtitle = document.getElementById('deal-result-subtitle');
  const primaryBtn = document.getElementById('deal-result-primary-btn');
  const closeRow = document.getElementById('deal-result-close-row');
  const mainContent = document.getElementById('deal-result-main-content');
  const dealSimTitle = document.getElementById('sim-title-deal-result');
  const dealSimSvt = document.getElementById('sim-svt-approved-deal-result');

  if (dealSimTitle) dealSimTitle.classList.toggle('hidden', mode !== 'svt-pending');
  if (dealSimSvt) dealSimSvt.classList.toggle('hidden', mode !== 'svt-pending');
  if (mainContent) mainContent.classList.remove('hidden');

  if (iconWrap && title && subtitle && primaryBtn) {
    if (mode === 'rejected') {
      if (closeRow) closeRow.style.display = 'none';
      iconWrap.innerHTML = `<svg width="52" height="56" viewBox="0 0 52 56" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="4" y="2" width="36" height="46" rx="3" stroke="#000" stroke-width="2"/>
        <line x1="12" y1="16" x2="32" y2="16" stroke="#000" stroke-width="2" stroke-linecap="round"/>
        <line x1="12" y1="24" x2="32" y2="24" stroke="#000" stroke-width="2" stroke-linecap="round"/>
        <line x1="12" y1="32" x2="22" y2="32" stroke="#000" stroke-width="2" stroke-linecap="round"/>
        <circle cx="38" cy="44" r="11" fill="#000"/>
        <path d="M33.5 39.5L42.5 48.5M42.5 39.5L33.5 48.5" stroke="white" stroke-width="2" stroke-linecap="round"/>
      </svg>`;
      title.innerHTML = 'Deal marked as closed-lost';
      subtitle.innerHTML = 'The quoting session has been closed based on the selected rejection reason.';
      primaryBtn.textContent = 'Close';
      primaryBtn.disabled = false;
      primaryBtn.onclick = () => closeDealResult();
    } else if (mode === 'svt-pending') {
      if (closeRow) closeRow.style.display = 'flex';
      iconWrap.innerHTML = `<svg width="52" height="56" viewBox="0 0 52 56" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="4" y="2" width="36" height="46" rx="3" stroke="#000" stroke-width="2"/>
        <line x1="12" y1="16" x2="32" y2="16" stroke="#000" stroke-width="2" stroke-linecap="round"/>
        <line x1="12" y1="24" x2="32" y2="24" stroke="#000" stroke-width="2" stroke-linecap="round"/>
        <line x1="12" y1="32" x2="22" y2="32" stroke="#000" stroke-width="2" stroke-linecap="round"/>
        <circle cx="38" cy="44" r="11" fill="#000"/>
        <path d="M33 44l3.5 3.5L43 40.5" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>`;
      title.innerHTML = 'Contract signed and payment<br>configured';
      subtitle.innerHTML = '<p style="margin:0 0 8px; font-size:14px; color:var(--black);">The deal is complete on your end — you can close this now.</p><p style="margin:0; font-size:14px; color:var(--black);">We\'ll notify you once the <strong>SVT (Sales Velocity Team) validation</strong> is confirmed.</p>';
      primaryBtn.textContent = 'Close';
      primaryBtn.disabled = false;
      primaryBtn.onclick = () => closeDealResult();
    } else {
      if (closeRow) closeRow.style.display = 'flex';
      iconWrap.innerHTML = `<svg width="52" height="56" viewBox="0 0 52 56" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="4" y="2" width="36" height="46" rx="3" stroke="#000" stroke-width="2"/>
        <line x1="12" y1="16" x2="32" y2="16" stroke="#000" stroke-width="2" stroke-linecap="round"/>
        <line x1="12" y1="24" x2="32" y2="24" stroke="#000" stroke-width="2" stroke-linecap="round"/>
        <line x1="12" y1="32" x2="22" y2="32" stroke="#000" stroke-width="2" stroke-linecap="round"/>
        <circle cx="38" cy="44" r="11" fill="#000"/>
        <path d="M33 44l3.5 3.5L43 40.5" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>`;
      title.innerHTML = 'Contract signed and payment<br>configured';
      subtitle.innerHTML = 'The contract is fully executed and the payment method has been set up.';
      primaryBtn.textContent = 'Close';
      primaryBtn.disabled = false;
      primaryBtn.onclick = () => closeDealResult();
    }
  }
  updateDealResultFulfillmentCta();
  screen = 'deal-result';
  renderNav();
}

function closeDealResult() {
  document.getElementById('more-menu-deal-result')?.classList.add('hidden');
  if (lastDealResultMode !== 'rejected' && typeof captureCompletedPilotAccount === 'function') captureCompletedPilotAccount(); // Initial Sales pilots
  clearSvtPendingTransition();
  openQuotesList();
}

function openDealResultViewContractConfirmModal() {
  document.getElementById('more-menu-deal-result')?.classList.add('hidden');
  closeContractModifyConfirmModal();
  openContractInDocuSign();
}

function updateDealResultFulfillmentCta() {
  const primaryBtn = document.getElementById('deal-result-primary-btn');
  const secondaryBtn = document.getElementById('deal-result-secondary-btn');
  const badge = document.getElementById('deal-result-status-badge');
  if (!primaryBtn) return;

  if (lastDealResultMode === 'svt-pending') {
    if (badge) {
      badge.textContent = 'Pending SVT Validation';
      badge.style.background = '#eef6ff';
      badge.style.color = '#1d4e89';
      badge.style.borderColor = '#c7ddf7';
    }
    primaryBtn.textContent = 'Close';
    primaryBtn.disabled = false;
    primaryBtn.onclick = () => closeDealResult();
    if (secondaryBtn) {
      secondaryBtn.classList.remove('hidden');
      secondaryBtn.disabled = false;
      secondaryBtn.onclick = () => openDealResultViewContractConfirmModal();
    }
    return;
  }

  if (badge) {
    badge.textContent = 'Deal validated';
    badge.style.background = '#dcfce7';
    badge.style.color = 'var(--green)';
    badge.style.borderColor = '#86efac';
  }
  primaryBtn.textContent = 'Close';
  primaryBtn.disabled = false;
  primaryBtn.onclick = () => closeDealResult();
  if (secondaryBtn) {
    secondaryBtn.classList.add('hidden');
    secondaryBtn.disabled = false;
  }
}


/* Mark as dead — confirm (shared, 2026-10-09; Existing used to say "Closed", now "Dead" in both flows per Catalina).
   From a Proposal Dashboard row: Dead badge with the closure reason; from drafting/selection: Deal Result. */
function confirmMarkDead() {
  const reason = document.getElementById('dead-reason-select')?.value;
  if (!reason) {
    alert('Please select a reason before confirming.');
    return;
  }
  closeMarkDeadModal();

  if (_qlClosePendingRow) {
    // Coming from quotes list — update badge and move row to bottom
    const row = _qlClosePendingRow;
    _qlClosePendingRow = null;
    const quoteName = row.querySelector('a.record-link')?.textContent?.trim() || 'Quote';
    const reasonEl  = document.getElementById('dead-reason-select');
    const reasonText = reasonEl?.options[reasonEl.selectedIndex]?.text || reason;
    const badgeCell = row.querySelector('.badge')?.closest('td');
    if (badgeCell) {
      const today = new Date();
      const closedDate = today.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
      badgeCell.innerHTML = `
        <span class="badge badge--black badge__tooltip-wrap">
          Dead
          <span class="badge__tooltip-icon material-symbols-outlined" style="font-size:16px;width:16px;height:16px;font-variation-settings:'FILL' 0,'wght' 300;">info</span>
          <div class="badge__tooltip-popup">
            <strong style="font-size:12px; font-weight:700; color:#000; line-height:16px; display:block; margin-bottom:2px;">Closure reason</strong>
            <div style="font-size:12px; font-weight:400; color:#000; line-height:16px;">${reasonText}</div>
          </div>
        </span>`;
      // 2026-10-05 (per Catalina): no date under the Dead badge — the
      // Created / Modified column already carries it, so Modified updates.
      const modifiedNote = row.querySelector('td:nth-child(4) .ql-cell-ref');
      if (modifiedNote) modifiedNote.textContent = `Modified ${closedDate}`;
    }
    const tbody = row.closest('tbody');
    if (tbody) tbody.appendChild(row);
    const newBtn = document.getElementById('btn-new-proposal');
    if (newBtn) { newBtn.disabled = false; newBtn.title = ''; }
    // Show success notification
    showSuccessBanner('Proposal marked as dead', `"${quoteName}" was marked as Dead.`);
  } else {
    // Coming from within drafting/selection — navigate to deal result
    enterDealResult('rejected');
  }
}
