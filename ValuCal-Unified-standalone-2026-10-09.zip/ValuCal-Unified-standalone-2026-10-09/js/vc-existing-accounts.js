/* ── Existing accounts — demo account, MSA panel (shared module, 2026-10-09) ─────────────────────
   Moved verbatim from ExistingAccounts/index.html so the unified file can show a Customer account with
   the same data and the same MSA panel. Loaded by Existing Accounts and by Unified (customer scenarios).
   Reads, from the page: accountStatus ('active' | 'inactive'), options, proposalData; uses shared helpers
   (sumMsaTierQty, getMsaDiscountTier, formatMoney, VC.accountSummaryPanel, VC.kebabMenu…). */

// ── F2: MSA / Co-term ────────────────────────────────────────────
// Mock MSA on file for demo account (Apex Construction LLC).
// In production this comes from the Salesforce Account record.
const DEMO_MSA = {
  id: 'MSA-2024-0391',
  startDate: '2025-01-01',
  endDate: '2027-12-31',
  contractStartDate: '2025-01-01',
  contractEndDate: '2027-12-31',
  termMonths: 36,
  vehicleCount: 45,
  vehicleTrackingPrice: 34.00,
  poweredAssetTrackingPrice: 18.00,
  minQuantityCommitment: 60,
  minimumSpendCommitment: 870.00,
  rampUpPeriodMonths: 30,
  discretionaryDiscountPct: 7,
};

// Demo seed data (2026-09-16, per Catalina): represents an order this account
// ALREADY has under contract — separate from `options`, which is whatever
// NEW order the rep is drafting in THIS session ("como estamos entrando acá,
// vamos a crear otra orden"). Account Setup's aggregate pricing table
// (R11-add) needs something real to show at the Account level even before
// the rep has added a single bundle to the new order — this seed is that
// already-existing order. See buildAccountSetupPricingPayload() below.
const DEMO_CONTRACT_ACCOUNTS = [
  { id: 'denver-office', name: 'Denver Office' },
  { id: 'phoenix-office', name: 'Phoenix Office' },
];

const existingOrders = [
  {
    id: 'existing-order-1',
    name: 'Order ORD-2024-1187',
    term: 36,
    bundles: [
      { coreKey: 'vtu', coreName: 'VTU Only', qty: 14, basePrice: 35.00, baseCorePrice: 35.00, msaDiscountPct: 7, promoType: 'Standard', promoName: '' },
      { coreKey: 'vtu-ffc', coreName: 'VTU + Forward Facing Camera', qty: 6, basePrice: 65.00, baseCorePrice: 65.00, msaDiscountPct: 7, promoType: 'Standard', promoName: '' },
      { coreKey: 'vtu-dual', coreName: 'VTU + Dual Camera Subscription', qty: 3, basePrice: 75.00, baseCorePrice: 75.00, msaDiscountPct: 7, promoType: 'Standard', promoName: '' },
    ],
  },
];

const EXISTING_SAMPLE_PROPOSALS = [
  { id: '0524', type: 'Modify', status: 'draft', created: 'May 22, 2025', modified: 'May 22, 2025', owner: 'S. Patel', opp: 'Fleet Solutions', options: [[1, 29.6, null]] },
  { id: '0521', type: 'Renewal', status: 'sent', created: 'May 19, 2025', modified: 'May 21, 2025', owner: 'S. Patel', opp: 'Fleet Renewal', options: [[18, 800, null], [25, 1100, null]] },
  { id: '0519', type: 'Modify', status: 'approval', created: 'May 17, 2025', modified: 'May 20, 2025', owner: 'R. Chen', opp: 'Camera Expansion', options: [[20, 980, null], [28, 1372, null]] },
  { id: '0516', type: 'Rewrap', status: 'contract-review', created: 'May 14, 2025', modified: 'May 18, 2025', owner: 'S. Patel', opp: 'Vehicle Tracking Upgrade', contract: 'MSA-10516', selected: 0, options: [[18, 800, null]] },
  { id: '0512', type: 'Renewal', status: 'awaiting-sig', created: 'May 10, 2025', modified: 'May 16, 2025', owner: 'L. Torres', opp: 'Asset Tracking Renewal', contract: 'MSA-10512', selected: 1, options: [[10, 408, null], [15, 612, null]] },
  { id: '0508', type: 'Modify', status: 'payment', created: 'May 6, 2025', modified: 'May 13, 2025', owner: 'R. Chen', opp: 'Fleet Expansion', contract: 'MSA-10508', selected: 0, options: [[35, 1750, null]] },
  { id: '0504', type: 'Rewrap', status: 'svt', created: 'May 2, 2025', modified: 'May 11, 2025', owner: 'S. Patel', opp: 'EVC Camera Bundle', contract: 'MSA-10504', selected: 0, options: [[75, 4295, null]] },
  { id: '0501', type: 'Renewal', status: 'signed', created: 'Apr 29, 2025', modified: 'May 9, 2025', owner: 'L. Torres', opp: 'Regional Fleet', contract: 'MSA-10501', selected: 0, options: [[42, 2060, null]] },
  { id: '0496', type: 'Cancellation', status: 'dead', created: 'Apr 24, 2025', modified: 'May 7, 2025', owner: 'R. Chen', opp: 'Service Reduction', deadReason: 'Customer chose a different provider', options: [[12, 590, null]] },
];

const DEMO_PROPOSAL_CONTRACT_ACCOUNTS = {
  '0524': 'denver-office', '0521': 'phoenix-office', '0519': 'denver-office',
  '0516': 'phoenix-office', '0512': 'denver-office', '0508': 'phoenix-office',
  '0504': 'denver-office', '0501': 'phoenix-office', '0496': 'denver-office',
};

function getDemoContractAccountName(id) {
  return DEMO_CONTRACT_ACCOUNTS.find(account => account.id === id)?.name || '';
}

function getContractAccountOrders() {
  const source = existingOrders[0];
  return [
    { ...source, id: 'existing-order-denver', name: 'Order ORD-2024-1187', contractAccountId: 'denver-office', bundles: source.bundles.slice(0, 2) },
    { ...source, id: 'existing-order-phoenix', name: 'Order ORD-2024-1192', contractAccountId: 'phoenix-office', bundles: source.bundles.slice(2) },
  ];
}

const MSA_STEP_SCREEN_IDS = ['screen-proposal-selection', 'screen-contract', 'screen-deal-result'];

function getContractCommittedUnits() {
  return existingOrders.reduce((sum, order) => sum + (order.bundles || []).reduce((s, b) => s + (Number(b.qty) || 0), 0), 0);
}

function formatShortDate(isoDate) {
  if (!isoDate) return '';
  const [y, m, d] = String(isoDate).split('-');
  if (!y || !m || !d) return isoDate;
  return `${m}/${d}/${y}`;
}

function getMsaCommitmentStatus(additionalVehicles = 0) {
  const minCommitment = Number(DEMO_MSA.minQuantityCommitment) || 0;
  const baseContractedQty = Number(DEMO_MSA.vehicleCount) || 0;
  const addQty = Math.max(0, Number(additionalVehicles) || 0);
  const contractedQty = baseContractedQty + addQty;
  const remainingToCommitment = Math.max(0, minCommitment - contractedQty);
  const pctRaw = minCommitment > 0 ? (contractedQty / minCommitment) : 1;
  const pctOfCommitment = Math.max(0, Math.min(1, pctRaw));

  return {
    minCommitment,
    contractedQty,
    remainingToCommitment,
    pctOfCommitment,
    msaStartDate: DEMO_MSA.startDate,
    msaEndDate: DEMO_MSA.endDate,
    contractStartDate: DEMO_MSA.contractStartDate,
    contractEndDate: DEMO_MSA.contractEndDate,
    vehicleTrackingPrice: Number(DEMO_MSA.vehicleTrackingPrice) || 0,
    poweredAssetTrackingPrice: Number(DEMO_MSA.poweredAssetTrackingPrice) || 0,
    minimumSpendCommitment: Number(DEMO_MSA.minimumSpendCommitment) || 0,
    rampUpPeriodMonths: Number(DEMO_MSA.rampUpPeriodMonths) || 0,
    termMonths: Number(DEMO_MSA.termMonths) || 0,
    discretionaryDiscountPct: Number(DEMO_MSA.discretionaryDiscountPct) || 0,
  };
}

function getProposalDocMsaSummary(selectedVehicleCount = 0, forPanel = false) {
  // Unified: only a customer (existing MSA) has this box in its documents; new / pilot accounts don't
  // (hook, default = yes). The MSA panel itself asks with forPanel (the composer can show it anywhere).
  if (!forPanel && typeof isExistingMsaAccount === 'function' && !isExistingMsaAccount()) return null;
  const status = getMsaCommitmentStatus(selectedVehicleCount);
  const msaIdDisplay = String(DEMO_MSA.id || '').replace(/^MSA-?/i, '');
  const currentBundles = (Array.isArray(existingOrders) ? existingOrders : []).flatMap(order => order.bundles || []);
  const currentMsaTierUnits = sumMsaTierQty(currentBundles);
  const currentBandTier = getMsaDiscountTier(currentMsaTierUnits);
  const currentBandRange = currentBandTier.max >= 9999 ? `${currentBandTier.min}+` : `${currentBandTier.min}-${currentBandTier.max}`;
  return {
    title: `MSA-${msaIdDisplay}`,
    fields: [
      { label: 'Contract term', value: `${formatShortDate(status.msaStartDate)} - ${formatShortDate(status.msaEndDate)} (${status.termMonths} mo)` },
      { label: 'Ramp-up period', value: `${status.rampUpPeriodMonths} days`, minWidth: 108 },
      { label: `Tier/Term ${currentBandRange}`, value: `${getTierTermDiscountPct(status.termMonths, currentMsaTierUnits)}% (${currentMsaTierUnits})`, minWidth: 110 },
      { label: 'Account Discount', value: `${status.discretionaryDiscountPct}%`, minWidth: 96 },
    ],
  };
}

function renderMsaCommitmentPanel(selectedVehicleCount = 0, menuId = 'msa-commitment-menu', showKebab = true) {
  const status = getMsaCommitmentStatus(selectedVehicleCount);
  const projectedQty = status.contractedQty;
  const msaIdDisplay = String(DEMO_MSA.id || '').replace(/^MSA-?/i, '');
  const currentBundles = (Array.isArray(existingOrders) ? existingOrders : [])
    .flatMap(order => order.bundles || []);
  const currentMsaTierUnits = sumMsaTierQty(currentBundles);
  const currentBandTier = getMsaDiscountTier(currentMsaTierUnits);
  const currentBandRange = currentBandTier.max >= 9999
    ? `${currentBandTier.min}+`
    : `${currentBandTier.min}-${currentBandTier.max}`;
  const contractDateMonths = Math.max(1, Math.ceil(
    (new Date(status.contractEndDate + 'T00:00:00') - new Date(status.contractStartDate + 'T00:00:00')) /
    (1000 * 60 * 60 * 24 * 30.44)
  ));

  const actionsHtml = showKebab ? VC.kebabMenu({
    id: menuId + '-wrap',
    panelId: menuId,
    panelClassName: 'msa-commitment-menu',
    label: 'More MSA actions',
    onToggle: `toggleMsaCommitmentMenu(event, '${menuId}')`,
    items: [
      { label: 'Rewrap/Renewal Contract', onClick: `window.startRenewalRewrapProposal(); document.getElementById('${menuId}')?.classList.add('hidden');` },
      { label: 'Written Notice of Non-Renewal', onClick: `window.openCancelAutoRenewalModal(); document.getElementById('${menuId}')?.classList.add('hidden');` },
      { type: 'divider' },
      { label: 'Cancel contract', onClick: `window.openCancelMcModal(); document.getElementById('${menuId}')?.classList.add('hidden');`, danger: true },
    ],
  }) : '';

  const summary = getProposalDocMsaSummary(selectedVehicleCount, true);
  return VC.accountSummaryPanel({
    headerTitle: summary.title,
    actionsHtml,
    sections: [{ metrics: summary.fields }],
  });
}

function toggleMsaCommitmentMenu(e, id) {
  e.stopPropagation();
  const menu = document.getElementById(id);
  if (!menu) return;
  document.querySelectorAll('.msa-commitment-menu').forEach(otherMenu => {
    if (otherMenu !== menu) setKebabMenuOpen(otherMenu, false);
  });
  setKebabMenuOpen(menu, menu.classList.contains('hidden'));
}

function renderQuotesListMsaCommitmentPanel() {
  const slot = document.getElementById('msa-commitment-list-slot');
  if (!slot) return;
  if (accountStatus === 'inactive') {
    slot.innerHTML = '';
    return;
  }
  // The ⋮ actions (Renewal / Rewrap, Non-renewal, Cancel contract) show only where those transactions exist.
  slot.innerHTML = renderMsaCommitmentPanel(0, 'msa-commitment-menu-list', typeof window.startRenewalRewrapProposal === 'function');
}

function getDraftingMsaAdditionalVehicles() {
  if (!Array.isArray(options) || !options.length) return 0;
  return options.reduce((maxQty, opt) => Math.max(maxQty, totalUnitsForOption(opt)), 0);
}

function renderDraftingMsaCommitmentPanel() {
  const slot = document.getElementById('msa-commitment-drafting-slot');
  if (!slot) return;
  slot.classList.remove('hidden');
  slot.style.display = '';
  if (accountStatus === 'inactive') {
    slot.innerHTML = '';
    return;
  }
  // 2026-10-06 (per Catalina): the MSA kebab (Rewrap/Renewal, Written Notice
  // of Non-Renewal, Cancel contract) only belongs on the Proposal Dashboard.
  // Once inside a proposal (step 1 onwards) the MSA panel is informative only.
  const showKebab = false;
  slot.innerHTML = renderMsaCommitmentPanel(getDraftingMsaAdditionalVehicles(), 'msa-commitment-menu-drafting', showKebab);
}

function renderStepMsaCommitmentPanels() {
  MSA_STEP_SCREEN_IDS.forEach((screenId) => {
    const screenEl = document.getElementById(screenId);
    if (!screenEl) return;
    let slot = screenEl.querySelector(':scope > .msa-commitment-step-slot');
    if (!slot) {
      slot = document.createElement('div');
      slot.className = 'msa-commitment-step-slot';
      screenEl.prepend(slot);
    }
    if (screenEl.classList.contains('hidden') || accountStatus === 'inactive') { slot.innerHTML = ''; return; }
    slot.innerHTML = renderMsaCommitmentPanel(getDraftingMsaAdditionalVehicles(), 'msa-commitment-menu-' + screenId, false);
  });
}

function renderProposalMetaMsaSummary() {
  const rampEl = document.getElementById('header-prop-ramp');
  const discEl = document.getElementById('header-prop-discretionary-discount');
  if (rampEl) rampEl.textContent = proposalData.msaRampUpPeriod ? `${proposalData.msaRampUpPeriod} days` : '--';
  if (discEl) discEl.textContent = `${proposalData.msaDiscretionaryDiscountPct || 0}%`;
}

function vzRefreshMsaCommitmentPanel() {
  renderDraftingMsaCommitmentPanel();
}
