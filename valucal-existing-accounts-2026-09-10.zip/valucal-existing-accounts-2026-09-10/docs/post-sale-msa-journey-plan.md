# Plan de implementación — MSA en el flujo Post-Sale (Upsell/Expansion)

> Generado a partir de la llamada "Post Sale MSA Journey" (Anil Pilaka / Catalina Arango, 2026-08-26).
> Este archivo es un plan por fases con **prompts listos para pegar** en tu agente de código en VS Code (Copilot Chat, Cursor, Claude Code, etc.). Cada fase es independiente y se puede ejecutar y revisar por separado.
>
> **Regla de trabajo (2026-08-26):** de aquí en adelante, todo cambio de código de este proyecto se entrega como un prompt en este documento — no se editan los archivos HTML/JS directamente. Las Fases 1 y 3 (marcadas ✅ abajo) son la única excepción: se implementaron directamente para poder iterar rápido sobre el diseño visual del dashboard de MSA, con aprobación explícita de Catalina para ese caso puntual.

---

## 0. Contexto (para ti y para el agente)

Proyecto: `valucal-existing-accounts` — prototipo estático (HTML + JS vanilla, sin build step) del flujo de ventas/renovación de Verizon Connect.

Archivos relevantes:

- `app/demos/valucal_existing_accounts.html` — el flujo completo (Upsell/Expansion, generación de código/contrato, etc.). ~15,300 líneas, todo en un solo archivo.
- `app/demos/account-setup.html` — pantalla de Account Setup (hoy **no tiene** ningún campo de MSA: términos, precio negociado, compromiso mínimo, etc. — se confirmó por búsqueda directa en el archivo).

Ya existe en `valucal_existing_accounts.html` una funcionalidad relacionada pero distinta (feature "F2 - MSA / Co-term"), que **no** cubre lo que pide Anil:

- `DEMO_MSA` (objeto mock, línea ~7297): `{ id, startDate, endDate, termMonths, vehicleCount }`
- `renderMsaContextBar()` (línea ~7652): pinta una barra con "Add-on to MSA-XXXX · MSA expires <fecha> · N months remaining", usada para lógica de co-term/auto-extend.

Esto es la base sobre la que vamos a extender — no hay que rehacerlo, sino agregarle los campos de compromiso/precio que pide Anil.

**Regla general para todos los prompts:** es un prototipo de demo, no un backend real. Todo dato nuevo (precio negociado, cantidad mínima comprometida, número de orden, fechas de suscripción, etc.) se **mockea** con lógica determinística (como ya hace `vzMockVehicleDetails` con un hash del serial) — no se conecta a ningún API real.

---

## 1. Requerimientos extraídos de la llamada

> Actualizado 2026-08-26 con el transcript completo de la llamada "Post Sale MSA Journey" (Anil Pilaka, Madhuri R Muluka, Catalina Arango). Los puntos 1-5 son los que ya veníamos trabajando; se afinaron con detalle real de la conversación. Los puntos 6-9 son hallazgos nuevos del transcript que no estaban documentados antes.

1. **Columnas nuevas en la tabla de vehículos del flujo de Upsell/Expansion**: agregar `Order` (Anil: es el "provider order" / "service order" que viene del ERP — no está 100% seguro de cuál de los dos términos usan, por eso quedó como "Order" genérico), `Start Date` y `End Date` (fechas de la suscripción). Los tres valores son **a nivel de vehículo completo**, no por sub-ítem. ✅ Implementado (Fase 2).
2. **Dashboard de resumen de MSA** (para Upsell/Expansion, post-venta), de solo lectura salvo por un botón Edit: Anil confirmó explícitamente que esta info (compromiso mínimo, precio negociado, término, ramp-up) debe mostrarse en el flujo de upsell/expansion porque "these are the MSA details associated to that customer account... we are expected to be pulling from cal layer at this point and showcase it so that it's available for the rep to know beforehand" — es decir, es informativo para el rep, viene (en el mundo real) del "CAL layer".
   - Ubicación: en la pantalla de **Drafting**, justo después del breadcrumb. ✅ Implementado (Fase 3.2).
   - Restricción de espacio, dicha por Catalina en la llamada: "there are a lot of fields that we need to include and this screen is huge... let's say that the agent has this size of a screen" — de ahí la necesidad de consolidar campos redundantes (ver punto 7) y mantener el diseño compacto (Fases 3.3-3.5).
3. **Modal de confirmación al crear el contrato** (flujo de **venta nueva/inicial**, no post-sale): al hacer clic en "Create Contract" (lo que hoy dispara `confirmAndLockDeal()` en nuestro prototipo de post-sale, pero el requerimiento original es para el flujo de creación de contrato inicial), mostrar antes de crear el contrato un resumen de solo lectura de los atributos del MSA. Detalles nuevos del transcript:
   - Es **solo para la venta inicial** ("this is only for initial sale... this is during the contract initial because this [is] when they confirm and create the MSA"). No aplica al flujo de upsell/expansion (ese usa el dashboard del punto 2, no este modal).
   - Es de solo lectura a propósito ("for now I marked I told her to put it as read only here") — Madhuri preguntó si se puede modificar y Anil confirmó que por ahora no, que si se necesita editar se agrega después.
   - Este modal es un posible **punto de disparo** para la integración con el "CAL layer" (enviar la info del MSA), pero Anil aclaró que es una **decisión de negocio pendiente** cuál de estos 3 momentos dispara el envío real: (a) este popup de confirmación, (b) el flujo de DocuSign/firma del cliente, o (c) la confirmación de venta ("sale confirm"). Para el prototipo no hay que implementar el envío real, solo dejar claro en el modal que es el punto de confirmación.
   - Aclaración de negocio sobre las cantidades: cuando se cuenta la cantidad comprometida/contratada, **solo se cuentan los items "core"** (VTU, powered/non-powered trackers) — **no se incluyen features/add-ons**. Cita textual de Anil: "we don't send any of the quantities of features we only send the total core units". Esto ya es consistente con cómo se calcula `vehicleCount`/`contractedQty` en el mock actual (no incluye features), pero queda documentado como regla de negocio explícita.
4. **Record Type = "MSA"** en el registro de contrato que se crea desde ese flujo (campo nuevo, mockeado, mostrado en el documento de contrato generado). Sin cambios respecto a lo ya documentado.
5. **No** implementar edición de esos valores dentro del modal de confirmación todavía — confirmado explícitamente por Anil en la llamada. Por ahora es solo lectura + confirmar.
6. **🆕 Terminología "units" en vez de "vehicles"**: Anil pidió explícitamente usar la palabra **"units"** en los campos de MSA (minimum commitment, cantidad contratada, etc.) en vez de "vehicles", porque hay un defecto ya reportado en Valcal por la inconsistencia entre "vehicles" y "units" en distintas pantallas. Cita: "maybe call it units here... there was a defect that was raised in val[cal] as well with the vehicles and units." **No implementado todavía** — ver Fase 3.6 propuesta abajo, pendiente de que confirmes alcance.
7. **🆕 Consolidar los 3 campos redundantes del dashboard de MSA** (Minimum commitment, Projected quantity, Status): esto fue pedido explícitamente por Anil y Madhuri en la llamada — "those are all projecting the same information for me... try to see if you can combine it into one and say... 45 current quantity and 60 committed quantity, something like that" (Anil), confirmado por Madhuri ("just make it into one, you'll get more real estate there") y por Catalina ("we are repeating the same information"). ✅ Ya está en el plan como **Fase 3.5** (con el mismo criterio: un solo campo tipo contador, formato "45/60").
8. **🆕 Posible separación de "asset trackers" vs "vehicle tracking" como dos columnas/campos separados** en vez de un solo conteo genérico de unidades: Anil lo planteó como algo a considerar ("there might be separate attributes as well at the core level... separating your asset trackers versus your vehicle [tracker]s... maybe we might want to split that into two separate columns"), pero **no quedó como decisión cerrada** — quedó como "maybe". Ver Decisión pendiente en la sección 2.
9. **🆕 Fechas adicionales para el dashboard de MSA** — este fue el punto más largo y menos resuelto del transcript. Catalina notó que falta la fecha de inicio del MSA. La conversación evolucionó así:
   - Anil: quiere mantener tanto **MSA Start Date** como **MSA End Date** visibles (no solo el Term/duración), porque "people won't be calculating what my 36 [months]... started".
   - Madhuri preguntó también por **Contract Start Date**, **Contract End Date** y **Service Start Date** / **Service End Date** — distintos de las fechas del MSA en sí.
   - Anil explicó que el **Service Start Date** probablemente se calcule *después* del período de ramp-up, en base a la fecha de compromiso original — pero aclaró que esa es **una regla de negocio que todavía no está definida** ("that's a business rule something that needs to be flushed out").
   - Al cierre, Madhuri resumió pidiendo **las 4 fechas**: Service start date, Service end date, Contract start date, Contract end date — para ubicarlas junto al MSA ID, junto con Term, Ramp-up y Negotiated price.
   - **No quedó 100% claro en la llamada** si el MSA Start/End Date (que Anil pidió antes) es lo mismo que el Contract Start/End Date que pidió Madhuri al final, o si son 4 fechas distintas + el Term ya existente. Por eso este punto queda en la sección 2 como decisión pendiente antes de escribir el prompt de implementación — para no repetir el patrón de "hacer y deshacer" que ya pasó con el diseño visual del dashboard.

Nota de prioridad (dicha explícitamente por Anil): este trabajo de MSA tiene **precedencia** sobre otras mejoras planeadas de Valu Cal (p. ej. profundizar el flujo de creación de contrato) — puede que esas otras cosas se pausen mientras se resuelve esto.

**Fuera de alcance de esta ronda (confirmado explícitamente en la llamada):** el flujo de **Cancelación** no se tocó y no se va a tocar todavía — Anil: "it's all completely w[orked] out... we just added it on up for now, just quick[ly]." A futuro, las reglas de negocio de cancelación (parcial vs. total) deberían venir del CAL layer ("VCF rules everything should come up at this point from cal layer"), pero eso es un proyecto aparte, no parte de este plan.

---

## 2. Decisiones pendientes (no bloquean empezar, pero revisar con Anil/Madi)

- [x] ~~Ubicación final del "dashboard" de resumen MSA~~ → **Resuelto**: en Drafting, justo después del breadcrumb. Ver Fase 3.2.
- [x] ~~Nombre final de la tercera columna de la tabla del Upsell~~ → **Resuelto**: "Order" (representa el "provider order"/"service order" del ERP, según el transcript).
- [ ] Si el "Record Type: MSA" debe ser visible en el documento del contrato (Section 1) o solo un atributo interno del registro.
- [x] ~~Terminología "units" vs "vehicles"~~ → **Resuelto para el dashboard (2026-08-26)**: Catalina decidió hacer primero el rename en el dashboard de MSA (Fase 3.5, ya actualizada) y evaluar después si impacta a Account Setup y/o a la tabla de vehículos del Upsell — eso queda pendiente como un paso aparte, no se toca todavía.
- [x] ~~¿Separar "asset trackers" de "vehicle tracking" en dos campos/columnas?~~ → **Resuelto (2026-08-26)**: Catalina confirmó que sí, se separan. Alcance acotado para el dashboard de Drafting: **solo el precio** se separa en "Vehicle Tracking" / "Powered Asset Tracking" (Fase 3.6) — la cantidad (compromiso mínimo/contratada) se queda combinada en el contador único de la Fase 3.5, y el dashboard sigue sin botón Edit. Queda abierto si esto también debe aplicar a la tabla de vehículos del Upsell (no se tocó en esta fase).
- [x] ~~Qué fechas exactas mostrar en el dashboard de MSA~~ → **Resuelto por decisión de Catalina (2026-08-26), sin esperar confirmación de Anil/Madhuri**: "MSA Start/End" = "Service Start/End" (mismo par), "Contract Start/End" es un par aparte → 2 pares de fechas en total. Ver mapeo completo en la sección 2.1 y el prompt en la Fase 3.7. Si la lectura resulta incorrecta al validarla después, se ajusta con otro prompt puntual.

---

## 2.1. Mapeo de fechas mencionadas en la llamada (para preguntar mejor antes de implementar)

Catalina pidió mapear esto con calma antes de volver a preguntarle a Anil/Madhuri, en vez de adivinar. Así quedó el mapeo de cada mención de fecha en el transcript:

| # | Fecha mencionada | Quién la pidió y cita textual | ¿Existe hoy en el código? |
|---|---|---|---|
| 1 | **MSA Start Date** | Catalina notó que faltaba ("I am seeing that here we don't have the start date"); Madhuri: "we still need the MSA start date"; Anil: "I would keep actually both the dates [start y end]" | Sí, como dato — `DEMO_MSA.startDate` ('2024-03-15') en el mock viejo del dashboard. En Account Setup existe `msaTermStart` (campo nuevo, vacío). |
| 2 | **MSA End Date** | Anil insistió en mantenerla junto al start, aunque Madhuri al principio dijo "we don't need the MSA end date" (porque ya está el Term) — Anil la anuló: "people won't be calculating what my 36 [months]... started" | Sí, como dato — `DEMO_MSA.endDate` ('2027-07-15') en el mock viejo. En Account Setup NO existe todavía (`msaTermStart` no tiene su par "End"). |
| 3 | **Contract Start Date** | Madhuri: "don't we need the contract start date as well?" — lo preguntó como algo aparte de las fechas del MSA | No existe en ningún lado todavía. |
| 4 | **Contract End Date** | Madhuri, mismo contexto que la anterior | No existe en ningún lado todavía. |
| 5 | **Service Start Date** | Madhuri preguntó por ella; Anil explicó que se calcularía después del ramp-up period, pero aclaró que es "a business rule [that] needs to be flushed out" — no está definida | No existe en ningún lado todavía. Su regla de cálculo tampoco está definida. |
| 6 | **Service End Date** | Madhuri, mismo contexto que la anterior | No existe en ningún lado todavía. |

**La ambigüedad concreta:** al cerrar el tema, Madhuri resumió "we should have all those dates... all four", y Anil las listó como "Service start date, service end, contract start date and then contract end" — es decir, **su resumen final solo menciona 4 fechas y no vuelve a nombrar "MSA start/end" por separado**. Había dos lecturas posibles sobre cuál par se fusiona con cuál:

- **Lectura A:** "Contract Start/End Date" = "MSA Start/End Date" (mismo concepto, dos nombres) → 2 pares (MSA/Contract) + (Service).
- **Lectura C (la que eligió Catalina, 2026-08-26):** "MSA Start/End Date" = "Service Start/End Date" (mismo concepto — el servicio corre durante la vigencia del MSA) → 2 pares: **(MSA/Service Start–End)** + **(Contract Start–End, aparte)**. Bajo esta lectura, "Contract" queda como el registro de Salesforce que se crea en cada evento de creación de contrato (podría tener fechas propias por transacción, distintas de la vigencia del MSA), mientras que "MSA/Service" es la vigencia general del acuerdo.

En ambas lecturas el total termina siendo **2 pares de fechas (4 fechas)** — la diferencia es solo cuál par se llama "MSA/Service" y cuál "Contract". Con la Lectura C de Catalina, la regla de negocio del ramp-up que mencionó Anil ("Service Start Date se calcula después del ramp-up") quedaría sin aplicar tal cual, porque ahora "Service Start" = "MSA Start" (la fecha de inicio del acuerdo, no una fecha derivada después del ramp-up) — esto es una simplificación consciente para el prototipo, no necesariamente lo que Anil tenía en mente literalmente.

**Pregunta sugerida para llevarles, ya simplificada a partir de la lectura de Catalina (para confirmar sin ambigüedad):**
> "We're treating 'Service Start/End Date' as the same as the MSA's own Start/End Date (i.e. the service runs for the life of the MSA), and 'Contract Start/End Date' as a separate pair tied to the Contract record created at each contract-creation event. Does that match what you had in mind, or did you mean Service Start Date should be calculated separately (e.g. after the ramp-up period)?"

**Decisión de diseño ya tomada por Catalina (aplica sin importar la lectura final), para ahorrar espacio en el dashboard:** en vez de un campo "Start Date" y otro "End Date" por separado (2 mini-secciones por par), cada par de fechas va en **una sola mini-sección** con las dos fechas separadas por un guion, ej. `03/15/2024 - 07/15/2027`. Con `flex-wrap` esto debería acomodarse en dos renglones cuando no quepa todo en uno, igual que ya pasa con el resto de las mini-secciones del dashboard (Fase 3.4).

**Decisión final de Catalina (2026-08-26): implementar ya con la Lectura C, sin esperar confirmación de Anil/Madhuri.** Si luego resulta que la lectura no era correcta, se ajusta con otro prompt puntual (mismo patrón que ya usamos varias veces en este plan). Ver Fase 3.7 abajo.

---

## 3. Fases de implementación

### Fase 1 — Modelo de datos mock del MSA (compromiso y precio) ✅ Completado

**Estado:** ejecutado por Catalina. `DEMO_MSA` en `valucal_existing_accounts.html` ya tiene `negotiatedPricePerVehicle: 32.50`, `minQuantityCommitment: 60`, `rampUpPeriodMonths: 6`, y existe `getMsaCommitmentStatus(additionalVehicles)` (~línea 7320).

**Objetivo:** extender el mock `DEMO_MSA` para que tenga toda la info que las fases 2-4 van a necesitar, en un solo lugar.

**Prompt para pegar en el agente:**

```
Trabaja en app/demos/valucal_existing_accounts.html.

Busca el objeto `DEMO_MSA` (cerca de la línea 7297, justo antes de
`getMsaMonthsRemaining`). Hoy tiene esta forma:

const DEMO_MSA = {
  id: 'MSA-2024-0391',
  startDate: '2024-03-15',
  endDate: '2027-07-15',
  termMonths: 36,
  vehicleCount: 45,
};

Extiéndelo (sin romper los usos actuales de id/startDate/endDate/termMonths/
vehicleCount) agregando estos campos mock:

- negotiatedPricePerVehicle: number  → precio mensual negociado por vehículo (ej. 32.50)
- minQuantityCommitment: number      → cantidad mínima de vehículos que el cliente
                                        se comprometió a contratar bajo este MSA
- rampUpPeriodMonths: number         → meses de período de ramp-up acordado

Luego crea una función helper `getMsaCommitmentStatus()` que devuelva un objeto:

{
  minCommitment: number,       // DEMO_MSA.minQuantityCommitment
  contractedQty: number,       // cantidad de vehículos actualmente activos bajo
                                // el MSA (usa el mismo criterio que ya usa
                                // vzGenerateSubscriptions()/DEMO_MSA.vehicleCount
                                // para "vehículos actuales")
  remainingToCommitment: number,  // max(0, minCommitment - contractedQty)
  pctOfCommitment: number,        // contractedQty / minCommitment, entre 0 y 1
  negotiatedPricePerVehicle: number,
  rampUpPeriodMonths: number,
  termMonths: number,
}

Colócala inmediatamente después de `isMsaAutoExtend()`. No cambies el
comportamiento de renderMsaContextBar() en esta fase — solo agrega el modelo
de datos. Verifica que el archivo siga siendo HTML/JS válido (no rompas
comas ni llaves) y que no haya declaraciones duplicadas de DEMO_MSA.
```

---

### Fase 2 — Columnas "Order / Start Date / End Date" en la tabla de vehículos del Upsell ✅ Completado

**Objetivo:** que la tabla de vehículos que se ve al hacer un upsell/expansion muestre, por vehículo, el número de orden y las fechas de inicio/fin de la suscripción que lo cubre — igual que se ve hoy en la referencia HTML que compartió el otro equipo.

**Contexto para el agente:** la tabla vive en `vzRenderUpsellTable()` (~línea 13462 en adelante, dos vistas: "By Vehicle" y "By Subscription"), y los datos vienen de `vzGenerateSubscriptions()` (~línea 13353), que hoy genera `serial`, `vin`, `subEnd`, etc. por cada sub-ítem.

**Prompt para pegar en el agente:**

```
Trabaja en app/demos/valucal_existing_accounts.html.

1) En `vzGenerateSubscriptions()` (~línea 13353), donde se arma cada
   objeto `subs.push({...})`, agrega dos campos mock nuevos, determinísticos
   a partir de `subId` (igual de estilo que el resto de la función, sin usar
   Math.random para que sea estable al re-renderizar):

   - orderNumber: string   → algo como `ORD-${String(subId).padStart(6,'0')}`
   - subStart: string      → fecha ISO, calculada como
                              `subEnd` menos `termMonths` meses del MSA
                              (usa DEMO_MSA.termMonths o el termMonths que
                              corresponda; si no está disponible, usa 24 meses
                              antes de subEnd como fallback)

   Estos dos campos deben ser el MISMO valor para todas las subscripciones
   que pertenecen al mismo vehículo (mismo grupo de `linkedCoreSerial`/core),
   porque representan la orden que cubre al vehículo completo, no a cada
   sub-ítem por separado. Reutiliza el valor calculado para el "core" en
   sus add-ons vinculados.

2) En `vzRenderUpsellTable()`, vista "By Vehicle" (el bloque que arma
   `thead.innerHTML` con las columnas Vehicle/Asset, Name, License Plate,
   alrededor de la línea 13564), agrega tres columnas nuevas al final:
   "Order", "Start Date", "End Date". Deben quedar en la fila de vehículo
   (`vehicleRow`), no en las filas de sub-ítem (`subRows`) — ahí deja esas
   celdas vacías o con colspan, ya que el dato es a nivel de vehículo.
   Usa `s.orderNumber`, `s.subStart` y `s.subEnd` (ya existente) del
   objeto de la subscripción "core" de esa fila. Formatea las fechas con
   el mismo helper que ya use el resto del archivo para fechas legibles
   (busca cómo se formatea `endDisplay` en renderMsaContextBar y reutiliza
   ese patrón, o Intl.DateTimeFormat si no hay uno reusable).

3) Repite el mismo agregado de columnas en la vista "By Subscription"
   (el otro bloque de `thead.innerHTML`/`tbody.innerHTML` un poco más
   abajo en la misma función, alrededor de la línea 13620-13660), manteniendo
   el mismo criterio (valor a nivel de vehículo).

No cambies el ancho de columnas existentes de forma que rompa el layout;
usa el mismo patrón de <th>/<td> con estilos inline que ya usa el resto de
la tabla. Al terminar, abre el archivo en el navegador y confirma visualmente
que las tres columnas aparecen y muestran datos coherentes (fechas con
sentido, Order con formato ORD-XXXXXX) en ambas vistas (By Vehicle / By
Subscription) del flujo de Upsell.
```

---

### Fase 2.1 — Bug: falta scroll horizontal y los checkboxes se ven aplastados 🆕 Pendiente (2026-08-26)

**Reportado por Catalina** al probar la Fase 2 en su navegador: la tabla de vehículos del Upsell ahora tiene más columnas de las que caben (Order/Start Date/End Date se suman a Vehicle/Name/Plate), y (a) no hay forma de hacer scroll horizontal para verlas todas, y (b) los checkboxes de selección se ven "aplastados" — no siguen el Design System.

**Causa raíz identificada:** el contenedor que envuelve la tabla usa `overflow:hidden` en vez de scroll, y la tabla no tiene un `min-width`. Eso hace que el navegador comprima todas las columnas (incluida la del checkbox, que tiene `width:44px` fijo) para que "quepan" a la fuerza en el ancho disponible, en lugar de dejar la tabla en su ancho natural y scrollear. Es el mismo problema para ambos síntomas — un solo fix los arregla a los dos.

Hay **dos lugares** con este mismo wrapper envolviendo `<table class="gc-sub-table" id="gc-upsell-table">` (mismo problema en ambos, porque los dos usan `vzRenderUpsellTable()` para pintar las filas):
- Dentro de `renderVZUpsellForm()`, vista "By Vehicle" del Step 1 (modo `upsellMode === 'vehicles'`).
- Dentro de `vzGoUpsellStep2()`, cuando `upsellMode !== 'vehicles'` (flujo "selecting features" → Step 2 "Select Vehicles").

**Prompt para pegar en el agente:**

```
Trabaja en app/demos/valucal_existing_accounts.html.

Hay dos bugs visuales relacionados en la tabla de vehículos del flujo de
Upsell/Expansion (la que tiene columnas Vehicle/Asset, Name, License Plate,
Order, Start Date, End Date): (1) no hay scroll horizontal para ver las
columnas que no caben, y (2) el checkbox de selección de cada fila se ve
aplastado/deformado. Ambos vienen de la misma causa: el contenedor de la
tabla usa `overflow:hidden` y la tabla no tiene ancho mínimo, así que el
navegador comprime todas las columnas (incluida la del checkbox) para que
quepan, en vez de dejar que la tabla scrollee.

Busca las dos instancias de este patrón en el archivo (deberían ser
idénticas o casi idénticas):

  <div style="border:1px solid var(--gray-200); border-radius:8px; overflow:hidden;">
    <table class="gc-sub-table" style="width:100%;" id="gc-upsell-table">

Una está dentro de `renderVZUpsellForm()` (vista "By Vehicle" del Step 1) y
la otra dentro de `vzGoUpsellStep2()` (rama donde `upsellMode !== 'vehicles'`,
la vista "Select Vehicles" del Step 2 cuando se empezó por features). NO
toques el wrapper del Cancel table (`gc-cancel-table`, si existe algo
parecido) — el bug es solo en esta tabla de vehículos del upsell.

En AMBOS lugares:

1) Cambia el `overflow:hidden` del div contenedor por `overflow-x:auto` (deja
   el resto de estilos del div igual: borde, border-radius).
2) Cambia `style="width:100%;"` de la tabla por algo como
   `style="width:100%; min-width:900px;"` (ajusta el valor de min-width si
   hace falta, pero que sea suficiente para que las 9 columnas —checkbox,
   Vehicle/Asset, Name, License Plate, +espacio, Order, Start Date, End
   Date— no se compriman por debajo de un ancho legible; puedes calcularlo
   sumando los anchos que ya se usan en los <th>/<td> de esa tabla).
3) No cambies el ancho fijo `width:44px` del `<th>`/`<td>` del checkbox —
   una vez la tabla tenga min-width y el wrapper scrollee, esa columna
   debería volver a verse normal sin tocarla.

Verifica en el navegador, con la ventana angosta o el zoom alto (para forzar
que la tabla no quepa): que aparece una barra de scroll horizontal dentro
del wrapper de la tabla (no que la página entera scrollee), que las 6
columnas de datos se ven completas y legibles, y que el checkbox de cada
fila se ve como el resto de checkboxes del Design System (redondo/cuadrado
según corresponda, sin comprimirse ni deformarse). Prueba tanto la vista
"By Vehicle" (Step 1, modo vehicles) como la vista "Select Vehicles" (Step 2,
modo features) para confirmar que el fix aplicó en los dos lugares.
```

---

### Fase 3 — Panel de resumen de MSA — ⚠️ Reemplazada por la Fase 3.2 (ver abajo)

Esta fase se implementó primero dentro del modal de Upsell (Step 1). Catalina probó esa ubicación y pidió moverla: **el dashboard de MSA ya no debe vivir en el modal de Upsell** — debe vivir en la pantalla de Drafting, justo después del breadcrumb. El detalle de qué había en el modal queda documentado abajo por contexto histórico; el trabajo pendiente real es la Fase 3.2.

<details>
<summary>Detalle histórico (ya no aplica — ver Fase 3.2)</summary>

**Estado (histórico):** Catalina ejecutó primero una versión "barra horizontal" (una sola línea con separadores `|`), la probó y no le convenció visualmente. Se rediseñó como card tipo dashboard, directamente en `valucal_existing_accounts.html`, con aprobación explícita para esa iteración puntual (ver nota de flujo de trabajo al inicio del documento). Se verificó con pruebas automatizadas en navegador (Playwright headless) que el panel renderizaba, se actualizaba en vivo, y el botón Edit abría la URL correcta — pero vivía dentro del modal de Upsell, que es justo lo que se está retirando en la Fase 3.2.

**Ubicación que tenía (ya no aplica):** dentro de `renderVZUpsellForm()` → Step 1 (`#gc-tx-upsell-step1`), como primer elemento antes del selector de modo.

**Diseño del dashboard** (función `renderMsaCommitmentPanel()`, ~línea 13467 de `valucal_existing_accounts.html` — esta función SÍ se reutiliza en la Fase 3.2, solo cambia dónde se inserta su resultado):
- Fila superior: título "MSA Commitment" + chip con el MSA ID + botón **Edit** a la derecha.
- Grid de métricas debajo: Term, Ramp-up period, Negotiated price, Minimum commitment, Projected quantity.
- Barra de progreso + mensaje ("N more vehicles needed..." / "Minimum commitment met") al final.
- El botón Edit llama a `openMsaAccountSetup()`, que hace `window.open('account-setup.html?section=msa', '_blank')` — ver Fase 3.1.

</details>

---

### Fase 3.1 — Módulo MSA nuevo en Account Setup (para que el botón Edit tenga destino) ✅ Completado

**Por qué se agregó:** Catalina pidió que el botón Edit del dashboard "te lleve al account setup directamente al módulo de MSA" — pero `account-setup.html` no tenía ningún módulo de MSA (se había confirmado esto desde el relevamiento inicial). Se creó desde cero, con aprobación explícita para esta iteración puntual.

**Qué se implementó en `app/demos/account-setup.html`:**
- `state.msa = { id, termMonths, rampUpPeriodMonths, negotiatedPricePerVehicle, minQuantityCommitment }` — mock independiente del `DEMO_MSA` de `valucal_existing_accounts.html` (son dos documentos HTML separados, sin estado compartido en tiempo real; se usaron los mismos valores iniciales solo por consistencia visual entre pantallas).
- Nueva sección `#section-msa` ("MSA — Master Subscription Agreement"), agregada a `SECTIONS` y a `overviewSections`, con el mismo patrón visual de field-row/edit-row que ya usa el resto de la página (como el campo "Cost center" de Owner).
- 4 campos editables (Contract term, Ramp-up period, Negotiated price per vehicle, Minimum quantity commitment) vía `startEditMsa/saveEditMsa/cancelEditMsa`, más el MSA ID como dato de solo lectura ("From CRM").
- `init()` ahora lee `?section=` de la URL (`new URLSearchParams(window.location.search).get('section')`) y navega directo a esa sección si es válida — así `account-setup.html?section=msa` aterriza directo en el módulo de MSA.

**Hallazgo colateral (no se corrigió, fuera de alcance):** la función `renderOverview()` que arma la grilla de tarjetas "Account info / Billing / Fleet / Owner / Compliance" con botones "Go" es código muerto — el `#overview-grid` que necesita no existe en ningún lado del HTML, así que esa función nunca se ejecuta hoy en la página real. Si en algún momento se retoma esa grilla, la entrada de "MSA" ya quedó agregada en `overviewSections` para que aparezca junto a las demás.

---

### Fase 3.2 — Mover el dashboard del modal de Upsell a Drafting, después del breadcrumb ✅ Completado (verificado 2026-08-26) — el rediseño visual quedó pendiente, ver Fase 3.3

**Verificación (revisé el archivo real, no solo lo que pedía el prompt):** la parte de UBICACIÓN sí se hizo, y bien:
- Se quitó por completo del modal de Upsell — `#gc-tx-upsell-step1` ya no tiene ningún `msa-commitment-panel`.
- Se agregó `<div id="msa-commitment-drafting-slot" style="margin-bottom:16px;"></div>` justo después del `</nav>` del breadcrumb en `#screen-drafting` (línea ~4880).
- Se creó `renderDraftingMsaCommitmentPanel()` (~línea 13612) que llena ese slot, y `getDraftingMsaAdditionalVehicles()`, que calcula el total de unidades a través de todas las opciones de la propuesta actual — un plus respecto a lo pedido: el dashboard en Drafting ya refleja "cuánto llevo armado en este draft", no solo el estado ya contratado.
- Está bien conectado: se llama al entrar a Drafting y cada vez que cambian las opciones (varios call sites, incluyendo uno condicionado a `screen === 'drafting'`).

**Lo que NO se hizo:** el rediseño visual a una sola línea compacta (sin fondo, sin mayúsculas sostenidas, bold solo en valores, separadores). `renderMsaCommitmentPanel()` sigue exactamente igual que antes — el grid de 5 tarjetas con fondo gris (`.gc-tx-impact` / `background: var(--stone)`) y etiquetas en mayúsculas. Por eso Catalina lo sigue viendo saturado: el prompt pedía dos cosas a la vez y solo se ejecutó la mitad (mover de lugar), no el rediseño. Para evitar que se vuelva a saltar, el rediseño queda ahora como su propio prompt independiente — ver Fase 3.3.

**Contexto para el agente:**
---

### Fase 3.3 — Rediseñar el dashboard a una sola línea compacta ✅ Completado (2026-08-26) — generó scroll horizontal no deseado, superseded por Fase 3.4

**Por qué existe esta fase por separado:** el prompt de la Fase 3.2 pedía mover el dashboard Y rediseñarlo en un solo prompt; el agente en VS Code solo hizo la mitad (el traslado) y se saltó el rediseño. Para que no se vuelva a saltar, este prompt hace UNA sola cosa: cambiar el diseño visual de `renderMsaCommitmentPanel()`, sin tocar dónde vive ni cómo se llama.

**Estado real verificado del código (2026-08-26, no es lo que se pidió — es lo que hay):**
- La función a rediseñar es `renderMsaCommitmentPanel(selectedVehicleCount = 0)` (~línea 13467 de `valucal_existing_accounts.html`). Hoy devuelve una card: fila de título con ícono + "MSA Commitment" + chip del MSA ID + botón Edit, luego un `<div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(130px, 1fr));">` con 5 tarjetas (Term, Ramp-up period, Negotiated price, Minimum commitment, Projected quantity) cada una con su label en `text-transform:uppercase`, y al final una barra de progreso + mensaje en una fila aparte.
- Todo eso vive dentro de `<div class="gc-tx-impact" style="...">` — esa clase trae `background: var(--stone)` (el fondo gris que Catalina no quiere). `.gc-tx-impact` es compartida con el bloque "Pricing Preview" del flujo de Cancel (~línea 14111) — no tocar esa clase en el CSS global, solo dejar de usarla en este panel.
- Quien llama a esta función hoy es `renderDraftingMsaCommitmentPanel()` (~línea 13612), que la pinta dentro de `<div id="msa-commitment-drafting-slot">` (ya ubicado correctamente después del breadcrumb de Drafting — eso NO se toca en esta fase).
- El botón Edit (`onclick="openMsaAccountSetup()"`) y el ícono `handshake` se mantienen.

**Se ejecutó y quedó exactamente como se pidió** — una sola línea, sin fondo, sin mayúsculas, valores en negrita, separadores `|`, y el mensaje de estado como texto ("45/60 (75%) - 15 more vehicles needed", sin barra visual). El problema: cuando no cabe, esa línea hace scroll horizontal propio (`overflow-x:auto` + `white-space:nowrap`), y Catalina probándolo en su pantalla real no quiere ese scroll — prefiere que la información se acomode en más de una fila dentro de un contenedor con borde, no que scrollee.

---

### Fase 3.4 — Contenedor con borde, título arriba, y cada dato como su propia mini-sección (label arriba, valor abajo) — sin scroll horizontal ✅ Completado (verificado 2026-08-26) — se ejecutó bien en cuanto a layout, pero la verificación encontró un bug de datos (MSA ID incorrecto), corregido en la Fase 3.5

**Pedido de Catalina (después de ver la Fase 3.3 en su pantalla):**
- Que el dashboard esté en un **contenedor con borde** (no solo el `border-bottom` que dejó la Fase 3.3).
- Un **título "MSA Commitment" arriba**, separado del contenido.
- Debajo, cada dato (Term, Ramp-up, Negotiated price, Minimum commitment, Projected quantity, estado) como su propia mini-sección: **la etiqueta arriba, el valor abajo** (en vez de "Etiqueta valor" en una misma línea como quedó en la 3.3).
- **Nada de scroll horizontal** — si no caben todos los datos en una fila, que pasen a una segunda fila (wrap), no que aparezca una barra de scroll.
- Sigue sin barra de progreso visual — el contador de texto que ya quedó de la Fase 3.3 ("45/60 (75%)") está bien, eso no cambia.
- El MSA ID puede mostrarse tal cual (el código, sin nada elaborado) — el chip simple que ya existe está bien.

**En una frase:** es el mismo contenido de la Fase 3.3 (sin fondo gris pesado, sin mayúsculas, sin barra de progreso), pero organizado como el diseño original de la Fase 3 (mini-tarjetas con label arriba / valor abajo, dentro de un contenedor con borde) en vez de una sola línea con scroll — la diferencia es que esta vez las mini-tarjetas deben poder pasar a una segunda fila (`flex-wrap`) en vez de forzar un ancho mínimo que dispare el scroll.

**Prompt para pegar en el agente:**

```
Trabaja en app/demos/valucal_existing_accounts.html.

Objetivo: modificar SOLO el contenido visual de `renderMsaCommitmentPanel(selectedVehicleCount = 0)`
(~línea 13467). No cambies su firma ni quién la llama
(`renderDraftingMsaCommitmentPanel()`), no cambies el slot donde se pinta
(`#msa-commitment-drafting-slot`).

Hoy la función devuelve una sola línea horizontal con scroll propio
(`overflow-x:auto; white-space:nowrap`) uniendo todos los datos con
separadores "|". Reemplázala por este layout:

1. Contenedor exterior CON BORDE (no solo un border-bottom): por ejemplo
   `border:1px solid var(--gray-200); border-radius:8px; padding:12px 16px;
   margin-bottom:16px;`. Sin color de fondo (no uses `.gc-tx-impact`, sigue
   siendo compartida con "Pricing Preview" del flujo de Cancel — no la
   edites, simplemente no la uses aquí).

2. Fila de título, arriba del todo, separada del resto: ícono handshake +
   "MSA Commitment" + el chip del MSA ID (`DEMO_MSA.id`, el mismo chip
   simple que ya existe) a la izquierda, y el botón Edit
   (`onclick="openMsaAccountSetup()"`) a la derecha — este botón se
   mantiene igual que en la Fase 3.3. Un margin-bottom chico para separar
   esta fila del contenido de abajo (ej. `margin-bottom:12px;`), y opcional
   un `border-bottom:1px solid var(--gray-100); padding-bottom:10px;` si
   ayuda a diferenciar visualmente el título del contenido.

3. Debajo del título, un contenedor flex CON WRAP (`display:flex;
   flex-wrap:wrap; gap:12px 24px;`) — nada de `overflow-x:auto` ni
   `white-space:nowrap` aquí; si no caben todos los datos en una fila,
   deben pasar a una segunda fila dentro del mismo contenedor, sin scroll.

4. Cada dato es su propia mini-sección, con la etiqueta ARRIBA (peso
   normal, sin mayúsculas sostenidas, tamaño chico, ej. `font-size:11px;
   color:var(--gray-500);`) y el valor ABAJO en negrita (ej.
   `font-size:13px; font-weight:700;`). Ejemplo de estructura por dato:

     <div>
       <div style="font-size:11px; color:var(--gray-500); margin-bottom:2px;">Term</div>
       <div style="font-size:13px; font-weight:700;">36 months</div>
     </div>

   Datos a incluir, en este orden: Term, Ramp-up period, Negotiated price
   (con `formatMoney`), Minimum commitment, Projected quantity, y un
   último dato de estado con label "Status" (o similar) y como valor el
   contador de texto que ya se usa hoy (ej. "45/60 (75%) - 15 more
   vehicles needed" / "45/60 (75%) - Minimum commitment met"), en negrita
   y en color `var(--orange)` si falta o `var(--green)` si ya se cumplió
   el mínimo. NO agregues ninguna barra de progreso visual — el contador
   de texto es suficiente, eso ya quedó bien en la Fase 3.3.

Verifica en el navegador, achicando el ancho de la ventana o el panel
contenedor: el dashboard se ve como un bloque con borde, con "MSA
Commitment" arriba, y las mini-secciones (label arriba / valor abajo) se
reorganizan en una segunda fila cuando no caben — en ningún momento debe
aparecer una barra de scroll horizontal dentro del dashboard. Confirma
también que el botón Edit sigue funcionando y que los números se siguen
actualizando correctamente al crear/editar opciones en Drafting.
```

**Nota (2026-08-26):** esta subsección tenía duplicado por error el prompt de la Fase 3.3 (diseño de una sola línea con scroll). Se quitó de aquí porque no es lo que se ejecutó ni lo que queremos — lo que realmente corrió y quedó en el código es el prompt de arriba (contenedor con borde + mini-secciones + wrap). Ver Fase 3.5 para lo que sigue.

---

### Fase 3.5 — Consolidar campos redundantes + corregir bug del MSA ID 🆕 Pendiente (2026-08-26)

**Pedido de Catalina (después de ver la Fase 3.4 en su pantalla, con screenshot):**
> "para los campos de MSA que estamos mostrando necesito homologar estos si te pones a ver básicamente estamos dando la misma información en 3 campos..lo del contador esta bueno"

Los 3 campos que se solapan son **Minimum commitment** (60 vehicles), **Projected quantity** (45 vehicles) y **Status** (45/60) — el campo Status ya contiene la misma información que los otros dos combinados. Catalina confirmó que el formato de contador ("45/60") le gusta, así que ese es el que se conserva; los otros dos se eliminan como campos separados.

**1 problema que encontré verificando el código actual (Catalina no lo había visto todavía, aprovechamos este mismo prompt para corregirlo):**
- El MSA ID se está mostrando como `'20204.0391'` (un valor fijo, mal escrito) en vez de usar `DEMO_MSA.id` (que es `'MSA-2024-0391'`). Es un typo que quedó de la Fase 3.4.

**Nota:** el botón Edit que tenía el dashboard en versiones anteriores fue removido intencionalmente por Catalina — no es un bug, no se repone en esta fase.

**Estado real verificado del código (2026-08-26):**

```javascript
function renderMsaCommitmentPanel(selectedVehicleCount = 0) {
  const status = getMsaCommitmentStatus(selectedVehicleCount);
  const needsMore = status.remainingToCommitment > 0;
  const projectedQty = status.contractedQty;
  const msaIdDisplay = '20204.0391';
  const statusTextCompact = `${projectedQty}/${status.minCommitment}`;

  const metric = (label, value, valueStyle = '', isFirst = false) => `
        <div style="min-width:128px; padding-left:${isFirst ? '0' : '16px'}; border-left:${isFirst ? 'none' : '1px solid var(--gray-200)'};">
          <div style="font-size:11px; color:var(--gray-500); margin-bottom:2px;">${label}</div>
          <div style="font-size:13px; font-weight:700; ${valueStyle}">${value}</div>
        </div>`;

  return `
    <div style="margin-bottom:16px; background:var(--white); border:1px solid var(--gray-200); border-radius:8px; padding:12px 16px;">
      <div style="display:flex; align-items:center; gap:12px; margin-bottom:6px; padding-bottom:6px;">
        <div style="display:flex; align-items:center; gap:8px; min-width:0;">
          <span style="font-size:14px; font-weight:700;">MSA Commitment</span>
        </div>
      </div>

      <div style="display:flex; flex-wrap:wrap; gap:12px 24px; align-items:flex-start;">
        ${metric('ID', `${msaIdDisplay}`, '', true)}
        ${metric('Term', `${status.termMonths} months`)}
        ${metric('Ramp-up period', `${status.rampUpPeriodMonths} months`)}
        ${metric('Negotiated price', `${formatMoney(status.negotiatedPricePerVehicle)}/vehicle/mo`)}
        ${metric('Minimum commitment', `${status.minCommitment} vehicles`)}
        ${metric('Projected quantity', `${projectedQty} vehicles`)}
        ${metric('Status', statusTextCompact, `color:${needsMore ? 'var(--orange)' : 'var(--green)'}; white-space:nowrap;`)}
      </div>
    </div>`;
}
```

**En una frase:** mismo contenedor y mismas mini-secciones de la Fase 3.4, pero con un solo campo de cantidad/estado en vez de tres, y el MSA ID correcto (sin tocar el botón Edit, que fue removido a propósito).

**Prompt para pegar en el agente:**

```
Trabaja en app/demos/valucal_existing_accounts.html.

Objetivo: modificar SOLO el contenido de la función
`renderMsaCommitmentPanel(selectedVehicleCount = 0)`. No cambies su firma,
no cambies quién la llama (`renderDraftingMsaCommitmentPanel()`), no
cambies el slot donde se pinta (`#msa-commitment-drafting-slot`), y no
cambies el contenedor con borde ni el estilo de las mini-secciones (label
arriba / valor abajo) que ya quedaron bien en el rediseño anterior. No
agregues ningún botón Edit — se removió intencionalmente y debe seguir
sin estar. Este prompt hace 3 cosas puntuales dentro de esa misma función:

1. CONSOLIDAR CAMPOS REDUNDANTES. Hoy la función pinta tres mini-secciones
   que muestran la misma información repetida: "Minimum commitment" (ej.
   "60 vehicles"), "Projected quantity" (ej. "45 vehicles"), y "Status"
   (ej. "45/60", en naranja o verde). Elimina las mini-secciones de
   "Minimum commitment" y "Projected quantity" como campos separados, y
   deja SOLO UNA mini-sección que combine esa información usando el mismo
   formato de contador que ya existe (`${projectedQty}/${status.minCommitment}`),
   con el mismo color condicional (naranja si `needsMore`, verde si no).
   Cambia el label de esa mini-sección de "Status" a algo más descriptivo
   como "Commitment" o "Quantity" (tu criterio, que deje claro que el
   número es "cantidad proyectada / mínimo comprometido"), y el valor
   debe incluir la palabra **"units"** al final (NO "vehicles" — ya se
   decidió usar "units" en todo el dashboard de MSA, ver punto 3 abajo),
   ej. "45/60 units".

3. RENOMBRAR "vehicles" → "units" en todo lo que quede visible en este
   panel. Ya no debería quedar ninguna mención de la palabra "vehicles"
   como texto visible al usuario dentro de `renderMsaCommitmentPanel()`
   (los nombres internos de variables/parámetros como
   `selectedVehicleCount` o `additionalVehicles` NO se tocan, esto es solo
   sobre texto que ve el usuario en pantalla). Alcance de este cambio:
   SOLO este dashboard de MSA en Drafting — no toques la tabla de
   vehículos del Upsell ni ninguna otra pantalla, eso se evalúa aparte más
   adelante.

2. CORREGIR EL MSA ID. La variable `msaIdDisplay` está hardcodeada como
   `'20204.0391'` (un valor incorrecto). Cámbiala para que use el valor
   real: `const msaIdDisplay = DEMO_MSA.id;` (el objeto `DEMO_MSA` ya
   existe en el archivo con el campo `id`, que hoy vale `'MSA-2024-0391'`).

No cambies nada más: no agregues ningún botón Edit (se removió
intencionalmente), ni cambies el orden de Term / Ramp-up period /
Negotiated price, ni los estilos del contenedor exterior, ni el
`flex-wrap` de la fila de mini-secciones.

Verifica en el navegador (recarga con `?route=configure-bundle` o
navegando normal a Drafting):
- El dashboard ahora muestra: ID (con el valor correcto "MSA-2024-0391"),
  Term, Ramp-up period, Negotiated price, y UN solo campo de cantidad tipo
  "45/60 units" en naranja o verde según corresponda — ya no aparecen
  "Minimum commitment" y "Projected quantity" como campos separados, y ya
  no aparece la palabra "vehicles" en ningún texto de este dashboard.
- Sigue sin haber ningún botón Edit en el dashboard.
- Los números se siguen actualizando correctamente al crear/editar
  opciones en Drafting.
```

---

### Fase 3.6 — Separar el precio negociado en Vehicle Tracking vs Powered Asset Tracking 🆕 Pendiente (2026-08-26)

**Contexto y decisión de Catalina:** en la llamada, Anil pidió considerar separar "asset trackers" de "vehicle tracking" como conceptos distintos (no un solo conteo genérico). Catalina confirmó que **al final se optó por separarlos**, y precisó el alcance para esta fase:
- Se separa el **precio negociado** en dos: "Vehicle Tracking" y "Powered Asset Tracking" (mismos nombres que ya existen en Account Setup).
- La **cantidad** (compromiso mínimo / cantidad contratada) **NO se separa** — se queda como el contador único "45/60" que dejó la Fase 3.5.
- El dashboard de Drafting **sigue sin botón Edit** — no se reintroduce ningún link hacia Account Setup.

**Por qué estos nombres exactos:** al verificar el código encontré que `account-setup.html` ya tiene una card "Master Service Agreement" con los campos `msaVehicleTrackingPrice` ("Vehicle Tracking", $/unidad/mes) y `msaPoweredAssetTrackingPrice` ("Powered Asset Tracking", $/unidad/mes) como dos campos de precio ya separados (aunque hoy están vacíos ahí, es un formulario en blanco). Para que el dashboard de Drafting hable el mismo idioma que Account Setup, usamos exactamente esos dos nombres.

**Estado real verificado del código (2026-08-26) — solo 3 referencias en todo el archivo, todas dentro de la feature de MSA, así que es seguro renombrar sin romper nada más:**

```javascript
// 1. DEMO_MSA (~línea 7347)
const DEMO_MSA = {
  id: 'MSA-2024-0391',
  startDate: '2024-03-15',
  endDate: '2027-07-15',
  termMonths: 36,
  vehicleCount: 45,
  negotiatedPricePerVehicle: 32.50,   // ← a reemplazar
  minQuantityCommitment: 60,
  rampUpPeriodMonths: 6,
};

// 2. getMsaCommitmentStatus() (~línea 7370)
function getMsaCommitmentStatus(additionalVehicles = 0) {
  // ...
  return {
    // ...
    negotiatedPricePerVehicle: Number(DEMO_MSA.negotiatedPricePerVehicle) || 0,  // ← a reemplazar
    rampUpPeriodMonths: Number(DEMO_MSA.rampUpPeriodMonths) || 0,
    termMonths: Number(DEMO_MSA.termMonths) || 0,
  };
}

// 3. renderMsaCommitmentPanel() (~línea 13618, dentro del `<div style="display:flex; flex-wrap:wrap;...">`)
${metric('Negotiated price', `${formatMoney(status.negotiatedPricePerVehicle)}/vehicle/mo`)}   // ← a reemplazar por 2 metrics
```

**Prompt para pegar en el agente:**

```
Trabaja en app/demos/valucal_existing_accounts.html.

Objetivo: separar el precio negociado del MSA en dos valores independientes
— "Vehicle Tracking" y "Powered Asset Tracking" — en vez de un solo
"Negotiated price" combinado. La cantidad (compromiso mínimo / cantidad
contratada) NO cambia, se queda tal cual está. No agregues ningún botón
Edit ni link hacia account-setup.html — el dashboard sigue siendo de solo
lectura sin ese botón.

Haz estos 3 cambios puntuales:

1. En el objeto `DEMO_MSA` (busca ese nombre exacto, ~línea 7347),
   reemplaza el campo `negotiatedPricePerVehicle: 32.50,` por estos dos
   campos:
     vehicleTrackingPrice: 32.50,
     poweredAssetTrackingPrice: 18.00,
   (mantén el mismo valor 32.50 que ya existía para Vehicle Tracking, y usa
   18.00 como mock razonable para Powered Asset Tracking — mismo criterio
   de mock determinístico que ya usa el resto del archivo, no hay que
   conectar nada real).

2. En `getMsaCommitmentStatus()` (busca ese nombre exacto, ~línea 7370),
   reemplaza la línea `negotiatedPricePerVehicle: Number(DEMO_MSA.negotiatedPricePerVehicle) || 0,`
   dentro del objeto que retorna la función por estas dos líneas:
     vehicleTrackingPrice: Number(DEMO_MSA.vehicleTrackingPrice) || 0,
     poweredAssetTrackingPrice: Number(DEMO_MSA.poweredAssetTrackingPrice) || 0,

3. En `renderMsaCommitmentPanel()` (busca ese nombre exacto, ~línea 13618),
   busca la línea que arma el metric de "Negotiated price":
     ${metric('Negotiated price', `${formatMoney(status.negotiatedPricePerVehicle)}/vehicle/mo`)}
   y reemplázala por estas dos líneas (mismo array de mini-secciones,
   mismo orden relativo — donde estaba "Negotiated price" ahora van estas
   dos, una después de la otra):
     ${metric('Vehicle Tracking', `${formatMoney(status.vehicleTrackingPrice)}/unit/mo`)}
     ${metric('Powered Asset Tracking', `${formatMoney(status.poweredAssetTrackingPrice)}/unit/mo`)}
   (nota: aquí usamos "/unit/mo" en vez de "/vehicle/mo" — es literalmente
   el mismo texto "per unit per month" que ya usa Account Setup para estos
   dos campos de precio. La palabra "vehicles" del contador de cantidad ya
   se corrige aparte, en la Fase 3.5 — con las Fases 3.5 y 3.6 ya no debería
   quedar ninguna mención de "vehicles" como texto visible en este
   dashboard).

No cambies nada más: ni el contenedor con borde, ni el `flex-wrap`, ni el
contador de cantidad consolidado, ni el orden de Term/Ramp-up respecto a
estos campos de precio (Vehicle Tracking y Powered Asset Tracking quedan
donde estaba "Negotiated price").

Verifica en el navegador (recarga con `?route=configure-bundle` o
navegando normal a Drafting): el dashboard ahora muestra dos
mini-secciones de precio separadas — "Vehicle Tracking" ($32.50/unit/mo) y
"Powered Asset Tracking" ($18.00/unit/mo) — en vez de una sola "Negotiated
price". El resto del dashboard (ID, Term, Ramp-up period, el contador de
cantidad) no cambia. Sigue sin haber ningún botón Edit.
```

**Nota (queda pendiente, NO parte de este prompt):** la separación de la CANTIDAD (compromiso mínimo / cantidad contratada) en Vehicle Tracking vs Powered Asset Tracking queda fuera de esta fase — ver sección 2, decisiones pendientes. (El rename de "vehicles" → "units" del contador de cantidad ya no es un pendiente aparte: se hace dentro de la Fase 3.5.)

---

### Fase 3.7 — Agregar las fechas al dashboard (MSA/Service + Contract, como rangos) 🆕 Pendiente (2026-08-26)

**Contexto:** ver el mapeo completo en la sección 2.1. Catalina decidió implementar ya, sin esperar confirmación de Anil/Madhuri, con esta lectura: **"MSA Start/End Date" y "Service Start/End Date" son el mismo par** (el servicio corre durante toda la vigencia del MSA), y **"Contract Start/End Date" es un par aparte**, ligado al registro de Contract que se crea en cada evento de creación de contrato. Si esta lectura resulta no ser la correcta al validarla más adelante, se ajusta con otro prompt puntual — mismo patrón que ya usamos varias veces en este plan.

**Decisión de formato (para ahorrar espacio):** cada par de fechas va en UNA sola mini-sección con las dos fechas separadas por un guion, ej. `03/15/2024 - 07/15/2027` — no dos mini-secciones separadas de "Start"/"End".

**Estado real verificado del código (2026-08-26):**
- `DEMO_MSA` (~línea 7347) ya tiene `startDate: '2024-03-15'` y `endDate: '2027-07-15'` — hoy estos dos campos NO se usan en ningún otro lado del archivo salvo dentro de la propia definición (verificado con una búsqueda de `DEMO_MSA.startDate` / `DEMO_MSA.endDate` — cero resultados fuera de la definición), así que es seguro reutilizarlos como el par "MSA / Service" sin romper nada.
- No existe ningún campo de fecha de Contract todavía — hay que agregarlo como mock nuevo.
- No existe ninguna función para formatear fechas tipo `MM/DD/YYYY` en el archivo (se buscó `formatDate`/`fmtDate`/`vzFormatDate`, no aparece nada) — hay que agregar una chiquita, seguro el mismo patrón que `formatMoney()` (~línea 7445).

**Prompt para pegar en el agente:**

```
Trabaja en app/demos/valucal_existing_accounts.html.

Objetivo: agregar 2 mini-secciones de fechas al dashboard de MSA
(`renderMsaCommitmentPanel()`) — una para "MSA / Service" y otra para
"Contract" — cada una mostrando un rango "fecha - fecha" en un solo campo,
no fechas de inicio/fin separadas.

Haz estos 4 cambios:

1. Agrega una función pequeña de formato de fecha, cerca de `formatMoney()`
   (~línea 7445), que convierta 'YYYY-MM-DD' a 'MM/DD/YYYY':

     function formatShortDate(isoDate) {
       if (!isoDate) return '';
       const [y, m, d] = String(isoDate).split('-');
       if (!y || !m || !d) return isoDate;
       return `${m}/${d}/${y}`;
     }

2. En el objeto `DEMO_MSA` (~línea 7347), agrega 2 campos nuevos de mock
   para las fechas del Contract (los campos `startDate`/`endDate` que ya
   existen ahí se usan para el par "MSA / Service", no hace falta
   agregarlos de nuevo):

     contractStartDate: '2026-06-01',
     contractEndDate: '2027-07-15',

3. En `getMsaCommitmentStatus()` (~línea 7370), agrega estos 4 campos al
   objeto que retorna la función (junto a los demás `return { ... }`):

     msaStartDate: DEMO_MSA.startDate,
     msaEndDate: DEMO_MSA.endDate,
     contractStartDate: DEMO_MSA.contractStartDate,
     contractEndDate: DEMO_MSA.contractEndDate,

4. En `renderMsaCommitmentPanel()` (~línea 13618), agrega 2 mini-secciones
   nuevas usando el mismo helper `metric(...)` que ya arma las demás
   mini-secciones — colócalas después de "Ramp-up period" y antes de los
   campos de precio (Vehicle Tracking / Powered Asset Tracking):

     ${metric('MSA / Service', `${formatShortDate(status.msaStartDate)} - ${formatShortDate(status.msaEndDate)}`)}
     ${metric('Contract', `${formatShortDate(status.contractStartDate)} - ${formatShortDate(status.contractEndDate)}`)}

No cambies nada más: ni el contenedor con borde, ni el `flex-wrap`, ni el
resto de las mini-secciones existentes (ID, Term, Ramp-up period, los
campos de precio, el contador de cantidad).

Verifica en el navegador (recarga con `?route=configure-bundle` o
navegando normal a Drafting): el dashboard ahora muestra 2 mini-secciones
nuevas — "MSA / Service" con "03/15/2024 - 07/15/2027", y "Contract" con
"06/01/2026 - 07/15/2027" — cada una en un solo renglón de texto (fecha -
fecha), sin quedar cortadas. Si no caben todas las mini-secciones en una
fila, deben pasar a una segunda fila (el mismo `flex-wrap` de siempre), sin
scroll horizontal. El resto del dashboard no cambia.
```

**Nota de verificación (2026-08-26):** las Fases 3.5, 3.6 y 3.7 ya se corrieron y el dashboard quedó tal como se pidió (con pequeñas variaciones de nombre hechas por el agente en VS Code, todas dentro de lo esperado: el label quedó "Service date"/"Contract date" en vez de "MSA / Service"/"Contract", el ID se muestra como "MSA-0391", y el campo de cantidad se llama "Commitment" con sufijo "units"). Base de código verificada antes de escribir las Fases 3.8 y 3.9 de abajo.

---

### Fase 3.8 — Agregar "Minimum spend commitment" al dashboard de Drafting 🆕 Pendiente (2026-08-26)

**Contexto:** un colega de Catalina (fuera de la llamada original con Anil) pidió, a raíz de una revisión aparte, quitar las menciones de ETF/ECF ("Early Termination/Cancellation Fee") y agregar en su lugar un **"Minimum Spend Commitment"** — un piso de gasto mensual en dólares que el cliente debe alcanzar, sin importar la mezcla real de unidades (a diferencia de "Minimum quantity commitment", que es un piso de CANTIDAD, no de dinero). Por ahora Catalina solo pidió **agregar** este campo nuevo al dashboard y a Account Setup — la remoción de ETF/ECF (que solo existe en el flujo de Cancelación, verificado por búsqueda en todo el proyecto — cero menciones de "ETF", 5 menciones de "ECF" solo en Cancelación) queda como un pedido aparte, todavía no se toca en esta fase.

**Estado real verificado del código (2026-08-26) — el dashboard ya incorpora las Fases 3.5/3.6/3.7:**

```javascript
// DEMO_MSA actual:
const DEMO_MSA = {
  id: 'MSA-2024-0391',
  startDate: '2024-03-15',
  endDate: '2027-07-15',
  contractStartDate: '2026-06-01',
  contractEndDate: '2027-07-15',
  termMonths: 36,
  vehicleCount: 45,
  vehicleTrackingPrice: 32.50,
  poweredAssetTrackingPrice: 18.00,
  minQuantityCommitment: 60,
  rampUpPeriodMonths: 6,
};

// getMsaCommitmentStatus() ya retorna minCommitment, contractedQty, vehicleTrackingPrice,
// poweredAssetTrackingPrice, msaStartDate/EndDate, contractStartDate/EndDate, rampUpPeriodMonths, termMonths.

// renderMsaCommitmentPanel() ya pinta 7 mini-secciones: Service date, Term, Ramp-up period,
// Contract date, Vehicle Tracking, Powered Asset Tracking, Commitment (ej. "45/60 units").
```

**Prompt para pegar en el agente:**

```
Trabaja en app/demos/valucal_existing_accounts.html.

Objetivo: agregar UNA mini-sección nueva al dashboard de MSA —
"Minimum spend commitment" — un piso de gasto MENSUAL en dólares,
independiente del piso de cantidad ("Commitment", en unidades) que ya
existe. No quites ni cambies ninguna mini-sección existente.

Haz estos 3 cambios:

1. En el objeto `DEMO_MSA` (busca ese nombre exacto), agrega un campo
   mock nuevo, junto a `minQuantityCommitment: 60,`:

     minimumSpendCommitment: 1950.00,

2. En `getMsaCommitmentStatus()` (busca ese nombre exacto), agrega este
   campo al objeto que retorna la función:

     minimumSpendCommitment: Number(DEMO_MSA.minimumSpendCommitment) || 0,

3. En `renderMsaCommitmentPanel()` (busca ese nombre exacto), agrega una
   mini-sección nueva usando el mismo helper `metric(...)` que arma las
   demás, colócala inmediatamente después de la mini-sección "Commitment"
   (la de cantidad, "45/60 units"):

     ${metric('Minimum spend commitment', `${formatMoney(status.minimumSpendCommitment)}<span style="font-size:12px; color:var(--black);">/mo</span>`)}

No cambies nada más: ni el contenedor con borde, ni el `flex-wrap`, ni las
demás mini-secciones (Service date, Term, Ramp-up period, Contract date,
Vehicle Tracking, Powered Asset Tracking, Commitment).

Verifica en el navegador (recarga con `?route=configure-bundle` o
navegando normal a Drafting): el dashboard ahora muestra una mini-sección
nueva "Minimum spend commitment" con el valor "$1,950.00/mo", ubicada
justo después de "Commitment". El resto del dashboard no cambia.
```

---

### Fase 3.9 — Agregar "Minimum spend commitment" a Account Setup 🆕 Pendiente (2026-08-26)

**Contexto:** mismo pedido que la Fase 3.8, pero del lado de Account Setup — agregar el campo editable ahí también, siguiendo el mismo patrón que ya usan los demás campos de la card "Master Service Agreement".

**Estado real verificado del código (2026-08-26):**
- La card "Master Service Agreement" vive en `account-setup.html`, dentro de la sección "Negotiated price and commitment". El último campo de esa sub-sección es `msaMinimumQuantityCommitment` (~línea 649), justo antes de un `<div class="divider"></div>` que separa esta sub-sección de "Term".
- El patrón de cada campo son 4 piezas que hay que actualizar juntas: (a) el bloque HTML `field-row`/`edit-row` con su `id="row-<campo>"` / `id="edit-<campo>"`, (b) `state.accountInfo.<campo>` (~línea 1042, ya con valores mock reales cargados), (c) `fieldLabels.<campo>` (~línea 1265, el label legible), (d) `displayValues.<campo>` (~línea 1286, cómo se formatea en modo lectura), y (e) el array `msaFields` (~línea 1830) que se usa para pre-poblar los valores y calcular el badge "N items pending" — hoy son 7 campos con el badge "7 items pending".

**Prompt para pegar en el agente:**

```
Trabaja en app/demos/account-setup.html.

Objetivo: agregar un campo editable nuevo — "Minimum spend commitment" —
a la card "Master Service Agreement", dentro de la sub-sección
"Negotiated price and commitment", justo después del campo existente
"Minimum quantity commitment" y antes del <div class="divider"></div>
que sigue. Usa exactamente el mismo patrón HTML de field-row/edit-row que
ya usan los demás campos de esa card (busca el bloque de
`id="row-msaMinimumQuantityCommitment"` como referencia exacta de
estructura).

Haz estos 5 cambios, todos con el nuevo campo `msaMinimumSpendCommitment`:

1. HTML: agrega un bloque `<div class="field-row" id="row-msaMinimumSpendCommitment">`
   y su correspondiente `<div class="field-row hidden" id="edit-msaMinimumSpendCommitment">`,
   copiando la estructura exacta del bloque de "Minimum quantity commitment"
   que está justo arriba, pero:
   - Label: "Minimum spend commitment"
   - Hint: "The dollar floor billed monthly, regardless of the actual mix of SKUs."
   - El input debe ser `type="number" min="0" step="50" placeholder="e.g. 1950.00"`
     (en vez de `step="1"`, porque esto es un valor en dólares, no una
     cantidad de unidades)
   - Los botones Save/Cancel deben llamar `saveEdit('msaMinimumSpendCommitment')`
     y `cancelEdit('msaMinimumSpendCommitment')`

2. En `state.accountInfo` (busca ese objeto), agrega junto a
   `msaMinimumQuantityCommitment: '60',`:

     msaMinimumSpendCommitment: '1950.00',

3. En `fieldLabels` (busca ese objeto exacto), agrega junto a
   `msaMinimumQuantityCommitment: 'Minimum quantity commitment',`:

     msaMinimumSpendCommitment: 'Minimum spend commitment',

4. En `displayValues` (busca ese objeto exacto), agrega junto a
   `msaMinimumQuantityCommitment: v => v ? \`${v} units\` : '--',`:

     msaMinimumSpendCommitment: v => v ? `$${Number(v).toFixed(2)}/mo` : '--',

5. En el array `msaFields` (busca esa variable exacta, ~línea 1830),
   agrega `'msaMinimumSpendCommitment'` a la lista — esto hace que el
   campo se pre-popule al cargar la página y que cuente para el badge
   "N items pending" de la card (pasará de "7 items pending" a "8 items
   pending" si el campo llega vacío, o sigue en "Complete" si ya tiene
   valor).

No cambies ningún otro campo de la card ni el resto de la página.

Verifica en el navegador (recarga account-setup.html, o
account-setup.html?section=msa): la card "Master Service Agreement"
ahora muestra un campo nuevo "Minimum spend commitment" con el valor
"$1,950.00/mo", ubicado justo después de "Minimum quantity commitment" y
antes de la sección "Term". El botón "Edit →" abre el input numérico
correctamente, y Save/Cancel funcionan igual que en los demás campos.
```

---

### Fase 4 — Modal de confirmación de MSA antes de crear el contrato + Record Type "MSA"

**Objetivo:** antes de que se cree el contrato (hoy: botón "Confirm & lock deal" dentro del modal `#confirm-selection-overlay`, función `confirmAndLockDeal()`), mostrar los atributos del MSA en solo lectura para que el usuario confirme, y marcar el contrato resultante con Record Type = "MSA".

**Contexto para el agente:**
- Modal actual: `<div class="overlay" id="confirm-selection-overlay">` (línea ~6152), título "Confirm selection", botón "Confirm & lock deal" → `confirmAndLockDeal()` (línea ~11187) → `closeConfirmModal()` + `navigateToContractReviewFromSelection()` → `enterContractScreen(opt)` (línea ~11197) → `renderContractDoc(opt)` (línea ~11657, genera el documento con "Section 1 — Parties", "Section 2 — Solution & Pricing", "Section 3 — Term & Commitment", etc.)
- Este modal se abre automáticamente desde `openConfirmSelectionModal()` (línea ~11172) tras guardar/validar la cuenta (ver línea ~7269).

**Prompt para pegar en el agente:**

```
Trabaja en app/demos/valucal_existing_accounts.html.

Objetivo: agregar, dentro del modal existente con id
"confirm-selection-overlay" (el que hoy solo dice "This will lock the
quoting session and initiate the contract generation process." y tiene
el botón "Confirm & lock deal" que llama a confirmAndLockDeal()), un
bloque de solo lectura con los atributos del MSA, ANTES del botón de
confirmar.

1) En el HTML del modal (busca `id="confirm-selection-body"`, línea
   ~6156), después del texto actual, agrega un contenedor
   `<div id="confirm-msa-summary"></div>`.

2) Crea una función `renderConfirmMsaSummary()` que devuelva HTML de
   solo lectura (sin inputs) mostrando, usando `getMsaCommitmentStatus()`
   de la Fase 1:
   - Término del contrato (termMonths)
   - Precio negociado por vehículo
   - Cantidad mínima comprometida
   - Período de ramp-up
   - Un texto fijo tipo "These MSA terms are read-only at this step —
     changes are made in Account Setup." (para dejar explícito, igual
     que se acordó en la llamada, que en esta fase NO se puede editar
     acá, solo confirmar)

3) En `openConfirmSelectionModal()` (línea ~11172), justo antes de
   mostrar el overlay, setea
   `document.getElementById('confirm-msa-summary').innerHTML = renderConfirmMsaSummary();`

4) Introduce una variable/estado nuevo, por ejemplo
   `let pendingContractRecordType = 'MSA';` cerca de donde está
   `let selectedOpt = null;` (línea ~11195), y en `confirmAndLockDeal()`
   (línea ~11187) guarda ese valor en el objeto que use `renderContractDoc`
   (por ejemplo `selectedOpt.recordType = pendingContractRecordType;` o
   en `proposalData`, lo que sea consistente con cómo ya viaja `selectedOpt`
   hacia `renderContractDoc`).

5) En `renderContractDoc(opt)` (línea ~11657), dentro de "Section 1 —
   Parties" (el `ds-doc-grid` que hoy muestra Customer / Provider /
   Authorized Signatory / Account Representative), agrega un quinto
   campo:
   - Label: "Record Type"
   - Valor: el `recordType` que llega en `opt` (o 'MSA' si no viene nada,
     como fallback para no romper otros flujos que llamen a
     renderContractDoc sin este campo)

No cambies el copy del botón "Confirm & lock deal" en esta fase (eso lo
decide negocio más adelante) y no agregues ningún input editable en este
modal — es explícitamente de solo lectura + confirmar, según lo acordado
en la llamada. Verifica en el navegador el flujo completo: seleccionar
vehículos → guardar/validar cuenta → se abre el modal de confirmación →
se ve el resumen de MSA → clic en "Confirm & lock deal" → se abre la
pantalla de contrato y el documento generado muestra "Record Type: MSA".
```

---

### Fase 5 (backlog — NO implementar todavía)

Explícitamente pospuesto en la llamada: permitir editar los valores del MSA desde el modal de confirmación de la Fase 4. Anil fue claro en que por ahora es "solo para hablar" (talking points) y que la edición se definirá en una discusión de requerimientos de negocio posterior. Dejar como backlog, no como parte de este sprint.

---

## 4. QA / verificación final (prompt de cierre)

Una vez ejecutadas las Fases 1-4, correr esto para verificar que no se rompió nada:

```
Trabaja en app/demos/valucal_existing_accounts.html.

Abre el archivo en un navegador (o revísalo estáticamente) y verifica:

1. El flujo de Upsell/Expansion sigue funcionando de punta a punta:
   seleccionar vehículos → elegir features → ver preview → guardar.
2. La tabla de vehículos del upsell muestra correctamente las columnas
   Order / Start Date / End Date en ambas vistas (By Vehicle y By
   Subscription), con datos legibles (no "undefined", no "NaN", no
   "Invalid Date").
3. El dashboard de MSA commitment aparece en Drafting justo después del
   breadcrumb (siempre visible, sin abrir ningún modal), con los números
   correctos, y YA NO aparece dentro del modal de Upsell/Expansion.
3b. La tabla de vehículos del Upsell (con las columnas Order/Start Date/
   End Date) tiene scroll horizontal cuando no caben todas las columnas, y
   los checkboxes de selección se ven normales (sin aplastarse), tanto en
   la vista "By Vehicle" como en "Select Vehicles".
4. El modal de confirmación antes de crear el contrato muestra el
   resumen de MSA y no tiene ningún campo editable.
5. El documento de contrato generado (Section 1 — Parties) muestra
   "Record Type: MSA".
6. No aparecen errores en la consola del navegador (Console) al recorrer
   todo el flujo.
7. No se rompió ningún flujo existente que no esté relacionado con MSA
   (por ejemplo Cancel, Account Validation, Signature flow) — dales una
   pasada rápida.

Reporta cualquier inconsistencia encontrada en una lista corta antes de
dar el trabajo por terminado.
```

---

## 5. Entregables a compartir (pedido explícito de Anil)

Anil pidió compartir **tres versiones** del HTML con él y con Madi:

1. La versión original de Valu Cal (antes de estos cambios).
2. La versión actual del flujo de upsell (la que ya existía al momento de la llamada).
3. La nueva versión con los cambios de MSA de este plan (Fases 1-4).

Sugerencia: antes de empezar, guarda una copia de `valucal_existing_accounts.html` (por ejemplo `valucal_existing_accounts.pre-msa.html`) para tener a mano la versión "antes" sin tener que revertir git.

---

## 6. Reestructuración de archivos — `valucal_existing_accounts.html` pasa a ser el `index.html` de la raíz (2026-09-07)

**Pedido de Catalina:** que `app/demos/valucal_existing_accounts.html` quede en la raíz del proyecto y sea el `index.html` (para que abrir la carpeta cargue directo esa pantalla). Se decidió **reemplazar por completo** el `index.html` actual (el launcher con el link "Back to Prototype Viewer" y el script de presenter/`FLOW_STATES`) — esa funcionalidad se pierde a propósito.

**Importante:** mover el archivo de carpeta cambia cuántos `../` hacen falta para llegar a los assets compartidos, a `app/assets/`, y a `account-setup.html`. Hay que ajustar esas rutas en el mismo movimiento o quedan rotas.

**Prompt para pegar en el agente:**

```
Trabaja en la raíz del proyecto (donde están index.html, app/, etc.).

Objetivo: mover app/demos/valucal_existing_accounts.html a la raíz del
proyecto como el nuevo index.html (reemplazando por completo el
index.html actual), y corregir las rutas relativas que cambian de
profundidad al moverse.

Pasos:

1. Reemplaza el contenido de ./index.html con el contenido completo de
   app/demos/valucal_existing_accounts.html (el archivo viejo de
   app/demos/valucal_existing_accounts.html debe quedar borrado después,
   ya no debe existir ahí — el único lugar donde debe quedar el HTML es
   en la raíz como index.html).

2. Dentro de ese nuevo index.html (el que antes era
   valucal_existing_accounts.html), corrige estas rutas exactas —
   son las únicas que cambian de profundidad porque el archivo subió
   dos niveles (de app/demos/ a la raíz):

   a) Cambia (aparece 1 vez):
      href="../../../../assets/ds/design-system.css"
      por:
      href="../../assets/ds/design-system.css"

   b) Cambia (aparecen 3 veces, una por cada fuente):
      url('../../../../assets/ds/fonts/VerizonNHGDS-Light.ttf')
      url('../../../../assets/ds/fonts/VerizonNHGeDS-Regular.ttf')
      url('../../../../assets/ds/fonts/VerizonNHGeDS-Bold.ttf')
      por (mismo nombre de archivo, solo cambian los "../"):
      url('../../assets/ds/fonts/VerizonNHGDS-Light.ttf')
      url('../../assets/ds/fonts/VerizonNHGeDS-Regular.ttf')
      url('../../assets/ds/fonts/VerizonNHGeDS-Bold.ttf')

   c) Cambia (aparece 1 vez, es el iframe embed de Account Setup):
      const nextSrc = 'account-setup.html' + sectionParam;
      por:
      const nextSrc = 'app/demos/account-setup.html' + sectionParam;

   d) Cambia (aparece 1 vez, el PDF de ejemplo de la quote):
      document.getElementById('quote-pdf-frame').src = '../assets/quote-example.pdf';
      por:
      document.getElementById('quote-pdf-frame').src = 'app/assets/quote-example.pdf';

   e) Cambia (aparecen 4 veces — 3 en la tabla de quotes y 1 en un
      window.open — el mismo texto exacto las 4 veces):
      ../salesforce/salesforce-quote.html
      por:
      app/salesforce/salesforce-quote.html
      Nota: esta carpeta (app/salesforce/) no existe todavía en el
      proyecto — el link ya estaba roto/apuntando a un archivo
      inexistente ANTES de este cambio también, así que no es algo que
      este movimiento rompa; solo se ajusta la ruta para que, si ese
      archivo se crea más adelante, quede en el lugar correcto.

   NO toques ninguna otra ruta relativa del archivo (por ejemplo la
   imagen "assets/blt0371ecb1478c7909/.../vzc-monarch-DOT-desktop-us.webp"
   ya estaba rota/sin resolver antes de este cambio y no tiene relación
   con el movimiento — déjala igual, es un problema aparte).

3. NO toques app/demos/account-setup.html en este prompt — se queda
   donde está, sin cambios. (Nota aparte para Catalina, no para el
   agente: ese archivo tiene su propia inconsistencia de rutas —
   "../../assets/ds/design-system.css" — que ya existía antes de este
   cambio y es un tema separado, no relacionado con este movimiento.)

4. Verifica al final que no quedó ningún archivo duplicado
   (app/demos/valucal_existing_accounts.html ya no debe existir) y que
   index.html en la raíz es ahora el dashboard completo de Valu Cal
   Existing Accounts.
```

---

## 7. Cuentas existentes — completar el "tier jump" del slider de descuento MSA (2026-09-08)

**Contexto:** el slider que reemplazó el dropdown "Promotion" en el modal "Configure Bundle" ya existe y funciona (`bld.msaDiscountPct`, precios de deck a 36 meses vía `MSA_TIER_UNIT_PRICES`/`getMsaTierLetter()`). Lo que falta, confirmado con Catalina, es la capa de **tier jump**: que el slider cubra las 4 tiers completas (0-25%) con marcas A-D, que se avise dentro del modal cuando el rep se pasa de su tier natural, y que la card del cart muestre el badge "Jump N tier(s)" y el banner "Approval required" — sin bloquear nunca "Select & Create Quote" (ese botón lo sigue controlando el mecanismo viejo de `volumeTiers`/`forcedTierIndex`, que no se toca).

Todo el código de abajo está verificado contra el estado REAL del archivo el 2026-09-08 (no son snippets genéricos) — usa los números de línea solo como referencia, ubica cada bloque por el texto exacto.

**Prompt para pegar en el agente:**

```
Trabaja en app/demos/valucal_existing_accounts.html.

Objetivo: completar el mecanismo de "tier jump" sobre el slider de
descuento MSA que ya existe en el modal "Configure Bundle". No toques el
mecanismo viejo de volumeTiers/forcedTierIndex/requiresApproval que ya
existe y sigue bloqueando el botón "Select & Create Quote" — esto es
una capa nueva, puramente informativa, en paralelo.

Haz estos 7 cambios:

1. Agrega dos funciones nuevas justo después de la función
   getMsaFleetSizeForBundleModal() ya existente (busca su cierre `}` y
   agrega después, antes de `function formatMoney`):

   function getMsaNaturalTierIndex(fleetSize) {
     const idx = MSA_DISCOUNT_TIERS.findIndex(t => fleetSize >= t.min && fleetSize <= t.max);
     return idx === -1 ? 0 : idx;
   }
   function getMsaSelectedTierIndex(pct) {
     const idx = MSA_DISCOUNT_TIERS.findIndex(t => pct >= t.minPct && pct <= t.maxPct);
     return idx === -1 ? 0 : idx;
   }

2. En el bloque HTML del slider (busca `id="msa-discount-block"`), que hoy es:

   <div class="preview-promo" id="msa-discount-block">
     <div class="preview-promo-label">Discount</div>
     <div class="msa-discount-slider-row">
       <input type="range" id="msa-discount-slider" class="msa-discount-slider" min="0" max="7" step="1" value="0" aria-label="Discount percentage" oninput="onMsaDiscountSliderInput(this.value)">
       <span id="msa-discount-value" class="msa-discount-value" aria-live="polite">0%</span>
     </div>
     <div id="msa-discount-tier-note" class="promo-eligibility-note"></div>
   </div>

   reemplázalo por (agrega el wrapper con las marcas A-D debajo del track):

   <div class="preview-promo" id="msa-discount-block">
     <div class="preview-promo-label">Discount</div>
     <div class="msa-discount-slider-row">
       <div class="msa-discount-slider-track-wrap">
         <input type="range" id="msa-discount-slider" class="msa-discount-slider" min="0" max="25" step="1" value="0" aria-label="Discount percentage" oninput="onMsaDiscountSliderInput(this.value)">
         <div id="msa-discount-tier-marks" class="msa-discount-tier-marks"></div>
       </div>
       <span id="msa-discount-value" class="msa-discount-value" aria-live="polite">0%</span>
     </div>
     <div id="msa-discount-tier-note" class="promo-eligibility-note"></div>
   </div>

3. CSS — busca la regla `.msa-discount-slider-row { display: flex; align-items: center; gap: 10px; }`
   y agrega estas reglas nuevas justo después (no borres nada existente):

   .msa-discount-slider-track-wrap { position: relative; flex: 1; }
   .msa-discount-tier-marks { position: absolute; top: 100%; left: 0; right: 0; height: 14px; margin-top: 4px; pointer-events: none; }
   .msa-discount-tier-mark { position: absolute; transform: translateX(-50%); font-size: 9px; font-weight: 700; color: var(--gray-500); }
   .msa-discount-jump-note { color: #8a6100; }

   Y en la regla `.msa-discount-slider { ... flex: 1; width: 100%; ... }` que ya existe,
   quita `flex: 1;` de ahí (ese flex ahora vive en `.msa-discount-slider-track-wrap`,
   el input debe quedar solo con `width: 100%`).

4. Reemplaza la función `renderMsaDiscountSlider()` completa (la que hoy fija
   `slider.min`/`slider.max` al rango de la tier natural) por esta versión,
   que deja el slider siempre en el rango completo 0-25 y solo fija el valor
   inicial la primera vez que se abre un bundle (no cada vez que cambia la
   cantidad):

   function renderMsaDiscountSlider() {
     const slider = document.getElementById('msa-discount-slider');
     const valueEl = document.getElementById('msa-discount-value');
     if (!slider) return;

     const overallMin = MSA_DISCOUNT_TIERS[0].minPct;
     const overallMax = MSA_DISCOUNT_TIERS[MSA_DISCOUNT_TIERS.length - 1].maxPct;
     slider.min = overallMin;
     slider.max = overallMax;

     if (!bld._msaDiscountInitialized) {
       const naturalTier = getMsaDiscountTier(getMsaFleetSizeForBundleModal());
       bld.msaDiscountPct = naturalTier.minPct;
       bld._msaDiscountInitialized = true;
     }
     if (bld.msaDiscountPct < overallMin || bld.msaDiscountPct > overallMax) {
       bld.msaDiscountPct = overallMin;
     }

     slider.value = bld.msaDiscountPct;
     updateMsaDiscountSliderFill(slider);
     if (valueEl) valueEl.innerText = `${bld.msaDiscountPct}%`;
     renderMsaDiscountTierMarks();
     updateMsaDiscountNote();
   }

5. Agrega estas dos funciones nuevas justo después de `renderMsaDiscountSlider()`
   (antes de `updateMsaDiscountSliderFill`):

   function renderMsaDiscountTierMarks() {
     const marksEl = document.getElementById('msa-discount-tier-marks');
     if (!marksEl) return;
     const overallMin = MSA_DISCOUNT_TIERS[0].minPct;
     const overallMax = MSA_DISCOUNT_TIERS[MSA_DISCOUNT_TIERS.length - 1].maxPct;
     const letters = ['A', 'B', 'C', 'D'];
     marksEl.innerHTML = MSA_DISCOUNT_TIERS.map((tier, index) => {
       const centerPct = (tier.minPct + tier.maxPct) / 2;
       const leftPct = ((centerPct - overallMin) / (overallMax - overallMin)) * 100;
       return `<span class="msa-discount-tier-mark" style="left:${leftPct}%;">${letters[index]}</span>`;
     }).join('');
   }

   function updateMsaDiscountNote() {
     const note = document.getElementById('msa-discount-tier-note');
     if (!note) return;
     const fleetSize = getMsaFleetSizeForBundleModal();
     const naturalIdx = getMsaNaturalTierIndex(fleetSize);
     const naturalTier = MSA_DISCOUNT_TIERS[naturalIdx];
     const selectedIdx = getMsaSelectedTierIndex(bld.msaDiscountPct);
     const selectedTier = MSA_DISCOUNT_TIERS[selectedIdx];
     const skip = selectedIdx - naturalIdx;

     if (skip > 0) {
       const role = getApprovalRole(skip);
       note.innerHTML = `<span class="msa-discount-tier-name msa-discount-jump-note">Tier jump — ${selectedTier.label}</span><span class="msa-discount-tier-range msa-discount-jump-note">Fleet is ${naturalTier.label}. Requires ${role} approval.</span>`;
     } else {
       note.innerHTML = `<span class="msa-discount-tier-name">${naturalTier.label}</span><span class="msa-discount-tier-range">Discount range ${naturalTier.minPct}-${naturalTier.maxPct}%</span>`;
     }
   }

6. Reemplaza la función `onMsaDiscountSliderInput(value)` completa (para que
   también actualice el aviso de tier jump mientras el rep arrastra el
   slider, no solo al reabrir el modal):

   function onMsaDiscountSliderInput(value) {
     bld.msaDiscountPct = Number(value) || 0;
     updateMsaDiscountSliderFill(document.getElementById('msa-discount-slider'));
     const valueEl = document.getElementById('msa-discount-value');
     if (valueEl) valueEl.innerText = `${bld.msaDiscountPct}%`;
     updateMsaDiscountNote();
     updateBundlePreview();
   }

7. En el reset de un bundle en blanco dentro de `openConfigureBundle()`
   (busca la línea exacta):

   bld.qty = 1; bld.coreKey = null; bld.msaDiscountPct = 0; bld.selectedFeatures = [];

   reemplázala por (agrega el flag de inicialización):

   bld.qty = 1; bld.coreKey = null; bld.msaDiscountPct = 0; bld._msaDiscountInitialized = false; bld.selectedFeatures = [];

8. Dentro de `renderOptions()`, en el `forEach` que arma `bundlesHtml`,
   busca este bloque (ya existente):

   let discBadges = '';
   if (hasDisc)    discBadges += `<span class="disc-badge">${(bt.discount*100)}% Volume disc</span> `;
   if (promoApplied) discBadges += `<span class="disc-badge" style="background:#0076CE">Media Promo −20%</span>`;

   agrega justo después (usa `totalUnits`, que ya está calculado más arriba
   en esta misma función, y `b`, que es el bundle actual del forEach):

   const bundleTierSkip = getMsaSelectedTierIndex(b.msaDiscountPct || 0) - getMsaNaturalTierIndex(totalUnits);
   if (bundleTierSkip > 0) {
     discBadges += ` <span class="disc-badge">Jump ${bundleTierSkip} tier${bundleTierSkip > 1 ? 's' : ''}</span>`;
   }

9. Todavía dentro de `renderOptions()`, justo después de la línea donde se
   calcula `const requiresApproval = skip > 0 && proposalData.approvalStatus !== 'Approved';`
   agrega esta constante nueva (aparte, no reemplaza nada, es un cálculo
   paralelo para el mecanismo nuevo):

   const optionHasMsaTierJump = opt.bundles.some(b => (getMsaSelectedTierIndex(b.msaDiscountPct || 0) - getMsaNaturalTierIndex(totalUnits)) > 0);

   Y en el template de `card.innerHTML`, busca:

   <div class="option-card-body">
      <div style="margin-bottom:10px;">
        ${termFieldHtml}
      </div>
      <div class="opt-totals-row">

   reemplázalo por (agrega el banner amarillo no bloqueante justo después del
   selector de término, antes de los totales):

   <div class="option-card-body">
      <div style="margin-bottom:10px;">
        ${termFieldHtml}
      </div>
      ${optionHasMsaTierJump ? `<div style="display:flex;align-items:center;gap:6px;background:#fff8e1;border:1px solid #f0c14b;color:#8a6100;font-size:12px;font-weight:600;padding:8px 12px;border-radius:6px;margin:10px 0;"><span class="material-symbols-outlined" style="font-size:16px;">warning</span>Approval required</div>` : ''}
      <div class="opt-totals-row">

No toques nada del mecanismo viejo (volumeTiers, forcedTierIndex,
requiresApproval/actionHtml que bloquea "Select & Create Quote",
getEffectiveTier). Ese sigue funcionando exactamente igual que hoy, en
paralelo a esta capa nueva.

Al terminar, verifica: (a) abrir "Configure Bundle" con un core VTU o
VTU+FFC muestra el slider arrancando en el mínimo de la tier natural del
fleet size actual, con marcas A/B/C/D debajo; (b) mover el slider más
allá de la tier natural muestra el aviso "Tier jump" con el rol de
aprobación correcto; (c) guardar ese bundle y verlo en la card del cart
muestra el badge verde "Jump N tier(s)" y la card completa muestra el
banner amarillo "Approval required" arriba de los totales; (d) el botón
"Select & Create Quote" NO se bloquea nunca por esto.
```

---

## 8. Cuentas existentes — modal bloqueante de "Service order term" al entrar al flujo (y limpieza del modal viejo sin usar) (2026-09-08)

**Contexto:** Catalina confirmó que "Service order term" y "Contract term"/"MSA Term" son campos DISTINTOS (no lo mismo con otro nombre). El modal debe aparecer bloqueante apenas carga la pantalla, pidiendo fecha de inicio + término en meses (12/24/36/48/60, mismos valores que el resto de la app), calculando la fecha de fin. Una vez confirmado, se sigue al flujo normal.

Ya existía en el código un modal sin usar (`#msa-setup-overlay`/`openMsaSetupModal()`) con campos viejos (Minimum quantity commitment, Minimum service term, Ramp-up period) que nunca se llama desde ningún lado — es código huérfano de un rediseño anterior. Catalina pidió quitar ese código heredado en vez de dejarlo ahí. Este prompt hace las dos cosas: quita lo viejo y agrega el modal nuevo, reusando el mismo shell visual (`.msa-setup-modal`/`.msa-setup-field` ya definidos en CSS) pero con contenido, funciones y comportamiento completamente nuevos.

**Prompt para pegar en el agente:**

```
Trabaja en app/demos/valucal_existing_accounts.html.

Objetivo: quitar el modal viejo sin usar "New Master Service Agreement"
(#msa-setup-overlay) y sus funciones, y reemplazarlo por un modal nuevo,
bloqueante, que pide el "Service order term" (fecha de inicio + término
en meses) apenas carga la pantalla, antes de poder usar el resto de la
app. No tiene botón Cancel, ni X, ni se cierra haciendo clic afuera —
es obligatorio completarlo para continuar.

Haz estos 6 cambios:

1. CSS — busca este comentario y regla (justo antes de "/* Signature
   completed modal */"):

   /* New Master Service Agreement modal */
   #msa-setup-overlay {
     z-index: 4025;
     background: rgba(0, 0, 0, 0.55);
   }

   reemplázalo por:

   /* Service order term modal (blocking, shown on flow entry) */
   #service-order-term-overlay {
     z-index: 4025;
     background: rgba(0, 0, 0, 0.55);
   }

   No toques ninguna otra regla CSS de esta sección (.msa-setup-modal,
   .msa-setup-field, .msa-setup-field-label, .msa-setup-hint, etc. se
   quedan igual — el modal nuevo las reutiliza).

2. HTML — busca el bloque completo que empieza en:

   <div class="overlay" id="msa-setup-overlay" onclick="closeMsaSetupModal()">

   y termina en el `</div>` que cierra ese overlay (justo antes del
   comentario "<!-- Confirm modify from contract -->"). Reemplaza TODO
   ese bloque (overlay completo, con todos sus campos e inputs viejos)
   por:

   <div class="overlay" id="service-order-term-overlay">
     <div class="msa-setup-modal" role="dialog" aria-modal="true" aria-labelledby="service-order-term-title">
       <div class="account-setup-header">
         <h2 class="account-setup-title" id="service-order-term-title">Service order term</h2>
       </div>
       <p class="account-setup-sub">
         Set the term for this service order before continuing. This is separate from the account's overall MSA term.
       </p>

       <div class="msa-setup-field">
         <label class="msa-setup-field-label" for="service-order-start-date">Start date <span class="required">*</span></label>
         <input id="service-order-start-date" class="vds-input account-setup-input" type="date" oninput="updateServiceOrderTermPreview()">
       </div>

       <div class="msa-setup-field">
         <label class="msa-setup-field-label" for="service-order-term-months">Term <span class="required">*</span></label>
         <select id="service-order-term-months" class="vds-select account-setup-input" onchange="updateServiceOrderTermPreview()">
           <option value="">Select months</option>
           <option value="12">12 months</option>
           <option value="24">24 months</option>
           <option value="36">36 months</option>
           <option value="48">48 months</option>
           <option value="60">60 months</option>
         </select>
       </div>

       <div class="msa-setup-field">
         <div class="msa-setup-field-label">End date</div>
         <div id="service-order-end-date-preview" class="msa-setup-hint">Select a start date and term to calculate.</div>
       </div>

       <div class="account-setup-actions">
         <button type="button" id="btn-service-order-term-continue" class="vds-btn-primary" onclick="confirmServiceOrderTerm()" disabled>Continue</button>
       </div>
     </div>
   </div>

   (Nota: el overlay ya NO tiene `onclick="closeXModal()"` en el div
   exterior — no debe poder cerrarse haciendo clic afuera. Tampoco tiene
   botón de cerrar (X) ni Cancel.)

3. JS — busca y BORRA por completo estas 4 funciones (son código
   huérfano, nada las llama excepto el modal que acabas de quitar):

   function updateMsaSetupSaveState() { ... }
   function openMsaSetupModal() { ... }
   function closeMsaSetupModal() { ... }
   function saveMsaSetup() { ... }

   (Las 4 están seguidas, justo antes del comentario
   "// ── CONFIGURE BUNDLE ───────────────────────────". Bórralas
   completas, de "function updateMsaSetupSaveState() {" hasta el cierre
   de "function saveMsaSetup() { ... }" inclusive.)

4. En su lugar (mismo punto del archivo), agrega estas 3 funciones
   nuevas:

   function computeServiceOrderEndDate(startISO, months) {
     if (!startISO || !months) return null;
     const end = new Date(startISO + 'T00:00:00');
     end.setMonth(end.getMonth() + Number(months));
     end.setDate(end.getDate() - 1);
     const y = end.getFullYear();
     const m = String(end.getMonth() + 1).padStart(2, '0');
     const d = String(end.getDate()).padStart(2, '0');
     return `${y}-${m}-${d}`;
   }

   function updateServiceOrderTermPreview() {
     const startEl = document.getElementById('service-order-start-date');
     const monthsEl = document.getElementById('service-order-term-months');
     const previewEl = document.getElementById('service-order-end-date-preview');
     const btn = document.getElementById('btn-service-order-term-continue');
     const start = startEl ? startEl.value : '';
     const months = monthsEl ? monthsEl.value : '';
     const endIso = computeServiceOrderEndDate(start, months);
     if (previewEl) {
       previewEl.textContent = endIso ? formatShortDate(endIso) : 'Select a start date and term to calculate.';
     }
     if (btn) btn.disabled = !(start && months);
   }

   function openServiceOrderTermModal() {
     const overlay = document.getElementById('service-order-term-overlay');
     if (!overlay) return;
     const startEl = document.getElementById('service-order-start-date');
     if (startEl && !startEl.value) {
       startEl.value = new Date().toISOString().slice(0, 10);
     }
     document.body.style.overflow = 'hidden';
     overlay.classList.add('open');
     updateServiceOrderTermPreview();
   }

   function confirmServiceOrderTerm() {
     const btn = document.getElementById('btn-service-order-term-continue');
     if (!btn || btn.disabled) return;
     const start = document.getElementById('service-order-start-date').value;
     const months = document.getElementById('service-order-term-months').value;
     const endIso = computeServiceOrderEndDate(start, months);

     if (typeof proposalData !== 'undefined') {
       proposalData.serviceOrderStartDate = start;
       proposalData.msaServiceOrderTerm = Number(months);
       proposalData.serviceOrderEndDate = endIso || '';
     }

     const overlay = document.getElementById('service-order-term-overlay');
     if (overlay) overlay.classList.remove('open');
     document.body.style.overflow = '';
   }

5. Busca el listener de mensajes que hoy es:

   window.addEventListener('message', (event) => {
     const data = event && event.data;
     const shouldClose = data === 'account-setup-close' || (data && data.type === 'account-setup-close');
     if (!shouldClose) return;

     closeAccountSetupEmbed();
     closeMsaSetupModal();
   });

   quítale la línea `closeMsaSetupModal();` (esa función ya no existe),
   dejándolo así:

   window.addEventListener('message', (event) => {
     const data = event && event.data;
     const shouldClose = data === 'account-setup-close' || (data && data.type === 'account-setup-close');
     if (!shouldClose) return;

     closeAccountSetupEmbed();
   });

6. Al final del archivo, busca:

   // ── Init ────────────────────────────────────────────────────
   renderLifecycleBar();

   })();

   reemplázalo por (agrega la apertura del modal justo después de
   renderLifecycleBar(), para que aparezca apenas carga la pantalla):

   // ── Init ──────────────────────────────────────────────────
   renderLifecycleBar();
   openServiceOrderTermModal();

   })();

Al terminar, verifica: (a) al abrir/recargar el archivo, el modal
"Service order term" aparece automáticamente encima de todo, bloqueando
la pantalla; (b) no se puede cerrar haciendo clic afuera ni hay botón
para cerrarlo sin completar los campos; (c) la fecha de inicio viene
pre-llenada con hoy pero es editable; (d) elegir un término en meses
calcula y muestra la fecha de fin correctamente; (e) el botón
"Continue" está deshabilitado hasta que ambos campos tengan valor, y al
hacer clic cierra el modal y dejar ver el resto de la app con
normalidad; (f) no quedan referencias rotas a closeMsaSetupModal,
openMsaSetupModal, saveMsaSetup ni updateMsaSetupSaveState en ningún
lado del archivo.
```

---

## 9. Limpieza — puntos 5.1 y 5.2 del handoff v2 (2026-09-08)

Dos cambios simples, confirmados con Catalina. Van en prompts separados porque tocan partes distintas del archivo.

### 9.1 — Quitar el indicador "/ N min" de las cards de opciones

Verificado en vivo que sigue existiendo (a pesar de que el handoff v2 decía que ya no). Es distinto de la discusión más grande, todavía sin cerrar, sobre si "Minimum quantity commitment" debe desaparecer de TODO el proyecto (dashboard, Account Setup, el modal de MSA) — eso sigue pendiente de que Catalina confirme escuchando la grabación de la llamada del 2026-09-04. Este prompt solo quita el badge puntual de las cards, que es lo que Catalina pidió ahora.

**Prompt para pegar en el agente:**

```
Trabaja en app/demos/valucal_existing_accounts.html.

Dentro de la función renderOptions(), busca este bloque exacto (justo
antes del template card.innerHTML):

const msaMinimumCommitment = Number(DEMO_MSA.minQuantityCommitment || 0);
let minimumIndicatorHtml = '';
if (msaMinimumCommitment > 0) {
  const stateClass = totalUnits < msaMinimumCommitment ? 'is-warning' : 'is-success';
  minimumIndicatorHtml = `<span class="opt-minimum-indicator ${stateClass}">/ ${msaMinimumCommitment} min</span>`;
}

Bórralo por completo (las 6 líneas).

Luego busca, dentro del mismo template de card.innerHTML:

<div class="opt-totals-value opt-totals-value--qty">${totalUnits} <span>units</span>${minimumIndicatorHtml}</div>

y reemplázalo por (quita solo `${minimumIndicatorHtml}` del final):

<div class="opt-totals-value opt-totals-value--qty">${totalUnits} <span>units</span></div>

No toques DEMO_MSA.minQuantityCommitment ni ningún otro lugar del
archivo — este cambio es solo el badge "/ N min" de las cards de
opciones. El resto de dónde aparece "Minimum quantity commitment" en
el proyecto (dashboard, Account Setup, etc.) queda para una decisión
aparte.

Verifica al final: las cards de opciones ya no muestran ningún "/ N
min" junto a "Total qty", solo el número de unidades.
```

### 9.2 — Renombrar "VTU + Dual Camera" → "VTU + Dual Camera Subscription"

Confirmado en vivo: quedan exactamente 3 lugares en `valucal_existing_accounts.html` sin el sufijo "Subscription" (en `index.html`, cuentas nuevas, ya está hecho).

**Prompt para pegar en el agente:**

```
Trabaja en app/demos/valucal_existing_accounts.html.

Cambia el texto "VTU + Dual Camera" por "VTU + Dual Camera Subscription"
en estos 3 lugares exactos (son los únicos 3 que quedan sin el sufijo
"Subscription" en este archivo):

1. En el dropdown de selección de core del modal "Configure Bundle":
   <div class="dropdown-option" onclick="selectCore('vtu-dual')">VTU + Dual Camera</div>
   →
   <div class="dropdown-option" onclick="selectCore('vtu-dual')">VTU + Dual Camera Subscription</div>

2. En corePricing (el pricing del modal "Configure Bundle"):
   'vtu-dual': { name: 'VTU + Dual Camera', price: 75.00 },
   →
   'vtu-dual': { name: 'VTU + Dual Camera Subscription', price: 75.00 },

3. En vzExpCorePricing (el pricing separado del flujo de expansión):
   busca la línea que define 'vtu-dual' dentro de vzExpCorePricing (el
   nombre dice 'VTU + Dual Camera' con espaciado extra de alineación,
   price: 75.00) y cambia el name a 'VTU + Dual Camera Subscription',
   manteniendo el resto de la línea (price, espaciado) igual.

No cambies ningún otro texto ni ninguna otra ocurrencia de "VTU" en el
archivo (por ejemplo "VTU" o "VTU + FFC" solos no se tocan, solo el
texto exacto "VTU + Dual Camera").

Verifica al final: buscando "VTU + Dual Camera" en el archivo, las 3
ocurrencias ahora terminan en "VTU + Dual Camera Subscription", y no
quedó ninguna sin el sufijo.
```

---

## 10. Loader de creación de quote + redirect automático a Salesforce (2026-09-08)

**Contexto:** al confirmar una opción, hoy aparece una card inline "Quote created successfully" con un botón "View quote" que abre Salesforce en pestaña nueva manualmente. Catalina confirmó que esto se reemplaza por completo (no se agrega como paso extra) por un loader de 2 etapas ("Creating Opportunity" → "Creating Quote", ~6 segundos) que al terminar redirige automáticamente, en la misma pestaña, a `../salesforce/salesforce-quote.html` con los datos reales del MSA por query params. A diferencia de cuentas nuevas, aquí el MSA YA EXISTE — este cambio NO debe recalcular ni sobreescribir sus datos, solo agregar el loader y el redirect.

**Hallazgo hecho al verificar el código real (2026-09-08) antes de escribir este prompt:** `proposalData.msaId` nunca se asigna en ningún lado del archivo — se queda siempre en `''` (el valor con el que se declara). Si se arma el redirect solo cuando `proposalData.msaId` es verdadero (como en el mecanismo ya probado de cuentas nuevas), nunca se armarían los query params aquí. El prompt de abajo ya incluye el ajuste: usa `proposalData.msaId || DEMO_MSA.id` como fallback, para que el redirect siempre lleve el ID real de la cuenta demo aunque `proposalData.msaId` no se haya llenado explícitamente.

También se encontró un SEGUNDO lugar que hoy dispara el paso viejo de "Quote created" (cuando el rep completa Account Validation a mitad de la selección de una opción, en `saveAccountValidation()`) — se incluye en el mismo cambio para que ambos caminos usen el loader nuevo de forma consistente.

**Nota aparte para Catalina (no para el agente):** el redirect apunta a `../salesforce/salesforce-quote.html`, la misma ruta que ya usa hoy `viewCreatedQuote()` en este archivo — ese archivo no existe dentro de la carpeta `valucal-existing-accounts` (ya lo habíamos confirmado antes), así que asumo que vive en una carpeta compartida fuera de esta que no puedo ver desde aquí. Si al probar el redirect da 404, avísame para investigarlo.

**Prompt para pegar en el agente:**

```
Trabaja en app/demos/valucal_existing_accounts.html.

Objetivo: reemplazar la card inline "Quote created successfully" (con
su botón manual "View quote") por un loader de 2 etapas que redirige
automáticamente a la página de Salesforce al terminar. No se debe
recalcular ni sobreescribir ningún dato del MSA — este cambio es solo
loader + redirect.

Haz estos 5 cambios:

1. CSS — agrega esto en algún punto del <style> (no reemplaza nada
   existente, verifica primero que no exista ya una regla
   `.quote-loader-overlay` para no duplicar):

   /* Quote creation loader */
   .quote-loader-overlay {
     position: fixed;
     inset: 0;
     z-index: 6000;
     background: rgba(8, 18, 36, 0.87);
     backdrop-filter: blur(4px);
     display: none;
     align-items: center;
     justify-content: center;
   }
   .quote-loader-overlay.open { display: flex; }
   .quote-loader-card {
     background: #fff;
     border-radius: 20px;
     padding: 36px;
     width: min(480px, 94vw);
     text-align: center;
     animation: qlSlideIn 0.3s cubic-bezier(0.22, 1, 0.36, 1);
   }
   @keyframes qlSlideIn {
     from { transform: translateY(18px); opacity: 0; }
     to { transform: translateY(0); opacity: 1; }
   }
   .ql-progress-wrap { margin-bottom: 28px; }
   .ql-progress-track {
     height: 5px;
     background: var(--gray-200);
     border-radius: 999px;
     overflow: hidden;
     margin-bottom: 10px;
   }
   .ql-progress-fill {
     height: 100%;
     width: 0%;
     background: var(--black);
     border-radius: 999px;
     transition: width 3s ease;
   }
   .ql-progress-labels { display: flex; justify-content: space-between; }
   .ql-progress-label {
     font-size: 11px;
     font-weight: 700;
     color: var(--gray-400);
     text-transform: uppercase;
     letter-spacing: 0.06em;
     transition: color 0.3s ease;
   }
   .ql-progress-label.active { color: var(--black); }
   .ql-progress-label.done { color: var(--green); }
   .quote-loader-headline {
     font-size: 22px;
     font-weight: 700;
     color: var(--black);
     letter-spacing: -0.01em;
     margin-bottom: 10px;
   }
   .ql-dots::after { content: ''; animation: qlDots 1.4s steps(4, end) infinite; }
   @keyframes qlDots {
     0% { content: ''; }
     25% { content: '.'; }
     50% { content: '..'; }
     75% { content: '...'; }
     100% { content: ''; }
   }
   .quote-loader-body { font-size: 15px; color: var(--gray-600); line-height: 1.6; margin-bottom: 14px; }
   .quote-loader-warning { font-size: 12px; color: var(--gray-400); }

2. HTML — agrega esto junto a los otros overlays del body (busca
   cualquier overlay existente, por ejemplo `#confirm-selection-overlay`,
   y agrega este bloque justo después de su cierre):

   <!-- Quote creation loader -->
   <div class="quote-loader-overlay" id="quote-loader-overlay" aria-live="polite" aria-busy="true">
     <div class="quote-loader-card">
       <div class="ql-progress-wrap">
         <div class="ql-progress-track">
           <div class="ql-progress-fill" id="ql-fill"></div>
         </div>
         <div class="ql-progress-labels">
           <span class="ql-progress-label active" id="ql-label-1">Opportunity</span>
           <span class="ql-progress-label" id="ql-label-2">Quote</span>
         </div>
       </div>
       <div class="quote-loader-headline" id="ql-headline">Creating Opportunity<span class="ql-dots"></span></div>
       <div class="quote-loader-body" id="ql-body">
         Setting up the opportunity record in Salesforce.<br>This may take a moment.
       </div>
       <div class="quote-loader-warning">Don't close or refresh this window</div>
     </div>
   </div>

3. JS — agrega estas 2 funciones nuevas cerca de `confirmSelectionAndProceed()`:

   function showQuoteCreationLoader() {
     const overlay = document.getElementById('quote-loader-overlay');
     if (!overlay) {
       openSalesforceQuotePage();
       return;
     }

     const fill = document.getElementById('ql-fill');
     const lbl1 = document.getElementById('ql-label-1');
     const lbl2 = document.getElementById('ql-label-2');
     const headline = document.getElementById('ql-headline');
     const body = document.getElementById('ql-body');

     if (fill) {
       fill.style.transition = 'none';
       fill.style.width = '0%';
     }
     if (lbl1) lbl1.className = 'ql-progress-label active';
     if (lbl2) lbl2.className = 'ql-progress-label';
     if (headline) headline.textContent = 'Creating Opportunity';
     if (body) body.innerHTML = 'Setting up the opportunity record in Salesforce.<br>This may take a moment.';

     overlay.classList.add('open');

     requestAnimationFrame(function () {
       requestAnimationFrame(function () {
         if (fill) {
           fill.style.transition = 'width 3s ease';
           fill.style.width = '50%';
         }
       });
     });

     setTimeout(function () {
       if (lbl1) lbl1.className = 'ql-progress-label done';
       if (lbl2) lbl2.className = 'ql-progress-label active';
       if (fill) {
         fill.style.transition = 'width 3s ease';
         fill.style.width = '100%';
       }
       if (headline) headline.innerHTML = 'Creating Quote<span class="ql-dots"></span>';
       if (body) body.innerHTML = 'Generating your configured quote and<br>linking it to the opportunity record.';
     }, 3000);

     setTimeout(function () {
       overlay.classList.remove('open');
       openSalesforceQuotePage();
     }, 6000);
   }

   function openSalesforceQuotePage() {
     const msaId = (proposalData && proposalData.msaId) || (typeof DEMO_MSA !== 'undefined' ? DEMO_MSA.id : '') || '';
     const params = new URLSearchParams();
     if (msaId) {
       params.set('msaId', msaId);
       if (proposalData.msaMinimumSpendCommitment != null) params.set('msaMinSpend', proposalData.msaMinimumSpendCommitment);
       if (proposalData.msaTermStart) params.set('msaTermStart', proposalData.msaTermStart);
       if (proposalData.msaContractTerm != null) params.set('msaMinService', proposalData.msaContractTerm);
       if (proposalData.msaRampUpPeriod != null) params.set('msaRampUp', proposalData.msaRampUpPeriod);
     }
     const quoteQuery = params.toString() ? `?${params.toString()}` : '';
     window.location.href = `../salesforce/salesforce-quote.html${quoteQuery}`;
   }

4. Reemplaza la función `confirmSelectionAndProceed()` (busca la línea
   exacta):

   function confirmSelectionAndProceed() {
     closeConfirmSelectionModal();
     accountSetupOpenedFromOptionSelection = false;
     openQuoteCreatedStep();
   }

   por:

   function confirmSelectionAndProceed() {
     closeConfirmSelectionModal();
     accountSetupOpenedFromOptionSelection = false;
     showQuoteCreationLoader();
   }

5. Dentro de `saveAccountValidation()`, busca la línea:

   setTimeout(() => openQuoteCreatedStep(), 160);

   y reemplázala por (mismo delay, misma lógica, solo cambia qué función
   dispara al final, para que este segundo camino use el mismo loader
   nuevo):

   setTimeout(() => showQuoteCreationLoader(), 160);

No toques ningún otro lugar donde se lea o calcule
proposalData.msaMinimumSpendCommitment/msaTermStart/msaContractTerm/
msaRampUpPeriod — este cambio no debe recalcular ni sobreescribir esos
valores, solo leerlos para armar el redirect. Las funciones
openQuoteCreatedStep(), hideQuoteCreatedState() y viewCreatedQuote()
pueden quedar sin usar en el archivo (no hace falta borrarlas).

Verifica al final: al confirmar una opción, aparece el loader de 2
etapas ("Creating Opportunity" → "Creating Quote", ~6 segundos en
total) y al terminar la página redirige sola (misma pestaña, no una
nueva) a salesforce-quote.html con msaId, msaMinSpend, msaTermStart,
msaMinService y msaRampUp en la URL. La card vieja "Quote created
successfully" con el botón "View quote" ya no aparece en ningún
camino (ni al confirmar una opción directo, ni al completarla después
de una validación de cuenta a mitad de camino).
```

---

## 11. Cuentas existentes — llevar el "tier jump" al slider de descuento del modal de Upsells (2026-09-08)

**Contexto:** Catalina confirmó que la lógica de tier jump (Sección 7, slider completo 0-25% con marcas A-D y aviso de aprobación) también debe aplicar al slider de descuento del modal "Feature Upsell" (`vzUpsellDiscountPct`, `renderVZUpsellDiscountSlider()`, `onVZUpsellDiscountSliderInput()`, dentro de `vzUpdateUpsellPreview()`).

Verificado en vivo: este slider es una implementación paralela e independiente del de "Configure Bundle" — tiene sus propias funciones y su propio elemento (`#vz-upsell-discount-slider`), pero ya reutiliza `getMsaDiscountTier()` y el helper compartido `updateMsaDiscountSliderFill()`. También verificado: el badge "Jump N tier(s)" y el banner "Approval required" de la Sección 7 viven en `renderOptions()` y se calculan a partir de `b.msaDiscountPct` de cada bundle guardado — como el upsell ya guarda `msaDiscountPct: vzUpsellDiscountPct` al confirmarse (en `_vzCommitBundles`), esos dos indicadores van a aparecer automáticamente en la card del cart sin tocar nada más. Este prompt solo se encarga de la experiencia dentro del modal (slider completo + marcas + aviso en vivo), igual que la Sección 7 lo hizo para "Configure Bundle".

**IMPORTANTE — orden de ejecución:** este prompt reutiliza clases CSS y funciones que agrega la Sección 7 (`getMsaNaturalTierIndex`, `getMsaSelectedTierIndex`, `.msa-discount-slider-track-wrap`, `.msa-discount-tier-marks`, `.msa-discount-tier-mark`, `.msa-discount-jump-note`). **La Sección 7 debe ejecutarse primero.** El prompt de abajo empieza pidiéndole al agente que lo verifique antes de continuar.

**Prompt para pegar en el agente:**

```
Trabaja en app/demos/valucal_existing_accounts.html.

Antes de empezar, verifica que ya existan en el archivo las funciones
getMsaNaturalTierIndex y getMsaSelectedTierIndex, y la clase CSS
.msa-discount-slider-track-wrap. Si NO existen, detente y avisa que
falta aplicar primero el prompt de tier jump de "Configure Bundle"
(no continúes sin eso).

Objetivo: llevar el mismo mecanismo de "tier jump" (slider completo
0-25% con marcas A-D y aviso en vivo de aprobación) al slider de
descuento del modal "Feature Upsell". No toques renderOptions() ni el
mecanismo de badges/banner de la card del cart — eso ya funciona
automáticamente para bundles de upsell una vez que Configure Bundle
tiene su parte hecha, porque ambos leen b.msaDiscountPct de la misma
forma.

Haz estos 6 cambios:

1. Busca la declaración de variable (línea única en el archivo):

   let vzUpsellDiscountPct = 0;

   reemplázala por (agrega el flag de inicialización, mismo patrón que
   bld._msaDiscountInitialized en Configure Bundle):

   let vzUpsellDiscountPct = 0;
   let vzUpsellDiscountInitialized = false;

2. Dentro de la función que abre el flujo de upsell, busca este bloque
   exacto:

   if (bld.txType === 'upsell') {
     vzUpsellDiscountPct = 0;
     renderVZUpsellForm();
   }

   reemplázalo por (resetea también el flag cada vez que se abre el
   modal de upsell):

   if (bld.txType === 'upsell') {
     vzUpsellDiscountPct = 0;
     vzUpsellDiscountInitialized = false;
     renderVZUpsellForm();
   }

3. Dentro de la función vzUpdateUpsellPreview(), busca este bloque HTML
   exacto (dentro del template string):

   <div class="preview-promo" style="margin-bottom:16px;">
     <div class="preview-promo-label">Discount</div>
     <div class="msa-discount-slider-row">
       <input type="range" id="vz-upsell-discount-slider" class="msa-discount-slider" min="0" max="7" step="1" value="0" aria-label="Upsell discount percentage" oninput="onVZUpsellDiscountSliderInput(this.value)">
       <span id="vz-upsell-discount-value" class="msa-discount-value" aria-live="polite">0%</span>
     </div>
     <div id="vz-upsell-discount-tier-note" class="promo-eligibility-note"></div>
   </div>

   reemplázalo por (agrega el wrapper con las marcas A-D debajo del
   track, mismo patrón que el slider de Configure Bundle):

   <div class="preview-promo" style="margin-bottom:16px;">
     <div class="preview-promo-label">Discount</div>
     <div class="msa-discount-slider-row">
       <div class="msa-discount-slider-track-wrap">
         <input type="range" id="vz-upsell-discount-slider" class="msa-discount-slider" min="0" max="25" step="1" value="0" aria-label="Upsell discount percentage" oninput="onVZUpsellDiscountSliderInput(this.value)">
         <div id="vz-upsell-discount-tier-marks" class="msa-discount-tier-marks"></div>
       </div>
       <span id="vz-upsell-discount-value" class="msa-discount-value" aria-live="polite">0%</span>
     </div>
     <div id="vz-upsell-discount-tier-note" class="promo-eligibility-note"></div>
   </div>

4. Reemplaza la función renderVZUpsellDiscountSlider() completa (la que
   hoy fija slider.min/max al rango de la tier natural) por esta
   versión, que deja el slider siempre en el rango completo 0-25 y solo
   fija el valor inicial la primera vez que se abre el modal:

   function renderVZUpsellDiscountSlider() {
     const slider = document.getElementById('vz-upsell-discount-slider');
     const valueEl = document.getElementById('vz-upsell-discount-value');
     if (!slider) return;

     const overallMin = MSA_DISCOUNT_TIERS[0].minPct;
     const overallMax = MSA_DISCOUNT_TIERS[MSA_DISCOUNT_TIERS.length - 1].maxPct;
     slider.min = overallMin;
     slider.max = overallMax;

     if (!vzUpsellDiscountInitialized) {
       const naturalTier = getMsaDiscountTier(getMsaFleetSizeForUpsell());
       vzUpsellDiscountPct = naturalTier.minPct;
       vzUpsellDiscountInitialized = true;
     }
     if (vzUpsellDiscountPct < overallMin || vzUpsellDiscountPct > overallMax) {
       vzUpsellDiscountPct = overallMin;
     }

     slider.value = vzUpsellDiscountPct;
     updateMsaDiscountSliderFill(slider);
     if (valueEl) valueEl.textContent = `${vzUpsellDiscountPct}%`;
     renderVZUpsellDiscountTierMarks();
     updateVZUpsellDiscountNote();
   }

5. Agrega estas dos funciones nuevas justo después de
   renderVZUpsellDiscountSlider() (antes de onVZUpsellDiscountSliderInput):

   function renderVZUpsellDiscountTierMarks() {
     const marksEl = document.getElementById('vz-upsell-discount-tier-marks');
     if (!marksEl) return;
     const overallMin = MSA_DISCOUNT_TIERS[0].minPct;
     const overallMax = MSA_DISCOUNT_TIERS[MSA_DISCOUNT_TIERS.length - 1].maxPct;
     const letters = ['A', 'B', 'C', 'D'];
     marksEl.innerHTML = MSA_DISCOUNT_TIERS.map((tier, index) => {
       const centerPct = (tier.minPct + tier.maxPct) / 2;
       const leftPct = ((centerPct - overallMin) / (overallMax - overallMin)) * 100;
       return `<span class="msa-discount-tier-mark" style="left:${leftPct}%;">${letters[index]}</span>`;
     }).join('');
   }

   function updateVZUpsellDiscountNote() {
     const note = document.getElementById('vz-upsell-discount-tier-note');
     if (!note) return;
     const fleetSize = getMsaFleetSizeForUpsell();
     const naturalIdx = getMsaNaturalTierIndex(fleetSize);
     const naturalTier = MSA_DISCOUNT_TIERS[naturalIdx];
     const selectedIdx = getMsaSelectedTierIndex(vzUpsellDiscountPct);
     const selectedTier = MSA_DISCOUNT_TIERS[selectedIdx];
     const skip = selectedIdx - naturalIdx;

     if (skip > 0) {
       const role = getApprovalRole(skip);
       note.innerHTML = `<span class="msa-discount-tier-name msa-discount-jump-note">Tier jump — ${selectedTier.label}</span><span class="msa-discount-tier-range msa-discount-jump-note">Fleet is ${naturalTier.label}. Requires ${role} approval.</span>`;
     } else {
       note.innerHTML = `<span class="msa-discount-tier-name">${naturalTier.label}</span><span class="msa-discount-tier-range">Discount range ${naturalTier.minPct}-${naturalTier.maxPct}%</span>`;
     }
   }

6. Reemplaza la función onVZUpsellDiscountSliderInput(value) completa
   (para que también actualice el aviso de tier jump mientras el rep
   arrastra el slider):

   function onVZUpsellDiscountSliderInput(value) {
     vzUpsellDiscountPct = Number(value) || 0;
     updateMsaDiscountSliderFill(document.getElementById('vz-upsell-discount-slider'));
     vzUpdateUpsellPreview();
   }

   (Nota: a diferencia de Configure Bundle, aquí ya se llamaba a
   vzUpdateUpsellPreview() en vez de solo actualizar el texto del valor
   — mantenlo así, solo asegúrate de que updateVZUpsellDiscountNote()
   se siga llamando indirectamente porque vzUpdateUpsellPreview() llama
   a renderVZUpsellDiscountSlider() al final, que ya la incluye.)

No toques getMsaDiscountTier, MSA_DISCOUNT_TIERS, renderOptions(),
_vzCommitBundles, ni ningún otro lugar del archivo — este cambio es
solo la experiencia del slider dentro del modal de Feature Upsell.

Verifica al final: (a) abrir "Feature Upsell", seleccionar vehículos y
features muestra el slider arrancando en el mínimo de la tier natural
del número de vehículos seleccionados, con marcas A/B/C/D debajo; (b)
mover el slider más allá de la tier natural muestra el aviso "Tier
jump" con el rol de aprobación correcto, sin bloquear el botón "Add
Upsell"; (c) al confirmar el upsell y verlo en la card del cart,
aparece el badge "Jump N tier(s)" y el banner "Approval required" igual
que en un bundle de Configure Bundle con jump.
```

---

## 12. Cuentas existentes — rehacer el PDF de "Review & Send Proposal" igual a cuentas nuevas, con contenedor MSA (2026-09-08)

**Contexto:** Catalina confirmó reemplazar por completo `renderProposalDoc()` de `valucal_existing_accounts.html` por la versión de cuentas nuevas — una página por opción (hoy todas las opciones van en una sola página), mismo estilo de página/footer/paginación, y el contenedor MSA (con Min. spend commitment / Contract Date / Term / Ramp-up period) arriba de cada tabla de precios.

Verificado en vivo (2026-09-08) antes de escribir este prompt: `renderProposalDoc()` va de la línea 13207 a la 13358 de `app/demos/valucal_existing_accounts.html` (termina justo antes de `function onProposalExpirationChange()`) — se reemplaza completa. `proposalData` ya tiene `msaId`, `msaContractTerm`, `msaMinimumSpendCommitment`, `msaTermStart`, `msaRampUpPeriod` (agregados en trabajo anterior de este mismo plan), así que el contenedor MSA de abajo puede leerlos directo, sin agregar nada a `proposalData`. Confirmado también que `calcBundle`, `getEvcTypeLabel`, `getRoiConfig`, `getSelectedMaterials`, `calcOption`, `getOptionPromotion`, `formatMoney`, `parseProposalDate`, `formatUsDate` ya existen y no cambian. Dos funciones SÍ son nuevas y no existen todavía: `proposalEscapeHtml()` (sanitización de HTML) y `getMsaTermEndDate()` (fecha fin = inicio + N meses − 1 día, misma fórmula que ya se usa en otros lados de la app).

**No es un simple copy-paste de `index.html`:** este archivo no tiene `getSelectedCaseStudyData()` (selector de varios case studies) — la página de Case Study se queda con el contenido hardcodeado que ya tenía este archivo (Bill Howe / B.A.M Trucking), solo con la plantilla visual nueva. Tampoco usa `getBundleEvcLabel(b)` de `index.html` — se mantiene el patrón que ya existe aquí (`typeof getEvcTypeLabel === 'function' ? getEvcTypeLabel(b.evcType) : ...`). Las imágenes de logo/onboarding se quedan con las URLs remotas que ya funcionan en este archivo (no se cambia a rutas locales).

**Prompt para pegar en el agente:**

```
Trabaja en app/demos/valucal_existing_accounts.html.

Objetivo: reemplazar renderProposalDoc() completa por una versión nueva
que arma una página por opción (hoy arma todas las opciones juntas en
una sola página) con un contenedor "Master Service Agreement" arriba de
la tabla de precios de cada página, igual al que ya existe en la
versión de cuentas nuevas de esta app.

Haz estos 2 cambios:

1. Agrega estas 2 funciones nuevas en cualquier parte del <script>
   principal, antes de la definición de renderProposalDoc():

   function proposalEscapeHtml(value) {
     return String(value == null ? '' : value)
       .replace(/&/g, '&amp;')
       .replace(/</g, '&lt;')
       .replace(/>/g, '&gt;')
       .replace(/\"/g, '&quot;')
       .replace(/'/g, '&#39;');
   }

   function getMsaTermEndDate(startIso, termMonths) {
     const start = parseProposalDate(startIso);
     if (!start || !Number.isFinite(termMonths) || termMonths <= 0) return null;
     const end = new Date(start);
     end.setMonth(end.getMonth() + termMonths);
     end.setDate(end.getDate() - 1);
     return end;
   }

2. Busca la función completa function renderProposalDoc() { ... } (empieza
   con "function renderProposalDoc() {" y termina en el "}" justo antes
   de "function onProposalExpirationChange() {" — verifícalo por el
   texto, no por número de línea). Reemplázala completa por:

   function renderProposalDoc() {
     updateMaterialsLabel();
     const viewer = document.getElementById('prop-doc-viewer');
     if (!viewer) return;

     const dateStr = formatUsDate(new Date());
     const expirationInput = document.getElementById('proposal-expiration-date');
     let expirationStr;
     if (expirationInput && expirationInput.value) {
       const parsedExpiration = parseProposalDate(expirationInput.value);
       expirationStr = parsedExpiration ? formatExpirationDisplayDate(clampExpirationDate(startOfDay(parsedExpiration))) : formatExpirationDisplayDate(getDefaultExpirationDate());
     } else {
       expirationStr = formatExpirationDisplayDate(getDefaultExpirationDate());
     }

     const selectedMaterials = getSelectedMaterials();
     const pages = [];
     let pageNum = 1;

     const buildMsaContainerHtml = (optionTerm) => {
       if (!proposalData.msaId) return '';
       const startDate = parseProposalDate(proposalData.msaTermStart);
       const termMonths = Number(optionTerm) || Number(proposalData.msaContractTerm) || 0;
       const endDate = getMsaTermEndDate(proposalData.msaTermStart, termMonths);
       const rangeLabel = startDate
         ? (endDate ? `${formatUsDate(startDate)} – ${formatUsDate(endDate)}` : formatUsDate(startDate))
         : '--';
       const minSpend = proposalData.msaMinimumSpendCommitment != null ? `${formatMoney(proposalData.msaMinimumSpendCommitment)}/mo` : '--';
       const termLabel = termMonths ? `${termMonths} months` : '--';
       const rampUp = proposalData.msaRampUpPeriod != null ? `${proposalData.msaRampUpPeriod} days` : '--';
       const field = (label, value) => `<div><div style="font-size:10px;font-weight:700;margin-bottom:3px;white-space:nowrap;">${label}</div><div style="font-size:10px;color:#222;white-space:nowrap;">${value}</div></div>`;
       return `<div style="background:#fff;border:1px solid #000;border-radius:4px;padding:10px 16px 12px;margin:8px 0 14px;">
         <div style="background:#000;color:#fff;font-size:10px;font-weight:700;padding:8px 16px;margin:-10px -16px 10px;border-radius:3px 3px 0 0;">Master Service Agreement</div>
         <div style="display:grid;grid-template-columns:1.15fr 1.25fr .8fr 1.1fr;gap:12px;font-size:10px;color:#222;">
           ${field('Min. spend commitment', minSpend)}
           ${field('Contract Date', rangeLabel)}
           ${field('Term', termLabel)}
           ${field('Ramp-up period', rampUp)}
         </div>
       </div>`;
     };

     // Shared page footer disclaimer
     const DISCLAIMER = 'This quotation is for illustrative purpose only and does not constitute a formal offer or contractual agreement. Final configurations and pricing may vary. For complete terms and conditions, please contact your sales representative.';
     const COPYRIGHT = '© 2026 Verizon Connect. All Rights Reserved.';
     const VZC_LOGO = `<img src="https://raw.githubusercontent.com/catalinaypun/valu-cal-app/393563638315e21a9ce0a395f797c851de8be70d/resources/verizon-connect-logo.svg" alt="Verizon Connect" style="height:25px;display:block;">`;

     function wrapPage(content, num) {
       return `<div class="doc-page-outer" style="margin-bottom:16px;"><div class="vc-doc-shell"><div class="vc-doc-brand-line"></div><div class="vc-doc-inner" style="min-height:1040px;padding-bottom:56px;position:relative;">${content}<div style="position:absolute;bottom:12px;left:0;right:0;border-top:1px solid #dcdcdc;padding-top:10px;text-align:center;background:#ffffff;"><div style="font-size:6.8px;color:#2f2f2f;line-height:1.35;max-width:640px;margin:0 auto;">${DISCLAIMER}</div><div style="font-size:7px;color:#111111;font-weight:700;margin-top:8px;">${COPYRIGHT}</div></div></div></div></div>`;
     }

     // Simple header used on pages 2-4
     function simpleHeader() {
       return `<div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:6px;"><div><div style="font-size:28px;font-weight:900;color:#ee001e;line-height:1.1;">Quote</div><div style="font-size:11px;color:#555;margin-top:3px;">${dateStr}&nbsp;&nbsp;<strong style="font-weight:600;">|</strong>&nbsp;&nbsp;<strong style="font-weight:600;">Ref</strong> Prop-9284</div></div>${VZC_LOGO}</div><div style="height:1px;background:#e0e0e0;margin:10px -24px 20px;"></div>`;
     }

     function getQuoteTermLabel(opt) {
       const base = `${opt.term} Month`;
       const hasSeasonalWindow = Boolean(seasonalConfig && seasonalConfig.startMonth && seasonalConfig.endMonth);
       if (!hasSeasonalWindow) return base;
       return `${base} | Seasonal 6mo/3 off`;
     }

     function getDefaultQuoteTermLabel() {
       const hasSeasonalWindow = Boolean(seasonalConfig && seasonalConfig.startMonth && seasonalConfig.endMonth);
       return hasSeasonalWindow ? '48 Month | Seasonal 6mo/3 off' : '36 Month';
     }

     // ── PAGE 1..N: Quote — one page per option ─────────────────────
     {
       function buildIncludedNoCostRows(startRowIndex) {
         const includedRows = [
           { title: 'On site professional installation', subtitle: 'Certified Technician Service' },
           { title: 'Hardware and equipment', subtitle: '' },
           { title: 'Standard Activation', subtitle: 'One-time fee per unit' }
         ];
         return includedRows.map(function (row, offset) {
           const rowBg = ((startRowIndex + offset) % 2 === 1) ? 'background:#f7f7f7;' : '';
           const subtitleHtml = row.subtitle
             ? '<div style="font-size:9px;color:#555;line-height:1.3;">' + proposalEscapeHtml(row.subtitle) + '</div>'
             : '';
           return '<tr style="' + rowBg + '">' +
             '<td style="padding:8px 6px;font-size:10px;vertical-align:top;border-bottom:1px solid #ededed;color:#222;">1</td>' +
             '<td style="padding:8px 6px;font-size:10px;vertical-align:top;border-bottom:1px solid #ededed;color:#222;"><div style="font-weight:700;line-height:1.25;">' + proposalEscapeHtml(row.title) + '</div>' + subtitleHtml + '</td>' +
             '<td style="padding:8px 6px;text-align:right;vertical-align:top;border-bottom:1px solid #ededed;white-space:nowrap;"><div style="font-size:8px;color:#777;text-decoration:line-through;line-height:1.2;">$100.00</div><div style="font-size:10px;color:#1a1a1a;line-height:1.25;">$0.00</div></td>' +
             '<td style="padding:8px 6px;text-align:right;vertical-align:top;border-bottom:1px solid #ededed;white-space:nowrap;"><div style="font-size:10px;font-weight:700;color:#16a34a;line-height:1.25;">$0.00</div></td>' +
           '</tr>';
         }).join('');
       }

       const buildQuoteTableHtml = (optionLabel, termLabel, rowsHtml, optTotal, standardTotal) => {
         const hasDiscountedTotal = Number.isFinite(standardTotal) && standardTotal > optTotal + 0.005;
         return `<div style="margin-bottom:16px;"><div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:5px;"><div style="font-size:22px;font-weight:900;color:#ee001e;line-height:1.05;">${optionLabel}</div><div style="font-size:18px;font-weight:700;color:#1a1a1a;line-height:1.1;">${termLabel}</div></div><div style="height:1px;background:#1a1a1a;margin-bottom:0;"></div><table style="width:100%;border-collapse:collapse;"><thead><tr style="border-bottom:1px solid #d8d8d8;"><th style="padding:7px 6px;text-align:left;font-size:10px;font-weight:700;color:#1a1a1a;">QTY</th><th style="padding:7px 6px;text-align:left;font-size:10px;font-weight:700;color:#1a1a1a;">Description</th><th style="padding:7px 6px;text-align:right;font-size:10px;font-weight:700;color:#1a1a1a;">Unit price</th><th style="padding:7px 6px;text-align:right;font-size:10px;font-weight:700;color:#1a1a1a;">Total</th></tr></thead><tbody>${rowsHtml || '<tr><td colspan="4" style="padding:10px 6px;font-size:10px;color:#888;text-align:center;">No bundles added</td></tr>'}</tbody></table><div style="display:flex;flex-direction:column;align-items:flex-end;padding:8px 0 2px;gap:3px;">${hasDiscountedTotal ? `<div style="display:flex;align-items:center;gap:6px;"><div style="font-size:9px;color:#666;">Standard Monthly Rate</div><div style="font-size:11px;color:#777;text-decoration:line-through;">${formatMoney(standardTotal)}</div></div>` : ''}<div style="display:flex;align-items:baseline;gap:6px;"><div style="font-size:10px;font-weight:800;color:#ee001e;">Total Monthly Payment</div><div style="font-size:15px;font-weight:900;color:#1a1a1a;">${formatMoney(optTotal)}</div></div><div style="font-size:7px;color:#999;">*Excludes applicable taxes</div></div></div>`;
       };

       const upperLegal = `<div style="margin-top:10px;font-size:6.8px;color:#666;line-height:1.3;">This promotion is available to select new and existing Verizon Business customers in the US only, excluding Reveal Starter customers, OEM customers, Work, Group Purchasing Organization customers (GPOs), seasonal contracts, month-to-month contracts, federal, state and local government entities, healthcare sector, and migrations. Minimum Purchase Required: 5 Reveal Vehicle Tracking Subscription or 5 Reveal Powered Asset Tracking or 5 Reveal Vehicle Tracking Subscription plus either 1 Road-facing AI Dashcam or 1 Dual Cam with AI Dashcam. Promo credits and eligibility requirements are no longer met. Early cancellation or termination fees and other taxes, fees and terms may apply. Offer valid through December 31, 2026 or while supplies last. © 2026 Verizon.</div>`;

       const quotePageHeaderHtml = `<div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:7px;"><div><div style="font-size:30px;font-weight:900;color:#ee001e;line-height:1.04;">Quote</div><div style="font-size:10px;color:#555;margin-top:3px;"><strong style="font-weight:700;">${dateStr}</strong>&nbsp;|&nbsp;<strong style="font-weight:700;">Ref</strong> Prop-9284</div></div><div style="padding-top:4px;">${VZC_LOGO}</div></div><div style="background:#f8f3e9;padding:10px 20px;margin:8px -24px 14px;display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;font-size:10px;color:#222;"><div><div style="font-weight:700;margin-bottom:3px;font-size:10px;">Prepared by</div><div>Lisa Sullivan</div><div style="color:#666;">lisa.sullivan@verizonconnect.com</div><div style="color:#666;">(304) 555-0192</div></div><div><div style="font-weight:700;margin-bottom:3px;font-size:10px;">Prepared for</div><div>Apex Construction LLC</div><div style="color:#666;">123 Industrial PKWY, Tampa FL 33602, USA</div></div><div style="text-align:right;"><div style="font-weight:700;margin-bottom:3px;font-size:10px;">Valid until</div><div>${expirationStr}</div></div></div>`;

       const buildOptionPageHtml = (opt, i) => {
         let totalUnits = 0;
         opt.bundles.forEach(b => { totalUnits += b.qty; });
         const forcedIdx = opt.forcedTierIndex ?? -1;
         const optionPromo = getOptionPromotion(opt);
         let optTotal = 0;
         let standardTotal = 0;

         const bundleRowsHtml = opt.bundles.map((b, rowIdx) => {
           const livePromo = b.promoType || optionPromo || 'Standard';
           const { unitPrice, monthly } = calcBundle(b, opt.term, livePromo, forcedIdx, totalUnits);
           const { unitPrice: standardUnitPrice, monthly: standardMonthly } = calcBundle(b, opt.term, 'Standard', forcedIdx, totalUnits);
           optTotal += monthly;
           standardTotal += standardMonthly;

           const featNames = (b.features || b.selectedFeatures || []).map(k => {
             if (k === 'evc') return `EVC (${typeof getEvcTypeLabel === 'function' ? getEvcTypeLabel(b.evcType) : (b.evcType || 'Dual')})`;
             return featureLabels[k] || k;
           }).filter(Boolean);
           const featLine = featNames.length ? `<div style="font-size:9px;color:#555;line-height:1.3;">${featNames.join(', ')}</div>` : '';
           const hasDiscount = (standardUnitPrice - unitPrice) > 0.005;
           const rowBg = (rowIdx % 2 === 1) ? 'background:#f7f7f7;' : '';
           const bundleTermMonths = Number.parseInt(opt.term, 10) || 0;
           const totalSavings = (standardMonthly - monthly) * bundleTermMonths;
           const promoBadge = hasDiscount ? '<span style="display:inline-flex;align-items:center;background:#16a34a;color:#fff;border-radius:4px;font-size:8px;font-weight:700;padding:1px 5px;margin-top:3px;">Total Savings: ' + formatMoney(totalSavings) + '</span>' : '';

           return `<tr style="${rowBg}"><td style="padding:8px 6px;font-size:10px;vertical-align:top;border-bottom:1px solid #ededed;color:#222;">${b.qty}</td><td style="padding:8px 6px;font-size:10px;vertical-align:top;border-bottom:1px solid #ededed;color:#222;"><div style="font-weight:700;line-height:1.25;">${b.coreName}</div>${featLine}${promoBadge}</td><td style="padding:8px 6px;text-align:right;vertical-align:top;border-bottom:1px solid #ededed;white-space:nowrap;">${hasDiscount ? `<div style="font-size:8px;color:#777;text-decoration:line-through;line-height:1.2;">${formatMoney(standardUnitPrice)}</div>` : ''}<div style="font-size:10px;color:#1a1a1a;line-height:1.25;">${formatMoney(unitPrice)}</div></td><td style="padding:8px 6px;text-align:right;vertical-align:top;border-bottom:1px solid #ededed;white-space:nowrap;">${hasDiscount ? `<div style="font-size:8px;color:#777;text-decoration:line-through;line-height:1.2;">${formatMoney(standardMonthly)}</div>` : ''}<div style="font-size:10px;font-weight:700;color:#1a1a1a;line-height:1.25;">${formatMoney(monthly)}</div></td></tr>`;
         }).join('');
         const rowsHtml = bundleRowsHtml + buildIncludedNoCostRows(opt.bundles.length);

         const tableHtml = buildQuoteTableHtml(`Option ${i + 1}`, `${opt.term} Month`, rowsHtml, optTotal, standardTotal);
         return `${quotePageHeaderHtml}${buildMsaContainerHtml(opt.term)}${tableHtml}${upperLegal}`;
       };

       if (options.length > 0) {
         options.forEach((opt, i) => {
           pages.push(wrapPage(buildOptionPageHtml(opt, i), pageNum++));
         });
       } else {
         const defaultBaseRow = `<tr><td style="padding:8px 6px;font-size:10px;vertical-align:top;border-bottom:1px solid #ededed;color:#222;">25</td><td style="padding:8px 6px;font-size:10px;vertical-align:top;border-bottom:1px solid #ededed;color:#222;"><div style="font-weight:700;line-height:1.25;">Vehicle Tracking Subscription</div><div style="font-size:9px;color:#555;line-height:1.3;">Driver ID, Panic Button</div></td><td style="padding:8px 6px;text-align:right;vertical-align:top;border-bottom:1px solid #ededed;white-space:nowrap;"><div style="font-size:10px;color:#1a1a1a;line-height:1.25;">$42.00</div></td><td style="padding:8px 6px;text-align:right;vertical-align:top;border-bottom:1px solid #ededed;white-space:nowrap;"><div style="font-size:10px;font-weight:700;color:#1a1a1a;line-height:1.25;">$1,050.00</div></td></tr>`;
         const defaultRows = defaultBaseRow + buildIncludedNoCostRows(1);
         const defaultOptionTableHtml = buildQuoteTableHtml('Option 1', getDefaultQuoteTermLabel(), defaultRows, 1050, 1050);
         pages.push(wrapPage(`${quotePageHeaderHtml}${buildMsaContainerHtml()}${defaultOptionTableHtml}${upperLegal}`, pageNum++));
       }
     }

     // ── PAGE 2: Onboarding Flyer (optional) ───────────────────────
     if (selectedMaterials.has('onboarding')) {
       const HERO_IMG = `https://images.contentstack.io/v3/assets/blt0371ecb1478c7909/blt65a932e3237c46d9/688161b889e3963781bad1ea/vzc-monarch-DOT-desktop-us.webp?auto=webp?w=1920&q=75&auto=webp`;
       const CREW_IMG = `https://images.contentstack.io/v3/assets/blt0371ecb1478c7909/blt65a932e3237c46d9/688161b889e3963781bad1ea/vzc-monarch-DOT-desktop-us.webp?auto=webp?w=800&q=75&auto=webp`;
       const page2 = `${simpleHeader()}<div style="position:relative;margin:0 -24px 24px;overflow:hidden;height:260px;background:#4a5568 url('${HERO_IMG}') center/cover no-repeat;"><div style="position:absolute;left:24px;top:24px;width:46%;background:#ee001e;color:#fff;padding:22px 18px 18px;"><div style="font-size:21px;font-weight:700;line-height:1.18;margin-bottom:10px;">Fast, no&#8209;hassle onboarding with Verizon Connect</div><div style="font-size:12px;line-height:1.4;">Minimize disruption,<br><strong>Maximize ROI.</strong></div></div></div><div style="display:grid;grid-template-columns:1fr 1fr;gap:24px;margin-bottom:26px;"><div style="font-size:12px;color:#222;line-height:1.65;">Running a fleet leaves you with little time to spare. That's why we designed an onboarding process that delivers <strong>fast results with minimal vehicle downtime.</strong> Here's what you can expect:</div><div>${[['Dedicated onboarding success expert','A single point of contact to guide you every step of the way'],['Flexible installation scheduling','Evenings and weekends available, so daily routes stay intact'],['Complete control, always','Pick the installation window that works for you. We handle the logistics']].map(([t,d]) => `<div style="margin-bottom:12px;"><div style="font-size:12px;font-weight:700;color:#1a1a1a;">${t}</div><div style="font-size:11px;color:#555;line-height:1.45;">${d}</div></div>`).join('')}</div></div><div><div style="font-size:18px;font-weight:800;color:#ee001e;margin-bottom:2px;">Your proven, three-step journey</div><div style="font-size:11px;color:#888;margin-bottom:16px;">Efficient. Predictable. Outcome-driven.</div><div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;align-items:start;"><div>${[['Plan for success','We help you prepare for a smooth rollout, minimizing disruption to your business and accelerating ROI.'],['Install with confidence','Our professional installers are experts at installing fleet management solutions, ensuring your installation goes right the first time to minimize fleet downtime.'],['Activate day-one impact','Gain instant access to live tracking, real-time alerts, and the insights required to improve driver safety and operational efficiency, reduce fuel costs, and stay compliant.']].map(([t,d]) => `<div style="margin-bottom:14px;"><div style="font-size:12px;font-weight:700;color:#1a1a1a;margin-bottom:4px;">${t}</div><div style="font-size:11px;color:#555;line-height:1.5;">${d}</div></div>`).join('')}</div><div style="background:#4a5568 url('${CREW_IMG}') center/cover no-repeat;min-height:220px;border-radius:4px;"></div></div></div>`;
       pages.push(wrapPage(page2, pageNum++));
     }

     // ── PAGE 3: Case Study (optional) — contenido hardcodeado de este archivo, plantilla visual nueva ──
     if (selectedMaterials.has('case-study')) {
       const page3 = `${simpleHeader()}<div style="font-size:11px;font-weight:700;color:#555;margin-bottom:2px;">ROI Success history</div><div style="font-size:20px;font-weight:800;color:#ee001e;margin-bottom:18px;">Safety &amp; Insurance</div><div style="border:1px solid #e0e0e0;border-radius:8px;padding:18px 20px;margin-bottom:18px;"><div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;"><div style="color:#d4a800;font-size:18px;letter-spacing:3px;">&#9733;&#9733;&#9733;&#9733;&#9733;</div><div style="font-size:10px;font-weight:700;color:#555;border:1px solid #ccc;border-radius:4px;padding:3px 8px;">Verified result</div></div><div style="font-size:13px;color:#1a1a1a;margin-bottom:6px;">&quot;Deflected a false claim, saved $200,000 on insurance premiums.&quot;</div><div style="font-size:11px;color:#555;"><strong>Customer:</strong> B.A.M Trucking (Bill Howe)</div><div style="background:#f8f3e9;border:1px solid #e9dfc9;border-radius:6px;padding:12px 14px;margin-top:14px;display:flex;align-items:flex-start;gap:10px;"><span class="material-symbols-outlined" style="font-size:16px;color:#555;flex-shrink:0;margin-top:1px;">verified_user</span><div><div style="font-size:11px;font-weight:700;color:#1a1a1a;margin-bottom:2px;">Proven outcome</div><div style="font-size:11px;color:#444;line-height:1.5;">Reduced accidents by 87%, exonerated drivers from false claims.</div></div></div></div><div style="border:1px solid #e0e0e0;border-radius:8px;overflow:hidden;margin-bottom:24px;"><div style="display:grid;grid-template-columns:1fr 1fr;"><div style="padding:16px 18px;border-right:1px solid #e0e0e0;"><div style="font-size:12px;font-weight:700;margin-bottom:10px;">Common challenges</div><ul style="margin:0;padding-left:16px;font-size:11px;color:#444;line-height:1.9;"><li>False accident claims</li><li>High insurance premiums</li><li>Reputation damage</li></ul></div><div style="padding:16px 18px;"><div style="font-size:12px;font-weight:700;margin-bottom:10px;">Verizon Connect Solution</div><ul style="margin:0;padding-left:16px;font-size:11px;color:#444;line-height:1.9;"><li>Dashcams (Integrated Video)</li><li>Harsh driving alerts</li><li>Driver safety scorecards</li></ul></div></div></div><div style="background:#f5f5f5;margin:0 -24px -24px;padding:36px 24px;text-align:center;"><div style="margin-bottom:10px;"><span class="material-symbols-outlined" style="font-size:28px;color:#1a1a1a;">videocam</span></div><div style="font-size:17px;font-weight:800;color:#1a1a1a;margin-bottom:8px;">Want to see the full story?</div><div style="font-size:12px;color:#666;margin-bottom:22px;">Scan or click below to view the full success story and video testimonial.</div><div style="display:inline-block;color:#0B5FFF;font-size:13px;font-weight:700;text-decoration:underline;cursor:default;">View details</div></div>`;
       pages.push(wrapPage(page3, pageNum++));
     }

     // ── PAGE 4: ROI / Business Impact Analysis (optional) ─────────
     if (selectedMaterials.has('roi')) {
       let totalUnitsAll = 0;
       options.forEach(opt => opt.bundles.forEach(b => { totalUnitsAll += b.qty; }));
       const fleetSize = totalUnitsAll || 50;
       const cfg = getRoiConfig();
       const weeksPerMonth = 52 / 12;
       let grossMonthly = 0;
       const roiRows = [];

       if (cfg.productivity.enabled) {
         const { billingMethod, avgBillRate, jobsPerWeek, efficiencyGain } = cfg.productivity;
         const monthlyGain = avgBillRate * jobsPerWeek * (efficiencyGain / 100) * fleetSize * weeksPerMonth;
         grossMonthly += monthlyGain;
         const methodLabel = billingMethod === 'perHour' ? 'Hrs/Wk/Veh' : 'Jobs/Wk/Veh';
         roiRows.push({ icon: 'trending_up', title: 'Productivity', detail: `${methodLabel}: ${jobsPerWeek} &nbsp;|&nbsp; Rate: $${avgBillRate.toFixed(2)} &nbsp;|&nbsp; Gain: ${efficiencyGain}%`, label: 'Monthly Gain', value: formatMoney(monthlyGain) });
       }

       if (cfg.fuel.enabled) {
         const { costPerGallon, galSavedPerWeekVeh } = cfg.fuel;
         const monthlyGain = costPerGallon * galSavedPerWeekVeh * fleetSize * weeksPerMonth;
         grossMonthly += monthlyGain;
         roiRows.push({ icon: 'local_gas_station', title: 'Fuel Cost Reduction', detail: `Avg: $${costPerGallon}/gal &nbsp;|&nbsp; Saved: ${galSavedPerWeekVeh} gal/wk`, label: 'Monthly Gain', value: formatMoney(monthlyGain) });
       }

       if (cfg.payroll.enabled) {
         const { otHoursPerWeek, hourlyRate, includeMaint, maintSavePerVeh } = cfg.payroll;
         const payrollMonthly = hourlyRate * otHoursPerWeek * fleetSize * weeksPerMonth;
         const maintMonthly = includeMaint ? (maintSavePerVeh * fleetSize / 12) : 0;
         const totalMonthlyPayroll = payrollMonthly + maintMonthly;
         grossMonthly += totalMonthlyPayroll;
         const detail = `Rate: $${hourlyRate}/hr &nbsp;|&nbsp; Reduced: ${otHoursPerWeek} hrs/wk${includeMaint ? ` &nbsp;|&nbsp; Maint: $${maintSavePerVeh}/veh/yr` : ''}`;
         roiRows.push({ icon: 'attach_money', title: 'Payroll' + (includeMaint ? ' &amp; Maintenance' : ' Optimization'), detail, label: 'Monthly Savings', value: formatMoney(totalMonthlyPayroll) });
       }

       const safetyEnabled = cfg.safety.hasVideo;
       let estAnnualLiability = 0;
       if (safetyEnabled) {
         const { avgAccidentCost, accidentsPerYear, liabilityPct } = cfg.safety;
         estAnnualLiability = avgAccidentCost * accidentsPerYear * (liabilityPct / 100);
         const safetyMonthly = estAnnualLiability / 12;
         grossMonthly += safetyMonthly;
         roiRows.push({ icon: 'shield', title: 'Safety &amp; Cameras', detail: `Avg Accident: $${avgAccidentCost.toLocaleString()} &nbsp;|&nbsp; Liability reduction: ${liabilityPct}%`, label: 'Est. Monthly Savings', value: formatMoney(safetyMonthly) });
       }

       let sysInvestment = 0;
       if (options.length > 0) {
         const firstOpt = options[0];
         const { totalMonthly } = calcOption(firstOpt, getOptionPromotion(firstOpt), firstOpt.forcedTierIndex ?? -1);
         sysInvestment = totalMonthly;
       }
       const netBenefit = grossMonthly - sysInvestment;
       const roiRatio = sysInvestment > 0 ? (grossMonthly / sysInvestment).toFixed(1) : '—';

       const roiRowsHtml = roiRows.map(r => `<div style="display:flex;justify-content:space-between;align-items:center;padding:13px 0;border-bottom:1px solid #f0f0f0;"><div style="display:flex;align-items:center;gap:12px;"><div style="width:36px;height:36px;border:1px solid #e0e0e0;border-radius:6px;display:flex;align-items:center;justify-content:center;flex-shrink:0;"><span class="material-symbols-outlined" style="font-size:18px;color:#555;">${r.icon}</span></div><div><div style="font-size:12px;font-weight:700;color:#1a1a1a;margin-bottom:2px;">${r.title}</div><div style="font-size:10px;color:#888;">${r.detail}</div></div></div><div style="text-align:right;flex-shrink:0;"><div style="font-size:10px;color:#888;margin-bottom:1px;">${r.label}</div><div style="font-size:14px;font-weight:700;color:#1a1a1a;">${r.value}</div></div></div>`).join('');

       const page4 = `${simpleHeader()}<div style="font-size:20px;font-weight:800;color:#ee001e;margin-bottom:4px;">Business Impact Analysis</div><div style="margin-bottom:18px;">${roiRowsHtml || '<div style="font-size:12px;color:#aaa;padding:16px 0;text-align:center;">No categories selected.</div>'}</div><div style="background:#f8f3e9;margin:0 -24px 22px;padding:20px 24px;text-align:center;"><div style="font-size:14px;font-weight:800;color:#ee001e;margin-bottom:2px;">Estimated Monthly Financial Impact</div><div style="font-size:10px;color:#888;margin-bottom:16px;">Based on fleet size: ${fleetSize}</div><div style="display:flex;align-items:center;justify-content:center;gap:14px;flex-wrap:wrap;"><div><div style="font-size:22px;font-weight:900;color:#1a1a1a;">${formatMoney(grossMonthly)}</div><div style="background:#16a34a;color:#fff;font-size:9px;font-weight:700;border-radius:3px;padding:2px 7px;margin-top:4px;display:inline-block;">Gross Monthly Savings</div></div><div style="font-size:22px;color:#555;font-weight:300;">−</div><div><div style="font-size:22px;font-weight:900;color:#1a1a1a;">${formatMoney(sysInvestment)}</div><div style="background:#1d4ed8;color:#fff;font-size:9px;font-weight:700;border-radius:3px;padding:2px 7px;margin-top:4px;display:inline-block;">System Investment</div></div><div style="font-size:22px;color:#555;font-weight:300;">=</div><div><div style="font-size:22px;font-weight:900;color:#1a1a1a;">${formatMoney(netBenefit)}</div><div style="background:#1d4ed8;color:#fff;font-size:9px;font-weight:700;border-radius:3px;padding:2px 7px;margin-top:4px;display:inline-block;">Net Monthly Benefit</div></div></div><div style="font-size:11px;color:#555;margin-top:12px;">ROI Ratio ${roiRatio}:1</div></div>${safetyEnabled ? `<div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;align-items:start;"><div><div style="font-size:14px;font-weight:800;color:#1a1a1a;margin-bottom:8px;">Video Safety ROI and Liability Protection</div><div style="font-size:11px;color:#444;line-height:1.65;">Implementing Video Telematics (Dash Cams) significantly reduces liability exposure by providing exonerating evidence in false claims and improving driver behavior. Industry data suggests commercial fleets can reduce accident frequency by up to 40%.*</div></div><div style="border:1px solid #e0e0e0;border-radius:8px;padding:16px;"><div style="margin-bottom:12px;"><div style="font-size:10px;color:#888;margin-bottom:2px;">AVG Cost of Accident</div><div style="font-size:13px;font-weight:700;color:#1a1a1a;">${formatMoney(cfg.safety.avgAccidentCost)}</div></div><div style="margin-bottom:12px;"><div style="font-size:10px;color:#888;margin-bottom:2px;">EST Accidents Avoided</div><div style="font-size:13px;font-weight:700;color:#1a1a1a;">${cfg.safety.accidentsPerYear} / Year</div></div><div><div style="font-size:10px;color:#888;margin-bottom:2px;">EST Annual Liability Savings</div><div style="font-size:14px;font-weight:800;color:#ee001e;">${formatMoney(estAnnualLiability)}</div><div style="font-size:10px;color:#888;">Non-recurring / Insurance</div></div></div></div>` : ''}`;
       pages.push(wrapPage(page4, pageNum++));
     }

     viewer.innerHTML = pages.join('');
     fillProposalMessageDefaults();
     requestAnimationFrame(scaleDocPages);
   }

No toques calcBundle, getEvcTypeLabel, getRoiConfig, getSelectedMaterials,
calcOption, getOptionPromotion, formatMoney, parseProposalDate,
formatUsDate, ni ningún otro lugar del archivo — este cambio es solo
renderProposalDoc() completa más las 2 funciones nuevas del paso 1.

Verifica al final: abrir "Review & Send Proposal" con 2+ opciones
agregadas muestra una página por opción (no todas juntas), cada página
con el bloque negro "Master Service Agreement" arriba de la tabla de
precios mostrando Min. spend commitment / Contract Date / Term /
Ramp-up period con los valores reales de proposalData. Las páginas
opcionales (Onboarding, Case Study, ROI) se siguen agregando según los
materiales seleccionados, con el mismo footer/paginación en todas.
```

---

## 13. Cuentas existentes — que la pantalla de entrada a "Review & Send Proposal" se vea igual a cuentas nuevas, sin migrar el editor (2026-09-08)

**Contexto:** Catalina pidió, con alcance acotado explícitamente por ella: "no quiero migrar toda la funcionalidad de editar pero sí quiero que visualmente cuando entras al modal se vea igual." Es SOLO sobre la pantalla que aparece al abrir "Review & Send Proposal" (el modal), no sobre el editor completo.

Hoy, al abrir ese modal, se ve siempre la vista dividida completa (Message a la izquierda, documento completo a la derecha). En la versión de referencia (cuentas nuevas), la pantalla de entrada es un resumen con dos cards chiquitas — "Email body" y "PDF" — cada una con una miniatura del contenido y un botón "Edit" que por ahora no hace nada.

**3 decisiones de alcance confirmadas — no asumidas:**
1. Los botones "Edit" de las dos cards no hacen nada (deshabilitados, `disabled`). No se construye ningún editor ni vista dividida nueva.
2. El dropdown de "Materials" y el panel de configuración de ROI quedan inaccesibles desde la UI por ahora — se usan con los valores que ya tengan por defecto para armar el PDF y el email.
3. No se agrega ningún bloque de "Rep info" editable en la cabecera — eso no existe hoy en este archivo y no es parte de este pedido.

**Cómo se hace, sin romper nada:** todo el HTML que hoy está siempre visible (`prop-msg-to`, `prop-msg-subject`, `prop-msg-body`, el panel de ROI, el dropdown de materiales, `#prop-doc-viewer`) NO se borra — sigue existiendo en el DOM, pero se envuelve dentro de un contenedor oculto (`hidden`), porque `renderProposalDoc()`, `fillProposalMessageDefaults()`, `getSelectedMaterials()` y `getRoiConfig()` lo siguen leyendo por ID. Encima de ese contenedor oculto se agregan las dos cards nuevas con miniatura.

Verificado en vivo (2026-09-08) antes de escribir este prompt: el bloque `.proposal-review-modal` (línea 1821) y el contenido de `#proposal-review-layout` (abre en la línea 5078: `<div class="review-content-layout" id="proposal-review-layout">`) coinciden con lo esperado — adentro están `.review-message-pane#proposal-message-pane` (mensaje + panel de ROI) y `.review-preview-pane` (fecha de expiración/cierre, dropdown de materiales, `.review-preview-card > #prop-doc-viewer`). El cierre de `#proposal-review-layout` es el `</div>` que viene justo antes de `<div class="proposal-review-modal-actions">`.

**Prompt para pegar en el agente:**

```
Trabaja en app/demos/valucal_existing_accounts.html.

Objetivo: la pantalla de entrada al modal "Review & Send Proposal" pasa
de mostrar siempre la vista dividida completa a mostrar un resumen con
dos cards con miniatura ("Email body" y "PDF") con botones "Edit"
deshabilitados. El contenido real (mensaje, ROI, materiales, documento)
sigue existiendo en el DOM oculto — no se borra nada, solo se envuelve.

Haz estos 5 cambios:

1. Busca la regla CSS exacta:

   .proposal-review-modal {
     width: min(1280px, 96vw);
     max-height: 92vh;
     overflow: hidden;
     background: #F9FAFB;
     border-radius: 10px;
     display: flex;
     flex-direction: column;
   }

   reemplázala por:

   .proposal-review-modal {
     --proposal-pdf-surface: #ffffff;
     --proposal-header-surface: #f8f3ea;
     --proposal-header-band-height: 52px;
     --proposal-modal-pad-x: 12px;
     width: min(1700px, 90vw);
     height: 95vh;
     max-height: 95vh;
     overflow: hidden;
     background: #ffffff;
     border-radius: 10px;
     display: flex;
     flex-direction: column;
   }

2. Agrega este bloque de CSS nuevo en cualquier parte de la hoja de
   estilos (no reemplaza nada, verifica primero que no exista ya una
   regla `.proposal-customization-grid` para no duplicar):

   .proposal-general-direct {
     padding: 6px var(--proposal-modal-pad-x);
     margin-bottom: 0;
     border-bottom: 1px solid var(--gray-200);
     background: var(--white);
   }
   .proposal-general-card {
     border: 0;
     border-radius: 0;
     background: transparent;
     padding: 0;
   }
   .proposal-customization-grid {
     display: grid;
     grid-template-columns: repeat(2, minmax(0, 1fr));
     flex: 1;
     width: 100%;
     min-width: 0;
     min-height: 0;
     align-items: stretch;
     gap: 0;
     border: 1px solid #d7dde5;
     border-radius: 12px;
     overflow: hidden;
     background: #fff;
     box-shadow: 0 1px 2px rgba(16, 24, 40, 0.04);
   }
   .proposal-customization-wrap {
     flex: 1;
     width: 100%;
     min-height: 0;
     display: flex;
     box-sizing: border-box;
     overflow: hidden;
     padding: 12px 12px 12px;
     background: transparent;
   }
   .proposal-customization-card {
     border: 0;
     border-radius: 0;
     min-width: 0;
     min-height: 0;
     display: flex;
     flex-direction: column;
     padding: 0;
     background: transparent;
   }
   .proposal-customization-thumb {
     position: relative;
     border: 0;
     border-radius: 0;
     background: transparent;
     height: auto;
     min-height: 210px;
     flex: 1;
     overflow: hidden;
     margin-bottom: 0;
   }
   .proposal-customization-thumb__inner {
     width: 100%;
     height: 100%;
     overflow-y: auto;
     overflow-x: hidden;
     position: relative;
     padding-right: 0;
   }
   .proposal-customization-thumb__fade {
     position: absolute;
     left: 0;
     right: 0;
     bottom: 0;
     height: 58px;
     background: linear-gradient(180deg, rgba(255,255,255,0) 0%, #fff 88%);
     pointer-events: none;
     display: none;
   }
   .proposal-customization-thumb .doc-page-outer { margin-bottom: 8px; }
   .proposal-customization-message-frame {
     padding: 12px 14px 16px;
     font-size: 12px;
     line-height: 1.5;
     color: #1a1a1a;
   }
   .proposal-customization-message-frame .msg-chip { font-size: 11px; }
   .proposal-customization-empty {
     height: 100%;
     display: flex;
     align-items: center;
     justify-content: center;
     color: var(--gray-600);
     font-size: 12px;
   }
   .proposal-customization-card__head {
     display: grid;
     grid-template-columns: minmax(0, 1fr) auto;
     align-items: center;
     column-gap: 8px;
     background: var(--proposal-header-surface);
     padding-top: 8px;
     padding-right: 12px;
     padding-bottom: 10px;
     margin-bottom: 0;
     min-height: var(--proposal-header-band-height);
     box-sizing: border-box;
     position: relative;
   }
   .proposal-customization-head-actions {
     display: inline-flex;
     align-items: center;
     gap: 8px;
     justify-self: end;
   }
   .proposal-customization-card__title {
     display: flex;
     align-items: center;
     min-height: 32px;
     font-size: 14px;
     font-weight: 700;
     line-height: 1.1;
   }
   .proposal-customization-edit-btn {
     height: 32px !important;
     min-height: 32px !important;
     padding: 0 12px !important;
     font-size: 14px;
   }
   .proposal-customization-icon-btn {
     width: 32px;
     height: 32px;
     min-height: 32px;
     border: 1.5px solid var(--black);
     border-radius: 999px;
     background: transparent;
     color: var(--black);
     display: inline-flex;
     align-items: center;
     justify-content: center;
     cursor: pointer;
   }
   .proposal-customization-icon-btn .material-symbols-outlined { font-size: 18px; }
   .proposal-customization-card--pdf .proposal-customization-thumb {
     background: var(--proposal-pdf-surface);
     margin-bottom: 0;
   }
   .proposal-customization-card--pdf .proposal-customization-thumb__inner {
     display: flex;
     flex-direction: column;
     align-items: flex-start;
     justify-content: flex-start;
     gap: 8px;
     background: var(--proposal-pdf-surface);
     padding: 10px 0 0;
     margin: 0;
     scrollbar-color: #c2c2c2 var(--proposal-pdf-surface);
   }
   .proposal-customization-card--pdf #customization-pdf-preview {
     display: flex;
     flex-direction: column;
     width: 100%;
     background: var(--proposal-pdf-surface) !important;
     padding: 10px 0 0 !important;
     margin: 0 !important;
   }
   .proposal-customization-card--pdf #customization-pdf-preview .doc-page-outer {
     height: auto !important;
     overflow: visible !important;
   }
   .proposal-customization-card--pdf #customization-pdf-preview .vc-doc-shell {
     width: 90% !important;
     max-width: 90% !important;
     transform: none !important;
     margin-left: auto !important;
     margin-right: auto !important;
   }
   .proposal-customization-card--pdf .proposal-customization-thumb__inner .doc-page-outer {
     margin-left: 0;
     margin-right: 0;
     margin-top: 0;
     margin-bottom: 0;
   }
   .proposal-customization-card--pdf {
     --proposal-pdf-surface: var(--gray-100);
     background: var(--proposal-pdf-surface);
     border-left: 1px solid var(--gray-200);
     border-radius: 0;
     padding: 0;
   }
   .proposal-customization-card--pdf .proposal-customization-thumb__fade {
     background: linear-gradient(180deg, rgba(248,247,245,0) 0%, var(--proposal-pdf-surface) 88%);
   }
   .proposal-customization-card--message {
     border: 0;
     border-radius: 0;
     background: var(--white);
     padding: 0;
   }
   .proposal-customization-card--message .proposal-customization-card__head {
     margin-bottom: 0;
     padding-left: 12px;
     padding-right: 12px;
   }
   .proposal-customization-card--pdf .proposal-customization-card__head {
     margin-left: 0;
     padding-left: 12px;
     padding-right: 12px;
     background: var(--proposal-header-surface);
   }
   .proposal-customization-card--message .proposal-customization-thumb__inner { overflow-y: auto; }

3. Busca la etiqueta de apertura exacta (línea única en el archivo):

   <div class="review-content-layout" id="proposal-review-layout">

   reemplázala por (agrega las 2 cards nuevas visibles, y abre un
   contenedor oculto que envolverá TODO el contenido que ya existe
   después de esta línea):

   <div class="review-content-layout" id="proposal-review-layout">
     <div class="proposal-general-direct">
       <div class="proposal-general-card">
         <div style="display:flex; gap:16px; align-items:flex-end; flex-wrap:wrap;">
           <div class="proposal-review-field" style="flex:0 0 160px;">
             <div class="proposal-review-label">Expiration date</div>
             <input type="date" id="proposal-expiration-date-visible" class="vds-input proposal-date-input" lang="en-US" oninput="document.getElementById('proposal-expiration-date').value=this.value; onProposalExpirationChange(); updateSendBtn()">
           </div>
           <div class="proposal-review-field" style="flex:0 0 160px;">
             <div class="proposal-review-label">Close date</div>
             <input type="date" id="proposal-close-date-visible" class="vds-input proposal-date-input" lang="en-US" oninput="document.getElementById('proposal-close-date').value=this.value; updateSendBtn()" required>
             <div id="close-date-error-visible" class="proposal-field-error hidden">Required to send</div>
           </div>
         </div>
       </div>
     </div>

     <div class="proposal-customization-wrap">
       <div class="proposal-customization-grid">
         <div class="proposal-customization-card proposal-customization-card--message">
           <div class="proposal-customization-card__head">
             <div class="proposal-customization-card__title">Email body</div>
             <button type="button" class="btn btn--secondary btn--small proposal-customization-edit-btn" disabled title="Coming soon">Edit</button>
           </div>
           <div class="proposal-customization-thumb" aria-hidden="true">
             <div id="customization-message-preview" class="proposal-customization-thumb__inner"></div>
             <div class="proposal-customization-thumb__fade"></div>
           </div>
         </div>
         <div class="proposal-customization-card proposal-customization-card--pdf">
           <div class="proposal-customization-card__head">
             <div class="proposal-customization-card__title">PDF</div>
             <div class="proposal-customization-head-actions">
               <button type="button" class="proposal-customization-icon-btn" onclick="downloadPdfFromModal()" aria-label="Download proposal preview" title="Download">
                 <span class="material-symbols-outlined">download</span>
               </button>
               <button type="button" class="btn btn--secondary btn--small proposal-customization-edit-btn" disabled title="Coming soon">Edit</button>
             </div>
           </div>
           <div class="proposal-customization-thumb" aria-hidden="true">
             <div id="customization-pdf-preview" class="proposal-customization-thumb__inner"></div>
             <div class="proposal-customization-thumb__fade"></div>
           </div>
         </div>
       </div>
     </div>

     <!-- Oculto: sigue siendo la fuente de datos real para renderProposalDoc()/fillProposalMessageDefaults()/getSelectedMaterials()/getRoiConfig(). -->
     <div class="hidden" id="proposal-review-hidden-source" aria-hidden="true">

   IMPORTANTE — nota sobre los inputs de fecha: en vez de borrar o
   duplicar los IDs `proposal-expiration-date`/`proposal-close-date`
   (que otras funciones ya leen por ese ID exacto), los inputs nuevos
   de arriba usan IDs distintos (`-visible`) y, en su `oninput`, copian
   el valor al input oculto original antes de llamar a las funciones
   existentes — así no hay que tocar `onProposalExpirationChange()`,
   `updateSendBtn()` ni ninguna otra función que ya lee
   `proposal-expiration-date`/`proposal-close-date` por ID.

4. Busca la etiqueta de cierre exacta: el `</div>` que cierra
   `#proposal-review-layout`, identificado porque es el único `</div>`
   que aparece INMEDIATAMENTE antes de la línea:

   <div class="proposal-review-modal-actions">

   Reemplaza ese `</div>` (solo esa línea) por dos líneas (cierra el
   contenedor oculto que abriste en el paso 3, y luego cierra
   `#proposal-review-layout` como ya cerraba antes):

   </div>
   </div>

5. Agrega estas 2 funciones nuevas en cualquier parte del <script>
   principal, antes de renderProposalDoc() (o justo después, no importa
   el orden mientras estén definidas antes de que se llamen):

   function renderCustomizationThumbnails() {
     const pdfThumb = document.getElementById('customization-pdf-preview');
     const msgThumb = document.getElementById('customization-message-preview');
     const sourceDoc = document.getElementById('prop-doc-viewer');
     const bodyEl = document.getElementById('prop-msg-body');

     if (pdfThumb) {
       pdfThumb.innerHTML = '';
       const pages = sourceDoc ? Array.from(sourceDoc.querySelectorAll('.doc-page-outer')) : [];
       if (pages.length) {
         pages.forEach(function (page) { pdfThumb.appendChild(page.cloneNode(true)); });
       } else {
         pdfThumb.innerHTML = '<div class="proposal-customization-empty">Preview unavailable</div>';
       }
     }

     if (msgThumb) {
       const messageHtml = bodyEl && bodyEl.innerHTML ? bodyEl.innerHTML : '<em>No message content yet.</em>';
       msgThumb.innerHTML = '<div class="proposal-customization-message-frame">' + messageHtml + '</div>';
     }
   }

   function syncProposalReviewVisibleDateInputs() {
     const expHidden = document.getElementById('proposal-expiration-date');
     const expVisible = document.getElementById('proposal-expiration-date-visible');
     if (expHidden && expVisible) expVisible.value = expHidden.value;
     const closeHidden = document.getElementById('proposal-close-date');
     const closeVisible = document.getElementById('proposal-close-date-visible');
     if (closeHidden && closeVisible) closeVisible.value = closeHidden.value;
   }

6. Dentro de renderProposalDoc() (la versión reemplazada en la Sección
   12 de este plan si ya se aplicó, o la que esté ahora), busca las 3
   líneas finales:

   viewer.innerHTML = pages.join('');
   fillProposalMessageDefaults();
   requestAnimationFrame(scaleDocPages);

   y agrega 2 líneas más (refresca las miniaturas y sincroniza las
   fechas visibles cada vez que se re-renderiza el documento):

   viewer.innerHTML = pages.join('');
   fillProposalMessageDefaults();
   requestAnimationFrame(scaleDocPages);
   renderCustomizationThumbnails();
   syncProposalReviewVisibleDateInputs();

No toques prop-msg-to, prop-msg-subject, prop-msg-body, el panel de
ROI (roi-config-section), el dropdown de materiales
(materials-btn/materials-menu), ni #prop-doc-viewer — todo eso sigue
existiendo tal cual, solo ahora está dentro del contenedor oculto
#proposal-review-hidden-source. No borres ninguna función existente
(fillProposalMessageDefaults, getSelectedMaterials, getRoiConfig,
toggleMaterialsMenu, onRoiChange, etc.) — todas se siguen llamando
igual, solo que sus campos de origen ya no son visibles en la entrada
al modal.

Verifica al final: (a) al abrir "Review & Send Proposal" se ve la
pantalla resumen con dos cards con miniatura, "Email body" y "PDF",
cada una con un botón "Edit" que no hace nada (deshabilitado); (b) los
campos Expiration date / Close date siguen arriba, visibles y
funcionando (cambiar la fecha sigue habilitando/deshabilitando el
botón "Send Proposal" igual que antes); (c) las miniaturas muestran el
contenido real del documento y del mensaje, no un placeholder vacío;
(d) no hay ningún error de consola por IDs duplicados.
```
