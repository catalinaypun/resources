# MSA — Cuentas existentes: contexto y trabajo pendiente

**Nota:** este archivo se reconstruyó el 2026-09-07 y se revisó y actualizó a fondo el 2026-09-08, una vez que el flujo de MSA para **cuentas nuevas** quedó terminado en `backups/valucal-mvp-backup-2026-08-25-production-msa/index.html`. Cada punto de abajo se verificó contra el código real de `app/demos/valucal_existing_accounts.html` en esa fecha — los números de línea y nombres de función están confirmados, no son de memoria.

**Corrección importante (2026-09-07, sigue vigente):** el punto 1 de este documento se reescribió por completo. La primera versión asumía que había que agregar los campos del MSA dentro de `#account-setup-overlay` (el modal chiquito de Zip Code/Tax ID/Phone). Eso estaba mal — ese modal es el equivalente exacto del modal de validación básica que también existe en `index.html` (mismo patrón, mismos 3 campos, mismas funciones `saveAccountSetup()`/`updateAccountSetupSaveState()`) y no debe tocarse. La pantalla con los campos de MSA (Subscription, Contract term, Term start date, etc.) es un archivo **completamente aparte**: `account-setup.html`. En `index.html` esa pantalla se abre embebida en un iframe (`openAccountSetupEmbed()`); en `valucal_existing_accounts.html` se abre en pestaña nueva vía `openAccountSetupEntry()` (línea ~7559) — que ya apunta a `account-setup.html`, solo que sin pasarle ningún dato. Lo único que falta es que, para una cuenta existente, esos campos lleguen ya llenos.

**Gap abierto en cuentas nuevas — avísenme cuando se cierre:** el punto 8 del plan de cuentas nuevas ("Minimum spend commitment" pasa a ser de solo lectura, con default $2000) todavía **no está aplicado** en `account-setup.html` — verificado el 2026-09-08, el campo sigue editable ("Edit →", valor "--"). El punto 1 de este documento (abajo) asume que ese campo puede seguir siendo editable por ahora; si el punto 8 se aplica antes de portar esto, el equivalente para cuentas existentes también debería volverse de solo lectura, pero mostrando el valor real ya comprometido por esa cuenta (no el default de $2000, que solo aplica a cuentas nuevas sin historial).

---

## 1. Que `account-setup.html` abra con los campos de MSA ya llenos cuando se navega desde cuentas existentes

**Contexto:** `account-setup.html` es el mismo archivo para cuentas nuevas y existentes — no hay que duplicarlo ni reconstruirlo. La diferencia es que en cuentas nuevas los campos de MSA arrancan vacíos ("--"), y en cuentas existentes deberían llegar ya con los valores reales del MSA que esa cuenta ya tiene, porque no se está creando un MSA nuevo, se está mostrando uno que ya existe.

**Campos reales — verificado el 2026-09-08 en `account-setup.html` (`state.accountInfo`, línea ~991-996):** son 5, no 6. El campo `msaMinimumServiceTerm` que aparecía en la versión anterior de este documento **ya no existe en la UI** — se eliminó por completo (fila + heading "Service Order Term") como parte de la limpieza de cuentas nuevas del 2026-09-08 (quitar "Service order term", dejar solo "Contract term"). Sigue como llave muerta en `state.accountInfo` pero no tiene fila visible ni se debe llenar.

Los 5 campos reales, con sus IDs (`val-<campo>` / `input-<campo>`) y su formato de visualización (`displayValues`, línea ~1239-1257):
- `msaSubscriptionPrice` → label "Subscription, unit/month" → se muestra como `$X.XX/mo`
- `msaMinimumSpendCommitment` → label "Minimum spend commitment" → se muestra como `$X.XX/mo`
- `msaTermStart` → label "Contract Start Date" (así quedó, no "Term start date" — deviación de VS que Catalina no ha decidido corregir aún) → tipo `<input type="date">`, se combina con `msaContractTerm` para mostrar el rango inicio–fin vía `formatMsaTermValueHtml()`/`renderMsaTermStartValue()`
- `msaContractTerm` → label "Contract term, months" → `<select>` con opciones 12/24/36/48/60
- `msaRampUpPeriod` → label "Ramp-up period, days" → default `'30'`

**Piezas a tocar:**

1. **`valucal_existing_accounts.html` — agregar los campos de MSA a `proposalData`** (junto a `msaId: ''`, línea ~8053, donde ya existe `msaEndDate`). Esta cuenta de demo ya simula tener un MSA (usa `MSA-DEMO` / `2028-01-01` como fallback en varios lados) pero no trackea el detalle fino. Agregar, con valores de ejemplo razonables:
   ```js
   msaSubscriptionPrice:        34.00,
   msaMinimumSpendCommitment:   870.00,
   msaTermStart:                '2025-01-01',
   msaContractTerm:             36,
   msaRampUpPeriod:             30,
   ```

2. **`valucal_existing_accounts.html` — `openAccountSetupEntry()`** (línea ~7559). Hoy es:
   ```js
   function openAccountSetupEntry() {
     const target = isPublishedFlowRuntime()
       ? buildFlowUrl('valucal-account-setup')
       : 'account-setup.html';
     window.open(target, '_blank');
   }
   ```
   Reemplazar por (usa `buildFlowUrl(flowName, extraParams)`, que ya acepta un segundo argumento para agregar query params — línea ~7545):
   ```js
   function openAccountSetupEntry() {
     const msaParams = {
       msaSubscriptionPrice:      proposalData.msaSubscriptionPrice,
       msaMinimumSpendCommitment: proposalData.msaMinimumSpendCommitment,
       msaTermStart:              proposalData.msaTermStart,
       msaContractTerm:           proposalData.msaContractTerm,
       msaRampUpPeriod:           proposalData.msaRampUpPeriod,
     };
     let target;
     if (isPublishedFlowRuntime()) {
       target = buildFlowUrl('valucal-account-setup', msaParams);
     } else {
       const params = new URLSearchParams();
       Object.keys(msaParams).forEach((key) => {
         if (msaParams[key] != null) params.set(key, msaParams[key]);
       });
       const query = params.toString() ? `?${params.toString()}` : '';
       target = 'account-setup.html' + query;
     }
     window.open(target, '_blank');
   }
   ```

3. **`account-setup.html` — `init()`** (línea 1790-1819, confirmado 2026-09-08). Agregar justo antes de la línea `renderMsaTermStartValue();` (línea 1812):
   ```js
   const urlParams = new URLSearchParams(window.location.search);
   const msaUrlKeys = ['msaSubscriptionPrice', 'msaMinimumSpendCommitment', 'msaTermStart', 'msaContractTerm', 'msaRampUpPeriod'];
   msaUrlKeys.forEach((key) => {
     if (urlParams.has(key)) {
       state.accountInfo[key] = urlParams.get(key);
       const valEl = document.getElementById('val-' + key);
       if (valEl && displayValues[key]) valEl.textContent = displayValues[key](state.accountInfo[key]);
     }
   });
   ```
   La línea `renderMsaTermStartValue();` que ya está ahí, justo después, recalcula el rango start–end con los valores recién cargados — no hace falta duplicarla.

**Efecto:** al hacer clic en "Account Setup" desde `valucal_existing_accounts.html`, se abre el mismo `account-setup.html` de siempre, pero con Subscription, Minimum spend commitment, Contract term, Contract Start Date (con su rango calculado) y Ramp-up period ya mostrando valores reales en vez de "--" — sin duplicar ninguna pantalla ni patrón de UI.

**Pendiente de decidir:** los valores de ejemplo del punto 1 (`34.00`, `870.00`, `2025-01-01`, etc.) son solo un placeholder razonable — si Catalina tiene valores reales de referencia para la cuenta de demo de "cuentas existentes", reemplazarlos ahí.

---

## 2. Portar el mecanismo COMPLETO de descuento MSA — slider + tier jump — a `valucal_existing_accounts.html`

**Actualización 2026-09-08: este punto reemplaza y absorbe lo que antes eran los puntos 2 y 4 por separado.** Cuando se escribió la primera versión de este documento, el tier jump todavía no estaba diseñado ni construido en cuentas nuevas, así que se planteó portar primero el slider simple y, más adelante, portar el tier jump aparte. Ya no hace falta hacerlo en dos pasos: el tier jump quedó completamente diseñado y construido en `index.html` el 2026-09-08 (punto 11 de `msa-new-accounts-implementation-plan.md`), así que este punto porta la versión FINAL de una sola vez.

**Contexto:** esta lógica ya está construida y probada en `backups/valucal-mvp-backup-2026-08-25-production-msa/index.html`. `valucal_existing_accounts.html` tiene el mismo modal "Configure Bundle" con dropdown de "Promotion" en el mismo estado en el que estaba `index.html` antes de estos cambios — mismo `corePricing`, mismo `volumeTiers`, mismo `calcBundle()`, mismo dropdown de Promotion, y **el mismo `renderOptions()`/`getApprovalRole()`/`getNaturalTierIndex()`** que usa el mecanismo viejo de aprobación por `volumeTiers` (verificado 2026-09-08 — están en las líneas ~7320-7345 y ~8744). Se porta el mismo mecanismo nuevo encima, sin tocar ese viejo.

**Diferencia importante verificada en este archivo — NO tiene keyfobs.** `index.html` sí maneja keyfobs (`getKeyfobPrice()`, `keyfob-qty`) dentro de `updateBundlePreview()`; `valucal_existing_accounts.html` no — su `updateBundlePreview()` (línea ~8666) y `createBundle()` (línea ~8693) son más simples. El código de abajo ya está adaptado a esta versión sin keyfobs — **no copiar tal cual el código de `index.html`, usar el de aquí.**

**Otra diferencia:** en `openConfigureBundle()` (línea ~8256) de este archivo, editar un bundle existente (`bundleId` presente) no recarga `bld.coreKey`/`bld.corePrice`/etc. desde el bundle guardado — es una limitación que ya existe hoy, no la introduce este cambio, y queda fuera de alcance arreglarla aquí.

**Alcance del tier jump — importante:** al igual que en cuentas nuevas, esto es SOLO para el slider dentro del modal "Configure Bundle" de este flujo (creación/edición de bundles en una opción). El tier jump "de afuera"/del cart (`volumeTiers`, `opt.forcedTierIndex`, el bloque `requiresApproval`/`actionHtml` en `renderOptions()` que ya existe y bloquea el botón "Select & Create Quote") es un mecanismo aparte, no se toca. Es exactamente el mismo mecanismo viejo, ya presente en este archivo, que en cuentas nuevas.

**Decisiones de diseño acordadas con Catalina (aplican igual aquí):**
1. El slider cubre las 4 tiers completas (A-D, 0-25%), con marcas A/B/C/D debajo.
2. Si hay tier jump, se muestra un aviso informativo dentro del modal — reusando `getApprovalRole(skip)`, que ya existe en este archivo (línea ~7340). No se construye ningún flujo real de aprobación (nada de `approvalStatus`, snackbar, Pending/Approved) — es puramente informativo.
3. Guardar el bundle (`createBundle()`) NO se bloquea por tier jump.
4. En la card del cart (`renderOptions()`, línea ~8744), cada bundle con tier jump muestra un badge verde "Jump N tier(s)" (reusa la clase `.disc-badge` que ya existe en este archivo, línea ~369).
5. La card muestra un banner amarillo NO bloqueante "Approval required" cuando algún bundle de esa opción tiene tier jump — sin tocar el botón "Select & Create Quote" ni el `requiresApproval`/`actionHtml` viejo.

**Piezas a tocar, todas en `app/demos/valucal_existing_accounts.html`:**

1. **Constantes y helpers nuevos** — agregar después de `getEffectiveTier()` (línea ~7338, justo antes de `getApprovalRole()`):
   ```js
   const MSA_DISCOUNT_TIERS = [
     { min: 1,   max: 24,   minPct: 0,  maxPct: 7,  label: 'Tier A (1-24 units)' },
     { min: 25,  max: 49,   minPct: 8,  maxPct: 12, label: 'Tier B (25-49 units)' },
     { min: 50,  max: 99,   minPct: 13, maxPct: 19, label: 'Tier C (50-99 units)' },
     { min: 100, max: 9999, minPct: 20, maxPct: 25, label: 'Tier D (100+ units)' },
   ];
   const MSA_TIER_UNIT_PRICES = {
     'vtu':     { A: 34.00, B: 29.00, C: 24.00, D: 22.00 },
     'vtu-ffc': { A: 64.00, B: 55.00, C: 46.00, D: 41.00 }, // suma VTU + Front Facing Camera del deck
   };
   function getMsaTierLetter(fleetSize) {
     const idx = MSA_DISCOUNT_TIERS.findIndex(t => fleetSize >= t.min && fleetSize <= t.max);
     return ['A', 'B', 'C', 'D'][idx === -1 ? 0 : idx];
   }
   function getMsaDiscountTier(fleetSize) {
     const idx = MSA_DISCOUNT_TIERS.findIndex(t => fleetSize >= t.min && fleetSize <= t.max);
     return MSA_DISCOUNT_TIERS[idx === -1 ? 0 : idx];
   }
   function getMsaNaturalTierIndex(fleetSize) {
     const idx = MSA_DISCOUNT_TIERS.findIndex(t => fleetSize >= t.min && fleetSize <= t.max);
     return idx === -1 ? 0 : idx;
   }
   function getMsaSelectedTierIndex(pct) {
     const idx = MSA_DISCOUNT_TIERS.findIndex(t => pct >= t.minPct && pct <= t.maxPct);
     return idx === -1 ? 0 : idx;
   }
   function getMsaFleetSizeForBundleModal() {
     const opt = bld.targetOptId ? options.find(o => o.id === bld.targetOptId) : null;
     const otherUnits = opt ? opt.bundles.reduce((sum, b) => sum + (b.id === bld.targetBundleId ? 0 : b.qty), 0) : 0;
     return otherUnits + (bld.qty || 0);
   }
   ```

2. **`bld` (línea ~8078)** — hoy es:
   ```js
   let bld = { targetOptId: null, targetBundleId: null, qty: 15, coreKey: null, coreName: null, corePrice: 0, selectedFeatures: [], promoType: 'Standard', txType: null };
   ```
   Quitar `promoType: 'Standard'`, agregar `msaDiscountPct: 0`:
   ```js
   let bld = { targetOptId: null, targetBundleId: null, qty: 15, coreKey: null, coreName: null, corePrice: 0, selectedFeatures: [], msaDiscountPct: 0, txType: null };
   ```

3. **HTML — reemplazar el bloque `.preview-promo`** (línea 5996-6006, confirmado 2026-09-08 sin cambios de línea):
   ```html
   <div class="preview-promo">
     <div class="preview-promo-label">Promotion</div>
     <div class="custom-select-wrap">
       <button class="custom-select-btn selected" id="bundle-promo-btn" onclick="togglePromoDropdown()">
         <span id="bundle-promo-label">Standard</span>
         <span class="material-symbols-outlined">expand_more</span>
       </button>
       <div class="custom-dropdown hidden" id="bundle-promo-dropdown"></div>
     </div>
     <div id="promo-eligibility-note" class="promo-eligibility-note"></div>
   </div>
   ```
   por:
   ```html
   <div class="preview-promo" id="msa-discount-block">
     <div class="preview-promo-label">Discount</div>
     <div class="msa-discount-slider-row" style="display:flex;align-items:center;gap:10px;">
       <div class="msa-discount-slider-track-wrap" style="position:relative;flex:1;">
         <input type="range" id="msa-discount-slider" min="0" max="25" step="1" value="0" style="width:100%;" oninput="onMsaDiscountSliderInput(this.value)">
         <div id="msa-discount-tier-marks" style="position:absolute;top:100%;left:0;right:0;height:14px;margin-top:4px;"></div>
       </div>
       <span id="msa-discount-value" style="font-weight:700;font-size:13px;min-width:34px;text-align:right;">0%</span>
     </div>
     <div id="msa-discount-tier-note" class="promo-eligibility-note"></div>
   </div>
   ```
   (CSS opcional para las marcas A-D: `.msa-discount-tier-mark { position:absolute; transform:translateX(-50%); font-size:9px; font-weight:700; color:var(--gray-500); }` y `.msa-discount-jump-note { color:#8a6100; }`.)

4. **Funciones nuevas del slider** — agregar cerca de `renderPromoCards()` (línea ~8528), reemplazando cualquier referencia futura a esa función por estas:
   ```js
   function renderMsaDiscountSlider() {
     const slider = document.getElementById('msa-discount-slider');
     const valueEl = document.getElementById('msa-discount-value');
     if (!slider) return;

     const overallMin = MSA_DISCOUNT_TIERS[0].minPct;
     const overallMax = MSA_DISCOUNT_TIERS[MSA_DISCOUNT_TIERS.length - 1].maxPct;
     slider.min = overallMin;
     slider.max = overallMax;

     const fleetSize = getMsaFleetSizeForBundleModal();
     const naturalTier = getMsaDiscountTier(fleetSize);
     if (bld.msaDiscountPct < overallMin || bld.msaDiscountPct > overallMax) {
       bld.msaDiscountPct = naturalTier.minPct;
     }
     slider.value = bld.msaDiscountPct;
     if (valueEl) valueEl.innerText = `${bld.msaDiscountPct}%`;
     renderMsaDiscountTierMarks();
     updateMsaDiscountNote();
   }

   function renderMsaDiscountTierMarks() {
     const marksEl = document.getElementById('msa-discount-tier-marks');
     if (!marksEl) return;
     const overallMin = MSA_DISCOUNT_TIERS[0].minPct;
     const overallMax = MSA_DISCOUNT_TIERS[MSA_DISCOUNT_TIERS.length - 1].maxPct;
     const letters = ['A', 'B', 'C', 'D'];
     marksEl.innerHTML = MSA_DISCOUNT_TIERS.map((tier, index) => {
       const centerPct = (tier.minPct + tier.maxPct) / 2;
       const leftPct = ((centerPct - overallMin) / (overallMax - overallMin)) * 100;
       return `<span class="msa-discount-tier-mark" style="left:${leftPct}%;">${letters[index]}</span>`;
     }).join('');
   }

   function updateMsaDiscountNote() {
     const note = document.getElementById('msa-discount-tier-note');
     if (!note) return;
     const fleetSize = getMsaFleetSizeForBundleModal();
     const naturalIdx = getMsaNaturalTierIndex(fleetSize);
     const naturalTier = MSA_DISCOUNT_TIERS[naturalIdx];
     const selectedIdx = getMsaSelectedTierIndex(bld.msaDiscountPct);
     const selectedTier = MSA_DISCOUNT_TIERS[selectedIdx];
     const skip = selectedIdx - naturalIdx;

     if (skip > 0) {
       const role = getApprovalRole(skip);
       note.innerHTML = `<span style="font-weight:700;" class="msa-discount-jump-note">Tier jump — ${selectedTier.label}</span><br><span class="msa-discount-jump-note">Fleet is ${naturalTier.label}. Requires ${role} approval.</span>`;
     } else {
       note.innerHTML = `<span style="font-weight:700;">${naturalTier.label}</span><br><span>Discount range ${naturalTier.minPct}-${naturalTier.maxPct}%</span>`;
     }
   }

   function onMsaDiscountSliderInput(value) {
     bld.msaDiscountPct = Number(value) || 0;
     updateBundlePreview();
   }
   ```

5. **`calcBundle()`** (línea ~7364) — reemplazar la función completa:
   ```js
   function calcBundle(bundle, termStr, promoType, forcedTierIndex = -1, tierQty = null) {
     const term = parseInt(termStr) || 36;
     const qtyBasis = tierQty == null ? bundle.qty : tierQty;
     const promoMult = (typeof bundle.msaDiscountPct === 'number')
       ? 1 - (bundle.msaDiscountPct / 100)
       : getPromoMultiplier(bundle.coreKey, promoType);

     const deckPrices = MSA_TIER_UNIT_PRICES[bundle.coreKey];
     if (term === 36 && deckPrices) {
       const tierLetter = getMsaTierLetter(qtyBasis);
       const addonsAndKeyfobs = bundle.basePrice - (bundle.baseCorePrice ?? bundle.basePrice);
       const unitPrice = (deckPrices[tierLetter] + addonsAndKeyfobs) * promoMult;
       const monthly = unitPrice * bundle.qty;
       return { unitPrice, monthly, tier: { label: `Tier ${tierLetter}` }, tierMult: 1, promoMult, termMult: 1 };
     }

     const termMult  = getTermMultiplier(term);
     const tierObj   = getEffectiveTier(qtyBasis, forcedTierIndex);
     const tierMult  = 1 - tierObj.discount;
     const unitPrice = bundle.basePrice * termMult * tierMult * promoMult;
     const monthly   = unitPrice * bundle.qty;
     return { unitPrice, monthly, tier: tierObj, tierMult, promoMult, termMult };
   }
   ```
   **Ojo:** este `calcBundle()` es el que también usa `renderOptions()` para las cards del cart — es el mismo que hoy calcula el "Volume disc" del mecanismo viejo. Al reemplazarlo, cualquier bundle que use `msaDiscountPct` deja de pasar por `tierObj.discount` (por eso el badge "Jump N tier(s)" del punto 8 de abajo se calcula aparte, no leyendo `bt.discount`).

6. **`updateBundlePreview()`** (línea ~8666) — reemplazar la función completa (ya adaptada, sin keyfobs):
   ```js
   function updateBundlePreview() {
     renderMsaDiscountSlider();
     if (!bld.coreKey) return;

     const optId = bld.targetOptId;
     const term = optId ? (options.find(o => o.id === optId)?.term || 36) : 36;
     const forcedTier = optId ? ((options.find(o => o.id === optId)?.forcedTierIndex) ?? -1) : -1;

     syncAddonControls();

     const fleetSize = getMsaFleetSizeForBundleModal();
     const deckPrices = MSA_TIER_UNIT_PRICES[bld.coreKey];
     const usesDeckPrice = parseInt(term) === 36 && !!deckPrices;
     const tierLetter = usesDeckPrice ? getMsaTierLetter(fleetSize) : null;
     const displayCorePrice = usesDeckPrice ? deckPrices[tierLetter] : bld.corePrice;

     const addOnBase = (bld.selectedFeatures || []).reduce((sum, featureKey) => sum + (featurePricing[featureKey] || 0), 0);
     const basePrice = displayCorePrice + addOnBase;

     const dummyBundle = {
       basePrice: bld.corePrice + addOnBase,
       baseCorePrice: bld.corePrice,
       qty: bld.qty,
       coreKey: bld.coreKey,
       msaDiscountPct: bld.msaDiscountPct,
     };
     const { monthly } = calcBundle(dummyBundle, term, null, forcedTier);

     const discountPct = bld.msaDiscountPct || 0;
     let discountLine = '';
     if (discountPct > 0) {
       const { monthly: monthlyNoDiscount } = calcBundle({ ...dummyBundle, msaDiscountPct: 0 }, term, null, forcedTier);
       const discountAmount = monthlyNoDiscount - monthly;
       discountLine = `<div class="preview-line" style="color:#1a7f37;font-weight:600;"><span>Tier Discount (−${discountPct}%)</span><span>−$${discountAmount.toFixed(2)}</span></div>`;
     }

     document.getElementById('preview-price-val').innerText = Math.round(monthly).toLocaleString();
     document.getElementById('preview-lines').classList.remove('hidden');
     const featureLines = (bld.selectedFeatures || []).map(featureKey =>
       `<div class="preview-line"><span>${featureLabels[featureKey] || featureKey}</span><span>+$${featurePricing[featureKey].toFixed(2)}</span></div>`
     ).join('');
     document.getElementById('preview-lines').innerHTML = `
       <div class="preview-line"><span>${bld.coreName}</span><span>$${displayCorePrice.toFixed(2)}</span></div>
       ${featureLines}
       <div class="preview-line"><strong>Bundle subtotal (base)</strong><strong>$${basePrice.toFixed(2)}</strong></div>
       ${discountLine}
     `;
   }
   ```
   (`renderMsaDiscountSlider()` como primera línea hace que el slider se pinte solo, con las marcas y el aviso, apenas se selecciona un core — `selectCore()`, línea ~8608, ya llama a `updateBundlePreview()` al final.)

7. **`createBundle()`** (línea ~8693) — en el objeto `bundleData`, reemplazar:
   ```js
   promoType: bld.promoType || 'Standard'
   ```
   por:
   ```js
   msaDiscountPct: bld.msaDiscountPct || 0
   ```
   (`baseCorePrice` ya se guarda — no hace falta tocarlo.)

8. **`openConfigureBundle()` / reset de bundle nuevo** (línea ~8256, buscar el reset de `bld` al abrir un bundle en blanco) — donde hoy dice:
   ```js
   bld.qty = 1; bld.coreKey = null; bld.promoType = proposalData.promoType || 'Standard'; bld.selectedFeatures = [];
   ```
   reemplazar por:
   ```js
   bld.qty = 1; bld.coreKey = null; bld.msaDiscountPct = 0; bld.selectedFeatures = [];
   ```

9. **Badge "Jump N tier(s)" en la card del cart** — dentro de `renderOptions()` (línea 8744), en el bloque de `discBadges` (línea 8844-8846):
   ```js
   let discBadges = '';
   if (hasDisc)    discBadges += `<span class="disc-badge">${(bt.discount*100)}% Volume disc</span> `;
   if (promoApplied) discBadges += `<span class="disc-badge" style="background:#0076CE">Media Promo −20%</span>`;
   ```
   agregar justo después:
   ```js
   const bundleTierSkip = getMsaSelectedTierIndex(b.msaDiscountPct || 0) - getMsaNaturalTierIndex(totalUnits);
   if (bundleTierSkip > 0) {
     discBadges += ` <span class="disc-badge">Jump ${bundleTierSkip} tier${bundleTierSkip > 1 ? 's' : ''}</span>`;
   }
   ```

10. **Banner "Approval required" en la card** — dentro de `renderOptions()`, calcular junto a donde ya se computa `totalUnits`/`requiresApproval` (línea ~8809-8816):
    ```js
    const optionHasTierJump = opt.bundles.some(b => (getMsaSelectedTierIndex(b.msaDiscountPct || 0) - getMsaNaturalTierIndex(totalUnits)) > 0);
    ```
    Y en el template de la card (línea 9004-9007), cambiar:
    ```html
    <div class="option-card-body">
       <div style="margin-bottom:10px;">
         ${termFieldHtml}
       </div>
    ```
    por:
    ```html
    <div class="option-card-body">
       <div style="margin-bottom:10px;">
         ${termFieldHtml}
       </div>
       ${optionHasTierJump ? `<div style="display:flex;align-items:center;gap:6px;background:#fff8e1;border:1px solid #f0c14b;color:#8a6100;font-size:12px;font-weight:600;padding:8px 12px;border-radius:6px;margin:10px 0;"><span class="material-symbols-outlined" style="font-size:16px;">warning</span>Approval required</div>` : ''}
    ```

11. **Limpieza (opcional, código muerto tras este cambio):** `togglePromoDropdown()`, `renderPromoCards()`, `selectBundlePromo()` y el array `PROMOS` quedan sin usar — se pueden borrar o dejar, no rompen nada si quedan.

**Efecto:** mismo comportamiento que ya está en producción en `index.html` — el dropdown "Promotion" desaparece del modal "Configure Bundle", aparece un slider de descuento que cubre las 4 tiers completas con marcas A-D, VTU y VTU+FFC muestran el precio exacto del deck a 36 meses, y si el rep selecciona un % de un tier más alto que su tier natural (tier jump), el modal lo avisa de forma informativa con el rol de aprobación correspondiente, la card del cart muestra el badge verde "Jump N tier(s)" en el bundle y un banner amarillo "Approval required" en la card — sin bloquear nunca el botón "Select & Create Quote". El mecanismo viejo de `volumeTiers`/`forcedTierIndex` (el que sí bloquea ese botón) no se toca.

---

## 3. Modal de "Service order term" al entrar al flujo (requerimiento nuevo, dictado 2026-09-08 — sin investigar código aún)

Al entrar al flujo de cuentas existentes, debe aparecer un modal que pida el **Service order term** como un rango de fechas:
- Fecha de inicio (seleccionable).
- Término en meses — mismos valores por defecto que se usan en el resto de la app (12/24/36/48/60).
- El sistema calcula y muestra la fecha de finalización resultante.

Una vez configurado, se continúa a la pantalla de home y sigue el proceso normal.

**Posible inconsistencia de nomenclatura a resolver con Catalina antes de construir esto:** el 2026-09-08 se decidió, para cuentas NUEVAS, eliminar por completo el campo/concepto "Service order term" y dejar solo "Contract term" (plan point 2.E) — porque eran redundantes (mismo dato, dos nombres). Este requerimiento de cuentas existentes pide textualmente lo contrario: introducir un modal de "Service order term". Es razonable pensar que, conceptualmente, es el MISMO dato (fecha de inicio + término en meses → fecha de fin) que ya se llama "Contract term" en cuentas nuevas, y que el nombre "Service order term" en el dictado es simplemente el nombre con el que Catalina conocía este campo antes de la limpieza del punto 2.E. **No asumir esto sin confirmarlo con ella** — puede que sí sea un concepto distinto en el flujo de cuentas existentes (por ejemplo, si una cuenta existente puede tener un MSA con un término distinto al de una orden de servicio puntual). Antes de escribir código, preguntarle directamente: "¿esto es lo mismo que 'Contract term' en cuentas nuevas, con otro nombre, o es un dato conceptualmente distinto?"

**Referencia de código ya construida y probada, reusable si la respuesta es "es el mismo concepto":** la lógica de fecha de inicio + término → fecha de fin ya existe y funciona en `account-setup.html` (`formatMsaTermRangeText()`, `formatMsaTermValueHtml()`, `renderMsaTermStartValue()`, línea ~1270-1307) y en `index.html` (`getMsaTermEndDate()`, línea ~9898, agregado el 2026-09-08 para el contenedor MSA del PDF de propuesta). Misma fórmula en ambos: fin = inicio + N meses − 1 día.

**Pendiente antes de escribir el código:** además de resolver la pregunta de nomenclatura de arriba, localizar en `valucal_existing_accounts.html` el punto exacto de entrada al flujo (qué pantalla/función se ejecuta primero) para decidir dónde enganchar este modal, y si ya existe algún modal similar reutilizable (revisar `#account-setup-overlay` y otros overlays de entrada al flujo antes de crear uno nuevo).

---

## 4. Tier jump en upsells y expansión — ya se puede arrancar, pero es una investigación aparte

**Actualización 2026-09-08:** este punto ya no está bloqueado — el diseño del tier jump quedó cerrado en cuentas nuevas (punto 2 de este documento tiene el código completo y probado). Lo que falta es investigar cómo aplicarlo a los flujos de **upsells** y **expansión** de cuentas existentes, que — verificado el 2026-09-08 — **no comparten código con el modal "Configure Bundle"** del punto 2: tienen su propio sistema de pricing independiente.

**Hallazgo de la investigación de hoy, para ahorrar tiempo en el otro chat:** el flujo de "Add Vehicles"/expansión tiene su propia constante de pricing separada, `vzExpCorePricing` (línea ~13860 de `valucal_existing_accounts.html`), con sus propios `vzExpFeaturePricing`, `vzExpFeatureLabels` y `vzExpVolumeT` (tiers de volumen propios) — es decir, es un sistema paralelo al `corePricing`/`bld`/`calcBundle()` del punto 2, no el mismo código reutilizado. El flujo de upsells (`_vzCommitBundles`, cerca de la línea ~13850) también parece tener su propia lógica de armado de bundle, separada.

**Antes de escribir código para esto:** hay que investigar a fondo, en el otro chat, cómo `vzExpCorePricing` y el sistema de upsells calculan precio y descuento hoy (¿tienen su propio concepto de tier/volumen? ¿usan `volumeTiers` global o uno propio?) antes de decidir cómo portar el slider + tier jump ahí — probablemente NO sea un copy-paste del punto 2, sino una adaptación a una estructura de datos distinta. Seguir el mismo método riguroso usado en el punto 2 de este documento: leer el código real antes de asumir que es igual.

---

## 5. Dos ajustes menores, compartidos con cuentas nuevas

1. **Indicador de "minimum quantity" en las cards — verificado 2026-09-08, ya NO existe en este archivo.** Se buscó a fondo (patrón tipo "30/45 units", `minQtyRequired`, etc.) y no hay ningún rastro — no hace falta ninguna acción aquí.
2. **Renombrar "VTU + Dual Camera" → "VTU + Dual Camera Subscription"** — verificado 2026-09-08, faltan **3 lugares** en `valucal_existing_accounts.html` (en `index.html` ya está hecho, punto 9 del plan de cuentas nuevas):
   - Línea 5914 — dropdown de selección de core del modal "Configure Bundle": `<div class="dropdown-option" onclick="selectCore('vtu-dual')">VTU + Dual Camera</div>`
   - Línea 7279 — `corePricing['vtu-dual'].name` (el que usa el modal "Configure Bundle" del punto 2 de este documento)
   - Línea 13863 — `vzExpCorePricing['vtu-dual'].name` (el pricing separado del flujo de expansión, punto 4 de este documento)

   Los 3 deben decir "VTU + Dual Camera Subscription" al final para que quede consistente en toda la app.

---

## 6. Actualización (2026-09-08): loader de creación de quote + redirect automático a Salesforce

**Requerimiento:** al seleccionar y confirmar una opción, en vez de la card inline "Quote created successfully" que existe hoy (con un botón "View quote" para abrir Salesforce manualmente en pestaña nueva), debe pasar exactamente lo mismo que en cuentas nuevas: aparece un loader de 2 etapas ("Creating Opportunity" → "Creating Quote", ~6 segundos) y al terminar redirige automáticamente (página completa, no pestaña nueva) a `salesforce-quote.html`, pasando los datos reales del MSA por query params. **Confirmado con Catalina: esto reemplaza por completo el comportamiento actual, no se agrega como paso adicional.**

**Requisito previo — ya resuelto en cuentas nuevas el 2026-09-08 (punto 12 del plan de cuentas nuevas), aplicar la versión corregida:** `index.html` tenía un bug donde los parámetros que mandaba a `salesforce-quote.html` no coincidían con los que ese archivo leía (mandaba `msaMinQty`, se leía `msaMinimumSpend`; las fechas y ramp-up estaban hardcodeados del lado de `salesforce-quote.html` sin mirar la URL). Ya se corrigió: ahora el parámetro es `msaMinSpend` (no `msaMinQty` — se quitó la palabra "quantity" de la lógica porque es un monto de gasto mínimo, no una cantidad) y `salesforce-quote.html` lee los 5 parámetros de la URL sin hardcodear nada. **Este archivo (`salesforce-quote.html`) es compartido entre cuentas nuevas y existentes — el fix ya aplica para ambas, no hay que tocarlo de nuevo aquí.**

**Diferencia importante de lógica de negocio — NO portar tal cual:** en `index.html`, `confirmSelectionAndProceed()` (línea 13549-13566) además del loader también **crea el MSA la primera vez** — le asigna `msaId` si no existe, y sobreescribe `msaMinimumServiceTerm`/`msaMinimumSpendCommitment` con el término y el total de la opción recién seleccionada. Eso tiene sentido en cuentas nuevas porque el MSA se está creando en ese momento. En cuentas existentes el MSA **ya existe** (con su minimum spend commitment, term start y ramp-up ya fijos, cargados en el punto 1 de este documento) — seleccionar una opción para un upsell/expansión NO debe cambiar los términos del MSA ya firmado. Por eso el port de abajo **solo agrega el loader y el redirect**, sin tocar ni recalcular los campos financieros del MSA.

**Piezas a tocar, todas en `app/demos/valucal_existing_accounts.html`:**

1. **CSS del loader** — agregar (copiado tal cual de `index.html`, líneas 3434-3514, no cambia nada):
   ```css
   /* Quote creation loader */
   .quote-loader-overlay {
     position: fixed;
     inset: 0;
     z-index: 6000;
     background: rgba(8, 18, 36, 0.87);
     backdrop-filter: blur(4px);
     display: none;
     align-items: center;
     justify-content: center;
   }
   .quote-loader-overlay.open { display: flex; }
   .quote-loader-card {
     background: #fff;
     border-radius: 20px;
     padding: 36px;
     width: min(480px, 94vw);
     text-align: center;
     animation: qlSlideIn 0.3s cubic-bezier(0.22, 1, 0.36, 1);
   }
   @keyframes qlSlideIn {
     from { transform: translateY(18px); opacity: 0; }
     to { transform: translateY(0); opacity: 1; }
   }
   .ql-progress-wrap { margin-bottom: 28px; }
   .ql-progress-track {
     height: 5px;
     background: var(--gray-200);
     border-radius: 999px;
     overflow: hidden;
     margin-bottom: 10px;
   }
   .ql-progress-fill {
     height: 100%;
     width: 0%;
     background: var(--black);
     border-radius: 999px;
     transition: width 3s ease;
   }
   .ql-progress-labels { display: flex; justify-content: space-between; }
   .ql-progress-label {
     font-size: 11px;
     font-weight: 700;
     color: var(--gray-400);
     text-transform: uppercase;
     letter-spacing: 0.06em;
     transition: color 0.3s ease;
   }
   .ql-progress-label.active { color: var(--black); }
   .ql-progress-label.done { color: var(--green); }
   .quote-loader-headline {
     font-size: 22px;
     font-weight: 700;
     color: var(--black);
     letter-spacing: -0.01em;
     margin-bottom: 10px;
   }
   .ql-dots::after { content: ''; animation: qlDots 1.4s steps(4, end) infinite; }
   @keyframes qlDots {
     0% { content: ''; }
     25% { content: '.'; }
     50% { content: '..'; }
     75% { content: '...'; }
     100% { content: ''; }
   }
   .quote-loader-body { font-size: 15px; color: var(--gray-600); line-height: 1.6; margin-bottom: 14px; }
   .quote-loader-warning { font-size: 12px; color: var(--gray-400); }
   ```
   (Verificar que `var(--gray-200)`, `var(--black)`, `var(--green)`, `var(--gray-600)`, `var(--gray-400)` ya existan como variables en este archivo — se usan en otros lados como `.disc-badge`, así que deberían estar.)

2. **HTML del overlay** — agregar en algún punto del body, junto a otros overlays (copiado tal cual de `index.html`, líneas 7700-7720):
   ```html
   <!-- Quote creation loader -->
   <div class="quote-loader-overlay" id="quote-loader-overlay" aria-live="polite" aria-busy="true">
     <div class="quote-loader-card">
       <div class="ql-progress-wrap">
         <div class="ql-progress-track">
           <div class="ql-progress-fill" id="ql-fill"></div>
         </div>
         <div class="ql-progress-labels">
           <span class="ql-progress-label active" id="ql-label-1">Opportunity</span>
           <span class="ql-progress-label" id="ql-label-2">Quote</span>
         </div>
       </div>
       <div class="quote-loader-headline" id="ql-headline">Creating Opportunity<span class="ql-dots"></span></div>
       <div class="quote-loader-body" id="ql-body">
         Setting up the opportunity record in Salesforce.<br>This may take a moment.
       </div>
       <div class="quote-loader-warning">Don't close or refresh this window</div>
     </div>
   </div>
   ```

3. **Funciones nuevas** — agregar cerca de `confirmSelectionAndProceed()` (línea ~9700):
   ```js
   function showQuoteCreationLoader() {
     const overlay = document.getElementById('quote-loader-overlay');
     if (!overlay) {
       openSalesforceQuotePage();
       return;
     }

     const fill = document.getElementById('ql-fill');
     const lbl1 = document.getElementById('ql-label-1');
     const lbl2 = document.getElementById('ql-label-2');
     const headline = document.getElementById('ql-headline');
     const body = document.getElementById('ql-body');

     if (fill) {
       fill.style.transition = 'none';
       fill.style.width = '0%';
     }
     if (lbl1) lbl1.className = 'ql-progress-label active';
     if (lbl2) lbl2.className = 'ql-progress-label';
     if (headline) headline.textContent = 'Creating Opportunity';
     if (body) body.innerHTML = 'Setting up the opportunity record in Salesforce.<br>This may take a moment.';

     overlay.classList.add('open');

     requestAnimationFrame(function () {
       requestAnimationFrame(function () {
         if (fill) {
           fill.style.transition = 'width 3s ease';
           fill.style.width = '50%';
         }
       });
     });

     setTimeout(function () {
       if (lbl1) lbl1.className = 'ql-progress-label done';
       if (lbl2) lbl2.className = 'ql-progress-label active';
       if (fill) {
         fill.style.transition = 'width 3s ease';
         fill.style.width = '100%';
       }
       if (headline) headline.innerHTML = 'Creating Quote<span class="ql-dots"></span>';
       if (body) body.innerHTML = 'Generating your configured quote and<br>linking it to the opportunity record.';
     }, 3000);

     setTimeout(function () {
       overlay.classList.remove('open');
       openSalesforceQuotePage();
     }, 6000);
   }

   function openSalesforceQuotePage() {
     const params = new URLSearchParams();
     if (proposalData.msaId) {
       params.set('msaId', proposalData.msaId);
       if (proposalData.msaMinimumSpendCommitment != null) params.set('msaMinSpend', proposalData.msaMinimumSpendCommitment);
       if (proposalData.msaTermStart) params.set('msaTermStart', proposalData.msaTermStart);
       if (proposalData.msaContractTerm != null) params.set('msaMinService', proposalData.msaContractTerm);
       if (proposalData.msaRampUpPeriod != null) params.set('msaRampUp', proposalData.msaRampUpPeriod);
     }
     const quoteQuery = params.toString() ? `?${params.toString()}` : '';
     window.location.href = `../salesforce/salesforce-quote.html${quoteQuery}`;
   }
   ```
   **Ojo con el nombre del campo de término:** en `index.html`, `proposalData` guarda el término en `msaMinimumServiceTerm` (nombre viejo, ya no coincide con la UI que ahora dice "Contract term", pero no se renombró la variable). En este archivo, el punto 1 de este documento agrega el campo con el nombre `msaContractTerm` (coincide con `account-setup.html`) — por eso arriba se usa `proposalData.msaContractTerm`, no `msaMinimumServiceTerm`. No copiar el nombre de variable de `index.html` tal cual.

   **`../salesforce/` y no `app/salesforce/`:** esta ruta relativa ya se usa así en otros links de este mismo archivo (ej. línea 4774) porque `valucal_existing_accounts.html` vive en `app/demos/`, un nivel más adentro que `index.html`. No usar la ruta de `index.html` (`app/salesforce/...`) tal cual, o el link queda roto.

4. **`confirmSelectionAndProceed()`** (línea 9700-9704) — hoy es:
   ```js
   function confirmSelectionAndProceed() {
     closeConfirmSelectionModal();
     accountSetupOpenedFromOptionSelection = false;
     openQuoteCreatedStep();
   }
   ```
   Reemplazar por:
   ```js
   function confirmSelectionAndProceed() {
     closeConfirmSelectionModal();
     accountSetupOpenedFromOptionSelection = false;
     showQuoteCreationLoader();
   }
   ```
   **No se toca nada del cálculo de MSA** — a diferencia de `index.html`, aquí NO se agrega ninguna línea que asigne `msaId`/`msaMinimumSpendCommitment`/`msaContractTerm` desde `opt` — esos valores ya existen en `proposalData` desde que se cargó la cuenta (punto 1 de este documento) y no cambian por seleccionar una opción de upsell/expansión.

5. **Código que queda sin uso tras este cambio (opcional, no rompe nada si se deja):** `openQuoteCreatedStep()`, `hideQuoteCreatedState()` y `viewCreatedQuote()` dejan de estar en la ruta principal — ya no hay ningún botón que los dispare tras este cambio. Se pueden borrar o dejar como código muerto.

**Efecto:** al confirmar la selección de una opción en cuentas existentes, aparece el mismo loader de 2 etapas que en cuentas nuevas y, al terminar, la página redirige sola a `salesforce-quote.html` con los datos reales del MSA ya existente de esa cuenta (no recalculados) — igual que en cuentas nuevas, pero sin crear ni modificar el MSA.

---

## 7. Actualización (2026-09-08): rehacer el PDF de "Review & Send Proposal" igual a cuentas nuevas (incluye el contenedor MSA)

**Decisión confirmada con Catalina:** reemplazar por completo `renderProposalDoc()` de `valucal_existing_accounts.html` por la versión de `index.html` — una página por opción (no todas las opciones en una sola página como está hoy), mismo estilo de página/footer/paginación, y ya con el contenedor MSA (punto 10 del plan de cuentas nuevas) incluido. No es un simple copy-paste: hay 3 dependencias de `index.html` que **no existen** en este archivo y hay que adaptar — detalladas abajo.

**El modal en sí (el shell con el email a la izquierda y el PDF a la derecha) ya está sincronizado — no hay que tocarlo.** Comparé el CSS de `.proposal-review-modal`/`#proposal-message-pane`/`.review-preview-pane` en los dos archivos y son prácticamente idénticos (mismos anchos 36%/64%, mismas transiciones al hacer focus del preview). El trabajo real está solo en `renderProposalDoc()`, que sí divergió con el tiempo.

**Gap aparte, encontrado al investigar — NO incluido en este punto:** el cuerpo del email (`fillProposalMessageDefaults()`) en este archivo es una plantilla estática simple (un solo template hardcodeado). En `index.html`, el email tiene un sistema mucho más grande: selector de formato de mensaje, bloques de mensaje con tokens, `buildProposalMessageHtmlBySelectedFormat()`, `renderProposalMessageFormatControl()` — ninguna de esas funciones existe en `valucal_existing_accounts.html`. Portar eso es un trabajo de un tamaño comparable al tier jump (punto 2), no algo que quepa dentro de "que el PDF se vea igual". Lo dejo señalado aquí para que se decida aparte si se quiere portar — no está incluido en el código de este punto.

**3 adaptaciones necesarias porque el código de `index.html` depende de cosas que no existen aquí:**

1. **`getSelectedCaseStudyData()` no existe.** En `index.html`, la Página 3 (case study) llama a esta función para elegir entre varios casos de éxito guardados. Aquí no existe ese selector — la Página 3 actual tiene un solo caso hardcodeado (Bill Howe / B.A.M Trucking). La versión de abajo usa la plantilla visual nueva de `index.html` pero con el contenido hardcodeado de este archivo, sin agregar el selector de casos de éxito (eso sería una feature aparte).
2. **`getBundleEvcLabel(b)` no existe.** Aquí ya existe un patrón equivalente y funcionando: `typeof getEvcTypeLabel === 'function' ? getEvcTypeLabel(b.evcType) : (b.evcType || 'Dual')`. La versión de abajo usa el patrón de aquí, no el de `index.html`.
3. **`proposalEscapeHtml()` no existe.** Es una función chiquita de sanitización de HTML que `index.html` sí tiene y usa en varios lugares de esta función. Se agrega como función nueva (ver pieza 1 abajo) — es una mejora de seguridad, no rompe nada.
4. **`getMsaTermEndDate()` no existe** (se agregó en `index.html` como parte del punto 10, contenedor MSA del PDF). Se agrega también aquí (ver pieza 2).
5. **El nombre del campo del término es distinto.** `index.html` usa `proposalData.msaMinimumServiceTerm`; aquí, por el punto 1 de este documento, el campo se llama `proposalData.msaContractTerm`. El contenedor MSA de abajo ya usa el nombre correcto de este archivo.
6. **Las imágenes del logo y del flyer de onboarding se dejan como están (URLs remotas), no se cambian a rutas locales.** `index.html` usa archivos locales (`app/assets/logo.svg`, `app/assets/img_1.png`, `app/assets/image_2.png`). Este archivo ya usa URLs remotas (GitHub raw / Contentstack) — probablemente porque el entorno donde corre esta demo no resuelve bien rutas locales relativas. La versión de abajo mantiene esas mismas URLs remotas que ya funcionan aquí, no las de `index.html`.
7. **`syncProposalReviewV2Previews()` no existe** (es de un modal "v2" que solo existe en `index.html`). Se quita esa línea de la función portada — no aplica aquí.

**Piezas a tocar, todas en `app/demos/valucal_existing_accounts.html`:**

1. **Dos funciones auxiliares nuevas** — agregar en cualquier parte del `<script>` principal, antes de `renderProposalDoc()`:
   ```js
   function proposalEscapeHtml(value) {
     return String(value == null ? '' : value)
       .replace(/&/g, '&amp;')
       .replace(/</g, '&lt;')
       .replace(/>/g, '&gt;')
       .replace(/\"/g, '&quot;')
       .replace(/'/g, '&#39;');
   }

   function getMsaTermEndDate(startIso, termMonths) {
     const start = parseProposalDate(startIso);
     if (!start || !Number.isFinite(termMonths) || termMonths <= 0) return null;
     const end = new Date(start);
     end.setMonth(end.getMonth() + termMonths);
     end.setDate(end.getDate() - 1);
     return end;
   }
   ```

2. **Reemplazar `renderProposalDoc()` completo** (línea 12784-12934) por:
   ```js
   function renderProposalDoc() {
     updateMaterialsLabel();
     const viewer = document.getElementById('prop-doc-viewer');
     if (!viewer) return;

     const dateStr = formatUsDate(new Date());
     const expirationInput = document.getElementById('proposal-expiration-date');
     let expirationStr;
     if (expirationInput && expirationInput.value) {
       const parsedExpiration = parseProposalDate(expirationInput.value);
       expirationStr = parsedExpiration ? formatExpirationDisplayDate(clampExpirationDate(startOfDay(parsedExpiration))) : formatExpirationDisplayDate(getDefaultExpirationDate());
     } else {
       expirationStr = formatExpirationDisplayDate(getDefaultExpirationDate());
     }

     const selectedMaterials = getSelectedMaterials();
     const pages = [];
     let pageNum = 1;

     const buildMsaContainerHtml = (optionTerm) => {
       if (!proposalData.msaId) return '';
       const startDate = parseProposalDate(proposalData.msaTermStart);
       const termMonths = Number(optionTerm) || Number(proposalData.msaContractTerm) || 0;
       const endDate = getMsaTermEndDate(proposalData.msaTermStart, termMonths);
       const rangeLabel = startDate
         ? (endDate ? `${formatUsDate(startDate)} – ${formatUsDate(endDate)}` : formatUsDate(startDate))
         : '--';
       const minSpend = proposalData.msaMinimumSpendCommitment != null ? `${formatMoney(proposalData.msaMinimumSpendCommitment)}/mo` : '--';
       const termLabel = termMonths ? `${termMonths} months` : '--';
       const rampUp = proposalData.msaRampUpPeriod != null ? `${proposalData.msaRampUpPeriod} days` : '--';
       const field = (label, value) => `<div><div style="font-size:10px;font-weight:700;margin-bottom:3px;white-space:nowrap;">${label}</div><div style="font-size:10px;color:#222;white-space:nowrap;">${value}</div></div>`;
       return `<div style="background:#fff;border:1px solid #000;border-radius:4px;padding:10px 16px 12px;margin:8px 0 14px;">
         <div style="background:#000;color:#fff;font-size:10px;font-weight:700;padding:8px 16px;margin:-10px -16px 10px;border-radius:3px 3px 0 0;">Master Service Agreement</div>
         <div style="display:grid;grid-template-columns:1.15fr 1.25fr .8fr 1.1fr;gap:12px;font-size:10px;color:#222;">
           ${field('Min. spend commitment', minSpend)}
           ${field('Contract Date', rangeLabel)}
           ${field('Term', termLabel)}
           ${field('Ramp-up period', rampUp)}
         </div>
       </div>`;
     };

     // Shared page footer disclaimer
     const DISCLAIMER = 'This quotation is for illustrative purpose only and does not constitute a formal offer or contractual agreement. Final configurations and pricing may vary. For complete terms and conditions, please contact your sales representative.';
     const COPYRIGHT = '© 2026 Verizon Connect. All Rights Reserved.';
     const VZC_LOGO = `<img src="https://raw.githubusercontent.com/catalinaypun/valu-cal-app/393563638315e21a9ce0a395f797c851de8be70d/resources/verizon-connect-logo.svg" alt="Verizon Connect" style="height:25px;display:block;">`;

     function wrapPage(content, num) {
       return `<div class="doc-page-outer" style="margin-bottom:16px;"><div class="vc-doc-shell"><div class="vc-doc-brand-line"></div><div class="vc-doc-inner" style="min-height:1040px;padding-bottom:56px;position:relative;">${content}<div style="position:absolute;bottom:12px;left:0;right:0;border-top:1px solid #dcdcdc;padding-top:10px;text-align:center;background:#ffffff;"><div style="font-size:6.8px;color:#2f2f2f;line-height:1.35;max-width:640px;margin:0 auto;">${DISCLAIMER}</div><div style="font-size:7px;color:#111111;font-weight:700;margin-top:8px;">${COPYRIGHT}</div></div></div></div></div>`;
     }

     // Simple header used on pages 2-4
     function simpleHeader() {
       return `<div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:6px;"><div><div style="font-size:28px;font-weight:900;color:#ee001e;line-height:1.1;">Quote</div><div style="font-size:11px;color:#555;margin-top:3px;">${dateStr}&nbsp;&nbsp;<strong style="font-weight:600;">|</strong>&nbsp;&nbsp;<strong style="font-weight:600;">Ref</strong> Prop-9284</div></div>${VZC_LOGO}</div><div style="height:1px;background:#e0e0e0;margin:10px -24px 20px;"></div>`;
     }

     function getQuoteTermLabel(opt) {
       const base = `${opt.term} Month`;
       const hasSeasonalWindow = Boolean(seasonalConfig && seasonalConfig.startMonth && seasonalConfig.endMonth);
       if (!hasSeasonalWindow) return base;
       return `${base} | Seasonal 6mo/3 off`;
     }

     function getDefaultQuoteTermLabel() {
       const hasSeasonalWindow = Boolean(seasonalConfig && seasonalConfig.startMonth && seasonalConfig.endMonth);
       return hasSeasonalWindow ? '48 Month | Seasonal 6mo/3 off' : '36 Month';
     }

     // ── PAGE 1..N: Quote — one page per option ─────────────────────
     {
       function buildIncludedNoCostRows(startRowIndex) {
         const includedRows = [
           { title: 'On site professional installation', subtitle: 'Certified Technician Service' },
           { title: 'Hardware and equipment', subtitle: '' },
           { title: 'Standard Activation', subtitle: 'One-time fee per unit' }
         ];
         return includedRows.map(function (row, offset) {
           const rowBg = ((startRowIndex + offset) % 2 === 1) ? 'background:#f7f7f7;' : '';
           const subtitleHtml = row.subtitle
             ? '<div style="font-size:9px;color:#555;line-height:1.3;">' + proposalEscapeHtml(row.subtitle) + '</div>'
             : '';
           return '<tr style="' + rowBg + '">' +
             '<td style="padding:8px 6px;font-size:10px;vertical-align:top;border-bottom:1px solid #ededed;color:#222;">1</td>' +
             '<td style="padding:8px 6px;font-size:10px;vertical-align:top;border-bottom:1px solid #ededed;color:#222;"><div style="font-weight:700;line-height:1.25;">' + proposalEscapeHtml(row.title) + '</div>' + subtitleHtml + '</td>' +
             '<td style="padding:8px 6px;text-align:right;vertical-align:top;border-bottom:1px solid #ededed;white-space:nowrap;"><div style="font-size:8px;color:#777;text-decoration:line-through;line-height:1.2;">$100.00</div><div style="font-size:10px;color:#1a1a1a;line-height:1.25;">$0.00</div></td>' +
             '<td style="padding:8px 6px;text-align:right;vertical-align:top;border-bottom:1px solid #ededed;white-space:nowrap;"><div style="font-size:10px;font-weight:700;color:#16a34a;line-height:1.25;">$0.00</div></td>' +
           '</tr>';
         }).join('');
       }

       const buildQuoteTableHtml = (optionLabel, termLabel, rowsHtml, optTotal, standardTotal) => {
         const hasDiscountedTotal = Number.isFinite(standardTotal) && standardTotal > optTotal + 0.005;
         return `<div style="margin-bottom:16px;"><div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:5px;"><div style="font-size:22px;font-weight:900;color:#ee001e;line-height:1.05;">${optionLabel}</div><div style="font-size:18px;font-weight:700;color:#1a1a1a;line-height:1.1;">${termLabel}</div></div><div style="height:1px;background:#1a1a1a;margin-bottom:0;"></div><table style="width:100%;border-collapse:collapse;"><thead><tr style="border-bottom:1px solid #d8d8d8;"><th style="padding:7px 6px;text-align:left;font-size:10px;font-weight:700;color:#1a1a1a;">QTY</th><th style="padding:7px 6px;text-align:left;font-size:10px;font-weight:700;color:#1a1a1a;">Description</th><th style="padding:7px 6px;text-align:right;font-size:10px;font-weight:700;color:#1a1a1a;">Unit price</th><th style="padding:7px 6px;text-align:right;font-size:10px;font-weight:700;color:#1a1a1a;">Total</th></tr></thead><tbody>${rowsHtml || '<tr><td colspan="4" style="padding:10px 6px;font-size:10px;color:#888;text-align:center;">No bundles added</td></tr>'}</tbody></table><div style="display:flex;flex-direction:column;align-items:flex-end;padding:8px 0 2px;gap:3px;">${hasDiscountedTotal ? `<div style="display:flex;align-items:center;gap:6px;"><div style="font-size:9px;color:#666;">Standard Monthly Rate</div><div style="font-size:11px;color:#777;text-decoration:line-through;">${formatMoney(standardTotal)}</div></div>` : ''}<div style="display:flex;align-items:baseline;gap:6px;"><div style="font-size:10px;font-weight:800;color:#ee001e;">Total Monthly Payment</div><div style="font-size:15px;font-weight:900;color:#1a1a1a;">${formatMoney(optTotal)}</div></div><div style="font-size:7px;color:#999;">*Excludes applicable taxes</div></div></div>`;
       };

       const upperLegal = `<div style="margin-top:10px;font-size:6.8px;color:#666;line-height:1.3;">This promotion is available to select new and existing Verizon Business customers in the US only, excluding Reveal Starter customers, OEM customers, Work, Group Purchasing Organization customers (GPOs), seasonal contracts, month-to-month contracts, federal, state and local government entities, healthcare sector, and migrations. Minimum Purchase Required: 5 Reveal Vehicle Tracking Subscription or 5 Reveal Powered Asset Tracking or 5 Reveal Vehicle Tracking Subscription plus either 1 Road-facing AI Dashcam or 1 Dual Cam with AI Dashcam. Promo credits and eligibility requirements are no longer met. Early cancellation or termination fees and other taxes, fees and terms may apply. Offer valid through December 31, 2026 or while supplies last. © 2026 Verizon.</div>`;

       const quotePageHeaderHtml = `<div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:7px;"><div><div style="font-size:30px;font-weight:900;color:#ee001e;line-height:1.04;">Quote</div><div style="font-size:10px;color:#555;margin-top:3px;"><strong style="font-weight:700;">${dateStr}</strong>&nbsp;|&nbsp;<strong style="font-weight:700;">Ref</strong> Prop-9284</div></div><div style="padding-top:4px;">${VZC_LOGO}</div></div><div style="background:#f8f3e9;padding:10px 20px;margin:8px -24px 14px;display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;font-size:10px;color:#222;"><div><div style="font-weight:700;margin-bottom:3px;font-size:10px;">Prepared by</div><div>Lisa Sullivan</div><div style="color:#666;">lisa.sullivan@verizonconnect.com</div><div style="color:#666;">(304) 555-0192</div></div><div><div style="font-weight:700;margin-bottom:3px;font-size:10px;">Prepared for</div><div>Apex Construction LLC</div><div style="color:#666;">123 Industrial PKWY, Tampa FL 33602, USA</div></div><div style="text-align:right;"><div style="font-weight:700;margin-bottom:3px;font-size:10px;">Valid until</div><div>${expirationStr}</div></div></div>`;

       const buildOptionPageHtml = (opt, i) => {
         let totalUnits = 0;
         opt.bundles.forEach(b => { totalUnits += b.qty; });
         const forcedIdx = opt.forcedTierIndex ?? -1;
         const optionPromo = getOptionPromotion(opt);
         let optTotal = 0;
         let standardTotal = 0;

         const bundleRowsHtml = opt.bundles.map((b, rowIdx) => {
           const livePromo = b.promoType || optionPromo || 'Standard';
           const { unitPrice, monthly } = calcBundle(b, opt.term, livePromo, forcedIdx, totalUnits);
           const { unitPrice: standardUnitPrice, monthly: standardMonthly } = calcBundle(b, opt.term, 'Standard', forcedIdx, totalUnits);
           optTotal += monthly;
           standardTotal += standardMonthly;

           const featNames = (b.features || b.selectedFeatures || []).map(k => {
             if (k === 'evc') return `EVC (${typeof getEvcTypeLabel === 'function' ? getEvcTypeLabel(b.evcType) : (b.evcType || 'Dual')})`;
             return featureLabels[k] || k;
           }).filter(Boolean);
           const featLine = featNames.length ? `<div style="font-size:9px;color:#555;line-height:1.3;">${featNames.join(', ')}</div>` : '';
           const hasDiscount = (standardUnitPrice - unitPrice) > 0.005;
           const rowBg = (rowIdx % 2 === 1) ? 'background:#f7f7f7;' : '';
           const bundleTermMonths = Number.parseInt(opt.term, 10) || 0;
           const totalSavings = (standardMonthly - monthly) * bundleTermMonths;
           const promoBadge = hasDiscount ? '<span style="display:inline-flex;align-items:center;background:#16a34a;color:#fff;border-radius:4px;font-size:8px;font-weight:700;padding:1px 5px;margin-top:3px;">Total Savings: ' + formatMoney(totalSavings) + '</span>' : '';

           return `<tr style="${rowBg}"><td style="padding:8px 6px;font-size:10px;vertical-align:top;border-bottom:1px solid #ededed;color:#222;">${b.qty}</td><td style="padding:8px 6px;font-size:10px;vertical-align:top;border-bottom:1px solid #ededed;color:#222;"><div style="font-weight:700;line-height:1.25;">${b.coreName}</div>${featLine}${promoBadge}</td><td style="padding:8px 6px;text-align:right;vertical-align:top;border-bottom:1px solid #ededed;white-space:nowrap;">${hasDiscount ? `<div style="font-size:8px;color:#777;text-decoration:line-through;line-height:1.2;">${formatMoney(standardUnitPrice)}</div>` : ''}<div style="font-size:10px;color:#1a1a1a;line-height:1.25;">${formatMoney(unitPrice)}</div></td><td style="padding:8px 6px;text-align:right;vertical-align:top;border-bottom:1px solid #ededed;white-space:nowrap;">${hasDiscount ? `<div style="font-size:8px;color:#777;text-decoration:line-through;line-height:1.2;">${formatMoney(standardMonthly)}</div>` : ''}<div style="font-size:10px;font-weight:700;color:#1a1a1a;line-height:1.25;">${formatMoney(monthly)}</div></td></tr>`;
         }).join('');
         const rowsHtml = bundleRowsHtml + buildIncludedNoCostRows(opt.bundles.length);

         const tableHtml = buildQuoteTableHtml(`Option ${i + 1}`, `${opt.term} Month`, rowsHtml, optTotal, standardTotal);
         return `${quotePageHeaderHtml}${buildMsaContainerHtml(opt.term)}${tableHtml}${upperLegal}`;
       };

       if (options.length > 0) {
         options.forEach((opt, i) => {
           pages.push(wrapPage(buildOptionPageHtml(opt, i), pageNum++));
         });
       } else {
         const defaultBaseRow = `<tr><td style="padding:8px 6px;font-size:10px;vertical-align:top;border-bottom:1px solid #ededed;color:#222;">25</td><td style="padding:8px 6px;font-size:10px;vertical-align:top;border-bottom:1px solid #ededed;color:#222;"><div style="font-weight:700;line-height:1.25;">Vehicle Tracking Subscription</div><div style="font-size:9px;color:#555;line-height:1.3;">Driver ID, Panic Button</div></td><td style="padding:8px 6px;text-align:right;vertical-align:top;border-bottom:1px solid #ededed;white-space:nowrap;"><div style="font-size:10px;color:#1a1a1a;line-height:1.25;">$42.00</div></td><td style="padding:8px 6px;text-align:right;vertical-align:top;border-bottom:1px solid #ededed;white-space:nowrap;"><div style="font-size:10px;font-weight:700;color:#1a1a1a;line-height:1.25;">$1,050.00</div></td></tr>`;
         const defaultRows = defaultBaseRow + buildIncludedNoCostRows(1);
         const defaultOptionTableHtml = buildQuoteTableHtml('Option 1', getDefaultQuoteTermLabel(), defaultRows, 1050, 1050);
         pages.push(wrapPage(`${quotePageHeaderHtml}${buildMsaContainerHtml()}${defaultOptionTableHtml}${upperLegal}`, pageNum++));
       }
     }

     // ── PAGE 2: Onboarding Flyer (optional) ───────────────────────
     if (selectedMaterials.has('onboarding')) {
       const HERO_IMG = `https://images.contentstack.io/v3/assets/blt0371ecb1478c7909/blt65a932e3237c46d9/688161b889e3963781bad1ea/vzc-monarch-DOT-desktop-us.webp?auto=webp?w=1920&q=75&auto=webp`;
       const CREW_IMG = `https://images.contentstack.io/v3/assets/blt0371ecb1478c7909/blt65a932e3237c46d9/688161b889e3963781bad1ea/vzc-monarch-DOT-desktop-us.webp?auto=webp?w=800&q=75&auto=webp`;
       const page2 = `${simpleHeader()}<div style="position:relative;margin:0 -24px 24px;overflow:hidden;height:260px;background:#4a5568 url('${HERO_IMG}') center/cover no-repeat;"><div style="position:absolute;left:24px;top:24px;width:46%;background:#ee001e;color:#fff;padding:22px 18px 18px;"><div style="font-size:21px;font-weight:700;line-height:1.18;margin-bottom:10px;">Fast, no&#8209;hassle onboarding with Verizon Connect</div><div style="font-size:12px;line-height:1.4;">Minimize disruption,<br><strong>Maximize ROI.</strong></div></div></div><div style="display:grid;grid-template-columns:1fr 1fr;gap:24px;margin-bottom:26px;"><div style="font-size:12px;color:#222;line-height:1.65;">Running a fleet leaves you with little time to spare. That's why we designed an onboarding process that delivers <strong>fast results with minimal vehicle downtime.</strong> Here's what you can expect:</div><div>${[['Dedicated onboarding success expert','A single point of contact to guide you every step of the way'],['Flexible installation scheduling','Evenings and weekends available, so daily routes stay intact'],['Complete control, always','Pick the installation window that works for you. We handle the logistics']].map(([t,d]) => `<div style="margin-bottom:12px;"><div style="font-size:12px;font-weight:700;color:#1a1a1a;">${t}</div><div style="font-size:11px;color:#555;line-height:1.45;">${d}</div></div>`).join('')}</div></div><div><div style="font-size:18px;font-weight:800;color:#ee001e;margin-bottom:2px;">Your proven, three-step journey</div><div style="font-size:11px;color:#888;margin-bottom:16px;">Efficient. Predictable. Outcome-driven.</div><div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;align-items:start;"><div>${[['Plan for success','We help you prepare for a smooth rollout, minimizing disruption to your business and accelerating ROI.'],['Install with confidence','Our professional installers are experts at installing fleet management solutions, ensuring your installation goes right the first time to minimize fleet downtime.'],['Activate day-one impact','Gain instant access to live tracking, real-time alerts, and the insights required to improve driver safety and operational efficiency, reduce fuel costs, and stay compliant.']].map(([t,d]) => `<div style="margin-bottom:14px;"><div style="font-size:12px;font-weight:700;color:#1a1a1a;margin-bottom:4px;">${t}</div><div style="font-size:11px;color:#555;line-height:1.5;">${d}</div></div>`).join('')}</div><div style="background:#4a5568 url('${CREW_IMG}') center/cover no-repeat;min-height:220px;border-radius:4px;"></div></div></div>`;
       pages.push(wrapPage(page2, pageNum++));
     }

     // ── PAGE 3: Case Study (optional) — contenido hardcodeado de este archivo, plantilla visual de index.html ──
     if (selectedMaterials.has('case-study')) {
       const page3 = `${simpleHeader()}<div style="font-size:11px;font-weight:700;color:#555;margin-bottom:2px;">ROI Success history</div><div style="font-size:20px;font-weight:800;color:#ee001e;margin-bottom:18px;">Safety &amp; Insurance</div><div style="border:1px solid #e0e0e0;border-radius:8px;padding:18px 20px;margin-bottom:18px;"><div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;"><div style="color:#d4a800;font-size:18px;letter-spacing:3px;">&#9733;&#9733;&#9733;&#9733;&#9733;</div><div style="font-size:10px;font-weight:700;color:#555;border:1px solid #ccc;border-radius:4px;padding:3px 8px;">Verified result</div></div><div style="font-size:13px;color:#1a1a1a;margin-bottom:6px;">&quot;Deflected a false claim, saved $200,000 on insurance premiums.&quot;</div><div style="font-size:11px;color:#555;"><strong>Customer:</strong> B.A.M Trucking (Bill Howe)</div><div style="background:#f8f3e9;border:1px solid #e9dfc9;border-radius:6px;padding:12px 14px;margin-top:14px;display:flex;align-items:flex-start;gap:10px;"><span class="material-symbols-outlined" style="font-size:16px;color:#555;flex-shrink:0;margin-top:1px;">verified_user</span><div><div style="font-size:11px;font-weight:700;color:#1a1a1a;margin-bottom:2px;">Proven outcome</div><div style="font-size:11px;color:#444;line-height:1.5;">Reduced accidents by 87%, exonerated drivers from false claims.</div></div></div></div><div style="border:1px solid #e0e0e0;border-radius:8px;overflow:hidden;margin-bottom:24px;"><div style="display:grid;grid-template-columns:1fr 1fr;"><div style="padding:16px 18px;border-right:1px solid #e0e0e0;"><div style="font-size:12px;font-weight:700;margin-bottom:10px;">Common challenges</div><ul style="margin:0;padding-left:16px;font-size:11px;color:#444;line-height:1.9;"><li>False accident claims</li><li>High insurance premiums</li><li>Reputation damage</li></ul></div><div style="padding:16px 18px;"><div style="font-size:12px;font-weight:700;margin-bottom:10px;">Verizon Connect Solution</div><ul style="margin:0;padding-left:16px;font-size:11px;color:#444;line-height:1.9;"><li>Dashcams (Integrated Video)</li><li>Harsh driving alerts</li><li>Driver safety scorecards</li></ul></div></div></div><div style="background:#f5f5f5;margin:0 -24px -24px;padding:36px 24px;text-align:center;"><div style="margin-bottom:10px;"><span class="material-symbols-outlined" style="font-size:28px;color:#1a1a1a;">videocam</span></div><div style="font-size:17px;font-weight:800;color:#1a1a1a;margin-bottom:8px;">Want to see the full story?</div><div style="font-size:12px;color:#666;margin-bottom:22px;">Scan or click below to view the full success story and video testimonial.</div><div style="display:inline-block;color:#0B5FFF;font-size:13px;font-weight:700;text-decoration:underline;cursor:default;">View details</div></div>`;
       pages.push(wrapPage(page3, pageNum++));
     }

     // ── PAGE 4: ROI / Business Impact Analysis (optional) ─────────
     if (selectedMaterials.has('roi')) {
       let totalUnitsAll = 0;
       options.forEach(opt => opt.bundles.forEach(b => { totalUnitsAll += b.qty; }));
       const fleetSize = totalUnitsAll || 50;
       const cfg = getRoiConfig();
       const weeksPerMonth = 52 / 12;
       let grossMonthly = 0;
       const roiRows = [];

       if (cfg.productivity.enabled) {
         const { billingMethod, avgBillRate, jobsPerWeek, efficiencyGain } = cfg.productivity;
         const monthlyGain = avgBillRate * jobsPerWeek * (efficiencyGain / 100) * fleetSize * weeksPerMonth;
         grossMonthly += monthlyGain;
         const methodLabel = billingMethod === 'perHour' ? 'Hrs/Wk/Veh' : 'Jobs/Wk/Veh';
         roiRows.push({ icon: 'trending_up', title: 'Productivity', detail: `${methodLabel}: ${jobsPerWeek} &nbsp;|&nbsp; Rate: $${avgBillRate.toFixed(2)} &nbsp;|&nbsp; Gain: ${efficiencyGain}%`, label: 'Monthly Gain', value: formatMoney(monthlyGain) });
       }

       if (cfg.fuel.enabled) {
         const { costPerGallon, galSavedPerWeekVeh } = cfg.fuel;
         const monthlyGain = costPerGallon * galSavedPerWeekVeh * fleetSize * weeksPerMonth;
         grossMonthly += monthlyGain;
         roiRows.push({ icon: 'local_gas_station', title: 'Fuel Cost Reduction', detail: `Avg: $${costPerGallon}/gal &nbsp;|&nbsp; Saved: ${galSavedPerWeekVeh} gal/wk`, label: 'Monthly Gain', value: formatMoney(monthlyGain) });
       }

       if (cfg.payroll.enabled) {
         const { otHoursPerWeek, hourlyRate, includeMaint, maintSavePerVeh } = cfg.payroll;
         const payrollMonthly = hourlyRate * otHoursPerWeek * fleetSize * weeksPerMonth;
         const maintMonthly = includeMaint ? (maintSavePerVeh * fleetSize / 12) : 0;
         const totalMonthlyPayroll = payrollMonthly + maintMonthly;
         grossMonthly += totalMonthlyPayroll;
         const detail = `Rate: $${hourlyRate}/hr &nbsp;|&nbsp; Reduced: ${otHoursPerWeek} hrs/wk${includeMaint ? ` &nbsp;|&nbsp; Maint: $${maintSavePerVeh}/veh/yr` : ''}`;
         roiRows.push({ icon: 'attach_money', title: 'Payroll' + (includeMaint ? ' &amp; Maintenance' : ' Optimization'), detail, label: 'Monthly Savings', value: formatMoney(totalMonthlyPayroll) });
       }

       const safetyEnabled = cfg.safety.hasVideo;
       let estAnnualLiability = 0;
       if (safetyEnabled) {
         const { avgAccidentCost, accidentsPerYear, liabilityPct } = cfg.safety;
         estAnnualLiability = avgAccidentCost * accidentsPerYear * (liabilityPct / 100);
         const safetyMonthly = estAnnualLiability / 12;
         grossMonthly += safetyMonthly;
         roiRows.push({ icon: 'shield', title: 'Safety &amp; Cameras', detail: `Avg Accident: $${avgAccidentCost.toLocaleString()} &nbsp;|&nbsp; Liability reduction: ${liabilityPct}%`, label: 'Est. Monthly Savings', value: formatMoney(safetyMonthly) });
       }

       let sysInvestment = 0;
       if (options.length > 0) {
         const firstOpt = options[0];
         const { totalMonthly } = calcOption(firstOpt, getOptionPromotion(firstOpt), firstOpt.forcedTierIndex ?? -1);
         sysInvestment = totalMonthly;
       }
       const netBenefit = grossMonthly - sysInvestment;
       const roiRatio = sysInvestment > 0 ? (grossMonthly / sysInvestment).toFixed(1) : '—';

       const roiRowsHtml = roiRows.map(r => `<div style="display:flex;justify-content:space-between;align-items:center;padding:13px 0;border-bottom:1px solid #f0f0f0;"><div style="display:flex;align-items:center;gap:12px;"><div style="width:36px;height:36px;border:1px solid #e0e0e0;border-radius:6px;display:flex;align-items:center;justify-content:center;flex-shrink:0;"><span class="material-symbols-outlined" style="font-size:18px;color:#555;">${r.icon}</span></div><div><div style="font-size:12px;font-weight:700;color:#1a1a1a;margin-bottom:2px;">${r.title}</div><div style="font-size:10px;color:#888;">${r.detail}</div></div></div><div style="text-align:right;flex-shrink:0;"><div style="font-size:10px;color:#888;margin-bottom:1px;">${r.label}</div><div style="font-size:14px;font-weight:700;color:#1a1a1a;">${r.value}</div></div></div>`).join('');

       const page4 = `${simpleHeader()}<div style="font-size:20px;font-weight:800;color:#ee001e;margin-bottom:4px;">Business Impact Analysis</div><div style="margin-bottom:18px;">${roiRowsHtml || '<div style="font-size:12px;color:#aaa;padding:16px 0;text-align:center;">No categories selected.</div>'}</div><div style="background:#f8f3e9;margin:0 -24px 22px;padding:20px 24px;text-align:center;"><div style="font-size:14px;font-weight:800;color:#ee001e;margin-bottom:2px;">Estimated Monthly Financial Impact</div><div style="font-size:10px;color:#888;margin-bottom:16px;">Based on fleet size: ${fleetSize}</div><div style="display:flex;align-items:center;justify-content:center;gap:14px;flex-wrap:wrap;"><div><div style="font-size:22px;font-weight:900;color:#1a1a1a;">${formatMoney(grossMonthly)}</div><div style="background:#16a34a;color:#fff;font-size:9px;font-weight:700;border-radius:3px;padding:2px 7px;margin-top:4px;display:inline-block;">Gross Monthly Savings</div></div><div style="font-size:22px;color:#555;font-weight:300;">−</div><div><div style="font-size:22px;font-weight:900;color:#1a1a1a;">${formatMoney(sysInvestment)}</div><div style="background:#1d4ed8;color:#fff;font-size:9px;font-weight:700;border-radius:3px;padding:2px 7px;margin-top:4px;display:inline-block;">System Investment</div></div><div style="font-size:22px;color:#555;font-weight:300;">=</div><div><div style="font-size:22px;font-weight:900;color:#1a1a1a;">${formatMoney(netBenefit)}</div><div style="background:#1d4ed8;color:#fff;font-size:9px;font-weight:700;border-radius:3px;padding:2px 7px;margin-top:4px;display:inline-block;">Net Monthly Benefit</div></div></div><div style="font-size:11px;color:#555;margin-top:12px;">ROI Ratio ${roiRatio}:1</div></div>${safetyEnabled ? `<div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;align-items:start;"><div><div style="font-size:14px;font-weight:800;color:#1a1a1a;margin-bottom:8px;">Video Safety ROI and Liability Protection</div><div style="font-size:11px;color:#444;line-height:1.65;">Implementing Video Telematics (Dash Cams) significantly reduces liability exposure by providing exonerating evidence in false claims and improving driver behavior. Industry data suggests commercial fleets can reduce accident frequency by up to 40%.*</div></div><div style="border:1px solid #e0e0e0;border-radius:8px;padding:16px;"><div style="margin-bottom:12px;"><div style="font-size:10px;color:#888;margin-bottom:2px;">AVG Cost of Accident</div><div style="font-size:13px;font-weight:700;color:#1a1a1a;">${formatMoney(cfg.safety.avgAccidentCost)}</div></div><div style="margin-bottom:12px;"><div style="font-size:10px;color:#888;margin-bottom:2px;">EST Accidents Avoided</div><div style="font-size:13px;font-weight:700;color:#1a1a1a;">${cfg.safety.accidentsPerYear} / Year</div></div><div><div style="font-size:10px;color:#888;margin-bottom:2px;">EST Annual Liability Savings</div><div style="font-size:14px;font-weight:800;color:#ee001e;">${formatMoney(estAnnualLiability)}</div><div style="font-size:10px;color:#888;">Non-recurring / Insurance</div></div></div></div>` : ''}`;
       pages.push(wrapPage(page4, pageNum++));
     }

     viewer.innerHTML = pages.join('');
     fillProposalMessageDefaults();
     requestAnimationFrame(scaleDocPages);
   }
   ```

**Efecto:** el PDF de "Review & Send Proposal" en cuentas existentes queda visualmente idéntico al de cuentas nuevas — una página por opción con el contenedor MSA arriba de la tabla de precios, mismo estilo de footer/paginación en todas las páginas, misma estructura en las páginas opcionales (Onboarding, Case Study, ROI). El logo y las imágenes de onboarding se quedan con sus URLs remotas actuales (funcionando), y la página de case study usa la plantilla visual nueva con el contenido de éxito que ya tenía este archivo (sin selector de múltiples casos, esa es una feature aparte no incluida aquí).

---

## 8. Actualización (2026-09-08): que la pantalla de entrada al modal se vea igual a cuentas nuevas (sin migrar el editor)

**Requerimiento de Catalina, con alcance acotado explícitamente por ella:** "no quiero migrar toda la funcionalidad de editar pero sí quiero que visualmente cuando entras al modal se vea igual." Esto es SOLO sobre la pantalla que aparece al abrir "Review & Send Proposal" — no sobre el editor completo.

**Lo que cambió en cuentas nuevas y no en cuentas existentes:** en `index.html`, la pantalla de entrada ya NO es la vista dividida (mensaje a la izquierda, documento completo a la derecha) que `valucal_existing_accounts.html` sigue mostrando siempre. Ahora es una vista resumen con dos cards chiquitas — "Email body" y "PDF" — cada una con una miniatura del contenido y un botón "Edit". Solo al hacer clic en "Edit" se revela la vista dividida completa (con un sistema de formato de mensaje con tokens que Catalina explícitamente no quiere migrar).

**3 decisiones de alcance que Catalina confirmó explícitamente — no asumidas por mí:**
1. Los botones "Edit" de las dos cards **no hacen nada por ahora** (sin `onclick`, o deshabilitados). No se construye ningún editor ni vista dividida nueva.
2. El dropdown de "Materials" (Onboarding/Case study/ROI) y la calculadora de ROI **quedan inaccesibles por ahora** — en `index.html` esos controles viven dentro de la vista de Edit del PDF, que aquí no se construye. Catalina aceptó esta limitación temporal en vez de dejarlos visibles en el resumen.
3. **No se porta el bloque de "Rep info" inline** (nombre/email/teléfono del rep editable en la cabecera) que sí existe en `index.html` — es una feature que `valucal_existing_accounts.html` nunca tuvo, y agregarla es un alcance distinto al pedido ("que se vea igual la entrada al modal", no "agregar información nueva"). Si Catalina la quiere después, es un punto aparte.

**Lo que SÍ se porta:** las dos cards con miniatura (Email/PDF) reemplazando la vista dividida siempre-visible, y los campos de Expiration date / Close date se quedan funcionando igual que hoy (mismos IDs, mismo comportamiento) — solo se reordenan visualmente dentro de la nueva estructura.

**Pieza que sigue existiendo pero se esconde:** todo el HTML que hoy está siempre visible (`prop-msg-to`, `prop-msg-subject`, `prop-msg-body`, el dropdown de materiales, el panel de ROI, `prop-doc-viewer`) **no se borra** — sigue en el DOM pero oculto (`hidden`), porque `renderProposalDoc()`, `fillProposalMessageDefaults()`, `getSelectedMaterials()` y `getRoiConfig()` siguen leyendo esos elementos por ID. Se mantienen con los valores que ya tengan (los de hoy / los defaults), simplemente no se pueden cambiar desde la UI hasta que se decida portar el editor.

**Piezas a tocar, todas en `app/demos/valucal_existing_accounts.html`:**

1. **Ampliar la regla `.proposal-review-modal`** (línea ~1810-1818) — agregar las variables y el tamaño nuevo. Cambiar:
   ```css
   .proposal-review-modal {
     width: min(1280px, 96vw);
     max-height: 92vh;
     overflow: hidden;
     background: #F9FAFB;
     border-radius: 10px;
     display: flex;
     flex-direction: column;
   }
   ```
   por:
   ```css
   .proposal-review-modal {
     --proposal-pdf-surface: #ffffff;
     --proposal-header-surface: #f8f3ea;
     --proposal-header-band-height: 52px;
     --proposal-modal-pad-x: 12px;
     width: min(1700px, 90vw);
     height: 95vh;
     max-height: 95vh;
     overflow: hidden;
     background: #ffffff;
     border-radius: 10px;
     display: flex;
     flex-direction: column;
   }
   ```

2. **CSS nuevo** — agregar en cualquier parte de la hoja de estilos (copiado de `index.html`, líneas 2104-2110 y 2343-2581, con los selectores de rep-info y materials-menu ya excluidos porque no se portan):
   ```css
   .proposal-general-direct {
     padding: 6px var(--proposal-modal-pad-x);
     margin-bottom: 0;
     border-bottom: 1px solid var(--gray-200);
     background: var(--white);
   }
   .proposal-general-card {
     border: 0;
     border-radius: 0;
     background: transparent;
     padding: 0;
   }
   .proposal-customization-grid {
     display: grid;
     grid-template-columns: repeat(2, minmax(0, 1fr));
     flex: 1;
     width: 100%;
     min-width: 0;
     min-height: 0;
     align-items: stretch;
     gap: 0;
     border: 1px solid #d7dde5;
     border-radius: 12px;
     overflow: hidden;
     background: #fff;
     box-shadow: 0 1px 2px rgba(16, 24, 40, 0.04);
   }
   .proposal-customization-wrap {
     flex: 1;
     width: 100%;
     min-height: 0;
     display: flex;
     box-sizing: border-box;
     overflow: hidden;
     padding: 12px 12px 12px;
     background: transparent;
   }
   .proposal-customization-card {
     border: 0;
     border-radius: 0;
     min-width: 0;
     min-height: 0;
     display: flex;
     flex-direction: column;
     padding: 0;
     background: transparent;
   }
   .proposal-customization-thumb {
     position: relative;
     border: 0;
     border-radius: 0;
     background: transparent;
     height: auto;
     min-height: 210px;
     flex: 1;
     overflow: hidden;
     margin-bottom: 0;
   }
   .proposal-customization-thumb__inner {
     width: 100%;
     height: 100%;
     overflow-y: auto;
     overflow-x: hidden;
     position: relative;
     padding-right: 0;
   }
   .proposal-customization-thumb__fade {
     position: absolute;
     left: 0;
     right: 0;
     bottom: 0;
     height: 58px;
     background: linear-gradient(180deg, rgba(255,255,255,0) 0%, #fff 88%);
     pointer-events: none;
     display: none;
   }
   .proposal-customization-thumb .doc-page-outer { margin-bottom: 8px; }
   .proposal-customization-message-frame {
     padding: 12px 14px 16px;
     font-size: 12px;
     line-height: 1.5;
     color: #1a1a1a;
   }
   .proposal-customization-message-frame .msg-chip { font-size: 11px; }
   .proposal-customization-empty {
     height: 100%;
     display: flex;
     align-items: center;
     justify-content: center;
     color: var(--gray-600);
     font-size: 12px;
   }
   .proposal-customization-card__head {
     display: grid;
     grid-template-columns: minmax(0, 1fr) auto;
     align-items: center;
     column-gap: 8px;
     background: var(--proposal-header-surface);
     padding-top: 8px;
     padding-right: 12px;
     padding-bottom: 10px;
     margin-bottom: 0;
     min-height: var(--proposal-header-band-height);
     box-sizing: border-box;
     position: relative;
   }
   .proposal-customization-head-actions {
     display: inline-flex;
     align-items: center;
     gap: 8px;
     justify-self: end;
   }
   .proposal-customization-card__title {
     display: flex;
     align-items: center;
     min-height: 32px;
     font-size: 14px;
     font-weight: 700;
     line-height: 1.1;
   }
   .proposal-customization-edit-btn {
     height: 32px !important;
     min-height: 32px !important;
     padding: 0 12px !important;
     font-size: 14px;
   }
   .proposal-customization-icon-btn {
     width: 32px;
     height: 32px;
     min-height: 32px;
     border: 1.5px solid var(--black);
     border-radius: 999px;
     background: transparent;
     color: var(--black);
     display: inline-flex;
     align-items: center;
     justify-content: center;
     cursor: pointer;
   }
   .proposal-customization-icon-btn .material-symbols-outlined { font-size: 18px; }
   .proposal-customization-card--pdf .proposal-customization-thumb {
     background: var(--proposal-pdf-surface);
     margin-bottom: 0;
   }
   .proposal-customization-card--pdf .proposal-customization-thumb__inner {
     display: flex;
     flex-direction: column;
     align-items: flex-start;
     justify-content: flex-start;
     gap: 8px;
     background: var(--proposal-pdf-surface);
     padding: 10px 0 0;
     margin: 0;
     scrollbar-color: #c2c2c2 var(--proposal-pdf-surface);
   }
   .proposal-customization-card--pdf #customization-pdf-preview {
     display: flex;
     flex-direction: column;
     width: 100%;
     background: var(--proposal-pdf-surface) !important;
     padding: 10px 0 0 !important;
     margin: 0 !important;
   }
   .proposal-customization-card--pdf #customization-pdf-preview .doc-page-outer {
     height: auto !important;
     overflow: visible !important;
   }
   .proposal-customization-card--pdf #customization-pdf-preview .vc-doc-shell {
     width: 90% !important;
     max-width: 90% !important;
     transform: none !important;
     margin-left: auto !important;
     margin-right: auto !important;
   }
   .proposal-customization-card--pdf .proposal-customization-thumb__inner .doc-page-outer {
     margin-left: 0;
     margin-right: 0;
     margin-top: 0;
     margin-bottom: 0;
   }
   .proposal-customization-card--pdf {
     --proposal-pdf-surface: var(--gray-100);
     background: var(--proposal-pdf-surface);
     border-left: 1px solid var(--gray-200);
     border-radius: 0;
     padding: 0;
   }
   .proposal-customization-card--pdf .proposal-customization-thumb__fade {
     background: linear-gradient(180deg, rgba(248,247,245,0) 0%, var(--proposal-pdf-surface) 88%);
   }
   .proposal-customization-card--message {
     border: 0;
     border-radius: 0;
     background: var(--white);
     padding: 0;
   }
   .proposal-customization-card--message .proposal-customization-card__head {
     margin-bottom: 0;
     padding-left: 12px;
     padding-right: 12px;
   }
   .proposal-customization-card--pdf .proposal-customization-card__head {
     margin-left: 0;
     padding-left: 12px;
     padding-right: 12px;
     background: var(--proposal-header-surface);
   }
   .proposal-customization-card--message .proposal-customization-thumb__inner { overflow-y: auto; }
   ```

3. **Reemplazar el HTML de `#proposal-review-layout`** (líneas 4951-5153) — cambiar el bloque actual (`review-message-pane` + `review-preview-pane` siempre visibles) por:
   ```html
   <div class="review-content-layout" id="proposal-review-layout">
     <div class="proposal-general-direct">
       <div class="proposal-general-card">
         <div style="display:flex; gap:16px; align-items:flex-end; flex-wrap:wrap;">
           <div class="proposal-review-field" style="flex:0 0 160px;">
             <div class="proposal-review-label">Expiration date</div>
             <input type="date" id="proposal-expiration-date" class="vds-input proposal-date-input" lang="en-US" oninput="onProposalExpirationChange(); updateSendBtn()">
           </div>
           <div class="proposal-review-field" style="flex:0 0 160px;">
             <div class="proposal-review-label">Close date</div>
             <input type="date" id="proposal-close-date" class="vds-input proposal-date-input" lang="en-US" oninput="updateSendBtn()" required>
             <div id="close-date-error" class="proposal-field-error hidden">Required to send</div>
           </div>
         </div>
       </div>
     </div>

     <div class="proposal-customization-wrap">
       <div class="proposal-customization-grid">
         <div class="proposal-customization-card proposal-customization-card--message">
           <div class="proposal-customization-card__head">
             <div class="proposal-customization-card__title">Email body</div>
             <button type="button" class="btn btn--secondary btn--small proposal-customization-edit-btn" disabled title="Coming soon">Edit</button>
           </div>
           <div class="proposal-customization-thumb" aria-hidden="true">
             <div id="customization-message-preview" class="proposal-customization-thumb__inner"></div>
             <div class="proposal-customization-thumb__fade"></div>
           </div>
         </div>
         <div class="proposal-customization-card proposal-customization-card--pdf">
           <div class="proposal-customization-card__head">
             <div class="proposal-customization-card__title">PDF</div>
             <div class="proposal-customization-head-actions">
               <button type="button" class="proposal-customization-icon-btn" onclick="downloadPdfFromModal()" aria-label="Download proposal preview" title="Download">
                 <span class="material-symbols-outlined">download</span>
               </button>
               <button type="button" class="btn btn--secondary btn--small proposal-customization-edit-btn" disabled title="Coming soon">Edit</button>
             </div>
           </div>
           <div class="proposal-customization-thumb" aria-hidden="true">
             <div id="customization-pdf-preview" class="proposal-customization-thumb__inner"></div>
             <div class="proposal-customization-thumb__fade"></div>
           </div>
         </div>
       </div>
     </div>

     <!-- Oculto: sigue siendo la fuente de datos real para renderProposalDoc()/fillProposalMessageDefaults()/getSelectedMaterials()/getRoiConfig().
          Materials y ROI quedan con los valores que ya tengan (defaults) — no editables desde la UI hasta que se porte el editor. -->
     <div class="hidden" id="proposal-review-hidden-source" aria-hidden="true">
       <!-- Todo el contenido que estaba en review-message-pane (To/Subject/Message/ROI config) y en review-preview-pane
            (título "Proposal review", fila de Expiration/Close/Materials, .review-preview-card > #prop-doc-viewer)
            se mueve aquí TAL CUAL, sin modificar ningún id ni atributo. -->
     </div>
   </div>
   ```
   **Importante:** los inputs `#proposal-expiration-date` y `#proposal-close-date` que quedaban dentro de `review-preview-pane` se BORRAN de ahí (ya están arriba, en `proposal-general-card`) — no debe haber dos elementos con el mismo id en el documento. El resto de esa fila (el dropdown de Materials) sí se mueve completo al bloque oculto.

4. **Nueva función `renderCustomizationThumbnails()`** — agregar cerca de `renderProposalDoc()`:
   ```js
   function renderCustomizationThumbnails() {
     const pdfThumb = document.getElementById('customization-pdf-preview');
     const msgThumb = document.getElementById('customization-message-preview');
     const sourceDoc = document.getElementById('prop-doc-viewer');
     const bodyEl = document.getElementById('prop-msg-body');

     if (pdfThumb) {
       pdfThumb.innerHTML = '';
       const pages = sourceDoc ? Array.from(sourceDoc.querySelectorAll('.doc-page-outer')) : [];
       if (pages.length) {
         pages.forEach(function (page) { pdfThumb.appendChild(page.cloneNode(true)); });
       } else {
         pdfThumb.innerHTML = '<div class="proposal-customization-empty">Preview unavailable</div>';
       }
     }

     if (msgThumb) {
       const messageHtml = bodyEl && bodyEl.innerHTML ? bodyEl.innerHTML : '<em>No message content yet.</em>';
       msgThumb.innerHTML = '<div class="proposal-customization-message-frame">' + messageHtml + '</div>';
     }
   }
   ```
   (Versión simplificada de la de `index.html` — se quita `scaleDocPagesInContainer()` porque el CSS de arriba ya fuerza el ancho de la página al 90% del thumb sin necesitar reescalar por JS.)

5. **Llamarla al final de `renderProposalDoc()`** (la versión ya reemplazada en el punto 7 de este documento) — donde dice:
   ```js
   viewer.innerHTML = pages.join('');
   fillProposalMessageDefaults();
   requestAnimationFrame(scaleDocPages);
   ```
   agregar una línea:
   ```js
   viewer.innerHTML = pages.join('');
   fillProposalMessageDefaults();
   requestAnimationFrame(scaleDocPages);
   renderCustomizationThumbnails();
   ```
   Como `renderProposalDoc()` ya se llama cada vez que cambia algo (fecha de expiración, materiales, ROI — ver los call sites existentes), las miniaturas se refrescan solas.

**Efecto:** al abrir "Review & Send Proposal" en cuentas existentes, se ve la misma pantalla resumen que en cuentas nuevas — dos cards con miniatura (Email body / PDF) en vez de los paneles completos siempre visibles. Los botones "Edit" están deshabilitados (no hacen nada). Expiration date y Close date se quedan arriba, funcionando igual que hoy. El dropdown de Materials y el panel de ROI quedan sin acceso desde la UI por ahora — los valores que tengan por defecto son los que se usan para armar el PDF y el email.

---

## 9. Actualización (2026-09-08): diseño visual del email (no solo el PDF)

**Depende del punto 8** — la card "Email body" del punto 8 clona directamente el `innerHTML` de `#prop-msg-body` (ver `renderCustomizationThumbnails()`, punto 8, paso 4: `bodyEl && bodyEl.innerHTML`). Hoy `fillProposalMessageDefaults()` en `valucal_existing_accounts.html` llena `#prop-msg-body` con texto plano (`[Contact name],<br><br>...`), así que la card se ve como un bloque de texto. En `index.html`, `#prop-msg-body` se llena con un email HTML con marca (header con logo, imagen hero, secciones con estilo, footer) — por eso ahí la card sí se ve como un email de verdad.

**Alcance:** solo cambia lo que arma `fillProposalMessageDefaults()`. No se toca el motor de bloques/tokens de `index.html` (`MESSAGE_BLOCK_IDS`, `buildProposalVisualMessageHtmlFromBlocks`, selector de formato) — eso sigue fuera de alcance por decisión de Catalina. Se reutiliza el contenido que esta función ya calcula hoy (bloques de precio por opción, bullets de "package includes" y "why Verizon"), solo que envuelto en la plantilla visual en vez de texto plano.

**Imágenes:** no hace falta subir ni migrar nada — `header.jpg`, `logo.svg` y `verizon-connect-logo.svg` ya existen, con el mismo contenido (MD5 idéntico) que usa `index.html`, en `Valu cal/app/assets/`. Como `valucal_existing_accounts.html` vive en `app/demos/`, se referencian como `../assets/header.jpg` y `../assets/logo.svg` (esta misma convención de ruta relativa ya la usa el archivo para sus fuentes, línea 8).

**Piezas a tocar, todas en `app/demos/valucal_existing_accounts.html`:**

1. **Agregar el CSS del email visual** — insertarlo justo después de la regla `.proposal-review-modal.is-preview-focus .review-preview-pane { width: 100%; padding: 28px 32px; }` (línea ~1857-1860), copiado tal cual de `index.html` (líneas 3129-3212):
   ```css
   .vez-email__global-header { background:#fff; border-bottom:1px solid #e5e5e5; display:flex; align-items:center; justify-content:space-between; padding:16px; flex-shrink:0; }
   .vez-email__global-header-logo img { height:32px; display:block; }
   .vez-email__hero { background:linear-gradient(to right, rgba(255,255,255,0.9), rgba(255,255,255,0)),url('../assets/header.jpg') center/cover no-repeat; color:#000; padding:47px 24px 42px; }
   .vez-email__hero h1 { margin:0 0 8px; font-size:40pt; font-weight:900; line-height:0.98; letter-spacing:-0.01em; }
   .vez-email__hero p { margin:0; font-size:15px; opacity:.9; line-height:1.5; }
   .vez-email__body { }
   .vez-email__block { padding:24px; border-bottom:1px solid #f0f0f0; }
   .vez-email__block:last-child { border-bottom:none; }
   .vez-email__block--no-border { border-bottom:none; padding-bottom:0; }
   .vez-email__block-label { margin:0 0 10px; font-size:17px; font-weight:900; color:#ee001e; letter-spacing:.01em; }
   .vez-email__block p,.vez-email__block > div { font-size:15px; line-height:1.65; color:#1a1a1a; margin:0 0 8px; }
   .vez-email__block ul { margin:6px 0 0; padding-left:20px; font-size:15px; line-height:1.8; color:#1a1a1a; }
   .vez-email__pricing { margin-top:2px; }
   .vez-email__option-card { background:transparent; padding:16px 0; border-bottom:1px solid #e9dfc9; }
   .vez-email__option-card:first-child { padding-top:0; }
   .vez-email__option-card:last-child { border-bottom:none; padding-bottom:0; }
   .vez-email__option-head { display:flex; align-items:baseline; justify-content:space-between; gap:10px; }
   .vez-email__option-name { font-size:15px; font-weight:900; color:#ee001e; }
   .vez-email__option-term { font-size:12px; font-weight:400; color:#000; margin-top:0; text-align:right; }
   .vez-email__option-divider { height:1px; background:#e9dfc9; margin:10px 0; }
   .vez-email__option-line { display:flex; justify-content:space-between; gap:12px; font-size:13px; color:#1a1a1a; padding:3px 0; }
   .vez-email__option-line-price { font-weight:700; white-space:nowrap; }
   .vez-email__option-total-line { display:flex; justify-content:space-between; align-items:baseline; }
   .vez-email__option-total-line span:first-child { font-size:13px; font-weight:700; color:#1a1a1a; }
   .vez-email__option-total-line span:last-child { font-size:17px; font-weight:900; color:#ee001e; }
   .vez-email__footer { background:#fff; border-top:1px solid #e8e8e8; padding:28px 24px 24px; }
   ```
   (Se omiten a propósito las reglas de `.vez-email__check-list`, `.vez-email__materials-*`, `.vez-email__followup-*` y `.vez-email__note-*` de `index.html` — son para bloques del motor de tokens que no se están portando. Si más adelante se agrega alguno de esos bloques, se copia su regla correspondiente en ese momento.)

2. **Reemplazar `fillProposalMessageDefaults()`** (hoy en las líneas ~9405-9467) completa, por:
   ```js
   function fillProposalMessageDefaults() {
     const toEl = document.getElementById('prop-msg-to');
     const subjectEl = document.getElementById('prop-msg-subject');
     const bodyEl = document.getElementById('prop-msg-body');
     if (!toEl || !subjectEl || !bodyEl) return;

     // Only pre-fill once per modal open (don't overwrite manual edits)
     const alreadyFilled = bodyEl.dataset.autofilled === 'true';

     subjectEl.value = subjectEl.value || 'Verizon Connect info & pricing';
     toEl.value = toEl.value || 'laura.mendez@acmelogistics.com';

     if (!alreadyFilled) {
       // Build per-option pricing cards as rich HTML (same classes as the PDF/email visual template)
       const optionBlocksHtml = options.map((opt, optIdx) => {
         let totalUnits = 0;
         opt.bundles.forEach(b => { totalUnits += b.qty; });
         const forcedIdx = opt.forcedTierIndex ?? -1;
         const termMonths = parseInt(opt.term);
         const { totalMonthly } = calcOption(opt, getOptionPromotion(opt), forcedIdx);

         const bundleLinesHtml = opt.bundles.map(b => {
           const { unitPrice } = calcBundle(b, opt.term, b.promoType || 'Standard', forcedIdx, totalUnits);
           const featNames = (b.features || b.selectedFeatures || []).map(k => featureLabels[k] || k).filter(Boolean);
           const desc = featNames.length ? `${b.coreName} + ${featNames.join(' + ')}` : b.coreName;
           return `<div class="vez-email__option-line"><span>${b.qty}x ${desc}</span><span class="vez-email__option-line-price">$${unitPrice.toFixed(2)}/mo</span></div>`;
         }).join('');

         const vehicleWord = totalUnits === 1 ? 'vehicle' : 'vehicles';
         return `<div class="vez-email__option-card">` +
           `<div class="vez-email__option-head"><div class="vez-email__option-name">Option ${optIdx + 1}</div><div class="vez-email__option-term">${termMonths} Month</div></div>` +
           `<div class="vez-email__option-divider"></div>` +
           bundleLinesHtml +
           `<div class="vez-email__option-divider"></div>` +
           `<div class="vez-email__option-total-line"><span>Total for ${totalUnits} ${vehicleWord}</span><span>$${totalMonthly.toFixed(2)}/mo</span></div>` +
           `</div>`;
       }).join('');

       const globalHeader =
         `<div class="vez-email__global-header"><div class="vez-email__global-header-logo"><img src="../assets/logo.svg" alt="Verizon Connect"></div></div>`;

       const hero =
         `<div class="vez-email__hero"><h1>Your Custom<br>Fleet Quote.</h1><p>A smarter way to run your fleet.</p></div>`;

       const introBlock =
         `<div class="vez-email__block"><p>[Contact name],</p>` +
         `<p>Thank you for your time today. The quote and info we discussed are all below. If anything pops up between now and then, feel free to reach out directly - [Your phone]</p></div>`;

       const pricingBlock =
         `<div class="vez-email__block"><div class="vez-email__block-label">Your Quote</div><div class="vez-email__pricing">${optionBlocksHtml}</div></div>`;

       const packageBlock =
         `<div class="vez-email__block"><div class="vez-email__block-label">Your Customized Package Includes:</div>` +
         `<ul><li>Complete price lock guarantee on services</li><li>Waived Activation Fees</li><li>Waived Equipment Cost ($399-$699 value)</li><li>On-site professional installation</li><li>45 Day Roll out period applied</li></ul></div>`;

       const whyBlock =
         `<div class="vez-email__block vez-email__block--no-border"><div class="vez-email__block-label">Why Choose Verizon Connect Over 3rd Party Providers:</div>` +
         `<ul><li><b>In-house support:</b> No third parties — Verizon handles hardware, software, and support directly.</li>` +
         `<li><b>Network reliability:</b> 99.9% uptime guarantee with satellite + cell tower backup. No dead zones.</li>` +
         `<li><b>Flexible terms:</b> Defaults to month-to-month after the initial agreement — you're never locked in long-term.</li></ul></div>`;

       const year = new Date().getFullYear();
       const footer =
         `<div class="vez-email__footer"><p style="margin:0 0 12px;font-size:13px;color:#1a1a1a;">© ${year} Verizon. All rights reserved.</p>` +
         `<img src="../assets/logo.svg" alt="Verizon Connect" style="height:32px;display:block;"></div>`;

       bodyEl.innerHTML = `<div class="vez-email">${globalHeader}${hero}<div class="vez-email__body">${introBlock}${pricingBlock}${packageBlock}${whyBlock}</div>${footer}</div>`;

       bodyEl.dataset.autofilled = 'true';
     }

     updateCharCount(bodyEl);
     updateSendBtn();
   }
   ```
   Cambios respecto a la versión actual: (a) ya no arma el mensaje con `<br>` sueltos — usa las mismas clases `.vez-email__*` que el PDF/email de cuentas nuevas; (b) agrega el header con logo, el hero con foto e imagen de marca, y el footer, que hoy no existen; (c) se mantiene el guard `alreadyFilled` y el flag `bodyEl.dataset.autofilled` igual que antes, para no pisar ediciones manuales ni reconstruir en cada refresco.

3. **No se toca `hideProposalReviewModal()`** — ya resetea `bodyEl.dataset.autofilled = ''` al cerrar el modal (línea ~12127), así que al reabrir se reconstruye el email visual con los datos vigentes de las opciones.

**Efecto:** la card "Email body" del punto 8 ahora clona un email con la misma identidad visual que cuentas nuevas — header con logo, imagen hero, tarjetas de precio por opción con el mismo estilo que el PDF, y footer con logo — en vez de un bloque de texto plano.
