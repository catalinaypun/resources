# Valu Cal icons in use — 2026-10-21

Icons the Valu Cal prototype uses today. Rule: **VDS icon library** first; a Material Symbols icon only when VDS has
nothing similar (Valu Cal **local** icons).

- `vds/` — 44 VDS icons (SVG, 24 x 24).
- Local icons — Material Symbols Outlined (weight 400, 24 px), from Google Fonts:
  - `drag_indicator` — Drag handles — https://fonts.google.com/icons?selected=Material+Symbols+Outlined:drag_indicator
  - `calendar_month` — Date fields — https://fonts.google.com/icons?selected=Material+Symbols+Outlined:calendar_month
  - `filter_list` — Filter buttons — https://fonts.google.com/icons?selected=Material+Symbols+Outlined:filter_list

| VDS icon | Material name it replaces | Where |
|---|---|---|
| `checkmark.svg` | `check` | Checks in lists and steps |
| `checkmark-alternate.svg` | `check_circle` | Success notifications, done states |
| `checkmark-alternate.svg` | `task_alt` | Status icons (data) |
| `close.svg` | `close` | Modal / drawer / chip close |
| `close-alt.svg` | `cancel` | Cancelled status (data) |
| `compliance-document.svg` | `contract` | Contract status (data) |
| `down-arrow.svg` | `arrow_downward` | Dashboard column sort (data) |
| `down-caret.svg` | `expand_more` | Accordion chevrons, dropdowns |
| `down-caret.svg` | `keyboard_arrow_down` | Dropdown chevron |
| `download.svg` | `download` | Downloads |
| `duplicate.svg` | `content_copy` | Clone option |
| `edit.svg` | `edit` | Edit actions |
| `email-signature.svg` | `draw` | Signature fields (contract) |
| `enterprise.svg` | `domain` | Account context (header) |
| `error.svg` | `error` | Error notifications |
| `government.svg` | `account_balance` | Government segment chip |
| `grid-view.svg` | `apps` | Salesforce app launcher (mock chrome) |
| `growth.svg` | `trending_up` | Plan groups (upsell summary) |
| `handshake.svg` | `handshake` | Deal result |
| `history.svg` | `restart_alt` | Transaction type card (Renewal) |
| `info.svg` | `info` | Info notifications, tooltips |
| `invitation-accepted.svg` | `mark_email_read` | Contract sent, waiting for signature |
| `left-arrow.svg` | `arrow_back` | Back links |
| `left-caret.svg` | `chevron_left` | Back chevron |
| `link.svg` | `link` | Links |
| `menu.svg` | `menu` | App menu |
| `minus.svg` | `remove` | Steppers (minus) |
| `more-vertical.svg` | `more_vert` | Kebab menus |
| `no.svg` | `block` | Blocked status (data) |
| `no-video.svg` | `videocam_off` | No video |
| `notification.svg` | `notifications` | Notifications |
| `parcel.svg` | `package_2` | Current setup: Active solutions (data) |
| `plus.svg` | `add` | Add actions |
| `right-arrow.svg` | `arrow_forward` | Forward links |
| `search.svg` | `search` | Search fields |
| `single-document.svg` | `description` | Documents |
| `sort.svg` | `unfold_more` | Dashboard column sort (data) |
| `sync.svg` | `sync` | Sync / refresh states |
| `sync.svg` | `refresh` | Refresh contract preview |
| `sync.svg` | `autorenew` | Auto-extend chip |
| `tag.svg` | `sell` | Discounts & Promotions button |
| `trash.svg` | `delete` | Delete option / solution |
| `up-arrow.svg` | `arrow_upward` | Dashboard column sort (data) |
| `up-caret.svg` | `expand_less` | Collapse |
| `upload.svg` | `upload` | File upload |
| `user-registration.svg` | `how_to_reg` | Status icons (data) |
| `video.svg` | `videocam` | Video features |
| `warning.svg` | `warning` | Warning notifications |
