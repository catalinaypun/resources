# Valu Cal icons — 2026-10-21

Rule: icons come from the **VDS icon library**. A Material Symbols icon is used only when VDS has nothing similar
(Valu Cal **local** icons).

- `used-in-valucal/` — the 57 VDS icons the Valu Cal prototype uses.
- `vds-library/` — the full VDS icon library (685 SVG, 24 × 24).
- Local icons (Material Symbols Outlined, weight 400, 24 px) — download from Google Fonts:
  - `drag_indicator` — Drag handles — https://fonts.google.com/icons?selected=Material+Symbols+Outlined:drag_indicator
  - `calendar_month` — Date fields — https://fonts.google.com/icons?selected=Material+Symbols+Outlined:calendar_month
  - `filter_list` — Filter buttons — https://fonts.google.com/icons?selected=Material+Symbols+Outlined:filter_list
  - `radio_button_unchecked` — Fulfillment: "Empty" status (paused flow) — https://fonts.google.com/icons?selected=Material+Symbols+Outlined:radio_button_unchecked
  - `pending` — Fulfillment: "Partial" status (paused flow) — https://fonts.google.com/icons?selected=Material+Symbols+Outlined:pending
  - `waves` — Option deployment waves strip — https://fonts.google.com/icons?selected=Material+Symbols+Outlined:waves

## Map (Material name used in the prototype → VDS icon)

| Material name | VDS icon | Where |
|---|---|---|
| `close` | `close.svg` | Modal / drawer / chip close |
| `check_circle` | `checkmark-alternate.svg` | Success notifications, done states |
| `expand_more` | `down-caret.svg` | Accordion chevrons, dropdowns |
| `check` | `checkmark.svg` | Checks in lists and steps |
| `edit` | `edit.svg` | Edit actions |
| `info` | `info.svg` | Info notifications, tooltips |
| `delete` | `trash.svg` | Delete option / solution |
| `warning` | `warning.svg` | Warning notifications |
| `arrow_back` | `left-arrow.svg` | Back links |
| `sync` | `sync.svg` | Sync / refresh states |
| `sell` | `tag.svg` | Discounts & Promotions button |
| `search` | `search.svg` | Search fields |
| `arrow_forward` | `right-arrow.svg` | Forward links |
| `add` | `plus.svg` | Add actions |
| `remove` | `minus.svg` | Steppers (minus) |
| `more_vert` | `more-vertical.svg` | Kebab menus |
| `draw` | `email-signature.svg` | Signature fields (contract) |
| `refresh` | `sync.svg` | Refresh contract preview |
| `lock` | `lock-closed.svg` | Locked options |
| `download` | `download.svg` | Downloads |
| `content_copy` | `duplicate.svg` | Clone option |
| `bookmark` | `bookmark.svg` | Recommended / saved |
| `videocam` | `video.svg` | Video features |
| `videocam_off` | `no-video.svg` | No video |
| `verified_user` | `security-check.svg` | Verification note |
| `upload` | `upload.svg` | File upload |
| `trending_up` | `growth.svg` | Plan groups (upsell summary) |
| `send` | `send-message.svg` | Send Proposal button |
| `science` | `energy-science.svg` | Simulation / demo tools |
| `restart_alt` | `history.svg` | Transaction type card (Renewal) |
| `power_off` | `turnon-off.svg` | Vehicle attribute: master switch off |
| `notifications` | `notification.svg` | Notifications |
| `menu` | `menu.svg` | App menu |
| `mark_email_read` | `invitation-accepted.svg` | Contract sent, waiting for signature |
| `link` | `link.svg` | Links |
| `keyboard_arrow_down` | `down-caret.svg` | Dropdown chevron |
| `handshake` | `handshake.svg` | Deal result |
| `expand_less` | `up-caret.svg` | Collapse |
| `error` | `error.svg` | Error notifications |
| `emergency` | `ambulance.svg` | Vehicle attribute: emergency vehicle |
| `domain` | `enterprise.svg` | Account context (header) |
| `description` | `single-document.svg` | Documents |
| `chevron_left` | `left-caret.svg` | Back chevron |
| `build` | `tools.svg` | Vehicle attribute: competitor device removal |
| `autorenew` | `sync.svg` | Auto-extend chip |
| `apps` | `grid-view.svg` | Salesforce app launcher (mock chrome) |
| `account_balance` | `government.svg` | Government segment chip |
| `accessible` | `international-symbol-of-access.svg` | Vehicle attribute: wheelchair lift |
| `task_alt` | `checkmark-alternate.svg` | Status icons (data) |
| `shield` | `security-check.svg` | Status icons (data) |
| `pause_circle` | `pause.svg` | Status icons (data) |
| `local_shipping` | `shipping.svg` | Shipping status (data) |
| `local_gas_station` | `gas.svg` | Vehicle attribute (data) |
| `how_to_reg` | `user-registration.svg` | Status icons (data) |
| `contract` | `compliance-document.svg` | Contract status (data) |
| `cancel` | `close-alt.svg` | Cancelled status (data) |
| `block` | `no.svg` | Blocked status (data) |
| `attach_money` | `coin.svg` | Pricing (data) |
| `arrow_downward` | `down-arrow.svg` | Dashboard column sort (data) |
| `arrow_upward` | `up-arrow.svg` | Dashboard column sort (data) |
| `unfold_more` | `sort.svg` | Dashboard column sort (data) |
| `package_2` | `parcel.svg` | Current setup: Active solutions (data) |
