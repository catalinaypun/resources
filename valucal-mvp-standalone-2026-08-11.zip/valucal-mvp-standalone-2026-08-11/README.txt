ValuCal MVP standalone package (updated)

Source used:
- flows/valucal-mvp/app/demos/valucal_mvp.html (latest)

Open in browser:
- valucal-mvp-standalone-2026-08-11.html

Included local assets:
- assets/ds/ (design system)
- assets/app/ (module images, js, css, pdf sample)

Notes:
- Includes the latest proposal email and PDF customization flows from the current MVP file.
