/* ── APPROVALS: shared engine for the per-role Approvals pages ──
   Loaded by index-approvals-ad.html / index-approvals-director.html / index-approvals-finance.html.
   Holds the seed data, the escalation-state math, and every apv* view renderer. Each HTML
   file only supplies its own header/sidebar shell markup and calls apvBoot('<role-key>') once
   on load — nothing here decides which role is active, so editing shared logic can't silently
   change one role's markup without also being visible in the others (and vice versa, editing
   one file's markup can't break this shared engine). */
(function () {
  var PERSONAS = {
    alicia:   { name: 'Alicia',        role: 'Promotion Manager',  admin: false },
    rep:      { name: 'Jordan Kim',    role: 'Sales Rep',          admin: false },
    ad:       { name: 'Alex Torres',   role: 'Area Director',      admin: false },
    director: { name: 'Morgan Chen',   role: 'Director, SMB',      admin: false },
    finance:  { name: 'Taylor Wright', role: 'Pricing & Finance',  admin: true }
  };

  var REQUESTS = [
    /* Area Director-routed: track / reminder / backup (an AD-routed item can't show
       "escalated" in the AD's own queue — once it escalates it belongs to Director). */
    { id: 'REQ-001', proposalName: 'Apex Construction Fleet', accountName: 'Apex Construction LLC',
      repName: 'Jordan Kim', route: 'ad', status: 'pending', baseAgeHours: 1,
      dm: 46.2, ebitda: 32.1, npv: 42300, mrr: 8750,
      triggers: [
        { label: 'Competitive price match', value: 'Requested', threshold: 'Standard pricing', flagged: true },
        { label: 'Direct margin', value: '46.2%', threshold: '45.0%', flagged: false }
      ],
      justification: 'Competitive bid from Samsara — need to match pricing to retain.' },
    { id: 'REQ-002', proposalName: 'Summit Logistics GPS', accountName: 'Summit Logistics Inc',
      repName: 'Avery Martin', route: 'ad', status: 'pending', baseAgeHours: 4,
      dm: 39.8, ebitda: 24.5, npv: 118500, mrr: 29750,
      triggers: [
        { label: 'Volume tier override', value: 'Requested', threshold: 'Standard tier', flagged: true },
        { label: 'Direct margin', value: '39.8%', threshold: '45.0%', flagged: true },
        { label: 'EBITDA', value: '24.5%', threshold: '27.0%', flagged: true }
      ],
      justification: 'Strategic account — expansion of 3-year partnership. Volume justifies discount.' },
    { id: 'REQ-003', proposalName: 'FleetPro Expansion', accountName: 'FleetPro Services',
      repName: 'Quinn Harris', route: 'ad', status: 'pending', baseAgeHours: 10,
      dm: 52.1, ebitda: 36.4, npv: 18200, mrr: 4950,
      triggers: [
        { label: 'Tier lock request', value: 'Requested', threshold: 'Re-evaluated annually', flagged: true }
      ],
      justification: 'Add-on to existing MSA. Customer requesting tier lock for remainder of contract.' },
    { id: 'REQ-009', proposalName: 'Riverside Cold Chain Expansion', accountName: 'Riverside Cold Chain LLC',
      repName: 'Casey Liu', route: 'ad', status: 'pending', baseAgeHours: 20,
      dm: 41.5, ebitda: 23.0, npv: 54000, mrr: 15200,
      triggers: [
        { label: 'Direct margin', value: '41.5%', threshold: '45.0%', flagged: true },
        { label: 'EBITDA', value: '23.0%', threshold: '27.0%', flagged: true }
      ],
      justification: 'Temperature-tracking add-on for existing reefer fleet — approver unresponsive past backup window.' },

    /* Director-routed: track / reminder / backup, plus one already escalated to Finance. */
    { id: 'REQ-004', proposalName: 'Metro Delivery Camera', accountName: 'Metro Delivery Corp',
      repName: 'Skyler Adams', route: 'director', status: 'pending', baseAgeHours: 2,
      dm: 38.1, ebitda: 19.2, npv: 85200, mrr: 61275,
      triggers: [
        { label: 'Custom pricing', value: 'Requested', threshold: 'Standard', flagged: true },
        { label: 'Direct margin', value: '38.1%', threshold: '45.0%', flagged: true },
        { label: 'EBITDA', value: '19.2%', threshold: '27.0%', flagged: true }
      ],
      justification: 'Custom pricing to win enterprise RFP. 200+ vehicle fleet with 5-year commitment.' },
    { id: 'REQ-010', proposalName: 'Lakeside Transit Refresh', accountName: 'Lakeside Transit Authority',
      repName: 'Skyler Adams', route: 'director', status: 'pending', baseAgeHours: 10,
      dm: 36.8, ebitda: 17.5, npv: 29800, mrr: 9400,
      triggers: [
        { label: 'Direct margin', value: '36.8%', threshold: '45.0%', flagged: true },
        { label: 'EBITDA', value: '17.5%', threshold: '27.0%', flagged: true }
      ],
      justification: 'Fleet refresh for aging camera units — public-sector procurement timeline is tight.' },
    { id: 'REQ-011', proposalName: 'Union Freight Modernization', accountName: 'Union Freight Corp',
      repName: 'Drew Ellis', route: 'director', status: 'pending', baseAgeHours: 30,
      dm: 33.2, ebitda: 15.1, npv: 71200, mrr: 24600,
      triggers: [
        { label: 'Direct margin', value: '33.2%', threshold: '45.0%', flagged: true },
        { label: 'EBITDA', value: '15.1%', threshold: '27.0%', flagged: true }
      ],
      justification: 'Multi-year modernization deal, custom install schedule across 6 depots.' },
    { id: 'REQ-012', proposalName: 'Continental Parcel Network', accountName: 'Continental Parcel Inc',
      repName: 'Riley Chen', route: 'director', status: 'pending', baseAgeHours: 55,
      dm: 29.7, ebitda: 12.4, npv: -3100, mrr: 41300,
      triggers: [
        { label: 'Soft floor breach', value: 'Below floor', threshold: 'At/above floor', flagged: true },
        { label: 'Negative NPV', value: '-$3,100', threshold: '$0', flagged: true },
        { label: 'Direct margin', value: '29.7%', threshold: '45.0%', flagged: true }
      ],
      justification: 'Large parcel network deal, pricing near floor — needs Finance sign-off, Director unresponsive.' },

    /* Pricing & Finance-routed: track / reminder / backup. */
    { id: 'REQ-005', proposalName: 'City Water Dept', accountName: 'City Water Department',
      repName: 'Lane Bishop', route: 'finance', status: 'pending', baseAgeHours: 4,
      dm: 47.3, ebitda: 30.8, npv: 38900, mrr: 12880,
      triggers: [
        { label: 'Net payment days', value: '60', threshold: '30', flagged: true }
      ],
      justification: 'Government sole-source procurement. Net 60 payment required per agency policy.' },
    { id: 'REQ-013', proposalName: 'State Highway Fleet Program', accountName: 'State Highway Department',
      repName: 'Lane Bishop', route: 'finance', status: 'pending', baseAgeHours: 12,
      dm: 44.0, ebitda: 26.3, npv: 22000, mrr: 8100,
      triggers: [
        { label: 'Direct margin', value: '44.0%', threshold: '45.0%', flagged: true },
        { label: 'EBITDA', value: '26.3%', threshold: '27.0%', flagged: true }
      ],
      justification: 'State framework agreement, standard government terms.' },
    { id: 'REQ-014', proposalName: 'Metro Transit Authority Deal', accountName: 'Metro Transit Authority',
      repName: 'Avery Martin', route: 'finance', status: 'pending', baseAgeHours: 60,
      dm: 31.5, ebitda: 14.2, npv: -1500, mrr: 52700,
      triggers: [
        { label: 'Soft floor breach', value: 'Below floor', threshold: 'At/above floor', flagged: true },
        { label: 'Negative NPV', value: '-$1,500', threshold: '$0', flagged: true },
        { label: 'Direct margin', value: '31.5%', threshold: '45.0%', flagged: true }
      ],
      justification: 'Large transit deal below soft floor pricing — needs Finance approval on floor exception.' },

    { id: 'REQ-006', proposalName: 'Regional Freight Renewal', accountName: 'Regional Freight Co',
      repName: 'Morgan Diaz', route: 'ad', status: 'approved', cycleHours: 1.5, decidedStage: 'track',
      dm: 44.5, ebitda: 27.0, npv: 15200, mrr: 3200,
      triggers: [
        { label: 'Direct margin', value: '44.5%', threshold: '45.0%', flagged: true }
      ],
      justification: 'Standard renewal at existing tier, no exceptions requested.' },
    { id: 'REQ-007', proposalName: 'Coastal Distribution Cameras', accountName: 'Coastal Distribution Inc',
      repName: 'Riley Chen', route: 'director', status: 'approved', cycleHours: 10, decidedStage: 'backup',
      dm: 41.2, ebitda: 22.8, npv: 63500, mrr: 17400,
      triggers: [
        { label: 'Direct margin', value: '41.2%', threshold: '45.0%', flagged: true },
        { label: 'EBITDA', value: '22.8%', threshold: '27.0%', flagged: true }
      ],
      justification: 'Multi-site rollout, needed backup approver before Director could review.' },
    { id: 'REQ-008', proposalName: 'Harbor County Schools', accountName: 'Harbor County School District',
      repName: 'Drew Ellis', route: 'finance', status: 'rejected', cycleHours: 5, decidedStage: 'reminder',
      dm: 28.4, ebitda: 11.6, npv: -8200, mrr: 6100,
      triggers: [
        { label: 'Hard floor breach', value: 'Below floor', threshold: 'At/above floor', flagged: true },
        { label: 'Negative NPV', value: '-$8,200', threshold: '$0', flagged: true },
        { label: 'Direct margin', value: '28.4%', threshold: '45.0%', flagged: true }
      ],
      justification: 'Requested pricing breached hard floor — negative NPV, declined pending re-quote.' },

    /* Additional decided history so every rep on the team has at least one approved
       deal — gives the Team Performance leaderboard (below) real numbers to show. */
    { id: 'REQ-015', proposalName: 'Ridgeline Courier Renewal', accountName: 'Ridgeline Courier LLC',
      repName: 'Jordan Kim', route: 'ad', status: 'approved', cycleHours: 2, decidedStage: 'track',
      dm: 48.0, ebitda: 29.5, npv: 19800, mrr: 6200,
      triggers: [
        { label: 'Direct margin', value: '48.0%', threshold: '45.0%', flagged: false }
      ],
      justification: 'Standard renewal, no exceptions.' },
    { id: 'REQ-016', proposalName: 'Pacific Route Expansion', accountName: 'Pacific Route Logistics',
      repName: 'Avery Martin', route: 'ad', status: 'approved', cycleHours: 3.5, decidedStage: 'track',
      dm: 42.3, ebitda: 25.1, npv: 33200, mrr: 11400,
      triggers: [
        { label: 'Direct margin', value: '42.3%', threshold: '45.0%', flagged: true },
        { label: 'EBITDA', value: '25.1%', threshold: '27.0%', flagged: true }
      ],
      justification: 'New routes added to existing MSA.' },
    { id: 'REQ-017', proposalName: 'Downtown Shuttle Add-On', accountName: 'Downtown Shuttle Co',
      repName: 'Quinn Harris', route: 'ad', status: 'approved', cycleHours: 1, decidedStage: 'track',
      dm: 50.2, ebitda: 33.0, npv: 14100, mrr: 5100,
      triggers: [
        { label: 'Direct margin', value: '50.2%', threshold: '45.0%', flagged: false }
      ],
      justification: 'Small fleet add-on, within standard tier.' },
    { id: 'REQ-018', proposalName: 'Cold Chain Monitoring Renewal', accountName: 'Cold Chain Monitoring Inc',
      repName: 'Casey Liu', route: 'ad', status: 'approved', cycleHours: 9, decidedStage: 'backup',
      dm: 39.5, ebitda: 21.8, npv: 26700, mrr: 8300,
      triggers: [
        { label: 'Direct margin', value: '39.5%', threshold: '45.0%', flagged: true },
        { label: 'EBITDA', value: '21.8%', threshold: '27.0%', flagged: true }
      ],
      justification: 'Renewal with minor tier adjustment, approver needed backup coverage.' },
    { id: 'REQ-019', proposalName: 'Camera Fleet Upgrade Phase 2', accountName: 'Camera Fleet Partners',
      repName: 'Skyler Adams', route: 'director', status: 'approved', cycleHours: 6, decidedStage: 'reminder',
      dm: 35.0, ebitda: 18.4, npv: 58400, mrr: 28500,
      triggers: [
        { label: 'Direct margin', value: '35.0%', threshold: '45.0%', flagged: true },
        { label: 'EBITDA', value: '18.4%', threshold: '27.0%', flagged: true }
      ],
      justification: 'Phase 2 of an existing rollout, same terms as phase 1.' },
    { id: 'REQ-020', proposalName: 'County Fleet Renewal', accountName: 'County Fleet Services',
      repName: 'Lane Bishop', route: 'finance', status: 'approved', cycleHours: 4, decidedStage: 'track',
      dm: 46.8, ebitda: 28.0, npv: 21500, mrr: 15200,
      triggers: [
        { label: 'Direct margin', value: '46.8%', threshold: '45.0%', flagged: false }
      ],
      justification: 'Government renewal, standard terms.' },

    /* Jamie Brooks' team (SMB segment, second AD team under Director Morgan Chen) —
       decided history only, routed at 'director' rather than 'ad', since this app has
       only one AD login (Alex Torres) and these deals shouldn't appear in his queue.
       Gives the Director's per-team Rep leaderboard selector a second team with real
       numbers instead of an empty state. */
    { id: 'REQ-021', proposalName: 'Meridian Transport Renewal', accountName: 'Meridian Transport Group',
      repName: 'Sage Whitman', route: 'director', status: 'approved', cycleHours: 5, decidedStage: 'track',
      dm: 44.0, ebitda: 27.5, npv: 24700, mrr: 9800,
      triggers: [
        { label: 'Direct margin', value: '44.0%', threshold: '45.0%', flagged: true }
      ],
      justification: 'Standard renewal, no exceptions requested.' },
    { id: 'REQ-022', proposalName: 'Brightline Sanitation Expansion', accountName: 'Brightline Sanitation',
      repName: 'Reese Coleman', route: 'director', status: 'approved', cycleHours: 12, decidedStage: 'backup',
      dm: 38.5, ebitda: 20.0, npv: 31500, mrr: 16200,
      triggers: [
        { label: 'Direct margin', value: '38.5%', threshold: '45.0%', flagged: true },
        { label: 'EBITDA', value: '20.0%', threshold: '27.0%', flagged: true }
      ],
      justification: 'Route expansion added to existing contract, approver needed backup coverage.' },
    { id: 'REQ-023', proposalName: 'Northgate Utilities Add-On', accountName: 'Northgate Utilities',
      repName: 'Micah Foster', route: 'director', status: 'approved', cycleHours: 3, decidedStage: 'track',
      dm: 41.0, ebitda: 24.0, npv: 12300, mrr: 6300,
      triggers: [
        { label: 'Direct margin', value: '41.0%', threshold: '45.0%', flagged: true },
        { label: 'EBITDA', value: '24.0%', threshold: '27.0%', flagged: true }
      ],
      justification: 'Small fleet add-on, within standard tier.' },
    { id: 'REQ-024', proposalName: 'Vantage Point Security Renewal', accountName: 'Vantage Point Security',
      repName: 'Emerson Vance', route: 'director', status: 'approved', cycleHours: 7, decidedStage: 'reminder',
      dm: 46.5, ebitda: 31.0, npv: 22000, mrr: 11750,
      triggers: [
        { label: 'Direct margin', value: '46.5%', threshold: '45.0%', flagged: false }
      ],
      justification: 'Renewal at existing tier with minor scope increase.' },
    { id: 'REQ-025', proposalName: 'Meridian Transport Add-On', accountName: 'Meridian Transport Group',
      repName: 'Sage Whitman', route: 'director', status: 'approved', cycleHours: 4, decidedStage: 'track',
      dm: 39.0, ebitda: 22.5, npv: 5200, mrr: 4100,
      triggers: [
        { label: 'Direct margin', value: '39.0%', threshold: '45.0%', flagged: true },
        { label: 'EBITDA', value: '22.5%', threshold: '27.0%', flagged: true }
      ],
      justification: 'Second vehicle group added to the same account.' },
    { id: 'REQ-026', proposalName: 'Brightline Sanitation Phase 2', accountName: 'Brightline Sanitation',
      repName: 'Reese Coleman', route: 'director', status: 'rejected', cycleHours: 15, decidedStage: 'reminder',
      dm: 26.0, ebitda: 9.0, npv: -3400, mrr: 3200,
      triggers: [
        { label: 'Soft floor breach', value: 'Below floor', threshold: 'At/above floor', flagged: true },
        { label: 'Negative NPV', value: '-$3,400', threshold: '$0', flagged: true },
        { label: 'Direct margin', value: '26.0%', threshold: '45.0%', flagged: true }
      ],
      justification: 'Requested pricing breached floor — negative margin trend, declined pending re-quote.' }
  ];

  function apvRequestNumber(r, idx) {
    var raw = String((r && r.id) || '');
    var digits = raw.replace(/\D/g, '');
    return parseInt(digits, 10) || (idx + 1);
  }

  function apvRequestRef(prefix, n) {
    return prefix + '-' + String(n).padStart(5, '0');
  }

  function apvPrimeRequestDetails() {
    REQUESTS.forEach(function (r, idx) {
      var n = apvRequestNumber(r, idx);
      if (!r.opportunityRef) r.opportunityRef = apvRequestRef('OPP', n);
      if (!r.opportunityName) r.opportunityName = apvBuildOpportunityName(r.accountName);
      if (!r.quoteRef) r.quoteRef = 'Q-' + String(1565000 + n);
      if (!Array.isArray(r.attachments)) r.attachments = [];
      if (!Array.isArray(r.rfiEvents)) r.rfiEvents = [];
      if (!Array.isArray(r.actionEvents)) r.actionEvents = [];
      if (!r.attachments.length && (idx === 1 || idx === 4 || idx === 9)) {
        r.attachments.push({
          name: 'Pricing exception ' + r.id + '.pdf',
          uploadedBy: r.repName,
          when: 'At submission'
        });
      }
    });
  }

  apvPrimeRequestDetails();

  var NOTIFICATIONS = [
    { chan: 'slack', title: 'New request from Avery Martin', body: 'Summit Logistics GPS needs your approval', time: '6h ago' },
    { chan: 'slack', title: 'Reminder', body: 'Summit Logistics is still pending — 4h with no action', time: '4h ago' },
    { chan: 'slack', title: 'Escalated to your backup', body: 'Sam Rodriguez was notified about Summit Logistics', time: '30m ago' },
    { chan: 'inapp', title: 'Request approved', body: 'Rapid Courier Duo', time: 'Yesterday' }
  ];

  var STEP_META = [
    { key: 'rep', label: 'Rep' },
    { key: 'ad', label: 'Area Director' },
    { key: 'director', label: 'Director' },
    { key: 'finance', label: 'Finance' }
  ];

  var LEVEL_ORDER = ['ad', 'director', 'finance'];
  var LEVEL_LABEL = { ad: 'Area Director', director: 'Director', finance: 'Pricing & Finance' };

  var apvOrgConfig = {
    ad:       { holderName: 'Alex Torres',   backupName: 'Sam Rodriguez',            reminderHours: 2, backupHours: 8 },
    director: { holderName: 'Morgan Chen',   backupName: 'Pat Sullivan',              reminderHours: 4, backupHours: 24 },
    finance:  { holderName: 'Taylor Wright', backupName: '— no backup assigned —',     reminderHours: 8, backupHours: 48 }
  };

  /* Team Performance — the SMB segment has two AD teams under Director Morgan Chen.
     This app only has one AD login (Alex Torres, TEAMS[0]), so the 'ad' persona always
     scopes to their own team; 'director'/'finance' aggregate across every team in
     TEAMS via allSegmentReps (built in apvShowHome). apvTeamMetrics/apvRepLeaderboardRows
     take an explicit rep-name list rather than reaching for a single global roster, so
     the same functions serve a one-team view (AD), an all-teams view (Director/Finance
     default), or a single selected team drilled into from the Rep leaderboard's
     team selector (Director only — see apvSelectTeam). */
  var TEAMS = [
    { adName: 'Alex Torres', reps: ['Jordan Kim', 'Avery Martin', 'Quinn Harris', 'Casey Liu', 'Skyler Adams', 'Drew Ellis', 'Riley Chen', 'Lane Bishop', 'Morgan Diaz'], goals: { mrrTarget: 90000, dmTarget: 0.45, ebitdaTarget: 0.27 } },
    { adName: 'Jamie Brooks', reps: ['Sage Whitman', 'Reese Coleman', 'Micah Foster', 'Emerson Vance'], goals: { mrrTarget: 55000, dmTarget: 0.42, ebitdaTarget: 0.25 } }
  ];

  var SEGMENT_CONFIG = {
    segment: 'SMB',
    directorName: 'Morgan Chen',
    goals: { mrrTarget: 145000, dmTarget: 0.44, ebitdaTarget: 0.26 }
  };

  function apvTeamForRep(repName) {
    for (var i = 0; i < TEAMS.length; i++) {
      if (TEAMS[i].reps.indexOf(repName) > -1) return TEAMS[i];
    }
    return null;
  }

  function apvTeamMetrics(repNames) {
    var approved = REQUESTS.filter(function (r) { return r.status === 'approved' && repNames.indexOf(r.repName) > -1; });
    var mrr = 0, dmSum = 0, ebitdaSum = 0;
    approved.forEach(function (r) { mrr += r.mrr; dmSum += r.dm; ebitdaSum += r.ebitda; });
    var n = approved.length;
    return { mrr: mrr, avgDM: n ? dmSum / n : 0, avgEBITDA: n ? ebitdaSum / n : 0, dealCount: n };
  }

  function apvRepLeaderboardRows(repNames) {
    return repNames.map(function (rep) {
      var repReqs = REQUESTS.filter(function (r) { return r.repName === rep; });
      var repApproved = repReqs.filter(function (r) { return r.status === 'approved'; });
      var mrr = 0, dmSum = 0;
      repApproved.forEach(function (r) { mrr += r.mrr; dmSum += r.dm; });
      return { rep: rep, submitted: repReqs.length, approved: repApproved.length, mrr: mrr, avgDM: repApproved.length ? dmSum / repApproved.length : null };
    });
  }

  /* Sales Rep — individual-level goals, one rung below a team's goals in TEAMS. */
  var REP_CONFIG = {
    name: 'Jordan Kim',
    goals: { mrrTarget: 12000, dmTarget: 0.45, ebitdaTarget: 0.27 }
  };

  function apvRepMetrics(repName) {
    var repReqs = REQUESTS.filter(function (r) { return r.repName === repName; });
    var repApproved = repReqs.filter(function (r) { return r.status === 'approved'; });
    var repPending = repReqs.filter(function (r) { return r.status === 'pending'; });
    var repRejected = repReqs.filter(function (r) { return r.status === 'rejected'; });
    var mrr = 0, dmSum = 0, ebitdaSum = 0, npv = 0;
    repApproved.forEach(function (r) { mrr += r.mrr; dmSum += r.dm; ebitdaSum += r.ebitda; npv += r.npv; });
    var n = repApproved.length;
    return {
      mrr: mrr, avgDM: n ? dmSum / n : 0, avgEBITDA: n ? ebitdaSum / n : 0, npv: npv,
      submitted: repReqs.length, pending: repPending.length, approved: repApproved.length, rejected: repRejected.length,
      requests: repReqs
    };
  }

  var apvState = { persona: null, currentView: 'home', clockHours: 0, openRequestId: null, selectedTeam: 'all', sidebarOpen: false };
  var apvDecisionModalState = { action: null, requestId: null, isOpen: false };

  function apvEsc(s) { var d = document.createElement('div'); d.textContent = s == null ? '' : String(s); return d.innerHTML; }

  /* ── Data visualization helpers — built only from the DS's dataviz tokens/classes
     (design-system.css, documented in assets/ds/index.html #dataviz). No new colors. ── */

  /* Ranking-style bar chart — every row is the same metric (MRR, volume, cycle time)
     for a different rep/team/role, not distinct categories, so per the DS's own rule
     ("analogous palette... when comparing values of the same metric") these are
     monochromatic — single accent color (Blue 600), varying only by bar length. */
  function apvCategoricalBarChart(items) {
    if (!items.length) return '<div class="dataviz-empty">No data available</div>';
    var max = Math.max.apply(null, items.map(function (i) { return i.value; }).concat([1]));
    var html = '';
    items.forEach(function (item) {
      var pct = Math.max(2, (item.value / max) * 100);
      html += '<div class="dataviz-bar-row" style="margin-bottom:10px;">' +
        '<span class="text-body-small" style="width:110px;flex-shrink:0;" title="' + apvEsc(item.label) + '">' + apvEsc(item.label) + '</span>' +
        '<div class="dataviz-bar-track"><div class="dataviz-bar-fill" style="width:' + pct + '%;background:var(--color-dataviz-single-accent);"></div></div>' +
        '<span class="dataviz-data-value">' + apvEsc(item.formatted) + '</span></div>';
    });
    return html;
  }

  function apvNextLevel(level) {
    var i = LEVEL_ORDER.indexOf(level);
    return (i > -1 && i < LEVEL_ORDER.length - 1) ? LEVEL_ORDER[i + 1] : null;
  }

  function apvFormatHours(h) {
    h = Math.max(0, h);
    if (h < 1) return Math.round(h * 60) + 'm';
    if (h < 24) return (Math.round(h * 10) / 10) + 'h';
    var d = Math.floor(h / 24), rem = Math.round(h - d * 24);
    return d + 'd' + (rem ? ' ' + rem + 'h' : '');
  }

  /* Builds the audit timeline from scratch given how far the request has progressed —
     safe to call after every clock change since nothing is mutated incrementally. */
  function apvBuildTimeline(r, stage, level, ageHours, isDecided) {
    var cfg = apvOrgConfig[level] || { reminderHours: 2, backupHours: 8, holderName: '', backupName: '' };
    var events = [{ type: 'submit', title: 'Submitted by ' + r.repName, meta: apvFormatHours(ageHours) + ' ago' }];
    var passedReminder = stage === 'reminder' || stage === 'backup' || stage === 'escalated';
    var passedBackup = stage === 'backup' || stage === 'escalated';
    var passedEscalate = stage === 'escalated';
    if (passedReminder) {
      events.push({ type: 'reminder', title: 'Reminder sent to ' + cfg.holderName + ' (' + LEVEL_LABEL[level] + ')', meta: 'Slack · ' + apvFormatHours(ageHours - cfg.reminderHours) + ' ago' });
    }
    if (passedBackup) {
      events.push({ type: 'backup', title: 'Backup notified — ' + cfg.backupName, meta: 'Slack · ' + apvFormatHours(ageHours - cfg.backupHours) + ' ago' });
    }
    if (passedEscalate) {
      var next = apvNextLevel(level);
      var nextCfg = next ? apvOrgConfig[next] : null;
      events.push({ type: 'reminder', title: next ? ('Escalated to ' + nextCfg.holderName + ' (' + LEVEL_LABEL[next] + ')') : 'Escalated — no level above, needs attention', meta: 'Slack · ' + apvFormatHours(ageHours - cfg.backupHours * 2) + ' ago' });
    }
    (r.rfiEvents || []).forEach(function (ev) {
      events.push({ type: 'rfi', title: ev.title, meta: ev.meta });
    });
    if (isDecided) {
      var who = r.decisionBy ? (' by ' + r.decisionBy) : '';
      var note = r.decisionNote ? (' · ' + r.decisionNote) : '';
      events.push({ type: 'decision', title: (r.status === 'approved' ? 'Approved' : 'Rejected') + who, meta: 'Total cycle time: ' + apvFormatHours(r.cycleHours) + note });
    }
    return events;
  }

  /* Pure — derives everything escalation-related from baseAgeHours + the simulated clock,
     so it can be recomputed on every render with no stored/mutated state. */
  function apvComputeRequestState(r, clockHours) {
    if (r.status !== 'pending') {
      var decStage = r.decidedStage || 'track';
      return {
        ageHours: r.cycleHours, ageLabel: apvFormatHours(r.cycleHours), ageClass: 'normal',
        stage: decStage, currentLevel: r.route,
        escalationLabel: r.status === 'approved' ? 'Approved' : 'Rejected',
        timeline: apvBuildTimeline(r, decStage, r.route, r.cycleHours, true)
      };
    }
    var level = r.route;
    var cfg = apvOrgConfig[level] || { reminderHours: 2, backupHours: 8 };
    var ageHours = r.baseAgeHours + clockHours;
    var stage = 'track';
    var currentLevel = level;
    if (ageHours >= cfg.backupHours * 2) {
      stage = 'escalated';
      currentLevel = apvNextLevel(level) || level;
    } else if (ageHours >= cfg.backupHours) {
      stage = 'backup';
    } else if (ageHours >= cfg.reminderHours) {
      stage = 'reminder';
    }
    var ageClass = stage === 'track' ? 'normal' : (stage === 'reminder' ? 'warning' : 'critical');
    var next = apvNextLevel(level);
    var escalationLabel = {
      track: 'On track', reminder: 'Reminder sent', backup: 'Backup notified',
      escalated: next ? ('Escalated → ' + LEVEL_LABEL[next]) : 'Escalated — critical'
    }[stage];
    return {
      ageHours: ageHours, ageLabel: apvFormatHours(ageHours), ageClass: ageClass,
      stage: stage, currentLevel: currentLevel, escalationLabel: escalationLabel,
      timeline: apvBuildTimeline(r, stage, level, ageHours, false)
    };
  }

  function apvBadgeClass(stage) {
    /* DS badge component (design-system.css) instead of a custom apv- badge — mapped
       per the same state→color convention already used for requirements.html's States
       table: gray-low default, yellow in-review/warning, orange more urgent, red critical. */
    return { track: 'badge--gray-low', reminder: 'badge--yellow', backup: 'badge--orange', escalated: 'badge--red' }[stage] || 'badge--gray-low';
  }

  function apvShowToast(msg) {
    var t = document.getElementById('apv-toast');
    if (!t) return;
    t.textContent = msg;
    t.classList.add('apv-show');
    clearTimeout(apvShowToast._timer);
    apvShowToast._timer = setTimeout(function () { t.classList.remove('apv-show'); }, 2200);
  }

  function apvSyncNotifBadge() {
    var badge = document.getElementById('apv-bell-badge');
    if (!badge) return;
    var count = NOTIFICATIONS.length;
    badge.textContent = count > 99 ? '99+' : String(count);
    badge.style.display = count ? 'flex' : 'none';
  }

  function apvRequestById(id) {
    return REQUESTS.filter(function (x) { return x.id === id; })[0] || null;
  }

  function apvDisplayQuoteRef(rawRef) {
    var raw = String(rawRef || '').trim();
    if (!raw) return '';
    if (/^Q-\d{7}$/i.test(raw)) return raw.toUpperCase();
    var digits = raw.replace(/\D/g, '');
    if (!digits) return raw;
    return 'Q-' + String(parseInt(digits, 10)).padStart(7, '0');
  }

  function apvDisplayProposalId(rawId) {
    var raw = String(rawId || '').trim();
    var digits = raw.replace(/\D/g, '');
    var n = parseInt(digits, 10);
    if (!n) return '0524';
    return String(523 + n).padStart(4, '0');
  }

  function apvBuildOpportunityName(accountName) {
    var base = String(accountName || '').trim();
    if (!base) return 'Opportunity renewal';
    base = base
      .replace(/\b(inc|llc|corp|co|ltd|group|services|authority|department|district)\b\.?/ig, '')
      .replace(/\s{2,}/g, ' ')
      .trim();
    if (!base) return 'Opportunity renewal';
    return base + ' renewal';
  }

  function apvDisplayOpportunityName(rawName, accountName) {
    var name = String(rawName || '').trim();
    if (name) return name;
    return apvBuildOpportunityName(accountName);
  }

  function apvActorName() {
    return PERSONAS[apvState.persona] ? PERSONAS[apvState.persona].name : 'Approver';
  }

  function apvPushNotification(chan, title, body) {
    NOTIFICATIONS.unshift({ chan: chan, title: title, body: body, time: 'Just now' });
    if (NOTIFICATIONS.length > 30) NOTIFICATIONS.length = 30;
    apvRenderNotifList();
    apvSyncNotifBadge();
  }

  function apvTriggerRowHtml(t) {
    var color = t.flagged ? '#e10014' : '#008331';
    var icon = t.flagged ? 'report' : 'check_circle';
    return '<div class="apv-trigger-row"><span class="material-symbols-outlined" style="font-size:18px;color:' + color + ';">' + icon + '</span>' +
      '<div><div class="apv-trigger-label">' + apvEsc(t.label) + '</div>' +
      '<div class="apv-trigger-values">' + apvEsc(t.value) + ' <span style="color:#9a9a9a;">vs. threshold</span> ' + apvEsc(t.threshold) + '</div></div></div>';
  }

  function apvMetricCauseTrigger(triggers, key) {
    var labelByKey = {
      dm: 'Direct margin',
      ebitda: 'EBITDA',
      npv: 'Negative NPV'
    };
    var label = labelByKey[key];
    if (!label) return null;
    for (var i = 0; i < triggers.length; i += 1) {
      if (triggers[i].label === label) return triggers[i];
    }
    return null;
  }

  function apvBuildConsolidatedMetricsHtml(r) {
    var triggers = r.triggers || [];
    var metricTriggerKeys = { 'Direct margin': true, 'EBITDA': true, 'Negative NPV': true };
    var nonMetricTriggers = triggers.filter(function (t) { return !metricTriggerKeys[t.label]; });

    var isPending = r.status === 'pending';
    var team = apvTeamForRep(r.repName) || TEAMS[0];
    var goals = team.goals || SEGMENT_CONFIG.goals;
    var current = apvTeamMetrics(team.reps);
    var nextDeals = current.dealCount + 1;
    var nextDM = nextDeals ? ((current.avgDM * current.dealCount) + r.dm) / nextDeals : r.dm;
    var nextEBITDA = nextDeals ? ((current.avgEBITDA * current.dealCount) + r.ebitda) / nextDeals : r.ebitda;
    var nextMRR = current.mrr + r.mrr;
    var dmGoalPct = goals.dmTarget * 100;
    var ebitdaGoalPct = goals.ebitdaTarget * 100;

    var tiles = [
      {
        key: 'dm',
        label: 'Direct margin',
        valueHtml: r.dm.toFixed(1) + '%',
        valueColor: r.dm < 45 ? '#e10014' : '#008331',
        impactHtml: 'Team avg: ' + current.avgDM.toFixed(1) + '% → ' + nextDM.toFixed(1) + '% · Goal: ' + dmGoalPct.toFixed(0) + '%',
        impactWarn: nextDM < dmGoalPct
      },
      {
        key: 'ebitda',
        label: 'EBITDA',
        valueHtml: r.ebitda.toFixed(1) + '%',
        valueColor: r.ebitda < 25 ? '#e10014' : '#008331',
        impactHtml: 'Team avg: ' + current.avgEBITDA.toFixed(1) + '% → ' + nextEBITDA.toFixed(1) + '% · Goal: ' + ebitdaGoalPct.toFixed(0) + '%',
        impactWarn: nextEBITDA < ebitdaGoalPct
      },
      {
        key: 'npv',
        label: 'NPV',
        valueHtml: '$' + r.npv.toLocaleString(),
        valueColor: r.npv < 0 ? '#e10014' : '#000',
        impactHtml: '',
        impactWarn: false
      },
      {
        key: 'mrr',
        label: 'Monthly revenue',
        valueHtml: '$' + r.mrr.toLocaleString(),
        valueColor: '#000',
        impactHtml: 'Team total: $' + current.mrr.toLocaleString() + ' → $' + nextMRR.toLocaleString() + ' · Goal: $' + goals.mrrTarget.toLocaleString(),
        impactWarn: nextMRR < goals.mrrTarget
      }
    ];

    var tilesHtml = tiles.map(function (tile) {
      var causeTrigger = apvMetricCauseTrigger(triggers, tile.key);
      var causeHtml = '';
      if (causeTrigger) {
        var causeColor = causeTrigger.flagged ? '#e10014' : '#008331';
        var causeIcon = causeTrigger.flagged ? 'report' : 'check_circle';
        causeHtml = '<div class="apv-metric-cause"><span class="material-symbols-outlined" style="font-size:15px;color:' + causeColor + ';">' + causeIcon + '</span>' +
          '<span class="apv-metric-cause-text">vs. threshold ' + apvEsc(causeTrigger.threshold) + '</span></div>';
      }
      var impactHtml = '';
      if (isPending && tile.impactHtml) {
        impactHtml = '<div class="apv-metric-impact' + (tile.impactWarn ? ' apv-warn' : '') + '">' + apvEsc(tile.impactHtml) + '</div>';
      }
      return '<div class="apv-metric' + (tile.impactWarn && isPending ? ' apv-metric--warn' : '') + '">' +
        '<div class="apv-metric-label">' + apvEsc(tile.label) + '</div>' +
        '<div class="apv-metric-value" style="color:' + tile.valueColor + ';">' + tile.valueHtml + '</div>' +
        causeHtml + impactHtml +
        '</div>';
    }).join('');

    var extraTriggersHtml = nonMetricTriggers.length
      ? '<div class="apv-metric-extra"><div class="apv-metric-extra-title">Other approval triggers</div>' + nonMetricTriggers.map(apvTriggerRowHtml).join('') + '</div>'
      : '';

    return '<div class="apv-metric-grid">' + tilesHtml + '</div>' + extraTriggersHtml;
  }

  function apvRefLink(label, type, ref, requestId) {
    var jsRef = String(ref == null ? '' : ref).replace(/\\/g, '\\\\').replace(/'/g, "\\'");
    var jsReq = String(requestId == null ? '' : requestId).replace(/\\/g, '\\\\').replace(/'/g, "\\'");
    return '<a href="#" class="apv-ref-link" onclick="apvOpenRequestRef(\'' + apvEsc(type) + '\', \'' + jsRef + '\', \'' + jsReq + '\');return false;">' + apvEsc(label) + ': ' + apvEsc(ref) + '</a>';
  }

  function apvApplyTemplate(tpl, ref) {
    return String(tpl || '').replace(/\{ref\}/g, encodeURIComponent(ref));
  }

  function apvResolveSalesforceRefUrl(type, ref, requestId) {
    var r = apvRequestById(requestId);
    if (r) {
      if (type === 'Opportunity' && r.opportunityUrl) return r.opportunityUrl;
      if (type === 'Quote' && r.quoteUrl) return r.quoteUrl;
    }
    var cfg = window.APV_SF_LINKS || {};
    if (type === 'Opportunity' && cfg.opportunityTemplate) {
      return apvApplyTemplate(cfg.opportunityTemplate, ref);
    }
    if (type === 'Quote' && cfg.quoteTemplate) {
      return apvApplyTemplate(cfg.quoteTemplate, ref);
    }
    if (type === 'Opportunity') {
      return '/lightning/r/Opportunity/' + encodeURIComponent(ref) + '/view';
    }
    return '/lightning/r/Quote/' + encodeURIComponent(ref) + '/view';
  }

  window.apvOpenRequestRef = function (type, ref, requestId) {
    var url = apvResolveSalesforceRefUrl(type, ref, requestId);
    var win = window.open(url, '_blank', 'noopener');
    if (!win) {
      apvShowToast('Popup blocked. Allow popups to open ' + type + ' links.');
      return;
    }
    apvShowToast(type + ' ' + ref + ' opened');
  };

  function apvEnsureDecisionModal() {
    var overlay = document.getElementById('apv-decision-modal-overlay');
    if (overlay) return overlay;

    overlay = document.createElement('div');
    overlay.id = 'apv-decision-modal-overlay';
    overlay.className = 'apv-modal-overlay';
    overlay.setAttribute('aria-hidden', 'true');
    overlay.innerHTML =
      '<div class="apv-modal" role="dialog" aria-modal="true" aria-labelledby="apv-decision-modal-title">' +
      '<div class="apv-modal-head"><h3 id="apv-decision-modal-title" class="apv-modal-title">Decision</h3>' +
      '<button type="button" class="apv-modal-close" aria-label="Close" onclick="apvCloseDecisionModal()"><span class="material-symbols-outlined" style="font-size:18px;">close</span></button></div>' +
      '<div class="apv-modal-body">' +
      '<p id="apv-decision-modal-context" class="apv-modal-context"></p>' +
      '<label id="apv-decision-modal-label" class="apv-modal-label" for="apv-decision-modal-note"></label>' +
      '<textarea id="apv-decision-modal-note" class="apv-modal-textarea" rows="4" maxlength="500"></textarea>' +
      '<p id="apv-decision-modal-hint" class="apv-modal-hint"></p>' +
      '</div>' +
      '<div class="apv-modal-actions">' +
      '<button type="button" class="btn btn--secondary btn--small" onclick="apvCloseDecisionModal()">Cancel</button>' +
      '<button type="button" id="apv-decision-modal-confirm" class="btn btn--primary btn--small" onclick="apvConfirmDecisionModal()">Confirm</button>' +
      '</div>' +
      '</div>';
    document.body.appendChild(overlay);

    overlay.addEventListener('click', function (evt) {
      if (evt.target === overlay) window.apvCloseDecisionModal();
    });

    document.addEventListener('keydown', function (evt) {
      if (evt.key === 'Escape' && apvDecisionModalState.isOpen) {
        window.apvCloseDecisionModal();
      }
    });

    return overlay;
  }

  window.apvOpenDecisionModal = function (action) {
    var r = apvRequestById(apvState.openRequestId);
    if (!r || r.status !== 'pending' || apvState.persona === 'rep') return;

    var overlay = apvEnsureDecisionModal();
    var title = document.getElementById('apv-decision-modal-title');
    var context = document.getElementById('apv-decision-modal-context');
    var label = document.getElementById('apv-decision-modal-label');
    var note = document.getElementById('apv-decision-modal-note');
    var hint = document.getElementById('apv-decision-modal-hint');
    var confirm = document.getElementById('apv-decision-modal-confirm');

    var mode = action === 'approve' ? 'approve' : (action === 'reject' ? 'reject' : 'rfi');
    var cfg = {
      approve: {
        title: 'Approve request',
        label: 'Approval note (optional)',
        hint: 'This request will move to Approved and leave the active queue.',
        cta: 'Approve'
      },
      reject: {
        title: 'Reject request',
        label: 'Rejection reason (required)',
        hint: 'Provide a clear reason so the rep can adjust and resubmit.',
        cta: 'Reject'
      },
      rfi: {
        title: 'Request info',
        label: 'What information is missing? (required)',
        hint: 'The request remains pending and the rep is notified.',
        cta: 'Send request'
      }
    }[mode];

    title.textContent = cfg.title;
    context.textContent = r.id + ' · ' + r.proposalName;
    label.textContent = cfg.label;
    hint.textContent = cfg.hint;
    confirm.textContent = cfg.cta;
    note.value = '';

    apvDecisionModalState.action = mode;
    apvDecisionModalState.requestId = r.id;
    apvDecisionModalState.isOpen = true;

    overlay.classList.add('is-open');
    overlay.setAttribute('aria-hidden', 'false');
    setTimeout(function () { if (note && note.focus) note.focus(); }, 0);
  };

  window.apvCloseDecisionModal = function () {
    var overlay = document.getElementById('apv-decision-modal-overlay');
    if (!overlay) return;
    overlay.classList.remove('is-open');
    overlay.setAttribute('aria-hidden', 'true');
    apvDecisionModalState.isOpen = false;
    apvDecisionModalState.action = null;
    apvDecisionModalState.requestId = null;
  };

  window.apvConfirmDecisionModal = function () {
    if (!apvDecisionModalState.isOpen || !apvDecisionModalState.action || !apvDecisionModalState.requestId) return;
    var noteEl = document.getElementById('apv-decision-modal-note');
    var note = noteEl ? noteEl.value : '';
    var done = window.apvHandleRequestAction(apvDecisionModalState.action, note, apvDecisionModalState.requestId);
    if (done) window.apvCloseDecisionModal();
  };

  function apvAttachmentListHtml(r) {
    var listHtml = (r.attachments || []).map(function (a, idx) {
      return '<div class="apv-attach-item"><div><div class="apv-attach-name">' + apvEsc(a.name) + '</div><div class="apv-attach-meta">' + apvEsc(a.uploadedBy || 'User') + ' · ' + apvEsc(a.when || 'Just now') + '</div></div>' +
        '<div style="display:flex;gap:6px;align-items:center;">' +
        '<button class="apv-attach-link" type="button" onclick="apvPreviewAttachment(' + idx + ')">Preview</button>' +
        '</div></div>';
    }).join('');
    if (!listHtml) {
      listHtml = '<div class="apv-attach-item"><div><div class="apv-attach-name">Approval Summary - ' + apvEsc(r.id) + '.pdf</div><div class="apv-attach-meta">System template · Read only</div></div>' +
        '<div style="display:flex;gap:6px;align-items:center;">' +
        '<button class="apv-attach-link" type="button" onclick="apvPreviewPlaceholderAttachment(\'Approval Summary - ' + apvEsc(r.id) + '.pdf\')">Preview</button>' +
        '</div></div>';
    }
    return listHtml;
  }

  window.apvPreviewAttachment = function (idx) {
    var r = apvRequestById(apvState.openRequestId);
    if (!r || !r.attachments || !r.attachments[idx]) return;
    apvShowToast('Opening ' + r.attachments[idx].name + ' (prototype)');
  };

  window.apvPreviewPlaceholderAttachment = function (name) {
    apvShowToast('Opening ' + name + ' (prototype)');
  };

  window.apvPickAttachment = function () {
    var input = document.getElementById('apv-attachment-input');
    if (input) input.click();
  };

  window.apvAddAttachmentFromInput = function (inputEl) {
    var r = apvRequestById(apvState.openRequestId);
    if (!r || !inputEl || !inputEl.files || !inputEl.files.length) return;
    for (var i = 0; i < inputEl.files.length; i++) {
      var f = inputEl.files[i];
      r.attachments.push({ name: f.name, uploadedBy: apvActorName(), when: 'Just now' });
      apvPushNotification('inapp', 'Attachment added', f.name + ' added to ' + r.id);
    }
    inputEl.value = '';
    apvShowToast('Attachment added');
    window.apvOpenRequest(r.id);
  };

  window.apvRemoveAttachment = function (idx) {
    var r = apvRequestById(apvState.openRequestId);
    if (!r || !r.attachments || !r.attachments[idx]) return;
    var target = r.attachments[idx];
    if (!window.confirm('Remove attachment "' + target.name + '"?')) return;
    r.attachments.splice(idx, 1);
    apvShowToast('Attachment removed');
    window.apvOpenRequest(r.id);
  };

  window.apvHandleRequestAction = function (action, noteText, requestId) {
    var targetId = requestId || apvState.openRequestId;
    var r = apvRequestById(targetId);
    if (!r || r.status !== 'pending' || apvState.persona === 'rep') return;
    var st = apvComputeRequestState(r, apvState.clockHours);
    var actor = apvActorName();

    if (action === 'rfi') {
      var question = String(noteText || '').trim();
      if (!question) {
        apvShowToast('A note is required to request info');
        return false;
      }
      r.rfiEvents.push({ title: 'Info requested by ' + actor, meta: 'To ' + r.repName + ' · ' + question });
      apvPushNotification('inapp', 'Info requested', actor + ' requested more info on ' + r.id);
      apvShowToast('Info request sent to ' + r.repName);
      window.apvOpenRequest(r.id);
      return true;
    }

    if (action !== 'approve' && action !== 'reject') return false;

    var isApprove = action === 'approve';
    var note = String(noteText || '').trim();
    if (!isApprove && !note) {
      apvShowToast('Rejection reason is required');
      return false;
    }

    r.status = isApprove ? 'approved' : 'rejected';
    r.cycleHours = Math.max(0.1, st.ageHours);
    r.decidedStage = st.stage;
    r.decisionBy = actor;
    r.decisionNote = note;
    r.actionEvents.push({ type: r.status, by: actor, note: note });

    apvPushNotification('inapp', isApprove ? 'Request approved' : 'Request rejected', r.id + ' · ' + r.proposalName);
    apvShowToast(isApprove ? 'Request approved' : 'Request rejected');
    window.apvOpenRequest(r.id);
    return true;
  };

  function apvQueueForPersona(key) {
    return REQUESTS.filter(function (r) {
      return r.status === 'pending' && apvComputeRequestState(r, apvState.clockHours).currentLevel === key;
    });
  }

  function apvAllForPersona(key) {
    return REQUESTS.filter(function (r) {
      if (r.status === 'pending') return apvComputeRequestState(r, apvState.clockHours).currentLevel === key;
      return r.route === key;
    });
  }

  function apvRenderSidebar() {
    var persona = PERSONAS[apvState.persona];
    var sb = document.getElementById('apv-sidebar');
    if (!sb) return;
    var layout = document.querySelector('.apv-layout');
    /* Home is the only destination for AD/Director/Rep — a one-item sidebar is just
       chrome, so it only renders for personas with more than one destination
       (Finance, for its admin sub-pages). */
    var hasExtraDestinations = persona && persona.admin;
    if (layout) {
      layout.classList.toggle('apv-no-sidebar', !hasExtraDestinations);
      layout.classList.toggle('apv-sidebar-open', hasExtraDestinations && apvState.sidebarOpen);
    }
    var v = apvState.currentView;
    var html = '<div class="apv-sidebar-item ' + (v === 'home' ? 'apv-active' : '') + '" onclick="apvShowHome()"><span class="material-symbols-outlined" style="font-size:18px;">home</span>Home</div>';
    if (persona && persona.admin) {
      html += '<div class="apv-sidebar-divider"></div><div class="apv-sidebar-label">Administration</div>';
      html += '<div class="apv-sidebar-item ' + (v === 'admin' ? 'apv-active' : '') + '" onclick="apvShowAdmin()"><span class="material-symbols-outlined" style="font-size:18px;">tune</span>Approvers &amp; backups</div>';
      html += '<div class="apv-sidebar-item ' + (v === 'cost' ? 'apv-active' : '') + '" onclick="apvShowCostTables()"><span class="material-symbols-outlined" style="font-size:18px;">payments</span>Cost Tables</div>';
      html += '<div class="apv-sidebar-item ' + (v === 'thresholds' ? 'apv-active' : '') + '" onclick="apvShowThresholds()"><span class="material-symbols-outlined" style="font-size:18px;">rule</span>Thresholds</div>';
    }
    sb.innerHTML = html;
  }

  window.apvToggleSidebar = function () {
    apvState.sidebarOpen = !apvState.sidebarOpen;
    apvRenderSidebar();
  };

  /* ── single Home view — combines the SLA dashboard stats with the approval queue
     table so approvers land on one page instead of two. ── */
  var apvHomeListCache = [];

  function apvHomeRowHtml(rowList) {
    var showRepTeamHint = apvState.persona === 'finance' || (apvState.persona === 'director' && apvState.selectedTeam === 'all');
    var rows = rowList.map(function (r) {
      var st = apvComputeRequestState(r, apvState.clockHours);
      var team = apvTeamForRep(r.repName);
      var proposalId = apvDisplayProposalId(r.id);
      var quoteRef = apvDisplayQuoteRef(r.quoteRef);
      var opportunityRef = String(r.opportunityRef || '').trim();
      var opportunityName = apvDisplayOpportunityName(r.opportunityName, r.accountName);
      var quoteJs = quoteRef.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
      var opportunityJs = opportunityRef.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
      var reqIdJs = String(r.id || '').replace(/\\/g, '\\\\').replace(/'/g, "\\'");
      var quoteCell = quoteRef
        ? '<a href="#" class="apv-quote-link" onclick="event.stopPropagation();apvOpenRequestRef(\'Quote\', \'' + quoteJs + '\', \'' + reqIdJs + '\');return false;">' + apvEsc(quoteRef) + '</a>'
        : '—';
      var opportunityCell = opportunityRef
        ? '<a href="#" class="apv-quote-link" onclick="event.stopPropagation();apvOpenRequestRef(\'Opportunity\', \'' + opportunityJs + '\', \'' + reqIdJs + '\');return false;">' + apvEsc(opportunityName) + '</a>'
        : apvEsc(opportunityName);
      return '<tr onclick="apvOpenRequest(\'' + r.id + '\')">' +
        '<td><strong>' + apvEsc(proposalId) + '</strong></td>' +
        '<td><span class="badge badge--yellow">Pending</span></td>' +
        '<td>' + apvEsc(r.accountName) + '</td>' +
        '<td>' + quoteCell + '</td>' +
        '<td>' + opportunityCell + '</td>' +
        '<td>' + apvEsc(r.repName) + (showRepTeamHint && team ? '<br><span style="font-size:11px;color:#5c5c5c;">' + apvEsc(team.adName) + '’s team</span>' : '') + '</td>' +
        '<td style="color:' + (r.dm < 45 ? '#e10014' : '#008331') + ';font-weight:600;">' + r.dm.toFixed(1) + '%</td>' +
        '<td class="apv-age-' + st.ageClass + '">' + st.ageLabel + '</td>' +
        '<td>' + apvEsc(st.escalationLabel) + '</td>' +
        '</tr>';
    }).join('');
    return rows || '<tr><td colspan="9" style="text-align:center;color:#9a9a9a;padding:30px;">No matching requests</td></tr>';
  }

  /* Rep's own requests table (all statuses, not just pending) — uses the same
     visible column set as approver Home for consistency across personas. */
  function apvRepRowHtml(rowList) {
    var rows = rowList.map(function (r) {
      var st = apvComputeRequestState(r, apvState.clockHours);
      var proposalId = apvDisplayProposalId(r.id);
      var quoteRef = apvDisplayQuoteRef(r.quoteRef);
      var opportunityRef = String(r.opportunityRef || '').trim();
      var opportunityName = apvDisplayOpportunityName(r.opportunityName, r.accountName);
      var quoteJs = quoteRef.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
      var opportunityJs = opportunityRef.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
      var reqIdJs = String(r.id || '').replace(/\\/g, '\\\\').replace(/'/g, "\\'");
      var badgeClass = r.status === 'pending' ? 'badge--yellow' : (r.status === 'approved' ? 'badge--green' : 'badge--red');
      var statusLabel = r.status === 'pending' ? 'Pending' : (r.status === 'approved' ? 'Approved' : 'Rejected');
      var quoteCell = quoteRef
        ? '<a href="#" class="apv-quote-link" onclick="event.stopPropagation();apvOpenRequestRef(\'Quote\', \'" + quoteJs + "\', \'" + reqIdJs + "\');return false;">' + apvEsc(quoteRef) + '</a>'
        : '—';
      var opportunityCell = opportunityRef
        ? '<a href="#" class="apv-quote-link" onclick="event.stopPropagation();apvOpenRequestRef(\'Opportunity\', \'" + opportunityJs + "\', \'" + reqIdJs + "\');return false;">' + apvEsc(opportunityName) + '</a>'
        : apvEsc(opportunityName);
      var ageCell = r.status === 'pending' ? '<td class="apv-age-' + st.ageClass + '">' + st.ageLabel + '</td>' : '<td>—</td>';
      var escalationCell = r.status === 'pending' ? apvEsc(st.escalationLabel) : '—';
      return '<tr onclick="apvOpenRequest(\'' + r.id + '\')">' +
        '<td><strong>' + apvEsc(proposalId) + '</strong></td>' +
        '<td><span class="badge ' + badgeClass + '">' + statusLabel + '</span></td>' +
        '<td>' + apvEsc(r.accountName) + '</td>' +
        '<td>' + quoteCell + '</td>' +
        '<td>' + opportunityCell + '</td>' +
        '<td style="color:' + (r.dm < 45 ? '#e10014' : '#008331') + ';font-weight:600;">' + r.dm.toFixed(1) + '%</td>' +
        ageCell +
        '<td>' + escalationCell + '</td>' +
        '</tr>';
    }).join('');
    return rows || '<tr><td colspan="8" style="text-align:center;color:#9a9a9a;padding:30px;">No requests yet</td></tr>';
  }

  /* Which row-renderer the search field's live filter uses — set by whichever Home
     view is currently on screen, since the approver queue and the rep's own requests
     list have different row shapes but share one #apv-home-tbody/search convention. */
  var apvHomeRowRenderer = apvHomeRowHtml;

  /* Filters only the queue table body — the stat grid / stage breakdown above it stay
     pinned to the full scoped list, matching how a search box conventionally narrows
     what you're looking at without changing the KPIs it's drawn from. Also re-reads the
     search input itself rather than the tbody being replaced, so typing keeps focus. */
  window.apvFilterHomeRows = function (term) {
    var tbody = document.getElementById('apv-home-tbody');
    if (!tbody) return;
    var q = (term || '').toLowerCase().trim();
    var filtered = !q ? apvHomeListCache : apvHomeListCache.filter(function (r) {
      return (r.id + ' ' + r.proposalName + ' ' + r.accountName + ' ' + (r.quoteRef || '') + ' ' + (r.opportunityRef || '') + ' ' + (r.repName || '')).toLowerCase().indexOf(q) > -1;
    });
    tbody.innerHTML = apvHomeRowRenderer(filtered);
  };

  function apvMeasureLeftHomeContentHeight(leftCol) {
    var cards = leftCol.querySelectorAll('.apv-card');
    if (!cards || !cards.length) return leftCol.offsetHeight;
    var total = 0;
    for (var i = 0; i < cards.length; i += 1) {
      var card = cards[i];
      var styles = window.getComputedStyle(card);
      total += card.offsetHeight + (parseFloat(styles.marginTop) || 0) + (parseFloat(styles.marginBottom) || 0);
    }
    return Math.ceil(total);
  }

  function apvSyncHomeColumnsHeight() {
    var leftCol = document.getElementById('apv-home-left-col');
    var rightCard = document.getElementById('apv-home-leaderboard-card');
    if (!leftCol || !rightCard) return;

    rightCard.style.height = 'auto';
    /* On stacked mobile layout there is no side-by-side alignment requirement. */
    if ((window.innerWidth || 0) < 900) return;

    var target = apvMeasureLeftHomeContentHeight(leftCol);
    if (target > 0) {
      rightCard.style.height = target + 'px';
    }
  }

  window.apvShowHome = function () {
    apvState.currentView = 'home';
    apvState.openRequestId = null;
    apvState.sidebarOpen = false;
    var mainHome = document.getElementById('apv-main');
    if (mainHome) mainHome.classList.remove('apv-main--detail');
    if (apvState.persona === 'rep') { apvRenderRepHome(); return; }
    apvRenderSidebar();
    var key = apvState.persona;
    var isDirector = key === 'director';
    var allSegmentReps = [].concat.apply([], TEAMS.map(function (t) { return t.reps; }));

     /* Team scope — the single source of truth for everything on this page (stat
       cards, queue table, and the Rep leaderboard). AD always scopes to their own
       team; Director can drill into one team or view all teams combined
       (apvState.selectedTeam). Finance stays all-teams, matching its
       "Organization Performance" framing. */
    var scopeReps = allSegmentReps, scopeLabel = 'All teams', scopeGoals = SEGMENT_CONFIG.goals;
    if (key === 'ad') {
      scopeReps = TEAMS[0].reps;
      scopeLabel = TEAMS[0].adName + '’s team';
      scopeGoals = TEAMS[0].goals;
    } else if (isDirector && apvState.selectedTeam !== 'all') {
      var selectedTeam = TEAMS[Number(apvState.selectedTeam)];
      scopeReps = selectedTeam.reps;
      scopeLabel = selectedTeam.adName + '’s team';
      scopeGoals = selectedTeam.goals;
    }
    var teamSelectHtml = '';
    if (isDirector) {
      var teamOptions = '<option value="all"' + (apvState.selectedTeam === 'all' ? ' selected' : '') + '>All teams</option>' +
        TEAMS.map(function (t, i) {
          return '<option value="' + i + '"' + (apvState.selectedTeam === String(i) ? ' selected' : '') + '>' + apvEsc(t.adName) + '’s team</option>';
        }).join('');
      teamSelectHtml = '<select class="apv-team-select" aria-label="Filter Home by team" onchange="apvSelectTeam(this.value)">' + teamOptions + '</select>';
    }

    var list = apvQueueForPersona(key);
    var all = apvAllForPersona(key);
    if (isDirector && apvState.selectedTeam !== 'all') {
      list = list.filter(function (r) { return scopeReps.indexOf(r.repName) > -1; });
      all = all.filter(function (r) { return scopeReps.indexOf(r.repName) > -1; });
    }
    apvHomeListCache = list;
    apvHomeRowRenderer = apvHomeRowHtml;
    var decided = all.filter(function (r) { return r.status !== 'pending'; });
    var approved = decided.filter(function (r) { return r.status === 'approved'; });
    var rejected = decided.filter(function (r) { return r.status === 'rejected'; });

    var avgCycle = decided.length ? decided.reduce(function (sum, r) { return sum + r.cycleHours; }, 0) / decided.length : 0;
    var withinSLA = decided.length ? (decided.filter(function (r) { return (r.decidedStage || 'track') === 'track'; }).length / decided.length * 100) : 0;

    var stageCounts = { track: 0, reminder: 0, backup: 0, escalated: 0 };
    list.forEach(function (r) {
      var st = apvComputeRequestState(r, apvState.clockHours);
      stageCounts[st.stage] = (stageCounts[st.stage] || 0) + 1;
    });
    var bottleneckCount = stageCounts.backup + stageCounts.escalated;
    var bottleneckPct = list.length ? (bottleneckCount / list.length * 100) : 0;

    var tm = apvTeamMetrics(scopeReps);
    var mrrPct = scopeGoals.mrrTarget ? Math.min(100, (tm.mrr / scopeGoals.mrrTarget) * 100) : 0;
    var mrrColor = mrrPct >= 100 ? 'var(--color-dataviz-green-600)' : 'var(--color-dataviz-orange-600)';
    var repRows = apvRepLeaderboardRows(scopeReps);
    var isAdPersona = key === 'ad';
    var performanceTitle = isAdPersona ? 'Team performance' : 'Performance';
    var approvalsTitle = isAdPersona ? 'Team approvals' : 'Approvals';
    var leaderboardTitle = isAdPersona ? 'Team leaderboard' : 'Rep leaderboard';
    var scopeSubtitle = isAdPersona ? '' : apvEsc(scopeLabel);
    var hideScopeOnLeaderboard = isDirector && apvState.selectedTeam !== 'all';
    var leaderboardSubtitle = (isAdPersona || hideScopeOnLeaderboard)
      ? (repRows.length + ' reps')
      : (repRows.length + ' reps · ' + apvEsc(scopeLabel));

    /* Stats (left) next to the Rep leaderboard (right) as one top row, then the
       queue table full-width below. Performance vs. Approvals stats stay in
       separate labeled groups within the left column so the two categories
       aren't blurred together. Both cards' subtitles show the current team scope
       so it's visible everywhere, not just on the leaderboard where the selector
       itself lives. */
    var html = '<div class="apv-home-columns" style="margin-bottom:20px;">';

    html += '<div class="apv-home-col" id="apv-home-left-col" style="flex:7 1 420px;">';
    html += '<div class="apv-card" style="margin-bottom:16px;">';
    html += apvCardHeader(performanceTitle, scopeSubtitle);
    html += '<div class="apv-card-body">';
    html += '<div class="apv-stat-grid">';
    html += '<div class="apv-stat-card"><div class="apv-stat-label">Team MRR</div><div class="apv-stat-value">$' + tm.mrr.toLocaleString() + '</div>' +
      '<div class="dataviz-bar-track" style="margin-top:8px;"><div class="dataviz-bar-fill" style="width:' + mrrPct + '%;background:' + mrrColor + ';"></div></div>' +
      '<div class="apv-stat-delta">Target: $' + scopeGoals.mrrTarget.toLocaleString() + '</div></div>';
    html += apvStatCard('Avg DM%', tm.avgDM.toFixed(1) + '%', 'Goal: ' + (scopeGoals.dmTarget * 100).toFixed(0) + '%', tm.avgDM >= scopeGoals.dmTarget * 100 ? 'positive' : 'negative');
    html += apvStatCard('Avg EBITDA%', tm.avgEBITDA.toFixed(1) + '%', 'Goal: ' + (scopeGoals.ebitdaTarget * 100).toFixed(0) + '%', tm.avgEBITDA >= scopeGoals.ebitdaTarget * 100 ? 'positive' : 'negative');
    html += apvStatCard('Approved deals', tm.dealCount, '');
    html += '</div>';
    html += '</div></div>'; // end performance card

    html += '<div class="apv-card">';
    html += apvCardHeader(approvalsTitle, scopeSubtitle);
    html += '<div class="apv-card-body">';
    html += '<div class="apv-stat-grid">';
    /* Pending/Approved/Rejected are the three states of one thing (a request's
       disposition), not three independent metrics — one card instead of three,
       same reasoning as the escalation-stage meter being one chart, not four. */
    html += '<div class="apv-stat-card"><div class="apv-stat-label">Requests</div><div class="apv-status-strip">' +
      '<div class="apv-status-item"><span class="apv-status-count">' + list.length + '</span><span class="badge badge--yellow">Pending</span></div>' +
      '<div class="apv-status-item"><span class="apv-status-count">' + approved.length + '</span><span class="badge badge--green">Approved</span></div>' +
      '<div class="apv-status-item"><span class="apv-status-count">' + rejected.length + '</span><span class="badge badge--red">Rejected</span></div>' +
      '</div></div>';
    html += apvStatCard('Avg cycle time', avgCycle ? apvFormatHours(avgCycle) : '—', decided.length + ' decided');
    html += apvStatCard('Within SLA', decided.length ? (Math.round(withinSLA) + '%') : '—', 'resolved before backup stage', withinSLA >= 70 ? 'positive' : 'negative');
    html += apvStatCard('Bottleneck rate', list.length ? (Math.round(bottleneckPct) + '%') : '—', 'pending at backup+ stage', bottleneckPct <= 30 ? 'positive' : 'negative');
    html += '</div>';
    html += '</div></div>'; // end approvals card
    html += '</div>'; // end left col

    /* Rep leaderboard — MRR bar and the per-rep detail merged into one component
       instead of a bar chart plus a separate table repeating the same MRR figures. */
    html += '<div class="apv-home-col apv-home-col--leaderboard" style="flex:3 1 300px;"><div class="apv-card apv-card--leaderboard" id="apv-home-leaderboard-card">';
    html += apvCardHeader(leaderboardTitle, leaderboardSubtitle, teamSelectHtml);
    html += '<div class="apv-card-body">';
    if (repRows.length) {
      html += '<div class="apv-leaderboard-scroll">';
      var maxRepMrr = Math.max.apply(null, repRows.map(function (r) { return r.mrr; }).concat([1]));
      repRows.forEach(function (row) {
        var pct = Math.max(2, (row.mrr / maxRepMrr) * 100);
        html += '<div class="dataviz-bar-row" style="margin-bottom:4px;">' +
          '<span class="text-body-small" style="width:100px;flex-shrink:0;" title="' + apvEsc(row.rep) + '">' + apvEsc(row.rep) + '</span>' +
          '<div class="dataviz-bar-track"><div class="dataviz-bar-fill" style="width:' + pct + '%;background:var(--color-dataviz-single-accent);"></div></div>' +
          '<span class="dataviz-data-value" style="min-width:64px;text-align:right;">' + (row.mrr ? '$' + row.mrr.toLocaleString() : '$0') + '</span></div>';
        html += '<div class="text-micro" style="color:var(--color-secondary);margin:0 0 12px 112px;">' +
          row.submitted + ' submitted · ' + row.approved + ' approved' + (row.avgDM != null ? ' · ' + row.avgDM.toFixed(1) + '% avg DM' : '') + '</div>';
      });
      html += '</div>';
    } else {
      html += '<div class="dataviz-empty">No reps to show</div>';
    }
    html += '</div></div></div>'; // end card-body, end card, end right col

    html += '</div>'; // end top row

    // One full-width detail table.
    html += '<div class="apv-card"><table class="apv-table"><thead><tr><th>Proposal ID</th><th>Status</th><th>Account</th><th>Primary Quote</th><th>Opportunity</th><th>Rep</th><th>DM%</th><th>Age</th><th>Escalation</th></tr></thead><tbody id="apv-home-tbody">' +
      apvHomeRowHtml(list) +
      '</tbody></table></div>';

    var main = document.getElementById('apv-main');
    if (main) main.innerHTML = html;
    var searchInput = document.getElementById('apv-search-input');
    if (searchInput) searchInput.value = '';
    window.requestAnimationFrame(function () {
      apvSyncHomeColumnsHeight();
      window.requestAnimationFrame(apvSyncHomeColumnsHeight);
    });
    window.setTimeout(apvSyncHomeColumnsHeight, 120);
  };

  window.apvSelectTeam = function (val) {
    apvState.selectedTeam = val;
    window.apvShowHome();
  };

  window.apvOpenRequest = function (id) {
    apvState.currentView = 'detail';
    apvState.openRequestId = id;
    apvState.sidebarOpen = false;
    apvRenderSidebar();
    var r = apvRequestById(id);
    if (!r) { window.apvShowHome(); return; }
    var st = apvComputeRequestState(r, apvState.clockHours);
    var stepIndex = STEP_META.map(function (s) { return s.key; }).indexOf(st.currentLevel);
    if (stepIndex < 0) stepIndex = 1;

    var stepsHtml = STEP_META.map(function (s, i) {
      var cls = i < stepIndex ? 'done' : (i === stepIndex ? 'current' : 'pending');
      var levelCfg = apvOrgConfig[s.key];
      var sub = i === 0 ? r.repName : (i === stepIndex && levelCfg ? levelCfg.holderName : '');
      var backup = (i === stepIndex && levelCfg) ? '<div class="apv-step-backup">Backup: ' + apvEsc(levelCfg.backupName) + '</div>' : '';
      return '<div class="apv-step"><div class="apv-step-line ' + (i <= stepIndex ? 'done' : '') + '"></div>' +
        '<div class="apv-step-circle ' + cls + '">' + (cls === 'done' ? '<span class="material-symbols-outlined" style="font-size:15px;">check</span>' : s.label.charAt(0)) + '</div>' +
        '<div class="apv-step-label">' + s.label + '</div><div class="apv-step-sub">' + apvEsc(sub) + '</div>' + backup + '</div>';
    }).join('');

    var tlIconMap = { submit: 'upload', reminder: 'notifications', backup: 'group', rfi: 'help', decision: 'check_circle' };
    var tlHtml = st.timeline.map(function (t) {
      return '<div class="apv-tl-item"><div class="apv-tl-icon ' + t.type + '"><span class="material-symbols-outlined">' + (tlIconMap[t.type] || 'circle') + '</span></div>' +
        '<div><div class="apv-tl-title">' + apvEsc(t.title) + '</div><div class="apv-tl-meta">' + apvEsc(t.meta) + '</div></div></div>';
    }).join('');

    var canAct = r.status === 'pending' && apvState.persona !== 'rep';
    var headerOpportunityRef = String(r.opportunityRef || '').trim();
    var headerQuoteRef = apvDisplayQuoteRef(r.quoteRef);
    var headerAccountName = String(r.accountName || '').trim();
    var headerReqJs = String(r.id || '').replace(/\\/g, '\\\\').replace(/'/g, "\\'");
    var proposalTitle = apvDisplayProposalId(r.id) || String(r.id || r.proposalName || '').trim();
    function apvHeaderRefLink(type, value, label) {
      var jsValue = String(value || '').replace(/\\/g, '\\\\').replace(/'/g, "\\'");
      return '<a href="#" class="apv-detail-header-meta-link" onclick="apvOpenRequestRef(\'' + type + '\', \'' + jsValue + '\', \'' + headerReqJs + '\');return false;">' +
        apvEsc(label) + ': ' + apvEsc(value) + '</a>';
    }
    var headerRefsHtml = '<div class="apv-detail-header-meta">' +
      (headerAccountName
        ? '<span class="apv-detail-header-meta-item">Account: ' + apvEsc(headerAccountName) + '</span><span class="apv-detail-header-meta-sep" aria-hidden="true">|</span>'
        : '') +
      (headerOpportunityRef
        ? apvHeaderRefLink('Opportunity', headerOpportunityRef, 'Opportunity')
        : '<span class="apv-detail-header-meta-item apv-detail-header-meta-item--muted">Opportunity: —</span>') +
      '<span class="apv-detail-header-meta-sep" aria-hidden="true">|</span>' +
      (headerQuoteRef
        ? apvHeaderRefLink('Quote', headerQuoteRef, 'Quote')
        : '<span class="apv-detail-header-meta-item apv-detail-header-meta-item--muted">Quote: —</span>') +
      '</div>';
    var metricsHtml = apvBuildConsolidatedMetricsHtml(r);
    var attachmentsHtml = apvAttachmentListHtml(r);
    var statusBadgeClass = r.status === 'pending' ? 'badge--yellow' : (r.status === 'approved' ? 'badge--green' : 'badge--red');
    var statusLabel = r.status === 'pending' ? 'Pending' : (r.status === 'approved' ? 'Approved' : 'Rejected');

    var headerActionsHtml = '<div class="apv-detail-header-actions"><div class="apv-status-chip"><span class="apv-status-chip-label">Status:</span><span class="badge ' + statusBadgeClass + '">' + statusLabel + '</span></div>' +
      (canAct
        ? '<button class="btn btn--primary btn--small" type="button" onclick="apvOpenDecisionModal(\'approve\')"><span class="material-symbols-outlined" style="font-size:16px;">check_circle</span>Approve</button>' +
          '<button class="btn btn--secondary btn--small" type="button" onclick="apvOpenDecisionModal(\'reject\')"><span class="material-symbols-outlined" style="font-size:16px;">cancel</span>Reject</button>' +
          '<button class="btn btn--ghost btn--small" type="button" onclick="apvOpenDecisionModal(\'rfi\')"><span class="material-symbols-outlined" style="font-size:16px;">help</span>Request info</button>'
        : '') +
      '</div>';

    var main = document.getElementById('apv-main');
    if (!main) return;
    main.classList.add('apv-main--detail');
    main.innerHTML =
      '<div class="apv-detail-page">' +
      '<div class="apv-detail-header">' +
        '<div class="apv-detail-header-main">' +
        '<button class="apv-back-btn apv-back-btn--inline" type="button" aria-label="Back to home" title="Back to home" onclick="apvShowHome()"><span class="material-symbols-outlined" style="font-size:30px;">arrow_back</span></button>' +
        '<div class="apv-detail-header-copy"><div class="apv-page-title">Proposal ' + apvEsc(proposalTitle) + '</div>' +
        headerRefsHtml + '</div></div>' +
        headerActionsHtml +
      '</div>' +
      '<div class="apv-detail-section-title">Approval chain</div><div class="apv-detail-section-body"><div class="apv-stepper">' + stepsHtml + '</div></div>' +
      '<div class="apv-detail-section-title">Metrics</div><div class="apv-detail-section-body">' + metricsHtml + '</div>' +
      '<div class="apv-detail-section-title">Attachments</div><div class="apv-detail-section-body">' +
        attachmentsHtml +
      '</div>' +
      '<div class="apv-detail-section-title">Audit history</div><div class="apv-detail-section-body"><div class="apv-timeline">' + tlHtml + '</div></div>' +
      '<div class="apv-detail-section-title">Justification</div><div class="apv-detail-section-body">' +
      '<div style="background:var(--color-surface-alt);border-radius:8px;padding:12px 14px;font-size:13px;">' + apvEsc(r.justification) + '</div>' +
        '</div>' +
        '</div>';
  };

  /* Rep's Home — single page, same shape as AD/Director's merged Home: a compact
     "My Performance" summary against one consolidated goal per metric, a monthly
     request-count breakdown, and the rep's full request list (all statuses) below —
     no separate "My Requests" destination. Deliberately still no Quick Actions
     panel, per Leo's feedback (reps don't approve, so there's nothing to action). */
  function apvRenderRepHome() {
    apvRenderSidebar();
    var rm = apvRepMetrics(REP_CONFIG.name);
    apvHomeListCache = rm.requests;
    apvHomeRowRenderer = apvRepRowHtml;
    var mrrPct = REP_CONFIG.goals.mrrTarget ? Math.min(100, (rm.mrr / REP_CONFIG.goals.mrrTarget) * 100) : 0;
    var mrrColor = mrrPct >= 100 ? 'var(--color-dataviz-green-600)' : 'var(--color-dataviz-orange-600)';
    var dmTargetPct = REP_CONFIG.goals.dmTarget * 100;
    var ebitdaTargetPct = REP_CONFIG.goals.ebitdaTarget * 100;

    var html = '<div class="apv-home-columns" style="margin-bottom:20px;">';

    html += '<div class="apv-home-col" style="flex:7 1 420px;"><div class="apv-card">';
    html += apvCardHeader('My performance');
    html += '<div class="apv-card-body">';
    html += '<div class="apv-stat-grid">';
    html += '<div class="apv-stat-card"><div class="apv-stat-label">My MRR</div><div class="apv-stat-value">$' + rm.mrr.toLocaleString() + '</div>' +
      '<div class="dataviz-bar-track" style="margin-top:8px;"><div class="dataviz-bar-fill" style="width:' + mrrPct + '%;background:' + mrrColor + ';"></div></div>' +
      '<div class="apv-stat-delta">Target: $' + REP_CONFIG.goals.mrrTarget.toLocaleString() + '</div></div>';
    html += apvStatCard('My DM%', rm.avgDM.toFixed(1) + '%', 'Goal: ' + dmTargetPct.toFixed(0) + '%', rm.avgDM >= dmTargetPct ? 'positive' : 'negative');
    html += apvStatCard('My EBITDA%', rm.avgEBITDA.toFixed(1) + '%', 'Goal: ' + ebitdaTargetPct.toFixed(0) + '%', rm.avgEBITDA >= ebitdaTargetPct ? 'positive' : 'negative');
    html += apvStatCard('NPV (approved)', '$' + rm.npv.toLocaleString(), '');
    html += '</div>';
    html += '</div></div></div>'; // end card-body, end card, end left col

    html += '<div class="apv-home-col" style="flex:3 1 300px;"><div class="apv-card">';
    html += apvCardHeader('Approvals');
    html += '<div class="apv-card-body">';
    html += '<div class="apv-stat-grid">';
    html += '<div class="apv-stat-card"><div class="apv-stat-label">Requests</div><div class="apv-status-strip">' +
      '<div class="apv-status-item"><span class="apv-status-count">' + rm.pending + '</span><span class="badge badge--yellow">Pending</span></div>' +
      '<div class="apv-status-item"><span class="apv-status-count">' + rm.approved + '</span><span class="badge badge--green">Approved</span></div>' +
      '<div class="apv-status-item"><span class="apv-status-count">' + rm.rejected + '</span><span class="badge badge--red">Rejected</span></div>' +
      '</div></div>';
    html += '</div>';
    html += '</div></div></div>'; // end card-body, end card, end right col

    html += '</div>'; // end top row

    html += '<div class="apv-card"><table class="apv-table"><thead><tr><th>Proposal ID</th><th>Status</th><th>Account</th><th>Primary Quote</th><th>Opportunity</th><th>DM%</th><th>Age</th><th>Escalation</th></tr></thead><tbody id="apv-home-tbody">' +
      apvRepRowHtml(rm.requests) +
      '</tbody></table></div>';

    var main = document.getElementById('apv-main');
    if (main) main.innerHTML = html;
    var searchInput = document.getElementById('apv-search-input');
    if (searchInput) searchInput.value = '';
  }

  window.apvShowAdmin = function () {
    apvState.currentView = 'admin';
    apvState.sidebarOpen = false;
    apvRenderSidebar();
    var mainAdmin = document.getElementById('apv-main');
    if (mainAdmin) mainAdmin.classList.remove('apv-main--detail');
    var rows = LEVEL_ORDER.map(function (level) {
      var cfg = apvOrgConfig[level];
      return '<tr><td>' + LEVEL_LABEL[level] + '</td>' +
        '<td><input class="apv-admin-input" data-lvl="' + level + '" data-field="holderName" value="' + apvEsc(cfg.holderName) + '"></td>' +
        '<td><input class="apv-admin-input" data-lvl="' + level + '" data-field="backupName" value="' + apvEsc(cfg.backupName) + '"></td>' +
        '<td><input class="apv-admin-input" type="number" min="0" step="0.5" data-lvl="' + level + '" data-field="reminderHours" value="' + cfg.reminderHours + '" style="max-width:70px;"></td>' +
        '<td><input class="apv-admin-input" type="number" min="0" step="0.5" data-lvl="' + level + '" data-field="backupHours" value="' + cfg.backupHours + '" style="max-width:70px;"></td></tr>';
    }).join('');
    var volumeByRole = LEVEL_ORDER.map(function (level) {
      var n = REQUESTS.filter(function (r) { return r.status !== 'pending' && r.route === level; }).length;
      return { label: LEVEL_LABEL[level], value: n, formatted: String(n) };
    });
    var cycleByRole = LEVEL_ORDER.map(function (level) {
      var decidedForRole = REQUESTS.filter(function (r) { return r.status !== 'pending' && r.route === level; });
      var avg = decidedForRole.length ? decidedForRole.reduce(function (s, r) { return s + r.cycleHours; }, 0) / decidedForRole.length : 0;
      return { label: LEVEL_LABEL[level], value: avg, formatted: avg ? apvFormatHours(avg) : '—' };
    });

    var main = document.getElementById('apv-main');
    if (!main) return;
    main.innerHTML = '<div class="apv-page-title">Approvers &amp; backups</div>' +
      '<div class="apv-page-sub">Backup coverage and escalation thresholds per role. These values drive the Approval queue\'s escalation engine.</div>' +
      '<div class="apv-card" style="margin-bottom:16px;">' + apvCardHeader('Approval volume by role', 'Decided requests, all-time') + '<div class="apv-card-body">' + apvCategoricalBarChart(volumeByRole) + '</div></div>' +
      '<div class="apv-card" style="margin-bottom:16px;">' + apvCardHeader('Avg cycle time by role', 'Decided requests, all-time') + '<div class="apv-card-body">' + apvCategoricalBarChart(cycleByRole) + '</div></div>' +
      '<div class="apv-card"><table class="apv-admin-table"><thead><tr><th>Role</th><th>Holder</th><th>Backup</th><th>Reminder (h)</th><th>Escalate to backup (h)</th></tr></thead><tbody>' + rows + '</tbody></table></div>' +
      '<div class="apv-save-bar"><button class="apv-btn" style="background:#ece9e4;color:#000;" type="button" onclick="apvShowAdmin()">Reset changes</button><button class="apv-btn apv-btn-approve" type="button" onclick="apvSaveAdminConfig()"><span class="material-symbols-outlined" style="font-size:16px;">save</span>Save</button></div>';
  };

  window.apvSaveAdminConfig = function () {
    var inputs = document.querySelectorAll('#apv-main [data-lvl]');
    for (var i = 0; i < inputs.length; i++) {
      var input = inputs[i];
      var lvl = input.getAttribute('data-lvl'), field = input.getAttribute('data-field');
      if (!apvOrgConfig[lvl]) continue;
      var isHours = field === 'reminderHours' || field === 'backupHours';
      apvOrgConfig[lvl][field] = isHours ? (parseFloat(input.value) || 0) : input.value;
    }
    apvShowToast('Approvers & backups saved');
    window.apvShowAdmin();
  };

  /* ── Cost Tables admin (Finance) ── ported from vzc-pricing-desk.html's
     renderCostManagement family; kept in-memory only (no localStorage — deliberately, so
     this page and the standalone vzc-pricing-desk.html prototype never bleed state into
     each other via a shared localStorage key on the same origin). */
  var DEFAULT_COST_CONFIG = {
    recurring: {
      vtu:             { badDebt: 0.87, dataNetwork: 0.61, ga: 1.92, mapping: 0.78, otherServices: 0.31, serverHosting: 1.41, support: 1.26, wireless: 0.0024, rma: 0.04, oemDataFee: 6.50 },
      videoFwd:        { badDebt: 0.87, dataNetwork: 0.61, ga: 1.92, mapping: 0.00, otherServices: 0.31, serverHosting: 1.41, support: 1.26, wireless: 0.50, rma: 0.00 },
      videoDual:       { badDebt: 0.87, dataNetwork: 0.61, ga: 1.92, mapping: 0.00, otherServices: 0.31, serverHosting: 1.41, support: 1.26, wireless: 0.50, rma: 0.00 },
      assetPowered:    { badDebt: 0.87, dataNetwork: 0.61, ga: 1.92, mapping: 0.78, otherServices: 0.31, serverHosting: 1.41, support: 1.26, wireless: 0.0024, rma: 0.04 },
      assetNonPowered: { badDebt: 0.87, dataNetwork: 0.61, ga: 1.92, mapping: 0.78, otherServices: 0.31, serverHosting: 1.41, support: 1.26, wireless: 0.0024, rma: 0.04 }
    },
    oneTime: {
      vtu:             { hardware: 75.40,  installation: 82.99, implServices: 21.46, shipping: 8.69 },
      videoFwd:        { hardware: 261.20, installation: 76.21, implServices: 21.46, shipping: 8.69 },
      videoDual:       { hardware: 286.98, installation: 76.21, implServices: 21.46, shipping: 8.69 },
      assetPowered:    { hardware: 79.86,  installation: 82.21, implServices: 21.46, shipping: 8.69 },
      assetNonPowered: { hardware: 65.08,  installation: 0.00,  implServices: 21.46, shipping: 8.69 },
      evc: {
        'EVC-DVR-Rear':               { hardware: 405.00, installation: 220.00 },
        'EVC-DVR-Rear-Cargo':         { hardware: 527.00, installation: 330.00 },
        'EVC-DVR-Rear-2 sides':       { hardware: 615.00, installation: 440.00 },
        'EVC-DVR-Rear-Cargo-2 sides': { hardware: 747.00, installation: 550.00 }
      }
    },
    dealLevel: {
      SMB:        { commissionPct: 0.0847, ccFeePct: 0.007, marketingPerSale: 478.15,  sellingPerSale: 738.93 },
      Enterprise: { commissionPct: 0.0937, ccFeePct: 0.007, marketingPerSale: 1586.52, sellingPerSale: 9337.15 },
      Government: { commissionPct: 0.0949, ccFeePct: 0.007, marketingPerSale: 303.00,  sellingPerSale: 1538.37 }
    }
  };
  var apvCostConfig = JSON.parse(JSON.stringify(DEFAULT_COST_CONFIG));
  var apvCostTab = 'recurring';

  var CORE_KEYS = ['vtu', 'videoFwd', 'videoDual', 'assetPowered', 'assetNonPowered'];
  var CORE_LABELS = { vtu: 'VTU (GPS)', videoFwd: 'Video Fwd', videoDual: 'Video Dual', assetPowered: 'Asset (Powered)', assetNonPowered: 'Asset (Non-Pwr)' };

  function apvRenderRecurringCostTable() {
    var categories = Object.keys(apvCostConfig.recurring.vtu);
    var html = '<div class="apv-card" style="padding:16px;overflow-x:auto;"><table class="apv-edit-table"><thead><tr><th>Category</th>';
    CORE_KEYS.forEach(function (c) { html += '<th>' + CORE_LABELS[c] + '</th>'; });
    html += '</tr></thead><tbody>';
    categories.forEach(function (cat) {
      html += '<tr><td>' + cat + '</td>';
      CORE_KEYS.forEach(function (c) {
        var val = (apvCostConfig.recurring[c] && apvCostConfig.recurring[c][cat] != null) ? apvCostConfig.recurring[c][cat] : 0;
        html += '<td><input type="number" class="apv-edit-input" step="0.01" value="' + val + '" data-path="recurring.' + c + '.' + cat + '"></td>';
      });
      html += '</tr>';
    });
    html += '</tbody></table></div>';
    return html;
  }

  function apvRenderOneTimeCostTable() {
    var categories = ['hardware', 'installation', 'implServices', 'shipping'];
    var html = '<div class="apv-card" style="padding:16px;overflow-x:auto;"><table class="apv-edit-table"><thead><tr><th>Category</th>';
    CORE_KEYS.forEach(function (c) { html += '<th>' + CORE_LABELS[c] + '</th>'; });
    html += '</tr></thead><tbody>';
    categories.forEach(function (cat) {
      html += '<tr><td>' + cat + '</td>';
      CORE_KEYS.forEach(function (c) {
        var val = (apvCostConfig.oneTime[c] && apvCostConfig.oneTime[c][cat] != null) ? apvCostConfig.oneTime[c][cat] : 0;
        html += '<td><input type="number" class="apv-edit-input" step="0.01" value="' + val + '" data-path="oneTime.' + c + '.' + cat + '"></td>';
      });
      html += '</tr>';
    });
    html += '</tbody></table></div>';

    html += '<div class="apv-card" style="padding:16px;overflow-x:auto;margin-top:12px;"><div class="apv-detail-card-title">EVC Accessories</div><table class="apv-edit-table"><thead><tr><th>Configuration</th><th>Hardware</th><th>Installation</th></tr></thead><tbody>';
    Object.keys(apvCostConfig.oneTime.evc || {}).forEach(function (key) {
      var val = apvCostConfig.oneTime.evc[key];
      html += '<tr><td>' + key + '</td>' +
        '<td><input type="number" class="apv-edit-input" step="0.01" value="' + val.hardware + '" data-path="oneTime.evc.' + key + '.hardware"></td>' +
        '<td><input type="number" class="apv-edit-input" step="0.01" value="' + val.installation + '" data-path="oneTime.evc.' + key + '.installation"></td></tr>';
    });
    html += '</tbody></table></div>';
    return html;
  }

  function apvRenderDealLevelCostTable() {
    var segments = ['SMB', 'Enterprise', 'Government'];
    var fields = ['commissionPct', 'ccFeePct', 'marketingPerSale', 'sellingPerSale'];
    var fieldLabels = { commissionPct: 'Commission %', ccFeePct: 'CC Fee %', marketingPerSale: 'Marketing / Sale ($)', sellingPerSale: 'Selling / Sale ($)' };
    var html = '<div class="apv-card" style="padding:16px;overflow-x:auto;"><table class="apv-edit-table"><thead><tr><th>Field</th>';
    segments.forEach(function (s) { html += '<th>' + s + '</th>'; });
    html += '</tr></thead><tbody>';
    fields.forEach(function (f) {
      html += '<tr><td>' + fieldLabels[f] + '</td>';
      segments.forEach(function (s) {
        var val = (apvCostConfig.dealLevel[s] && apvCostConfig.dealLevel[s][f] != null) ? apvCostConfig.dealLevel[s][f] : 0;
        html += '<td><input type="number" class="apv-edit-input" step="0.0001" value="' + val + '" data-path="dealLevel.' + s + '.' + f + '"></td>';
      });
      html += '</tr>';
    });
    html += '</tbody></table></div>';
    return html;
  }

  window.apvShowCostTables = function () {
    apvState.currentView = 'cost';
    apvState.sidebarOpen = false;
    apvRenderSidebar();
    var mainCost = document.getElementById('apv-main');
    if (mainCost) mainCost.classList.remove('apv-main--detail');
    var html = '<div class="apv-page-title">Cost Tables</div><div class="apv-page-sub">Edit cost-to-serve values used for margin calculations.</div>';
    html += '<div class="apv-editor-tabs">';
    [['recurring', 'Recurring Costs'], ['oneTime', 'One-Time Costs'], ['dealLevel', 'Deal-Level Costs']].forEach(function (t) {
      html += '<button class="apv-editor-tab ' + (apvCostTab === t[0] ? 'apv-active' : '') + '" type="button" onclick="apvSetCostTab(\'' + t[0] + '\')">' + t[1] + '</button>';
    });
    html += '</div>';
    if (apvCostTab === 'recurring') html += apvRenderRecurringCostTable();
    else if (apvCostTab === 'oneTime') html += apvRenderOneTimeCostTable();
    else html += apvRenderDealLevelCostTable();
    html += '<div class="apv-save-bar"><button class="apv-btn" style="background:#ece9e4;color:#000;" type="button" onclick="apvResetCosts()">Reset to defaults</button><button class="apv-btn apv-btn-approve" type="button" onclick="apvSaveCosts()"><span class="material-symbols-outlined" style="font-size:16px;">save</span>Save changes</button></div>';
    var main = document.getElementById('apv-main');
    if (main) main.innerHTML = html;
  };

  window.apvSetCostTab = function (tab) {
    apvCostTab = tab;
    window.apvShowCostTables();
  };

  window.apvSaveCosts = function () {
    var inputs = document.querySelectorAll('#apv-main .apv-edit-input[data-path]');
    for (var i = 0; i < inputs.length; i++) {
      var input = inputs[i];
      var path = input.getAttribute('data-path').split('.');
      var obj = apvCostConfig;
      for (var p = 0; p < path.length - 1; p++) {
        if (!obj[path[p]]) obj[path[p]] = {};
        obj = obj[path[p]];
      }
      obj[path[path.length - 1]] = parseFloat(input.value) || 0;
    }
    apvShowToast('Cost tables saved');
    window.apvShowCostTables();
  };

  window.apvResetCosts = function () {
    apvCostConfig = JSON.parse(JSON.stringify(DEFAULT_COST_CONFIG));
    apvShowToast('Cost tables reset to defaults');
    window.apvShowCostTables();
  };

  /* ── Threshold Management admin (Finance) — operates on apvOrgConfig's per-level
     reminder/backup hours (Approvals escalation thresholds), not on Promotions
     Management's DM%/EBITDA% margin thresholds, which are out of scope here. ── */
  window.apvShowThresholds = function () {
    apvState.currentView = 'thresholds';
    apvState.sidebarOpen = false;
    apvRenderSidebar();
    var mainThresholds = document.getElementById('apv-main');
    if (mainThresholds) mainThresholds.classList.remove('apv-main--detail');
    var html = '<div class="apv-page-title">Escalation thresholds</div><div class="apv-page-sub">How long a request sits before a reminder, backup notification, or up-level escalation fires.</div>';
    html += '<div class="apv-card" style="padding:16px;"><table class="apv-edit-table"><thead><tr><th>Level</th><th>Reminder (h)</th><th>Escalate to backup (h)</th><th>Escalate up (h)</th></tr></thead><tbody>';
    LEVEL_ORDER.forEach(function (level) {
      var cfg = apvOrgConfig[level];
      html += '<tr><td>' + LEVEL_LABEL[level] + '</td>' +
        '<td><input type="number" class="apv-edit-input" step="0.5" min="0" value="' + cfg.reminderHours + '" data-thresh="' + level + '.reminderHours"></td>' +
        '<td><input type="number" class="apv-edit-input" step="0.5" min="0" value="' + cfg.backupHours + '" data-thresh="' + level + '.backupHours"></td>' +
        '<td style="color:#5c5c5c;">' + (cfg.backupHours * 2) + 'h <span style="font-size:10.5px;">(2× backup window)</span></td></tr>';
    });
    html += '</tbody></table></div>';
    html += '<div class="apv-card" style="padding:16px;margin-top:12px;"><div class="apv-detail-card-title">Floor pricing</div>' +
      '<div style="display:flex;gap:24px;flex-wrap:wrap;">' +
      '<div><div style="font-size:12px;font-weight:600;margin-bottom:4px;">Soft floor multiplier</div>' +
      '<input type="number" class="apv-edit-input" step="0.01" id="apv-floor-soft" value="' + (apvCostConfig.floorPrices ? apvCostConfig.floorPrices.softMultiplier : 1.15) + '" style="width:100px;">' +
      '<div style="font-size:11px;color:#5c5c5c;margin-top:4px;">Unit price &lt; cost × this = Finance approval</div></div>' +
      '<div><div style="font-size:12px;font-weight:600;margin-bottom:4px;">Hard floor multiplier</div>' +
      '<input type="number" class="apv-edit-input" step="0.01" id="apv-floor-hard" value="' + (apvCostConfig.floorPrices ? apvCostConfig.floorPrices.hardMultiplier : 1.00) + '" style="width:100px;">' +
      '<div style="font-size:11px;color:#5c5c5c;margin-top:4px;">Unit price &lt; cost × this = blocked</div></div>' +
      '</div></div>';
    html += '<div class="apv-save-bar"><button class="apv-btn" style="background:#ece9e4;color:#000;" type="button" onclick="apvResetThresholds()">Reset to defaults</button><button class="apv-btn apv-btn-approve" type="button" onclick="apvSaveThresholds()"><span class="material-symbols-outlined" style="font-size:16px;">save</span>Save thresholds</button></div>';
    var main = document.getElementById('apv-main');
    if (main) main.innerHTML = html;
  };

  window.apvSaveThresholds = function () {
    var inputs = document.querySelectorAll('#apv-main [data-thresh]');
    for (var i = 0; i < inputs.length; i++) {
      var input = inputs[i];
      var parts = input.getAttribute('data-thresh').split('.');
      var level = parts[0], field = parts[1];
      if (!apvOrgConfig[level]) continue;
      apvOrgConfig[level][field] = parseFloat(input.value) || 0;
    }
    apvCostConfig.floorPrices = {
      softMultiplier: parseFloat((document.getElementById('apv-floor-soft') || {}).value) || 1.15,
      hardMultiplier: parseFloat((document.getElementById('apv-floor-hard') || {}).value) || 1.00
    };
    apvShowToast('Thresholds saved');
    window.apvShowThresholds();
  };

  window.apvResetThresholds = function () {
    apvOrgConfig.ad.reminderHours = 2; apvOrgConfig.ad.backupHours = 8;
    apvOrgConfig.director.reminderHours = 4; apvOrgConfig.director.backupHours = 24;
    apvOrgConfig.finance.reminderHours = 8; apvOrgConfig.finance.backupHours = 48;
    apvCostConfig.floorPrices = { softMultiplier: 1.15, hardMultiplier: 1.00 };
    apvShowToast('Thresholds reset to defaults');
    window.apvShowThresholds();
  };

  /* apvStatCard is the tile helper used by the Home view's stat grid (cycle-time / SLA /
     bottleneck metrics — the reference prototype's dashboard only ever computed
     MRR/DM%/EBITDA%, so these were newly designed here). */
  function apvStatCard(label, value, delta, cls) {
    return '<div class="apv-stat-card"><div class="apv-stat-label">' + apvEsc(label) + '</div><div class="apv-stat-value">' + apvEsc(String(value)) + '</div>' +
      (delta ? '<div class="apv-stat-delta' + (cls ? ' apv-' + cls : '') + '">' + apvEsc(delta) + '</div>' : '') + '</div>';
  }

  /* Card header — title (+ optional controls, e.g. the Rep leaderboard's team select)
     and optional subtitle, in a band that spans the card's full width with its own
     padding, so the bottom rule reaches the card's edges instead of being inset by
     the card body's own padding. titleHtml/subtitleHtml are pre-built HTML (callers
     already apvEsc() any user data before passing it in). */
  function apvCardHeader(titleHtml, subtitleHtml, controlsHtml) {
    var html = '<div class="apv-card-header"><div style="display:flex;align-items:center;justify-content:space-between;gap:8px;"><p class="dataviz-title">' + titleHtml + '</p>' + (controlsHtml || '') + '</div>';
    if (subtitleHtml) html += '<p class="dataviz-subtitle">' + subtitleHtml + '</p>';
    html += '</div>';
    return html;
  }

  function apvRenderNotifList() {
    var list = document.getElementById('apv-notif-list');
    if (!list) return;
    list.innerHTML = NOTIFICATIONS.map(function (n) {
      return '<div class="apv-notif-item"><span class="apv-chan-pill ' + (n.chan === 'slack' ? 'apv-chan-slack' : 'apv-chan-inapp') + '">' + (n.chan === 'slack' ? 'S' : 'A') + '</span>' +
        '<div><div style="font-weight:600;">' + apvEsc(n.title) + '</div><div style="color:#5c5c5c;">' + apvEsc(n.body) + '</div><div style="font-size:10.5px;color:#9a9a9a;margin-top:2px;">' + apvEsc(n.time) + '</div></div></div>';
    }).join('');
    apvSyncNotifBadge();
  }

  window.apvToggleNotif = function (evt) {
    if (evt) evt.stopPropagation();
    var pd = document.getElementById('apv-persona-dropdown');
    if (pd) pd.classList.remove('apv-open');
    var nd = document.getElementById('apv-notif-dropdown');
    if (nd) nd.classList.toggle('apv-open');
  };

  window.apvTogglePersonaMenu = function (evt) {
    if (evt) evt.stopPropagation();
    var nd = document.getElementById('apv-notif-dropdown');
    if (nd) nd.classList.remove('apv-open');
    var dd = document.getElementById('apv-persona-dropdown');
    if (dd) dd.classList.toggle('apv-open');
  };

  document.addEventListener('click', function (evt) {
    var pd = document.getElementById('apv-persona-dropdown');
    var nd = document.getElementById('apv-notif-dropdown');
    var insidePersona = evt.target.closest('#apv-persona-dropdown') || evt.target.closest('#apv-chevron-btn');
    if (pd && !insidePersona) pd.classList.remove('apv-open');
    var insideNotif = evt.target.closest('#apv-notif-dropdown') || evt.target.closest('#apv-bell-btn');
    if (nd && !insideNotif) nd.classList.remove('apv-open');
  });

  /* Called once by each role page on load — e.g. apvBoot('ad'). The persona dropdown
     itself is static markup (plain links to the sibling files) written directly in each
     HTML file, not rendered here, since navigating between roles is now a real page load. */
  window.apvBoot = function (personaKey) {
    apvState.persona = personaKey;
    apvEnsureDecisionModal();
    apvRenderNotifList();
    window.addEventListener('resize', function () {
      if (apvState.currentView === 'home' && apvState.persona !== 'rep') {
        apvSyncHomeColumnsHeight();
      }
    });
    window.apvShowHome();
  };
}());
