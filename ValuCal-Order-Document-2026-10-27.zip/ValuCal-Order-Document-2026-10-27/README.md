# Valu Cal — Order document (design, 2026-10-27)

Open **index.html** in Chrome or Safari (keep the folders next to it).

The document the customer signs in DocuSign at the Contract step. The **Simulation Builder** on the left switches
scenarios: à la carte / bundles (and what each bundle includes), MSA discount, promotion, one-time charges, order
schedule, Existing Business (co-term) and the DocuSign signer fields.

Default: à la carte subscriptions with the MSA discount (10%) and a promotion on some of them (VTU and Dash Cam).
