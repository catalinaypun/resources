/* Valu Cal — shared product catalog (Initial Sales + Existing Accounts)
   One source for the pricing dictionaries used by Configure Solution / Expansion.
   2026-10-07 (Catalina): Existing Accounts adopts the Initial Sales catalog (adds DVIR,
   Roadside Assistance, DMS, Navigation, PTO, Fuel Card; Safety bundle as in Initial Sales).
   Bundles can be chosen at any contract term in both flows (no termRequired).
   PLACEHOLDER prices — real catalog pending from business.
   Loaded as a classic script before each flow's main script: these top-level consts are
   globals shared by both flows — do NOT redeclare them in the flow files. */

// Core subscriptions (per vehicle / asset, monthly list price)
const corePricing = {
  'vtu': { name: 'VTU Only', price: 35.00 },
  'vtu-ffc': { name: 'VTU + Forward Facing Camera', price: 65.00 },
  'vtu-dual': { name: 'VTU + Dual Camera Subscription', price: 75.00 },
  'asset-powered': { name: 'Powered Asset', price: 39.00 },
  'asset-nonpowered': { name: 'Non-Powered Asset', price: 19.00 },
};

// ── SEASONAL (2026-10-19, design proposal — per Catalina) ─────────────────────────────────────────
// A solution can be seasonal: the rep picks its active months, only those months are billed, and the price is
// fixed with a premium. Demo premium: +10% (no real values yet). Shown only with the Simulation Builder's
// "Seasonal subscriptions" on (on by default for now, for the demos). Open questions in seasonal-design.md.
// 2026-10-19 (per Leo): seasonal billing is an account setup option (Simulation Builder › Account configuration ›
// Seasonal billing). Not available by default since 2026-10-21 (per Catalina).
var seasonalSim = false; // 2026-10-21 (per Catalina): off by default — turn it on in Simulation Builder › Account configuration
const SEASONAL_PREMIUM_PCT = 10;
const SEASON_MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
// 2026-10-19 (as in production, per Leo): the season is set as a **Seasonal Hold** — a preset of on / off months that
// also sets the contract term — plus the month the hold starts; the hold's end month is auto-populated.
const SEASONAL_HOLDS = [
  { key: '9-3', on: 9, off: 3, term: 48, label: '9 On / 3 Off (48 Mo)' },
  { key: '8-4', on: 8, off: 4, term: 60, label: '8 On / 4 Off (60 Mo)' },
  { key: '7-5', on: 7, off: 5, term: 60, label: '7 On / 5 Off (60 Mo)' },
  { key: '6-6', on: 6, off: 6, term: 60, label: '6 On / 6 Off (60 Mo)' },
];
// 2026-10-19 (per Catalina / Leo): the option's contract term decides which holds exist — 48 months: 9 On / 3 Off;
// 60 months: 8/4, 7/5, 6/6. Any other term has no seasonal (the accordion doesn't show).
function getSeasonalHoldsForTerm(term) { return SEASONAL_HOLDS.filter(h => h.term === Number(term)); }
function getSeasonalHold(key) { return SEASONAL_HOLDS.find(h => h.key === key) || null; }
// Hold (off) months from its start; the ON months are the rest of the year.
function getSeasonalHoldMonths(key, start) {
  const hold = getSeasonalHold(key);
  if (!hold || start == null || start === '') return [];
  return Array.from({ length: hold.off }, (_, i) => (Number(start) + i) % 12);
}
function getSeasonalOnMonths(key, start) {
  const off = getSeasonalHoldMonths(key, start);
  return off.length ? [...Array(12).keys()].map(i => (Number(start) + off.length + i) % 12).filter(m => !off.includes(m)) : [];
}
// 2026-10-20 (per Catalina): seasonal is built for **new accounts (Initial Sales)**; Existing Business is on standby
// (business questions open) and Pilot is out of scope — there, nothing seasonal shows.
const SEASONAL_EXISTING_BUSINESS = false;
function isSeasonalAvailable() {
  if (!seasonalSim) return false;
  if (typeof accountType !== 'undefined' && accountType === 'pilot') return false;
  const isExisting = (window.VC && VC.scenario && VC.scenario.existing) || (typeof isExistingMsaAccount === 'function' && isExistingMsaAccount());
  if (isExisting) return SEASONAL_EXISTING_BUSINESS;
  return true;
}
// Accounts with seasonal billing start their options at 48 months (Leo: there's no seasonal for 36).
function getDefaultContractTerm() { return isSeasonalAvailable() ? 48 : 36; }

function isSeasonalBundle(bundle) {
  return !!(isSeasonalAvailable() && bundle && bundle.seasonal && Array.isArray(bundle.seasonal.months) && bundle.seasonal.months.length);
}
function getSeasonalFactor(bundle) {
  return isSeasonalBundle(bundle) ? 1 + SEASONAL_PREMIUM_PCT / 100 : 1;
}
// Active months as ranges: [5,6,7,8] → "Jun–Sep"; [10,11,0,1] → "Nov–Feb"; [0,2] → "Jan, Mar".
function formatSeasonalMonths(months) {
  const set = new Set((months || []).map(Number));
  if (!set.size) return '';
  if (set.size === 12) return 'All year';
  // Start each run at a month whose previous month isn't active (handles runs that wrap past December).
  const runs = [];
  for (let m = 0; m < 12; m++) {
    if (!set.has(m) || set.has((m + 11) % 12)) continue;
    let end = m;
    while (set.has((end + 1) % 12) && (end + 1) % 12 !== m) end = (end + 1) % 12;
    runs.push(m === end ? SEASON_MONTHS[m] : `${SEASON_MONTHS[m]}\u2013${SEASON_MONTHS[end]}`);
  }
  return runs.join(', ');
}
// 2026-10-19 (per Catalina): make it clear the months are the ON months — "9 on (Jan–Sep) | 3 off (Oct–Dec)".
function formatSeasonalOnOff(months) {
  const on = [...new Set((months || []).map(Number))];
  if (!on.length) return '';
  const off = [...Array(12).keys()].filter(m => !on.includes(m));
  return `${on.length} on (${formatSeasonalMonths(on)})` + (off.length ? ` | ${off.length} off (${formatSeasonalMonths(off)})` : '');
}
// Same, as HTML: the month ranges in bold, the counts in regular — "9 on <b>(Jan–Sep)</b> | 3 off <b>(Oct–Dec)</b>".
function formatSeasonalOnOffHtml(months) {
  const on = [...new Set((months || []).map(Number))];
  if (!on.length) return '';
  const off = [...Array(12).keys()].filter(m => !on.includes(m));
  return `${on.length} on <strong>(${formatSeasonalMonths(on)})</strong>` + (off.length ? ` | ${off.length} off <strong>(${formatSeasonalMonths(off)})</strong>` : '');
}
// The seasonal line used wherever a solution is listed (option cards, selection, summaries), right under its name.
function getSeasonalSubtitleHtml(bundle) {
  return isSeasonalBundle(bundle) ? `<div class="bundle-row-subtitle"><strong>Seasonal</strong> | ${formatSeasonalOnOffHtml(bundle.seasonal.months)}</div>` : '';
}
// "9 On / 3 Off" — the preset name, used where the price matters (it depends on the length, not the months).
function getSeasonalHoldName(bundle) {
  const hold = bundle && bundle.seasonal ? getSeasonalHold(bundle.seasonal.hold) : null;
  if (hold) return `${hold.on} On / ${hold.off} Off`;
  const on = bundle && bundle.seasonal ? (bundle.seasonal.months || []).length : 0;
  return on ? `${on} On / ${12 - on} Off` : '';
}
function getSeasonalLabel(bundle) {
  if (!isSeasonalBundle(bundle)) return '';
  const n = bundle.seasonal.months.length;
  return `${formatSeasonalMonths(bundle.seasonal.months)} (${n} month${n === 1 ? '' : 's'})`;
}

function resolveVideoCoreKey(bundle) {
  const coreKey = bundle?.coreKey;
  if (coreKey === 'vtu-ffc' || coreKey === 'vtu-dual') return coreKey;
  const name = String(bundle?.coreName || bundle?.name || '').toLowerCase();
  if (name.includes('dual') && name.includes('camera')) return 'vtu-dual';
  if (name.includes('forward facing') && name.includes('camera')) return 'vtu-ffc';
  return coreKey || '';
}

// Features (per vehicle, monthly list price)
const featurePricing = { 'driver-id': 2.00, 'privacy': 1.00, 'adas': 5.00, 'evc': 15.00, 'logbook': 3.00, 'sd-256': 5.00, 'monitor': 12.00, 'dvir': 3.00, 'rsa': 4.00, 'dms': 8.00, 'navigation': 5.00, 'pto': 4.00, 'fuel-card': 2.00 };

// Placeholder add-on volume discounts, aligned with the existing MSA quantity tiers.
const FEATURE_VOLUME_TIERS = [
  { min: 1, max: 9, discountPct: 0 },
  { min: 10, max: 19, discountPct: 5 },
  { min: 20, max: 49, discountPct: 10 },
  { min: 50, max: 99, discountPct: 15 },
  { min: 100, max: Infinity, discountPct: 20 },
];

function getFeatureUnitPrice(featureKey, quantity = 1) {
  const basePrice = Number(featurePricing[featureKey]) || 0;
  const units = Math.max(1, Math.floor(Number(quantity) || 1));
  const tier = FEATURE_VOLUME_TIERS.find(row => units >= row.min && units <= row.max) || FEATURE_VOLUME_TIERS.at(-1);
  return Math.round((basePrice * (1 - tier.discountPct / 100) + Number.EPSILON) * 100) / 100;
}

// Bundle mode: niche features a rep can add on top of a bundle (EXAMPLE list — open question).
const BUNDLE_EXTRA_FEATURES = ['navigation', 'pto', 'driver-id'];

const featureLabels = {
  'sd-256': '256 GB SD Card',
  'adas': 'ADAS',
  'evc': 'Extended View Cameras',
  'monitor': 'In-Cab Monitor',
  'driver-id': 'Driver ID',
  'privacy': 'Privacy Button',
  'logbook': 'Logbook',
  'dvir': 'DVIR',
  'rsa': 'Roadside Assistance',
  'dms': 'Driver Monitoring System',
  'navigation': 'Navigation',
  'pto': 'PTO Monitoring',
  'fuel-card': 'Fuel Card Integration'
};

// Account-level features, switchable for a whole option (EXAMPLE list: RSA per Leo; DVIR, Fuel Card as samples).
const ACCOUNT_FEATURES = ['rsa', 'dvir', 'fuel-card'];

// Bundles / plans: same core + features a rep could pick a la carte, pre-packaged (no bundle-level discount).
const PREBUILT_BUNDLES = {
  'complete-safety': {
    name: 'Safety',
    category: 'Safety',
    tiers: [
      { key: 'vtu', coreKey: 'vtu', label: 'Essential', includedFeatures: ['dvir', 'rsa'], sdSize: null },
      { key: 'vtu-ffc', coreKey: 'vtu-ffc', label: 'Advanced', includedFeatures: ['dvir', 'rsa', 'adas'], sdSize: 128 },
      { key: 'vtu-dual', coreKey: 'vtu-dual', label: 'Premium', includedFeatures: ['dvir', 'rsa', 'adas', 'dms'], sdSize: 256 }
    ]
  },
  'productivity-suite': {
    name: 'Productivity',
    category: 'Productivity',
    tiers: [
      { key: 'standard', coreKey: 'vtu', label: 'Standard', includedFeatures: ['driver-id'], sdSize: null },
      { key: 'plus', coreKey: 'vtu', label: 'Plus', includedFeatures: ['driver-id', 'logbook'], sdSize: null },
      { key: 'max', coreKey: 'vtu', label: 'Max', includedFeatures: ['driver-id', 'logbook', 'privacy'], sdSize: null }
    ]
  }
};

// Real subscription-catalog names shown in summaries (per Catalina, 2026-09-24).
const REAL_SUBSCRIPTION_NAMES = {
  'Vehicle Tracking Subscription': 'Vehicle Tracking',
  'Powered Asset': 'Powered Asset Tracker',
  'Non-Powered Asset': 'Non-Powered Asset Tracker',
  'Extended View Cameras': 'EVC',
  '256 GB SD Card': 'SD Card',
};
