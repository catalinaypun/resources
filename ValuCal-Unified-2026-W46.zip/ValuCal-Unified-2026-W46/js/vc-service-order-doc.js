/* Order Form (2026-10-27, per Catalina; titled "Order Form" since 2026-11-10) — what the customer signs in DocuSign at
   the Contract step. Visual language = the proposal PDF (vc-doc-shell page, red #ee001e titles, black title bars, zebra
   tables). Structure (2026-11-10 ACT-554 sync and 2026-11-11 T&Cs and SOFs Deep Dive — legal): "Initial Order Form"
   (Initial Sales) / "Order Form" (existing business); Subscription Fees (one line per subscription, List price /
   Contract price, each promotion as a row under its subscription), One-time Fees, the summary and the promo language;
   customer signature only.
   VC.serviceOrderDoc(data)            -> HTML (one or more .vc-doc-shell pages)
   VC.serviceOrderDemoData(scenario)   -> sample data for the design page / simulation
   Design page: ValuCal-MSA/componentization/service-order-doc.html. Brief: componentization/briefs/36-service-order-document.md */
(function () {
  window.VC = window.VC || {};

  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const money = n => {
    const v = Math.round((Number(n) || 0) * 100) / 100;
    const s = Math.abs(v).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    return (v < 0 ? '-$' : '$') + s;
  };
  const LOGO = () => {
    const base = (typeof VC_IMG !== 'undefined' && VC_IMG) ? VC_IMG : '../../assets-shared/img/';
    return '<img class="vc-sodoc__logo" src="' + base + 'logo.svg" alt="Verizon Connect">';
  };
  const DISCLAIMER = 'This Order is governed by the Master Service Agreement referenced above. Prices exclude taxes, '
    + 'which are calculated on each invoice. Verizon confidential and proprietary.';

  /* ---------- sample data ---------- */
  const CATALOG = {
    essential: { name: 'Essential Safety Bundle', subs: [{ name: 'Vehicle Tracking (VTU)', price: 30 }, { name: 'Dash Cam', price: 15 }] },
    pro: { name: 'Pro Safety Bundle', subs: [{ name: 'Vehicle Tracking (VTU)', price: 30 }, { name: 'AI Dual Cam', price: 22 }, { name: 'Driver ID', price: 10 }] }
  };

  VC.serviceOrderDemoData = function (sc) {
    sc = Object.assign({ bundles: true, alacarte: false, msaDiscount: true, itemized: false, promo: false, schedule: false, oneTime: false, existing: false }, sc || {});
    const discountPct = sc.msaDiscount ? 10 : 0; // simulation: MSA discount on / off (2026-10-27)
    const promo = sc.promo ? { pct: 5, months: 6, name: 'LevelUp 5%', text: 'LevelUp promotion: 5% off the monthly subscription for the first 6 months of each unit\u2019s service, starting on its billing start date. After month 6 the contracted price applies. Removing units during the promotion ends the promotion for those units.' } : null;
    const qty = { essential: 30, pro: 20 };
    // Subscriptions: bundles, a la carte, or both in the same order (2026-10-27, per Catalina).
    if (!sc.bundles && !sc.alacarte) sc.bundles = true;
    let lines = [];
    if (sc.bundles) {
      lines = Object.keys(qty).map(k => ({
        kind: 'bundle', name: CATALOG[k].name, qty: qty[k],
        price: CATALOG[k].subs.reduce((s, x) => s + x.price, 0),
        subs: sc.itemized ? CATALOG[k].subs.slice() : []
      }));
    }
    if (sc.alacarte) {
      lines = lines.concat(sc.bundles
        ? [
          // Only subscriptions that stand on their own (a feature like Driver ID always needs a VTU — 2026-10-27).
          { kind: 'sub', name: 'Vehicle Tracking (VTU)', qty: 10, price: 30, subs: [] },
          { kind: 'sub', name: 'Powered Asset Tracker', qty: 10, price: 18, subs: [] }
        ]
        : [
          // The promotion applies to some subscriptions only (VTU and Dash Cam) — 2026-10-27, per Catalina.
          { kind: 'sub', name: 'Vehicle Tracking (VTU)', qty: 50, price: 30, subs: [], promoPct: sc.promo ? undefined : 0 },
          { kind: 'sub', name: 'Dash Cam', qty: 30, price: 15, subs: [], promoPct: sc.promo ? undefined : 0 },
          { kind: 'sub', name: 'AI Dual Cam', qty: 20, price: 22, subs: [], promoPct: 0 },
          { kind: 'sub', name: 'Driver ID', qty: 20, price: 10, subs: [], promoPct: 0 }
        ]);
    }
    const units = (sc.bundles ? qty.essential + qty.pro : 50) + (sc.bundles && sc.alacarte ? 10 : 0);
    const split = (first) => {
      const o = {};
      lines.forEach(l => { o[l.name] = first ? Math.ceil(l.qty * 0.6) : l.qty - Math.ceil(l.qty * 0.6); });
      return o;
    };
    return {
      orderNumber: '5003808673',
      orderDate: '10/27/2026',
      rep: 'Sarah Patel',
      customer: { name: 'Acme Logistics', account: '1000212803', address: '1200 Peachtree St NE, Atlanta, GA 30309', contact: 'Laura Mendez' },
      agreement: sc.existing
        // End date = effective date + contract term + the first order's ramp-up (01/01/2026 + 36 months + 30 days).
        ? { number: 'MSA-0004127', start: '01/01/2026', end: '01/30/2029', term: '36 months', rampUp: 30, coTerm: true }
        : { number: 'MSA-0004127', start: '11/01/2026', end: '10/31/2029', term: '36 months', rampUp: 30, coTerm: false },
      discountPct, promo, lines, units,
      schedule: sc.schedule ? [
        { number: '5003808673', when: 'At signature', billingStart: '11/26/2026', qty: split(true) },
        { number: '5003809104', when: '+60 days', billingStart: '01/25/2027', qty: split(false) }
      ] : null,
      oneTime: sc.oneTime ? [
        // 2026-11-10 (ACT-554 sync, legal via Rogelio): key fobs show the included ones (3 per vehicle with Driver ID)
        // and the extra ones charged, like the waived installation.
        { name: 'Key fobs', type: 'One-time', qty: 60, price: 5, included: 50, includedLabel: 'Included with Driver ID (3 per vehicle)' },
        { name: 'On-site professional installation', type: 'One-time', qty: units, price: 99, waived: true }
      ] : []
    };
  };

  /* ---------- totals ---------- */
  // A line can carry its own discount / promo % (real options); otherwise the document's.
  const discOf = (d, l) => (l.discountPct != null ? l.discountPct : d.discountPct) || 0;
  const promoOf = (d, l) => (l.promoPct != null ? l.promoPct : (d.promo ? d.promo.pct : 0)) || 0;
  const pctText = n => (Math.round(n * 100) / 100) + '%';
  // A bundle's name without a trailing "Bundle" — the "Bundle" label above it already says it (2026-10-27, per Catalina).
  const lineName = l => l.kind === 'bundle' ? String(l.name || '').replace(/\s+bundle$/i, '') : l.name;

  function computeTotals(d) {
    const t = { list: 0, discount: 0, promo: 0, oneTimeList: 0, oneTimeWaived: 0 };
    d.lines.forEach(l => {
      const ext = l.price * l.qty;
      t.list += ext;
      t.discount -= ext * discOf(d, l) / 100;
      t.promo -= ext * (1 - discOf(d, l) / 100) * promoOf(d, l) / 100;
    });
    d.oneTime.forEach(o => {
      t.oneTimeList += o.price * o.qty;
      t.oneTimeWaived -= o.price * (o.waived ? o.qty : Math.min(o.qty, Number(o.included) || 0));
    });
    t.monthlyContracted = t.list + t.discount;
    t.monthlyPromo = t.monthlyContracted + t.promo;
    t.oneTime = t.oneTimeList + t.oneTimeWaived;
    return t;
  }

  /* ---------- pieces ---------- */

  // Column order like the proposal PDF: Qty first, then the item (2026-10-27, per Catalina): # · Qty · Item · Charge type · Unit price · Ext.
  const tr = (cls, ref, qty, item, itemCls, type, unit, ext, extCls) => '<tr class="' + cls + '"><td class="vc-sodoc__ref">' + ref + '</td>'
    + '<td class="vc-sodoc__qty">' + qty + '</td><td class="' + itemCls + '">' + item + '</td><td>' + type + '</td>'
    + '<td class="vc-sodoc__num">' + unit + '</td><td class="vc-sodoc__num' + (extCls ? ' ' + extCls : '') + '">' + ext + '</td></tr>';
  // 2026-11-10 (ACT-554 sync, legal via Rogelio): List price (per unit) and Contract price (the line's monthly total,
  // QTY × the contracted unit price — tier and discretionary discount included).
  const thead = (unitLabel, extLabel) => '<thead><tr><th class="vc-sodoc__ref">Line</th><th class="vc-sodoc__qty">QTY</th><th>Item</th><th>Charge type</th><th class="vc-sodoc__num">' + unitLabel + '</th><th class="vc-sodoc__num">' + extLabel + '</th></tr></thead>';

  // Subscription Fees (2026-11-11 T&Cs and SOFs Deep Dive — Eric, Ale, Maggie, Dahlia): each promotion is a lighter row
  // under its subscription (like the included key fobs in One-time Fees, and as the invoice will show it) — no separate
  // Promotions table. The row says the promotion and how long it applies; unit and line discount in the price columns.
  function servicesTable(d) {
    let n = 0;
    const rows = [];
    d.lines.forEach(l => {
      n += 1;
      // Itemized: what the bundle includes as a comma-separated line under its name — no prices, no sub-rows (2026-10-27).
      const includes = l.subs.length ? '<div class="vc-sodoc__includes">' + l.subs.map(x => esc(x.name)).join(', ') + '</div>' : '';
      const contractedUnit = l.price * (1 - discOf(d, l) / 100);
      rows.push(tr('vc-sodoc__row--line', n, l.qty, (l.kind === 'bundle' ? '<span class="vc-sodoc__item-sub">Bundle</span>' : '') + esc(lineName(l)) + includes, 'vc-sodoc__item', 'Recurring', money(l.price), money(contractedUnit * l.qty)));
      const pct = promoOf(d, l);
      if (pct) {
        const name = l.promoName || (d.promo && d.promo.name) || 'Promotion';
        const unit = -contractedUnit * pct / 100;
        const duration = d.promo && d.promo.months ? 'Months 1\u2013' + d.promo.months : 'Promotion period';
        rows.push(tr('vc-sodoc__row--adj is-promo', '', l.qty, '\u2013 Promo: ' + esc(name) + (/%/.test(name) ? '' : ' (' + pctText(pct) + ')'), 'vc-sodoc__adj-label', duration, money(unit), money(unit * l.qty)));
      }
    });
    return '<h3 class="vc-sodoc__section-title vc-sodoc__section-title--table">Subscription Fees</h3>'
      + '<table class="vc-sodoc__table vc-sodoc__table--fees">' + thead('List price', 'Contract price') + '<tbody>' + rows.join('') + '</tbody></table>';
  }

  // One-time Fees (2026-11-10, ACT-554 sync — legal via Rogelio): what's paid once (key fobs today; Capex hardware later).
  // Included units still show, as a negative row under the line (like the waived installation).
  function oneTimeTable(d) {
    if (!d.oneTime.length) return '';
    const rows = [];
    d.oneTime.forEach((o, i) => {
      rows.push(tr('vc-sodoc__row--line', i + 1, o.qty, esc(o.name), 'vc-sodoc__item', esc(o.type || 'One-time'), money(o.price), money(o.price * o.qty)));
      const freeQty = o.waived ? o.qty : Math.min(o.qty, Number(o.included) || 0);
      if (freeQty) rows.push(tr('vc-sodoc__row--adj is-promo', '', freeQty, '\u2013 ' + esc(o.waived ? 'Waived' : (o.includedLabel || 'Included')), 'vc-sodoc__adj-label', o.waived ? 'Waived' : 'Included', money(-o.price), money(-o.price * freeQty)));
    });
    return '<h3 class="vc-sodoc__section-title vc-sodoc__section-title--table">One-time Fees</h3><table class="vc-sodoc__table vc-sodoc__table--fees">' + thead('List price', 'Contract price') + '<tbody>' + rows.join('') + '</tbody></table>';
  }

  function totalsBlock(d, t) {
    const r = (label, value, cls) => '<div class="vc-sodoc__total ' + (cls || '') + '"><span>' + esc(label) + '</span><span>' + value + '</span></div>';
    let html = '<div class="vc-sodoc__totals">';
    html += r('Monthly subtotal at list', money(t.list));
    const pcts = Array.from(new Set(d.lines.map(l => discOf(d, l))));
    if (t.discount) html += r('MSA discount' + (pcts.length === 1 ? ' (' + pctText(pcts[0]) + ')' : ''), money(t.discount), 'is-discount');
    // 2026-11-11 (ACT-554 sync 11-10, per Catalina and Rogelio): one Monthly total, with the promotions applied — no
    // totals per promotion period (the Promotions table's "Applies" says how long each one lasts).
    if (t.promo) html += r('Promotions', money(t.promo), 'is-promo');
    html += r('Monthly total', money(t.monthlyPromo), 'is-strong');
    // 2026-11-10 (ACT-554 sync, legal via Rogelio): after the monthly total, one line with what's paid once, then the
    // first month total. No month-by-month totals for promotions of different lengths (kept simple).
    if (d.oneTime.length) html += r('One-time fee', money(t.oneTime));
    html += r('First month total', money(t.monthlyPromo + t.oneTime), 'is-grand');
    html += '<div class="vc-sodoc__tax-note">Taxes are calculated on each invoice.</div></div>';
    return html;
  }

  function scheduleBlock(d) {
    if (!d.schedule) return '';
    const items = d.lines.map(l => l.name);
    const itemLabel = Object.fromEntries(d.lines.map(l => [l.name, lineName(l)]));
    const head = '<tr><th>Order</th><th>Starts</th><th>Billing start</th>' + items.map(i => '<th class="vc-sodoc__num">' + esc(itemLabel[i]) + '</th>').join('') + '</tr>';
    const rows = d.schedule.map(o => '<tr class="vc-sodoc__row--plain"><td>' + esc(o.number) + '</td><td>' + esc(o.when) + '</td><td>' + esc(o.billingStart) + '</td>'
      + items.map(i => '<td class="vc-sodoc__num">' + (o.qty[i] != null ? o.qty[i] : '--') + '</td>').join('') + '</tr>').join('');
    const totals = '<tr class="vc-sodoc__row--total"><td>Total committed</td><td></td><td></td>' + d.lines.map(l => '<td class="vc-sodoc__num">' + l.qty + '</td>').join('') + '</tr>';
    return '<h3 class="vc-sodoc__section-title">Order schedule</h3><p class="vc-sodoc__note vc-sodoc__note--table">Units enter fulfillment in the orders below. Each order\u2019s units start billing after the ' + d.agreement.rampUp + '-day ramp-up period.</p>'
      + '<table class="vc-sodoc__table"><thead>' + head + '</thead><tbody>' + rows + totals + '</tbody></table>';
  }

  // 2026-11-05 (MSA T&Cs and SOFs Deep Dive): no hard-coded start date on a new MSA — the Contract Effective Date is the
  // day the order becomes Sales Confirmed (unknown when it's sent); the customer sees it in the Customer Portal, and
  // the subscriptions start that day — explained in the Terms (per Catalina), the MSA box only says "When Sales
  // Confirmed". Existing accounts co-term with an MSA whose dates are already set.
  // 2026-11-11 (T&Cs and SOFs Deep Dive, Ale): customers know the portal as "Reveal"; the dates show in its
  // "Subscriptions and contracts" section.
  const PORTAL_LINK = '<a class="vc-sodoc__link" href="#" onclick="return false;">Reveal</a>';
  const EFFECTIVE_DATE_TEXT = 'Your Contract Effective Date is the date this order is Sales Confirmed. Log in to '
    + PORTAL_LINK + ' (Subscriptions and contracts) to see it once the order is confirmed; your subscriptions start on that date.';

  // Promo language (2026-11-10, ACT-554 sync — legal via Rogelio): the legal terms of each applied promotion, set up
  // with the promotion in Salesforce and pulled into the PDF when it applies; a plain box after the tables, no title
  // (as in today's contracts). The text here is representative.
  function promoLanguage(d) {
    const names = [];
    d.lines.forEach(l => { if (promoOf(d, l)) { const n = l.promoName || (d.promo && d.promo.name) || 'Promotion'; if (!names.includes(n)) names.push(n); } });
    if (!names.length) return '';
    // Representative text, modeled on today's contracts (sample shared by Rogelio, 11-11): one long legal paragraph.
    const textOf = n => n + ': this promotion is available to select new and existing Reveal business customers in the US '
      + 'only, excluding Reveal Starter customers, Group Purchasing Organization customers (GPOs), seasonal contracts, '
      + 'month-to-month contracts, federal, state and local government entities, the healthcare sector and migrations. '
      + 'Customers who subscribe to the qualifying subscriptions shown with this promotion in the Subscription Fees qualify '
      + 'for the discount shown on the monthly rate, for the units and the period shown. The promotional discount starts on the Subscription '
      + 'Start Date and never extends past the term of the Master Service Agreement; after the promotional period, the '
      + 'contract price applies. If subscriptions are activated after the first Verizon Connect billing cycle, the customer '
      + 'only receives the remaining promotional value. Minimum purchase required. Promo credits end if eligibility '
      + 'requirements are no longer met or the qualifying subscriptions are cancelled. Verizon Connect reserves the right '
      + 'to charge the amount of the credit to the customer\u2019s account upon cancellation of any qualifying service during '
      + 'the credit period. May not be combined with any other offers or promotions; must be purchased from a Verizon '
      + 'Connect representative, subject to credit review; deposit may be required; excludes rewrites. Early cancellation '
      + 'or termination fees and other taxes, fees and terms may apply. In the event of a conflict between the terms of '
      + 'this promotion and the terms in the customer contract, including minimum purchase obligations, the terms in the '
      + 'customer contract govern. Limited availability.';
    return '<div class="vc-sodoc__promo-terms">' + names.map(n => '<p>' + esc(textOf(n)) + '</p>').join('') + '</div>';
  }

  function termsBlock(d) {
    let html = '<h3 class="vc-sodoc__section-title">Terms</h3><ul class="vc-sodoc__terms">'
      + '<li>This Order is part of Master Service Agreement ' + esc(d.agreement.number) + ' and is governed by its terms.</li>'
      + (d.agreement.coTerm
        ? '<li>Services on this order co-term with the MSA and end on ' + esc(d.agreement.end) + '.</li>'
        : '<li>Contract term: ' + esc(d.agreement.term) + ' from the Contract Effective Date.</li><li>' + EFFECTIVE_DATE_TEXT + '</li>')
      + '<li>Billing for each unit starts after a ' + d.agreement.rampUp + '-day ramp-up period.</li>'
      + '<li>Prices are monthly per unit and exclude taxes.</li></ul>';
    return html;
  }

  function signatureBlock(signed) {
    if (signed) {
      const done = (title, s) => '<section class="vc-sodoc__block vc-sodoc__sign"><div class="vc-sodoc__block-title">' + title + '</div><div class="vc-sodoc__sign-grid">'
        + '<div class="vc-sodoc__sign-field vc-sodoc__sign-field--wide"><span class="vc-sodoc__signed">' + esc(s.name) + '</span><label>Signature</label></div>'
        + '<div class="vc-sodoc__sign-field"><span class="vc-sodoc__sign-value">' + esc(s.name) + '</span><label>Name</label></div>'
        + '<div class="vc-sodoc__sign-field"><span class="vc-sodoc__sign-value">' + esc(s.title || '--') + '</span><label>Title</label></div>'
        + '<div class="vc-sodoc__sign-field"><span class="vc-sodoc__sign-value">' + esc(s.date) + '</span><label>Date</label></div>'
        + (s.po !== undefined ? '<div class="vc-sodoc__sign-field"><span class="vc-sodoc__sign-value">' + esc(s.po || '--') + '</span><label>PO number</label></div>' : '<div></div>')
        + '</div></section>';
      return '<div class="vc-sodoc__signatures">' + done('Customer', signed.customer) + '</div>';
    }
    // DocuSign: tabs are placed on the anchors (white text in the real PDF), never on moving content.
    const party = (title, n, withPo) => '<section class="vc-sodoc__block vc-sodoc__sign"><div class="vc-sodoc__block-title">' + title + '</div>'
      + '<div class="vc-sodoc__sign-grid">'
      + '<div class="vc-sodoc__sign-field vc-sodoc__sign-field--wide"><span class="vc-sodoc__tab vc-sodoc__tab--sign">Sign here</span><span class="vc-sodoc__anchor">\\s' + n + '\\</span><label>Signature</label></div>'
      + '<div class="vc-sodoc__sign-field"><span class="vc-sodoc__tab">Full name</span><span class="vc-sodoc__anchor">\\n' + n + '\\</span><label>Name</label></div>'
      + '<div class="vc-sodoc__sign-field"><span class="vc-sodoc__tab">Title</span><span class="vc-sodoc__anchor">\\t' + n + '\\</span><label>Title</label></div>'
      + '<div class="vc-sodoc__sign-field"><span class="vc-sodoc__tab">Date signed</span><span class="vc-sodoc__anchor">\\d' + n + '\\</span><label>Date</label></div>'
      + (withPo ? '<div class="vc-sodoc__sign-field"><span class="vc-sodoc__tab">PO number (optional)</span><span class="vc-sodoc__anchor">\\po' + n + '\\</span><label>PO number</label></div>' : '<div></div>')
      + '</div></section>';
    // 2026-11-11 (T&Cs and SOFs Deep Dive): only the customer signs — no Verizon Connect box.
    return '<div class="vc-sodoc__signatures">' + party('Customer', 1, true) + '</div>';
  }

  function page(content, num, total, d) {
    return '<div class="doc-page-outer vc-sodoc__page-outer"><div class="vc-doc-shell vc-sodoc"><div class="vc-doc-brand-line"></div><div class="vc-doc-inner vc-sodoc__inner">'
      + (d.envelopeId ? '<div class="vc-sodoc__envelope">DocuSign Envelope ID: ' + esc(d.envelopeId) + '</div>' : '')
      + content
      + '<footer class="vc-sodoc__footer"><div>' + esc(DISCLAIMER) + '</div><div class="vc-sodoc__footer-meta">Order ' + esc(d.orderNumber) + ' \u00b7 Page ' + num + ' of ' + total + '</div></footer>'
      + '</div></div></div>';
  }

  VC.serviceOrderDoc = function (d) {
    d = Object.assign({ oneTime: [], schedule: null, promo: null }, d);
    const t = computeTotals(d);
    const header = '<header class="vc-sodoc__header"><div><div class="vc-sodoc__title">' + (d.agreement.coTerm ? 'Order Form' : 'Initial Order Form') + '</div><div class="vc-sodoc__subtitle">' + esc(d.orderDate) + ' <b>|</b> <b>No.</b> ' + esc(d.orderNumber) + '</div></div>' + LOGO() + '</header>'; // no gray rule under the main header (2026-10-27, per Catalina) — the beige band follows
    // Customer: the proposal's beige band (Prepared by / Prepared for); MSA: the proposal's black-bar box (2026-10-27).
    const band = (cols) => '<div class="vc-sodoc__band">' + cols.map(c => '<div><div class="vc-sodoc__band-label">' + esc(c[0]) + '</div>'
      + c.slice(1).map((v, i) => '<div class="' + (i ? 'vc-sodoc__band-muted' : '') + '">' + esc(v == null || v === '' ? '--' : v) + '</div>').join('') + '</div>').join('') + '</div>';
    const customerBand = band([
        ['Customer', d.customer.name, d.customer.address],
        ['Account number', d.customer.account],
        ['Contact', d.customer.contact],
        ['Prepared by', d.rep]
      ]);
    // Every page repeats the main header and the customer band (2026-10-27, per Catalina); the MSA box only on page 1.
    const pageTop = header + customerBand;
    // 2026-11-11 (T&Cs and SOFs Deep Dive): "Contract term"; the Ramp-up period is per order, not an MSA field;
    // existing business shows only the MSA's End date (its start date is in the past). 2026-11-12 (per Catalina): one box
    // split in half — Master Service Agreement | Order — each with its black title bar and the fields below.
    const field = f => '<div class="vc-sodoc__field"><dt>' + esc(f[0]) + '</dt><dd>' + esc(f[1] == null || f[1] === '' ? '--' : f[1]) + '</dd></div>';
    const half = (title, fields) => '<div class="vc-sodoc__split-half"><div class="vc-sodoc__block-title">' + esc(title) + '</div><dl class="vc-sodoc__fields">' + fields.map(field).join('') + '</dl></div>';
    const msaFields = [['MSA number', d.agreement.number], ['Contract term', d.agreement.term]].concat(d.agreement.coTerm ? [['End date', d.agreement.end]] : []);
    const blocks = '<section class="vc-sodoc__block vc-sodoc__block--split">' + half('Master Service Agreement', msaFields)
      + half('Order', [['Order number', d.orderNumber], ['Ramp-up period', d.agreement.rampUp + ' days']]) + '</section>';
    const page1 = pageTop + blocks
      // Tables (2026-11-11, T&Cs and SOFs Deep Dive): Subscription Fees (promotions as rows under each subscription) and
      // One-time Fees; then the summary and the promo language.
      + servicesTable(d) + oneTimeTable(d) + totalsBlock(d, t) + promoLanguage(d);
    const page2 = pageTop
      + scheduleBlock(d) + termsBlock(d)
      + '<h3 class="vc-sodoc__section-title">Signatures</h3><p class="vc-sodoc__note">By signing, the customer orders the services above under the referenced Master Service Agreement.</p>'
      + signatureBlock(d.signed);
    return page(page1, 1, 2, d) + page(page2, 2, 2, d);
  };
})();
