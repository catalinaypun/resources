# Requerimientos — Llamada con Rogelio Fuentes
**Fecha:** 6 de agosto de 2026

---

## ⚠️ Corrección importante (post-llamada)

Rogelio le dio a Catalina información equivocada durante la llamada respecto a la fecha base para el rescheduling (ver sección Reschedule > Opción A). La corrección:

- **No** son dos días después del **appointment**.
- **Sí** son dos días después del **current date** (hoy).
- El flujo de **"Check other vendors"** se va a revisar con el equipo para ver si se puede mejorar (Rogelio y Catalina coinciden en que la solución actual no les convence del todo).
- **Acción:** Catalina **no debe trabajar ese flujo todavía** — queda en pausa hasta que se revise.

---

## Jobs (listado) — Épica C-117

Incluye: listado, búsqueda, sorting, indicadores de status (colores).

- **Columna "Last Updated":** falta trabajo de backend + el hipervínculo.
- **Hipervínculos (dos variantes según status del job):**
  - Job en estado **Open** → redirige a **Manual Schedule**.
  - Cualquier otro status → redirige a **Job Details**.

---

## Job Details

Toda la parte informativa del sitio. Ya cubierto en su mayoría:

- Header + Status Summary (ya trabajado por Catalina).
- Information cards: Installation Address, Installation Date, Site Contact, Site Notes.
- Scope actual: Vehicles/Assets.
- Summary + Additional Charges: en alcance de C-117.
- **Cancellation:** confirmado, también es parte de C-117.

### Escenario 4 (nuevo) — Vehicle Details: suscripciones que NO son parte del job

Cuando se expande un vehículo, se muestra la lista de suscripciones/hardware que **sí** son parte del job. Si el vehículo tiene suscripciones que **no** son parte del job:

- Esas suscripciones se muestran en una sección aparte, **a continuación de la última suscripción que sí es parte del job**.
- Se muestra la misma información, pero **"greyed out"** (grisada/atenuada).
- Esta es la propuesta que Catalina ya había hecho (la franja indicando "not in this job") a raíz de una observación de Flora sobre que no era evidente que una suscripción no aplicaba al job.

**⚠️ Pendiente:** Esto **no se ha refinado con el equipo todavía** — es una conversación que Catalina tuvo solo con Rogelio, no se ha validado formalmente. Rogelio tomó nota para refinarlo con el equipo al día siguiente de la llamada.

---

## Cancellation

Rogelio considera que el flujo de cancelación **ya está prácticamente listo** — no hay temas pendientes de diseño relevantes, solo ajustes menores.

- **Reason dropdown "Late Cancellation":** a Catalina le parece raro tener esta razón dentro del dropdown de motivos, ya que "late cancellation" es un escenario en sí mismo, no un "motivo". Rogelio le va a preguntar a **Soltan**. **Por ahora se deja como está** hasta nueva indicación.
- **Motivos de cancelación (dropdown):** son los mismos para ambos flujos (antes de 24h y después de 24h) — confirmado por Rogelio.
- **No-Show Vendor:** es la única razón que dispara el mismo flujo de arriba (late cancellation). Catalina puede usar esa razón como ejemplo ya que las opciones son las mismas para ambos flujos.
- **Tachado de líneas al cancelar (Service Line Items):**
  - Catalina ya había planteado (y hablado con Rogelio) que tachar todo es malo para la legibilidad.
  - Propuesta de Catalina: no tachar toda la fila, solo poner el **quantity en 0** (mostrando el valor original tachado al lado). Ya existe una pantalla con esta propuesta.
  - **⚠️ Pendiente:** Hay que **validar con negocio esta propuesta primero** antes de darla por definitiva — Rogelio indicó que este ticket no se ha platicado todavía con el equipo, así que no debe darse por cerrado.
- **PO Status (nuevo, pendiente de ticket):** Habrá que desplegar un status del PO porque lo va a compartir el ERP.
  - Rogelio ya sabe cuáles serán los statuses pero **todavía no ha creado el ticket**.
  - Sigue pendiente de respuesta del equipo de ERP sobre qué status usan para representar "cancelado" (no tienen uno que diga literalmente "cancellation").
  - Si no dan un status utilizable, alternativas a considerar: tachar el número de PO, agregar un label, etc. — sin definir aún.
- **Hipervínculo del PO cuando está cancelado:** **Confirmado por Soltan** — si el PO está cancelado, se puede quitar el hipervínculo. Este cambio **sí aplica** y se puede implementar.
  - Pendiente (pregunta a Soltan, ya enviada): si después de la cancelación se debe seguir permitiendo consultar el PDF del PO.

---

## Reschedule

Tres opciones/escenarios:

### A) Reschedule manteniendo el mismo vendor (appointment creado vía API)

- Se jala disponibilidad del mismo vendor (como está actualmente).
- **Fecha base para la disponibilidad:** ~~dos días después del appointment~~ → **corrección: dos días después del current date** (ver corrección al inicio de este documento).
  - Ejemplo original (con el dato incorrecto) usado en la llamada: si el appointment es el 8 de junio, se seleccionaba el 10. **Este ejemplo ya no aplica** tal cual — hay que confirmar el ejemplo correcto una vez se tenga la fecha base bien definida.
  - Catalina cuestionó que esto genera confusión (se preselecciona una fecha distinta a la que el usuario había elegido). Kevin también había manifestado desacuerdo con esto en su momento, pero Flora/Soltan decidieron que se necesita una fecha para poder llamar la API de disponibilidad. Rogelio tenía el ticket con la fecha seleccionada por el usuario como base, pero le pidieron cambiarlo (no recuerda la razón exacta).
- **Si el reschedule es exitoso** (confirmado tanto por VPM como por ERP): se muestra mensaje de éxito (arriba, formato estándar) y se actualiza la fecha/hora nueva en pantalla.
- **Si falla** (error de API, ej. "la API no está respondiendo"):
  - Se muestra un mensaje de error.
  - El usuario tiene dos opciones: **reintentar** o **ir a Manual Reschedule** (botón "Go to manual reschedule" — posición exacta aún sin definir por Rogelio).
  - Los slots/disponibilidad siguen visibles e interactivos aunque haya fallado la API — el usuario puede seguir cambiando de slot.

### B) Check / Schedule con otro vendor — ⏸️ EN PAUSA, no implementar todavía

- Botón "Check with another vendor" / "Schedule with another vendor".
- Al hacer clic, sale una alerta: *"Para agendar con un nuevo install partner se necesita cancelar [el actual], y esto puede hacer que pierdas el tiempo reservado."* El usuario debe confirmar.
- Si confirma: se cancela el appointment actual y se redirige a **Schedule Mode** (normal, no manual).
- **Problemas señalados (sin resolver):**
  - La acción es irreversible una vez confirmada.
  - Ni Rogelio ni Catalina están conformes con esta solución. Rogelio ya lo escaló con Soltan y Kevin; Kevin no estaba de acuerdo, Soltan dijo que lo revisaría con Kevin. Decisión no está cerrada.
  - Aunque el sistema evita mostrar el mismo vendor ya seleccionado (por detrás), esto no resuelve el caso real: agentes a veces quieren otro vendor por mala experiencia con uno específico, no solo para evitar repetir selección — el flujo actual no cubre ese caso.
- **Acción para Catalina: no trabajar este flujo todavía**, se va a revisar con el equipo para ver si se puede mejorar.

### C) Convertir a Manual Reschedule

- Mismo comportamiento de alerta/confirmación que la opción B (cancela y redirige), pero en este caso redirige a **Manual Schedule → pantalla de Time Selection**.
- En Manual, el vendor **no debe venir preseleccionado** — debe quedar vacío por default (a diferencia de A, donde si se puede seleccionar vendor).

### D) Cambiar dirección de instalación

- Se mantiene igual al flujo actual (definido en llamada del día anterior). El reto principal está en el backend, no en el UI.
- No es urgente para hoy — probablemente trabajo de la próxima semana.
- Incluye también: **Site Contact** y **Site Notes**.

---

## Resumen de próximos pasos para Catalina

1. Empezar a trabajar en **Reschedule** (excepto la opción B "Check other vendors", que queda en pausa).
2. Rogelio enviará los tickets actualizados con las reglas de cada flujo — revisar en cuanto lleguen.
3. Pendiente de Rogelio: refinar con el equipo el escenario 4 (suscripciones fuera del job) y la propuesta de tachado de quantity en cancelación — ambos necesitan validación de negocio antes de darse por definitivos.
