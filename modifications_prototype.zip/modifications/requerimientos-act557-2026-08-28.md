# Requerimientos — ACT 557, Requirements Gathering
**Fecha de la llamada:** 28 de agosto de 2026
**Asistentes:** Rogelio Fuentes, Flora Zhou, Kevin Kett, Zoltan Vidakovics, Anna Deeds, Pamela Sullivan, Catalina Arango, Abhay Baheti, Surabhi Sharma (parcial)

---

## ⚠️ Decisión clave — se descarta el modal para Reschedule

Después de la discusión de LOE, el equipo **decidió NO usar el modal** para el flujo de reschedule y en su lugar **reutilizar la pantalla completa de scheduling** (la misma que se usa para crear una cita nueva).

- **Razón:** LOE. Flora estimó el modal en **~2 sprints** (posiblemente incluyendo QA) vs. **~1 semana** para adaptar la pantalla existente.
- Anna (negocio) tomó la decisión final: el modal es un "must-have" en experiencia pero se clasifica como *nice to have* para esta entrega — **se prioriza velocidad de entrega**. Kevin y Zoltan estuvieron de acuerdo con avanzar así por ahora.
- **El modal queda en el backlog** como mejora futura, no descartado permanentemente.
- Catalina (UX) y Kevin (negocio) preferían el modal por experiencia, pero aceptaron la decisión de negocio dado el trade-off de tiempo.

**Nota para Catalina:** esto invalida, para esta entrega, el documento "Reschedule: Modal vs. Wizard Page" armado para la reunión anterior — esa discusión ya se resolvió en esta llamada a favor de la página completa. El documento puede servir como sustento si se retoma el modal en el futuro (queda en backlog).

---

## Flujo A — Reschedule con el mismo vendor (API / VPM)

1. Usuario da clic en "Reschedule" desde el job.
2. Sistema llama a VPM para revisar disponibilidad del **mismo vendor**, usando el **mismo job ID** (no se crea un job nuevo en este caso).
3. **Si es exitoso** (VPM + ERP confirman): se actualiza el job con la nueva fecha/hora, mismo job ID.
4. **Si falla ERP:** se hace rollback del cambio (ya acordado en sesión previa).
5. Si no hay slots disponibles con el vendor actual, el usuario elige entre dos caminos:
   - Ir a **Manual Reschedule**, o
   - **Buscar otros vendors** (ver Flujo B).
   - ⚠️ Pendiente de diseño: el popup/decisión para elegir entre estas dos opciones no quedó definido en esta llamada.

---

## Flujo B — Reschedule con otro vendor (antes en pausa, ahora se retoma)

A diferencia de la nota del 6 de agosto (donde este flujo quedaba pausado), en esta llamada **se trabajó el flujo completo y se acordó cómo construirlo**.

- Botón para buscar otros vendors (wording por definir — debe ser genérico, ej. "installation companies" en vez de "vendors", porque el mismo componente se reutiliza en scheduling normal).
- Al hacer clic, se muestra un **mensaje de advertencia** avisando que se buscará con un vendor distinto y que se podría perder el slot reservado actualmente. Wording exacto pendiente de definir (Flora, Kevin, Zoltan).
- Al confirmar:
  - Se crea un **job nuevo** (nuevo job ID) **sin cancelar el job original todavía**, para poder consultar disponibilidad de todos los vendors.
  - El job original permanece intacto y reservado mientras tanto.
  - Este job nuevo queda "open" y **no aparece en el listado de jobs** hasta que se confirme una cita (igual que el comportamiento actual del sistema al buscar disponibilidad).
- **Si el usuario cancela** en esta pantalla: el job nuevo queda abierto/huérfano (no se cancela explícitamente, simplemente no se usa) y el usuario regresa a la **página de Job Details del job original**, sin cambios.
- **Si el usuario confirma una cita con el nuevo vendor:** en ese momento se cancela el job original (mismo mecanismo: llamada a VPM para cancelar con el job ID original) y el job nuevo queda como el job activo/agendado.

### Diseño de la pantalla de disponibilidad (reutilizable)

- La pantalla de scheduling tendrá **dos secciones de slots**: una para el "vendor preferido" (arriba) y otra para "otros vendors" (abajo).
- En un flujo de creación normal (sin vendor preferido), la sección superior **no se muestra** (queda oculta, no ocupa espacio) — se ve igual que hoy.
- En reschedule, la sección superior sí se puebla con los slots del vendor actual; si el usuario decide buscar otros vendors, la sección inferior se puebla con el resto.
- Esto permite reutilizar el mismo componente/código para scheduling normal y reschedule.
- **Job ID:** se decidió **mantenerlo visible** en pantalla (incluyendo cuando es un job nuevo creado por la búsqueda de otro vendor), a pesar de la preocupación inicial de confusión — se van a apoyar en KB/training para explicar el comportamiento en vez de ocultar el ID.

---

## Manual Reschedule

- Si el reschedule automático falla o no hay slots, una de las opciones es **ir a Manual Reschedule**.
- Se usará la **pantalla manual existente** (la actual en producción) — **no se va a construir una pantalla manual nueva** en este alcance; eso es una iniciativa aparte, sin presupuesto ni arrancada todavía.

---

## Pantalla de confirmación (landing después de un reschedule exitoso)

- **Decisión:** después de un reschedule exitoso (mismo vendor o vendor distinto), el usuario aterriza en la **pantalla de "Booking Confirmed"** (la misma que ya existe para citas nuevas) — **no** solo un banner de éxito en Job Details como se había planteado antes.
- Razón: da contexto completo de qué pasó (fecha/hora, vendor, cancelación del job anterior si aplica) y sirve como comprobante que el agente puede compartir/descargar.
- El botón de esa pantalla (antes "Close") debe **redirigir a Job Details** del job correspondiente, no al listado de jobs.
- Esto aplica de forma consistente a todos los escenarios de reschedule (mismo vendor o vendor nuevo), para no tener comportamientos distintos según el caso.

---

## Edición de Site Contact / Site Notes / Installation Address durante Reschedule

- **Se mantienen** los modales existentes de Edit Installation Address, Edit Site Contact y Edit Site Notes en Job Details — sin cambios, independientes del nuevo flujo de reschedule.
- **Adicionalmente**, Site Contact y Site Notes serán **editables directamente dentro de la pantalla de scheduling/reschedule** (se heredan del job original y se pueden modificar antes de confirmar la nueva cita). Justificación de negocio (Kevin): es un caso de uso válido y común (ej. cliente llama para cambiar el contacto de sitio) que no debería forzar al agente a pasar por un reschedule completo.
- **Instalación address NO será editable** dentro de la pantalla de reschedule — se mantiene como proceso manual/negociado aparte, solo vía el modal dedicado en Job Details. Razón: cambiar la dirección afecta cálculo de millas/distancia y costo con el vendor — es más complejo.
- **Reschedule con dirección distinta queda en backlog** como mejora futura (no en este alcance). Por ahora, reschedule solo aplica para la misma dirección.

### ⚠️ Concern de Catalina (registrado, no resuelto)

Catalina señaló que esto genera redundancia: dos formas distintas de editar site contact/site notes (el modal en Job Details y el campo directo en la pantalla de reschedule), y que "reschedule" deja de ser solo cambiar fecha/hora para volverse una edición más amplia del job. Propuso consolidar en un solo botón "Edit Job" en vez de botones separados. El equipo (Kevin, Rogelio) decidió mantener los botones separados porque los usuarios ya están acostumbrados a ese patrón — la sugerencia de Catalina queda como nota abierta, no se implementa por ahora.

---

## Contexto organizacional

- **Rogelio se está moviendo progresivamente a otro ACT** (563 — Pricing and Promotions) y va a dedicar menos tiempo a este ACT, pero sigue disponible como apoyo. **Marcio** va a tomar más protagonismo en el seguimiento de este ACT.
- Catalina va a reunirse la próxima semana con **Maria** para continuar el trabajo.
- **Próximo paso de Catalina:** construir un prototipo reflejando todo este flujo (reschedule mismo vendor, reschedule otro vendor, manual, edición de site contact/notes inline) para validar con el equipo que la experiencia completa tiene sentido antes de pasar a desarrollo.
- Se está evaluando también reprogramar el horario/formato de esta ceremonia (ACT 557) para incluir a más personas (QA, equipos offshore) — sin resolver, se retoma por fuera de la llamada.

---

## Resumen de próximos pasos para Catalina

1. Construir el prototipo del flujo completo de reschedule (mismo vendor, otro vendor, manual, edición inline de site contact/notes) reflejando lo acordado en esta llamada.
2. Validar con el equipo que el flujo tiene sentido de punta a punta antes de pasar a desarrollo.
3. Mantener registrada la propuesta de "Edit Job" unificado como mejora futura a evaluar, dado que no fue aceptada en esta llamada.
4. El modal para reschedule queda en backlog — reconsiderar si en el futuro se prioriza mejorar la experiencia de este flujo.
