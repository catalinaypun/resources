# MSA en la versión de producción (v1) — Plan de implementación

## 0. Contexto y alcance

Todo lo que se ha construido hasta ahora en `contract-stage-implementation-plan.md` es sobre `app/demos/valucal_mvp.html` — la versión **futura** de ValuCal (con Proposal, Contract, Deal Result). Sin embargo, lo que está desplegado hoy para los usuarios reales es una versión anterior, más simple, con solo 3 pasos: Drafting → Review & Send → Quote creation.

Como el MSA se volvió prioritario, hay que llevarlo también a esa versión de producción, **sin perder ninguna de las dos versiones**. Para eso:

- Se identificó `app/demos/valucal_mvp_v1.html` como la versión que coincide con producción (confirmado contigo).
- Se creó una copia exacta: **`app/demos/valucal_mvp_production.html`** (mismo contenido byte a byte que v1 al momento de la copia). **Todo el trabajo de este documento va sobre este archivo nuevo**, no sobre `valucal_mvp_v1.html` (que se conserva intacto como referencia histórica) ni sobre `valucal_mvp.html` (la versión futura, que tampoco se toca).
- Este documento es independiente de `contract-stage-implementation-plan.md` — está pensado para copiarse a Visual Studio por separado, en su propia sesión de trabajo, sin mezclar los dos.

Buenas noticias tras revisar el código de `valucal_mvp_production.html`:
- Ya tiene la misma infraestructura base que la versión futura usó como punto de partida: `proposalData`, `options`/`nextOptId`, `openDraftingRoute()`, `_termVals`, `btn-new-proposal`, e incluso el stub de "F2: MSA add-on / co-term" (`proposalData.isAddOn`/`msaId`/`msaEndDate`, la barra `#msa-context-bar`, y las funciones `renderMsaContextBar()` / `getMsaMonthsRemaining()` / `isMsaAutoExtend()` — **ya completas y ya con el diseño final correcto** (solo se activan cuando `isAddOn` es `true`, sin mostrar el ID del MSA en ningún otro caso). No hay que tocar nada de eso salvo un bug de sintaxis (punto 1).
- Lo que falta construir es exactamente lo mismo que ya se diseñó y probó en la versión futura: el modal de "MSA Setup", su enganche antes de Drafting, la persistencia de los campos, el campo de Term start date en el header, y el contador de mínimo en las cards. Como esa versión futura ya tiene todo esto funcionando y verificado en vivo, este documento copia ese mismo código ya probado — no es un diseño nuevo desde cero, es un traslado.
- Se identificó también dónde vive el "Account Setup" real que usan hoy en producción: no es un modal, es una página aparte, **`app/demos/account-setup.html`**, que se abre en pestaña nueva. No ha cambiado desde el commit inicial, así que es un archivo seguro y compartido — lo que se agregue ahí no choca con nada de la versión futura.

**Archivos que toca este documento:** `app/demos/valucal_mvp_production.html` (secciones 1-7) y `app/demos/account-setup.html` (sección 8).

---

## 1. 🔴 Bug de sintaxis heredado — corregir primero

En `valucal_mvp_production.html`, línea **8523**, hay un comentario mal escrito, igual al bug que ya se corrigió en la versión futura:

```
/ ── F2: MSA CONTEXT BAR ──────────────────────────────────────────
```

Le falta la segunda `/`. **Corregir a:**

```
// ── F2: MSA CONTEXT BAR ──────────────────────────────────────────
```

---

## 2. Extender `proposalData` con los campos de MSA Setup

En `valucal_mvp_production.html`, el objeto `proposalData` (líneas 8885-8909) ya tiene `isAddOn`, `msaId`, `msaEndDate` — no tocar esos. Agregar los 4 campos nuevos justo después de `msaEndDate: '',`:

```js
  msaEndDate: '',        // ISO date string; drives co-term calculation
  msaTermStart: '',
  msaMinimumQuantityCommitment: null,
  msaMinimumServiceTerm: null,
  msaRampUpPeriod: null,
```

---

## 3. Funciones nuevas de MSA Setup

Agregar estas funciones (por ejemplo, justo después de `closeAccountSetupModal()` / `updateAccountSetupSaveState()`, alrededor de la línea 8040 — el lugar exacto no importa mientras queden en el mismo `<script>` del archivo). Es el mismo código, ya probado, que corre hoy en la versión futura:

```js
function isMsaSetupRequired() {
  return !proposalData.msaId;
}

function getMsaSetupMissingFields() {
  const minimumQuantityCommitment = (document.getElementById('msa-minimum-quantity-commitment')?.value || '').trim();
  const minimumServiceTerm = (document.getElementById('msa-minimum-service-term')?.value || '').trim();

  const missing = [];
  if (!minimumQuantityCommitment) missing.push('minimum quantity commitment');
  if (!minimumServiceTerm) missing.push('minimum service term');
  return missing;
}

function updateMsaSetupCtaState() {
  const missing = getMsaSetupMissingFields();
  const createBtn = document.getElementById('msa-create-agreement-btn');
  const isReady = missing.length === 0;
  if (createBtn) createBtn.disabled = !isReady;
}

function handleMsaSetupInput() {
  updateMsaSetupCtaState();
}

function toggleMsaMinServiceTermDropdown(event) {
  event.stopPropagation();
  document.getElementById('msa-minimum-service-term-dropdown')?.classList.toggle('hidden');
}

function selectMsaMinServiceTerm(val) {
  const input = document.getElementById('msa-minimum-service-term');
  const btn = document.getElementById('msa-minimum-service-term-btn');
  const normalized = String(val || '').trim();
  if (input) input.value = normalized;
  if (btn) {
    btn.classList.toggle('selected', !!normalized);
    const textNode = btn.querySelector('span:first-child');
    if (textNode) textNode.textContent = normalized ? `${normalized} months` : 'Select months';
  }
  document.getElementById('msa-minimum-service-term-dropdown')?.classList.add('hidden');
  handleMsaSetupInput();
}

function closeMsaSetupModal() {
  document.getElementById('msa-setup-overlay')?.classList.remove('open');
  document.getElementById('msa-minimum-service-term-dropdown')?.classList.add('hidden');
}

function openMsaSetupRoute() {
  const overlay = document.getElementById('msa-setup-overlay');
  if (!overlay) return;

  const minQtyEl = document.getElementById('msa-minimum-quantity-commitment');
  const minServiceEl = document.getElementById('msa-minimum-service-term');
  const rampUpEl = document.getElementById('msa-ramp-up-period');

  if (minQtyEl) minQtyEl.value = proposalData.msaMinimumQuantityCommitment ?? '';
  if (minServiceEl) minServiceEl.value = proposalData.msaMinimumServiceTerm ?? '';
  if (rampUpEl) rampUpEl.value = proposalData.msaRampUpPeriod ?? 30;
  selectMsaMinServiceTerm(String(proposalData.msaMinimumServiceTerm || ''));

  overlay.classList.add('open');
  updateMsaSetupCtaState();
}

function createMsaAgreement() {
  const missing = getMsaSetupMissingFields();
  if (missing.length > 0) {
    updateMsaSetupCtaState();
    return;
  }

  const termStart = (proposalData.msaTermStart || '').trim();
  const minimumQuantityCommitment = Number(document.getElementById('msa-minimum-quantity-commitment')?.value || 0);
  const minimumServiceTerm = Number(document.getElementById('msa-minimum-service-term')?.value || 0);
  const rampUpRaw = (document.getElementById('msa-ramp-up-period')?.value || '30').trim();
  const rampUpValue = Number(rampUpRaw);

  const generatedMsaId = `MSA-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;

  proposalData.msaId = generatedMsaId;
  proposalData.msaMinimumQuantityCommitment = Number.isFinite(minimumQuantityCommitment) ? minimumQuantityCommitment : 0;
  proposalData.msaMinimumServiceTerm = Number.isFinite(minimumServiceTerm) ? minimumServiceTerm : 0;
  proposalData.msaRampUpPeriod = Number.isFinite(rampUpValue) ? rampUpValue : 30;
  proposalData.msaTermStart = termStart;
  proposalData.msaEndDate = '';
  proposalData.isAddOn = false;

  closeMsaSetupModal();
  showSuccessBanner('Agreement created', 'Minimum quantity commitment, term start date, minimum service term, and ramp-up period have been saved for this account.');
  openDraftingRoute(true, true);
  try { renderOptions(); } catch (renderError) { console.warn('renderOptions failed after MSA creation', renderError); }
}

function updateMsaHeaderTermStart(value) {
  proposalData.msaTermStart = (value || '').trim();
}

function renderMsaHeaderTermStart() {
  const wrap = document.getElementById('msa-header-term-start');
  const input = document.getElementById('msa-header-term-start-date');
  if (!wrap || !input) return;
  const shouldShow = !!proposalData.msaId;
  wrap.classList.toggle('hidden', !shouldShow);
  if (shouldShow) {
    input.value = proposalData.msaTermStart || '';
  }
}
```

**Nota:** `showSuccessBanner()` debe existir ya en `valucal_mvp_production.html` (es un mecanismo genérico de toast). Si al ejecutar no existe con ese nombre exacto, avisar antes de seguir — no inventar una versión distinta.

---

## 4. HTML — modal de MSA Setup

Insertar este bloque justo antes de `<div id="screen-drafting" class="content-area">` (línea 5463):

```html
<div class="overlay" id="msa-setup-overlay" onclick="closeMsaSetupModal()">
  <div class="account-setup-modal msa-setup-modal" role="dialog" aria-modal="true" aria-labelledby="msa-setup-title" onclick="event.stopPropagation()">
    <div class="account-setup-header">
      <h2 class="account-setup-title" id="msa-setup-title">New Master Service Agreement</h2>
      <button type="button" class="btn-modal-close account-setup-close" onclick="closeMsaSetupModal()" aria-label="Close">
        <span class="material-symbols-outlined">close</span>
      </button>
    </div>
    <p class="account-setup-sub">Some Master Service Agreement fields are required before continuing with this proposal. They'll be saved to this account's setup.</p>

    <div class="account-setup-section">
      <label class="field-label account-setup-label textarea-field__label--required" for="msa-minimum-quantity-commitment">Minimum quantity commitment</label>
      <input id="msa-minimum-quantity-commitment" class="account-setup-input msa-setup-number-input" type="number" min="0" step="1" placeholder="0" oninput="handleMsaSetupInput()">
    </div>

    <div class="account-setup-section">
      <label class="field-label account-setup-label textarea-field__label--required" for="msa-minimum-service-term">Minimum service term (months)</label>
      <input id="msa-minimum-service-term" type="hidden" value="">
      <div class="custom-select-wrap msa-setup-min-service-wrap">
        <button type="button" id="msa-minimum-service-term-btn" class="custom-select-btn" onclick="toggleMsaMinServiceTermDropdown(event)">
          <span>Select months</span>
          <span class="material-symbols-outlined">expand_more</span>
        </button>
        <div id="msa-minimum-service-term-dropdown" class="custom-dropdown hidden">
          <div class="dropdown-option" onclick="selectMsaMinServiceTerm('12')">12 months</div>
          <div class="dropdown-option" onclick="selectMsaMinServiceTerm('24')">24 months</div>
          <div class="dropdown-option" onclick="selectMsaMinServiceTerm('36')">36 months</div>
          <div class="dropdown-option" onclick="selectMsaMinServiceTerm('48')">48 months</div>
          <div class="dropdown-option" onclick="selectMsaMinServiceTerm('60')">60 months</div>
        </div>
      </div>
    </div>

    <div class="account-setup-section">
      <label class="field-label account-setup-label" for="msa-ramp-up-period">Ramp-up period (days)</label>
      <input id="msa-ramp-up-period" class="account-setup-input msa-setup-number-input" type="number" min="0" step="1" value="30" placeholder="30" oninput="handleMsaSetupInput()">
    </div>

    <div class="account-setup-actions msa-setup-actions">
      <button type="button" class="vds-btn-secondary" onclick="closeMsaSetupModal()">Cancel</button>
      <button id="msa-create-agreement-btn" type="button" class="vds-btn-primary" onclick="createMsaAgreement()" disabled>Confirm</button>
    </div>
  </div>
</div>
```

Las clases `.account-setup-modal`, `.account-setup-header`, `.account-setup-title`, `.account-setup-close`, `.account-setup-sub`, `.account-setup-section`, `.account-setup-label`, `.account-setup-input`, `.account-setup-actions`, `.custom-select-wrap`, `.custom-dropdown` **ya existen** en `valucal_mvp_production.html` (se reusan del modal chico de "Account setup incomplete" y del dropdown de Contract term). Solo hace falta el CSS nuevo del punto 6.

---

## 5. HTML — Term start date en el header de Drafting

En el mismo archivo, dentro de `.drafting-title-wrap` (líneas 5470-5473 aprox., dentro del bloque que empieza en `id="screen-drafting"` línea 5463), agregar el bloque de Term start date justo después del título:

```html
<div class="drafting-title-wrap">
  <div class="drafting-header-copy" id="drafting-header-title">Quote Options Comparison</div>
  <div id="msa-header-term-start" class="msa-header-term-start hidden">
    <span class="msa-header-term-start-divider" aria-hidden="true"></span>
    <div class="msa-header-term-start-field">
      <label class="field-label" for="msa-header-term-start-date">Term start date</label>
      <input id="msa-header-term-start-date" class="vds-input proposal-date-input" type="date" lang="en-US" onchange="updateMsaHeaderTermStart(this.value)">
    </div>
  </div>
  <!-- resto de lo que ya hay ahí (drafting-title-edit-btn, drafting-title-input-wrap, seasonal-pill-slot-drafting) se conserva tal cual -->
</div>
```

No mostrar el ID del MSA en ningún lado de este bloque — solo la fecha.

---

## 6. CSS — modal, header term start, e indicador de mínimo

Agregar este bloque completo de CSS (mismo código ya probado en la versión futura):

```css
/* ── MSA SETUP MODAL ────────────────────────── */
#msa-setup-overlay {
  z-index: 4015;
}
.msa-setup-modal {
  width: min(640px, 92vw);
}
.msa-setup-modal .account-setup-sub {
  max-width: none;
}
.msa-setup-modal .account-setup-label {
  display: block;
}
.textarea-field__label--required::after {
  content: ' *';
  color: var(--color-brand-red);
}
.msa-setup-number-input {
  width: 100%;
  font-family: 'Archivo', sans-serif;
  font-size: 16px;
  font-weight: 400;
  line-height: 20px;
  letter-spacing: 0.5px;
  color: #000;
  padding: 12px;
  box-sizing: border-box;
}
.msa-setup-number-input::-webkit-inner-spin-button,
.msa-setup-number-input::-webkit-outer-spin-button {
  -webkit-appearance: auto;
  margin: 0;
}
.msa-setup-number-input[type=number] {
  -moz-appearance: auto;
  appearance: auto;
}
.msa-setup-min-service-wrap {
  z-index: 220;
}
.msa-setup-min-service-wrap .custom-select-btn {
  border: 1px solid #000;
  border-radius: 12px;
}
.msa-setup-min-service-wrap .custom-dropdown {
  left: 0;
  right: 0;
}
.msa-setup-modal .msa-setup-actions {
  margin-top: 18px;
}

/* Term start date en el header de Drafting */
.msa-header-term-start {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-top: 0;
}
.msa-header-term-start-divider {
  width: 1px;
  height: 32px;
  background: var(--gray-200);
  display: inline-block;
  flex-shrink: 0;
}
.msa-header-term-start-field {
  display: flex;
  flex-direction: column;
  gap: 2px;
}
.msa-header-term-start .field-label {
  margin-bottom: 0;
  font-size: 12px;
  color: var(--gray-600);
}
.msa-header-term-start .proposal-date-input {
  width: 190px;
  height: 36px;
  font-size: 12px;
  padding: 6px 10px;
}

/* Proposal card helper: qty vs MSA minimum indicator */
.opt-minimum-indicator {
  margin-top: 4px;
  font-size: 11px;
  line-height: 1.25;
}
.opt-minimum-indicator.is-warning {
  color: #b95319;
}
.opt-minimum-indicator.is-success {
  color: #12763d;
  font-weight: 600;
}
```

**Ojo:** verificar que `var(--color-brand-red)` exista como variable en `valucal_mvp_production.html` (debería, ya que es del Design System compartido). Si no existe con ese nombre exacto, avisar antes de usar un color hardcodeado.

---

## 7. Enganchar el flujo: gating antes de Drafting + reset de opciones

En `valucal_mvp_production.html`, la función `openDraftingRoute()` (línea 14500) hoy no tiene ningún parámetro ni chequeo de MSA. Reemplazar su firma y cuerpo para que quede así (mismo patrón ya probado en la versión futura):

```js
function openDraftingRoute(skipMsaSetup = false, preserveProposalData = false) {
  const vcAppUi = document.getElementById('vc-app-ui');
  if (vcAppUi) vcAppUi.classList.remove('hidden');

  if (!skipMsaSetup && isMsaSetupRequired()) {
    openMsaSetupRoute();
    return;
  }

  if (!preserveProposalData) {
    // Auto-generate proposal name: AccountName_YYYY-MM-DD
    const accountName = (document.querySelector('.vc-account-name')?.textContent || 'Account').trim();
    const today = new Date();
    const dateStr = `${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,'0')}-${String(today.getDate()).padStart(2,'0')}`;
    proposalData.name = `${accountName}_${dateStr}`;
    proposalData.hasCustomName = false;
    proposalData.quoteReference = '';

    // Start every new proposal with a clean Drafting canvas.
    options = [];
    nextOptId = 1;
    document.getElementById('empty-state')?.classList.remove('hidden');
    document.getElementById('options-grid')?.classList.add('hidden');
  }

  screen = 'drafting';
  document.getElementById('vc-nav')?.classList.remove('hidden');
  document.getElementById('screen-quotes-list')?.classList.add('hidden');
  document.getElementById('screen-drafting')?.classList.remove('hidden');
  closeMsaSetupModal();
  hideProposalReviewModal();
  document.getElementById('screen-proposal-selection')?.classList.add('hidden');
  document.getElementById('screen-contract')?.classList.add('hidden');
  document.getElementById('screen-deal-result')?.classList.add('hidden');

  document.getElementById('vc-body').style.paddingTop = '159px';
  document.getElementById('success-banner').style.top = '159px';

  const sendBtn = document.getElementById('footer-send');
  if (sendBtn) {
    sendBtn.classList.add('hidden');
    sendBtn.innerText = 'Send Proposal';
    sendBtn.onclick = handleSend;
  }
  const backBtn = document.getElementById('footer-back');
  backBtn?.classList.remove('visible');
  backBtn?.classList.add('hidden');

  updateDraftingHeaderTitle();
}
```

Y en `openDraftingQuoteFromList()` (línea 14537, el flujo de "reanudar una cotización demo existente"), cambiar la llamada `openDraftingRoute();` (línea 14569) por `openDraftingRoute(true, true);` — para que ese caso demo (que ya trae datos precargados) no dispare el modal de MSA Setup ni borre las opciones que esa misma función acaba de precargar.

Por último, en `renderOptions()` (línea 9611), donde ya se llama `renderMsaContextBar();` dentro del `setTimeout`, agregar justo al lado `renderMsaHeaderTermStart();`:

```js
setTimeout(() => { if (typeof updateApprovalSnackbar === 'function') { updateApprovalSnackbar(); updateMarkDeadBtn(); renderMsaContextBar(); renderMsaHeaderTermStart(); } }, 0);
```

---

## 7bis. Contador "Total qty vs. minimum" en las cards de opción

En `renderOptions()`, justo antes del `card.innerHTML = ...` (línea 9859), agregar:

```js
const msaMinimumCommitment = Number(proposalData.msaMinimumQuantityCommitment || 0);
let minimumIndicatorHtml = '';
if (proposalData.msaId && msaMinimumCommitment > 0) {
  if (totalUnits < msaMinimumCommitment) {
    const missingUnits = msaMinimumCommitment - totalUnits;
    minimumIndicatorHtml = `<div class="opt-minimum-indicator is-warning">${missingUnits} more needed to reach minimum (${msaMinimumCommitment})</div>`;
  } else {
    minimumIndicatorHtml = '<div class="opt-minimum-indicator is-success">Minimum met</div>';
  }
}
```

Y dentro del `card.innerHTML`, en la celda "Total qty" del `.opt-totals-row` (línea 9871-9875), agregar `${minimumIndicatorHtml}` justo después del valor:

```html
<div class="opt-totals-cell">
  <div class="opt-totals-label">Total qty</div>
  <div class="opt-totals-value">${totalUnits} <span>units</span></div>
  ${minimumIndicatorHtml}
</div>
```

---

## 8. Modal de "Send Proposal" / Review — sincronizar con la versión futura

Catalina pidió conservar, para el paso de Review & Send, el modal que se está usando actualmente en la versión futura (más completo) en vez del que trae v1.

Ambos archivos tienen el mismo contenedor (`#proposal-review-overlay` / `.proposal-review-modal`, prácticamente el mismo tamaño de HTML: PROD líneas 5542-5921, futuro líneas 7680-8047), así que **no hay que reconstruir el HTML desde cero** — la diferencia real está en:

1. **JS — reemplazar las funciones existentes en PROD por las versiones vigentes del futuro.** En PROD, estas funciones tienen una sola definición (limpia): `openProposalCustomizationEditor` (~10522), `backToProposalReviewSummary` (~10550), `fillProposalMessageDefaults`, `renderCustomizationSummary`, `moduleMarkup`. En el archivo futuro (`valucal_mvp.html`), estas mismas funciones están definidas **dos veces** — la primera copia (~14257-14707) es código muerto que quedó abandonado; la que realmente corre es la **segunda** (~15767-16700+), más completa (agrega indicadores de autosave, editor/dropdown de búsqueda de rep, etc.). **Instrucción para Visual Studio:** copiar, del archivo futuro, la **segunda** definición de cada una de esas funciones (la que está más abajo en el archivo, alrededor de la línea 15767 en adelante — NO la de ~14257), y usarla para reemplazar la única definición que hoy existe en PROD. También copiar dos funciones que solo existen en el futuro y no tienen equivalente en PROD: `syncProposalMessageInlineFieldsPlacement` y `setProposalReviewHeaderEditorMode`.

2. **HTML — agregar dos elementos nuevos** que están en el header del modal en el futuro pero no en PROD: `#proposal-edit-message-inline-host` y `#proposal-edit-loader` (el loader con el texto "Redirecting to email customization"). Copiarlos tal cual desde el bloque del modal en el archivo futuro (dentro del rango de líneas 7680-8047) al bloque equivalente en PROD (rango 5542-5921).

3. **CSS — agregar 2 reglas que hoy solo existen en el futuro:** `.is-editor-open .proposal-review-modal-actions` y `.is-editor-open .proposal-review-edit-view .proposal-editor-topbar { display:none; }`, más las variables CSS nuevas `--proposal-header-surface`, `--proposal-header-band-height`, `--proposal-modal-pad-x` y las reglas de `.proposal-edit-message-inline-host` / `.proposal-edit-loader`. Todo esto está en el bloque `.proposal-review-modal` del futuro (~líneas 2101-2116, con las reglas sueltas en ~2244 y ~2998) — copiarlo íntegro a PROD, agregándolo al bloque equivalente (~líneas 1888-1901 en PROD).

**Orden sugerido:** primero el CSS y el HTML (son aditivos, no rompen nada existente), y al final el reemplazo de las funciones JS (para poder probar visualmente el modal antes de tocar su lógica).

---

## 9. Account Setup — sección nueva para los campos de MSA

En `app/demos/account-setup.html` (el archivo real que ven hoy en producción, sin cambios desde el commit inicial), agregar una sección nueva "Master Service Agreement", siguiendo el mismo patrón visual que ya usa la sección "Seasonal Billing" (línea 1172) — su propia tarjeta, con badge y campos editables.

**Alcance de este punto:** esta sección queda como un área editable independiente dentro de Account Setup — para que el campo exista y se pueda configurar/corregir ahí más adelante, tal como pediste. **No queda conectada todavía** con los valores que se capturan en el modal de MSA Setup de `valucal_mvp_production.html` (esa sincronización sigue siendo trabajo futuro, ya confirmado en la otra conversación de la versión futura — se resuelve cuando se construya el puente entre los dos archivos).

**9.1 — Agregar los 4 campos al estado (línea ~1599, dentro de `accountInfo: { ... }`), después de `seasonalBilling: '',`:**

```js
    seasonalBilling:   '',
    msaMinimumQuantityCommitment: '',
    msaTermStart:      '',
    msaMinimumServiceTerm: '',
    msaRampUpPeriod:   '30',
```

**9.2 — Agregar las etiquetas y formateo de valores (`fieldLabels` línea ~1993, `displayValues` línea ~2004):**

```js
// en fieldLabels:
  msaMinimumQuantityCommitment: 'Minimum quantity commitment',
  msaTermStart:                 'Term start date',
  msaMinimumServiceTerm:        'Minimum service term',
  msaRampUpPeriod:              'Ramp-up period',

// en displayValues:
  msaMinimumQuantityCommitment: v => v ? `${v} units` : 'Not configured',
  msaTermStart:                 v => v ? new Date(v + 'T00:00:00').toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : 'Not configured',
  msaMinimumServiceTerm:        v => v ? `${v} months` : 'Not configured',
  msaRampUpPeriod:              v => v ? `${v} days` : 'Not configured',
```

**9.3 — HTML de la sección nueva.** Insertar justo después de que cierra la tarjeta de "Seasonal Billing" (después de la línea 1199, antes del `</div>` de la línea 1200):

```html
<div class="card section-card">
  <div class="subsection-heading">
    <h3 class="subsection-title">Master Service Agreement</h3>
    <span class="badge badge--yellow" id="acc-badge-msa">4 items pending</span>
  </div>

  <div class="field-row" id="row-msaMinimumQuantityCommitment">
    <div class="field-lbl">Minimum quantity commitment</div>
    <div class="field-val" id="val-msaMinimumQuantityCommitment"><span style="color:var(--color-gray-400);">Not configured</span></div>
    <div class="field-actions">
      <button class="btn btn--ghost btn--small" onclick="startEdit('msaMinimumQuantityCommitment')">Edit <span class="material-symbols-outlined ui-icon--sm" aria-hidden="true">arrow_forward</span></button>
    </div>
  </div>
  <div class="field-row hidden" id="edit-msaMinimumQuantityCommitment">
    <div class="field-lbl">Minimum quantity commitment</div>
    <div class="field-edit-wrap">
      <input type="number" min="0" step="1" class="input" id="input-msaMinimumQuantityCommitment">
      <div class="edit-actions">
        <button class="btn btn--primary btn--medium" onclick="saveEdit('msaMinimumQuantityCommitment')">Save</button>
        <button class="btn btn--secondary btn--medium" onclick="cancelEdit('msaMinimumQuantityCommitment')">Cancel</button>
      </div>
    </div>
  </div>

  <div class="field-row" id="row-msaTermStart">
    <div class="field-lbl">Term start date</div>
    <div class="field-val" id="val-msaTermStart"><span style="color:var(--color-gray-400);">Not configured</span></div>
    <div class="field-actions">
      <button class="btn btn--ghost btn--small" onclick="startEdit('msaTermStart')">Edit <span class="material-symbols-outlined ui-icon--sm" aria-hidden="true">arrow_forward</span></button>
    </div>
  </div>
  <div class="field-row hidden" id="edit-msaTermStart">
    <div class="field-lbl">Term start date</div>
    <div class="field-edit-wrap">
      <input type="date" class="input" id="input-msaTermStart">
      <div class="edit-actions">
        <button class="btn btn--primary btn--medium" onclick="saveEdit('msaTermStart')">Save</button>
        <button class="btn btn--secondary btn--medium" onclick="cancelEdit('msaTermStart')">Cancel</button>
      </div>
    </div>
  </div>

  <div class="field-row" id="row-msaMinimumServiceTerm">
    <div class="field-lbl">Minimum service term</div>
    <div class="field-val" id="val-msaMinimumServiceTerm"><span style="color:var(--color-gray-400);">Not configured</span></div>
    <div class="field-actions">
      <button class="btn btn--ghost btn--small" onclick="startEdit('msaMinimumServiceTerm')">Edit <span class="material-symbols-outlined ui-icon--sm" aria-hidden="true">arrow_forward</span></button>
    </div>
  </div>
  <div class="field-row hidden" id="edit-msaMinimumServiceTerm">
    <div class="field-lbl">Minimum service term</div>
    <div class="field-edit-wrap">
      <select class="select" id="input-msaMinimumServiceTerm">
        <option value="">Select option…</option>
        <option value="12">12 months</option>
        <option value="24">24 months</option>
        <option value="36">36 months</option>
        <option value="48">48 months</option>
        <option value="60">60 months</option>
      </select>
      <div class="edit-actions">
        <button class="btn btn--primary btn--medium" onclick="saveEdit('msaMinimumServiceTerm')">Save</button>
        <button class="btn btn--secondary btn--medium" onclick="cancelEdit('msaMinimumServiceTerm')">Cancel</button>
      </div>
    </div>
  </div>

  <div class="field-row" id="row-msaRampUpPeriod">
    <div class="field-lbl">Ramp-up period</div>
    <div class="field-val" id="val-msaRampUpPeriod"><span style="color:var(--color-gray-400);">Not configured</span></div>
    <div class="field-actions">
      <button class="btn btn--ghost btn--small" onclick="startEdit('msaRampUpPeriod')">Edit <span class="material-symbols-outlined ui-icon--sm" aria-hidden="true">arrow_forward</span></button>
    </div>
  </div>
  <div class="field-row hidden" id="edit-msaRampUpPeriod">
    <div class="field-lbl">Ramp-up period</div>
    <div class="field-edit-wrap">
      <input type="number" min="0" step="1" class="input" id="input-msaRampUpPeriod">
      <div class="edit-actions">
        <button class="btn btn--primary btn--medium" onclick="saveEdit('msaRampUpPeriod')">Save</button>
        <button class="btn btn--secondary btn--medium" onclick="cancelEdit('msaRampUpPeriod')">Cancel</button>
      </div>
    </div>
  </div>
</div>
```

Esto reusa exactamente la maquinaria genérica ya existente (`startEdit`/`saveEdit`/`cancelEdit`, líneas 2025-2056) — al agregar las entradas de `fieldLabels`/`displayValues` del punto 9.2, estos 4 campos quedan completamente editables desde ya, igual que "Platform" o "Contract type".

**9.4 — Badge de la sección.** Donde ya se actualizan los demás badges (`setBadge('acc-badge-general', ...)`, alrededor de la línea 1913), agregar una línea análoga:

```js
const msaPending = ['msaMinimumQuantityCommitment','msaTermStart','msaMinimumServiceTerm','msaRampUpPeriod'].filter(k => !state.accountInfo[k]).length;
setBadge('acc-badge-msa', msaPending > 0 ? 'yellow' : 'green', msaPending > 0 ? (msaPending + ' item' + (msaPending > 1 ? 's' : '') + ' pending') : 'Ready');
```

**Nota:** esta sección/badge se deja fuera del arreglo `blocking`/`requiredFields` que usa el resto del archivo para bloquear el contrato (esa lógica es sobre validación de Salesforce y no aplica todavía a MSA) — es solo una sección editable más, visualmente consistente con el resto.

---

## Orden sugerido para ejecutar en Visual Studio

0. 🔴 Hacer primero: reemplazar por completo `openAccountSetupEmbed()` (punto 10.2) para cargar `account-setup.html` con `google.script.run` + `iframe.srcdoc` y agregar en `Code.gs` la función de servidor `getAccountSetupHtml()` (punto 11.3).
1. Bug de sintaxis (punto 1).
2. `proposalData` + funciones nuevas de MSA (puntos 2-3).
3. HTML del modal + Term start date en header (puntos 4-5).
4. CSS (punto 6).
5. Gating en `openDraftingRoute()` + ajuste de `openDraftingQuoteFromList()` + llamada a `renderMsaHeaderTermStart()` (punto 7).
6. Contador de mínimo en las cards (punto 7bis).
7. Probar el flujo completo de MSA Setup en `valucal_mvp_production.html` antes de seguir.
8. Sincronización del modal de Send Proposal (punto 8) — en su propia pasada, probando visualmente el modal antes de tocar el JS.
9. Sección de Master Service Agreement en `account-setup.html` (punto 9) — puede hacerse en paralelo, es independiente del resto.

**Estado: listo para ejecutar. Ningún punto de este documento toca `valucal_mvp.html` (versión futura) ni `valucal_mvp_v1.html` (snapshot histórico).**
