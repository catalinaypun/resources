# Plan de implementación — MSA en el flujo Post-Sale (Upsell/Expansion)

> Generado a partir de la llamada "Post Sale MSA Journey" (Anil Pilaka / Catalina Arango, 2026-08-26).
> Este archivo es un plan por fases con **prompts listos para pegar** en tu agente de código en VS Code (Copilot Chat, Cursor, Claude Code, etc.). Cada fase es independiente y se puede ejecutar y revisar por separado.
>
> **Regla de trabajo (2026-08-26):** de aquí en adelante, todo cambio de código de este proyecto se entrega como un prompt en este documento — no se editan los archivos HTML/JS directamente. Las Fases 1 y 3 (marcadas ✅ abajo) son la única excepción: se implementaron directamente para poder iterar rápido sobre el diseño visual del dashboard de MSA, con aprobación explícita de Catalina para ese caso puntual.

---

## 0. Contexto (para ti y para el agente)

Proyecto: `valucal-existing-accounts` — prototipo estático (HTML + JS vanilla, sin build step) del flujo de ventas/renovación de Verizon Connect.

Archivos relevantes:

- `app/demos/valucal_existing_accounts.html` — el flujo completo (Upsell/Expansion, generación de código/contrato, etc.). ~15,300 líneas, todo en un solo archivo.
- `app/demos/account-setup.html` — pantalla de Account Setup (hoy **no tiene** ningún campo de MSA: términos, precio negociado, compromiso mínimo, etc. — se confirmó por búsqueda directa en el archivo).

Ya existe en `valucal_existing_accounts.html` una funcionalidad relacionada pero distinta (feature "F2 - MSA / Co-term"), que **no** cubre lo que pide Anil:

- `DEMO_MSA` (objeto mock, línea ~7297): `{ id, startDate, endDate, termMonths, vehicleCount }`
- `renderMsaContextBar()` (línea ~7652): pinta una barra con "Add-on to MSA-XXXX · MSA expires <fecha> · N months remaining", usada para lógica de co-term/auto-extend.

Esto es la base sobre la que vamos a extender — no hay que rehacerlo, sino agregarle los campos de compromiso/precio que pide Anil.

**Regla general para todos los prompts:** es un prototipo de demo, no un backend real. Todo dato nuevo (precio negociado, cantidad mínima comprometida, número de orden, fechas de suscripción, etc.) se **mockea** con lógica determinística (como ya hace `vzMockVehicleDetails` con un hash del serial) — no se conecta a ningún API real.

---

## 1. Requerimientos extraídos de la llamada

> Actualizado 2026-08-26 con el transcript completo de la llamada "Post Sale MSA Journey" (Anil Pilaka, Madhuri R Muluka, Catalina Arango). Los puntos 1-5 son los que ya veníamos trabajando; se afinaron con detalle real de la conversación. Los puntos 6-9 son hallazgos nuevos del transcript que no estaban documentados antes.

1. **Columnas nuevas en la tabla de vehículos del flujo de Upsell/Expansion**: agregar `Order` (Anil: es el "provider order" / "service order" que viene del ERP — no está 100% seguro de cuál de los dos términos usan, por eso quedó como "Order" genérico), `Start Date` y `End Date` (fechas de la suscripción). Los tres valores son **a nivel de vehículo completo**, no por sub-ítem. ✅ Implementado (Fase 2).
2. **Dashboard de resumen de MSA** (para Upsell/Expansion, post-venta), de solo lectura salvo por un botón Edit: Anil confirmó explícitamente que esta info (compromiso mínimo, precio negociado, término, ramp-up) debe mostrarse en el flujo de upsell/expansion porque "these are the MSA details associated to that customer account... we are expected to be pulling from cal layer at this point and showcase it so that it's available for the rep to know beforehand" — es decir, es informativo para el rep, viene (en el mundo real) del "CAL layer".
   - Ubicación: en la pantalla de **Drafting**, justo después del breadcrumb. ✅ Implementado (Fase 3.2).
   - Restricción de espacio, dicha por Catalina en la llamada: "there are a lot of fields that we need to include and this screen is huge... let's say that the agent has this size of a screen" — de ahí la necesidad de consolidar campos redundantes (ver punto 7) y mantener el diseño compacto (Fases 3.3-3.5).
3. **Modal de confirmación al crear el contrato** (flujo de **venta nueva/inicial**, no post-sale): al hacer clic en "Create Contract" (lo que hoy dispara `confirmAndLockDeal()` en nuestro prototipo de post-sale, pero el requerimiento original es para el flujo de creación de contrato inicial), mostrar antes de crear el contrato un resumen de solo lectura de los atributos del MSA. Detalles nuevos del transcript:
   - Es **solo para la venta inicial** ("this is only for initial sale... this is during the contract initial because this [is] when they confirm and create the MSA"). No aplica al flujo de upsell/expansion (ese usa el dashboard del punto 2, no este modal).
   - Es de solo lectura a propósito ("for now I marked I told her to put it as read only here") — Madhuri preguntó si se puede modificar y Anil confirmó que por ahora no, que si se necesita editar se agrega después.
   - Este modal es un posible **punto de disparo** para la integración con el "CAL layer" (enviar la info del MSA), pero Anil aclaró que es una **decisión de negocio pendiente** cuál de estos 3 momentos dispara el envío real: (a) este popup de confirmación, (b) el flujo de DocuSign/firma del cliente, o (c) la confirmación de venta ("sale confirm"). Para el prototipo no hay que implementar el envío real, solo dejar claro en el modal que es el punto de confirmación.
   - Aclaración de negocio sobre las cantidades: cuando se cuenta la cantidad comprometida/contratada, **solo se cuentan los items "core"** (VTU, powered/non-powered trackers) — **no se incluyen features/add-ons**. Cita textual de Anil: "we don't send any of the quantities of features we only send the total core units". Esto ya es consistente con cómo se calcula `vehicleCount`/`contractedQty` en el mock actual (no incluye features), pero queda documentado como regla de negocio explícita.
4. **Record Type = "MSA"** en el registro de contrato que se crea desde ese flujo (campo nuevo, mockeado, mostrado en el documento de contrato generado). Sin cambios respecto a lo ya documentado.
5. **No** implementar edición de esos valores dentro del modal de confirmación todavía — confirmado explícitamente por Anil en la llamada. Por ahora es solo lectura + confirmar.
6. **🆕 Terminología "units" en vez de "vehicles"**: Anil pidió explícitamente usar la palabra **"units"** en los campos de MSA (minimum commitment, cantidad contratada, etc.) en vez de "vehicles", porque hay un defecto ya reportado en Valcal por la inconsistencia entre "vehicles" y "units" en distintas pantallas. Cita: "maybe call it units here... there was a defect that was raised in val[cal] as well with the vehicles and units." **No implementado todavía** — ver Fase 3.6 propuesta abajo, pendiente de que confirmes alcance.
7. **🆕 Consolidar los 3 campos redundantes del dashboard de MSA** (Minimum commitment, Projected quantity, Status): esto fue pedido explícitamente por Anil y Madhuri en la llamada — "those are all projecting the same information for me... try to see if you can combine it into one and say... 45 current quantity and 60 committed quantity, something like that" (Anil), confirmado por Madhuri ("just make it into one, you'll get more real estate there") y por Catalina ("we are repeating the same information"). ✅ Ya está en el plan como **Fase 3.5** (con el mismo criterio: un solo campo tipo contador, formato "45/60").
8. **🆕 Posible separación de "asset trackers" vs "vehicle tracking" como dos columnas/campos separados** en vez de un solo conteo genérico de unidades: Anil lo planteó como algo a considerar ("there might be separate attributes as well at the core level... separating your asset trackers versus your vehicle [tracker]s... maybe we might want to split that into two separate columns"), pero **no quedó como decisión cerrada** — quedó como "maybe". Ver Decisión pendiente en la sección 2.
9. **🆕 Fechas adicionales para el dashboard de MSA** — este fue el punto más largo y menos resuelto del transcript. Catalina notó que falta la fecha de inicio del MSA. La conversación evolucionó así:
   - Anil: quiere mantener tanto **MSA Start Date** como **MSA End Date** visibles (no solo el Term/duración), porque "people won't be calculating what my 36 [months]... started".
   - Madhuri preguntó también por **Contract Start Date**, **Contract End Date** y **Service Start Date** / **Service End Date** — distintos de las fechas del MSA en sí.
   - Anil explicó que el **Service Start Date** probablemente se calcule *después* del período de ramp-up, en base a la fecha de compromiso original — pero aclaró que esa es **una regla de negocio que todavía no está definida** ("that's a business rule something that needs to be flushed out").
   - Al cierre, Madhuri resumió pidiendo **las 4 fechas**: Service start date, Service end date, Contract start date, Contract end date — para ubicarlas junto al MSA ID, junto con Term, Ramp-up y Negotiated price.
   - **No quedó 100% claro en la llamada** si el MSA Start/End Date (que Anil pidió antes) es lo mismo que el Contract Start/End Date que pidió Madhuri al final, o si son 4 fechas distintas + el Term ya existente. Por eso este punto queda en la sección 2 como decisión pendiente antes de escribir el prompt de implementación — para no repetir el patrón de "hacer y deshacer" que ya pasó con el diseño visual del dashboard.

Nota de prioridad (dicha explícitamente por Anil): este trabajo de MSA tiene **precedencia** sobre otras mejoras planeadas de Valu Cal (p. ej. profundizar el flujo de creación de contrato) — puede que esas otras cosas se pausen mientras se resuelve esto.

**Fuera de alcance de esta ronda (confirmado explícitamente en la llamada):** el flujo de **Cancelación** no se tocó y no se va a tocar todavía — Anil: "it's all completely w[orked] out... we just added it on up for now, just quick[ly]." A futuro, las reglas de negocio de cancelación (parcial vs. total) deberían venir del CAL layer ("VCF rules everything should come up at this point from cal layer"), pero eso es un proyecto aparte, no parte de este plan.

---

## 2. Decisiones pendientes (no bloquean empezar, pero revisar con Anil/Madi)

- [x] ~~Ubicación final del "dashboard" de resumen MSA~~ → **Resuelto**: en Drafting, justo después del breadcrumb. Ver Fase 3.2.
- [x] ~~Nombre final de la tercera columna de la tabla del Upsell~~ → **Resuelto**: "Order" (representa el "provider order"/"service order" del ERP, según el transcript).
- [ ] Si el "Record Type: MSA" debe ser visible en el documento del contrato (Section 1) o solo un atributo interno del registro.
- [x] ~~Terminología "units" vs "vehicles"~~ → **Resuelto para el dashboard (2026-08-26)**: Catalina decidió hacer primero el rename en el dashboard de MSA (Fase 3.5, ya actualizada) y evaluar después si impacta a Account Setup y/o a la tabla de vehículos del Upsell — eso queda pendiente como un paso aparte, no se toca todavía.
- [x] ~~¿Separar "asset trackers" de "vehicle tracking" en dos campos/columnas?~~ → **Resuelto (2026-08-26)**: Catalina confirmó que sí, se separan. Alcance acotado para el dashboard de Drafting: **solo el precio** se separa en "Vehicle Tracking" / "Powered Asset Tracking" (Fase 3.6) — la cantidad (compromiso mínimo/contratada) se queda combinada en el contador único de la Fase 3.5, y el dashboard sigue sin botón Edit. Queda abierto si esto también debe aplicar a la tabla de vehículos del Upsell (no se tocó en esta fase).
- [x] ~~Qué fechas exactas mostrar en el dashboard de MSA~~ → **Resuelto por decisión de Catalina (2026-08-26), sin esperar confirmación de Anil/Madhuri**: "MSA Start/End" = "Service Start/End" (mismo par), "Contract Start/End" es un par aparte → 2 pares de fechas en total. Ver mapeo completo en la sección 2.1 y el prompt en la Fase 3.7. Si la lectura resulta incorrecta al validarla después, se ajusta con otro prompt puntual.

---

## 2.1. Mapeo de fechas mencionadas en la llamada (para preguntar mejor antes de implementar)

Catalina pidió mapear esto con calma antes de volver a preguntarle a Anil/Madhuri, en vez de adivinar. Así quedó el mapeo de cada mención de fecha en el transcript:

| # | Fecha mencionada | Quién la pidió y cita textual | ¿Existe hoy en el código? |
|---|---|---|---|
| 1 | **MSA Start Date** | Catalina notó que faltaba ("I am seeing that here we don't have the start date"); Madhuri: "we still need the MSA start date"; Anil: "I would keep actually both the dates [start y end]" | Sí, como dato — `DEMO_MSA.startDate` ('2024-03-15') en el mock viejo del dashboard. En Account Setup existe `msaTermStart` (campo nuevo, vacío). |
| 2 | **MSA End Date** | Anil insistió en mantenerla junto al start, aunque Madhuri al principio dijo "we don't need the MSA end date" (porque ya está el Term) — Anil la anuló: "people won't be calculating what my 36 [months]... started" | Sí, como dato — `DEMO_MSA.endDate` ('2027-07-15') en el mock viejo. En Account Setup NO existe todavía (`msaTermStart` no tiene su par "End"). |
| 3 | **Contract Start Date** | Madhuri: "don't we need the contract start date as well?" — lo preguntó como algo aparte de las fechas del MSA | No existe en ningún lado todavía. |
| 4 | **Contract End Date** | Madhuri, mismo contexto que la anterior | No existe en ningún lado todavía. |
| 5 | **Service Start Date** | Madhuri preguntó por ella; Anil explicó que se calcularía después del ramp-up period, pero aclaró que es "a business rule [that] needs to be flushed out" — no está definida | No existe en ningún lado todavía. Su regla de cálculo tampoco está definida. |
| 6 | **Service End Date** | Madhuri, mismo contexto que la anterior | No existe en ningún lado todavía. |

**La ambigüedad concreta:** al cerrar el tema, Madhuri resumió "we should have all those dates... all four", y Anil las listó como "Service start date, service end, contract start date and then contract end" — es decir, **su resumen final solo menciona 4 fechas y no vuelve a nombrar "MSA start/end" por separado**. Había dos lecturas posibles sobre cuál par se fusiona con cuál:

- **Lectura A:** "Contract Start/End Date" = "MSA Start/End Date" (mismo concepto, dos nombres) → 2 pares (MSA/Contract) + (Service).
- **Lectura C (la que eligió Catalina, 2026-08-26):** "MSA Start/End Date" = "Service Start/End Date" (mismo concepto — el servicio corre durante la vigencia del MSA) → 2 pares: **(MSA/Service Start–End)** + **(Contract Start–End, aparte)**. Bajo esta lectura, "Contract" queda como el registro de Salesforce que se crea en cada evento de creación de contrato (podría tener fechas propias por transacción, distintas de la vigencia del MSA), mientras que "MSA/Service" es la vigencia general del acuerdo.

En ambas lecturas el total termina siendo **2 pares de fechas (4 fechas)** — la diferencia es solo cuál par se llama "MSA/Service" y cuál "Contract". Con la Lectura C de Catalina, la regla de negocio del ramp-up que mencionó Anil ("Service Start Date se calcula después del ramp-up") quedaría sin aplicar tal cual, porque ahora "Service Start" = "MSA Start" (la fecha de inicio del acuerdo, no una fecha derivada después del ramp-up) — esto es una simplificación consciente para el prototipo, no necesariamente lo que Anil tenía en mente literalmente.

**Pregunta sugerida para llevarles, ya simplificada a partir de la lectura de Catalina (para confirmar sin ambigüedad):**
> "We're treating 'Service Start/End Date' as the same as the MSA's own Start/End Date (i.e. the service runs for the life of the MSA), and 'Contract Start/End Date' as a separate pair tied to the Contract record created at each contract-creation event. Does that match what you had in mind, or did you mean Service Start Date should be calculated separately (e.g. after the ramp-up period)?"

**Decisión de diseño ya tomada por Catalina (aplica sin importar la lectura final), para ahorrar espacio en el dashboard:** en vez de un campo "Start Date" y otro "End Date" por separado (2 mini-secciones por par), cada par de fechas va en **una sola mini-sección** con las dos fechas separadas por un guion, ej. `03/15/2024 - 07/15/2027`. Con `flex-wrap` esto debería acomodarse en dos renglones cuando no quepa todo en uno, igual que ya pasa con el resto de las mini-secciones del dashboard (Fase 3.4).

**Decisión final de Catalina (2026-08-26): implementar ya con la Lectura C, sin esperar confirmación de Anil/Madhuri.** Si luego resulta que la lectura no era correcta, se ajusta con otro prompt puntual (mismo patrón que ya usamos varias veces en este plan). Ver Fase 3.7 abajo.

---

## 3. Fases de implementación

### Fase 1 — Modelo de datos mock del MSA (compromiso y precio) ✅ Completado

**Estado:** ejecutado por Catalina. `DEMO_MSA` en `valucal_existing_accounts.html` ya tiene `negotiatedPricePerVehicle: 32.50`, `minQuantityCommitment: 60`, `rampUpPeriodMonths: 6`, y existe `getMsaCommitmentStatus(additionalVehicles)` (~línea 7320).

**Objetivo:** extender el mock `DEMO_MSA` para que tenga toda la info que las fases 2-4 van a necesitar, en un solo lugar.

**Prompt para pegar en el agente:**

```
Trabaja en app/demos/valucal_existing_accounts.html.

Busca el objeto `DEMO_MSA` (cerca de la línea 7297, justo antes de
`getMsaMonthsRemaining`). Hoy tiene esta forma:

const DEMO_MSA = {
  id: 'MSA-2024-0391',
  startDate: '2024-03-15',
  endDate: '2027-07-15',
  termMonths: 36,
  vehicleCount: 45,
};

Extiéndelo (sin romper los usos actuales de id/startDate/endDate/termMonths/
vehicleCount) agregando estos campos mock:

- negotiatedPricePerVehicle: number  → precio mensual negociado por vehículo (ej. 32.50)
- minQuantityCommitment: number      → cantidad mínima de vehículos que el cliente
                                        se comprometió a contratar bajo este MSA
- rampUpPeriodMonths: number         → meses de período de ramp-up acordado

Luego crea una función helper `getMsaCommitmentStatus()` que devuelva un objeto:

{
  minCommitment: number,       // DEMO_MSA.minQuantityCommitment
  contractedQty: number,       // cantidad de vehículos actualmente activos bajo
                                // el MSA (usa el mismo criterio que ya usa
                                // vzGenerateSubscriptions()/DEMO_MSA.vehicleCount
                                // para "vehículos actuales")
  remainingToCommitment: number,  // max(0, minCommitment - contractedQty)
  pctOfCommitment: number,        // contractedQty / minCommitment, entre 0 y 1
  negotiatedPricePerVehicle: number,
  rampUpPeriodMonths: number,
  termMonths: number,
}

Colócala inmediatamente después de `isMsaAutoExtend()`. No cambies el
comportamiento de renderMsaContextBar() en esta fase — solo agrega el modelo
de datos. Verifica que el archivo siga siendo HTML/JS válido (no rompas
comas ni llaves) y que no haya declaraciones duplicadas de DEMO_MSA.
```

---

### Fase 2 — Columnas "Order / Start Date / End Date" en la tabla de vehículos del Upsell ✅ Completado

**Objetivo:** que la tabla de vehículos que se ve al hacer un upsell/expansion muestre, por vehículo, el número de orden y las fechas de inicio/fin de la suscripción que lo cubre — igual que se ve hoy en la referencia HTML que compartió el otro equipo.

**Contexto para el agente:** la tabla vive en `vzRenderUpsellTable()` (~línea 13462 en adelante, dos vistas: "By Vehicle" y "By Subscription"), y los datos vienen de `vzGenerateSubscriptions()` (~línea 13353), que hoy genera `serial`, `vin`, `subEnd`, etc. por cada sub-ítem.

**Prompt para pegar en el agente:**

```
Trabaja en app/demos/valucal_existing_accounts.html.

1) En `vzGenerateSubscriptions()` (~línea 13353), donde se arma cada
   objeto `subs.push({...})`, agrega dos campos mock nuevos, determinísticos
   a partir de `subId` (igual de estilo que el resto de la función, sin usar
   Math.random para que sea estable al re-renderizar):

   - orderNumber: string   → algo como `ORD-${String(subId).padStart(6,'0')}`
   - subStart: string      → fecha ISO, calculada como
                              `subEnd` menos `termMonths` meses del MSA
                              (usa DEMO_MSA.termMonths o el termMonths que
                              corresponda; si no está disponible, usa 24 meses
                              antes de subEnd como fallback)

   Estos dos campos deben ser el MISMO valor para todas las subscripciones
   que pertenecen al mismo vehículo (mismo grupo de `linkedCoreSerial`/core),
   porque representan la orden que cubre al vehículo completo, no a cada
   sub-ítem por separado. Reutiliza el valor calculado para el "core" en
   sus add-ons vinculados.

2) En `vzRenderUpsellTable()`, vista "By Vehicle" (el bloque que arma
   `thead.innerHTML` con las columnas Vehicle/Asset, Name, License Plate,
   alrededor de la línea 13564), agrega tres columnas nuevas al final:
   "Order", "Start Date", "End Date". Deben quedar en la fila de vehículo
   (`vehicleRow`), no en las filas de sub-ítem (`subRows`) — ahí deja esas
   celdas vacías o con colspan, ya que el dato es a nivel de vehículo.
   Usa `s.orderNumber`, `s.subStart` y `s.subEnd` (ya existente) del
   objeto de la subscripción "core" de esa fila. Formatea las fechas con
   el mismo helper que ya use el resto del archivo para fechas legibles
   (busca cómo se formatea `endDisplay` en renderMsaContextBar y reutiliza
   ese patrón, o Intl.DateTimeFormat si no hay uno reusable).

3) Repite el mismo agregado de columnas en la vista "By Subscription"
   (el otro bloque de `thead.innerHTML`/`tbody.innerHTML` un poco más
   abajo en la misma función, alrededor de la línea 13620-13660), manteniendo
   el mismo criterio (valor a nivel de vehículo).

No cambies el ancho de columnas existentes de forma que rompa el layout;
usa el mismo patrón de <th>/<td> con estilos inline que ya usa el resto de
la tabla. Al terminar, abre el archivo en el navegador y confirma visualmente
que las tres columnas aparecen y muestran datos coherentes (fechas con
sentido, Order con formato ORD-XXXXXX) en ambas vistas (By Vehicle / By
Subscription) del flujo de Upsell.
```

---

### Fase 2.1 — Bug: falta scroll horizontal y los checkboxes se ven aplastados 🆕 Pendiente (2026-08-26)

**Reportado por Catalina** al probar la Fase 2 en su navegador: la tabla de vehículos del Upsell ahora tiene más columnas de las que caben (Order/Start Date/End Date se suman a Vehicle/Name/Plate), y (a) no hay forma de hacer scroll horizontal para verlas todas, y (b) los checkboxes de selección se ven "aplastados" — no siguen el Design System.

**Causa raíz identificada:** el contenedor que envuelve la tabla usa `overflow:hidden` en vez de scroll, y la tabla no tiene un `min-width`. Eso hace que el navegador comprima todas las columnas (incluida la del checkbox, que tiene `width:44px` fijo) para que "quepan" a la fuerza en el ancho disponible, en lugar de dejar la tabla en su ancho natural y scrollear. Es el mismo problema para ambos síntomas — un solo fix los arregla a los dos.

Hay **dos lugares** con este mismo wrapper envolviendo `<table class="gc-sub-table" id="gc-upsell-table">` (mismo problema en ambos, porque los dos usan `vzRenderUpsellTable()` para pintar las filas):
- Dentro de `renderVZUpsellForm()`, vista "By Vehicle" del Step 1 (modo `upsellMode === 'vehicles'`).
- Dentro de `vzGoUpsellStep2()`, cuando `upsellMode !== 'vehicles'` (flujo "selecting features" → Step 2 "Select Vehicles").

**Prompt para pegar en el agente:**

```
Trabaja en app/demos/valucal_existing_accounts.html.

Hay dos bugs visuales relacionados en la tabla de vehículos del flujo de
Upsell/Expansion (la que tiene columnas Vehicle/Asset, Name, License Plate,
Order, Start Date, End Date): (1) no hay scroll horizontal para ver las
columnas que no caben, y (2) el checkbox de selección de cada fila se ve
aplastado/deformado. Ambos vienen de la misma causa: el contenedor de la
tabla usa `overflow:hidden` y la tabla no tiene ancho mínimo, así que el
navegador comprime todas las columnas (incluida la del checkbox) para que
quepan, en vez de dejar que la tabla scrollee.

Busca las dos instancias de este patrón en el archivo (deberían ser
idénticas o casi idénticas):

  <div style="border:1px solid var(--gray-200); border-radius:8px; overflow:hidden;">
    <table class="gc-sub-table" style="width:100%;" id="gc-upsell-table">

Una está dentro de `renderVZUpsellForm()` (vista "By Vehicle" del Step 1) y
la otra dentro de `vzGoUpsellStep2()` (rama donde `upsellMode !== 'vehicles'`,
la vista "Select Vehicles" del Step 2 cuando se empezó por features). NO
toques el wrapper del Cancel table (`gc-cancel-table`, si existe algo
parecido) — el bug es solo en esta tabla de vehículos del upsell.

En AMBOS lugares:

1) Cambia el `overflow:hidden` del div contenedor por `overflow-x:auto` (deja
   el resto de estilos del div igual: borde, border-radius).
2) Cambia `style="width:100%;"` de la tabla por algo como
   `style="width:100%; min-width:900px;"` (ajusta el valor de min-width si
   hace falta, pero que sea suficiente para que las 9 columnas —checkbox,
   Vehicle/Asset, Name, License Plate, +espacio, Order, Start Date, End
   Date— no se compriman por debajo de un ancho legible; puedes calcularlo
   sumando los anchos que ya se usan en los <th>/<td> de esa tabla).
3) No cambies el ancho fijo `width:44px` del `<th>`/`<td>` del checkbox —
   una vez la tabla tenga min-width y el wrapper scrollee, esa columna
   debería volver a verse normal sin tocarla.

Verifica en el navegador, con la ventana angosta o el zoom alto (para forzar
que la tabla no quepa): que aparece una barra de scroll horizontal dentro
del wrapper de la tabla (no que la página entera scrollee), que las 6
columnas de datos se ven completas y legibles, y que el checkbox de cada
fila se ve como el resto de checkboxes del Design System (redondo/cuadrado
según corresponda, sin comprimirse ni deformarse). Prueba tanto la vista
"By Vehicle" (Step 1, modo vehicles) como la vista "Select Vehicles" (Step 2,
modo features) para confirmar que el fix aplicó en los dos lugares.
```

---

### Fase 3 — Panel de resumen de MSA — ⚠️ Reemplazada por la Fase 3.2 (ver abajo)

Esta fase se implementó primero dentro del modal de Upsell (Step 1). Catalina probó esa ubicación y pidió moverla: **el dashboard de MSA ya no debe vivir en el modal de Upsell** — debe vivir en la pantalla de Drafting, justo después del breadcrumb. El detalle de qué había en el modal queda documentado abajo por contexto histórico; el trabajo pendiente real es la Fase 3.2.

<details>
<summary>Detalle histórico (ya no aplica — ver Fase 3.2)</summary>

**Estado (histórico):** Catalina ejecutó primero una versión "barra horizontal" (una sola línea con separadores `|`), la probó y no le convenció visualmente. Se rediseñó como card tipo dashboard, directamente en `valucal_existing_accounts.html`, con aprobación explícita para esa iteración puntual (ver nota de flujo de trabajo al inicio del documento). Se verificó con pruebas automatizadas en navegador (Playwright headless) que el panel renderizaba, se actualizaba en vivo, y el botón Edit abría la URL correcta — pero vivía dentro del modal de Upsell, que es justo lo que se está retirando en la Fase 3.2.

**Ubicación que tenía (ya no aplica):** dentro de `renderVZUpsellForm()` → Step 1 (`#gc-tx-upsell-step1`), como primer elemento antes del selector de modo.

**Diseño del dashboard** (función `renderMsaCommitmentPanel()`, ~línea 13467 de `valucal_existing_accounts.html` — esta función SÍ se reutiliza en la Fase 3.2, solo cambia dónde se inserta su resultado):
- Fila superior: título "MSA Commitment" + chip con el MSA ID + botón **Edit** a la derecha.
- Grid de métricas debajo: Term, Ramp-up period, Negotiated price, Minimum commitment, Projected quantity.
- Barra de progreso + mensaje ("N more vehicles needed..." / "Minimum commitment met") al final.
- El botón Edit llama a `openMsaAccountSetup()`, que hace `window.open('account-setup.html?section=msa', '_blank')` — ver Fase 3.1.

</details>

---

### Fase 3.1 — Módulo MSA nuevo en Account Setup (para que el botón Edit tenga destino) ✅ Completado

**Por qué se agregó:** Catalina pidió que el botón Edit del dashboard "te lleve al account setup directamente al módulo de MSA" — pero `account-setup.html` no tenía ningún módulo de MSA (se había confirmado esto desde el relevamiento inicial). Se creó desde cero, con aprobación explícita para esta iteración puntual.

**Qué se implementó en `app/demos/account-setup.html`:**
- `state.msa = { id, termMonths, rampUpPeriodMonths, negotiatedPricePerVehicle, minQuantityCommitment }` — mock independiente del `DEMO_MSA` de `valucal_existing_accounts.html` (son dos documentos HTML separados, sin estado compartido en tiempo real; se usaron los mismos valores iniciales solo por consistencia visual entre pantallas).
- Nueva sección `#section-msa` ("MSA — Master Subscription Agreement"), agregada a `SECTIONS` y a `overviewSections`, con el mismo patrón visual de field-row/edit-row que ya usa el resto de la página (como el campo "Cost center" de Owner).
- 4 campos editables (Contract term, Ramp-up period, Negotiated price per vehicle, Minimum quantity commitment) vía `startEditMsa/saveEditMsa/cancelEditMsa`, más el MSA ID como dato de solo lectura ("From CRM").
- `init()` ahora lee `?section=` de la URL (`new URLSearchParams(window.location.search).get('section')`) y navega directo a esa sección si es válida — así `account-setup.html?section=msa` aterriza directo en el módulo de MSA.

**Hallazgo colateral (no se corrigió, fuera de alcance):** la función `renderOverview()` que arma la grilla de tarjetas "Account info / Billing / Fleet / Owner / Compliance" con botones "Go" es código muerto — el `#overview-grid` que necesita no existe en ningún lado del HTML, así que esa función nunca se ejecuta hoy en la página real. Si en algún momento se retoma esa grilla, la entrada de "MSA" ya quedó agregada en `overviewSections` para que aparezca junto a las demás.

---

### Fase 3.2 — Mover el dashboard del modal de Upsell a Drafting, después del breadcrumb ✅ Completado (verificado 2026-08-26) — el rediseño visual quedó pendiente, ver Fase 3.3

**Verificación (revisé el archivo real, no solo lo que pedía el prompt):** la parte de UBICACIÓN sí se hizo, y bien:
- Se quitó por completo del modal de Upsell — `#gc-tx-upsell-step1` ya no tiene ningún `msa-commitment-panel`.
- Se agregó `<div id="msa-commitment-drafting-slot" style="margin-bottom:16px;"></div>` justo después del `</nav>` del breadcrumb en `#screen-drafting` (línea ~4880).
- Se creó `renderDraftingMsaCommitmentPanel()` (~línea 13612) que llena ese slot, y `getDraftingMsaAdditionalVehicles()`, que calcula el total de unidades a través de todas las opciones de la propuesta actual — un plus respecto a lo pedido: el dashboard en Drafting ya refleja "cuánto llevo armado en este draft", no solo el estado ya contratado.
- Está bien conectado: se llama al entrar a Drafting y cada vez que cambian las opciones (varios call sites, incluyendo uno condicionado a `screen === 'drafting'`).

**Lo que NO se hizo:** el rediseño visual a una sola línea compacta (sin fondo, sin mayúsculas sostenidas, bold solo en valores, separadores). `renderMsaCommitmentPanel()` sigue exactamente igual que antes — el grid de 5 tarjetas con fondo gris (`.gc-tx-impact` / `background: var(--stone)`) y etiquetas en mayúsculas. Por eso Catalina lo sigue viendo saturado: el prompt pedía dos cosas a la vez y solo se ejecutó la mitad (mover de lugar), no el rediseño. Para evitar que se vuelva a saltar, el rediseño queda ahora como su propio prompt independiente — ver Fase 3.3.

**Contexto para el agente:**
---

### Fase 3.3 — Rediseñar el dashboard a una sola línea compacta ✅ Completado (2026-08-26) — generó scroll horizontal no deseado, superseded por Fase 3.4

**Por qué existe esta fase por separado:** el prompt de la Fase 3.2 pedía mover el dashboard Y rediseñarlo en un solo prompt; el agente en VS Code solo hizo la mitad (el traslado) y se saltó el rediseño. Para que no se vuelva a saltar, este prompt hace UNA sola cosa: cambiar el diseño visual de `renderMsaCommitmentPanel()`, sin tocar dónde vive ni cómo se llama.

**Estado real verificado del código (2026-08-26, no es lo que se pidió — es lo que hay):**
- La función a rediseñar es `renderMsaCommitmentPanel(selectedVehicleCount = 0)` (~línea 13467 de `valucal_existing_accounts.html`). Hoy devuelve una card: fila de título con ícono + "MSA Commitment" + chip del MSA ID + botón Edit, luego un `<div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(130px, 1fr));">` con 5 tarjetas (Term, Ramp-up period, Negotiated price, Minimum commitment, Projected quantity) cada una con su label en `text-transform:uppercase`, y al final una barra de progreso + mensaje en una fila aparte.
- Todo eso vive dentro de `<div class="gc-tx-impact" style="...">` — esa clase trae `background: var(--stone)` (el fondo gris que Catalina no quiere). `.gc-tx-impact` es compartida con el bloque "Pricing Preview" del flujo de Cancel (~línea 14111) — no tocar esa clase en el CSS global, solo dejar de usarla en este panel.
- Quien llama a esta función hoy es `renderDraftingMsaCommitmentPanel()` (~línea 13612), que la pinta dentro de `<div id="msa-commitment-drafting-slot">` (ya ubicado correctamente después del breadcrumb de Drafting — eso NO se toca en esta fase).
- El botón Edit (`onclick="openMsaAccountSetup()"`) y el ícono `handshake` se mantienen.

**Se ejecutó y quedó exactamente como se pidió** — una sola línea, sin fondo, sin mayúsculas, valores en negrita, separadores `|`, y el mensaje de estado como texto ("45/60 (75%) - 15 more vehicles needed", sin barra visual). El problema: cuando no cabe, esa línea hace scroll horizontal propio (`overflow-x:auto` + `white-space:nowrap`), y Catalina probándolo en su pantalla real no quiere ese scroll — prefiere que la información se acomode en más de una fila dentro de un contenedor con borde, no que scrollee.

---

### Fase 3.4 — Contenedor con borde, título arriba, y cada dato como su propia mini-sección (label arriba, valor abajo) — sin scroll horizontal ✅ Completado (verificado 2026-08-26) — se ejecutó bien en cuanto a layout, pero la verificación encontró un bug de datos (MSA ID incorrecto), corregido en la Fase 3.5

**Pedido de Catalina (después de ver la Fase 3.3 en su pantalla):**
- Que el dashboard esté en un **contenedor con borde** (no solo el `border-bottom` que dejó la Fase 3.3).
- Un **título "MSA Commitment" arriba**, separado del contenido.
- Debajo, cada dato (Term, Ramp-up, Negotiated price, Minimum commitment, Projected quantity, estado) como su propia mini-sección: **la etiqueta arriba, el valor abajo** (en vez de "Etiqueta valor" en una misma línea como quedó en la 3.3).
- **Nada de scroll horizontal** — si no caben todos los datos en una fila, que pasen a una segunda fila (wrap), no que aparezca una barra de scroll.
- Sigue sin barra de progreso visual — el contador de texto que ya quedó de la Fase 3.3 ("45/60 (75%)") está bien, eso no cambia.
- El MSA ID puede mostrarse tal cual (el código, sin nada elaborado) — el chip simple que ya existe está bien.

**En una frase:** es el mismo contenido de la Fase 3.3 (sin fondo gris pesado, sin mayúsculas, sin barra de progreso), pero organizado como el diseño original de la Fase 3 (mini-tarjetas con label arriba / valor abajo, dentro de un contenedor con borde) en vez de una sola línea con scroll — la diferencia es que esta vez las mini-tarjetas deben poder pasar a una segunda fila (`flex-wrap`) en vez de forzar un ancho mínimo que dispare el scroll.

**Prompt para pegar en el agente:**

```
Trabaja en app/demos/valucal_existing_accounts.html.

Objetivo: modificar SOLO el contenido visual de `renderMsaCommitmentPanel(selectedVehicleCount = 0)`
(~línea 13467). No cambies su firma ni quién la llama
(`renderDraftingMsaCommitmentPanel()`), no cambies el slot donde se pinta
(`#msa-commitment-drafting-slot`).

Hoy la función devuelve una sola línea horizontal con scroll propio
(`overflow-x:auto; white-space:nowrap`) uniendo todos los datos con
separadores "|". Reemplázala por este layout:

1. Contenedor exterior CON BORDE (no solo un border-bottom): por ejemplo
   `border:1px solid var(--gray-200); border-radius:8px; padding:12px 16px;
   margin-bottom:16px;`. Sin color de fondo (no uses `.gc-tx-impact`, sigue
   siendo compartida con "Pricing Preview" del flujo de Cancel — no la
   edites, simplemente no la uses aquí).

2. Fila de título, arriba del todo, separada del resto: ícono handshake +
   "MSA Commitment" + el chip del MSA ID (`DEMO_MSA.id`, el mismo chip
   simple que ya existe) a la izquierda, y el botón Edit
   (`onclick="openMsaAccountSetup()"`) a la derecha — este botón se
   mantiene igual que en la Fase 3.3. Un margin-bottom chico para separar
   esta fila del contenido de abajo (ej. `margin-bottom:12px;`), y opcional
   un `border-bottom:1px solid var(--gray-100); padding-bottom:10px;` si
   ayuda a diferenciar visualmente el título del contenido.

3. Debajo del título, un contenedor flex CON WRAP (`display:flex;
   flex-wrap:wrap; gap:12px 24px;`) — nada de `overflow-x:auto` ni
   `white-space:nowrap` aquí; si no caben todos los datos en una fila,
   deben pasar a una segunda fila dentro del mismo contenedor, sin scroll.

4. Cada dato es su propia mini-sección, con la etiqueta ARRIBA (peso
   normal, sin mayúsculas sostenidas, tamaño chico, ej. `font-size:11px;
   color:var(--gray-500);`) y el valor ABAJO en negrita (ej.
   `font-size:13px; font-weight:700;`). Ejemplo de estructura por dato:

     <div>
       <div style="font-size:11px; color:var(--gray-500); margin-bottom:2px;">Term</div>
       <div style="font-size:13px; font-weight:700;">36 months</div>
     </div>

   Datos a incluir, en este orden: Term, Ramp-up period, Negotiated price
   (con `formatMoney`), Minimum commitment, Projected quantity, y un
   último dato de estado con label "Status" (o similar) y como valor el
   contador de texto que ya se usa hoy (ej. "45/60 (75%) - 15 more
   vehicles needed" / "45/60 (75%) - Minimum commitment met"), en negrita
   y en color `var(--orange)` si falta o `var(--green)` si ya se cumplió
   el mínimo. NO agregues ninguna barra de progreso visual — el contador
   de texto es suficiente, eso ya quedó bien en la Fase 3.3.

Verifica en el navegador, achicando el ancho de la ventana o el panel
contenedor: el dashboard se ve como un bloque con borde, con "MSA
Commitment" arriba, y las mini-secciones (label arriba / valor abajo) se
reorganizan en una segunda fila cuando no caben — en ningún momento debe
aparecer una barra de scroll horizontal dentro del dashboard. Confirma
también que el botón Edit sigue funcionando y que los números se siguen
actualizando correctamente al crear/editar opciones en Drafting.
```

**Nota (2026-08-26):** esta subsección tenía duplicado por error el prompt de la Fase 3.3 (diseño de una sola línea con scroll). Se quitó de aquí porque no es lo que se ejecutó ni lo que queremos — lo que realmente corrió y quedó en el código es el prompt de arriba (contenedor con borde + mini-secciones + wrap). Ver Fase 3.5 para lo que sigue.

---

### Fase 3.5 — Consolidar campos redundantes + corregir bug del MSA ID 🆕 Pendiente (2026-08-26)

**Pedido de Catalina (después de ver la Fase 3.4 en su pantalla, con screenshot):**
> "para los campos de MSA que estamos mostrando necesito homologar estos si te pones a ver básicamente estamos dando la misma información en 3 campos..lo del contador esta bueno"

Los 3 campos que se solapan son **Minimum commitment** (60 vehicles), **Projected quantity** (45 vehicles) y **Status** (45/60) — el campo Status ya contiene la misma información que los otros dos combinados. Catalina confirmó que el formato de contador ("45/60") le gusta, así que ese es el que se conserva; los otros dos se eliminan como campos separados.

**1 problema que encontré verificando el código actual (Catalina no lo había visto todavía, aprovechamos este mismo prompt para corregirlo):**
- El MSA ID se está mostrando como `'20204.0391'` (un valor fijo, mal escrito) en vez de usar `DEMO_MSA.id` (que es `'MSA-2024-0391'`). Es un typo que quedó de la Fase 3.4.

**Nota:** el botón Edit que tenía el dashboard en versiones anteriores fue removido intencionalmente por Catalina — no es un bug, no se repone en esta fase.

**Estado real verificado del código (2026-08-26):**

```javascript
function renderMsaCommitmentPanel(selectedVehicleCount = 0) {
  const status = getMsaCommitmentStatus(selectedVehicleCount);
  const needsMore = status.remainingToCommitment > 0;
  const projectedQty = status.contractedQty;
  const msaIdDisplay = '20204.0391';
  const statusTextCompact = `${projectedQty}/${status.minCommitment}`;

  const metric = (label, value, valueStyle = '', isFirst = false) => `
        <div style="min-width:128px; padding-left:${isFirst ? '0' : '16px'}; border-left:${isFirst ? 'none' : '1px solid var(--gray-200)'};">
          <div style="font-size:11px; color:var(--gray-500); margin-bottom:2px;">${label}</div>
          <div style="font-size:13px; font-weight:700; ${valueStyle}">${value}</div>
        </div>`;

  return `
    <div style="margin-bottom:16px; background:var(--white); border:1px solid var(--gray-200); border-radius:8px; padding:12px 16px;">
      <div style="display:flex; align-items:center; gap:12px; margin-bottom:6px; padding-bottom:6px;">
        <div style="display:flex; align-items:center; gap:8px; min-width:0;">
          <span style="font-size:14px; font-weight:700;">MSA Commitment</span>
        </div>
      </div>

      <div style="display:flex; flex-wrap:wrap; gap:12px 24px; align-items:flex-start;">
        ${metric('ID', `${msaIdDisplay}`, '', true)}
        ${metric('Term', `${status.termMonths} months`)}
        ${metric('Ramp-up period', `${status.rampUpPeriodMonths} months`)}
        ${metric('Negotiated price', `${formatMoney(status.negotiatedPricePerVehicle)}/vehicle/mo`)}
        ${metric('Minimum commitment', `${status.minCommitment} vehicles`)}
        ${metric('Projected quantity', `${projectedQty} vehicles`)}
        ${metric('Status', statusTextCompact, `color:${needsMore ? 'var(--orange)' : 'var(--green)'}; white-space:nowrap;`)}
      </div>
    </div>`;
}
```

**En una frase:** mismo contenedor y mismas mini-secciones de la Fase 3.4, pero con un solo campo de cantidad/estado en vez de tres, y el MSA ID correcto (sin tocar el botón Edit, que fue removido a propósito).

**Prompt para pegar en el agente:**

```
Trabaja en app/demos/valucal_existing_accounts.html.

Objetivo: modificar SOLO el contenido de la función
`renderMsaCommitmentPanel(selectedVehicleCount = 0)`. No cambies su firma,
no cambies quién la llama (`renderDraftingMsaCommitmentPanel()`), no
cambies el slot donde se pinta (`#msa-commitment-drafting-slot`), y no
cambies el contenedor con borde ni el estilo de las mini-secciones (label
arriba / valor abajo) que ya quedaron bien en el rediseño anterior. No
agregues ningún botón Edit — se removió intencionalmente y debe seguir
sin estar. Este prompt hace 3 cosas puntuales dentro de esa misma función:

1. CONSOLIDAR CAMPOS REDUNDANTES. Hoy la función pinta tres mini-secciones
   que muestran la misma información repetida: "Minimum commitment" (ej.
   "60 vehicles"), "Projected quantity" (ej. "45 vehicles"), y "Status"
   (ej. "45/60", en naranja o verde). Elimina las mini-secciones de
   "Minimum commitment" y "Projected quantity" como campos separados, y
   deja SOLO UNA mini-sección que combine esa información usando el mismo
   formato de contador que ya existe (`${projectedQty}/${status.minCommitment}`),
   con el mismo color condicional (naranja si `needsMore`, verde si no).
   Cambia el label de esa mini-sección de "Status" a algo más descriptivo
   como "Commitment" o "Quantity" (tu criterio, que deje claro que el
   número es "cantidad proyectada / mínimo comprometido"), y el valor
   debe incluir la palabra **"units"** al final (NO "vehicles" — ya se
   decidió usar "units" en todo el dashboard de MSA, ver punto 3 abajo),
   ej. "45/60 units".

3. RENOMBRAR "vehicles" → "units" en todo lo que quede visible en este
   panel. Ya no debería quedar ninguna mención de la palabra "vehicles"
   como texto visible al usuario dentro de `renderMsaCommitmentPanel()`
   (los nombres internos de variables/parámetros como
   `selectedVehicleCount` o `additionalVehicles` NO se tocan, esto es solo
   sobre texto que ve el usuario en pantalla). Alcance de este cambio:
   SOLO este dashboard de MSA en Drafting — no toques la tabla de
   vehículos del Upsell ni ninguna otra pantalla, eso se evalúa aparte más
   adelante.

2. CORREGIR EL MSA ID. La variable `msaIdDisplay` está hardcodeada como
   `'20204.0391'` (un valor incorrecto). Cámbiala para que use el valor
   real: `const msaIdDisplay = DEMO_MSA.id;` (el objeto `DEMO_MSA` ya
   existe en el archivo con el campo `id`, que hoy vale `'MSA-2024-0391'`).

No cambies nada más: no agregues ningún botón Edit (se removió
intencionalmente), ni cambies el orden de Term / Ramp-up period /
Negotiated price, ni los estilos del contenedor exterior, ni el
`flex-wrap` de la fila de mini-secciones.

Verifica en el navegador (recarga con `?route=configure-bundle` o
navegando normal a Drafting):
- El dashboard ahora muestra: ID (con el valor correcto "MSA-2024-0391"),
  Term, Ramp-up period, Negotiated price, y UN solo campo de cantidad tipo
  "45/60 units" en naranja o verde según corresponda — ya no aparecen
  "Minimum commitment" y "Projected quantity" como campos separados, y ya
  no aparece la palabra "vehicles" en ningún texto de este dashboard.
- Sigue sin haber ningún botón Edit en el dashboard.
- Los números se siguen actualizando correctamente al crear/editar
  opciones en Drafting.
```

---

### Fase 3.6 — Separar el precio negociado en Vehicle Tracking vs Powered Asset Tracking 🆕 Pendiente (2026-08-26)

**Contexto y decisión de Catalina:** en la llamada, Anil pidió considerar separar "asset trackers" de "vehicle tracking" como conceptos distintos (no un solo conteo genérico). Catalina confirmó que **al final se optó por separarlos**, y precisó el alcance para esta fase:
- Se separa el **precio negociado** en dos: "Vehicle Tracking" y "Powered Asset Tracking" (mismos nombres que ya existen en Account Setup).
- La **cantidad** (compromiso mínimo / cantidad contratada) **NO se separa** — se queda como el contador único "45/60" que dejó la Fase 3.5.
- El dashboard de Drafting **sigue sin botón Edit** — no se reintroduce ningún link hacia Account Setup.

**Por qué estos nombres exactos:** al verificar el código encontré que `account-setup.html` ya tiene una card "Master Service Agreement" con los campos `msaVehicleTrackingPrice` ("Vehicle Tracking", $/unidad/mes) y `msaPoweredAssetTrackingPrice` ("Powered Asset Tracking", $/unidad/mes) como dos campos de precio ya separados (aunque hoy están vacíos ahí, es un formulario en blanco). Para que el dashboard de Drafting hable el mismo idioma que Account Setup, usamos exactamente esos dos nombres.

**Estado real verificado del código (2026-08-26) — solo 3 referencias en todo el archivo, todas dentro de la feature de MSA, así que es seguro renombrar sin romper nada más:**

```javascript
// 1. DEMO_MSA (~línea 7347)
const DEMO_MSA = {
  id: 'MSA-2024-0391',
  startDate: '2024-03-15',
  endDate: '2027-07-15',
  termMonths: 36,
  vehicleCount: 45,
  negotiatedPricePerVehicle: 32.50,   // ← a reemplazar
  minQuantityCommitment: 60,
  rampUpPeriodMonths: 6,
};

// 2. getMsaCommitmentStatus() (~línea 7370)
function getMsaCommitmentStatus(additionalVehicles = 0) {
  // ...
  return {
    // ...
    negotiatedPricePerVehicle: Number(DEMO_MSA.negotiatedPricePerVehicle) || 0,  // ← a reemplazar
    rampUpPeriodMonths: Number(DEMO_MSA.rampUpPeriodMonths) || 0,
    termMonths: Number(DEMO_MSA.termMonths) || 0,
  };
}

// 3. renderMsaCommitmentPanel() (~línea 13618, dentro del `<div style="display:flex; flex-wrap:wrap;...">`)
${metric('Negotiated price', `${formatMoney(status.negotiatedPricePerVehicle)}/vehicle/mo`)}   // ← a reemplazar por 2 metrics
```

**Prompt para pegar en el agente:**

```
Trabaja en app/demos/valucal_existing_accounts.html.

Objetivo: separar el precio negociado del MSA en dos valores independientes
— "Vehicle Tracking" y "Powered Asset Tracking" — en vez de un solo
"Negotiated price" combinado. La cantidad (compromiso mínimo / cantidad
contratada) NO cambia, se queda tal cual está. No agregues ningún botón
Edit ni link hacia account-setup.html — el dashboard sigue siendo de solo
lectura sin ese botón.

Haz estos 3 cambios puntuales:

1. En el objeto `DEMO_MSA` (busca ese nombre exacto, ~línea 7347),
   reemplaza el campo `negotiatedPricePerVehicle: 32.50,` por estos dos
   campos:
     vehicleTrackingPrice: 32.50,
     poweredAssetTrackingPrice: 18.00,
   (mantén el mismo valor 32.50 que ya existía para Vehicle Tracking, y usa
   18.00 como mock razonable para Powered Asset Tracking — mismo criterio
   de mock determinístico que ya usa el resto del archivo, no hay que
   conectar nada real).

2. En `getMsaCommitmentStatus()` (busca ese nombre exacto, ~línea 7370),
   reemplaza la línea `negotiatedPricePerVehicle: Number(DEMO_MSA.negotiatedPricePerVehicle) || 0,`
   dentro del objeto que retorna la función por estas dos líneas:
     vehicleTrackingPrice: Number(DEMO_MSA.vehicleTrackingPrice) || 0,
     poweredAssetTrackingPrice: Number(DEMO_MSA.poweredAssetTrackingPrice) || 0,

3. En `renderMsaCommitmentPanel()` (busca ese nombre exacto, ~línea 13618),
   busca la línea que arma el metric de "Negotiated price":
     ${metric('Negotiated price', `${formatMoney(status.negotiatedPricePerVehicle)}/vehicle/mo`)}
   y reemplázala por estas dos líneas (mismo array de mini-secciones,
   mismo orden relativo — donde estaba "Negotiated price" ahora van estas
   dos, una después de la otra):
     ${metric('Vehicle Tracking', `${formatMoney(status.vehicleTrackingPrice)}/unit/mo`)}
     ${metric('Powered Asset Tracking', `${formatMoney(status.poweredAssetTrackingPrice)}/unit/mo`)}
   (nota: aquí usamos "/unit/mo" en vez de "/vehicle/mo" — es literalmente
   el mismo texto "per unit per month" que ya usa Account Setup para estos
   dos campos de precio. La palabra "vehicles" del contador de cantidad ya
   se corrige aparte, en la Fase 3.5 — con las Fases 3.5 y 3.6 ya no debería
   quedar ninguna mención de "vehicles" como texto visible en este
   dashboard).

No cambies nada más: ni el contenedor con borde, ni el `flex-wrap`, ni el
contador de cantidad consolidado, ni el orden de Term/Ramp-up respecto a
estos campos de precio (Vehicle Tracking y Powered Asset Tracking quedan
donde estaba "Negotiated price").

Verifica en el navegador (recarga con `?route=configure-bundle` o
navegando normal a Drafting): el dashboard ahora muestra dos
mini-secciones de precio separadas — "Vehicle Tracking" ($32.50/unit/mo) y
"Powered Asset Tracking" ($18.00/unit/mo) — en vez de una sola "Negotiated
price". El resto del dashboard (ID, Term, Ramp-up period, el contador de
cantidad) no cambia. Sigue sin haber ningún botón Edit.
```

**Nota (queda pendiente, NO parte de este prompt):** la separación de la CANTIDAD (compromiso mínimo / cantidad contratada) en Vehicle Tracking vs Powered Asset Tracking queda fuera de esta fase — ver sección 2, decisiones pendientes. (El rename de "vehicles" → "units" del contador de cantidad ya no es un pendiente aparte: se hace dentro de la Fase 3.5.)

---

### Fase 3.7 — Agregar las fechas al dashboard (MSA/Service + Contract, como rangos) 🆕 Pendiente (2026-08-26)

**Contexto:** ver el mapeo completo en la sección 2.1. Catalina decidió implementar ya, sin esperar confirmación de Anil/Madhuri, con esta lectura: **"MSA Start/End Date" y "Service Start/End Date" son el mismo par** (el servicio corre durante toda la vigencia del MSA), y **"Contract Start/End Date" es un par aparte**, ligado al registro de Contract que se crea en cada evento de creación de contrato. Si esta lectura resulta no ser la correcta al validarla más adelante, se ajusta con otro prompt puntual — mismo patrón que ya usamos varias veces en este plan.

**Decisión de formato (para ahorrar espacio):** cada par de fechas va en UNA sola mini-sección con las dos fechas separadas por un guion, ej. `03/15/2024 - 07/15/2027` — no dos mini-secciones separadas de "Start"/"End".

**Estado real verificado del código (2026-08-26):**
- `DEMO_MSA` (~línea 7347) ya tiene `startDate: '2024-03-15'` y `endDate: '2027-07-15'` — hoy estos dos campos NO se usan en ningún otro lado del archivo salvo dentro de la propia definición (verificado con una búsqueda de `DEMO_MSA.startDate` / `DEMO_MSA.endDate` — cero resultados fuera de la definición), así que es seguro reutilizarlos como el par "MSA / Service" sin romper nada.
- No existe ningún campo de fecha de Contract todavía — hay que agregarlo como mock nuevo.
- No existe ninguna función para formatear fechas tipo `MM/DD/YYYY` en el archivo (se buscó `formatDate`/`fmtDate`/`vzFormatDate`, no aparece nada) — hay que agregar una chiquita, seguro el mismo patrón que `formatMoney()` (~línea 7445).

**Prompt para pegar en el agente:**

```
Trabaja en app/demos/valucal_existing_accounts.html.

Objetivo: agregar 2 mini-secciones de fechas al dashboard de MSA
(`renderMsaCommitmentPanel()`) — una para "MSA / Service" y otra para
"Contract" — cada una mostrando un rango "fecha - fecha" en un solo campo,
no fechas de inicio/fin separadas.

Haz estos 4 cambios:

1. Agrega una función pequeña de formato de fecha, cerca de `formatMoney()`
   (~línea 7445), que convierta 'YYYY-MM-DD' a 'MM/DD/YYYY':

     function formatShortDate(isoDate) {
       if (!isoDate) return '';
       const [y, m, d] = String(isoDate).split('-');
       if (!y || !m || !d) return isoDate;
       return `${m}/${d}/${y}`;
     }

2. En el objeto `DEMO_MSA` (~línea 7347), agrega 2 campos nuevos de mock
   para las fechas del Contract (los campos `startDate`/`endDate` que ya
   existen ahí se usan para el par "MSA / Service", no hace falta
   agregarlos de nuevo):

     contractStartDate: '2026-06-01',
     contractEndDate: '2027-07-15',

3. En `getMsaCommitmentStatus()` (~línea 7370), agrega estos 4 campos al
   objeto que retorna la función (junto a los demás `return { ... }`):

     msaStartDate: DEMO_MSA.startDate,
     msaEndDate: DEMO_MSA.endDate,
     contractStartDate: DEMO_MSA.contractStartDate,
     contractEndDate: DEMO_MSA.contractEndDate,

4. En `renderMsaCommitmentPanel()` (~línea 13618), agrega 2 mini-secciones
   nuevas usando el mismo helper `metric(...)` que ya arma las demás
   mini-secciones — colócalas después de "Ramp-up period" y antes de los
   campos de precio (Vehicle Tracking / Powered Asset Tracking):

     ${metric('MSA / Service', `${formatShortDate(status.msaStartDate)} - ${formatShortDate(status.msaEndDate)}`)}
     ${metric('Contract', `${formatShortDate(status.contractStartDate)} - ${formatShortDate(status.contractEndDate)}`)}

No cambies nada más: ni el contenedor con borde, ni el `flex-wrap`, ni el
resto de las mini-secciones existentes (ID, Term, Ramp-up period, los
campos de precio, el contador de cantidad).

Verifica en el navegador (recarga con `?route=configure-bundle` o
navegando normal a Drafting): el dashboard ahora muestra 2 mini-secciones
nuevas — "MSA / Service" con "03/15/2024 - 07/15/2027", y "Contract" con
"06/01/2026 - 07/15/2027" — cada una en un solo renglón de texto (fecha -
fecha), sin quedar cortadas. Si no caben todas las mini-secciones en una
fila, deben pasar a una segunda fila (el mismo `flex-wrap` de siempre), sin
scroll horizontal. El resto del dashboard no cambia.
```

**Nota de verificación (2026-08-26):** las Fases 3.5, 3.6 y 3.7 ya se corrieron y el dashboard quedó tal como se pidió (con pequeñas variaciones de nombre hechas por el agente en VS Code, todas dentro de lo esperado: el label quedó "Service date"/"Contract date" en vez de "MSA / Service"/"Contract", el ID se muestra como "MSA-0391", y el campo de cantidad se llama "Commitment" con sufijo "units"). Base de código verificada antes de escribir las Fases 3.8 y 3.9 de abajo.

---

### Fase 3.8 — Agregar "Minimum spend commitment" al dashboard de Drafting 🆕 Pendiente (2026-08-26)

**Contexto:** un colega de Catalina (fuera de la llamada original con Anil) pidió, a raíz de una revisión aparte, quitar las menciones de ETF/ECF ("Early Termination/Cancellation Fee") y agregar en su lugar un **"Minimum Spend Commitment"** — un piso de gasto mensual en dólares que el cliente debe alcanzar, sin importar la mezcla real de unidades (a diferencia de "Minimum quantity commitment", que es un piso de CANTIDAD, no de dinero). Por ahora Catalina solo pidió **agregar** este campo nuevo al dashboard y a Account Setup — la remoción de ETF/ECF (que solo existe en el flujo de Cancelación, verificado por búsqueda en todo el proyecto — cero menciones de "ETF", 5 menciones de "ECF" solo en Cancelación) queda como un pedido aparte, todavía no se toca en esta fase.

**Estado real verificado del código (2026-08-26) — el dashboard ya incorpora las Fases 3.5/3.6/3.7:**

```javascript
// DEMO_MSA actual:
const DEMO_MSA = {
  id: 'MSA-2024-0391',
  startDate: '2024-03-15',
  endDate: '2027-07-15',
  contractStartDate: '2026-06-01',
  contractEndDate: '2027-07-15',
  termMonths: 36,
  vehicleCount: 45,
  vehicleTrackingPrice: 32.50,
  poweredAssetTrackingPrice: 18.00,
  minQuantityCommitment: 60,
  rampUpPeriodMonths: 6,
};

// getMsaCommitmentStatus() ya retorna minCommitment, contractedQty, vehicleTrackingPrice,
// poweredAssetTrackingPrice, msaStartDate/EndDate, contractStartDate/EndDate, rampUpPeriodMonths, termMonths.

// renderMsaCommitmentPanel() ya pinta 7 mini-secciones: Service date, Term, Ramp-up period,
// Contract date, Vehicle Tracking, Powered Asset Tracking, Commitment (ej. "45/60 units").
```

**Prompt para pegar en el agente:**

```
Trabaja en app/demos/valucal_existing_accounts.html.

Objetivo: agregar UNA mini-sección nueva al dashboard de MSA —
"Minimum spend commitment" — un piso de gasto MENSUAL en dólares,
independiente del piso de cantidad ("Commitment", en unidades) que ya
existe. No quites ni cambies ninguna mini-sección existente.

Haz estos 3 cambios:

1. En el objeto `DEMO_MSA` (busca ese nombre exacto), agrega un campo
   mock nuevo, junto a `minQuantityCommitment: 60,`:

     minimumSpendCommitment: 1950.00,

2. En `getMsaCommitmentStatus()` (busca ese nombre exacto), agrega este
   campo al objeto que retorna la función:

     minimumSpendCommitment: Number(DEMO_MSA.minimumSpendCommitment) || 0,

3. En `renderMsaCommitmentPanel()` (busca ese nombre exacto), agrega una
   mini-sección nueva usando el mismo helper `metric(...)` que arma las
   demás, colócala inmediatamente después de la mini-sección "Commitment"
   (la de cantidad, "45/60 units"):

     ${metric('Minimum spend commitment', `${formatMoney(status.minimumSpendCommitment)}<span style="font-size:12px; color:var(--black);">/mo</span>`)}

No cambies nada más: ni el contenedor con borde, ni el `flex-wrap`, ni las
demás mini-secciones (Service date, Term, Ramp-up period, Contract date,
Vehicle Tracking, Powered Asset Tracking, Commitment).

Verifica en el navegador (recarga con `?route=configure-bundle` o
navegando normal a Drafting): el dashboard ahora muestra una mini-sección
nueva "Minimum spend commitment" con el valor "$1,950.00/mo", ubicada
justo después de "Commitment". El resto del dashboard no cambia.
```

---

### Fase 3.9 — Agregar "Minimum spend commitment" a Account Setup 🆕 Pendiente (2026-08-26)

**Contexto:** mismo pedido que la Fase 3.8, pero del lado de Account Setup — agregar el campo editable ahí también, siguiendo el mismo patrón que ya usan los demás campos de la card "Master Service Agreement".

**Estado real verificado del código (2026-08-26):**
- La card "Master Service Agreement" vive en `account-setup.html`, dentro de la sección "Negotiated price and commitment". El último campo de esa sub-sección es `msaMinimumQuantityCommitment` (~línea 649), justo antes de un `<div class="divider"></div>` que separa esta sub-sección de "Term".
- El patrón de cada campo son 4 piezas que hay que actualizar juntas: (a) el bloque HTML `field-row`/`edit-row` con su `id="row-<campo>"` / `id="edit-<campo>"`, (b) `state.accountInfo.<campo>` (~línea 1042, ya con valores mock reales cargados), (c) `fieldLabels.<campo>` (~línea 1265, el label legible), (d) `displayValues.<campo>` (~línea 1286, cómo se formatea en modo lectura), y (e) el array `msaFields` (~línea 1830) que se usa para pre-poblar los valores y calcular el badge "N items pending" — hoy son 7 campos con el badge "7 items pending".

**Prompt para pegar en el agente:**

```
Trabaja en app/demos/account-setup.html.

Objetivo: agregar un campo editable nuevo — "Minimum spend commitment" —
a la card "Master Service Agreement", dentro de la sub-sección
"Negotiated price and commitment", justo después del campo existente
"Minimum quantity commitment" y antes del <div class="divider"></div>
que sigue. Usa exactamente el mismo patrón HTML de field-row/edit-row que
ya usan los demás campos de esa card (busca el bloque de
`id="row-msaMinimumQuantityCommitment"` como referencia exacta de
estructura).

Haz estos 5 cambios, todos con el nuevo campo `msaMinimumSpendCommitment`:

1. HTML: agrega un bloque `<div class="field-row" id="row-msaMinimumSpendCommitment">`
   y su correspondiente `<div class="field-row hidden" id="edit-msaMinimumSpendCommitment">`,
   copiando la estructura exacta del bloque de "Minimum quantity commitment"
   que está justo arriba, pero:
   - Label: "Minimum spend commitment"
   - Hint: "The dollar floor billed monthly, regardless of the actual mix of SKUs."
   - El input debe ser `type="number" min="0" step="50" placeholder="e.g. 1950.00"`
     (en vez de `step="1"`, porque esto es un valor en dólares, no una
     cantidad de unidades)
   - Los botones Save/Cancel deben llamar `saveEdit('msaMinimumSpendCommitment')`
     y `cancelEdit('msaMinimumSpendCommitment')`

2. En `state.accountInfo` (busca ese objeto), agrega junto a
   `msaMinimumQuantityCommitment: '60',`:

     msaMinimumSpendCommitment: '1950.00',

3. En `fieldLabels` (busca ese objeto exacto), agrega junto a
   `msaMinimumQuantityCommitment: 'Minimum quantity commitment',`:

     msaMinimumSpendCommitment: 'Minimum spend commitment',

4. En `displayValues` (busca ese objeto exacto), agrega junto a
   `msaMinimumQuantityCommitment: v => v ? \`${v} units\` : '--',`:

     msaMinimumSpendCommitment: v => v ? `$${Number(v).toFixed(2)}/mo` : '--',

5. En el array `msaFields` (busca esa variable exacta, ~línea 1830),
   agrega `'msaMinimumSpendCommitment'` a la lista — esto hace que el
   campo se pre-popule al cargar la página y que cuente para el badge
   "N items pending" de la card (pasará de "7 items pending" a "8 items
   pending" si el campo llega vacío, o sigue en "Complete" si ya tiene
   valor).

No cambies ningún otro campo de la card ni el resto de la página.

Verifica en el navegador (recarga account-setup.html, o
account-setup.html?section=msa): la card "Master Service Agreement"
ahora muestra un campo nuevo "Minimum spend commitment" con el valor
"$1,950.00/mo", ubicado justo después de "Minimum quantity commitment" y
antes de la sección "Term". El botón "Edit →" abre el input numérico
correctamente, y Save/Cancel funcionan igual que en los demás campos.
```

---

### Fase 4 — Modal de confirmación de MSA antes de crear el contrato + Record Type "MSA"

**Objetivo:** antes de que se cree el contrato (hoy: botón "Confirm & lock deal" dentro del modal `#confirm-selection-overlay`, función `confirmAndLockDeal()`), mostrar los atributos del MSA en solo lectura para que el usuario confirme, y marcar el contrato resultante con Record Type = "MSA".

**Contexto para el agente:**
- Modal actual: `<div class="overlay" id="confirm-selection-overlay">` (línea ~6152), título "Confirm selection", botón "Confirm & lock deal" → `confirmAndLockDeal()` (línea ~11187) → `closeConfirmModal()` + `navigateToContractReviewFromSelection()` → `enterContractScreen(opt)` (línea ~11197) → `renderContractDoc(opt)` (línea ~11657, genera el documento con "Section 1 — Parties", "Section 2 — Solution & Pricing", "Section 3 — Term & Commitment", etc.)
- Este modal se abre automáticamente desde `openConfirmSelectionModal()` (línea ~11172) tras guardar/validar la cuenta (ver línea ~7269).

**Prompt para pegar en el agente:**

```
Trabaja en app/demos/valucal_existing_accounts.html.

Objetivo: agregar, dentro del modal existente con id
"confirm-selection-overlay" (el que hoy solo dice "This will lock the
quoting session and initiate the contract generation process." y tiene
el botón "Confirm & lock deal" que llama a confirmAndLockDeal()), un
bloque de solo lectura con los atributos del MSA, ANTES del botón de
confirmar.

1) En el HTML del modal (busca `id="confirm-selection-body"`, línea
   ~6156), después del texto actual, agrega un contenedor
   `<div id="confirm-msa-summary"></div>`.

2) Crea una función `renderConfirmMsaSummary()` que devuelva HTML de
   solo lectura (sin inputs) mostrando, usando `getMsaCommitmentStatus()`
   de la Fase 1:
   - Término del contrato (termMonths)
   - Precio negociado por vehículo
   - Cantidad mínima comprometida
   - Período de ramp-up
   - Un texto fijo tipo "These MSA terms are read-only at this step —
     changes are made in Account Setup." (para dejar explícito, igual
     que se acordó en la llamada, que en esta fase NO se puede editar
     acá, solo confirmar)

3) En `openConfirmSelectionModal()` (línea ~11172), justo antes de
   mostrar el overlay, setea
   `document.getElementById('confirm-msa-summary').innerHTML = renderConfirmMsaSummary();`

4) Introduce una variable/estado nuevo, por ejemplo
   `let pendingContractRecordType = 'MSA';` cerca de donde está
   `let selectedOpt = null;` (línea ~11195), y en `confirmAndLockDeal()`
   (línea ~11187) guarda ese valor en el objeto que use `renderContractDoc`
   (por ejemplo `selectedOpt.recordType = pendingContractRecordType;` o
   en `proposalData`, lo que sea consistente con cómo ya viaja `selectedOpt`
   hacia `renderContractDoc`).

5) En `renderContractDoc(opt)` (línea ~11657), dentro de "Section 1 —
   Parties" (el `ds-doc-grid` que hoy muestra Customer / Provider /
   Authorized Signatory / Account Representative), agrega un quinto
   campo:
   - Label: "Record Type"
   - Valor: el `recordType` que llega en `opt` (o 'MSA' si no viene nada,
     como fallback para no romper otros flujos que llamen a
     renderContractDoc sin este campo)

No cambies el copy del botón "Confirm & lock deal" en esta fase (eso lo
decide negocio más adelante) y no agregues ningún input editable en este
modal — es explícitamente de solo lectura + confirmar, según lo acordado
en la llamada. Verifica en el navegador el flujo completo: seleccionar
vehículos → guardar/validar cuenta → se abre el modal de confirmación →
se ve el resumen de MSA → clic en "Confirm & lock deal" → se abre la
pantalla de contrato y el documento generado muestra "Record Type: MSA".
```

---

### Fase 5 (backlog — NO implementar todavía)

Explícitamente pospuesto en la llamada: permitir editar los valores del MSA desde el modal de confirmación de la Fase 4. Anil fue claro en que por ahora es "solo para hablar" (talking points) y que la edición se definirá en una discusión de requerimientos de negocio posterior. Dejar como backlog, no como parte de este sprint.

---

## 4. QA / verificación final (prompt de cierre)

Una vez ejecutadas las Fases 1-4, correr esto para verificar que no se rompió nada:

```
Trabaja en app/demos/valucal_existing_accounts.html.

Abre el archivo en un navegador (o revísalo estáticamente) y verifica:

1. El flujo de Upsell/Expansion sigue funcionando de punta a punta:
   seleccionar vehículos → elegir features → ver preview → guardar.
2. La tabla de vehículos del upsell muestra correctamente las columnas
   Order / Start Date / End Date en ambas vistas (By Vehicle y By
   Subscription), con datos legibles (no "undefined", no "NaN", no
   "Invalid Date").
3. El dashboard de MSA commitment aparece en Drafting justo después del
   breadcrumb (siempre visible, sin abrir ningún modal), con los números
   correctos, y YA NO aparece dentro del modal de Upsell/Expansion.
3b. La tabla de vehículos del Upsell (con las columnas Order/Start Date/
   End Date) tiene scroll horizontal cuando no caben todas las columnas, y
   los checkboxes de selección se ven normales (sin aplastarse), tanto en
   la vista "By Vehicle" como en "Select Vehicles".
4. El modal de confirmación antes de crear el contrato muestra el
   resumen de MSA y no tiene ningún campo editable.
5. El documento de contrato generado (Section 1 — Parties) muestra
   "Record Type: MSA".
6. No aparecen errores en la consola del navegador (Console) al recorrer
   todo el flujo.
7. No se rompió ningún flujo existente que no esté relacionado con MSA
   (por ejemplo Cancel, Account Validation, Signature flow) — dales una
   pasada rápida.

Reporta cualquier inconsistencia encontrada en una lista corta antes de
dar el trabajo por terminado.
```

---

## 5. Entregables a compartir (pedido explícito de Anil)

Anil pidió compartir **tres versiones** del HTML con él y con Madi:

1. La versión original de Valu Cal (antes de estos cambios).
2. La versión actual del flujo de upsell (la que ya existía al momento de la llamada).
3. La nueva versión con los cambios de MSA de este plan (Fases 1-4).

Sugerencia: antes de empezar, guarda una copia de `valucal_existing_accounts.html` (por ejemplo `valucal_existing_accounts.pre-msa.html`) para tener a mano la versión "antes" sin tener que revertir git.
