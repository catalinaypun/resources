# Valu Cal MVP - Requirements

> **Purpose:** Provide an ecosystem-compliant entry point for the imported valucal_mvp.html demo.

---

## Context

- **Tool area:** VaLu Cal
- **Target user role:** Sales Rep
- **Entry point:** From the VaLu Cal project list in the Prototype Viewer.

---

## User Stories

| ID    | As a...   | I want to...                       | So that...                             |
|-------|-----------|------------------------------------|----------------------------------------|
| US-01 | Sales Rep | open the MVP prototype directly    | I can review the baseline Valu Cal flow|

---

## Acceptance Criteria

### US-01 - Open MVP screen
- **Given** I select Valu Cal MVP in the viewer
- **When** the flow page loads
- **Then** I can launch valucal_mvp.html in a new tab

---

## States & Edge Cases

| State            | Trigger                             | Expected UI behavior                    |
|------------------|-------------------------------------|-----------------------------------------|
| default          | Flow page loads successfully        | Launch action is visible                |
| loading          | Opening or checking linked resource | Loading messaging can be shown          |
| validation-error | Linked file path is invalid         | Warning state indicates broken link     |

---

## Open Questions

- [ ] Should this flow remain an external link wrapper or be migrated to a native ecosystem HTML page?
