/* ── Proposal history (brief 34, batch 1 — 2026-10-21, per Catalina) ───────────────────────────────
   A medium drawer (VC.drawer, vc-drawer--medium) with the proposal's current status and its activity — status changes
   and documents, newest first, one chronological list (not grouped by stage). Built from a proposal's event log with
   getStageTimeline(events).changes (vc-common.js), the same source as the stepper, so both always agree.
   Entry points: dashboard row kebab "View history" (openQlProposalHistory) and the stepper tooltip link
   (openOpenProposalHistory). A dashboard row that isn't the open proposal uses its sample log (getSampleHistoryEvents),
   which is also what the row opens with.
   Batch 2: the documents preview inside the drawer (two variants, see below). Not yet: the per-option approval lines
   (batch 3). */

// The dashboard row whose live log is proposalHistoryEvents (set when a row opens; cleared for a new proposal).
var historyProposalId = null;

const HISTORY_DRAWER_ID = 'proposal-history-drawer';

function historyEsc(value) {
  return String(value == null ? '' : value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
}

// MM/DD/YYYY h:mm AM/PM — the stepper's format.
function formatHistoryDateTime(at) {
  const date = at instanceof Date ? at : new Date(at);
  if (Number.isNaN(date.getTime())) return '--';
  const day = new Intl.DateTimeFormat('en-US', { month: '2-digit', day: '2-digit', year: 'numeric' }).format(date);
  return `${day} ${new Intl.DateTimeFormat('en-US', { hour: 'numeric', minute: '2-digit' }).format(date)}`;
}

// [{ number }] → "Option 1" / "Options 1, 2" (event design v2: no term in the descriptions).
function historyOptionsSummary(list) {
  const numbers = (list || []).map(item => (item && typeof item === 'object' ? item.number : item)).filter(Boolean);
  if (!numbers.length) return '';
  return `${numbers.length === 1 ? 'Option' : 'Options'} ${numbers.join(', ')}`;
}

// The open proposal's option cards → [{ number }] (number = position among the real options, as the cards read).
function historyOptionsOf(opts) {
  const real = (Array.isArray(options) ? options : []).filter(opt => !opt.msaPreviewFor);
  return (opts || []).map(opt => ({ number: real.indexOf(opt) + 1 })).filter(item => item.number > 0);
}

// "Options 1, 3" from option names ("Option 1", "Option 3") — names are stable while the cards renumber.
function historyOptionNamesSummary(names) {
  const numbers = (names || []).map(name => String(name || '').replace(/^Option\s*/i, '')).filter(Boolean);
  return numbers.length ? `${numbers.length === 1 ? 'Option' : 'Options'} ${numbers.join(', ')}` : '';
}

function findHistoryProposal(proposalId) {
  const existing = typeof isExistingMsaAccount === 'function' && isExistingMsaAccount() && typeof EXISTING_SAMPLE_PROPOSALS !== 'undefined';
  const set = existing ? EXISTING_SAMPLE_PROPOSALS : (typeof QL_PROPOSALS !== 'undefined' ? QL_PROPOSALS : []);
  return set.find(p => p.id === proposalId) || null;
}

function getHistoryContext(proposal) {
  const repName = document.getElementById('gi-rep-name')?.value;
  const isOpen = proposal && historyProposalId === proposal.id;
  return {
    owner: (isOpen && repName) || (proposal && proposal.owner) || repName || 'the rep',
    contact: (window.demoState && demoState.account && demoState.account.contact) || 'the customer',
  };
}

/* A sample proposal's log, dated between its Created (9:10 AM) and Modified (3:40 PM) dates, within business hours: the
   steps its status implies.
   proposal.historyLoop: contract created → canceled to modify the proposal → sent again. */
function getSampleHistoryEvents(proposal) {
  if (!proposal) return [];
  const allOptions = (proposal.options || []).map((_, index) => ({ number: index + 1 }));
  const optionsSummary = historyOptionsSummary(allOptions);
  const selected = proposal.selected != null ? proposal.selected : 0;
  const contract = { optionNumber: selected + 1 };
  const approval = { allOptions: true, role: 'Associate Director', optionsSummary };
  const steps = [['Proposal saved', {}]];
  const add = (title, data) => steps.push([title, data || {}]);
  const contractSteps = ['contract-review', 'awaiting-sig', 'payment', 'svt', 'signed'];
  const reached = status => contractSteps.indexOf(proposal.status) >= contractSteps.indexOf(status);
  if (proposal.historyLoop) {
    add('Proposal sent', { optionsSummary });
    add('Contract created', contract);
    add('Contract returned to drafting');
    add('Proposal saved', { allOptions: false, requestPending: false });
    add('Proposal re-sent', { optionsSummary });
  } else if (proposal.status === 'draft' && proposal.sentBefore) {
    add('Proposal sent', { optionsSummary });
    add('Proposal saved', { allOptions: false, requestPending: false });
  } else if (proposal.status === 'approval' || proposal.status === 'rejected') {
    add('Approval requested', approval);
    if (proposal.status === 'rejected') add('Approval rejected', { role: approval.role, reason: 'Discount above the approved limit' });
  } else if (proposal.status === 'sent' || proposal.status === 'dead' || contractSteps.includes(proposal.status)) {
    add('Proposal sent', { optionsSummary });
    if (reached('contract-review')) add('Contract created', contract);
    if (reached('awaiting-sig')) add('Contract sent');
    if (reached('payment')) add('Contract signed');
    if (reached('svt')) add('Payment setup configured');
    if (reached('signed')) add('Sale confirmed');
    if (proposal.status === 'dead') add('Marked as dead', { reason: proposal.deadReason || '' });
  }
  // 2026-10-22 (per Catalina): sample times stay within business hours (9:00 AM – 6:00 PM). The steps are spread evenly
  // over the business minutes between Created 9:10 AM and Modified 3:40 PM, so every day only counts 9:00 – 6:00.
  const OPEN = 9 * 60, CLOSE = 18 * 60, DAY = CLOSE - OPEN;
  const parse = value => { const date = new Date(`${value} 00:00`); return Number.isNaN(date.getTime()) ? new Date(new Date().setHours(0, 0, 0, 0)) : date; };
  const firstDay = parse(proposal.created);
  const lastDay = parse(proposal.modified || proposal.created);
  const days = Math.max(0, Math.round((lastDay - firstDay) / 86400000));
  const startMin = (9 * 60 + 10) - OPEN;
  const endMin = Math.max(startMin, days * DAY + (15 * 60 + 40) - OPEN);
  const toDate = businessMin => {
    const rounded = Math.round(businessMin);
    const date = new Date(firstDay);
    date.setDate(date.getDate() + Math.floor(rounded / DAY));
    date.setHours(0, OPEN + (rounded % DAY), 0, 0);
    return date;
  };
  return steps.map(([title, data], index) => ({
    id: `sample-${proposal.id}-${index}`,
    title,
    description: 'Sample proposal.',
    at: toDate(steps.length < 2 ? startMin : startMin + (endMin - startMin) * index / (steps.length - 1)),
    ...data,
  }));
}

// One activity item per status change (+ document events), newest first — event design v2 (brief 34, 2026-10-22):
// { stage, title, responsible, description, doc } exactly as the brief's milestones table. A re-send is another
// "Proposal sent" / "Contract sent" row.
function getProposalHistoryItems(events, ctx) {
  const { changes } = getStageTimeline(events);
  const rep = ctx.owner;
  const signer = ctx.contact;
  const log = events || [];
  const backToDraft = {
    'changed-after-sent': 'Changed after it was sent',
    'approval-cleared': 'Not every option needs approval anymore',
    'request-canceled': 'The approval request was canceled',
    'contract-canceled': 'The contract was canceled to modify the proposal',
  };
  // The options deleted since the last approval request (they left only options that need approval).
  const deletedSinceRequest = evt => {
    const until = log.indexOf(evt);
    let from = 0;
    log.forEach((e, index) => { if (index <= until && e.title === 'Approval requested') from = index; });
    return log.slice(from, until + 1).filter(e => e.optionRemoved && e.removedOption).map(e => e.removedOption);
  };
  const describe = change => {
    const evt = change.evt || {};
    if (change.stage === 'Proposal') {
      if (change.status === 'draft' && change.cause === 'created') return { title: 'Proposal created', responsible: rep };
      if (change.status === 'draft') return { title: 'Back to Draft', responsible: rep, description: backToDraft[change.cause] };
      if (change.status === 'approval' && change.cause === 'every-option') {
        const deleted = historyOptionNamesSummary(deletedSinceRequest(evt));
        return { title: 'Needs Approval', responsible: rep, description: deleted ? `${deleted} deleted — the remaining option is waiting for approval` : 'The remaining option is waiting for approval' };
      }
      if (change.status === 'approval') return { title: 'Needs Approval', responsible: rep, description: ['Approval requested for every option', evt.role].filter(Boolean).join(' · ') };
      if (change.status === 'rejected') return { title: 'Approval rejected', responsible: evt.approver || evt.role || 'Approver', description: evt.reason };
      if (change.status === 'sent') return { title: 'Proposal sent', responsible: rep, description: [`To ${signer}`, evt.optionsSummary].filter(Boolean).join(' · '), doc: 'pdf' };
    }
    if (change.stage === 'Contract') {
      if (change.cause === 'contract-canceled') return { title: 'Contract canceled', responsible: rep, description: 'To modify the proposal' };
      if (change.status === 'contract-review') return { title: 'Contract created', responsible: rep, description: evt.optionNumber ? `From Option ${evt.optionNumber}` : '' };
      if (change.status === 'awaiting-sig') return { title: 'Contract sent', responsible: rep, description: `To ${signer} for signature`, doc: 'contract' };
      if (change.status === 'payment') return { title: 'Contract signed', responsible: signer, description: 'Signed in DocuSign', doc: 'contract', signed: true };
      if (change.status === 'svt') return { title: 'Payment setup completed', responsible: signer, description: 'Payment method set up' };
    }
    if (change.stage === 'Deal') {
      if (change.status === 'signed') return { title: 'Sale confirmed', responsible: 'SVT Team', description: 'Confirmed after the payment setup' };
      if (change.status === 'dead') return { title: 'Marked as dead', responsible: rep, description: evt.reason };
    }
    return null;
  };
  const order = new Map(log.map((evt, index) => [evt, index]));
  const items = [];
  changes.forEach((change, sub) => {
    const item = describe(change);
    if (!item) return;
    items.push({ ...item, stage: change.stage === 'Deal' ? 'Deal Result' : change.stage, at: change.at, evt: change.evt, cause: change.cause, seq: order.get(change.evt) || 0, sub });
  });
  log.forEach((evt, index) => {
    if (evt.title === 'Proposal PDF downloaded') items.push({ title: 'Proposal PDF downloaded', responsible: rep, description: evt.optionsSummary, doc: 'pdf', stage: 'Proposal', at: evt.at, evt, seq: index, sub: 0 });
  });
  const time = at => new Date(at).getTime();
  return items.sort((a, b) => (time(b.at) - time(a.at)) || (b.seq - a.seq) || (b.sub - a.sub));
}

/* ── Documents and preview (batch 2) ──────────────────────────────────────────────────────────────────
   Every send / download / contract send is a document; its snapshot (evt.docHtml, kept when it happened) is what the
   preview shows. Sample events have no snapshot: they use the existing renderers (the sample proposal PDF, the row's
   contract preview). A document is outdated (warning notice above it, view only) unless it's the latest of its kind and nothing replaced it
   (the proposal went back to Draft / the contract was canceled after it). Old versions can't be re-sent (Leo).
   Drill-in (2026-10-22, per Catalina — chosen over the Expand side panel, which was removed): the preview replaces the
   list at the same width; the drawer header becomes the document's (← back, name, event · date); ← goes back
   to the same scroll. Escape / X close the drawer. */
let historyView = null; // { proposalId, events, ctx, items, docs, viewing (doc index | null), listScroll }

function getHistoryDocuments(items) {
  const time = at => new Date(at).getTime();
  const docs = items.filter(item => item.doc).slice().sort((a, b) => (time(a.at) - time(b.at)) || (a.seq - b.seq));
  // What replaces a document: the proposal back to Draft (proposal PDF) / the contract canceled (contract).
  const backToDraft = items.filter(item => item.stage === 'Proposal' && item.title === 'Back to Draft');
  const contractCanceled = items.filter(item => item.stage === 'Contract' && item.cause === 'contract-canceled');
  docs.forEach((doc, index) => {
    const newerOfKind = docs.slice(index + 1).some(other => other.doc === doc.doc);
    const replacedBy = doc.doc === 'contract' ? contractCanceled : backToDraft;
    doc.outdated = newerOfKind || replacedBy.some(reset => time(reset.at) > time(doc.at));
    doc.docIndex = index;
  });
  return docs;
}

// 2026-10-22 (per Catalina): the current status is a badge next to the proposal ID in the header (dashboard colors) — no
// status box above the list. The badge's title says since when.
function historyStatusBadgeHtml(events) {
  const status = getOpenProposalStatus(events);
  const meta = status && VC.QL_STATUS[status];
  if (!meta) return '';
  const { current } = getStageTimeline(events);
  const now = current.Deal || current.Contract || current.Proposal;
  return `<span class="badge ${meta.badge}" title="Since ${historyEsc(formatHistoryDateTime(now.at))}">${historyEsc(meta.label)}</span>`;
}

// 2026-10-22 (per Catalina): the document links are record links in a text-body-small wrapper — same markup and look as
// the dashboard's document links; other links keep the VDS text-link.
function historyListHtml() {
  const { items } = historyView;
  const list = items.length ? `<ol class="vc-history__list">${items.map(item => `
      <li class="vc-history__item"${item.doc ? ` data-doc-index="${item.docIndex}"` : ''}>
        <span class="vc-history__dot" aria-hidden="true"></span>
        <div class="vc-history__main">
          <span class="badge badge--white vc-history__stage">${historyEsc(item.stage)}</span>
          <div class="vc-history__title-row">
            <strong class="vc-history__title">${historyEsc(item.title)}</strong>
            <span class="vc-history__date">${historyEsc(formatHistoryDateTime(item.at))}</span>
          </div>
          ${item.responsible ? `<div class="vc-history__responsible">By ${historyEsc(item.responsible)}</div>` : ''}
          ${item.description && item.description !== '--' ? `<div class="vc-history__detail">${historyEsc(item.description)}</div>` : ''}
          ${item.doc ? `<div class="text-body-small vc-history__doc"><button type="button" class="record-link" onclick="openHistoryPreview(${item.docIndex})">${item.doc === 'contract' ? 'View contract' : 'View PDF'}</button></div>` : ''}
        </div>
      </li>`).join('')}
    </ol>` : '<div class="vc-history__empty">No activity yet.</div>';
  // 2026-10-22 (per Catalina): no "Activity" heading — the list starts right under the header.
  return `<div class="vc-history">${list}</div>`;
}

// The document's content: its snapshot, else the existing renderer for the sample.
function historyDocumentContentHtml(doc) {
  if (doc.evt && doc.evt.docHtml) return `<div class="doc-viewer vc-history-preview__doc">${doc.evt.docHtml}</div>`;
  if (doc.doc === 'contract' && typeof buildQlContractPreviewHtml === 'function') {
    const html = buildQlContractPreviewHtml(historyView.proposalId);
    if (html) return `<div class="doc-viewer vc-history-preview__doc">${html}</div>`;
  }
  // Sample proposal PDF (same file as the dashboard's Proposal PDF link).
  return `<iframe class="vc-history-preview__frame" src="app/assets/quote-example.pdf" title="${historyEsc(historyDocumentName(doc))}"></iframe>`;
}

function historyDocumentName(doc) {
  const id = historyView.proposalId || '';
  if (doc.doc === 'contract') return doc.signed ? `Contract_${id}_signed.pdf` : `Contract_${id}.pdf`;
  return `Proposal_${id}.pdf`;
}

function historyPreviewHtml() {
  const doc = historyView.docs[historyView.viewing];
  const isContract = doc.doc === 'contract';
  // 2026-10-22 (per Catalina): the notification slot above the document — an outdated document gets a warning (no badge
  // in the subtitle: badges are for statuses); the current contract gets the DocuSign live-preview notice (same as the
  // contract preview); the current proposal PDF gets none.
  const notice = (tone, icon, title, message) => `
      <div class="notification notification--${tone} vc-history-preview__notice" role="status">
        <span class="notification__icon" aria-hidden="true"><span class="material-symbols-outlined">${icon}</span></span>
        <div class="notification__body">
          <p class="notification__title">${title}</p>
          <p class="notification__message">${message}</p>
        </div>
      </div>`;
  const noticeHtml = doc.outdated
    ? notice('warning', 'warning', 'Outdated version.', isContract ? 'This contract was replaced after it was sent. View only.' : 'The proposal changed after this was sent. View only.')
    : isContract
      ? notice('info', 'info', 'This is a live preview from DocuSign.', 'Nothing here is editable in ValuCal. To make changes, edit the contract directly in DocuSign. Updates will appear here automatically.')
      : '';
  // The drawer header carries ← / name / event · date (renderHistoryHeader); the body is the notice + document.
  return `
    <div class="vc-history-preview">
      ${noticeHtml}
      <div class="vc-history-preview__content" id="history-preview-content">${historyDocumentContentHtml(doc)}</div>
    </div>`;
}

// "Contract sent · 10/06/2026 3:40 PM" (an outdated version is told by the notice above the document).
function historyDocumentMetaHtml(doc) {
  return `<div class="vc-history-preview__meta"><span>${historyEsc(doc.title)} · ${historyEsc(formatHistoryDateTime(doc.at))}</span></div>`;
}

// The drawer header: "Proposal history" + ID and status badge; in Drill-in preview, ← + the document's name, its event
// and date.
function renderHistoryHeader() {
  const drawer = document.getElementById(HISTORY_DRAWER_ID);
  const title = document.getElementById(`${HISTORY_DRAWER_ID}-title`);
  const sub = document.getElementById(`${HISTORY_DRAWER_ID}-sub`);
  const doc = historyView.viewing != null ? historyView.docs[historyView.viewing] : null;
  const drill = !!doc;
  drawer.querySelector('.vc-history-head__back')?.classList.toggle('hidden', !drill);
  if (drill) {
    title.textContent = historyDocumentName(doc);
    sub.innerHTML = historyDocumentMetaHtml(doc);
  } else {
    // 2026-10-22 (per Catalina): "Proposal history – <ID>"; the subtitle is only the current status badge.
    title.textContent = `Proposal history \u2013 ${historyView.proposalId || '--'}`;
    sub.innerHTML = historyStatusBadgeHtml(historyView.events);
  }
}

function historyBody() {
  return document.querySelector(`#${HISTORY_DRAWER_ID} .vc-drawer__body`);
}

// Drill-in transition (2026-10-22, per Catalina): the preview slides in from the right, Back brings the list in from
// the left; the header text fades. No direction = first render, no animation.
function animateHistoryDrill(direction) {
  if (!direction) return;
  const targets = [historyBody().firstElementChild, document.getElementById(`${HISTORY_DRAWER_ID}-title`), document.getElementById(`${HISTORY_DRAWER_ID}-sub`)];
  targets.forEach((el, i) => {
    if (!el) return;
    el.classList.remove('vc-history-enter--forward', 'vc-history-enter--back', 'vc-history-enter--fade');
    void el.offsetWidth;
    const cls = i === 0 ? `vc-history-enter--${direction}` : 'vc-history-enter--fade';
    el.classList.add(cls);
    el.addEventListener('animationend', () => el.classList.remove(cls), { once: true });
  });
}

// Renders the drawer for the current view: the list, or the preview of one document.
function renderHistoryView(direction) {
  const body = historyBody();
  if (historyView.viewing == null) {
    body.innerHTML = historyListHtml();
    body.scrollTop = historyView.listScroll || 0;
  } else {
    body.innerHTML = historyPreviewHtml();
    body.scrollTop = 0;
  }
  body.classList.toggle('vc-history-body--preview', historyView.viewing != null);
  body.classList.toggle('vc-history-body--bleed', !!body.querySelector('.vc-history-preview__frame'));
  renderHistoryHeader();
  animateHistoryDrill(direction);
  const content = document.getElementById('history-preview-content');
  if (content && typeof scaleDocPagesInContainer === 'function') requestAnimationFrame(() => scaleDocPagesInContainer(content));
}

function openHistoryPreview(docIndex) {
  if (!historyView || !historyView.docs[docIndex]) return;
  const body = historyBody();
  if (historyView.viewing == null) historyView.listScroll = body.scrollTop;
  historyView.viewing = docIndex;
  renderHistoryView('forward');
}

function closeHistoryPreview() {
  if (!historyView || historyView.viewing == null) return;
  historyView.viewing = null;
  renderHistoryView('back');
}

function openProposalHistoryDrawer(proposalId, events, ctx) {
  if (!document.getElementById(HISTORY_DRAWER_ID)) {
    document.body.insertAdjacentHTML('beforeend', VC.drawer({ id: HISTORY_DRAWER_ID, title: 'Proposal history', medium: true, onClose: 'closeProposalHistoryDrawer()' }));
    // Header slot for the Drill-in preview: ← before the title (hidden on the list). No download: the PDF viewer has its
    // own (2026-10-22, per Catalina).
    const header = document.querySelector(`#${HISTORY_DRAWER_ID} .vc-drawer__header`);
    const titles = header.firstElementChild;
    titles.insertAdjacentHTML('beforebegin', `<div class="vc-history-head"><button type="button" class="btn-icon btn-icon--ghost-vds btn-icon--vds-large vc-history-head__back hidden" aria-label="Back to history" title="Back to history" onclick="closeHistoryPreview()">${VC.icon ? VC.icon('arrow_back') : '<span class="material-symbols-outlined" aria-hidden="true">arrow_back</span>'}</button></div>`);
    header.querySelector('.vc-history-head').appendChild(titles);
    document.getElementById(`${HISTORY_DRAWER_ID}-sub`).classList.add('vc-history__subtitle');
  }
  const items = getProposalHistoryItems(events, ctx);
  historyView = { proposalId, events, ctx, items, docs: getHistoryDocuments(items), viewing: null, listScroll: 0 };
  renderHistoryView();
  VC.setDrawerOpen(HISTORY_DRAWER_ID, true);
}

function closeProposalHistoryDrawer() {
  VC.setDrawerOpen(HISTORY_DRAWER_ID, false);
  const drawer = document.getElementById(HISTORY_DRAWER_ID);
  if (historyView) historyView.viewing = null;
}

// Stepper tooltip link: the open proposal's live log.
function openOpenProposalHistory() {
  if (VC.closeStageTooltips) VC.closeStageTooltips();
  const id = typeof proposalData !== 'undefined' ? proposalData.proposalId : '';
  openProposalHistoryDrawer(id, proposalHistoryEvents, getHistoryContext(findHistoryProposal(id)));
}

// Dashboard row kebab: the live log when the row is the open proposal, otherwise its sample log.
function openQlProposalHistory(proposalId) {
  const proposal = findHistoryProposal(proposalId);
  const events = historyProposalId === proposalId && proposalHistoryEvents.length ? proposalHistoryEvents : getSampleHistoryEvents(proposal);
  openProposalHistoryDrawer(proposalId, events, getHistoryContext(proposal));
}

document.addEventListener('keydown', event => {
  if (event.key !== 'Escape') return;
  const drawer = document.getElementById(HISTORY_DRAWER_ID);
  if (!drawer || !drawer.classList.contains('is-open')) return;
  // A preview modal above the drawer closes first (its own handlers).
  if (document.querySelector('.modal-overlay.is-open')) return;
  closeProposalHistoryDrawer();
});
