/* \u2500\u2500 Transaction configuration (Unified composer, 2026-10-09) \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
   One flow of reusable steps; each transaction picks its steps and gives values to the variables of
   each step's modules. The prototype reads this at runtime (js/flow-composer.js applies it), so what the
   composer shows is how the unified file is actually built.

   STEPS    \u2014 the step library (reused by every transaction).
   MODULES  \u2014 modules per step: where they render (selector), which accounts they exist for, variables.
              `locked` = decided by the account (domain model \u00a77: account-resolved), never by the admin.
   TRANSACTIONS \u2014 the transactions the unified file runs today (scenario = account + door). */
(function (global) {
  const STEPS = [
    { id: 'dashboard', name: 'Proposal Dashboard', optional: true, offNote: 'Skipped: the transaction starts in Drafting and the Proposals crumb goes away.' },
    { id: 'options', name: 'Proposal options', required: 'Every transaction builds its offer here.' },
    { id: 'configure-solution', name: 'Configure solution', optional: true, offNote: 'Skipped: options can\'t get new solutions (the + Add buttons go away).' },
    { id: 'send-proposal', name: 'Send proposal', optional: true, offNote: 'Skipped: no Send Proposal \u2014 the rep goes straight to Select & Create Contract.' },
    { id: 'contract', name: 'Contract', optional: true, offNote: 'Skipped: no Select & Create Contract \u2014 the transaction ends once the proposal is sent.' },
    { id: 'deal-result', name: 'Deal result', required: 'Every transaction records its result (won, lost, pending).' },
  ];

  // Option card: the variant (VC.OPTION_CARD_VARIANTS) brings its own texts (solutions title, + Add, main action).
  const OPTION_CARD_VARS = [
    { key: 'variant', label: 'Card variant', type: 'variant' },
    { key: 'maxOptions', label: 'Max options', type: 'select', options: [['', 'No limit'], ['1', '1'], ['2', '2'], ['3', '3'], ['4', '4'], ['5', '5']] },
  ];
  const VARIANT_LABELS = { new: 'New', pilot: 'Pilot', 'msa-preview': 'MSA preview (read-only)', modification: 'Modification', renewal: 'Renewal', rewrap: 'Rewrap', reactivation: 'Reactivation' };
  const ALL = ['prospect', 'pilot', 'customer'];
  // Each card variant runs on one scenario (the card's content comes from that account); choosing a variant
  // whose account differs moves the transaction to this scenario. msa-preview keeps the current one.
  const VARIANT_SCENARIOS = {
    new: { accountType: 'prospect', entryPoint: 'newProposal' },
    pilot: { accountType: 'pilot', contractedPilot: false, entryPoint: 'newProposal' },
    modification: { accountType: 'customer', cancellation: 'none', entryPoint: 'newProposal' },
    renewal: { accountType: 'customer', cancellation: 'none', entryPoint: 'renewalRewrap' },
    rewrap: { accountType: 'customer', cancellation: 'none', entryPoint: 'renewalRewrap' },
    reactivation: { accountType: 'customer', cancellation: 'full', entryPoint: 'reactivationReinstatement' },
  };

  // Every module of a screen is listed for every transaction.
  //   appliesTo: accounts where the screen can show it (otherwise listed, unchecked, with the reason).
  //   defaultOn: accounts where it starts checked (default: every account in appliesTo).
  //   selector: where it renders (unchecked hides it). Texts come from the component itself.
  //   render: the composer draws it itself (e.g. Account summary), so it works for any account.
  //   variants: option card parts \u2014 which card variants have them (the variant decides, not the account).
  const MODULES = [
    // 1 - Proposal Dashboard
    { id: 'account-summary', step: 'dashboard', name: 'Account summary', appliesTo: ALL, defaultOn: ['customer'], render: 'accountSummary', selector: '#msa-commitment-list-slot, #pilot-account-panel-slot',
      vars: [{ key: 'variant', label: 'Summary', type: 'select', options: [['msa', 'MSA (existing account)'], ['pilot', 'Pilot'], ['pilot-msa', 'Pilot + MSA conversion']] }] },
    { id: 'page-title', step: 'dashboard', name: 'Page title', appliesTo: ALL, selector: '#quotes-list-page-header-host .vc-page-header__title' },
    { id: 'page-subtitle', step: 'dashboard', name: 'Page description', appliesTo: ALL, selector: '#quotes-list-page-header-host .vc-page-header__subtitle' },
    { id: 'create-button', step: 'dashboard', name: 'Create proposal button', appliesTo: ALL, selector: '#btn-new-proposal' },
    { id: 'proposal-table', step: 'dashboard', name: 'Proposal table', appliesTo: ALL, selector: '#new-ql-table-host' },

    // 2 - Proposal options
    { id: 'msa-panel', step: 'options', name: 'MSA panel', appliesTo: ALL, defaultOn: ['customer'], render: 'msaDrafting', selector: '#msa-commitment-drafting-slot' },
    { id: 'approval-banner', step: 'options', name: 'Approval notification', appliesTo: ALL, selector: '#approval-snackbar-wrap', note: 'Shows when an option needs pricing approval' },
    { id: 'current-setup', step: 'options', name: 'Current / Previous setup', appliesTo: ['customer'], selector: '#current-proposal-panel' },
    { id: 'option-card', step: 'options', name: 'Option card', appliesTo: ALL, required: 'The options board is made of option cards', vars: OPTION_CARD_VARS },
    { id: 'transaction-switch', step: 'options', name: 'Renewal / Rewrap switch', parent: 'option-card', variants: ['renewal', 'rewrap'], selector: '.option-header-controls' },
    { id: 'pilot-summary', step: 'options', name: 'Pilot terms strip', parent: 'option-card', variants: ['pilot'], selector: '.pilot-summary' },
    { id: 'term', step: 'options', name: 'Contract term', parent: 'option-card', variants: ['new', 'renewal', 'rewrap'], selector: '.opt-term-cell' },
    { id: 'discounts-button', step: 'options', name: 'Discounts & Promotions', parent: 'option-card', variants: ['new', 'renewal', 'rewrap'], selector: '.opt-discount-cell' },
    { id: 'totals', step: 'options', name: 'Option totals', parent: 'option-card', appliesTo: ALL, selector: '.option-card-body > .opt-totals-row, .option-card-body > .bundle-stat-row' },
    { id: 'account-features', step: 'options', name: 'Account level features', parent: 'option-card', appliesTo: ALL, selector: '.bundles-label:has(+ .account-level-card), .account-level-card', note: 'Shows when the account has account-level features (Demo simulations)' },
    { id: 'solution-rows', step: 'options', name: 'Solution rows', parent: 'option-card', appliesTo: ALL, required: 'The solutions the option is made of' },

    // 3 - Configure solution
    { id: 'transaction-cards', step: 'configure-solution', name: 'Transaction type (first screen)', appliesTo: ['customer'], required: 'Existing accounts choose what the change does first' },
    { id: 'tx-upsell', step: 'configure-solution', name: 'Feature Upsell', parent: 'transaction-cards', appliesTo: ['customer'], selector: '#tx-card-upsell' },
    { id: 'tx-expansion', step: 'configure-solution', name: 'Expansion', parent: 'transaction-cards', appliesTo: ['customer'], selector: '#tx-card-add' },
    { id: 'tx-cancel', step: 'configure-solution', name: 'Cancel / Downgrade', parent: 'transaction-cards', appliesTo: ['customer'], selector: '#tx-card-cancel' },
    { id: 'tx-reactivate', step: 'configure-solution', name: 'Reactivate', parent: 'transaction-cards', appliesTo: ['customer'], selector: '#tx-card-reactivate', note: 'Only when something on the account was cancelled' },
    { id: 'solution-type', step: 'configure-solution', name: 'Bundle / \u00c0 la carte', appliesTo: ALL, locked: 'Decided by the account\'s Purchase mode (Scenario \u203a Account configuration)' },
    { id: 'cost-type', step: 'configure-solution', name: 'Opex / Capex', appliesTo: ALL, locked: 'Decided by the account\'s Cost type (Scenario \u203a Account configuration)' },
    { id: 'summary', step: 'configure-solution', name: 'Solution summary (right column)', appliesTo: ALL, selector: '#bundle-overlay .bundle-modal-preview' },

    // 4 - Send proposal
    { id: 'rep-info', step: 'send-proposal', name: 'Sales rep', appliesTo: ALL, selector: '#proposal-rep-inline-row' },
    { id: 'message', step: 'send-proposal', name: 'Customer message', appliesTo: ALL, selector: '.proposal-customization-thumb:has(#customization-message-preview)' },
    { id: 'pdf', step: 'send-proposal', name: 'Proposal PDF', appliesTo: ALL, selector: '.proposal-customization-thumb:has(#customization-pdf-preview)' },
    { id: 'case-studies', step: 'send-proposal', name: 'Case studies', appliesTo: ALL, selector: '#case-study-selector-wrap' },
    { id: 'roi', step: 'send-proposal', name: 'ROI calculator', appliesTo: ALL, selector: '#roi-config-section' },

    // 5 - Contract
    { id: 'readiness-gate', step: 'contract', name: 'Contract readiness gate', appliesTo: ALL, locked: 'Decided by the account readiness (Scenario \u203a Account configuration)' },
    { id: 'msa-panel', step: 'contract', name: 'MSA panel', appliesTo: ['customer'], selector: '#screen-contract > .msa-commitment-step-slot' },
    { id: 'contract-preview', step: 'contract', name: 'Contract preview', appliesTo: ALL, selector: '#contract-doc-viewer' },
    { id: 'signature-tracking', step: 'contract', name: 'Signature and payment tracking', appliesTo: ALL, selector: '#sp-checklist-wrap' },

    // 6 - Deal result
    { id: 'msa-panel', step: 'deal-result', name: 'MSA panel', appliesTo: ['customer'], selector: '#screen-deal-result > .msa-commitment-step-slot' },
    { id: 'view-contract', step: 'deal-result', name: 'View Contract button', appliesTo: ALL, selector: '#deal-result-secondary-btn' },
  ];

  // Entry points of a step that can be removed (the flow skips it).
  const STEP_ENTRY_SELECTORS = {
    dashboard: '#breadcrumb-proposals-crumb, #breadcrumb-proposals-sep',
    'configure-solution': '.btn-add-bundle, #empty-state-btn',
    'send-proposal': '#drafting-review-btn, #footer-send',
    contract: '.btn-select-contract',
  };

  const allOn = { dashboard: true, options: true, 'configure-solution': true, 'send-proposal': true, contract: true, 'deal-result': true };
  const card = variant => ({ variant, maxOptions: '' });

  const TRANSACTIONS = [
    { id: 'initial-sale', name: 'Initial Sale', scenario: { accountType: 'prospect', entryPoint: 'newProposal' }, steps: { ...allOn },
      modules: { 'options.option-card': { on: true, vars: card('new') } } },
    { id: 'pilot', name: 'Pilot', scenario: { accountType: 'pilot', contractedPilot: false, entryPoint: 'newProposal' }, steps: { ...allOn },
      modules: { 'options.option-card': { on: true, vars: card('pilot') } } },
    { id: 'modification', name: 'Modification', scenario: { accountType: 'customer', cancellation: 'none', entryPoint: 'newProposal' }, steps: { ...allOn },
      modules: { 'options.option-card': { on: true, vars: card('modification') } } },
    { id: 'renewal-rewrap', name: 'Renewal / Rewrap', scenario: { accountType: 'customer', cancellation: 'none', entryPoint: 'renewalRewrap' }, steps: { ...allOn },
      modules: { 'options.option-card': { on: true, vars: card('renewal') } } },
    { id: 'reactivation', name: 'Reactivation', scenario: { accountType: 'customer', cancellation: 'full', entryPoint: 'reactivationReinstatement' }, steps: { ...allOn },
      modules: { 'options.option-card': { on: true, vars: card('reactivation') } } },
  ];

  // ── Leo's object model (phase 1, 2026-10-19) ─────────────────────────────────────────────────────
  // Source: Leo's workbook "MSA Screens" › "Objects by Transaction" (componentization/leo-object-model/README.md §1A).
  // Data only — nothing reads it yet to change the UI (phase 2 = matrix view in the Composer, phase 3 = wiring).
  //   LEO_TRANSACTIONS — Leo's 13 transactions. `builtAs` = the TRANSACTIONS id the prototype runs it as today
  //                      (null = not built). `door` = how the prototype opens it when it isn't a TRANSACTIONS entry.
  //   OBJECTS          — Leo's 21 objects: id, flowOrder, hierarchy, calledFrom, name, variants (code → label),
  //                      byTransaction (code per transaction: a variant code, '--' = not used, '' = not defined yet,
  //                      '?' = open question — `questions` are the numbers of README §5), and `covers` = the
  //                      'step.module' ids (or other places in the prototype) that implement the object today.
  const LEO_TRANSACTIONS = [
    { id: 'pilot', name: 'Pilot', builtAs: 'pilot' },
    { id: 'initial-sale', name: 'Initial Sale', builtAs: 'initial-sale' },
    { id: 'existing-business', name: 'Existing Business', builtAs: 'modification', parts: ['Upsell (US)', 'Expansion (EX)', 'Partial Cancellation (PC)', 'Reactivation (RA)'] },
    { id: 'renewal', name: 'Renewal', builtAs: 'renewal-rewrap' },
    { id: 'reactivation', name: 'Reactivation', builtAs: 'reactivation' },
    { id: 'rewrap', name: 'Rewrap', builtAs: 'renewal-rewrap' },
    { id: 'pilot-conversion', name: 'Pilot Conversion', builtAs: null },
    { id: 'reinstatement', name: 'Reinstatement', builtAs: null },
    { id: 'transfer', name: 'Transfer', builtAs: null },
    { id: 'full-cancellation', name: 'Full Cancellation', builtAs: null, door: 'MSA panel ⋮ › Cancel contract (modal)' },
    { id: 'wnnr', name: 'WNNR (Written Notice of Non-Renewal)', builtAs: null, door: 'MSA panel ⋮ › Written Notice of Non-Renewal (modal)' },
    { id: 'migration-msa', name: 'Migration to MSA', builtAs: null },
    { id: 'migration-non-msa', name: 'Migration to Non MSA', builtAs: null },
  ];
  // One code per transaction (Transfer and the two Migrations are blank in the workbook).
  const by = (pilot, is, eb, renewal, reactivation, rewrap, pilotConversion, reinstatement, fullCancellation, wnnr) => ({
    pilot, 'initial-sale': is, 'existing-business': eb, renewal, reactivation, rewrap, 'pilot-conversion': pilotConversion,
    reinstatement, transfer: '', 'full-cancellation': fullCancellation, wnnr, 'migration-msa': '', 'migration-non-msa': '',
  });
  const NONE = by('', '', '', '', '', '', '', '', '', '');
  const OBJECTS = [
    { id: 1, flowOrder: '0', hierarchy: '', calledFrom: [], name: 'Proposal Dashboard', variants: {}, byTransaction: NONE,
      covers: ['dashboard.account-summary', 'dashboard.page-title', 'dashboard.page-subtitle', 'dashboard.create-button', 'dashboard.proposal-table'] },
    { id: 2, flowOrder: '2', hierarchy: '1', calledFrom: [], name: 'Proposal',
      variants: { PI: 'Pilot', IS: 'Initial Sale', AM: 'Active MSA', CM: 'Cancelled MSA' },
      byTransaction: by('PI', 'IS', 'AM', 'AM', 'CM', 'AM', 'PI', 'CM', '', ''),
      covers: ['options.msa-panel', 'options.approval-banner', 'options.current-setup'],
      note: 'Variant = account state (Leo: mostly the banner on top) ↔ our accountType + cancellation.' },
    { id: 3, flowOrder: '2', hierarchy: '2', calledFrom: [], name: 'Option',
      variants: { PI: 'Pilot', MA: 'Main', MO: 'Modifications', RE: 'Reinstatement' },
      byTransaction: by('PI', 'MA', 'MO', 'MA', 'MA', 'MA', 'MA', 'RE', '', ''),
      covers: ['options.option-card', 'options.transaction-switch', 'options.pilot-summary', 'options.term', 'options.totals', 'options.account-features'],
      cardVariants: { PI: ['pilot'], MA: ['new', 'renewal', 'rewrap', 'reactivation'], MO: ['modification'], RE: [] }, questions: [5] },
    { id: 4, flowOrder: '2', hierarchy: '3', calledFrom: [], name: 'Solution', variants: { PI: 'Pilot', MA: 'Main' },
      byTransaction: by('PI', 'MA', 'MA', 'MA', 'MA', 'MA', 'MA', 'MA', '', ''), covers: ['options.solution-rows'], questions: [1] },
    { id: 5, flowOrder: '2', hierarchy: '4', calledFrom: [], name: 'Line', variants: { PI: 'Pilot', MA: 'Main' },
      byTransaction: by('PI', 'MA', 'MA', 'MA', 'MA', 'MA', 'MA', 'MA', '', ''), covers: ['options.solution-rows'],
      note: 'Today the lines live inside each solution row (and in the Price List).', questions: [1] },
    { id: 6, flowOrder: '3', hierarchy: '', calledFrom: [2, 3, 4], name: 'Modification popup', variants: { MA: 'Main' },
      byTransaction: by('--', '--', 'MA', 'MA', 'MA', 'MA', 'MA', '--', '', ''),
      covers: ['configure-solution.transaction-cards', 'configure-solution.tx-upsell', 'configure-solution.tx-expansion', 'configure-solution.tx-cancel', 'configure-solution.tx-reactivate'] },
    { id: 7, flowOrder: '1', hierarchy: '', calledFrom: [2, 3, 6], name: 'Create Solution', variants: { PI: 'Pilot', MA: 'Main', EB: 'Existing Business' },
      byTransaction: by('PI', 'MA', 'EB', 'MA', 'MA', 'MA', 'MA', '--', '', ''),
      covers: ['configure-solution.solution-type', 'configure-solution.cost-type', 'configure-solution.summary'] },
    { id: 8, flowOrder: '1', hierarchy: '', calledFrom: [4, 6], name: 'Vehicle/Subscription Selection', variants: { US: 'Upsell' },
      byTransaction: by('--', '--', 'US', 'US', 'US', 'US', 'US', '--', '', ''), covers: ['configure-solution.tx-upsell'], note: 'Shared C360 vehicle table.' },
    { id: 9, flowOrder: '1', hierarchy: '', calledFrom: [4, 6], name: 'Vehicle/Subscription Selection', variants: { CA: 'Cancel' },
      byTransaction: by('--', '--', 'CA', 'CA', 'CA', 'CA', 'CA', '--', '', ''), covers: ['configure-solution.tx-cancel'],
      note: 'Partial Cancellation Immediate / End of contract ↔ Cancel mid term / term end.' },
    { id: 10, flowOrder: '1', hierarchy: '', calledFrom: [4, 6], name: 'Vehicle/Subscription Selection', variants: { RA: 'Reactivation' },
      byTransaction: by('--', '--', 'RA', 'RA', 'RA', 'RA', 'RA', '--', '', ''), covers: ['configure-solution.tx-reactivate'] },
    { id: 11, flowOrder: '3', hierarchy: '', calledFrom: [3], name: 'Discounts & Promotions', variants: { IS: 'Initial Sales (with discretionary)', MA: 'Main' },
      byTransaction: by('--', 'IS', 'MA', 'MA', 'MA', 'MA', 'MA', '--', '', ''), covers: ['options.discounts-button'], questions: [2] },
    { id: 12, flowOrder: '4', hierarchy: '', calledFrom: [2], name: 'Proposal Package', variants: { MA: 'Main' },
      byTransaction: by('MA', 'MA', 'MA', 'MA', 'MA', 'MA', 'MA', '--', '', ''),
      covers: ['send-proposal.rep-info', 'send-proposal.case-studies', 'send-proposal.roi'] },
    { id: 13, flowOrder: '5', hierarchy: '', calledFrom: [12], name: 'PDF Configurator', variants: { PI: 'Pilot', MA: 'Main' },
      byTransaction: by('?', 'MA', 'MA', 'MA', 'MA', 'MA', 'MA', '--', '', ''), covers: ['send-proposal.pdf'], questions: [3] },
    { id: 14, flowOrder: '5', hierarchy: '', calledFrom: [12], name: 'Email configurator', variants: { PI: 'Pilot', MA: 'Main' },
      byTransaction: by('?', 'MA', 'MA', 'MA', 'MA', 'MA', 'MA', '--', '', ''), covers: ['send-proposal.message'], questions: [3] },
    { id: 15, flowOrder: '', hierarchy: '', calledFrom: [3], name: 'Order Schedule', variants: { MA: 'Main' },
      byTransaction: by('--', 'MA', 'MA', 'MA', 'MA', 'MA', 'MA', '--', '', ''),
      covers: ['Option card menu › Order Schedule (from 20 units)', 'Contract › Edit order schedule'] },
    { id: 16, flowOrder: '', hierarchy: '', calledFrom: [1, 2, 3], name: 'Contract PDF', variants: { PI: 'Pilot', IS: 'Initial Sale', MO: 'Modifications' },
      byTransaction: by('PI', 'IS', 'MO', '?', '?', '?', '?', '--', '', ''), covers: ['contract.contract-preview'], questions: [4] },
    { id: 17, flowOrder: '', hierarchy: '', calledFrom: [], name: 'Full Cancellation', variants: { MA: 'Main' },
      byTransaction: by('', '', '', '', '', '', '', '', 'MA', ''), covers: ['MSA panel ⋮ › Cancel contract (modal)'] },
    { id: 18, flowOrder: '', hierarchy: '', calledFrom: [], name: 'WNNR', variants: { MA: 'Main' },
      byTransaction: by('', '', '', '', '', '', '', '', '', 'MA'), covers: ['MSA panel ⋮ › Written Notice of Non-Renewal (modal)'] },
    { id: 19, flowOrder: '', hierarchy: '', calledFrom: [1, 2], name: 'Account/Order Setup', variants: {}, byTransaction: NONE,
      covers: ['Simulation Builder › Account configuration'] },
    { id: 20, flowOrder: '', hierarchy: '', calledFrom: [], name: 'Admin Interface', variants: {}, byTransaction: NONE, covers: [] },
    { id: 21, flowOrder: '', hierarchy: '', calledFrom: [20], name: 'Segment Defaults', variants: {}, byTransaction: NONE, covers: [] },
  ];
  // Helpers: the code an object uses in a transaction, and the objects a transaction uses (not '--' / blank).
  const getObjectVariant = (objectId, txId) => ((OBJECTS.find(o => o.id === objectId) || {}).byTransaction || {})[txId] || '';
  const objectsForTransaction = txId => OBJECTS.filter(o => { const c = o.byTransaction[txId]; return !!c && c !== '--'; });

  global.VC_TX_CONFIG = { STEPS, MODULES, STEP_ENTRY_SELECTORS, TRANSACTIONS, VARIANT_LABELS, VARIANT_SCENARIOS,
    LEO_TRANSACTIONS, OBJECTS, getObjectVariant, objectsForTransaction };
})(window);
