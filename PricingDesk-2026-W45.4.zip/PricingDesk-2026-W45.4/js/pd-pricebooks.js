/* Pricing Desk — Price books (brief 05, batch 1: read-only). Sam Rivera's home (Pricing Manager).
   List (?page=price-books): page title, search and a table in the look of Approvals / Valu Cal's Proposal Dashboard
   (the name is the link). Price book page (?page=price-books&view=book&item=<id>): breadcrumb "Price books / <name>",
   title + type, the versions table, and the selected version (the active one by default) in VDS tabs: Prices,
   Discount schedules, Tier bands. Data: config/pricebooks.config.js (sample).
   Batch 2 (2026-10-30, Catalina: "el creador de pricebooks"): "+ Create new version" copies the active (or latest)
   version into a Draft; the Draft's list prices are edited in the Prices tab ("was $x" under a changed price); the sticky
   footer has Delete draft and Publish. Publish asks for Valid from (after the latest published start, not before today)
   and Valid to (optional), reminds that MSA customers keep their frozen price card and that no approval is needed; the
   version becomes Scheduled (or Active if it starts today) and the previous one ends the day before. "Create price book"
   on the list: name (unique), type, description and which prices to start from → its v1 Draft opens. Discount
   schedules and tier bands stay read-only (copied with the version). Everything is kept for the session. */
(function (global) {
  var PD = global.PD = global.PD || {};
  var VSTATUS = {
    active: { label: 'Active', badge: 'badge--green' },
    scheduled: { label: 'Scheduled', badge: 'badge--blue' },
    draft: { label: 'Draft', badge: 'badge--gray' },
    expired: { label: 'Expired', badge: 'badge--white' },
  };
  var TABS = [['prices', 'Prices'], ['schedules', 'Discount schedules'], ['tiers', 'Tier bands']];

  PD.pricebookState = PD.pricebookState || { search: '', versionByBook: {}, tab: 'prices' };

  // ── Session store (as promotions): the price books as changed in the demo. Memory backs it up where storage is
  // missing or blocked (file:// in some browsers, jsdom); the sample in the config is the starting point.
  var STORE_KEY = 'pd.pricebooks.session.v1';
  var ORIGINAL = JSON.stringify(PD.PRICE_BOOKS || []);
  function storage() { try { return global.sessionStorage || null; } catch (e) { return null; } }
  (function load() {
    var st = storage();
    try {
      var raw = st && st.getItem(STORE_KEY);
      var data = raw ? JSON.parse(raw) : null;
      if (data && Array.isArray(data.books)) PD.PRICE_BOOKS = data.books;
    } catch (e) { /* keep the sample */ }
  })();
  function save() {
    var st = storage();
    try { if (st) st.setItem(STORE_KEY, JSON.stringify({ books: PD.PRICE_BOOKS })); } catch (e) { /* memory only */ }
  }
  PD.resetPriceBookSession = function () {
    PD.PRICE_BOOKS = JSON.parse(ORIGINAL);
    var st = storage();
    try { if (st) st.removeItem(STORE_KEY); } catch (e) { /* storage blocked */ }
  };
  function todayIso() {
    var d = new Date();
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  }
  function dayBefore(iso) {
    var p = iso.split('-');
    var d = new Date(+p[0], +p[1] - 1, +p[2] - 1);
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  }
  function personaName() { var p = PD.currentPersona ? PD.currentPersona() : null; return p ? p.name : 'Sam Rivera'; }
  function toast(text) { if (PD.showToast) PD.showToast(text); }

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function el(id) { return document.getElementById(id); }
  function fmt(iso) { return iso ? (PD.formatDate ? PD.formatDate(iso) : iso) : '--'; }
  function money(n) { return '$' + Number(n).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ','); }
  function count(n) { return String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ','); }
  function badge(status) { var s = VSTATUS[status]; return s ? '<span class="badge ' + s.badge + '">' + esc(s.label) + '</span>' : ''; }
  function validity(v) { return v.from ? fmt(v.from) + ' – ' + (v.to ? fmt(v.to) : 'No end date') : v.status === 'draft' ? (v.proposedFrom ? 'Proposed: ' + fmt(v.proposedFrom) + ' – ' + (v.proposedTo ? fmt(v.proposedTo) : 'No end date') : 'Dates set when published') : '--'; }

  PD.priceBooks = function () { return PD.PRICE_BOOKS || []; };
  PD.findPriceBook = function (id) { return PD.priceBooks().filter(function (b) { return b.id === id; })[0] || null; };
  PD.activeVersion = function (book) { return book.versions.filter(function (v) { return v.status === 'active'; })[0] || null; };
  PD.nextVersion = function (book) {
    return book.versions.filter(function (v) { return v.status === 'scheduled' || v.status === 'draft'; })[0] || null;
  };
  function lastPublished(book) {
    return book.versions.map(function (v) { return v.publishedOn; }).filter(Boolean).sort().pop() || '';
  }

  // A version's prices: the base rows times its priceFactor, rounded to the cent (sample data).
  PD.versionPrices = function (version) {
    if (version.prices) return version.prices.map(function (r) { var c = {}; Object.keys(r).forEach(function (k) { c[k] = r[k]; }); return c; });
    var data = PD.PRICEBOOK_DATA || { basePrices: [] };
    return data.basePrices.map(function (r) {
      var copy = {};
      Object.keys(r).forEach(function (k) { copy[k] = r[k]; });
      copy.price = Math.round(r.price * (version.priceFactor || 1) * 100) / 100;
      return copy;
    });
  };

  function clone(x) { return JSON.parse(JSON.stringify(x)); }
  // A version's discount schedules and tier bands: its own copy (drafts, edited), else the named sample set.
  PD.versionSchedules = function (version) {
    if (version.schedules) return version.schedules;
    var data = PD.PRICEBOOK_DATA || {};
    return (data.scheduleSets || {})[version.scheduleSet] || {};
  };
  PD.versionTiers = function (version) { return version.tiers || (PD.PRICEBOOK_DATA || {}).tierBands || []; };
  // A draft keeps its own prices, schedules and tier bands, and a snapshot of them as it opened: "was" compares with
  // that snapshot, so it only shows what was changed in this draft (Catalina, 2026-10-30).
  function ensureDraft(d) {
    if (!d.prices) d.prices = PD.versionPrices(d);
    if (!d.schedules) d.schedules = clone(PD.versionSchedules(d));
    if (!d.tiers) d.tiers = clone(PD.versionTiers(d));
    if (!d.original) d.original = clone({ prices: d.prices, schedules: d.schedules, tiers: d.tiers });
    return d;
  }

  // ── List.
  function rowHtml(b) {
    var active = PD.activeVersion(b);
    var next = PD.nextVersion(b);
    var nextText = !next ? '--' : 'v' + next.v + ' ' + VSTATUS[next.status].label + (next.from ? ' from ' + fmt(next.from) : '');
    var link = '<a href="?persona=' + esc(PD.state.personaId) + '&amp;page=price-books&amp;view=book&amp;item=' + esc(b.id) + '" class="record-link" id="pd-pb-link-' + esc(b.id) + '"' +
      ' onclick="event.preventDefault(); PD.openPriceBook(\'' + esc(b.id) + '\')">' + esc(b.name) + '</a>';
    return '<tr class="ql-table-row" id="pd-pb-row-' + esc(b.id) + '">' +
      '<td class="table-body-cell">' + link + '<div class="text-body-small ql-cell-ref">' + esc(b.type) + '</div></td>' +
      '<td class="table-body-cell">' + (active ? 'v' + active.v + '<div class="text-body-small ql-cell-ref">' + esc(validity(active)) + '</div>' : '--') + '</td>' +
      '<td class="table-body-cell">' + esc(nextText) + '</td>' +
      '<td class="table-body-cell ql-col-num">' + esc(count(b.accounts)) + '</td>' +
      '<td class="table-body-cell">' + esc(fmt(lastPublished(b))) + '</td>' +
    '</tr>';
  }

  PD.updatePriceBooks = function () {
    var q = (PD.pricebookState.search || '').trim().toLowerCase();
    var list = PD.priceBooks().filter(function (b) { return !q || b.name.toLowerCase().indexOf(q) !== -1; });
    var host = el('pd-pb-items');
    if (!host) return;
    host.innerHTML = list.length
      ? '<div class="ql-table-wrap">' + VC.dataTable({
          className: 'ql-table pd-pb-table', id: 'pd-pb-tbody', ariaLabel: 'Price books',
          columns: [{ label: 'Price book' }, { label: 'Active version' }, { label: 'Next version' }, { label: 'Accounts', className: 'ql-col-num' }, { label: 'Last published' }],
          rowsHtml: list.map(rowHtml),
        }) + '</div>'
      : '<div class="vc-master-detail__empty text-body-medium" id="pd-pb-empty">No price books match your search</div>';
  };
  PD.setPriceBookSearch = function (value) { PD.pricebookState.search = value || ''; PD.updatePriceBooks(); };

  function listPageHtml(page) {
    return '<div id="pd-pricebooks">' +
      '<div class="vc-page-header"><div class="vc-page-header__main">' +
        '<h1 class="vc-page-header__title" id="pd-page-title">' + esc(page.title) + '</h1>' +
        '<p class="vc-page-header__subtitle">Products and their prices, discount schedules and tier bands, by version.</p>' +
      '</div>' +
      // One line (Catalina, 2026-10-30): title and description on the left; search and Create price book on the right.
      '<div class="vc-page-header__actions vc-page-header__actions--inline">' +
        VC.searchField({ id: 'pd-pb-search', placeholder: 'Search by price book', value: PD.pricebookState.search, onInput: 'PD.setPriceBookSearch(this.value)' }) +
        '<button type="button" class="btn btn--primary btn--large" id="pd-pb-create" onclick="PD.openCreatePriceBook()">Create price book</button>' +
      '</div></div>' +
      '<div id="pd-pb-items"></div>' +
    '</div>';
  }

  // ── Price book page.
  function crumb(current) {
    return '<nav aria-label="Breadcrumb"><ol class="breadcrumb-nav">' +
      '<li class="breadcrumb-nav__item"><a class="breadcrumb-nav__link" href="?persona=' + esc(PD.state.personaId) + '&amp;page=price-books" id="pd-pb-back"' +
        ' onclick="event.preventDefault(); PD.closePriceBook()">Price books</a><span class="breadcrumb-nav__sep" aria-hidden="true">/</span></li>' +
      '<li class="breadcrumb-nav__item breadcrumb-nav__item--current" aria-current="page">' + esc(current) + '</li>' +
    '</ol></nav>';
  }

  function selectedVersion(book) {
    var v = PD.pricebookState.versionByBook[book.id];
    var found = book.versions.filter(function (x) { return x.v === v; })[0];
    return found || PD.activeVersion(book) || book.versions[book.versions.length - 1];
  }

  // Versions as a side menu (Catalina, 2026-10-30: "un menú lateral para que nos podamos meter a cada versión"): the
  // master-detail list of Promotions & Discounts, narrower; newest first; the selected one marked.
  function versionsHtml(book, sel) {
    var items = book.versions.slice().reverse().map(function (v) {
      var on = v.v === sel.v;
      return '<li><button type="button" class="vc-master-detail__item' + (on ? ' is-selected' : '') + '" id="pd-pb-version-' + v.v + '"' + (on ? ' aria-current="true"' : '') +
        ' onclick="PD.selectPriceBookVersion(\'' + esc(book.id) + '\', ' + v.v + ')">' +
        '<span class="vc-master-detail__item-main">' +
          '<span class="text-body-medium-bold">Version ' + v.v + '</span>' +
          '<span class="vc-master-detail__item-sub text-body-small">' + esc(validity(v)) + '</span>' +
          '<span class="vc-master-detail__item-sub text-body-small">' + esc(v.publishedOn ? 'Published ' + fmt(v.publishedOn) + (v.publishedBy ? ' by ' + v.publishedBy : '') : 'Not published') + '</span>' +
        '</span>' + badge(v.status) + '</button></li>';
    }).join('');
    var d = draftOf(book);
    return '<nav class="vc-master-detail__list" id="pd-pb-versions" aria-labelledby="pd-pb-versions-title">' +
      '<div class="vc-master-detail__list-header"><div class="vc-master-detail__list-title-row">' +
        '<h2 class="vc-master-detail__detail-title text-body-large-bold" id="pd-pb-versions-title">Versions</h2>' +
      '</div>' +
      // One draft at a time: while there is one, the button opens it (2026-10-30).
      (d && d.v === sel.v ? '<p class="vc-form-page__note text-body-small" id="pd-pb-draft-note">You\'re editing the v' + d.v + ' draft. One draft at a time.</p>'
         : d ? '<button type="button" class="btn btn--secondary btn--small" id="pd-pb-create-version" onclick="PD.selectPriceBookVersion(\'' + esc(book.id) + '\', ' + d.v + ')">Go to draft v' + d.v + '</button>'
         : '<button type="button" class="btn btn--secondary btn--small" id="pd-pb-create-version" onclick="PD.createPriceBookVersion(\'' + esc(book.id) + '\')">Create new version</button>') +
      '</div>' +
      '<ul class="vc-master-detail__items" id="pd-pb-versions-list">' + items + '</ul>' +
    '</nav>';
  }

  function draftOf(book) { return book.versions.filter(function (v) { return v.status === 'draft'; })[0] || null; }
  // The version a draft was copied from (to show "was $x"): basedOn, else the active one.
  function baseOf(book, version) {
    return book.versions.filter(function (v) { return v.v === version.basedOn; })[0] || PD.activeVersion(book) || null;
  }
  // Empty = not sold that way (e.g. no installation for a wireless tracker); negative is an error.
  function priceError(value) {
    if (value === '' || value == null) return '';
    var n = parseFloat(value);
    return isNaN(n) ? 'Enter a number' : n < 0 ? 'Can\'t be negative' : '';
  }
  function productsOf(prices) { var out = []; prices.forEach(function (r) { if (out.indexOf(r.product) === -1) out.push(r.product); }); return out; }
  // Products of a draft without any price (added and not filled in).
  function unpricedProducts(prices) {
    return productsOf(prices).filter(function (pr) { return !prices.some(function (r) { return r.product === pr && r.price !== '' && r.price != null; }); });
  }
  // No CAPEX installation by CMI in a price book (Catalina, 2026-11-03): only VMI.
  // Prices as a matrix (Catalina, 2026-10-30: one line per product, not six): products grouped by schedule group, one
  // column per price under OPEX and CAPEX. In a draft every cell is an input, with "was $x" under a changed price.
  var PRICE_COLS = [
    { mode: 'OPEX', component: 'Subscription', install: 'Any', label: 'Monthly' },
    { mode: 'OPEX', component: 'Installation', install: 'VMI', label: 'Extra install (VMI)' },
    { mode: 'CAPEX', component: 'Subscription', install: 'Any', label: 'Monthly' },
    { mode: 'CAPEX', component: 'Hardware', install: 'Any', label: 'Hardware' },
    { mode: 'CAPEX', component: 'Installation', install: 'VMI', label: 'Install (VMI)' },
  ];
  function productLabel(name) { var i = name.indexOf(':'); var t = i === -1 ? name : name.slice(i + 1).trim(); return t.charAt(0).toUpperCase() + t.slice(1); }
  function pricesMatrixHtml(book, version, editable) {
    var prices = PD.versionPrices(version);
    var base = editable ? baseOf(book, version) : null;
    var before = editable ? ensureDraft(version).original.prices : [];
    // The product catalog's schedule group places each product (Products page), in the catalog's group order.
    var groups = (PD.SCHEDULE_GROUPS || []).map(function (n) { return { name: n, products: [] }; });
    prices.forEach(function (r) {
      var name = (PD.productGroup && PD.productGroup(r.product)) || r.group;
      var g = groups.filter(function (x) { return x.name === name; })[0];
      if (!g) { g = { name: name, products: [] }; groups.push(g); }
      if (g.products.indexOf(r.product) === -1) g.products.push(r.product);
    });
    groups = groups.filter(function (g) { return g.products.length; });
    function cell(product, col) {
      var i = -1;
      prices.forEach(function (r, k) { if (i === -1 && r.product === product && r.saleMode === col.mode && r.component === col.component && r.install === col.install) i = k; });
      var first = col === PRICE_COLS[0] || col === PRICE_COLS[2] ? ' vc-pb-matrix__start' : '';
      if (i === -1 && editable) {
        var mid = 'pd-pb-new-' + productKey(product) + '-' + PRICE_COLS.indexOf(col);
        return '<td class="table-body-cell' + first + '"><span class="input-affix input-affix--compact"><span class="input-affix__text" aria-hidden="true">$</span>' +
          '<input type="number" class="input input--small input-affix__field" id="' + mid + '" min="0" step="0.01" placeholder="--" value=""' +
            ' aria-label="' + esc(product + ', ' + col.mode + ' ' + col.label) + '"' +
            ' oninput="PD.setDraftMissingPrice(this, \'' + esc(book.id) + '\', \'' + esc(productKey(product)) + '\', ' + PRICE_COLS.indexOf(col) + ')"></span>' +
          '<span class="input__error-text hidden"></span><div class="text-body-small ql-cell-ref"></div></td>';
      }
      if (i === -1) return '<td class="table-body-cell' + first + '">--</td>';
      var r = prices[i];
      if (!editable) return '<td class="table-body-cell' + first + '">' + (r.price === '' || r.price == null ? '--' : esc(money(r.price))) + '</td>';
      var err = PD.pricebookState.showErrors ? priceError(r.price) : '';
      var prev = before.filter(function (x) { return x.product === r.product && x.saleMode === r.saleMode && x.component === r.component && x.install === r.install; })[0];
      var was = !prev ? '' : prev.price !== r.price ? 'was ' + (prev.price === '' ? '--' : money(prev.price)) : '';
      return '<td class="table-body-cell' + first + '">' +
        '<span class="input-affix input-affix--compact"><span class="input-affix__text" aria-hidden="true">$</span>' +
        '<input type="number" class="input input--small input-affix__field" id="pd-pb-price-' + i + '" min="0" step="0.01" placeholder="--" value="' + esc(r.price) + '"' +
          ' aria-label="' + esc(r.product + ', ' + col.mode + ' ' + col.label) + '" aria-describedby="pd-pb-price-' + i + '-error"' +
          ' oninput="PD.setDraftPrice(\'' + esc(book.id) + '\', ' + i + ', this.value)"></span>' +
        '<span class="input__error-text' + (err ? '' : ' hidden') + '" id="pd-pb-price-' + i + '-error">' + esc(err) + '</span>' +
        '<div class="text-body-small ql-cell-ref" id="pd-pb-was-' + i + '">' + esc(was) + '</div></td>';
    }
    var body = groups.map(function (g) {
      return '<tr class="vc-pb-matrix__group"><th scope="rowgroup" colspan="' + (PRICE_COLS.length + 1) + '" class="table-body-cell text-body-medium-bold">' + esc(g.name) + '</th></tr>' +
        g.products.map(function (product) {
          var isNew = editable && !before.some(function (x) { return x.product === product; });
          var missing = editable && PD.pricebookState.showErrors && unpricedProducts(prices).indexOf(product) !== -1;
          return '<tr><th scope="row" class="table-body-cell vc-pb-matrix__product">' +
              '<span class="vc-pb-matrix__product-name">' + esc(productLabel(product)) + (isNew ? ' <span class="badge badge--blue">New</span>' : '') + '</span>' +
              (missing ? '<span class="input__error-text">Enter at least one price</span>' : '') +
              (editable ? iconBtn('pd-pb-remove-' + productKey(product), 'delete', 'Remove ' + productLabel(product), 'PD.removeDraftProduct(\'' + esc(book.id) + '\', \'' + esc(productKey(product)) + '\')') : '') +
            '</th>' +
            PRICE_COLS.map(function (col) { return cell(product, col); }).join('') + '</tr>';
        }).join('');
    }).join('');
    // No note above the matrix (Catalina, 2026-11-03).
    return '<div class="vc-master-detail__table-wrap"><table class="vc-master-detail__table vc-pb-matrix" aria-label="Prices"><thead>' +
        '<tr><th rowspan="2" class="table-header-cell vc-pb-matrix__product-col">Product</th>' +
          '<th colspan="2" class="table-header-cell vc-pb-matrix__mode vc-pb-matrix__start">OPEX</th>' +
          '<th colspan="' + PRICE_COLS.filter(function (c) { return c.mode === 'CAPEX'; }).length + '" class="table-header-cell vc-pb-matrix__mode vc-pb-matrix__start">CAPEX</th></tr>' +
        '<tr>' + PRICE_COLS.map(function (col, k) { return '<th class="table-header-cell' + (k === 0 || k === 2 ? ' vc-pb-matrix__start' : '') + '">' + esc(col.label) + '</th>'; }).join('') + '</tr>' +
      '</thead><tbody id="pd-pb-prices">' + body + '</tbody></table></div>' +
      (editable ? '<button type="button" class="btn-dashed-add btn-dashed-add--pill" id="pd-pb-add-product" onclick="PD.openAddDraftProduct(\'' + esc(book.id) + '\')">+ Add product</button>' : '');
  }
  function productKey(name) { return name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, ''); }
  function iconBtn(id, icon, label, onclick) {
    return '<button type="button" class="btn-icon btn-icon--ghost-vds btn-icon--vds-small" id="' + id + '" aria-label="' + esc(label) + '" title="' + esc(label) + '" onclick="' + onclick + '">' +
      '<span class="material-symbols-outlined" aria-hidden="true">' + icon + '</span></button>';
  }

  function pctError(value) {
    if (value === '' || value == null) return 'Enter a %';
    var n = parseFloat(value);
    return isNaN(n) || n < 0 || n > 100 ? '0–100%' : '';
  }
  // Discount schedules: term × tier per schedule group; in a draft each cell is a % input (0–100) with "was".
  function schedulesHtml(book, version, editable) {
    var data = PD.PRICEBOOK_DATA || {};
    var set = PD.versionSchedules(version), tiers = PD.versionTiers(version);
    var orig = editable ? ensureDraft(version).original.schedules : null;
    // No note above the schedules (Catalina, 2026-11-03).
    return Object.keys(set).map(function (group, gi) {
        var rows = data.terms.map(function (t, ti) {
          return '<tr><th scope="row" class="table-body-cell vc-pb-matrix__product">' + t + ' months</th>' + set[group][ti].map(function (p, ki) {
            if (!editable) return '<td class="table-body-cell">' + esc(Number(p).toFixed(1)) + '%</td>';
            var id = 'pd-pb-sched-' + gi + '-' + ti + '-' + ki;
            var o = orig[group] && orig[group][ti] ? orig[group][ti][ki] : undefined;
            var err = PD.pricebookState.showErrors ? pctError(p) : '';
            return '<td class="table-body-cell"><span class="input-affix input-affix--compact input-affix--suffix">' +
              '<input type="number" class="input input--small input-affix__field" id="' + id + '" min="0" max="100" step="0.1" value="' + esc(p) + '"' +
                ' aria-label="' + esc(group + ', ' + t + ' months, ' + (tiers[ki] ? tiers[ki].tier : 'Tier ' + (ki + 1))) + '" aria-describedby="' + id + '-error"' +
                ' oninput="PD.setDraftSchedule(\'' + esc(book.id) + '\', ' + gi + ', ' + ti + ', ' + ki + ', this.value)">' +
              '<span class="input-affix__text" aria-hidden="true">%</span></span>' +
              '<span class="input__error-text' + (err ? '' : ' hidden') + '" id="' + id + '-error">' + esc(err) + '</span>' +
              '<div class="text-body-small ql-cell-ref" id="' + id + '-was">' + (o !== undefined && String(o) !== String(p) ? 'was ' + esc(Number(o).toFixed(1)) + '%' : o === undefined ? 'new' : '') + '</div></td>';
          }).join('') + '</tr>';
        }).join('');
        return '<div class="vc-pb-schedule" id="pd-pb-schedule-' + gi + '"><h3 class="text-body-medium-bold vc-pb-schedule__title">' + esc(group) + '</h3>' +
          '<div class="vc-master-detail__table-wrap"><table class="vc-master-detail__table vc-pb-matrix" aria-label="Discount schedule, ' + esc(group) + '"><thead><tr>' +
            '<th class="table-header-cell vc-pb-matrix__product-col">Term</th>' + tiers.map(function (b) { return '<th class="table-header-cell">' + esc(b.tier + ' (' + bandText(b) + ')') + '</th>'; }).join('') +
          '</tr></thead><tbody>' + rows + '</tbody></table></div></div>';
      }).join('');
  }
  function bandText(b) { return b.max == null || b.max === '' ? b.min + '+' : b.min + '–' + b.max; }

  // Tier bands: in a draft only the maximums are typed — each minimum is the previous maximum + 1 and the last tier is
  // open — so there are no overlaps and no gaps by construction; a maximum below its minimum is an error.
  function tierError(tiers, i) {
    var b = tiers[i];
    if (i === tiers.length - 1) return '';
    if (b.max === '' || b.max == null) return 'Enter a maximum';
    var n = parseFloat(b.max);
    return isNaN(n) || Math.round(n) !== n ? 'Whole number' : n < b.min ? 'At least ' + b.min : '';
  }
  function relinkTiers(tiers) {
    tiers.forEach(function (b, i) {
      b.tier = 'Tier ' + (i + 1);
      b.min = i === 0 ? 1 : (parseInt(tiers[i - 1].max, 10) || tiers[i - 1].min) + 1;
      if (i === tiers.length - 1) b.max = null;
    });
  }
  function tiersHtml(book, version, editable) {
    var tiers = PD.versionTiers(version);
    var orig = editable ? ensureDraft(version).original.tiers : null;
    var rows = tiers.map(function (b, i) {
      var last = i === tiers.length - 1;
      var maxCell = !editable ? (b.max == null ? 'and above' : esc(b.max))
        : last ? 'and above'
        : '<input type="number" class="input input--small vc-form-page__input--narrow" id="pd-pb-tier-max-' + i + '" min="' + b.min + '" step="1" value="' + esc(b.max) + '"' +
            ' aria-label="' + esc(b.tier) + ' maximum" aria-describedby="pd-pb-tier-max-' + i + '-error" oninput="PD.setDraftTierMax(\'' + esc(book.id) + '\', ' + i + ', this.value)">' +
          '<span class="input__error-text' + (PD.pricebookState.showErrors && tierError(tiers, i) ? '' : ' hidden') + '" id="pd-pb-tier-max-' + i + '-error">' + esc(PD.pricebookState.showErrors ? tierError(tiers, i) : '') + '</span>' +
          '<div class="text-body-small ql-cell-ref" id="pd-pb-tier-max-' + i + '-was">' + (orig && orig[i] && orig[i].max != null && String(orig[i].max) !== String(b.max) ? 'was ' + esc(orig[i].max) : '') + '</div>';
      return '<tr><td class="table-body-cell">' + esc(b.tier) + '</td><td class="table-body-cell" id="pd-pb-tier-min-' + i + '">' + b.min + '</td>' +
        '<td class="table-body-cell">' + maxCell + '</td>' +
        (editable ? '<td class="table-body-cell">' + (last && tiers.length > 1 ? '<button type="button" class="btn-icon btn-icon--ghost-vds btn-icon--vds-small" id="pd-pb-tier-remove" aria-label="Remove ' + esc(b.tier) + '" title="Remove ' + esc(b.tier) + '" onclick="PD.removeDraftTier(\'' + esc(book.id) + '\')"><span class="material-symbols-outlined" aria-hidden="true">delete</span></button>' : '') + '</td>' : '') +
      '</tr>';
    });
    // No note above the tier bands (Catalina, 2026-11-03).
    return '<div class="vc-master-detail__table-wrap">' + VC.dataTable({
        className: 'vc-master-detail__table vc-form-page__table', ariaLabel: 'Tier bands', id: 'pd-pb-tiers',
        columns: [{ label: 'Tier' }, { label: 'Minimum' }, { label: 'Maximum' }].concat(editable ? [{ label: '' }] : []),
        rowsHtml: rows,
      }) + '</div>' +
      (editable ? '<button type="button" class="btn-dashed-add btn-dashed-add--pill" id="pd-pb-tier-add" onclick="PD.addDraftTier(\'' + esc(book.id) + '\')">+ Add tier</button>' : '');
  }

  function versionCardHtml(book, v) {
    var tab = PD.pricebookState.tab;
    var tabs = '<div class="tabs" role="tablist" aria-label="Version content" id="pd-pb-tabs">' + TABS.map(function (t) {
      var on = t[0] === tab;
      return '<button type="button" class="tabs__item' + (on ? ' tabs__item--active' : '') + '" role="tab" aria-selected="' + on + '" id="pd-pb-tab-' + t[0] + '"' +
        ' aria-controls="pd-pb-panel" onclick="PD.setPriceBookTab(\'' + t[0] + '\')"><span>' + esc(t[1]) + '</span><span class="tabs__indicator' + (on ? '' : ' hidden') + '"></span></button>';
    }).join('') + '</div>';
    var draft = v.status === 'draft';
    var body = tab === 'schedules' ? schedulesHtml(book, v, draft) : tab === 'tiers' ? tiersHtml(book, v, draft) : pricesMatrixHtml(book, v, draft);
    return '<section class="vc-master-detail__detail vc-form-page__card" id="pd-pb-version" aria-labelledby="pd-pb-version-title">' +
      '<div class="vc-form-page__title-row"><h2 class="vc-form-page__card-title text-body-large-bold" id="pd-pb-version-title">Version ' + v.v + '</h2>' + badge(v.status) +
        '<span class="text-body-medium vc-form-page__meta" id="pd-pb-version-validity">' + esc(validity(v)) + '</span>' +
        // A scheduled version hasn't started: it can go back to draft to be changed (Catalina, 2026-10-30). Active and
        // expired versions are never edited.
        (v.status === 'scheduled' ? '<div class="vc-form-page__title-actions"><button type="button" class="btn btn--secondary btn--small" id="pd-pb-edit-version" onclick="PD.askEditScheduledVersion(\'' + esc(book.id) + '\', ' + v.v + ')">Edit</button></div>' : '') +
      '</div>' +
      tabs + '<div role="tabpanel" id="pd-pb-panel" aria-labelledby="pd-pb-tab-' + tab + '">' + body + '</div>' +
    '</section>' +
    '';
  }
  // A draft is edited in place: the form page's sticky footer (as the create-promotion form).
  function draftFooterHtml(book, v) {
    return (v.status === 'draft' ? '<div class="vc-form-page__footer" id="pd-pb-footer">' +
      '<button type="button" class="text-link vc-form-page__footer-cancel" id="pd-pb-delete-draft" onclick="PD.askDeletePriceBookDraft(\'' + esc(book.id) + '\')">Delete draft</button>' +
      '<button type="button" class="btn btn--primary btn--small" id="pd-pb-publish" onclick="PD.openPublishPriceBook(\'' + esc(book.id) + '\')">Publish v' + v.v + '</button>' +
    '</div>' : '');
  }

  function bookPageHtml(book) {
    if (!book) {
      return '<div class="vc-form-page" id="pd-pb-page"><div class="vc-form-page__header">' + crumb('Price book not found') +
        '<h1 class="vc-page-header__title" id="pd-page-title">Price book not found</h1></div></div>';
    }
    var v = selectedVersion(book);
    return '<div class="vc-form-page vc-form-page--wide" id="pd-pb-page">' +
      '<div class="vc-form-page__header">' + crumb(book.name) +
        '<div class="vc-form-page__title-row"><h1 class="vc-page-header__title" id="pd-pb-title">' + esc(book.name) + '</h1>' +
          '<span class="badge badge--gray-low">' + esc(book.type) + '</span></div>' +
        '<p class="vc-form-page__meta text-body-medium" id="pd-pb-meta">' + esc(count(book.accounts) + ' accounts · ' + book.description) + '</p>' +
      '</div>' +
      '<div class="vc-master-detail vc-master-detail--rail">' + versionsHtml(book, v) + versionCardHtml(book, v) + '</div>' +
      draftFooterHtml(book, v) +
    '</div>';
  }

  function rerenderBook() {
    var host = el('pd-pb-page');
    var book = PD.findPriceBook(PD.state.item);
    if (host && book) host.outerHTML = bookPageHtml(book);
  }

  PD.openPriceBook = function (id) {
    PD.navigate({ page: 'price-books', view: 'book', item: id });
    var title = el('pd-pb-title');
    if (title) { title.setAttribute('tabindex', '-1'); title.focus(); }
  };
  PD.closePriceBook = function () {
    var id = PD.state.item;
    PD.navigate({ page: 'price-books' });
    var link = el('pd-pb-link-' + id);
    if (link) link.focus();
  };
  PD.selectPriceBookVersion = function (bookId, v) {
    PD.pricebookState.versionByBook[bookId] = v;
    rerenderBook();
    var title = el('pd-pb-version-title');
    if (title) { title.setAttribute('tabindex', '-1'); title.focus(); }
  };
  PD.setPriceBookTab = function (tab) {
    PD.pricebookState.tab = tab;
    rerenderBook();
    var b = el('pd-pb-tab-' + tab);
    if (b) b.focus();
  };

  PD.renderPriceBooksPage = function (host, page) {
    page = page || { title: 'Price books' };
    if (PD.state.view === 'book') {
      var book = PD.findPriceBook(PD.state.item);
      host.innerHTML = bookPageHtml(book);
      document.title = (book ? book.name : 'Price book') + ' — Pricing Desk';
      return;
    }
    host.innerHTML = listPageHtml(page);
    PD.updatePriceBooks();
  };

  // ── Batch 2: new version, edit prices, publish, delete draft, create price book.
  function nextNumber(book) { return book.versions.reduce(function (m, v) { return Math.max(m, v.v); }, 0) + 1; }
  function showBookVersion(book, v) {
    PD.pricebookState.versionByBook[book.id] = v;
    PD.pricebookState.tab = 'prices';
    PD.pricebookState.showErrors = false;
  }
  PD.createPriceBookVersion = function (bookId) {
    var book = PD.findPriceBook(bookId);
    if (!book || draftOf(book)) return;
    var base = PD.activeVersion(book) || book.versions.filter(function (v) { return v.status !== 'draft'; }).slice(-1)[0] || book.versions[book.versions.length - 1];
    var v = { v: nextNumber(book), status: 'draft', from: null, to: null, publishedOn: null, publishedBy: null,
      scheduleSet: base ? base.scheduleSet : 'standard', basedOn: base ? base.v : null, prices: base ? PD.versionPrices(base) : PD.versionPrices({ priceFactor: 1 }),
      schedules: clone(base ? PD.versionSchedules(base) : PD.versionSchedules({ scheduleSet: 'standard' })), tiers: clone(base ? PD.versionTiers(base) : PD.versionTiers({})) };
    ensureDraft(v);
    book.versions.push(v);
    save();
    showBookVersion(book, v.v);
    rerenderBook();
    var first = el('pd-pb-price-0');
    if (first) first.focus();
    toast(book.name + ' v' + v.v + ' created as a draft' + (base ? ' from v' + base.v : ''));
  };
  PD.setDraftPrice = function (bookId, i, value) {
    var book = PD.findPriceBook(bookId);
    var d = book && draftOf(book);
    if (!d) return;
    if (!d.prices) d.prices = PD.versionPrices(d);
    var n = parseFloat(value);
    d.prices[i].price = value === '' || isNaN(n) ? '' : Math.round(n * 100) / 100;
    save();
    // Only the cell's notes change, so the input keeps the focus.
    var r = d.prices[i];
    var before = ensureDraft(d).original.prices.filter(function (x) { return x.product === r.product && x.saleMode === r.saleMode && x.component === r.component && x.install === r.install; })[0] || null;
    var was = el('pd-pb-was-' + i);
    if (was) was.textContent = before && before.price !== r.price ? 'was ' + (before.price === '' ? '--' : money(before.price)) : '';
    var errEl = el('pd-pb-price-' + i + '-error');
    if (errEl && PD.pricebookState.showErrors) { var e = priceError(value); errEl.textContent = e; errEl.classList.toggle('hidden', !e); }
  };

  function draftFor(bookId) { var book = PD.findPriceBook(bookId); var d = book && draftOf(book); return d ? { book: book, d: ensureDraft(d) } : null; }
  PD.setDraftSchedule = function (bookId, gi, ti, ki, value) {
    var x = draftFor(bookId); if (!x) return;
    var group = Object.keys(x.d.schedules)[gi]; if (!group) return;
    var n = parseFloat(value);
    x.d.schedules[group][ti][ki] = value === '' || isNaN(n) ? '' : Math.round(n * 10) / 10;
    save();
    var id = 'pd-pb-sched-' + gi + '-' + ti + '-' + ki;
    var o = x.d.original.schedules[group] && x.d.original.schedules[group][ti] ? x.d.original.schedules[group][ti][ki] : undefined;
    var was = el(id + '-was'); if (was && o !== undefined) was.textContent = String(o) !== String(x.d.schedules[group][ti][ki]) ? 'was ' + Number(o).toFixed(1) + '%' : '';
    var err = el(id + '-error'); if (err && PD.pricebookState.showErrors) { var e = pctError(value); err.textContent = e; err.classList.toggle('hidden', !e); }
  };
  PD.setDraftTierMax = function (bookId, i, value) {
    var x = draftFor(bookId); if (!x) return;
    var t = x.d.tiers;
    var n = parseFloat(value);
    t[i].max = value === '' || isNaN(n) ? '' : n;
    relinkTiers(t);
    save();
    // The next minimum follows; the tier labels in the schedules follow on the next render.
    t.forEach(function (b, k) { var m = el('pd-pb-tier-min-' + k); if (m) m.textContent = b.min; });
    var o = x.d.original.tiers[i];
    var was = el('pd-pb-tier-max-' + i + '-was'); if (was) was.textContent = o && o.max != null && String(o.max) !== String(t[i].max) ? 'was ' + o.max : '';
    if (PD.pricebookState.showErrors) t.forEach(function (b, k) { var e = el('pd-pb-tier-max-' + k + '-error'); if (e) { var m = tierError(t, k); e.textContent = m; e.classList.toggle('hidden', !m); } });
  };
  // Add a tier: the open last tier gets a maximum (its minimum + 49) and a new open tier follows; each schedule gets a
  // column for it, a copy of the last one. Remove: the last tier and its column go, the one before becomes open.
  PD.addDraftTier = function (bookId) {
    var x = draftFor(bookId); if (!x) return;
    var t = x.d.tiers, last = t[t.length - 1];
    last.max = last.min + 49;
    t.push({ tier: '', min: 0, max: null });
    relinkTiers(t);
    Object.keys(x.d.schedules).forEach(function (g) { x.d.schedules[g].forEach(function (row) { row.push(row[row.length - 1]); }); });
    save(); rerenderBook();
    var input = el('pd-pb-tier-max-' + (t.length - 2)); if (input) input.focus();
    toast('Tier ' + t.length + ' added; the discount schedules have a column for it');
  };
  PD.removeDraftTier = function (bookId) {
    var x = draftFor(bookId); if (!x) return;
    var t = x.d.tiers;
    if (t.length < 2) return;
    t.pop();
    relinkTiers(t);
    Object.keys(x.d.schedules).forEach(function (g) { x.d.schedules[g].forEach(function (row) { row.pop(); }); });
    save(); rerenderBook();
    var add = el('pd-pb-tier-add'); if (add) add.focus();
    toast('Tier ' + (t.length + 1) + ' removed with its column in the discount schedules');
  };

  // A price typed where the product wasn't sold that way adds the row; the input then works as any other (keeps focus).
  PD.setDraftMissingPrice = function (input, bookId, key, colIndex) {
    var book = PD.findPriceBook(bookId);
    var d = book && draftOf(book);
    if (!d) return;
    if (!d.prices) d.prices = PD.versionPrices(d);
    var product = productsOf(d.prices).filter(function (pr) { return productKey(pr) === key; })[0];
    var group = (d.prices.filter(function (r) { return r.product === product; })[0] || {}).group;
    var col = PRICE_COLS[colIndex];
    var charge = { Subscription: 'Monthly', Hardware: 'One-time', Installation: 'One-time' };
    d.prices.push({ product: product, group: group, saleMode: col.mode, component: col.component, install: col.install, charge: charge[col.component], price: '' });
    var i = d.prices.length - 1;
    input.id = 'pd-pb-price-' + i;
    input.setAttribute('oninput', "PD.setDraftPrice('" + bookId + "', " + i + ', this.value)');
    var cellEl = input.closest('td');
    var err = cellEl.querySelector('.input__error-text'); if (err) err.id = 'pd-pb-price-' + i + '-error';
    var was = cellEl.querySelector('.ql-cell-ref'); if (was) { was.id = 'pd-pb-was-' + i; }
    PD.setDraftPrice(bookId, i, input.value);
    if (was) was.textContent = 'new';
  };

  // Salesforce products a draft can add: the product catalog (Products page) when present, else the sample list.
  function sfProducts() {
    if (PD.catalogProducts) return PD.catalogProducts().map(function (p) { return { product: p.product, group: p.group }; });
    return (PD.PRICEBOOK_DATA || {}).salesforceProducts || [];
  }

  // Add a product from Salesforce to the draft (one row per price column, empty to fill in); remove one.
  PD.openAddDraftProduct = function (bookId) {
    var book = PD.findPriceBook(bookId);
    var d = book && draftOf(book);
    if (!d) return;
    var have = productsOf(PD.versionPrices(d));
    var list = sfProducts().filter(function (x) { return have.indexOf(x.product) === -1; });
    var body = list.length
      ? '<div class="vc-form-page__fields">' + field('pd-pb-add-product-select', 'Product', '<select class="select" id="pd-pb-add-product-select">' +
          list.map(function (x) { return '<option value="' + esc(x.product) + '">' + esc(x.product) + ' (' + esc(x.group) + ')</option>'; }).join('') + '</select>',
          'Products come from Salesforce. Its prices start empty: fill in the ones it\'s sold with.') + '</div>'
      : '<p class="text-body-medium">Every Salesforce product is already in this version.</p>';
    openModal(modal('pd-pb-add-modal', 'Add a product to v' + d.v, body, 'Add product', list.length ? 'PD.addDraftProduct(\'' + esc(book.id) + '\')' : 'PD.closePriceBookModal()'), 'pd-pb-add-product-select');
  };
  PD.addDraftProduct = function (bookId, product) {
    var book = PD.findPriceBook(bookId);
    var d = book && draftOf(book);
    if (!d) return false;
    product = product || (el('pd-pb-add-product-select') || {}).value;
    var info = sfProducts().filter(function (x) { return x.product === product; })[0];
    if (!info) return false;
    if (!d.prices) d.prices = PD.versionPrices(d);
    if (d.prices.some(function (r) { return r.product === product; })) return false;
    var charge = { Subscription: 'Monthly', Hardware: 'One-time', Installation: 'One-time' };
    PRICE_COLS.forEach(function (col) {
      d.prices.push({ product: product, group: info.group, saleMode: col.mode, component: col.component, install: col.install, charge: charge[col.component], price: '' });
    });
    save(); closeModal();
    PD.pricebookState.tab = 'prices';
    rerenderBook();
    var first = d.prices.length - PRICE_COLS.length;
    var input = el('pd-pb-price-' + first); if (input) input.focus();
    toast(productLabel(product) + ' added to v' + d.v);
    return true;
  };
  PD.removeDraftProduct = function (bookId, key) {
    var book = PD.findPriceBook(bookId);
    var d = book && draftOf(book);
    if (!d) return;
    if (!d.prices) d.prices = PD.versionPrices(d);
    var name = productsOf(d.prices).filter(function (pr) { return productKey(pr) === key; })[0];
    if (!name) return;
    d.prices = d.prices.filter(function (r) { return r.product !== name; });
    save();
    rerenderBook();
    var add = el('pd-pb-add-product'); if (add) add.focus();
    toast(productLabel(name) + ' removed from v' + d.v + '. Accounts that have it on their price card keep it.');
  };

  // Modals (VDS modal, as the create-promotion discard modal).
  function closeModal() { var m = el('pd-pb-modal'); if (m) m.remove(); }
  function openModal(html, focusId) {
    closeModal();
    document.body.insertAdjacentHTML('beforeend', '<div class="modal-overlay is-open" id="pd-pb-modal" onclick="PD.closePriceBookModal()">' + html + '</div>');
    if (VC.initDatePickers) VC.initDatePickers(el('pd-pb-modal'));
    if (VC.enhanceDropdowns) VC.enhanceDropdowns(el('pd-pb-modal'), 'select.select');
    var f = el(focusId); if (f) f.focus();
  }
  PD.closePriceBookModal = function () { closeModal(); };
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && el('pd-pb-modal')) closeModal(); });
  function field(id, label, control, note, optional, half) {
    return '<div class="vds-field vc-form-page__field' + (half ? '' : ' vc-form-page__field--full') + '"><label class="vc-field-label" for="' + id + '">' + esc(label) + (optional ? ' (optional)' : '') + '</label>' + control +
      '<span class="input__error-text hidden" id="' + id + '-error"></span>' + (note ? '<p class="vc-form-page__note text-body-small">' + note + '</p>' : '') + '</div>';
  }
  function dateField(id) {
    return '<span class="vc-date-field"><input type="date" class="input" id="' + id + '" aria-describedby="' + id + '-error">' +
      '<span class="material-symbols-outlined vc-date-field__icon" aria-hidden="true">calendar_month</span></span>';
  }
  function setError(id, text) {
    var e = el(id + '-error');
    if (e) { e.textContent = text || ''; e.classList.toggle('hidden', !text); }
    var input = el(id);
    if (input) input.setAttribute('aria-invalid', text ? 'true' : 'false');
  }
  function modal(id, title, bodyHtml, primaryLabel, onPrimary) {
    return '<div class="modal" role="dialog" aria-modal="true" aria-labelledby="' + id + '-title" id="' + id + '" onclick="event.stopPropagation()">' +
      '<div class="modal__content"><h2 class="modal__title" id="' + id + '-title">' + esc(title) + '</h2><div class="modal__body">' + bodyHtml + '</div></div>' +
      '<div class="modal__actions">' +
        '<button type="button" class="btn btn--secondary btn--large" id="' + id + '-cancel" onclick="PD.closePriceBookModal()">Cancel</button>' +
        '<button type="button" class="btn btn--primary btn--large" id="' + id + '-confirm" onclick="' + onPrimary + '">' + esc(primaryLabel) + '</button>' +
      '</div></div>';
  }

  // Publish: Valid from (required; after the latest published start; not before today), Valid to (optional).
  function latestStart(book) {
    return book.versions.filter(function (v) { return v.status !== 'draft' && v.from; }).map(function (v) { return v.from; }).sort().pop() || '';
  }
  PD.openPublishPriceBook = function (bookId) {
    var book = PD.findPriceBook(bookId);
    var d = book && draftOf(book);
    if (!d) return;
    ensureDraft(d);
    var dp = PD.versionPrices(d);
    var badPrices = dp.some(function (r) { return priceError(r.price); }) || unpricedProducts(dp).length > 0;
    var badSchedules = Object.keys(d.schedules).some(function (g) { return d.schedules[g].some(function (row) { return row.some(function (p) { return pctError(p); }); }); });
    var badTiers = d.tiers.some(function (b, i) { return tierError(d.tiers, i); });
    if (badPrices || badSchedules || badTiers) {
      PD.pricebookState.showErrors = true;
      PD.pricebookState.tab = badPrices ? 'prices' : badSchedules ? 'schedules' : 'tiers';
      rerenderBook();
      var first = document.querySelector('#pd-pb-panel .input__error-text:not(.hidden)');
      var row = first && first.closest('tr');
      var input = first && (first.id ? el(first.id.replace(/-error$/, '')) : row && row.querySelector('input'));
      if (input) input.focus();
      return;
    }
    var last = latestStart(book);
    var body = '<div class="vc-form-page__fields">' +
      field('pd-pb-from', 'Valid from', dateField('pd-pb-from'), last ? 'After ' + esc(fmt(last)) + ', when v' + esc(book.versions.filter(function (v) { return v.from === last; })[0].v) + ' starts.' : 'Today or later.', false, true) +
      field('pd-pb-to', 'Valid to', dateField('pd-pb-to'), 'Empty = no end date.', true, true) +
      '</div>' +
      '<ul class="vc-master-detail__bullets text-body-medium" id="pd-pb-publish-notes">' +
        '<li>Customers with an MSA keep the prices they ordered for their term (their price card is frozen).</li>' +
        '<li>The previous version ends the day before.</li>' +
        '<li>No approval needed.</li>' +
      '</ul>';
    openModal(modal('pd-pb-publish-modal', 'Publish ' + book.name + ' v' + d.v, body, 'Publish', 'PD.publishPriceBook(\'' + esc(book.id) + '\')'), 'pd-pb-from');
    // A version taken back from Scheduled proposes its dates again.
    if (d.proposedFrom && el('pd-pb-from')) { var f = el('pd-pb-from'); if (f._flatpickr) f._flatpickr.setDate(d.proposedFrom, true); else f.value = d.proposedFrom; }
    if (d.proposedTo && el('pd-pb-to')) { var t = el('pd-pb-to'); if (t._flatpickr) t._flatpickr.setDate(d.proposedTo, true); else t.value = d.proposedTo; }
  };
  PD.publishPriceBook = function (bookId, from, to) {
    var book = PD.findPriceBook(bookId);
    var d = book && draftOf(book);
    if (!d) return false;
    from = from != null ? from : (el('pd-pb-from') || {}).value || '';
    to = to != null ? to : (el('pd-pb-to') || {}).value || '';
    var last = latestStart(book), today = todayIso();
    var errFrom = !from ? 'Pick the date it starts' : from < today ? 'Can\'t be before today' : last && from <= last ? 'Must be after ' + fmt(last) : '';
    var errTo = to && from && to < from ? 'Must be on or after Valid from' : '';
    setError('pd-pb-from', errFrom);
    setError('pd-pb-to', errTo);
    if (errFrom || errTo) { var f = el(errFrom ? 'pd-pb-from' : 'pd-pb-to'); if (f) f.focus(); return false; }
    var starts = from <= today;
    // The version running on (or scheduled past) the new start ends the day before; one that starts today replaces
    // the active one.
    book.versions.forEach(function (v) {
      if (v === d || v.status === 'draft' || v.status === 'expired') return;
      if (!v.to || v.to >= from) { if (!starts) { v.closedBy = d.v; v.toBefore = v.to || null; } v.to = dayBefore(from); }
      if (starts && v.status === 'active') v.status = 'expired';
    });
    d.status = starts ? 'active' : 'scheduled';
    d.from = from; d.to = to || null;
    d.publishedOn = today; d.publishedBy = personaName();
    delete d.proposedFrom; delete d.proposedTo; delete d.original;
    save();
    closeModal();
    showBookVersion(book, d.v);
    rerenderBook();
    toast(book.name + ' v' + d.v + (starts ? ' published and active' : ' published, scheduled from ' + fmt(from)));
    return true;
  };

  // Edit a scheduled version: it goes back to Draft (keeping its dates as a proposal for Publish); a version it had
  // closed gets its end back. One draft at a time.
  PD.askEditScheduledVersion = function (bookId, n) {
    var book = PD.findPriceBook(bookId);
    var v = book && book.versions.filter(function (x) { return x.v === n; })[0];
    if (!v || v.status !== 'scheduled') return;
    var d = draftOf(book);
    var body = d
      ? '<p class="text-body-medium">v' + d.v + ' is already a draft. Publish or delete it first: one draft at a time.</p>'
      : '<p class="text-body-medium">It goes back to draft and won\'t start on ' + esc(fmt(v.from)) + ' unless you publish it again. Nobody is using it yet.</p>';
    openModal(modal('pd-pb-edit-modal', 'Edit v' + v.v + '?', body, d ? 'Go to draft v' + d.v : 'Edit',
      d ? 'PD.closePriceBookModal(); PD.selectPriceBookVersion(\'' + esc(book.id) + '\', ' + d.v + ')' : 'PD.editScheduledVersion(\'' + esc(book.id) + '\', ' + v.v + ')'), 'pd-pb-edit-modal-cancel');
  };
  PD.editScheduledVersion = function (bookId, n) {
    var book = PD.findPriceBook(bookId);
    var v = book && book.versions.filter(function (x) { return x.v === n; })[0];
    if (!v || v.status !== 'scheduled' || draftOf(book)) return false;
    book.versions.forEach(function (x) {
      if (x.closedBy === v.v) { x.to = x.toBefore || null; delete x.closedBy; delete x.toBefore; }
    });
    delete v.original;
    ensureDraft(v);
    v.proposedFrom = v.from; v.proposedTo = v.to;
    v.status = 'draft'; v.from = null; v.to = null; v.publishedOn = null; v.publishedBy = null;
    if (v.basedOn == null) { var prev = book.versions.filter(function (x) { return x.v < v.v && x.status !== 'draft'; }).pop(); v.basedOn = prev ? prev.v : null; }
    save(); closeModal();
    showBookVersion(book, v.v);
    rerenderBook();
    toast('v' + v.v + ' is a draft again: edit it and publish it');
    return true;
  };

  PD.askDeletePriceBookDraft = function (bookId) {
    var book = PD.findPriceBook(bookId);
    var d = book && draftOf(book);
    if (!d) return;
    openModal(modal('pd-pb-delete-modal', 'Delete the v' + d.v + ' draft?', '<p class="text-body-medium">Its prices will be lost.</p>', 'Delete draft',
      'PD.deletePriceBookDraft(\'' + esc(book.id) + '\')'), 'pd-pb-delete-modal-cancel');
  };
  PD.deletePriceBookDraft = function (bookId) {
    var book = PD.findPriceBook(bookId);
    var d = book && draftOf(book);
    if (!d) return;
    if (book.versions.length === 1) {
      // A new price book with only its draft goes away with it.
      PD.PRICE_BOOKS = PD.priceBooks().filter(function (b) { return b !== book; });
      save(); closeModal();
      PD.navigate({ page: 'price-books' });
      toast(book.name + ' deleted');
      return;
    }
    book.versions = book.versions.filter(function (v) { return v !== d; });
    save(); closeModal();
    PD.pricebookState.versionByBook[book.id] = null;
    rerenderBook();
    var b = el('pd-pb-create-version'); if (b) b.focus();
    toast('Draft v' + d.v + ' deleted');
  };

  // Create price book: name (unique), type, description, prices to start from → v1 Draft.
  PD.openCreatePriceBook = function () {
    var sources = PD.priceBooks().map(function (b) {
      var v = PD.activeVersion(b) || b.versions[b.versions.length - 1];
      return v ? '<option value="' + esc(b.id + ':' + v.v) + '">' + esc(b.name + ' — v' + v.v + ' (' + VSTATUS[v.status].label.toLowerCase() + ')') + '</option>' : '';
    }).join('');
    var type = '<div class="segmented-control" role="radiogroup" aria-label="Type" id="pd-pb-new-type">' +
      [['Standard', 'Standard'], ['Public schedule', 'Public schedule']].map(function (t, i) {
        return '<button type="button" role="radio" aria-checked="' + (i === 0) + '" class="segmented-control__option' + (i === 0 ? ' segmented-control__option--active' : '') + '" data-value="' + t[0] + '"' +
          ' onclick="PD.setNewPriceBookType(this)">' + t[1] + '</button>';
      }).join('') + '</div>';
    var body = '<div class="vc-form-page__fields">' +
      field('pd-pb-new-name', 'Name', '<input type="text" class="input" id="pd-pb-new-name" maxlength="40" aria-describedby="pd-pb-new-name-error" placeholder="e.g. Pilot East">', 'The identifier accounts use. Unique.') +
      '<div class="vds-field vc-form-page__field vc-form-page__field--full"><span class="vc-field-label">Type</span>' + type + '</div>' +
      field('pd-pb-new-desc', 'Description', '<input type="text" class="input" id="pd-pb-new-desc" maxlength="80">', '', true) +
      field('pd-pb-new-source', 'Start from the prices of', '<select class="select" id="pd-pb-new-source">' + sources + '<option value="base">Base list prices</option></select>',
        'Its discount schedules and tier bands come too. v1 opens as a draft to edit.') + '</div>';
    openModal(modal('pd-pb-new-modal', 'Create price book', body, 'Create', 'PD.createPriceBook()'), 'pd-pb-new-name');
  };
  PD.setNewPriceBookType = function (btn) {
    Array.prototype.forEach.call(btn.parentNode.children, function (b) {
      var on = b === btn;
      b.classList.toggle('segmented-control__option--active', on); b.setAttribute('aria-checked', on);
    });
  };
  function slug(name) { return name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'price-book'; }
  PD.createPriceBook = function (opts) {
    opts = opts || {};
    var name = (opts.name != null ? opts.name : (el('pd-pb-new-name') || {}).value || '').trim();
    var typeBtn = document.querySelector('#pd-pb-new-type [aria-checked="true"]');
    var type = opts.type || (typeBtn ? typeBtn.getAttribute('data-value') : 'Standard');
    var desc = (opts.description != null ? opts.description : (el('pd-pb-new-desc') || {}).value || '').trim();
    var source = opts.source || (el('pd-pb-new-source') || {}).value || 'base';
    var taken = PD.priceBooks().some(function (b) { return b.name.toLowerCase() === name.toLowerCase(); });
    var err = !name ? 'Enter a name' : taken ? 'There is already a price book with this name' : '';
    setError('pd-pb-new-name', err);
    if (err) { var n = el('pd-pb-new-name'); if (n) n.focus(); return null; }
    var base = null, set = 'standard';
    if (source !== 'base') {
      var parts = source.split(':'), sb = PD.findPriceBook(parts[0]);
      base = sb && sb.versions.filter(function (v) { return v.v === +parts[1]; })[0];
      if (base) set = base.scheduleSet;
    }
    var id = slug(name), k = 2;
    while (PD.findPriceBook(id)) id = slug(name) + '-' + k++;
    var book = { id: id, name: name, type: type, accounts: 0, description: desc || (type === 'Public schedule' ? 'Public schedule' : 'New price book'),
      versions: [ensureDraft({ v: 1, status: 'draft', from: null, to: null, publishedOn: null, publishedBy: null, scheduleSet: set, basedOn: null,
        prices: base ? PD.versionPrices(base) : PD.versionPrices({ priceFactor: 1 }),
        schedules: clone(base ? PD.versionSchedules(base) : PD.versionSchedules({ scheduleSet: set })), tiers: clone(base ? PD.versionTiers(base) : PD.versionTiers({})) })] };
    PD.PRICE_BOOKS = PD.priceBooks().concat([book]);
    save();
    closeModal();
    showBookVersion(book, 1);
    PD.openPriceBook(id);
    toast(name + ' created: v1 is a draft. Edit the prices and publish it.');
    return book;
  };

  PD.PAGE_RENDERERS = PD.PAGE_RENDERERS || {};
  PD.PAGE_RENDERERS['price-books'] = PD.renderPriceBooksPage;
})(window);
