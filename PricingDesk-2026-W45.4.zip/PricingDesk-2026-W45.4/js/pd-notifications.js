/* Pricing Desk — notifications bell in the app header, next to the user block (Catalina, 2026-10-26).
   The bell shows the number of unread notifications (VDS badge-indicator); it opens a panel with the persona's
   notifications, newest first: icon by kind, title, message and date; unread ones are marked. Picking one marks it as
   read and opens its promotion in Promotions & Discounts; "Mark all as read" clears the count.
   Data: config/notifications.config.js; what was read is kept for the session (sessionStorage, memory fallback). */
(function (global) {
  var PD = global.PD = global.PD || {};
  var ID = 'pd-notifications';
  var STORE_KEY = 'pd.notifications.session.v1';
  var memory = { read: [], added: [] };
  var KINDS = {
    approved: { icon: 'check_circle', className: 'vc-notifications__icon--success' },
    rejected: { icon: 'cancel', className: 'vc-notifications__icon--error' },
    request: { icon: 'pending_actions', className: '' },
  };

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function storage() { try { return global.sessionStorage || null; } catch (e) { return null; } }
  function readStore() {
    var s = storage();
    if (!s) return memory;
    try { var d = JSON.parse(s.getItem(STORE_KEY) || 'null'); if (d && Array.isArray(d.read)) { d.added = d.added || []; return d; } return memory; } catch (e) { return memory; }
  }
  function writeStore(d) {
    memory = { read: d.read.slice(), added: (d.added || []).slice() };
    var s = storage();
    try { if (s) s.setItem(STORE_KEY, JSON.stringify(memory)); } catch (e) { /* memory only */ }
  }
  PD.resetNotificationSession = function () {
    memory = { read: [], added: [] };
    var s = storage();
    try { if (s) s.removeItem(STORE_KEY); } catch (e) { /* blocked */ }
  };
  // A notification made in the demo (brief 04, batch 2: a decision on a request), for a persona; kept for the session.
  PD.addNotification = function (personaId, n) {
    var d = readStore();
    d.added = (d.added || []).concat([Object.assign({ unread: true }, n, { to: personaId })]);
    writeStore(d);
    refresh(false);
  };

  // The current persona's notifications, newest first, with the session's read state applied.
  PD.notifications = function () {
    var persona = PD.currentPersona ? PD.currentPersona() : null;
    var store = readStore(), read = store.read;
    var pid = persona ? persona.id : '';
    var added = (store.added || []).filter(function (n) { return n.to === pid; });
    return (((PD.NOTIFICATIONS || {})[pid]) || []).concat(added).map(function (n) {
      var copy = {};
      Object.keys(n).forEach(function (k) { copy[k] = n[k]; });
      copy.unread = n.unread && read.indexOf(n.id) === -1;
      return copy;
    }).sort(function (a, b) { return a.date < b.date ? 1 : a.date > b.date ? -1 : 0; });
  };
  PD.unreadNotificationCount = function () { return PD.notifications().filter(function (n) { return n.unread; }).length; };

  function itemHtml(n) {
    var k = KINDS[n.kind] || KINDS.approved;
    return '<li><button type="button" class="vc-notifications__item' + (n.unread ? ' is-unread' : '') + '" id="pd-notification-' + esc(n.id) + '" role="menuitem"' +
      ' onclick="PD.openNotification(\'' + esc(n.id) + '\')">' +
      '<span class="material-symbols-outlined vc-notifications__icon ' + k.className + '" aria-hidden="true">' + k.icon + '</span>' +
      '<span class="vc-notifications__text">' +
        '<span class="vc-notifications__title text-body-medium-bold">' + esc(n.title) + '</span>' +
        '<span class="vc-notifications__message text-body-small">' + esc(n.message) + '</span>' +
        '<span class="vc-notifications__date text-body-small">' + esc(PD.formatDate ? PD.formatDate(n.date) : n.date) + '</span>' +
      '</span>' +
      (n.unread ? '<span class="vc-notifications__dot" aria-label="Unread"></span>' : '') +
    '</button></li>';
  }

  function panelHtml(list) {
    var unread = list.filter(function (n) { return n.unread; }).length;
    return '<div class="vc-notifications__panel hidden" id="' + ID + '-panel" role="menu" aria-labelledby="' + ID + '-title">' +
      '<div class="vc-notifications__header">' +
        '<span class="text-body-large-bold" id="' + ID + '-title">Notifications</span>' +
        (unread ? '<button type="button" class="text-link text-link--small" id="' + ID + '-mark-all" onclick="PD.markAllNotificationsRead(event)">Mark all as read</button>' : '') +
      '</div>' +
      (list.length
        ? '<ul class="vc-notifications__list">' + list.map(itemHtml).join('') + '</ul>'
        : '<p class="vc-notifications__empty text-body-medium" id="' + ID + '-empty">No notifications yet</p>') +
    '</div>';
  }

  // The bell + panel, for the header's right side (js/pd-header.js puts it before the user block).
  PD.notificationsBell = function () {
    var list = PD.notifications();
    var unread = list.filter(function (n) { return n.unread; }).length;
    var label = 'Notifications' + (unread ? ' (' + unread + ' unread)' : '');
    return '<div class="vc-notifications" id="' + ID + '">' +
      '<button type="button" class="btn-icon btn-icon--ghost-vds btn-icon--vds-small vc-notifications__trigger" id="' + ID + '-trigger"' +
        ' aria-label="' + esc(label) + '" title="Notifications" aria-haspopup="menu" aria-expanded="false" aria-controls="' + ID + '-panel" onclick="PD.toggleNotifications(event)">' +
        '<span class="material-symbols-outlined" aria-hidden="true">notifications</span>' +
        (unread ? '<span class="badge-indicator badge-indicator--numbered vc-notifications__count" id="' + ID + '-count" aria-hidden="true">' + unread + '</span>' : '') +
      '</button>' + panelHtml(list) +
    '</div>';
  };

  function el(id) { return document.getElementById(id); }

  PD.setNotificationsOpen = function (open) {
    var panel = el(ID + '-panel');
    var trigger = el(ID + '-trigger');
    if (!panel || !trigger) return;
    panel.classList.toggle('hidden', !open);
    trigger.setAttribute('aria-expanded', String(!!open));
  };
  PD.toggleNotifications = function (event) {
    if (event) event.stopPropagation();
    var panel = el(ID + '-panel');
    PD.setNotificationsOpen(!!panel && panel.classList.contains('hidden'));
  };
  PD.isNotificationsOpen = function () { var p = el(ID + '-panel'); return !!p && !p.classList.contains('hidden'); };

  // Redraws the bell (count + panel) and keeps the panel open if it was.
  function refresh(keepOpen) {
    var host = el(ID);
    if (!host) return;
    host.outerHTML = PD.notificationsBell();
    if (keepOpen) PD.setNotificationsOpen(true);
  }

  PD.markNotificationRead = function (id) {
    var d = readStore();
    if (d.read.indexOf(id) === -1) d.read.push(id);
    writeStore(d);
  };
  PD.markAllNotificationsRead = function (event) {
    if (event) event.stopPropagation(); // the button is redrawn: the outside-click check would close the panel
    var d = readStore();
    PD.notifications().forEach(function (n) { if (d.read.indexOf(n.id) === -1) d.read.push(n.id); });
    writeStore(d);
    refresh(true);
    var trigger = el(ID + '-trigger');
    if (trigger) trigger.focus();
  };

  // Opens the notification's promotion (selected in Promotions & Discounts) and marks it as read.
  PD.openNotification = function (id) {
    var n = PD.notifications().filter(function (x) { return x.id === id; })[0];
    if (!n) return;
    PD.markNotificationRead(id);
    PD.setNotificationsOpen(false);
    // A request notification (approvers) opens the request.
    if (n.requestId && PD.openApprovalRequest) { PD.openApprovalRequest(n.requestId); return; }
    if (!n.promotionId) { refresh(false); return; } // nothing to open (e.g. a rep's Valu Cal request)
    if (n.promotionId && PD.promoState) {
      PD.promoState.search = '';
      PD.promoState.filters = { types: [], statuses: [] };
      PD.promoState.selectedId = n.promotionId;
    }
    PD.navigate({ page: 'promotions' });
    var item = el('pd-promo-item-' + n.promotionId);
    if (item) { item.focus(); if (item.scrollIntoView) item.scrollIntoView({ block: 'nearest' }); }
  };

  document.addEventListener('click', function (e) {
    var host = el(ID);
    if (host && !host.contains(e.target)) PD.setNotificationsOpen(false);
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && PD.isNotificationsOpen()) {
      PD.setNotificationsOpen(false);
      var trigger = el(ID + '-trigger');
      if (trigger) trigger.focus();
    }
  });
})(window);
