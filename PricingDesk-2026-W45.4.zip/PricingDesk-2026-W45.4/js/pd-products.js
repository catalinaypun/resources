/* Pricing Desk — Products (2026-11-03, Catalina: "armemos el product catalog"). Sam Rivera (Pricing Manager).
   Requirements by section › Section 1 (P-01): a view of the Salesforce product catalog where only the fields that
   affect pricing can be edited — weight for the tier count, schedule group, seasonal flag, instalments allowed — plus
   the product cost used to calculate margin. Products are created and maintained in Salesforce (read-only here).
   Page (?page=products): title and description on the left, search on the right (as Price books); a table with the
   products under their schedule group (as the price matrix): product + SKU, weight, seasonal, instalments, monthly
   cost, hardware cost, margin on the Commercial price book's active version, and "Edit". Edit opens a side drawer
   (as the Simulation Builder) with the Salesforce fields read-only and the pricing fields editable; Save / Cancel.
   The schedule group decides where a product sits in the price books; "+ Add product" in a price book draft offers
   these products. Changes are kept for the session (sessionStorage, memory fallback).
   PENDING (Leo): are these fields versioned with the price book (a new weight changes the tier of new orders)? Now
   they apply at once. Data: config/products.config.js (sample). */
(function (global) {
  var PD = global.PD = global.PD || {};
  var DRAWER = 'pd-product-drawer';
  var STORE_KEY = 'pd.products.session.v1';
  var memory = { changes: {} };
  PD.productsState = PD.productsState || { search: '', editing: null, showErrors: false };

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function el(id) { return document.getElementById(id); }
  function money(n) { return n == null || n === '' || isNaN(n) ? '--' : '$' + Number(n).toFixed(2); }
  function todayIso() {
    var d = new Date();
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  }
  function storage() { try { return global.sessionStorage || null; } catch (e) { return null; } }
  function readStore() {
    var s = storage();
    if (!s) return memory;
    try { var d = JSON.parse(s.getItem(STORE_KEY) || 'null'); return d && d.changes ? d : memory; } catch (e) { return memory; }
  }
  function writeStore(d) {
    memory = { changes: d.changes };
    var s = storage();
    try { if (s) s.setItem(STORE_KEY, JSON.stringify(memory)); } catch (e) { /* memory only */ }
  }
  PD.resetProductSession = function () {
    memory = { changes: {} };
    var s = storage();
    try { if (s) s.removeItem(STORE_KEY); } catch (e) { /* blocked */ }
  };

  // The catalog with the session's changes on top.
  PD.catalogProducts = function () {
    var changes = readStore().changes;
    return (PD.PRODUCT_CATALOG || []).map(function (p) {
      var c = changes[p.id];
      var out = {};
      Object.keys(p).forEach(function (k) { out[k] = p[k]; });
      if (c) Object.keys(c).forEach(function (k) { out[k] = c[k]; });
      return out;
    });
  };
  PD.findCatalogProduct = function (idOrName) {
    return PD.catalogProducts().filter(function (p) { return p.id === idOrName || p.product === idOrName; })[0] || null;
  };
  // The schedule group a product sits in (price books use it to place the product).
  PD.productGroup = function (name) { var p = PD.findCatalogProduct(name); return p ? p.group : null; };

  function shortName(name) { var i = name.indexOf(':'); var t = i === -1 ? name : name.slice(i + 1).trim(); return t.charAt(0).toUpperCase() + t.slice(1); }
  function instalmentsText(n) { return n ? 'Up to ' + n + ' months' : 'Not allowed'; }
  // Margin on the monthly OPEX price of the Commercial price book's active version (the standard price).
  function commercialPrice(product) {
    var book = PD.findPriceBook ? PD.findPriceBook('commercial') : null;
    var v = book && PD.activeVersion ? PD.activeVersion(book) : null;
    if (!v || !PD.versionPrices) return null;
    var r = PD.versionPrices(v).filter(function (x) { return x.product === product && x.saleMode === 'OPEX' && x.component === 'Subscription'; })[0];
    return r && r.price !== '' ? Number(r.price) : null;
  }
  function marginText(p) {
    var price = commercialPrice(p.product);
    if (price == null || !price || p.cost === '' || p.cost == null) return '--';
    return Math.round((price - p.cost) / price * 100) + '%';
  }

  // ── Page.
  function rowHtml(p) {
    return '<tr id="pd-product-row-' + esc(p.id) + '">' +
      '<th scope="row" class="table-body-cell vc-pb-matrix__product"><span class="text-body-medium">' + esc(shortName(p.product)) + '</span>' +
        '<div class="text-body-small ql-cell-ref">' + esc(p.sku) + '</div></th>' +
      '<td class="table-body-cell">' + esc(p.weight) + '</td>' +
      '<td class="table-body-cell">' + (p.seasonal ? 'Yes' : 'No') + '</td>' +
      '<td class="table-body-cell">' + esc(instalmentsText(p.instalments)) + '</td>' +
      '<td class="table-body-cell">' + esc(money(p.cost)) + '</td>' +
      '<td class="table-body-cell">' + esc(money(p.hardwareCost)) + '</td>' +
      '<td class="table-body-cell" id="pd-product-margin-' + esc(p.id) + '">' + esc(marginText(p)) + '</td>' +
      '<td class="table-body-cell"><button type="button" class="btn btn--secondary btn--small" id="pd-product-edit-' + esc(p.id) + '"' +
        ' aria-label="Edit ' + esc(p.product) + '" onclick="PD.openProduct(\'' + esc(p.id) + '\')">Edit</button></td>' +
    '</tr>';
  }
  PD.updateProducts = function () {
    var host = el('pd-products-items');
    if (!host) return;
    var q = (PD.productsState.search || '').trim().toLowerCase();
    var list = PD.catalogProducts().filter(function (p) { return !q || (p.product + ' ' + p.sku).toLowerCase().indexOf(q) !== -1; });
    if (!list.length) { host.innerHTML = '<div class="vc-master-detail__empty text-body-medium" id="pd-products-empty">No products match your search</div>'; return; }
    var groups = (PD.SCHEDULE_GROUPS || []).slice();
    list.forEach(function (p) { if (groups.indexOf(p.group) === -1) groups.push(p.group); });
    var heads = ['Weight', 'Seasonal', 'Instalments', 'Cost / month', 'Hardware cost', 'Margin (Commercial)', ''];
    var body = groups.map(function (g) {
      var inGroup = list.filter(function (p) { return p.group === g; });
      if (!inGroup.length) return '';
      return '<tr class="vc-pb-matrix__group"><th scope="rowgroup" colspan="' + (heads.length + 1) + '" class="table-body-cell">' + esc(g) + '</th></tr>' + inGroup.map(rowHtml).join('');
    }).join('');
    host.innerHTML = '<div class="vc-master-detail__table-wrap"><table class="vc-master-detail__table vc-pb-matrix vc-pb-matrix--catalog" aria-label="Products"><thead><tr>' +
      '<th class="table-header-cell vc-pb-matrix__product-col">Product</th>' + heads.map(function (h) { return '<th class="table-header-cell"' + (h ? '' : ' aria-label="Actions"') + '>' + (h ? esc(h) : '') + '</th>'; }).join('') +
      '</tr></thead><tbody id="pd-products-tbody">' + body + '</tbody></table></div>';
  };
  PD.setProductSearch = function (value) { PD.productsState.search = value || ''; PD.updateProducts(); };

  PD.renderProductsPage = function (host, page) {
    page = page || { title: 'Products' };
    host.innerHTML = '<div id="pd-products">' +
      '<div class="vc-page-header"><div class="vc-page-header__main">' +
        '<h1 class="vc-page-header__title" id="pd-page-title">' + esc(page.title) + '</h1>' +
        '<p class="vc-page-header__subtitle">Products come from Salesforce. Here you set what affects pricing: schedule group, weight, seasonal, instalments and cost.</p>' +
      '</div><div class="vc-page-header__actions vc-page-header__actions--inline">' +
        VC.searchField({ id: 'pd-products-search', placeholder: 'Search by product or SKU', value: PD.productsState.search, onInput: 'PD.setProductSearch(this.value)' }) +
      '</div></div>' +
      '<div id="pd-products-items"></div>' +
    '</div>';
    PD.updateProducts();
  };

  // ── Edit drawer.
  function field(id, label, control, note) {
    return '<div class="vds-field vc-form-page__field vc-form-page__field--full"><label class="vc-field-label" for="' + id + '">' + esc(label) + '</label>' + control +
      '<span class="input__error-text hidden" id="' + id + '-error"></span>' + (note ? '<p class="vc-form-page__note text-body-small">' + note + '</p>' : '') + '</div>';
  }
  function moneyInput(id, value) {
    return '<span class="input-affix"><span class="input-affix__text" aria-hidden="true">$</span><input type="number" class="input input-affix__field" id="' + id + '" min="0" step="0.01" value="' + esc(value) + '"' +
      ' aria-describedby="' + id + '-error" oninput="PD.previewProductMargin()"></span>';
  }
  function drawerBodyHtml(p) {
    var opts = function (list, cur, label) { return list.map(function (v) { return '<option value="' + esc(v) + '"' + (String(v) === String(cur) ? ' selected' : '') + '>' + esc(label ? label(v) : v) + '</option>'; }).join(''); };
    return '<p class="text-body-small-bold">From Salesforce</p>' +
      '<dl class="vc-master-detail__fields" id="pd-product-sf">' +
        '<dt class="text-body-small-bold">Product</dt><dd class="text-body-medium">' + esc(p.product) + '</dd>' +
        '<dt class="text-body-small-bold">SKU</dt><dd class="text-body-medium">' + esc(p.sku) + '</dd>' +
        '<dt class="text-body-small-bold">Family</dt><dd class="text-body-medium">' + esc(p.family) + '</dd>' +
      '</dl>' +
      '<p class="text-body-small-bold">Pricing</p>' +
      '<div class="vc-form-page__fields">' +
        field('pd-product-group', 'Schedule group', '<select class="select" id="pd-product-group">' + opts(PD.SCHEDULE_GROUPS || [], p.group) + '</select>',
          'Its discount schedule, and where it sits in the price books.') +
        field('pd-product-weight', 'Weight for the tier count', '<input type="number" class="input" id="pd-product-weight" min="0" step="0.5" value="' + esc(p.weight) + '" aria-describedby="pd-product-weight-error">',
          'How much one unit adds to the weighted quantity that sets the tier (0 = it doesn\'t count).') +
        '<div class="vds-field vc-form-page__field vc-form-page__field--full"><span class="vc-field-label" id="pd-product-seasonal-label">Seasonal</span>' +
          '<label class="toggle"><input type="checkbox" class="toggle__input" id="pd-product-seasonal" aria-labelledby="pd-product-seasonal-label"' + (p.seasonal ? ' checked' : '') + '>' +
          '<span class="toggle__track"><span class="toggle__knob"></span></span></label>' +
          '<p class="vc-form-page__note text-body-small">Seasonal lines are excluded from promotions.</p></div>' +
        field('pd-product-instalments', 'Instalments allowed', '<select class="select" id="pd-product-instalments">' + opts(PD.INSTALMENT_OPTIONS || [0, 12, 24, 36], p.instalments, instalmentsText) + '</select>',
          'Months the hardware can be paid over, under CAPEX.') +
        field('pd-product-cost', 'Cost per unit / month', moneyInput('pd-product-cost', p.cost), '') +
        field('pd-product-hardware-cost', 'Hardware cost per unit', moneyInput('pd-product-hardware-cost', p.hardwareCost), '') +
      '</div>' +
      '<p class="text-body-medium" id="pd-product-margin-preview"></p>' +
      (p.changedBy ? '<p class="vc-form-page__note text-body-small" id="pd-product-last-change">Last change by ' + esc(p.changedBy) + ' on ' + esc(PD.formatDate ? PD.formatDate(p.changedOn) : p.changedOn) + '</p>' : '');
  }
  function ensureDrawer() {
    if (el(DRAWER)) return;
    document.body.insertAdjacentHTML('beforeend', VC.drawer({
      id: DRAWER, title: 'Product', onClose: 'PD.closeProduct()',
      actions: [
        { label: 'Cancel', id: DRAWER + '-cancel', onClick: 'PD.closeProduct()' },
        { label: 'Save', primary: true, id: DRAWER + '-save', onClick: 'PD.saveProduct()' },
      ],
    }));
    el(DRAWER).getBoundingClientRect(); // so the first slide-in animates
  }
  PD.openProduct = function (id) {
    var p = PD.findCatalogProduct(id);
    if (!p) return;
    ensureDrawer();
    PD.productsState.editing = id;
    var t = el(DRAWER + '-title'); if (t) t.textContent = shortName(p.product);
    var sub = el(DRAWER + '-sub'); if (sub) sub.textContent = p.sku + ' · ' + p.group;
    var body = document.querySelector('#' + DRAWER + ' .vc-drawer__body');
    body.innerHTML = drawerBodyHtml(p);
    if (VC.enhanceDropdowns) VC.enhanceDropdowns(body, 'select.select');
    PD.previewProductMargin();
    VC.setDrawerOpen(DRAWER, true);
    var f = el('pd-product-weight'); if (f) f.focus();
  };
  PD.isProductOpen = function () { var d = el(DRAWER); return !!d && d.classList.contains('is-open'); };
  PD.closeProduct = function () {
    VC.setDrawerOpen(DRAWER, false);
    var id = PD.productsState.editing;
    PD.productsState.editing = null;
    var b = id && el('pd-product-edit-' + id); if (b) b.focus();
  };
  PD.previewProductMargin = function () {
    var id = PD.productsState.editing, p = id && PD.findCatalogProduct(id), out = el('pd-product-margin-preview');
    if (!p || !out) return;
    var price = commercialPrice(p.product), cost = parseFloat((el('pd-product-cost') || {}).value);
    out.textContent = price == null ? 'Not in the Commercial price book yet: no margin to show.'
      : isNaN(cost) ? '' : 'Margin on Commercial (' + money(price) + ' / month): ' + Math.round((price - cost) / price * 100) + '%';
  };
  function setError(id, text) {
    var e = el(id + '-error'); if (e) { e.textContent = text || ''; e.classList.toggle('hidden', !text); }
    var i = el(id); if (i) i.setAttribute('aria-invalid', text ? 'true' : 'false');
  }
  function numberError(v) { if (v === '' || v == null) return 'Enter a number'; var n = parseFloat(v); return isNaN(n) ? 'Enter a number' : n < 0 ? 'Can\'t be negative' : ''; }
  // Save: checks the numbers, keeps the change for the session and redraws the table.
  PD.saveProduct = function (values) {
    var id = PD.productsState.editing;
    var p = id && PD.findCatalogProduct(id);
    if (!p) return false;
    values = values || {
      group: (el('pd-product-group') || {}).value, weight: (el('pd-product-weight') || {}).value,
      seasonal: !!(el('pd-product-seasonal') || {}).checked, instalments: (el('pd-product-instalments') || {}).value,
      cost: (el('pd-product-cost') || {}).value, hardwareCost: (el('pd-product-hardware-cost') || {}).value,
    };
    var errs = { 'pd-product-weight': numberError(values.weight), 'pd-product-cost': numberError(values.cost), 'pd-product-hardware-cost': numberError(values.hardwareCost) };
    Object.keys(errs).forEach(function (k) { setError(k, errs[k]); });
    var first = Object.keys(errs).filter(function (k) { return errs[k]; })[0];
    if (first) { var f = el(first); if (f) f.focus(); return false; }
    var store = readStore();
    var me = PD.currentPersona ? PD.currentPersona() : null;
    store.changes[id] = {
      group: values.group || p.group, weight: parseFloat(values.weight), seasonal: !!values.seasonal, instalments: parseInt(values.instalments, 10) || 0,
      cost: parseFloat(values.cost), hardwareCost: parseFloat(values.hardwareCost), changedBy: me ? me.name : 'Sam Rivera', changedOn: todayIso(),
    };
    writeStore(store);
    PD.closeProduct();
    PD.updateProducts();
    var b = el('pd-product-edit-' + id); if (b) b.focus();
    if (PD.showToast) PD.showToast(shortName(p.product) + ' saved');
    return true;
  };
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && PD.isProductOpen()) PD.closeProduct(); });

  PD.PAGE_RENDERERS = PD.PAGE_RENDERERS || {};
  PD.PAGE_RENDERERS.products = PD.renderProductsPage;
})(window);
