/* Pricing Desk personas (brief 01) — sample data for the demo role switcher; not real users.
   One entry per role: who it is, the page it lands on (home) and the menu items it sees, as page ids:
   price-books, promotions, custom-settings, approvals, approval-rules, my-requests (pages come in batch 2).
   approvalLevel = the approver level the persona decides (brief 04: 1 Associate Director, 2 Director, 3 Pricing & Finance).
   The current persona is kept in the URL (?persona=<id>); no persona (or an unknown one) → defaultId. */
(function (global) {
  global.PD = global.PD || {};
  global.PD.PERSONAS_CONFIG = {
    defaultId: 'alicia',
    personas: [
      { id: 'pricing', name: 'Sam Rivera', role: 'Pricing Manager', home: 'price-books', menu: ['price-books', 'products'] },
      { id: 'alicia', name: 'Alicia Milton', role: 'Promotion Manager', home: 'promotions', menu: ['promotions', 'custom-settings'] },
      { id: 'ad', name: 'Alex Torres', role: 'Associate Director', approvalLevel: 1, home: 'approvals', menu: ['approvals'] },
      { id: 'director', name: 'Morgan Chen', role: 'Director, SMB', approvalLevel: 2, home: 'approvals', menu: ['approvals'] },
      { id: 'finance', name: 'Taylor Wright', role: 'Pricing & Finance', approvalLevel: 3, home: 'approvals', menu: ['approvals', 'approval-rules'] },
      { id: 'rep', name: 'Jordan Kim', role: 'Sales Rep', home: 'my-requests', menu: ['my-requests'] },
    ],
  };
})(window);
