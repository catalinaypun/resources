/* Pricing Desk price books (brief 05) — sample data only. Requirements by section › Section 1: a price book has
   versions with a validity range and a published date; ranges of the same price book never overlap; a published
   version is never edited (a change is a new version); several price books can be active at once; public schedules
   (GSA, Sourcewell) have their own. Each version holds its prices, discount schedules and tier bands.
   To keep the sample short, a version's prices are the base rows below times its priceFactor (rounded to the cent),
   and its discount schedules come from a named set (scheduleSet). Version statuses (Active, Scheduled, Draft,
   Expired) are our naming — to confirm with Leo. */
(function (global) {
  global.PD = global.PD || {};

  // Base list prices: product × sale mode × component × installation method. Monthly = per unit per month;
  // One-time = per unit. OPEX subscription includes hardware (and installation with VMI); the OPEX installation row
  // is for extra installations; CAPEX charges subscription, hardware and installation separately.
  var BASE_PRICES = [];
  [
    ['Vehicle tracking: GPS tracker', 'Vehicle tracking', 22, 14, 120, 45, 60],
    ['Video: road-facing camera', 'Video', 32, 20, 199, 60, 80],
    ['Video: dual camera', 'Video', 45, 28, 349, 75, 95],
    ['Asset tracker: powered', 'Asset tracking', 16, 10, 89, 40, 55],
    ['Asset tracker: non-powered', 'Asset tracking', 12, 8, 69, 0, 0],
  ].forEach(function (p) {
    var product = p[0], group = p[1];
    BASE_PRICES.push(
      { product: product, group: group, saleMode: 'OPEX', component: 'Subscription', install: 'Any', charge: 'Monthly', price: p[2] },
      { product: product, group: group, saleMode: 'OPEX', component: 'Installation', install: 'VMI', charge: 'One-time', price: p[5] },
      { product: product, group: group, saleMode: 'CAPEX', component: 'Subscription', install: 'Any', charge: 'Monthly', price: p[3] },
      { product: product, group: group, saleMode: 'CAPEX', component: 'Hardware', install: 'Any', charge: 'One-time', price: p[4] },
      { product: product, group: group, saleMode: 'CAPEX', component: 'Installation', install: 'VMI', charge: 'One-time', price: p[5] }
    );
    // No CAPEX installation by CMI in a price book (Catalina, 2026-11-03); p[6] (the old CMI price) is not used.
  });
  // Non-powered asset trackers are wireless: no installation rows (as Valu Cal's "Wireless asset trackers do not
  // require installation").
  BASE_PRICES = BASE_PRICES.filter(function (r) { return !(r.component === 'Installation' && r.price === 0); });

  var TERMS = [12, 24, 36, 48, 60];
  var TIER_BANDS = [
    { tier: 'Tier 1', min: 1, max: 9 },
    { tier: 'Tier 2', min: 10, max: 19 },
    { tier: 'Tier 3', min: 20, max: 49 },
    { tier: 'Tier 4', min: 50, max: 99 },
    { tier: 'Tier 5', min: 100, max: null },
  ];
  // Discount schedule sets: % per schedule group = start + per longer term + per higher tier (sample shape).
  function schedule(start, perTerm, perTier) {
    return TERMS.map(function (t, i) { return TIER_BANDS.map(function (b, j) { return Math.round((start + i * perTerm + j * perTier) * 10) / 10; }); });
  }
  var SCHEDULE_SETS = {
    standard: { 'Vehicle tracking': schedule(0, 2, 1.5), Video: schedule(0, 1.5, 1), 'Asset tracking': schedule(0, 2.5, 2) },
    standard2027: { 'Vehicle tracking': schedule(0, 2, 2), Video: schedule(0, 2, 1), 'Asset tracking': schedule(0, 2.5, 2) },
    pilot: { 'Vehicle tracking': schedule(2, 2, 1.5), Video: schedule(2, 1.5, 1), 'Asset tracking': schedule(2, 2.5, 2) },
    public: { 'Vehicle tracking': schedule(5, 1, 0.5), Video: schedule(5, 1, 0.5), 'Asset tracking': schedule(5, 1, 0.5) },
  };

  // Products in Salesforce that a draft can add (sample; products are created in Salesforce, Pricing Desk only prices
  // them — requirements by section › Section 1). The first five are already in every price book.
  var SALESFORCE_PRODUCTS = [
    { product: 'Vehicle tracking: GPS tracker', group: 'Vehicle tracking' },
    { product: 'Vehicle tracking: OBD plug-in', group: 'Vehicle tracking' },
    { product: 'Driver ID', group: 'Vehicle tracking' },
    { product: 'Video: road-facing camera', group: 'Video' },
    { product: 'Video: dual camera', group: 'Video' },
    { product: 'Video: AI dashcam', group: 'Video' },
    { product: 'Asset tracker: powered', group: 'Asset tracking' },
    { product: 'Asset tracker: non-powered', group: 'Asset tracking' },
    { product: 'Asset tracker: solar', group: 'Asset tracking' },
  ];
  global.PD.PRICEBOOK_DATA = { basePrices: BASE_PRICES, terms: TERMS, tierBands: TIER_BANDS, scheduleSets: SCHEDULE_SETS, salesforceProducts: SALESFORCE_PRODUCTS };

  global.PD.PRICE_BOOKS = [
    {
      id: 'commercial', name: 'Commercial', type: 'Standard', accounts: 1248, description: 'Standard prices for every MSA account',
      versions: [
        { v: 1, status: 'expired', from: '2025-01-01', to: '2025-12-31', publishedOn: '2024-12-10', publishedBy: 'Sam Rivera', priceFactor: 0.95, scheduleSet: 'standard' },
        { v: 2, status: 'expired', from: '2026-01-01', to: '2026-06-30', publishedOn: '2025-12-12', publishedBy: 'Sam Rivera', priceFactor: 0.98, scheduleSet: 'standard' },
        { v: 3, status: 'active', from: '2026-07-01', to: '2026-12-31', publishedOn: '2026-06-15', publishedBy: 'Sam Rivera', priceFactor: 1, scheduleSet: 'standard' },
        { v: 4, status: 'scheduled', from: '2027-01-01', to: null, publishedOn: '2026-10-20', publishedBy: 'Sam Rivera', priceFactor: 1.03, scheduleSet: 'standard2027' },
      ],
    },
    {
      id: 'pilot-west', name: 'Pilot West', type: 'Standard', accounts: 36, description: 'Pilot prices for the West region (active alongside Commercial)',
      versions: [
        { v: 1, status: 'active', from: '2026-09-01', to: '2027-02-28', publishedOn: '2026-08-25', publishedBy: 'Sam Rivera', priceFactor: 0.97, scheduleSet: 'pilot' },
        { v: 2, status: 'draft', from: null, to: null, publishedOn: null, publishedBy: null, priceFactor: 0.97, scheduleSet: 'pilot' },
      ],
    },
    {
      id: 'gsa', name: 'GSA', type: 'Public schedule', accounts: 84, description: 'U.S. General Services Administration schedule',
      versions: [
        { v: 1, status: 'expired', from: '2024-04-01', to: '2026-03-31', publishedOn: '2024-03-20', publishedBy: 'Sam Rivera', priceFactor: 0.88, scheduleSet: 'public' },
        { v: 2, status: 'active', from: '2026-04-01', to: '2028-03-31', publishedOn: '2026-03-18', publishedBy: 'Sam Rivera', priceFactor: 0.9, scheduleSet: 'public' },
      ],
    },
    {
      id: 'sourcewell', name: 'Sourcewell', type: 'Public schedule', accounts: 57, description: 'Sourcewell cooperative purchasing contract',
      versions: [
        { v: 1, status: 'active', from: '2025-07-01', to: '2027-06-30', publishedOn: '2025-06-24', publishedBy: 'Sam Rivera', priceFactor: 0.92, scheduleSet: 'public' },
      ],
    },
  ];
})(window);
