/* Pricing Desk product catalog (2026-11-03, Catalina: "armemos el product catalog") — sample data only.
   Requirements by section › Section 1: products are created and maintained in Salesforce; Pricing Desk has a view of
   the catalog where only the fields that affect pricing can be edited — weight for the tier count, schedule group,
   seasonal flag and instalments allowed — plus the product cost used to calculate margin.
   Salesforce (read-only): product, sku, family. Pricing (editable): group (schedule group), weight (how much one unit
   adds to the weighted quantity that sets the tier), seasonal, instalments (months the hardware can be paid over; 0 =
   not allowed), cost (monthly cost per unit) and hardwareCost (per unit; CAPEX).
   The same products feed the price books ("+ Add product" in a draft) and their schedule group places them there. */
(function (global) {
  global.PD = global.PD || {};
  global.PD.PRODUCT_CATALOG = [
    { id: 'vt-gps', product: 'Vehicle tracking: GPS tracker', sku: 'VZC-VT-GPS-01', family: 'Fleet', group: 'Vehicle tracking', weight: 1, seasonal: false, instalments: 24, cost: 8.5, hardwareCost: 62 },
    { id: 'vt-obd', product: 'Vehicle tracking: OBD plug-in', sku: 'VZC-VT-OBD-02', family: 'Fleet', group: 'Vehicle tracking', weight: 1, seasonal: false, instalments: 12, cost: 7, hardwareCost: 38 },
    { id: 'driver-id', product: 'Driver ID', sku: 'VZC-VT-DID-03', family: 'Fleet', group: 'Vehicle tracking', weight: 0, seasonal: false, instalments: 0, cost: 1.5, hardwareCost: 12 },
    { id: 'video-road', product: 'Video: road-facing camera', sku: 'VZC-VID-RF-01', family: 'Video', group: 'Video', weight: 1, seasonal: false, instalments: 36, cost: 13, hardwareCost: 110 },
    { id: 'video-dual', product: 'Video: dual camera', sku: 'VZC-VID-DC-02', family: 'Video', group: 'Video', weight: 1.5, seasonal: false, instalments: 36, cost: 19, hardwareCost: 205 },
    { id: 'video-ai', product: 'Video: AI dashcam', sku: 'VZC-VID-AI-03', family: 'Video', group: 'Video', weight: 1.5, seasonal: false, instalments: 36, cost: 22, hardwareCost: 240 },
    { id: 'at-powered', product: 'Asset tracker: powered', sku: 'VZC-AT-PW-01', family: 'Asset tracking', group: 'Asset tracking', weight: 0.5, seasonal: false, instalments: 12, cost: 6, hardwareCost: 48 },
    { id: 'at-non-powered', product: 'Asset tracker: non-powered', sku: 'VZC-AT-NP-02', family: 'Asset tracking', group: 'Asset tracking', weight: 0.5, seasonal: true, instalments: 0, cost: 4.5, hardwareCost: 35 },
    { id: 'at-solar', product: 'Asset tracker: solar', sku: 'VZC-AT-SO-03', family: 'Asset tracking', group: 'Asset tracking', weight: 0.5, seasonal: true, instalments: 12, cost: 5, hardwareCost: 54 },
  ];
  global.PD.SCHEDULE_GROUPS = ['Vehicle tracking', 'Video', 'Asset tracking'];
  global.PD.INSTALMENT_OPTIONS = [0, 12, 24, 36];
})(window);
