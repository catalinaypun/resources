/* Pricing Desk pages (brief 01, batch 2) — one page per section; for now each page is only its page header (title +
   one-line subtitle) with an empty body. The menu label of a page is its title. Which persona sees which page:
   config/personas.config.js (home + menu). The page is kept in the URL: ?persona=<id>&page=<page id>.
   headerInBody: the page's renderer shows the title and subtitle itself (Promotions: inside the full-height list).
   2026-10-26 (brief 02, batch 2 — Leo's review): Promotions renamed "Promotions & Discounts" (page title and menu label); no subtitle (Catalina, 2026-10-26). */
(function (global) {
  global.PD = global.PD || {};
  global.PD.PAGES = [
    { id: 'price-books', title: 'Price books', subtitle: '', headerInBody: true }, // brief 05: the page renders its own header
    { id: 'products', title: 'Products', subtitle: '', headerInBody: true }, // 2026-11-03: product catalog (P-01)
    { id: 'promotions', title: 'Promotions & Discounts', subtitle: '', headerInBody: true },
    { id: 'custom-settings', title: 'Custom promotion settings', subtitle: 'What reps can build as a custom promotion in Valu Cal.' },
    { id: 'approvals', title: 'Approvals', subtitle: '', headerInBody: true }, // brief 04: the queue carries the title
    { id: 'approval-rules', title: 'Approval rules', subtitle: 'What triggers an approval and who approves it.' },
    { id: 'my-requests', title: 'My requests', subtitle: 'Your approval requests and performance.' },
  ];
})(window);
