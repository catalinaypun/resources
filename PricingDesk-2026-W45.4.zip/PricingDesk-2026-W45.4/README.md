# Pricing Desk - prototype 2026-W45.4 (standalone, built Nov 5, 2026)

Open `index.html` in a browser (an internet connection loads the icon font and the date picker).

| Folder | What it is |
|---|---|
| `design-system/pricing-desk-design-system.css` | The whole design system in one stylesheet: tokens, typography, base components and the components shared with Valu Cal. `fonts/` and `icons/` hold only what it uses. |
| `js/` | Shared components (`vc-*.js`) and Pricing Desk logic (`pd-*.js`). |
| `config/` | Sample data: roles, pages, catalog, promotions, approval requests, Pricing & Finance ranges, notifications. |
| `img/` | Shared images. |

**Simulation Builder** (top right, Salesforce bar) switches the role: Pricing Manager (Sam Rivera) works in Price
books; Promotion Manager (Alicia Milton) in Promotions & Discounts; the approvers (Alex Torres, Morgan Chen, Taylor
Wright) in Approvals. Changes made in the demo (new promotions, submissions, price book versions) are kept while the
browser tab is open.

**Explorations** (`explorations/`): variants of a screen to compare with the prototype, e.g.
`explorations/promotion-create-v2.html` (Create promotion v2, the rules builder). They open the same app.
